package ca.sshrc.web.common.services;

import java.util.*;

import javax.servlet.http.*;

import ca.sshrc.web.common.beans.popupList.*;
import ca.sshrc.web.common.services.baseObject.*;
import ca.sshrc.web.common.util.*;
import ca.sshrc.web.forms.portFolio.*;
import ca.sshrc.web.lookupCache.*;
import hibernate.interceptors.*;
import org.hibernate.*;
import org.apache.log4j.*;
import org.apache.commons.lang.StringUtils;


/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 * navigate
 *
 * Will save data if required and show the requested page based
 * on the requested subsystem id and module id.
 *
 * @return String
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class CommonAction extends ActionBase {
    private Logger logger = Logger.getLogger(CommonAction.class.getName());

    public CommonAction() {
        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("CommonAction.constructor");
        }
    }

    public String showPortFolio() {
        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("CommonAction.showPortFolio");
            logger.info("CommonAction.showPortFolio - mainForm:formModified: " +
                        this.getHttpRequest().getParameter("mainForm:formModified"));
            logger.info("CommonAction.showPortFolio - this.getNavigationBean().getFormModified(): " +
                        this.getNavigationBean().getFormModified());
        }

        PortFolioAction portFolioAction = new PortFolioAction();

        // Call Save if required
        if (this.getNavigationBean().getFormModified().equalsIgnoreCase("Y")) {

            // Call save method
            if (this.save().compareToIgnoreCase(Constants.SUCCESS_OUTCOME) != 0) {
                // Save unsuccessful
                // Add error message and return to calling page OR forward to error page?
                return Constants.UPDATE_ERROR_OUTCOME;
            }
        }

        return portFolioAction.showPortFolio();
    }

    public String navigate() {
        String moduleName;

        // retrieve from navigationbean
        //              requestedModuleId
        //

        // Save if required
        if (this.getNavigationBean().getFormModified().compareToIgnoreCase("Y") == 0) {

            // Call save method
            if (this.save().equalsIgnoreCase(Constants.SUCCESS_OUTCOME)) {
                // Save unsuccessful
                // Add error message and return to calling page OR forward to error page?
                return Constants.UPDATE_ERROR_OUTCOME;
            }
        }

        // Reset navigation currentModuleId with requestedModuleId
        this.getNavigationBean().resetModuleId();

        // Reset navigation current & requested page - For multipage module
        this.getNavigationBean().setCurrentPageNumber(1);
        this.getNavigationBean().setRequestedPageNumber(1);

        /** Go to requested sub/module
         *
         * Faces-config.xml must have an entry named after the module name returned here.
         * NOT case sensitive.
         *
         * ex.: View id: /* (global)
          * from outcome: position
          * from action: #{commonAction.navigate}
          * to view id: /JSP/CV/CurrentPosition.jsp
          */
         if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
             logger.info("CommonAction.navigate - requested module ID: " +
                         this.getNavigationBean().getRequestedModuleId());
             logger.info("CommonAction.navigate - requested module name: " +
                         this.getNavigationBean().getRequestedModuleName());
         }

        moduleName = this.getNavigationBean().getRequestedModuleName().toLowerCase();

        // Attachments
        if (moduleName.equals("attachment")) {
            moduleName = this.getAttachmentName();
        }

        return moduleName;

    }

    public String exit() {

        // Save if required
        if (this.getNavigationBean().getFormModified().compareToIgnoreCase("Y") == 0) {
            if (this.save().compareToIgnoreCase(Constants.SUCCESS_OUTCOME) != 0) {
                // Save unsuccessful
                // Add error message and return to calling page OR forward to error page?
                return Constants.UPDATE_ERROR_OUTCOME;
            }
        }

        // Get and remove subsystem id from session bean
        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("CommonAction.exit");
        }

        HttpSession session = this.getHttpSession();

        session.removeAttribute("logonBean");
        session.removeAttribute("navigationBean");

        session.invalidate();
        return Constants.SUCCESS_OUTCOME;
    }

    /**
     * Call Save() on each bean that requires it, based on the subsystem id and the module name
     * Calling commonService.getModuleBeanClass(subSystemId, moduleName) will return an arrayList of
     * hibernate.WebModuleBeanClass.
     *
     * @return String
     */
    public String save() {
        Integer subSystemId;
        String moduleName;
        String saveOutcome = Constants.FAILURE_OUTCOME;
        BeanBase beanBaseContainer = null;
        ArrayList beanBaseContainerToCallRetrieveOn = new ArrayList();

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("CommonAction.save");
        }

        // Get targeted (current) subsystem & module name
        subSystemId = this.getNavigationBean().getCurrentSubsystemId();
        System.out.println("CommonAction.save - subsystemId = " + subSystemId);

        moduleName = this.getNavigationBean().getRequestedModuleName();
        System.out.println("CommonAction.save - moduleName = " + moduleName);
        moduleName = this.getNavigationBean().getCurrentModuleName();

        // Get bean classes to be processed
        ArrayList moduleBeanClassList = CommonService.getModuleBeanClass(subSystemId, moduleName);
        System.out.println("CommonAction.save - list of modules has " + moduleBeanClassList.size() +
                           " entries");

        // Get attribute names from request
        HttpServletRequest request = (HttpServletRequest)this.getExternalContext().
                                     getRequest();

        // Open Hibernate transaction
        try {
            // An update to form.formStatus column requires this interceptor.
            // See HibernateUtil.getSession() for more details.
            Interceptor interceptor = new FormStatusInterceptor();
            Session session = HibernateUtil.getSession(interceptor);

            HibernateUtil.beginTransaction();
            // loop in array of bean classes and look in the request attribute names list if it exist

            for (int i = 0; i < moduleBeanClassList.size(); i++) {
                // look for bean of each class type in request scope
                String beanClassName = ((hibernate.WebModuleBeanClass) moduleBeanClassList.get(i)).
                                       getBeanClassNickName();
                // Get class name out of the fully qualified class name
                System.out.println("CommonAction.save - for loop, beanClassNickName = " + beanClassName);

                if (beanClassName != null) {
                    beanBaseContainer = (BeanBase) request.getAttribute(beanClassName);

                    // Call Save() on that object
                    if (beanBaseContainer != null) {
                        saveOutcome = beanBaseContainer.save(session);

                        // Keep a copy so the bean's retrieve method can be called after the save's completed.
                        beanBaseContainerToCallRetrieveOn.add(beanBaseContainer);
                    }

                }

                // Exit as soon as a Failure occurs in any of the bean's call to Save() method.
                if (saveOutcome == Constants.UPDATE_ERROR_OUTCOME) {
                    break;
                }
            }

            // Reset modified status (attribute on the page and column on Form table) if save was successful
            if (saveOutcome == Constants.SUCCESS_OUTCOME) {
                // Set Form status

                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.info("CommonAction.save - setting form status to 'N'");
                }

                // Set Form(s) status to 'N'
                saveOutcome = CommonService.setFormStatus(new Long(this.getNavigationBean().getForm_id()),
                        new String("N"), moduleName, session);

                if (saveOutcome == Constants.SUCCESS_OUTCOME) {
                    if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                        logger.info("CommonAction.save - setting formModified page attribute to 'N'");
                    }

                    this.getNavigationBean().setFormModified("N");
                }

                // Call retrieve on bean(s) we just call the save on.
                beanBaseContainerToCallRetrieveOn.trimToSize();
                for (int i = 0; i < beanBaseContainerToCallRetrieveOn.size(); i++) {
                    beanBaseContainer = (BeanBase) beanBaseContainerToCallRetrieveOn.get(i);
                    beanBaseContainer.retrieve(session);
                }

                // Commit DB change(s)
                HibernateUtil.commitTransaction();

            } else {
                HibernateUtil.rollbackTransaction();
            }

        } catch (Exception ex) {
            HibernateUtil.rollbackTransaction();
            ex.printStackTrace();

        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        return saveOutcome;
    }

    public String print() {
        System.out.println("CommonAction.print");

        return Constants.SUCCESS_OUTCOME;
    }

    public String getInstructionUrl() {
        // Returns an href value for an OutputLink tag
        String helpFileName = null;
        String moduleName = null;
        String instructionUrl = null;
        WebSubSystemCache webSubSystemCache = null;
        String locale = null;
        String htmlPageLanguageExtension = null;

        // Get Instruction URL from systemCache
        /*try {
            JCS systemCacheCacheManager = JCS.getInstance("systemCache");
            webSubSystemCache = (WebSubSystemCache) systemCacheCacheManager.get("WebSubSystemCache");
                 } catch (Exception ex) {
            ex.printStackTrace();
                 }*/
        try {
            CacheService systemCacheCacheManager = CacheService.getInstance("systemCache");
            webSubSystemCache = (WebSubSystemCache) systemCacheCacheManager.get("WebSubSystemCache");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        if (webSubSystemCache != null) {
            helpFileName = webSubSystemCache.getHelpFileName(this.getNavigationBean().getRequestedSubsystemId());
        }

        /** INSTRUCTION URL - TO BE REVISITED WHEN THE WEB SERVER HANDLES THE HTTP CALLS.
         *  Instruction Url is made of web context, web_subsystem.help_file and module name
         *  We can't, right now, put "/JSP/Instructions-Help/" in the helpFileName. This will have to wait
         *  until we got to PROD or QA. All the static web page will probably be handle by the web server.
         */

        // Get module name which will be the html page's anchor value
        moduleName = "#" + this.getNavigationBean().getRequestedModuleName();

        // Get Locale and generate html page suffix/extension
        locale = this.getNavigationBean().getFormLanguage();
        if (locale.equalsIgnoreCase(Constants.ENGLISH_CANADIAN_LOCALE)) {
            htmlPageLanguageExtension = "_e.htm";
        } else {
            htmlPageLanguageExtension = "_f.htm";
        }

        instructionUrl = this.getExternalContext().getRequestContextPath() + "/Instructions-Help/" +
                         helpFileName + htmlPageLanguageExtension + moduleName;

        return instructionUrl;
    }

    public String getPrintUrl() {
        // Returns an href value for the print OutputLink tag
        return Constants.PRINT_URL_PB;
    }

    public String help() {
        System.out.println("CommonAction.help - Not implemented");
        return Constants.SUCCESS_OUTCOME;
    }

    public String validate() {
        System.out.println("CommonAction.validate - Not implemented");
        return Constants.SUCCESS_OUTCOME;
    }

    public String popUpList() {
        String outcome = Constants.FAILURE_OUTCOME;
        ResourceBundle applicationBundle = null;
        Locale locale = null;

        if (null != this.getHttpRequest().getAttribute("popupListParameterBean")) {
            PopupListParameterBean popupListParameterBean = (PopupListParameterBean)this.getHttpRequest().
                    getAttribute("popupListParameterBean");

            // Create Locale
            if (this.getNavigationBean().getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
                locale = Locale.CANADA_FRENCH;
            } else {
                locale = Locale.CANADA;
            }

            // Get resource bundles
            applicationBundle = ResourceBundle.getBundle(Constants.RESOURCES_PREFIXE + '.' +
                    Constants.APPLICATION_RESOURCES, locale);

            /**
             * Return outcome string based on ListName, ...
             * This one is for the ORGANIZATION/DEPARTMENT
             */

            if (popupListParameterBean.getListName().equalsIgnoreCase("organizationCountryList")) {
                // If this is the initial call for this popup session - show the countries
                if ((popupListParameterBean.getNextListName() == null ||
                     (popupListParameterBean.getNextListName().length() < 1)) &&
                    popupListParameterBean.getCurrentPopupRank() == 0) {

                    // Set list's popup rank
                    popupListParameterBean.setCurrentPopupRank(1);
                    popupListParameterBean.setListTitle(applicationBundle.getString("countryList"));

                    // Levels represent the number of variable pairs to be updated on the calling page
                    popupListParameterBean.setLevels(2); // 2 variable pair will be updated during this popup session
                    outcome = "showOrganizationCountryList";

                } else {
                    if (popupListParameterBean.getCurrentPopupRank() == 1) {
                        // If user selected code 1100 - Canada
                        if (popupListParameterBean.getSelectedValueCode1().equals("1100")) {
                            outcome = "showOrganizationProvinces";
                            popupListParameterBean.setNextListName("showOrganization");
                            popupListParameterBean.setListTitle(applicationBundle.getString("provinceList"));

                            // Set list's popup rank
                            popupListParameterBean.setCurrentPopupRank(2);

                            // If user selected code 1200 - US
                        } else if (popupListParameterBean.getSelectedValueCode1().equals("1200")) {
                            outcome = "showOrganizationStates";
                            popupListParameterBean.setNextListName("showOrganization");
                            popupListParameterBean.setListTitle(applicationBundle.getString("stateList"));

                            // Set list's popup rank
                            popupListParameterBean.setCurrentPopupRank(2);
                        } else {
                            outcome = "showOrganization";
                            popupListParameterBean.setNextListName("showOrganizationDepartment");
                            popupListParameterBean.setCurrentLevel(1); // First of two values to update the page with
                            popupListParameterBean.setListTitle(applicationBundle.getString(
                                    "organizationList"));

                            // Set list's popup rank
                            popupListParameterBean.setCurrentPopupRank(3);
                        }

                    } else if (popupListParameterBean.getCurrentPopupRank() > 1) {
                        outcome = popupListParameterBean.getNextListName();
                        if (outcome.equals("showOrganization")) {
                            popupListParameterBean.setNextListName("showOrganizationDepartment");
                            popupListParameterBean.setListTitle(applicationBundle.getString(
                                    "organizationList"));

                            popupListParameterBean.setCurrentLevel(1); // First of two values to update the page with
                            // Set list's popup rank
                            popupListParameterBean.setCurrentPopupRank(3);
                        } else if (outcome.equals("showOrganizationDepartment")) {
                            popupListParameterBean.setCurrentLevel(2); // Second of two values to update the page with

                            // last popup in this popup session
                            popupListParameterBean.setNextListName("");
                            popupListParameterBean.setListTitle(applicationBundle.getString("departmentList"));

                            // Set list's popup rank
                            popupListParameterBean.setCurrentPopupRank(4);
                        }
                    }
                }
            }

            /**
             * Return outcome string based on ListName, ...
             * This one is for the DISCIPLINE popup
             */

            if (popupListParameterBean.getListName().equalsIgnoreCase("disciplineList")) {
                // If this is the initial call for this popup session - show the main disciplines
                System.out.println(
                        "CommonAction.popItUp.disciplineList - PopupListParameterBean.getNextListName: " +
                        popupListParameterBean.getNextListName());
                System.out.println(
                        "CommonAction.popItUp.disciplineList - PopupListParameterBean.getCurrentLevel: " +
                        popupListParameterBean.getCurrentLevel());
                if ((popupListParameterBean.getNextListName() == null ||
                     (popupListParameterBean.getNextListName().length() < 1)) &&
                    popupListParameterBean.getCurrentLevel() == 0) {

                    // Set list's popup rank
                    popupListParameterBean.setCurrentPopupRank(1);
                    popupListParameterBean.setListTitle(applicationBundle.getString("mainDiscList"));
                    System.out.println("CommonAction.popItUp.disciplineList - inside Current level = 1");
                    System.out.println("CommonAction.popItUp - PopupListParameterBean.getListTitle: " +
                                       popupListParameterBean.getListTitle());

                    // Levels represent the number of variable pairs to be updated on the calling page
                    popupListParameterBean.setNextListName("disciplineList");

                    outcome = "showDisciplineList";

                } else {
                    if (popupListParameterBean.getCurrentPopupRank() == 1) {
                        // we're coming from the main discipline page
                        // Set list's popup rank
                        popupListParameterBean.setCurrentPopupRank(2);
                        popupListParameterBean.setCurrentLevel(1); // 2 variable pair will be updated during this popup session
                        popupListParameterBean.setListTitle(applicationBundle.getString("detailDiscList"));
                        popupListParameterBean.setNextListName(null);
                        System.out.println("CommonAction.popItUp.disciplineList - inside Current level = 2");

                        outcome = "showDisciplineList";

                    }
                }

            }

            /**
             * Return outcome string based on ListName, ...
             * This one is for the COUNTRY list
             */
            if (popupListParameterBean.getListName().equalsIgnoreCase("countrylist")) {
                outcome = "showCountryList";
                popupListParameterBean.setListTitle(applicationBundle.getString("countryList"));
            }

            /**
             * Return outcome string based on ListName, ...
             * This one is for the PROVINCE list
             */
            if (popupListParameterBean.getListName().equalsIgnoreCase("provincelist")) {
                outcome = "showOrganizationProvinces";
                popupListParameterBean.setCurrentLevel(1); // one pair of value to update the page with
                popupListParameterBean.setListTitle(applicationBundle.getString("provinceList"));
            }

            /**
             * Return outcome string based on ListName, ...
             * This one is for the POSITION list
             */
            if (popupListParameterBean.getListName().equalsIgnoreCase("positionlist")) {
                outcome = "showPositionList";
                popupListParameterBean.setListTitle(applicationBundle.getString("positionList"));
            }

            /**
             * Return outcome string based on ListName, ...
             * This one is for the Area Of Research list
             */
            if (popupListParameterBean.getListName().equalsIgnoreCase("areaOfResearchList")) {
                outcome = "showAreaOfResearchList";
                popupListParameterBean.setListTitle(applicationBundle.getString("areaOfResearchList"));
            }

            /**
             * Return outcome string based on ListName, ...
             * This one is for the Geographic Region list
             */
            if (popupListParameterBean.getListName().equalsIgnoreCase("geographicRegionList")) {
                outcome = "showGeographicRegionList";
                popupListParameterBean.setListTitle(applicationBundle.getString("geographicRegionList"));
            }

            /**
             * Return outcome string based on ListName, ...
             * This one is for the Province/state list
             */
            if (popupListParameterBean.getListName().equalsIgnoreCase("provinceStateList")) {
                outcome = "showprovinceStateList";
                popupListParameterBean.setListTitle(applicationBundle.getString("provinceStateList"));
            }

            /**
             * Return outcome string based on ListName, ...
             * This one is for the Funding Org list
             */
            if (popupListParameterBean.getListName().equalsIgnoreCase("fundingorglist")) {
                outcome = "showFundingOrgList";
                popupListParameterBean.setListTitle(applicationBundle.getString("fundingorglist"));
            }

            /**
             * Return outcome string based on ListName, ...
             * This one is for the COMMITTEE list
             */
            if (popupListParameterBean.getListName().equalsIgnoreCase("committeelist")) {
                outcome = "showCommitteeList";
                popupListParameterBean.setListTitle(applicationBundle.getString("committeeList"));
            }

            /**
             * Return outcome string based on ListName, ...
             * This one is for the Activity Type list
             */
            if (popupListParameterBean.getListName().equalsIgnoreCase("activityTypeList")) {
                outcome = "showActivityTypeList";
                popupListParameterBean.setListTitle(applicationBundle.getString("activityTypeList"));
            }
        }

        return outcome;
    }

    public String delete() {

        return null;
    }

    public String getAttachmentName() {
        // Returns an href value for an OutputLink tag
        String attachmentName = null;
        WebSubSystemCache webSubSystemCache = null;

        // Get attachment name from systemCache
        /*try {
            JCS systemCacheCacheManager = JCS.getInstance("systemCache");
            webSubSystemCache = (WebSubSystemCache) systemCacheCacheManager.get("WebSubSystemCache");
                 } catch (Exception ex) {
            ex.printStackTrace();
                 }*/
        try {
            CacheService systemCacheCacheManager = CacheService.getInstance("systemCache");
            webSubSystemCache = (WebSubSystemCache) systemCacheCacheManager.get("WebSubSystemCache");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        if (webSubSystemCache != null) {
            attachmentName = webSubSystemCache.getAttachmentName(this.getNavigationBean().getRequestedSubsystemId());
        }

        // Remove all "_" from the name (legacy system naming convention)
        attachmentName = StringUtils.replace(attachmentName, "_", "").toLowerCase();

        return attachmentName;
    }

    /**
     * Called to switch between same module's pages
     * Saves if required (and retrieve) and if not it calls
     * Retrieve() on the module's bean(s).
     *
     * @return String
     */
    public String showPage() {
        Integer subSystemId;
        String moduleName;
        BeanBase beanBaseContainer = null;

        // Save, if required
        if (this.getNavigationBean().getFormModified().compareToIgnoreCase("Y") == 0) {

            // Call save method
            if (!this.save().equalsIgnoreCase(Constants.SUCCESS_OUTCOME)) {
                // Save unsuccessful
                // Add error message and return to calling page OR forward to error page?
                return Constants.UPDATE_ERROR_OUTCOME;
            }
        } else {
            // Get module's beans and call Retrieve method on each of them

            // Get targeted (current) subsystem & module name
            subSystemId = this.getNavigationBean().getCurrentSubsystemId();
            moduleName = this.getNavigationBean().getCurrentModuleName();

            // Get bean classes to be processed
            ArrayList moduleBeanClassList = CommonService.getModuleBeanClass(subSystemId, moduleName);

            // Get HttpServletRequest
            HttpServletRequest request = (HttpServletRequest)this.getExternalContext().
                                         getRequest();

            // Lookup module's beans in HttpServletRequest and if found call it's Retrieve method
            try {
                // Get a session
                Session session = HibernateUtil.getSession();
                HibernateUtil.beginTransaction();

                for (int i = 0; i < moduleBeanClassList.size(); i++) {
                    // look for bean of each class type in request scope
                    String beanClassName = ((hibernate.WebModuleBeanClass) moduleBeanClassList.get(i)).
                                           getBeanClassNickName();

                    // Get class name out of the fully qualified class name
                    if (beanClassName != null) {
                        beanBaseContainer = (BeanBase) request.getAttribute(beanClassName);

                        // Call this object's retrieve method
                        if (beanBaseContainer != null) {
                            beanBaseContainer.retrieve(session);
                        }
                    }
                }

            } catch (Exception ex) {
                HibernateUtil.closeSession();
                ex.printStackTrace();
            } finally {
                // Close the Hibernate connection
                try {
                    HibernateUtil.commitTransaction();
                    HibernateUtil.closeSession();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

        }

        // A null will return to the calling page
        return null;
    }
}
