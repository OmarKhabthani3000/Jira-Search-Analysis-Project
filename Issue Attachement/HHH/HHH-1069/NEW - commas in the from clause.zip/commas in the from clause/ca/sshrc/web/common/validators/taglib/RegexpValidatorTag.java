package ca.sshrc.web.common.validators.taglib;

//import org.jia.util.Util;
import ca.sshrc.web.common.validators.RegularExpressionValidator;
import javax.faces.application.Application;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.webapp.ValidatorTag;
import javax.servlet.jsp.JspException;

public class RegexpValidatorTag extends ValidatorTag {
    private String expression;
    private String errorMessage;
    public RegexpValidatorTag() {
        super();
        setValidatorId(
                RegularExpressionValidator.
                VALIDATOR_ID);
    }

    protected Validator createValidator() throws JspException {
        RegularExpressionValidator validator =
                (RegularExpressionValidator)
                super.createValidator();
        FacesContext context = FacesContext.getCurrentInstance();
        Application app = context.getApplication();
        if (expression != null) {
//            if (Util.isBindingExpression(expression)) {
            if ((expression.indexOf("#{") > 0) && (expression.indexOf("}")) > 0) {
                validator.setExpression(
                        (String) app.createValueBinding(
                                expression).getValue(context));
            } else {
                validator.setExpression(expression);
            }
        }
        if (errorMessage != null) {
            if ((expression.indexOf("#{") > 0) && (expression.indexOf("}")) > 0) {
//            if (Util.isBindingExpression(errorMessage)) {
                validator.setErrorMessage(
                        (String) app.createValueBinding(
                                errorMessage).getValue(context));
            } else {
                validator.setErrorMessage(errorMessage);
            }
        }
        return validator;
    }

    public void release() {
        super.release();
        expression = null;
        errorMessage = null;
    }

// Properties
    public String getExpression() {
        return expression;
    }

    public void setExpression(String expression) {
        this.expression = expression;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
