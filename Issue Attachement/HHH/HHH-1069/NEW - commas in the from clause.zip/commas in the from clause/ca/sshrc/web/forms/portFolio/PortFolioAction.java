/*
 * PortFolioAction.java
 *
 * Generated on Fri Aug 08 13:07:42 EDT 2003
 *
 */

package ca.sshrc.web.forms.portFolio;

import java.util.*;

import javax.faces.context.*;
import javax.faces.model.*;
import javax.servlet.http.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.util.*;
import ca.sshrc.web.logon.*;
import ca.sshrc.web.lookupCache.*;
import org.apache.log4j.*;
import ca.sshrc.web.common.services.baseObject.BeanBase;
import hibernate.WebModuleBeanClass;
import hibernate.WebModuleBeanClassPK;

public class PortFolioAction {
    private ListDataModel listDataModel = null;
    private HttpSession httpSession;
    private Logger logger = Logger.getLogger(PortFolioAction.class.getName());
    private HttpServletRequest httpRequest;

    public PortFolioAction() {
        // Get http Session & Request objects
        httpRequest = (HttpServletRequest) FacesContext.
                      getCurrentInstance().
                      getExternalContext().getRequest();
        httpSession = ((HttpServletRequest) httpRequest).getSession(false);

    }


    public List getPortFolioList() {

        try {
            LogonBean logonBean = (LogonBean) httpSession.getAttribute(
                    "logonBean");
            if (logonBean == null) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.error("PortFolioAction - logonBean isn't there.");
                }
                return null;
            }

            NavigationBean navigationBean = (NavigationBean) httpSession.getAttribute(
                    "navigationBean");
            if (navigationBean == null) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.error("PortFolioAction.getPortFolioList - navigationBean isn't there.");
                }
                return null;
            }

            logger.info("PortFolioAction - navigationBean currentSub value: " +
                        navigationBean.getCurrentSubsystemId());
            logger.info("PortFolioAction - navigationBean currentMod value: " +
                        navigationBean.getCurrentModuleId());
            logger.info("PortFolioAction - navigationBean reqSub value: " +
                        navigationBean.getRequestedSubsystemId());
            logger.info("PortFolioAction - navigationBean reqmod value: " +
                        navigationBean.getRequestedModuleId());
            /** Patch: When user goes back to the portfolio using a browser back button and also refreshing the page,
             * the top toolbar get populated with the values from the previous page. Reset the tool list.
             *
             */

            PortFolioService portFolioService = new PortFolioService();
            return portFolioService.getPortFolioList(logonBean.getWeb_id(),
                    navigationBean.getCurrentSubsystemId());

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public List getPortFolioCVList() {
        try {
            LogonBean logonBean = (LogonBean) httpSession.getAttribute(
                    "logonBean");
            if (logonBean == null) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.error("PortFolioAction - logonBean isn't there.");
                }
                return null;
            }
            ;

            NavigationBean navigationBean = (NavigationBean) httpSession.getAttribute(
                    "navigationBean");
            if (navigationBean == null) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.error("PortFolioAction.getPortFolioList - navigationBean isn't there.");
                }
                return null;
            }

            PortFolioService portFolioService = new PortFolioService();
            return portFolioService.getPortFolioCVList(logonBean, navigationBean.getCurrentSubsystemId());

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public String showForm() {
        String navigationString = null;
        logger.info("PortFolioAction.showForm - starts");

        try {
            ExternalContext context = FacesContext.getCurrentInstance().
                                      getExternalContext();
            HttpServletRequest request = (HttpServletRequest) context.
                                         getRequest();
            HttpSession session = ((HttpServletRequest) request).getSession(false);

            LogonBean logonBean = (LogonBean) session.getAttribute("logonBean");
            if (logonBean == null) {
                if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                    logger.error("PortFolioAction.showForm - logonBean isn't there.");
                }
                return "Invalid_session";
            } else {

                // Get next page... This step will figure out the next page
                // based on the properties of NavigationBean (requestedSubsystemId & requestedModuleId)
                NavigationBean navigationBean = (NavigationBean) session.getAttribute("navigationBean");
                if (navigationBean == null) {
                    if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                        logger.error("PortFolioAction.showForm - navigationBean isn't there.");
                        return "Invalid_session";
                    }
                } else {
                    if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                        logger.info("PortFolioAction.showForm - navigationBean form id value: " +
                                    navigationBean.getForm_id());
                    }
                }

                // Following line commented out because, this method should always look for the module name in the first array position (0).
                // the requested module id is not relevant and should always be 1 (array pos. 0) on the portfolio page.
                // navigationString = ((NavigationBarBean)((ArrayList)navigationBean.getModuleList()).get(navigationBean.getRequestedModuleId().intValue()-1)).getModuleName();


                // Now set Current/Requested navigation properties
                navigationBean.setCurrentSubsystemId(navigationBean.getRequestedSubsystemId());
                navigationBean.setCurrentModuleId(new Integer(1)); // reset module id to 1

                navigationString = ((NavigationBarBean) ((ArrayList) navigationBean.getModuleList(false)).get(
                        0)).getModuleName();
                logger.info("PortFolioAction.showForm - Next page name: " + navigationString.toLowerCase());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        // Always return lower case values for navigation (est. standard)
        return navigationString.toLowerCase();
    }

    /**
     * Called from the portfolio page to switch between standard & final research report form list.
     * The calling page changes the navigationBean.requestedModuleId property.
     *
     * @return String
     */
    public String switchPortFolio() {
        String navigationString = null;

        logger.info("PortFolioAction.switchPortFolio");

        // Get NavigationBean from http session
        NavigationBean navigationBean = (NavigationBean) httpSession.getAttribute(
                "navigationBean");
        if (navigationBean != null) {
            /* Reset navigationBean current and requested subsystem id */
            navigationBean.setCurrentModuleId(new Integer(1));
            navigationBean.setCurrentSubsystemId(navigationBean.getRequestedSubsystemId());

            /**
             * Update the navigationBean.portFolioSubsystemId prior to executing the showPortFolio method.
             */
            navigationBean.setPortFolioSubsystemId(navigationBean.getRequestedSubsystemId());

            navigationBean.setRequestedModuleId(new Integer(1));
            navigationString = Constants.SUCCESS_OUTCOME;
        } else {
            navigationString = Constants.FAILURE_OUTCOME;
        }

        return navigationString;
    }

    /** Use web_subsystem_crossref table to figure out which portfolio to display.
     *
     * If the RequestedSubsystemId is a portfolio, the method will return the same subsystem id
     * If the RequestedSubsystemId is NOT a portfolio subsystem id but a program or CV, the method
     * will return a portfolio subsystem id
     *
     * ALSO, this method uses NavigationBean.getRequestedSubsystemId, because this method's call directly
     * from the JSP page and there's no intermediary process that resets the current subsystem id with the
     * requested subsystem id.
     *
     */
    public String showPortFolio() {
        Integer portfolioSubsystemId = null;
        String navigationString = null;

        logger.info("PortFolioAction.showPortFolio");

        // Get NavigationBean from http session
        NavigationBean navigationBean = (NavigationBean) httpSession.getAttribute(
                "navigationBean");

        if (navigationBean != null) {
            /**
             * Kept this code snippet when we changed the way we handle the portfolio subsystem id.
             * We use to figure out the portfolio subsystem id by looking up in the web_subsytem_crossref table.
             *
             * Now we get it from the logon JSP page and store it in the navigationBean.portFolioSubsystemId
             * (see object's constructor).
             *
             * The portFolioAction.switchPortFolio method updates the navigationBean.portFolioSubsystemId.
             *
             *
             *
             * PortFolioService portFolioService = new PortFolioService();
             * portfolioSubsystemId = portFolioService.getPortFolioSubSystemId(navigationBean.getCurrentSubsystemId());*/

            portfolioSubsystemId = navigationBean.getPortFolioSubsystemId();

            /** Reset navigationBean current and requested subsystem id
             * P.S.: Current module id must be set prior to the current sub sys id. or else,
             * the call to setCurrentSubsystemId will return an array out of bound exception
             * (if the current module is set to a larger number then 1).
             */

            navigationBean.setCurrentModuleId(new Integer(1));
            navigationBean.setCurrentSubsystemId(portfolioSubsystemId);
            navigationBean.setRequestedSubsystemId(portfolioSubsystemId);
            navigationBean.setRequestedModuleId(new Integer(1));

            // Used by multipage module ie: Participant.
            navigationBean.setCurrentPageNumber(1);
            navigationBean.setRequestedPageNumber(1);
            navigationString = Constants.SUCCESS_OUTCOME;
        } else {
            navigationString = Constants.FAILURE_OUTCOME;
        }

        return navigationString;
    }

    public String validateForm() {
        String navigationString = Constants.SUCCESS_OUTCOME;
        Integer subSystemId;
        Class classContainer;
        BeanBase beanBaseContainer = null;
        // Should this object load the bundle names required for all modules?
        // "                     " the list of module names?
        ValidationMessage validationMessage = new ValidationMessage();

        logger.info("PortFolioAction.validateForm - starts");

        try {
            ExternalContext context = FacesContext.getCurrentInstance().
                                      getExternalContext();
            HttpServletRequest request = (HttpServletRequest) context.
                                         getRequest();
            HttpSession session = ((HttpServletRequest) request).getSession(false);

            LogonBean logonBean = (LogonBean) session.getAttribute("logonBean");
            if (logonBean == null) {
                if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                    logger.error("PortFolioAction.validateForm - logonBean isn't there.");
                }
                return "Invalid_session";
            } else {

                // Get NavigationBean
                NavigationBean navigationBean = (NavigationBean) session.getAttribute("navigationBean");
                if (navigationBean == null) {
                    if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                        logger.error("PortFolioAction.validateForm - navigationBean isn't there.");
                        return "Invalid_session";
                    }
                } else {
                    if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                        logger.info("PortFolioAction.validateForm - navigationBean form id value: " +
                                    navigationBean.getForm_id());
                    }
                }

                // Get targeted (current) subsystem & module name
                subSystemId = navigationBean.getRequestedSubsystemId();

                // Get bean classes to be processed (bean classes per module)
                CommonService commonService = new CommonService();
                ArrayList moduleBeanClassList = commonService.getModuleBeanClass(subSystemId);

                // Now set Current/Requested navigation properties - This will trigger the navigationBean.loadModuleList.
                navigationBean.setCurrentSubsystemId(navigationBean.getRequestedSubsystemId());

                // Loop thru module_beanClass for this subsystem and call validate() on each module's bean
                for (int i = 0; i < moduleBeanClassList.size(); i++) {
                    try {
                        // Get module class name
                        String className = ((WebModuleBeanClassPK) ((WebModuleBeanClass) moduleBeanClassList.
                                get(i)).getComp_id()).getBeanClassName();

                        if (null != className && className.trim() != "") {
                            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                                logger.info("PortFolioAction.validateForm - " + className);
                            }

                            // Instantiate module class
                            classContainer = Class.forName(className);

                            // Create module class base bean
                            beanBaseContainer = (BeanBase) classContainer.newInstance();

                            // Now set Current/Requested navigation properties
                            navigationBean.setCurrentModuleId(new Integer(1)); // reset module id to 1

                            // Set validation object module resource bundle name about to be validated (e.g.: ressources.CVFundedResearchResources)
                            validationMessage.setResourceBundleName(Constants.RESOURCES_PREFIXE + '.' +
                                    ((WebModuleBeanClass) moduleBeanClassList.get(i)).
                                    getMessageResourceName());

                            // Set validation object module with NavigationBarBean object of the module about to be validated (required to get module display name in French or English)
                            validationMessage.setModuleNavigationBarBean(navigationBean.
                                    getModuleNavigationBarBean(subSystemId,
                                    ((WebModuleBeanClass) moduleBeanClassList.
                                     get(i)).getComp_id().getModuleName()));

                            beanBaseContainer.validate(validationMessage);
                        } else {
                            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                                logger.info(
                                        "PortFolioAction.validateForm - no class name found in web_module_beanClass table for sub: " +
                                        subSystemId + "module: " + (i + 1));
                            }
                        }
                    } catch (ClassNotFoundException ex) {
                        // This should not happen.
                        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                            logger.error(
                                    "PortFolioAction.validateForm - Invalid class name in Web_Module_BeanClass table: " +
                                    moduleBeanClassList.get(i));
                        }
                    } catch (Exception ex) {
                        // This should not happen.
                        ex.printStackTrace();
                    }
                }

                if (validationMessage.getMessagesCount() > 0) {
                    navigationString = Constants.VALIDATION_ERROR_OUTCOME;
                    // Put validationMessage object in the Request object
                    // Attribute name "validationMessage".
                    // That's where the ValidationLayout will be looking.
                    session.setAttribute("validationMessage", validationMessage);
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        // Always return lower case values for navigation (est. standard)
        /*        if (navigationString != null) {
                    return navigationString.toLowerCase();
                }*/
        return navigationString;
    }

    public DataModel getModel(ArrayList list) {
        if (listDataModel == null) {
            listDataModel = new ListDataModel(list);
        }
        return (DataModel) listDataModel;
    }
}
