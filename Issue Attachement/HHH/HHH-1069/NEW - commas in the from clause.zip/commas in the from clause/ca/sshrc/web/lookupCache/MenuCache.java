package ca.sshrc.web.lookupCache;

import java.io.*;
import java.util.*;

import org.hibernate.*;
import org.apache.log4j.*;
import ca.sshrc.web.common.services.*;

public class MenuCache implements Serializable {
    private static Logger logger = Logger.getLogger(MenuCache.class.getName());
    private static List queryList;

    public MenuCache() {
        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In MenuCache");

            queryList = session.createQuery(
                    "select new ca.sshrc.web.lookupCache.NavigationBarBean( WebModul.comp_id.webSubsystem.subsystemId, " +
                    "WebModul.comp_id.sequenceNumber, " +
                    "WebModul.moduleName, " +
                    "WebModul.nameEnglish, " +
                    "WebModul.nameFrench, " +
                    "WebModul.shortNameEnglish, " +
                    "WebModul.shortNameFrench, " +
                    "WebSubsystem.nameEnglish, " +
                    "WebSubsystem.nameFrench, " +
                    "WebModul.toolBar) " +
                    "from WebModul WebModul, " +
                    "WebSubsystem WebSubsystem " +
                    "where WebModul.comp_id.webSubsystem.subsystemId = WebSubsystem.subsystemId " +
                    "order by 1 desc,2").list();

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Loaded WebModul : " + queryList.size());
            }
        } catch (Exception e) {
            HibernateUtil.rollbackTransaction();
            HibernateUtil.closeSession();
            e.printStackTrace();
        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

    }

    /**
     * getModuleList
     * This will return to the calling object the list of modules for a given subsystem ID
     *
     * @param asubsystem int
     */
    public ArrayList getModuleList(Integer asubsystem) {
        NavigationBarBean myNavBean = null;
        ArrayList tempList = new ArrayList();

        for (Iterator it = queryList.iterator(); it.hasNext(); ) {
            myNavBean = (NavigationBarBean) it.next();
            // Exit loop if done querying requested subsystemid
            if (tempList.size() > 0 && !myNavBean.getWebSubsystem().equals(asubsystem)) {
                break;
            }
            // Add found web module
            if (myNavBean.getWebSubsystem().equals(asubsystem)) {
                tempList.add(myNavBean);
            }
        }
        return tempList;
    }

    /**
     * getModuleList
     */
    public List getModuleList() {
        return this.queryList;
    }

}
