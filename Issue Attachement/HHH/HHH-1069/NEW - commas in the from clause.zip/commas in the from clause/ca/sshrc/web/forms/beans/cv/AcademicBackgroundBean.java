package ca.sshrc.web.forms.beans.cv;

import java.lang.reflect.*;
import java.util.*;

import javax.faces.component.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.services.baseObject.*;
import hibernate.*;
import org.apache.commons.beanutils.*;
import org.apache.log4j.*;
import org.hibernate.*;


public class AcademicBackgroundBean extends BeanBase {
    public AcademicBackgroundBean() {
        logger.info("AcademicBackgroundBean - minimal constructor");

        try {
            // Get a session
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            // Call this object's retrieve method
            this.retrieve(new Integer(0), session);

        } catch (Exception ex) {
            HibernateUtil.closeSession();
            ex.printStackTrace();
        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private Logger logger = Logger.getLogger(AcademicBackgroundBean.class.getName());
    private ArrayList degreeList = null;
    private UIData degreeTable;


    // Overwrite ancestor method
    public void retrieve(Session session) {
        retrieve(new Integer(0), session);
    }

    /**
     * retrieve
     *
     * @param id Integer
     */
    public void retrieve(Integer id, Session session) {
        List queryList;
        logger.info("AcademicBackgroundBean.retrieve passed parameter is cid : " + id);

        if (null == session) {
            if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                logger.error("Cannot load AcademicBackgroundBean - Session is null");
                return;
            }
        }

        // If the passed form_id is 0, get the form_id from the NavigationBean
        if (id.intValue() == 0) {
            id = this.getLogonBean().getWeb_id();
            if (id.intValue() == 0) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.error("Cannot load AcademicBackgroundBean - no FormId : " + id);
                    return;
                }
            } else {
                logger.info("AcademicBackgroundBean.retrieve using logonBean webId : " + id);
            }

        } else {
            logger.info("AcademicBackgroundBean.retrieve using passed parm webId : " + id);
        }
        //Let's retrieve the data from the DB
        try {
            logger.info("In AcademicBackgroundBean.retrieve()");

/*            queryList = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.cv.AcademicDataBean( " +
                    "acad.degreeId, " +
                    "acad.cid, " +
                    "acad.degreeType, " +
                    "acad.degreeName, " +
                    "acad.startDate, " +
                    "acad.completedDate, " +
                    "acad.expectedDate, " +
                    "acad.disciplineCode, " +
                    "acad.otherDisciplineName, " +
                    "acad.orgId, " +
                    "acad.otherOrgName, " +
                    "acad.otherCountryCode, " +
                    "acad.resultOfSshrcInd, " +
                    "acad.highestDegreeInd, " +
                    "acad.changeDate, " +
                    "acad.startYear, " +
                    "acad.startMonth, " +
                    "acad.completedYear, " +
                    "acad.completedMonth, " +
                    "acad.expectedYear, " +
                    "acad.expectedMonth, " +
                    "cod.shortNameEnglish, " +
                    "cod.shortNameEnglish, " +
                    "disc.nameEnglish, " +
                    "disc.nameFrench, " +
                    "org.nameEnglish, " +
                    "org.nameFrench, " +
                    "country.nameEnglish, country.nameFrench )" +
                    "from PersonAcademicBackground acad, " +
                    "Cod cod, " +
                    "Discipline disc, " +
                    "Organization org, " +
                    "Country country " +
                    "where (acad.degreeType *= cod.code) and " +
                    "(acad.disciplineCode *= disc.disciplineCode) and " +
                    "(acad.orgId *= org.orgId) and  " +
                    "(acad.otherCountryCode *= country.countryCode) and " +
                    "(acad.cid = :aCid) " +
                    "order by acad.highestDegreeInd DESC, " +
                    "acad.startDate DESC, " +
                    "acad.completedDate DESC, " +
                    "acad.expectedDate DESC, " +
                    "acad.disciplineCode ASC")
                        .setParameter("aCid", id)
                        .list();*/


            queryList = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.cv.AcademicDataBean(" +
                    "acad.degreeId, " +
                    "acad.cid, " +
                    "acad.degreeType, " +
                    "acad.degreeName, " +
                    "acad.startDate, " +
                    "acad.completedDate, " +
                    "acad.expectedDate, " +
                    "acad.discipline, " +
                    "acad.otherDisciplineName, " +
                    "acad.organization, " +
                    "acad.otherOrgName, " +
                    "acad.otherCountry, " +
                    "acad.resultOfSshrcInd, " +
                    "acad.highestDegreeInd, " +
                    "acad.changeDate, " +
                    "acad.startYear, " +
                    "acad.startMonth, " +
                    "acad.completedYear, " +
                    "acad.completedMonth, " +
                    "acad.expectedYear, " +
                    "acad.expectedMonth, " +
                    "degreeType.shortNameEnglish, " +
                    "degreeType.shortNameEnglish, " +
                    "discipline.nameEnglish, " +
                    "discipline.nameFrench, " +
                    "organization.nameEnglish, " +
                    "organization.nameFrench, " +
                    "country.nameEnglish, " +
                    "country.nameFrench) " +
                    "FROM PersonAcademicBackground as acad join fetch acad.degreeType as degreeType " +
                    "join fetch acad.discipline as discipline " +
                    "join fetch acad.organization as organization " +
                    "join fetch acad.otherCountry as country " +
                    "where (acad.cid = :aCid) " +
                    "order by acad.highestDegreeInd desc, " +
                    "acad.startDate desc, " +
                    "acad.completedDate desc, " +
                    "acad.expectedDate desc, " +
                    "acad.discipline.disciplineCode asc")
                        .setParameter("aCid", id)
                        .list();
/*
                        from FORMS form0_ inner join PERSON person1_ on form0_.CID=person1_.CID left outer join PERSON_POSITION personposi2_ on person1_.CID=personposi2_.CID left outer join ORGANIZATION organizati5_ on personposi2_.Org_ID=organizati5_.Org_ID left outer join CODES cod3_ on personposi2_.Position_Number=cod3_.Code left outer join ORG_DEPT_LOCATION orgdeptloc4_ on personposi2_.Org_Dept_Loc_ID=orgdeptloc4_.Org_Dept_Loc_ID where form0_.Form_ID=? and personposi2_.Primary_Org_Ind='Y'

                                "cod.shortNameFrench) " +
                                "from Form form join fetch form.person as person " +
                                "left outer join fetch person.personPosition as position " +
                                "left outer join fetch position.positionNumber as cod " +
                                "left outer join fetch position.orgDeptLocation as department " +
                                "left outer join fetch position.organization as organization " +
                                "where (form.formId = :formID) and  " +
                                "(position.primaryOrgInd = 'Y')")
                                    .setParameter("formID", new Long(formId))
                                    .list();
             */

            logger.info("AcademicBackgroundBean.retrieve - just after the SQL statement");
            logger.info("AcademicBackgroundBean.retrieve - number of rows retrieved = " + queryList.size());
            if (queryList.size() > 0) {
                this.degreeList = new ArrayList(queryList);
                logger.info("AcademicBackgroundBean.retrieve - number of rows in degreeList = " +
                            this.degreeList.size());
            } else {
                this.degreeList = new ArrayList();
                logger.info("AcademicBackgroundBean.retrieve - number of rows in degreeList = " +
                            this.degreeList.size());
            }

            // Let's make sure that we always have 5 rows to display
            while (this.degreeList.size() < 5) {
                this.degreeList.add(new AcademicDataBean(this.getLogonBean().getWeb_id()));
            }
            logger.info("AcademicBackgroundBean.retrieve - number of rows in degreeList = " +
                        this.degreeList.size());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * setDegreeList
     *
     * @param aList ArrayList
     */
    public void setDegreeList(ArrayList aList) {
        this.degreeList = aList;
    }

    public void setDegreeTable(UIData degreeTable) {
        logger.info("AcademicBackgroundBean.getDegreeList");

        this.degreeTable = degreeTable;
    }

    /**
     * getDegreeList
     *
     * @return ArrayList
     */
    public ArrayList getDegreeList() {
        return this.degreeList;
    }

    public UIData getDegreeTable() {
        return degreeTable;
    }

    /**
     * save
     *
     * @param session Session
     * @return String
     */
    public String save(Session session) throws HibernateException, InvocationTargetException,
            IllegalAccessException, NoSuchMethodException {
        List queryList;
        PersonAcademicBackground myDegree = null;
        boolean boBeanHasData;
        String saveOutcome = "failure"; // Defaults to failure

        logger.info("In AcademicBackgroundBean.save()");
        logger.info("We have " + this.degreeList.size() + " beans in degreeList");
        if (this.degreeList.size() > 0) {

            logger.info("the cid = " + (AcademicDataBean)this.degreeList.get(0));
        }

        HibernateUtil.beginTransaction();

        queryList = session.createQuery("from PersonAcademicBackground " +
                                        "where cid = :cid")
                    .setParameter("cid", this.getLogonBean().getWeb_id())
                    .list();

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Loaded hibernate.PersonAcademicBackground objects : " + queryList.size());
        }

        if (this.degreeList.size() > 0) {
            // Set values
            for (int i = 0; i < this.degreeList.size(); i++) {
                boBeanHasData = ((AcademicDataBean)this.degreeList.get(i)).hasData();

                // Check that this is an existing record
                if (((AcademicDataBean)this.degreeList.get(0)).getDegreeId() == null) {
                    logger.info("Bean " + (i + 1) + " is a new record");
                    // there is no record, copy the bean and save
                    if (boBeanHasData) {
                        logger.info("Bean " + (i + 1) + " has data to save");
                        myDegree = new PersonAcademicBackground();
                        PropertyUtils.copyProperties(myDegree, ((AcademicDataBean)this.degreeList.get(0)));
                        session.saveOrUpdate(myDegree);
                        session.flush();
                        session.refresh(myDegree);
                    }
                    saveOutcome = "success";

                } else {

                    // this is an existing record. Locate the matching one in the database
                    logger.info("Bean " + (i + 1) + " is an existing record");
                        for (int j=0;j<queryList.size();j++) {
                        if (((PersonAcademicBackground)queryList.get(j)).getDegreeId().equals(((AcademicDataBean)this.degreeList.get(i)).getDegreeId())) {
                            // this is the correct record, update and save
                            if (boBeanHasData) {
                                PropertyUtils.copyProperties((PersonAcademicBackground)queryList.get(j), ((AcademicDataBean)this.degreeList.get(i)));
                                session.saveOrUpdate((PersonAcademicBackground)queryList.get(j));
                                session.flush();
                            } else {
                                session.delete((PersonAcademicBackground)queryList.get(j));
                                session.flush();
                                degreeList.remove(i);
                            }
                            saveOutcome = "success";
                            break;
                        }
                    }
                }
            }
        }
        return saveOutcome;
    }
}
