package ca.sshrc.web.common.services;

/**
 * <p>Title: NavigationBean</p>
 *
 * <p>Description: Contains navigation properties and methods. </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Social Sciences and Humanities Research Council of Canada</p>
 *
 * @author Pierre Masse
 * @version 1.0
 */

import java.io.*;
import java.util.*;

import javax.faces.context.*;
import javax.servlet.http.*;

import ca.sshrc.web.common.util.*;
import ca.sshrc.web.logon.*;
import ca.sshrc.web.lookupCache.*;
import hibernate.*;

public class NavigationBean implements Serializable {
    private long form_id;
    private String languageSite;
    private String formLanguage;
    private Integer currentSubsystemId;
    private Integer currentModuleId = new Integer(1);
    private Integer requestedSubsystemId;
    private Integer requestedModuleId = new Integer(1);
    private Integer portFolioSubsystemId;
    private String formModified = "N";
    private ArrayList moduleList;
    private String toolListStr;
    private MenuCache menuCache = null;

    /**
     * Variables for multipage module.
     */
    private int currentPageNumber = 1; //
    private int requestedPageNumber = 1; // Page requested by user
    private int numberOfPages = 0; // Total number of page to display all rows

    public NavigationBean() {
        System.out.println("In NavigationBean.constructor");
        // Get and remove parameters from session bean
        ExternalContext context = FacesContext.getCurrentInstance().
                                  getExternalContext();
        HttpServletRequest request = (HttpServletRequest) context.
                                     getRequest();

        HttpSession session = ((HttpServletRequest) request).getSession(false);

        // Get site language from logonbean and set this object's language site attribute with it
        LogonBean logonBean = (LogonBean)session.getAttribute("logonBean");
        if (logonBean == null) {
            // Get languageSite from request parm
            languageSite = new String((java.lang.String) (request.getParameter("mainForm:languageSite"))).trim();
        } else {
            languageSite = logonBean.getSiteLanguageAtLogon();
        }

        // If for some reason the site language isn't there, default to en_CA
        if (languageSite == null || languageSite.equalsIgnoreCase("")) {
            languageSite = Constants.ENGLISH_CANADIAN_LOCALE;
        }

        // Default form language to language
        formLanguage = languageSite;

        /**
         * Get current Subsystem Id from request parm (Passed from Logon.jsp to
         * Security_and_provacy.jsp where this bean's referenced for the first time)
         */

        currentSubsystemId = new Integer((java.lang.String) (request.getParameter("mainForm:subsystem_id")));
        System.out.println(
                "SubSystem found in request parm (mainForm:subsystem_id) : " + this.currentSubsystemId);

        // If for some reason the subsys isn't there, default to 3
        if (currentSubsystemId == null) {
            currentSubsystemId = new Integer(3);
            System.out.println(
                    "SubSystem Id missing from request parm (mainForm:subsystem_id), DEFAULTING to 3.");
        }

        portFolioSubsystemId = currentSubsystemId;

        // Default values
        this.requestedSubsystemId = this.currentSubsystemId;
        this.requestedModuleId = new Integer(1);
        this.currentModuleId = new Integer(1);

        // Get menuCache, required by method loadModuleList()
        try {
            CacheService systemCacheCacheManager = CacheService.getInstance("systemCache");
            menuCache = (MenuCache) systemCacheCacheManager.get("MenuCache");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setForm_id(long form_id) {
        this.form_id = form_id;  // Usually on the JSP page as hidden field
    }

    public long getForm_id() {
        return form_id;
    }

    public void setLanguageSite(String language) {
        this.languageSite = language;
    }

    public String getLanguageSite() {
        return this.languageSite;
    }

    public void setFormLanguage(String language) {
        this.formLanguage = language;  // Usually on the JSP page as hidden field
    }

    public String getFormLanguage() {
        return this.formLanguage;
    }

    public void setCurrentSubsystemId(Integer passedSubsystemId) {
        if (this.currentSubsystemId.equals(passedSubsystemId)) {
            if (moduleList == null || moduleList.size() == 0) {
                this.loadModuleList();
                this.loadToolList();
            }
        } else {
            // Reload the module list and tool list
            System.out.println("NavigationBean.setCurrentSubsystemId - Re-loading module list & tool list");
            this.currentSubsystemId = passedSubsystemId;  // Usually on the JSP page as hidden field
            this.loadModuleList();
            this.loadToolList();

            /** Remove validation message object from Session
             * whenever the current subsystemid changes. We don't
             * want that object to stay there for ever. It cannot
             * be put in the Request that's why we have to manually
             * remove it from the Session.
             */
            ExternalContext context = FacesContext.getCurrentInstance().
                                      getExternalContext();
            HttpServletRequest request = (HttpServletRequest) context.
                                         getRequest();

            HttpSession session = ((HttpServletRequest) request).getSession(false);
            session.removeAttribute("validationMessage");
        }
    }

    public Integer getCurrentSubsystemId() {
        return this.currentSubsystemId;
    }

    public void setCurrentModuleId(Integer currentModuleId) {
        if (this.currentModuleId.equals(currentModuleId)) {
            if (moduleList == null) {
                this.loadModuleList();
                this.loadToolList();
            }
        } else {
            // Reload the module list and tool list
            System.out.println("NavigationBean.setCurrentModuleId - Re-loading module list & tool list: " + currentModuleId);
            this.currentModuleId = currentModuleId;  // Usually on the JSP page as hidden field
            this.loadModuleList();
            this.loadToolList();
        }
    }

    public Integer getCurrentModuleId() {
        return this.currentModuleId;
    }

    public void setFormModified(String formModified) {
        System.out.println("setFormModified: " + formModified);
        this.formModified = formModified;  // Usually on the JSP page as hidden field
    }

    public String getFormModified() {
        return this.formModified;
    }

    public void setRequestedSubsystemId(Integer requestedSubsystemId) {
        this.requestedSubsystemId = requestedSubsystemId;  // Usually on the JSP page as hidden field
    }

    public Integer getRequestedSubsystemId() {
        return this.requestedSubsystemId;
    }

    public void setRequestedModuleId(Integer requestedModuleId) {
        this.requestedModuleId = requestedModuleId;  // Usually on the JSP page as hidden field
    }

    public Integer getRequestedModuleId() {
        return this.requestedModuleId;
    }

    private void setModuleList(ArrayList list) {
        this.moduleList = list;
    }

    public void setPortFolioSubsystemId(Integer portFolioSubsystemId) {
        this.portFolioSubsystemId = portFolioSubsystemId;
    }

    public void setCurrentPageNumber(int currentPageNumber) {
        this.currentPageNumber = currentPageNumber;
    }

    public void setRequestedPageNumber(int requestedPageNumber) {
        this.requestedPageNumber = requestedPageNumber;
    }

    public void setNumberOfPages(int numberOfPages) {
        this.numberOfPages = numberOfPages;
    }

    public ArrayList getModuleList() {
        return this.getModuleList(true);
    }

    public Integer getPortFolioSubsystemId() {
        return portFolioSubsystemId;
    }

    public int getCurrentPageNumber() {
        return currentPageNumber;
    }

    public int getRequestedPageNumber() {
        return requestedPageNumber;
    }

    public int getNumberOfPages() {
        return numberOfPages;
    }

    public ArrayList getModuleList(boolean isReloadRequired) {
        if (isReloadRequired) {
            this.loadModuleList();
        }
        return this.moduleList;
    }

    private void setToolList(String list) {
        this.toolListStr = list;
    }

    public String getToolList() {
        return this.getToolList(false);
    }

    public String getToolList(boolean isReloadRequired) {
        System.out.println("In Navigation.getToolList");
        if (isReloadRequired) {
            this.loadToolList();
        }

        return this.toolListStr;
    }

    public String getModuleListStyleClass() {
        String str = new String("");

        // Loop through module list and generate StyleClass list.
        // CMDL for selected module and MDL for the others
        for (int i = 0; i < this.moduleList.size(); i++) {
            if (i > 0) {
                str = str.concat(",");
            }
            if (i == (this.getCurrentModuleId().intValue() - 1)) {
                str = str.concat("CMDL");
            } else {
                str = str.concat("MDL");
            }
        }

        return str;
    }

    /**
     * Load list of module from cache object
     */
    private void loadModuleList() {
        System.out.println("In Navigation.loadModuleList");
        ArrayList moduleList = new ArrayList();

        moduleList = menuCache.getModuleList(this.getCurrentSubsystemId());
        moduleList.trimToSize();

        System.out.println("In Navigation.loadModuleList retrieved - " + moduleList.size());
        this.setModuleList(moduleList);
    }

    /**
     * Find and returns the NavigationBarBean representing the sub and module name passed
     * as parameters.
     */
    public NavigationBarBean getModuleNavigationBarBean(Integer subsystemId, String moduleName) {
        NavigationBarBean navigationBarBean= null;

        // Loop through module list to find the requested one.
        for (int i = 0; i < this.moduleList.size(); i++) {
            if (((NavigationBarBean)moduleList.get(i)).getModuleName().equalsIgnoreCase(moduleName) && ((NavigationBarBean)moduleList.get(i)).getWebSubsystem().equals(subsystemId)) {
                navigationBarBean = (NavigationBarBean)moduleList.get(i);
                break;
            }
        }

        return navigationBarBean;
    }


    /**
     * loadToolList
     *
     * Get the list of tool bar item to be displayed for the current module
     * based on the tool list (String) value of this.currentModuleId.
     *
     *
     */
    private void loadToolList() {
        System.out.println("In Navigation.loadToolList");
        String str = ((NavigationBarBean)this.getModuleList(true).get(getModuleIdArrayIndex(this.
                getCurrentModuleId()))).
                     getToolBar();
        System.out.println("In Navigation.loadToolList - " + str);
        this.setToolList(str);
    }

    /** getModuleIdArrayIndex
     * Based on this.requestedModuleId value, this method return
     * the module id index position in this.moduleList array
     *
     * @return int
     * */
    private int getModuleIdArrayIndex(Integer Moduleid) {
        int moduleArrayPosition = -1;

        // Loop through module list and find module Id
        for (int i = 0; i < this.getModuleList(false).size(); i++) {
            if (((NavigationBarBean)this.getModuleList(false).get(i)).getSequenceNumber().equals(Moduleid)) {
                moduleArrayPosition = i;
                break;
            }
        }

        return moduleArrayPosition;
    }


    /**
     * getRequestedModuleName
     *
     * Returns the module name corresponding to getRequestedModuleId module ID
     *
     * @return String
     */
    public String getRequestedModuleName() {

        return ((NavigationBarBean)this.getModuleList(false).get(getModuleIdArrayIndex(this.
                getRequestedModuleId()))).getModuleName();

    }

public String[] getRequestedModuleResourceBundle () {
    CommonService commonService = new CommonService();
    ArrayList moduleBeanClassArray = null;


    moduleBeanClassArray = commonService.getModuleBeanClass(this.getRequestedSubsystemId(), this.getCurrentModuleName());
    String[] resourceBundleName = new String[moduleBeanClassArray.size()];

    for (int i=0; i < moduleBeanClassArray.size(); i++) {
        resourceBundleName[i] = ((WebModuleBeanClass) moduleBeanClassArray.get(i)).getMessageResourceName();
    }

    return resourceBundleName;
}

    /**
     * getCurrentModuleName
     *
     * Returns the module name corresponding to getCurrentModuleId module ID
     *
     * @return String
     */
    public String getCurrentModuleName() {

        return ((NavigationBarBean)this.getModuleList(false).get(getModuleIdArrayIndex(this.
                getCurrentModuleId()))).getModuleName();

    }

    /**
     * getRequestedModuleDisplayName
     *
     * Returns the module's display name corresponding to getRequestedModuleId (in the language form)
     *
     * @return String
     */
    public String getRequestedModuleDisplayName() {
        String moduleDisplayName = null;

        if (this.getFormLanguage().compareToIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE) == 0) {
            moduleDisplayName = ((NavigationBarBean)this.getModuleList(false).get(getModuleIdArrayIndex(this.
                    getRequestedModuleId()))).getNameFrench();
        } else {
            moduleDisplayName = ((NavigationBarBean)this.getModuleList(false).get(getModuleIdArrayIndex(this.
                    getRequestedModuleId()))).getNameEnglish();
        }

        return moduleDisplayName;
    }

    /**
     * getRequestedModuleDisplayNameNoBlankSpace
     *
     * Returns the module's display name corresponding to getRequestedModuleId (in the language form)
     * Replaces all occurences of "&nbsp;" by " " (space)
     *
     * @return String
     */
    public String getRequestedModuleDisplayNameNoBlankSpace() {
        return this.getRequestedModuleDisplayName().replaceAll("&nbsp;", " ");
    }


    /**
     * getRequestedFormDisplayName
     *
     * Returns the form's display name corresponding to getRequestedModuleId (in the language form)
     * It doesn't matter which module id we look for, they will all return the same form name
     * (see MenuCache and/or NavigationBarBean class).
     *
     * @return String
     */
    public String getRequestedFormDisplayName() {
        String formDisplayName = null;

        if (this.getFormLanguage().equalsIgnoreCase(Constants.FRENCH_CANADIAN_LOCALE)) {
            formDisplayName = ((NavigationBarBean)this.getModuleList(false).get(getModuleIdArrayIndex(this.
                    getRequestedModuleId()))).getFormNameFrench();
        } else {
            formDisplayName = ((NavigationBarBean)this.getModuleList(false).get(getModuleIdArrayIndex(this.
                    getRequestedModuleId()))).getFormNameEnglish();
        }

        return formDisplayName;
    }


    /**
     * resetModuleId
     *
     * Resetting the module ID will also return the name of the new module.
     *
     * @return String
     */
    public void resetModuleId() {
        this.setCurrentModuleId(this.getRequestedModuleId());
    }

    /**
     * The following method are called from the Rendered attributes
     * of the top and bottom menu bar JSP page.
     *
     * isSaveEnabled
     */
    public boolean isSaveEnabled() {
        if (toolListStr == null) {
            return false;
        } else if (toolListStr.indexOf('S') > -1) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * isPrintEnabled
     */
    public boolean isPrintEnabled() {
        if (toolListStr == null) {
            return false;
        } else if (toolListStr.indexOf('P') > -1) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * isPortFolioEnabled
     */
    public boolean isPortFolioEnabled() {
        if (toolListStr == null) {
            return false;
        } else if (toolListStr.indexOf('M') > -1) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * isInstructionEnabled
     */
    public boolean isInstructionEnabled() {
        if (toolListStr == null) {
            return false;
        } else if (toolListStr.indexOf('I') > -1) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * isHelpEnabled
     */
    public boolean isHelpEnabled() {
        if (toolListStr == null) {
            return false;
        } else if (toolListStr.indexOf('H') > -1) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * isExitEnabled
     */
    public boolean isExitEnabled() {
        if (toolListStr == null) {
            return false;
        } else if (toolListStr.indexOf('E') > -1) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * getFormResourceBundleName
     *
     * Called by JSP pages to load the page's resource bundle as found in the
     * Web_Module_Beanclass table (MessageResource_name).
     *
     * @return String
     */
    public String getFormResourceBundleName() {
        String resourceBundleName = "";

        CommonService commonService = new CommonService();
        ArrayList moduleBeanClassList = commonService.getModuleBeanClass(this.getCurrentSubsystemId(), this.getRequestedModuleName());

        resourceBundleName = Constants.RESOURCES_PREFIXE + '.'+ (((WebModuleBeanClass)moduleBeanClassList.get(0)).getMessageResourceName());

        return resourceBundleName;
    }
}
