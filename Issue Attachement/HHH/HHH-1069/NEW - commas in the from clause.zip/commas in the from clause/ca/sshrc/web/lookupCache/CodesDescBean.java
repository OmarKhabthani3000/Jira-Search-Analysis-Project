package ca.sshrc.web.lookupCache;



/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class CodesDescBean {
    /** identifier field */
    private Integer code;

    /** nullable persistent field */
    private String codeType;

    /** nullable persistent field */
    private String nameEnglish;

    /** nullable persistent field */
    private String nameFrench;

    /** persistent field */
    private String shortNameEnglish;

    /** persistent field */
    private String shortNameFrench;

    /** nullable persistent field */
    private Integer sequenceNumber;

    /** identifier field */
    private Integer subGroup;

    public CodesDescBean() {
    }

    /* This constructor is required for ca.sshrc.web.lookupCache.CodesDescCache*/
    public CodesDescBean(Integer code, String codeType, String nameEnglish, String nameFrench,
                         String shortNameEnglish, String shortNameFrench, Integer codeSequenceNumber,
                         Integer codeCategorySequenceNumber, Integer subGroup) {
        this.code = code;
        this.codeType = codeType;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.shortNameEnglish = shortNameEnglish;
        this.shortNameFrench = shortNameFrench;
        this.subGroup = subGroup;

        // As per specification from PB object sshrc_caches.dddw_codes_group_long_desc
        if (codeCategorySequenceNumber == null) {
            this.sequenceNumber = codeSequenceNumber;
        } else {
            this.sequenceNumber = codeCategorySequenceNumber;
        }
    }

    /* This constructor is required for ca.sshrc.web.lookupCache.CodesDescTableCache*/
    public CodesDescBean(Integer code, String codeType, String nameEnglish, String nameFrench,
                         String shortNameEnglish, String shortNameFrench, Integer codeSequenceNumber) {
        this.code = code;
        this.codeType = codeType;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.shortNameEnglish = shortNameEnglish;
        this.shortNameFrench = shortNameFrench;

        this.sequenceNumber = codeSequenceNumber;
    }

    public Integer getCode() {
        return code;
    }

    public String getCodeType() {
        return codeType;
    }

    public String getNameEnglish() {
        return nameEnglish;
    }

    public String getNameFrench() {
        return nameFrench;
    }

    public Integer getSequenceNumber() {
        /** Should not return a null, the Comparator (sequenceNumberOrderAsc)
         * CodesDescCache object will not work properly. And the call to get
         * a cache that use this Comparator will return a NullPointerException*/
        if (sequenceNumber == null) {
            sequenceNumber = new Integer(0);
        }
        return sequenceNumber;
    }

    public String getShortNameEnglish() {
        return shortNameEnglish;
    }

    public String getShortNameFrench() {
        return shortNameFrench;
    }

    public Integer getSubGroup() {
        return subGroup;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public void setCodeType(String codeType) {
        this.codeType = codeType;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public void setNameFrench(String nameFrench) {
        this.nameFrench = nameFrench;
    }

    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public void setShortNameEnglish(String shortNameEnglish) {
        this.shortNameEnglish = shortNameEnglish;
    }

    public void setShortNameFrench(String shortNameFrench) {
        this.shortNameFrench = shortNameFrench;
    }

    public void setSubGroup(Integer subGroup) {
        this.subGroup = subGroup;
    }
}
