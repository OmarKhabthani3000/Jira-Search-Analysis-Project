package ca.sshrc.web.forms.beans.cv;

import java.util.*;

import ca.sshrc.web.common.services.*;
import ca.sshrc.web.common.services.baseObject.*;
import org.hibernate.*;
import org.apache.log4j.*;
import org.apache.commons.beanutils.*;
import hibernate.*;
import java.lang.reflect.InvocationTargetException;
import javax.faces.component.UIData;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class AddressBean extends BeanBase {

    private Logger logger = Logger.getLogger(AddressBean.class.getName());
    private ArrayList addressList = null;
    private UIData addressTable;

    public AddressBean() {
        logger.info("AddressBean - minimal constructor");
        try {
            // Get a session
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();

            // Call this object's retrieve method
            this.retrieve(new Integer(0), session);

        } catch (Exception ex) {
            HibernateUtil.closeSession();
            ex.printStackTrace();
        } finally {
            // Close the Hibernate connection
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public UIData getAddressTable() {
     return addressTable;
    }

    public void setAddressTable(UIData addressTable) {
        this.addressTable = addressTable;
    }

    public void setAddresses(ArrayList addresses) {
        this.addressList = addresses;
    }

    public ArrayList getAddresses() {
        return addressList;
    }

    // Overwrite ancestor method
    public void retrieve(Session session) {
        retrieve(new Integer(0), session);
    }

    /**
     * retrieve
     *
     * @param aCid Integer
     */
    public void retrieve(Integer aCid, Session session) {
        List queryList;
        logger.info("AddressBean.retrieve passed parameter is cid : " + aCid);

        if (null == session) {
            if (logger.isEnabledFor(org.apache.log4j.Level.ERROR)) {
                logger.error("Cannot load AddressBean - Session is null");
                return;
            }
        }

        // If the passed form_id is 0, get the form_id from the NavigationBean
        if (aCid.longValue() == 0) {
            aCid = this.getLogonBean().getWeb_id();
            if (aCid.intValue() == 0) {
                if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                    logger.error("Cannot load AddressBean - no FormId : " + aCid);
                    return;
                }
            } else {
                logger.info("AddressBean.retrieve using logonBean webId : " + aCid);
            }

        } else {
            logger.info("LogonBean.retrieve using passed parm webId : " + aCid);
        }
        //Let's retrieve the data from the DB
        try {
            logger.info("In AddressBean.retrieve()");

            queryList = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.cv.AddressDataBean(address.addressId, " +
                    "address.cid, " +
                    "address.formatType, " +
                    "address.addressType, " +
                    "address.address1, " +
                    "address.address2, " +
                    "address.address3, " +
                    "address.address4, " +
                    "address.municipality, " +
                    "address.provinceStateCode, " +
                    "address.country.countryCode, " +
                    "country.nameEnglish, " +
                    "country.nameFrench, " +
                    "address.postalZipCode, " +
                    "address.tmpPhoneCountryCode, " +
                    "address.tmpPhoneAreaCode, " +
                    "address.tmpPhoneNumber, " +
                    "address.tmpPhoneExtension, " +
                    "address.tmpFaxCountryCode, " +
                    "address.tmpFaxPhoneAreaCode, " +
                    "address.tmpFaxPhoneNumber, " +
                    "address.tmpFaxPhoneExtension, " +
                    "address.tmpEmailAddress, " +
                    "address.tmpDateFrom, " +
                    "address.tmpDateTo, " +
                    "address.changeDate )" +
                    "from PersonAddress address " +
                    "left outer join fetch address.country country " +
                    "where (address.cid = :Cid) and " +
                    "(address.addressType in (6,2)) " +
                    "order by address.addressType asc ")
                        .setParameter("Cid", aCid)
                        .list();
            /*                    "from Form form join fetch form.person person " +
                                "left outer join fetch person.personAddress address " +
                                "left outer join fetch address.country country " +
                                "where (address.addressType = :addressType)" +
                                " and (form.formId = :formId)")
*/
            logger.info("AddressBean.retrieve - just after the SQL statement");
            logger.info("AddressBean.retrieve - number of rows retrieved = " + queryList.size());
            if (queryList.size() == 2) {
                this.addressList = new ArrayList(queryList);
            } else if (queryList.size() == 1) {
                //we need to find which bean we have here
                logger.info("AddressBean.retrieve - we have 1 row");
                this.addressList = new ArrayList();
                addressList.add(queryList.get(0));
                logger.debug("AddressBean.retrieve - ArrayList has been created");
                if (((AddressDataBean) addressList.get(0)).getAddressType().intValue() == 6) {
                    logger.info("AddressBean.retrieve - addressType = 6");
                    this.addressList.add(0, new AddressDataBean(this.getLogonBean().getWeb_id(), new Integer(2)));
                } else {
                    logger.info("AddressBean.retrieve - addressType = 2");
                    this.addressList.add( new AddressDataBean(this.getLogonBean().getWeb_id(), new Integer(6)));
                }

            } else {
                this.addressList = new ArrayList();
                this.addressList.add(new AddressDataBean(this.getLogonBean().getWeb_id(), new Integer(2)));
                this.addressList.add(new AddressDataBean(this.getLogonBean().getWeb_id(), new Integer(6)));

            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * save
     *
     * @param session Session
     * @return String
     */
    public String save(Session session) throws HibernateException, InvocationTargetException,
            IllegalAccessException {

        List queryList;
        AddressDataBean tempBean = null;
        boolean boFullBean = false;
        hibernate.PersonAddress myAddress = null;
        String saveOutcome = "failure"; // Defaults to failure

        logger.info("In AddressBean.save()");
        logger.info("We have " + this.addressList.size() + " beans in addressList");
        if (this.addressList.size() > 0) {
            tempBean = (AddressDataBean)this.addressList.get(0);
            logger.info("the cid = " + tempBean.getCid());

        }

        HibernateUtil.beginTransaction();

        queryList = session.createQuery("from PersonAddress " +
                                        "where cid = :cid and Address_Type in (2,6)")
                    .setParameter("cid", tempBean.getCid())
                    .list();
        logger.info("In AddressBean.save() - Retrieved hibernate.AddressBean object for cid: " +
                    tempBean.getCid());

        if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
            logger.info("Loaded hibernate.AddressBean objects : " + queryList.size());
        }

        if (this.addressList.size() > 0) {
            // Set values
            for (int i = 0; i < this.addressList.size(); i++) {
                tempBean = (AddressDataBean)this.addressList.get(i);
                tempBean.populateDateFields();
                boFullBean = tempBean.hasData();
                logger.info("AddressBean.save - Is the bean " + i + " full: " + boFullBean);
                // Check that this is an existing record
                if ( tempBean.getAddressId() == null ) {
                    logger.info("this is a new record");
                    // there is no record, copy the bean and save.
                    // Save only if the bean has data
                    if (boFullBean) {

                        hibernate.PersonAddress newAddress = new PersonAddress();
                        BeanUtils.copyProperties(newAddress, tempBean);
                        newAddress.setAddressId(null);
                        session.saveOrUpdate(newAddress);
                        session.flush();
                        session.refresh(newAddress);
                    }
                    saveOutcome = "success";

                } else {

                    // this is an existing record. Locate the matching one in the database
                    Iterator it = queryList.iterator();
                    while (it.hasNext()) {
                        myAddress = (PersonAddress) it.next();
                        if (myAddress.getAddressId().equals(tempBean.getAddressId())) {
                            // this is the correct record, update and save
                            if (boFullBean ) {
                                BeanUtils.copyProperties(myAddress, tempBean);
                                session.saveOrUpdate(myAddress);
                            }else {
                                session.delete(myAddress);
                            }
                            saveOutcome = "success";
                            break;
                        }
                    }
                }
            }
        }

        return saveOutcome;
    }

}
