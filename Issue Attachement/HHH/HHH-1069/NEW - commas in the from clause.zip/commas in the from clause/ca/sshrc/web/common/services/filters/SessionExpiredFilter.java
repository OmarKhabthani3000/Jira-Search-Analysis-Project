package ca.sshrc.web.common.services.filters;

// SessionExpiredFilter.java


import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class SessionExpiredFilter implements Filter {
    private String page;
    private FilterConfig filterConfig = null;


    public void destroy() {
        this.filterConfig = null;
    }


    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException,
            ServletException {

        if (filterConfig == null) {
            return;
        }

        boolean isSessionExpired = false;

        // Get config
        if (filterConfig.getInitParameter("SessionTimeOutpage") != null) {
            page = filterConfig.getInitParameter("SessionTimeOutpage");
        } else {
            page = "/SessionTimeOut.html";
        }

        // Get requested path
        String requestedPath = ((HttpServletRequest) request).getRequestURI();

        System.out.println("SessionExpiredFilter - getRequestURI: " +
                           ((HttpServletRequest) request).getRequestURI());

        // Process only if request's not for logon page, StyleSheet or images
        if (!requestedPath.endsWith("logon.jsp") && !requestedPath.endsWith("logon_f.jsp") &&
            !requestedPath.endsWith("logon_e.jsp") && !requestedPath.endsWith(".css") &&
            !requestedPath.endsWith(".gif") && !requestedPath.endsWith("registration.jsp")) {

            // If there's a session open
            if (((HttpServletRequest) request).getRequestedSessionId() != null) {
                // If the session is invalid
                if (((HttpServletRequest) request).isRequestedSessionIdValid() == false) {
                    System.out.println("SessionExpiredFilter - isRequestedSessionIdValid returned false");
                    isSessionExpired = true;
                }
                // Are both the logonBean and navigationBean in the session bean?
                else {
                    HttpSession session = ((HttpServletRequest) request).getSession(false);
                    if (session != null) {
                        if ((session.getAttribute("logonBean") == null) ||
                            (session.getAttribute("navigationBean") == null)) {
                            if (session.getAttribute("logonBean") == null) {
                                System.out.println(
                                        "SessionExpiredFilter - Required bean (logonBean) missing");
                            }
                            if (session.getAttribute("navigationBean") == null) {
                                System.out.println(
                                        "SessionExpiredFilter - Required bean (navigationBean) missing");
                            }
                            isSessionExpired = true;
                        }
                    } else {
                        System.out.println("SessionExpiredFilter - HttpSession missing");
                        isSessionExpired = true;
                    }
                }

                // The session's null, is the request for a logon page
            } else if (!requestedPath.endsWith("logon.jsp")) {
                System.out.println("SessionExpiredFilter - getRequestedSessionId was null");
                System.out.println("SessionExpiredFilter - Requested URI not for logon page");
                isSessionExpired = true;
            }
        }

        if (isSessionExpired) {
            RequestDispatcher rd = request.getRequestDispatcher(page);
            System.out.println("SessionExpiredFilter - Expired");
            rd.forward(request, response);
        } else {
            chain.doFilter(request, response);
        }
    }


    public void init(FilterConfig filterConfig) throws ServletException {
        this.filterConfig = filterConfig;
    }
}
