package ca.sshrc.web.lookupCache;


/**
 * <p>Title: NavigationBarBean</p>
 *
 * <p>Description: Contains side menu properties and methods.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Social Sciences and Humanities Research Council of Canada</p>
 *
 * @author Guy Bellemarre
 * @version 1.0
 */


// Implements serializable - Kept in session bean
public class NavigationBarBean implements java.io.Serializable {
    private Integer webSubsystem;
    private Integer sequenceNumber;
    private String moduleName;
    private String nameEnglish;
    private String nameFrench;
    private String shortNameEnglish;
    private String shortNameFrench;
    private String formNameEnglish;
    private String formNameFrench;
    private String toolBar;


    public NavigationBarBean() {
    }

    /**
     * NavigationBarBean
     *
     * @param webSubsystem int
     * @param sequenceNumber int
     * @param moduleName String
     * @param nameEnglish String
     * @param nameFrench String
     * @param shortNameEnglish String
     * @param shortNameFrench String
     * @param toolBar String
     */

    public NavigationBarBean(Integer webSubsystem, Integer sequenceNumber, String moduleName,
                             String nameEnglish, String nameFrench, String shortNameEnglish,
                             String shortNameFrench, String formNameEnglish, String formNameFrench, String toolBar) {
        this.webSubsystem = webSubsystem;
        this.sequenceNumber = sequenceNumber;
        this.moduleName = moduleName;
        this.nameEnglish = nameEnglish;
        this.nameFrench = nameFrench;
        this.shortNameEnglish = shortNameEnglish;
        this.shortNameFrench = shortNameFrench;
        this.formNameEnglish = formNameEnglish;
        this.formNameFrench = formNameFrench;
        this.toolBar = toolBar;
    }

    public Integer getWebSubsystem() {
        return webSubsystem;
    }

    public Integer getSequenceNumber() {
        return sequenceNumber;
    }

    /**
     * getSequenceNumberString
     *
     * @return String
     */
    public String getSequenceNumberString() {
        return sequenceNumber.toString();
    }

    public String getModuleName() {
        return moduleName;
    }

    public String getNameEnglish() {
        return nameEnglish;
    }

    public String getNameFrench() {
        return nameFrench;
    }

    public String getShortNameEnglish() {
        return shortNameEnglish;
    }

    public String getShortNameFrench() {
        return shortNameFrench;
    }

    public String getFormNameEnglish() {
        return formNameEnglish;
    }

    public String getFormNameFrench() {
        return formNameFrench;
    }

    public String getToolBar() {
        return toolBar;
    }

    public void setWebSubsystem(Integer webSubsystem) {
        this.webSubsystem = webSubsystem;
    }

    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public void setNameEnglish(String nameEnglish) {
        this.nameEnglish = nameEnglish;
    }

    public void setNameFrench(String nameFrench) {
        this.nameFrench = nameFrench;
    }

    public void setShortNameEnglish(String shortNameEnglish) {
        this.shortNameEnglish = shortNameEnglish;
    }

    public void setShortNameFrench(String shortNameFrench) {
        this.shortNameFrench = shortNameFrench;
    }

    public void setToolBar(String toolBar) {
        this.toolBar = toolBar;
    }
}
