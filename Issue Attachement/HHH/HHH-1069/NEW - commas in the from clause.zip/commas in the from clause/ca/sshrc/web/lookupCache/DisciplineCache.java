package ca.sshrc.web.lookupCache;

import java.io.*;
import java.text.*;
import java.util.*;

import ca.sshrc.web.common.services.*;
import hibernate.*;
import org.hibernate.*;
import org.apache.log4j.*;

public class DisciplineCache implements Serializable {
    private Logger logger = Logger.getLogger(DisciplineCache.class.getName());
    private List queryList;

    /**
     * DisciplineCache
     */
    public DisciplineCache() {

        Session session = HibernateUtil.getSession();
        HibernateUtil.beginTransaction();
        logger.info("In DisciplineCache");

        try {
            queryList = session.createQuery(
                    "select new ca.sshrc.web.lookupCache.DisciplineBean(Discipline.disciplineCode, " +
                    "Discipline.nameFrench, " +
                    "Discipline.nameEnglish, " +
                    "Discipline.activeInd, " +
                    "Discipline.createDate, " +
                    "Discipline.createUserId, " +
                    "Discipline.changeDate, " +
                    "Discipline.changeUserId, " +
                    "Discipline.mainDiscipline.mainDisciplineCode) " +

                    "from Discipline Discipline " +
                    "where Discipline.activeInd = 'Y' " +
                    "order by Discipline.disciplineCode ASC ").list();

            if (logger.isEnabledFor(org.apache.log4j.Level.INFO)) {
                logger.info("Discipline loaded: " + queryList.size());

            }
        } catch (HibernateException ex) {
            ex.printStackTrace();
            HibernateUtil.rollbackTransaction();
            HibernateUtil.closeSession();
        } finally {
            try {
                HibernateUtil.commitTransaction();
                HibernateUtil.closeSession();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

    }

    public static final Comparator nameEnglishOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA);
            Discipline objComp1 = (Discipline) o1;
            Discipline objComp2 = (Discipline) o2;
            return myCollator.compare(objComp1.getNameEnglish(),
                                      objComp2.getNameEnglish());
        }
    };

    public static final Comparator nameFrenchOrder = new Comparator() {
        public int compare(Object o1, Object o2) {
            Collator myCollator = Collator.getInstance(Locale.CANADA_FRENCH);
            Discipline objComp1 = (Discipline) o1;
            Discipline objComp2 = (Discipline) o2;
            return myCollator.compare(objComp1.getNameFrench(),
                                      objComp2.getNameFrench());
        }
    };
    public ArrayList getMasterList() {
        // Keep the original array. Use a copy for sorting
        ArrayList listTemp = new ArrayList();

        for (int i = 0; i < this.queryList.size(); i++) {
            DisciplineBean tempDisc = (DisciplineBean) queryList.get(i);
            if (tempDisc.getDisciplineCode().toString().endsWith("00")) {
                listTemp.add(tempDisc);
            }

        }

        return listTemp;

    }

    /**
     * getDetailList
     *
     * @param aIMasterCode Integer
     * @return List
     */
    public ArrayList getDetailList(Integer aIMasterCode) {
        ArrayList listTemp = new ArrayList();
        int found = 0;

        for (int i = 0; i < this.queryList.size(); i++) {
            DisciplineBean tempDisc = (DisciplineBean) queryList.get(i);
            if (tempDisc.getMainDiscipline().equals(aIMasterCode)) {
                found++;
                listTemp.add(tempDisc);
                /*   } else if (found > 0) {
                       break;*/
            }
        }

        return listTemp;
    }


}
