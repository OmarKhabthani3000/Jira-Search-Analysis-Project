package ca.sshrc.web.common.services;

public class ValidationMessageBean {
    private String moduleName;
    private String message;
    private Integer moduleId;
    private Integer subsystemId;

    public ValidationMessageBean(Integer subsystemId, Integer moduleId, String moduleName, String message) {
        this.subsystemId = subsystemId;
        this.moduleId = moduleId;
        this.moduleName = moduleName;
        this.message = message;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }

    public void setSubsystemId(Integer subsystemId) {
        this.subsystemId = subsystemId;
    }

    public String getModuleName() {
        return moduleName;
    }

    public String getMessage() {
        return message;
    }

    public Integer getModuleId() {
        return moduleId;
    }

    public Integer getSubsystemId() {
        return subsystemId;
    }
}
