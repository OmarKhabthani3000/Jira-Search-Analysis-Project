package ca.sshrc.web.common.services;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class ForTesting {
    private String tempString;

    public ForTesting() {
        System.out.println("ForTesting.constructor");
    }

    public boolean isExitEnabled() {
        System.out.println("ForTesting.isExitEnabled");
    return false;
    }
    public boolean getExitEnabled() {
        System.out.println("ForTesting.isExitEnabled");
    return false;
    }

    public String getTempString() {
        return tempString;
    }

    public void setTempString(String tempString) {
        this.tempString = tempString;
    }
}
