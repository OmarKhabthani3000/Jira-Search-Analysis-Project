package ca.sshrc.web.common.services;

import java.util.*;

import org.hibernate.*;
import ca.sshrc.web.forms.beans.cv.AcademicDataBean;

public class TestDBAHibernate {
    private List list;

    public List TestDBAHibernate(long formId) {
        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();


            list = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.cv.AcademicDataBean(" +
                    "acad.degreeId, " +
                    "acad.cid, " +
                    "acad.degreeType, " +
                    "cod.shortNameEnglish, " +
                    "cod.shortNameEnglish) " +
                    "from PersonAcademicBackground acad join fetch acad.degreeType as cod " +
                    "where (acad.cid = :Cid)")
                        .setParameter("Cid", new Integer(21282))
                        .list();

            Iterator it = list.iterator();
            while (it.hasNext()) {
                AcademicDataBean localDataCasting = (AcademicDataBean) it.next();
            }
            HibernateUtil.commitTransaction();
            HibernateUtil.closeSession();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
