package ca.sshrc.web.common.services;

import java.util.*;

import org.apache.log4j.*;
import org.hibernate.*;
import ca.sshrc.web.forms.beans.cv.AcademicDataBean;

public class TestDBAHibernate {
    private Logger logger = Logger.getLogger(TestDBAHibernate.class.getName());
    private List list;

    public List TestDBAHibernate(long formId) {
        try {
            Session session = HibernateUtil.getSession();
            HibernateUtil.beginTransaction();
            logger.info("In TestDBAHibernate - About to execute query ...");


            list = session.createQuery(
                    "select new ca.sshrc.web.forms.beans.cv.AcademicDataBean(" +
                    "acad.degreeId, " +
                    "acad.cid, " +
                    "acad.degreeType, " +
                    "cod.shortNameEnglish, " +
                    "cod.shortNameEnglish) " +
                    "from PersonAcademicBackground acad left join fetch acad.degreeType as cod " +
                    "where (acad.cid = :Cid)")
                        .setParameter("Cid", new Integer(21282))
                        .list();

                 if (logger.isEnabledFor(org.apache.log4j.Priority.INFO)) {
                     logger.info("TestDBAHibernate rows retrieved: " +
                                 list.size());
                 }

            Iterator it = list.iterator();
            while (it.hasNext()) {
                AcademicDataBean localDataCasting = (AcademicDataBean) it.next();
                if (logger.isEnabledFor(org.apache.log4j.Priority.INFO)) {
                    logger.info("TestDBAHibernate before calling getDegreeId()");
                    logger.info("TestDBAHibernate getDegreeId: " +
                                localDataCasting.getDegreeId());
                }
            }
            HibernateUtil.commitTransaction();
            HibernateUtil.closeSession();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
