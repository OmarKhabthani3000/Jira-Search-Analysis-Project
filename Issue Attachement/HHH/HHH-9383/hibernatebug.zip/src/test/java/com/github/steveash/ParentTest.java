package com.github.steveash;

import static org.junit.Assert.assertEquals;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.junit.Before;
import org.junit.Test;

public class ParentTest {

    private SessionFactory sf;

    @Before
    public void setUp() throws Exception {
        Configuration cfg = new Configuration();
        cfg.addAnnotatedClass(Parent.class);
        cfg.addAnnotatedClass(Child.class);
        cfg.configure();
        sf = cfg.buildSessionFactory();

    }

    @Test
    public void testSaveLoad() throws Exception {
        Parent p = new Parent();
        p.setSomeOtherAttribute(42);
        save(p);
        int loadedValue = loadValue(p);
        assertEquals(42, loadedValue);
    }

    private int loadValue(Parent p) {Session s = sf.openSession();
        Transaction trx2 = s.beginTransaction();
        Parent loaded = (Parent) s.load(Parent.class, p.getId());

        int loadedValue = loaded.getSomeOtherAttribute();
        trx2.commit();
        s.close();
        return loadedValue;
    }

    @Test
    public void testMerge() throws Exception {
        Parent p = insertOneAndOne();

        Session s = sf.openSession();
        Transaction trx2 = s.beginTransaction();
        s.merge(p);
        p.setSomeOtherAttribute(21);
        trx2.commit();
        s.close();

        int loadedValue = loadValue(p);
        assertEquals(21, loadedValue);
    }

    @Test
    public void testJoinFetch() throws Exception {
        Parent p = insertOneAndOne();
        Session s = sf.openSession();

        Parent loaded = (Parent) s.createQuery("select distinct p from Parent p join fetch p.children where p.id = :id")
                .setLong("id", p.getId())
                .uniqueResult();

        assertEquals(42, p.getSomeOtherAttribute());
        s.close();
    }

    private Parent insertOneAndOne() {
        Parent p = new Parent();
        p.setSomeOtherAttribute(42);
        Child c = new Child();
        c.setParent(p);
        c.setQualifier("A");
        c.setSomeOtherAttributes(84);
        p.getChildren().add(c);

        save(p);
        return p;
    }

    private void save(Parent p) {
        Session s = sf.openSession();
        Transaction trx = s.beginTransaction();
        s.save(p);
        trx.commit();
        s.close();
    }
}