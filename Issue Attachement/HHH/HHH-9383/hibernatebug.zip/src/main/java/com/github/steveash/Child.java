package com.github.steveash;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 *
 */
@Entity
public class Child implements Serializable {

    private Parent parent;
    private String qualifier;
    private int someOtherAttributes;

    @Id
    @ManyToOne
    @JoinColumn(name = "parent_id", referencedColumnName = "id", nullable = false)
    public Parent getParent() {
        return parent;
    }

    public void setParent(Parent parent) {
        this.parent = parent;
    }

    @Id
    public String getQualifier() {
        return qualifier;
    }

    public void setQualifier(String qualifier) {
        this.qualifier = qualifier;
    }

    @Basic
    public int getSomeOtherAttributes() {
        return someOtherAttributes;
    }

    public void setSomeOtherAttributes(int someOtherAttributes) {
        this.someOtherAttributes = someOtherAttributes;
    }
}
