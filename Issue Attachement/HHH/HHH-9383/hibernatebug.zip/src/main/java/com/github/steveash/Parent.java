package com.github.steveash;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.DynamicUpdate;

/**
 *
 */
@Entity
@DynamicUpdate
public class Parent implements Serializable {

    private long id;
    private Set<Child> children = new HashSet<Child>();
    private int someOtherAttribute;

    @Id
    @GeneratedValue( strategy = GenerationType.AUTO)
    @Column(name = "id")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @OneToMany(mappedBy = "parent", orphanRemoval = true)
    @Cascade(value = {CascadeType.ALL})
    public Set<Child> getChildren() {
        return children;
    }

    public void setChildren(Set<Child> children) {
        this.children = children;
    }

    @Basic
    public int getSomeOtherAttribute() {
        return someOtherAttribute;
    }

    public void setSomeOtherAttribute(int someOtherAttribute) {
        this.someOtherAttribute = someOtherAttribute;
    }
}
