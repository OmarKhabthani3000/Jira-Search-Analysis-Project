/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2009, Red Hat, Inc. and/or its affiliates or third-
 * party contributors as indicated by the @author tags or express 
 * copyright attribution statements applied by the authors.  
 * All third-party contributions are distributed under license by 
 * Red Hat, Inc.
 *
 * This copyrighted material is made available to anyone wishing to 
 * use, modify, copy, or redistribute it subject to the terms and 
 * conditions of the GNU Lesser General Public License, as published 
 * by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public 
 * License along with this distribution; if not, write to:
 * 
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.test.aliastobeanresulttransformer;

import java.util.List;

import org.junit.Test;

import org.hibernate.Query;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.testing.TestForIssue;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.hibernate.transform.ResultTransformer;
import org.hibernate.test.sfi.aliastobeanresulttransformer.*;
import com.ibm.websphere.cluster.topography.Contract;
import org.hibernate.transform.AliasToBeanIgnoreCaseResultTransformer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * @author Javier Ledo Vázquez (javier.ledo@tecnocom.es)
 */
public class AliasToBeanIgnoreCaseResultTransformerTest extends BaseCoreFunctionalTestCase {
	@Override
	public String[] getMappings() {
		return new String[] { "aliastobeanresulttransformer/User.hbm.xml" };
	}

	@Test
	@TestForIssue( jiraKey = "HHH-7960" )
	public void testResultTransformerIsAppliedToScrollableResults() throws Exception
	{
		Session s = openSession();
		Transaction tx = s.beginTransaction();

		User a = new User();
		a.setFirstName("Ledo");
		a.setLastName("Vázquez");
		s.save(a);

		tx.commit();
		s.close();

		s = openSession();

                testQuery(s, ".testQuery");
                testQuery(s, ".testQuery2");

		s.close();
	}
        
        private void testQuery(Session s, String query){
            	Query q = s.getNamedQuery(User.class.getName() + query);
		q.setFetchSize(100);
		q.setResultTransformer(new AliasToBeanIgnoreCaseResultTransformer(User.class);
		ScrollableResults sr = q.scroll();
		sr.first();
		Object[] row = sr.get();
		assertEquals(1, row.length);
		Object obj = row[0];
		assertTrue(obj instanceof User);
		User obj2 = (User) obj;
		assertEquals("Ledo", obj2.getFirstName());
		assertEquals("Vázquez", obj2.getLastName());
        }
            
}


