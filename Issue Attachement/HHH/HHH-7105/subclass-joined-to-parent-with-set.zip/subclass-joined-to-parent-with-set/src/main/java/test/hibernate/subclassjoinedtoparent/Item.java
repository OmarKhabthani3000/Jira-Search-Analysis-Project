package test.hibernate.subclassjoinedtoparent;

public class Item extends AbstractContainer {
    
    private AbstractContainer container;
    
    public AbstractContainer getContainer() {
        return container;
    }
    public void setContainer(AbstractContainer container) {
        this.container = container;
    }
}
