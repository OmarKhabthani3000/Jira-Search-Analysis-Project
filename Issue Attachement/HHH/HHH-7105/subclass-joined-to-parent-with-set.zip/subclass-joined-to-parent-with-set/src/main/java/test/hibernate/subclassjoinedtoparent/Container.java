package test.hibernate.subclassjoinedtoparent;

public class Container extends AbstractContainer {

}
