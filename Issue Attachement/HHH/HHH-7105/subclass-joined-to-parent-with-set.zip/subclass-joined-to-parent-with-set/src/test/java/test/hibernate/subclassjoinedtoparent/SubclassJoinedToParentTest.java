package test.hibernate.subclassjoinedtoparent;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Assert;
import org.junit.Test;

/**
 * @author Justin Walsh
 */
public class SubclassJoinedToParentTest {

    @Test
    public void executeTest() throws Exception {

        // Create the SessionFactory from hibernate.cfg.xml
        SessionFactory sessionFactory = 
            new Configuration().configure("hibernate-subclassjoinedtoparent.cfg.xml").buildSessionFactory();

        AbstractContainer container;
        Item item;
        
        // set up the fixture
        Session session = sessionFactory.openSession();
        try {

            session.beginTransaction();
            container = new Container();
            
            item = new Item();
            container.addItem(item);

            session.save(container);
            session.flush();
            
            System.out.println("TX #1: Saved container with id: " + container.getId());
            System.out.println("TX #1: Container has " + container.getItems().size() + " items.");
            
            session.getTransaction().commit();
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        }
        finally {
            session.close();
        }
        
        // add a single item to the container
        session = sessionFactory.openSession();
        try {

            session.beginTransaction();
            
            AbstractContainer savedContainer = (AbstractContainer)session.get(AbstractContainer.class, container.getId());
            System.out.println("TX #2: Found the container with id: " + savedContainer.getId());
            
            System.out.println("TX #2: Container has " + savedContainer.getItems().size() + " items.");
            Assert.assertEquals(1, savedContainer.getItems().size());
            
            
            session.getTransaction().commit();
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        }
        finally {
            session.close();
        }
        
    }
}