package com.demo;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.demo.dao.IProductDao;
import com.demo.model.Language;
import com.demo.model.Product;
import com.demo.model.ProductLocalizedInfo;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:context.xml" })
public class MainTest {

	@Resource
	private IProductDao dao;

	@Test
	public void shouldFailBecauseOfBug() {
		Product prod = new Product("product_001_red_socks");

		prod.addI18NInfos(Language.fr, new ProductLocalizedInfo(
				"chaussettes rouges",
				"chaussettes rouges, confortables & chaudes"));
		prod.addI18NInfos(Language.en, new ProductLocalizedInfo("red socks",
				"warm & comfy red socks"));

		dao.createProduct(prod);

		System.out.println("done");
	}

}
