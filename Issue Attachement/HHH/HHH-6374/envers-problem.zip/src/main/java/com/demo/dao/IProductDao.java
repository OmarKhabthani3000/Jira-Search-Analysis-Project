package com.demo.dao;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.demo.model.Product;

public interface IProductDao {

	@Transactional(propagation = Propagation.REQUIRED)
	public abstract void createProduct(Product productToCreate);

}