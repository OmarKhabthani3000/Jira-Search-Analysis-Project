package com.demo.model;

import org.springframework.orm.jpa.support.JpaDaoSupport;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public class ProductDao extends JpaDaoSupport {

	@Transactional(propagation = Propagation.REQUIRED)
	public void createProduct(Product productToCreate) {
		getJpaTemplate().persist(productToCreate);
	}

}
