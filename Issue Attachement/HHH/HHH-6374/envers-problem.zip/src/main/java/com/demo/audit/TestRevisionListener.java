package com.demo.audit;

import org.hibernate.envers.RevisionListener;

public class TestRevisionListener implements RevisionListener {

	public void newRevision(Object revisionEntity) {

	}

}
