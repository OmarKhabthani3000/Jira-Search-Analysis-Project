package com.demo.model;

public enum Language {
	fr, en
}
