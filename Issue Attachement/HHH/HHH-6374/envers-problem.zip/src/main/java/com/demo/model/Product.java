package com.demo.model;

import java.util.EnumMap;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.envers.Audited;

@Entity
@Audited
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	private String code;

	@OneToMany(cascade = CascadeType.ALL)
	private Map<Language, ProductLocalizedInfo> localizedInfo = new EnumMap<Language, ProductLocalizedInfo>(
			Language.class);

	public Product() {
	}

	public Product(String code) {
		super();
		this.code = code;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Map<Language, ProductLocalizedInfo> getLocalizedInfo() {
		return localizedInfo;
	}

	public void setLocalizedInfo(
			Map<Language, ProductLocalizedInfo> localizedInfo) {
		this.localizedInfo = localizedInfo;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public void addI18NInfos(Language language,
			ProductLocalizedInfo localizedInfo) {
		if (language != null) {
			this.localizedInfo.put(language, localizedInfo);
		}
	}

}
