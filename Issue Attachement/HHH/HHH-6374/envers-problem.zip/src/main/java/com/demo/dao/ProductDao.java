package com.demo.dao;

import org.springframework.orm.jpa.support.JpaDaoSupport;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.demo.model.Product;

public class ProductDao extends JpaDaoSupport implements IProductDao {

	/* (non-Javadoc)
	 * @see com.demo.dao.IProductDao#createProduct(com.demo.model.Product)
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	public void createProduct(Product productToCreate) {
		getJpaTemplate().persist(productToCreate);
	}

}
