package com.demo.audit;

import javax.persistence.Entity;

import org.hibernate.envers.DefaultRevisionEntity;
import org.hibernate.envers.RevisionEntity;

@Entity
@RevisionEntity(TestRevisionListener.class)
public class TestRevisionEntity extends DefaultRevisionEntity {

}
