package service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import org.jboss.logging.Logger;

import domain.Adress;
import domain.Person;
import exceptions.DbUnitException;

@Stateless
public class PersonService {

    public static Logger logger = Logger.getLogger(PersonService.class.getName());

    @Inject
    DaoGenericService service;

    @Inject
    AdressService adressService;

    public Person createPersonMitDao(Person p) {
        p = service.create(p);
        return p;
    }

    public Person createPersonMitAdressDao(Person p) {
        // some logic...


        if (p != null && p.getAdresses() != null) {
            List<Adress> adressList = p.getAdresses();
            for (Adress adress : adressList) {
                adress = service.create(adress);
                logger.info("id:" + adress.getId() + " strasse:" + adress.getStrasse());
            }
        }
        p = service.create(p);

        return p;
    }


    public Person createPersonMitAdressService(Person p) throws DbUnitException {
        // some logic...
        // validierung ob Person mit Name und Vorname bereits existiert
        List<Person> personExists = findPersonNameVorname(p);
        if (!personExists.isEmpty()) {
            throw new DbUnitException("Achtung!!! Person existiert bereits in der DB.");
        }

        if (p != null && p.getAdresses() != null) {
            List<Adress> adressList = p.getAdresses();
            for (Adress adress : adressList) {
                adress = adressService.createAdress(adress);
                logger.info("id:" + adress.getId() + " strasse:" + adress.getStrasse());
            }
        }
        p = service.create(p);

        return p;
    }

    /**
     * @param p
     * @return
     */
    public List<Person> findPersonNameVorname(Person p) {
        Map<String, Object> parameterMap = new HashMap<String, Object>();
        parameterMap.put("name", p.getName());
        parameterMap.put("vorname", p.getVorname());
        @SuppressWarnings("unchecked")
        List<Person> personExists = service.findWithNamedQuery(Person.FINDPERSON_NAME_VORNAME, parameterMap);
        return personExists;
    }

}
