package service;

import javax.ejb.Stateless;
import javax.inject.Inject;

import domain.Adress;

@Stateless
public class AdressService {
    @Inject
    DaoGenericService service;

    public Adress createAdress(Adress adress) {
        return service.create(adress);
    }
}
