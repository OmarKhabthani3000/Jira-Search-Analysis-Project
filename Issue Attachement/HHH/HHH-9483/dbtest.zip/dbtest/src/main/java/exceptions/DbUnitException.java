package exceptions;

public class DbUnitException extends Exception {
    private static final long serialVersionUID = -2490482661614522061L;

    public DbUnitException(String errorMsg) {
        super(errorMsg);
    }
}
