package service;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class DaoGenericService {

    @PersistenceContext
    private EntityManager em;
    
    public <T> T create(T t) {
        this.em.persist(t);
        this.em.flush();
        this.em.refresh(t);
        return t;
    }

    public <T> T find(Class<T> type, Object id) {
        return this.em.find(type, id);
    }

    public <T> void delete(Class<T> type, Object id) {
        Object ref = this.em.getReference(type, id);
        this.em.remove(ref);
    }

    public <T> T update(T t) {
        return this.em.merge(t);
    }
    
    @SuppressWarnings("rawtypes")
    public List findWithNamedQuery(String namedQueryName) {
        return this.em.createNamedQuery(namedQueryName).getResultList();
    }

    @SuppressWarnings("rawtypes")
    public List findWithNamedQuery(String namedQueryName, Map<String, Object> parameters) {
        return findWithNamedQuery(namedQueryName, parameters, 0, 0);
    }

    @SuppressWarnings("rawtypes")
    private List findWithNamedQuery(String namedQueryName, Map<String, Object> parameters, int startPosition,
            int maxResult) {

        Set<Entry<String, Object>> rawParameters = parameters.entrySet();
        Query query = this.em.createNamedQuery(namedQueryName);

        for (Entry<String, Object> entry : rawParameters) {
            query.setParameter(entry.getKey(), entry.getValue());
        }

        query.setFirstResult(startPosition);

        if (maxResult > 0) {
            query.setMaxResults(maxResult);
        }

        return query.getResultList();
    }

}
