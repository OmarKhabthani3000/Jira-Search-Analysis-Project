package test;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import org.junit.Test;

public class HibernateTest {

    public static EntityManager em = Persistence.createEntityManagerFactory("devsample").createEntityManager();

    public void createPersons() {

        Adress adress = new Adress();
        adress.setStrasse("MyStrasse");
        adress.setPlz("11235");

        List<Adress> adressList = new ArrayList<Adress>();
        adressList.add(adress);

        Calendar date = Calendar.getInstance();
        date.set(2012, 0, 1);
        Person person = new Person("Nachname1", "Vorname1", adressList, date.getTime());

        em.getTransaction().begin();
        em.persist(adress);
        em.persist(person);

        Calendar date2 = Calendar.getInstance();
        date2.set(2013, 1, 1);
        Person person2 = new Person("Nachname2", "Vorname2", adressList, date2.getTime());
        em.persist(person2);

        Calendar date3 = Calendar.getInstance();
        date3.set(2014, 2, 1);
        Person person3 = new Person("Nachname3", "Vorname3", adressList, date3.getTime());
        em.persist(person3);

        em.getTransaction().commit();

    }

    @Test
    public void test() {
        createPersons();

        String insertJpql = "INSERT INTO  SecondPerson (id, name, vorname, date) "
                + " SELECT p.id, p.name, p.vorname, p.date FROM Person p "
                                + " WHERE  p.date = (select max(p2.date) FROM Person p2 "
                                + "    WHERE p.id = p2.id)";

        em.getTransaction().begin();
        em.createQuery(insertJpql).executeUpdate();
        em.getTransaction().commit();

    }
}
