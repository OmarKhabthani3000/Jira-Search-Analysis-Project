package hibernate.bug;

import hibernate.bug.model.Address;
import hibernate.bug.model.Person;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Address adress = new Address();
        adress.setStrasse("MyStrasse");
        adress.setPlz("11235");

        List<Address> adressList = new ArrayList<Address>();
        adressList.add(adress);

        Calendar date = Calendar.getInstance();
        date.set(2012, 0, 1);
        Person person = new Person("Nachname1", "Vorname1", adressList, date.getTime());

        em.persist(adress);
        em.persist(person);

        Calendar date2 = Calendar.getInstance();
        date2.set(2013, 1, 1);
        Person person2 = new Person("Nachname2", "Vorname2", adressList, date2.getTime());
        em.persist(person2);

        Calendar date3 = Calendar.getInstance();
        date3.set(2014, 2, 1);
        Person person3 = new Person("Nachname3", "Vorname3", adressList, date3.getTime());
        em.persist(person3);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testIssue() throws Throwable {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        
        tx.begin();
        
        try {
            int updated = em.createQuery(
                    "INSERT INTO SecondPerson (id, name, vorname, date) "
                    + " SELECT p.id, p.name, p.vorname, p.date FROM Person p "
                    + " WHERE p.date = ("
                            + "SELECT MAX(p2.date) FROM Person p2 WHERE p.id = p2.id)")
                    .executeUpdate();
            Assert.assertEquals(3, updated);
            tx.commit();
        } catch (Throwable t) {
            tx.rollback();
            throw t;
        }

        em.close();
    }
	
}
