package com.jpatest;

import org.springframework.stereotype.Repository;

@Repository
public interface StudentRepository {

	Student findById(Long id);

	Student findById(StudentId id);
}
