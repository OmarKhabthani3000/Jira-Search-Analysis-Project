package com.jpatest;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.transaction.annotation.Transactional;

@Transactional(readOnly = true)
public class StudentRepositoryImpl implements StudentRepository {

	@PersistenceContext(unitName = "pu")
    EntityManager entityManager;
	
	@Override
	public Student findById(Long id) {
		return entityManager.find(Student.class, id);
	}
	
	@Override
	public Student findById(StudentId id) {
		return entityManager.find(Student.class, id);
	}

}
