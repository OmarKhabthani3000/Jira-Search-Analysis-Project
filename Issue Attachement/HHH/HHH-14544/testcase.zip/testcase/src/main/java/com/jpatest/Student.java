package com.jpatest;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
public class Student {
	//@Id
	//@GeneratedValue
	//private Long id;
	
	@EmbeddedId
    private StudentId id;
	
	private String name;
	private String passportNumber;
	
	@ManyToOne(optional = true, targetEntity = Dorm.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "dorm_id", nullable = true)
	@Fetch(FetchMode.SELECT)
    private IDorm dorm;
	
    @Column(name = "dorm_id", nullable = true, insertable = false, updatable = false)
    private Long dormId;
    
    @OneToMany(mappedBy = "student", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @Fetch(FetchMode.JOIN)
    private Set<Purpose> purposes = new HashSet<>();

    @OneToMany(mappedBy = "student", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    @Fetch(FetchMode.JOIN)
    private Set<Attribute> attributes = new HashSet<>();
    
	public Student() {
		super();
	}

	public Student(Long id, String name, String passportNumber, Dorm dorm) {
		super();
		this.id = new StudentId(new BigDecimal(id), id);
		this.name = name;
		this.passportNumber = passportNumber;
		this.dorm = dorm;
		this.dormId = dorm.getId();
	}

	public Student(String name, String passportNumber, Dorm dorm) {
		super();
		this.name = name;
		this.passportNumber = passportNumber;
		this.dorm = dorm;
		this.dormId = dorm.getId();
	}

	public StudentId getId() {
		return id;
	}

	public void setId(StudentId id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	@Override
	public String toString() {
		return String.format("Student [id=%s, name=%s, passportNumber=%s]", id, name, passportNumber);
	}

}
