package com.jpatest;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
public class Purpose {

	@Id
    @Column(name = "PURPOSE_ID", unique = true, nullable = false)
    private Long id;

    @ManyToOne(optional = true, targetEntity = Student.class, fetch = FetchType.LAZY)
    @JoinColumns({
            @JoinColumn(name = "STUDENT_ID", referencedColumnName = "STUDENT_ID"),
            @JoinColumn(name = "STUDENT_PARTITION", referencedColumnName = "STUDENT_PARTITION") })
    @Fetch(FetchMode.SELECT)
    private Student student;

    @Column(name = "PURPOSE_CODE")
    private String purposeCode;

    public Purpose(Student student,
            String purpose)
    {
        this.student = student;
        this.purposeCode = purpose;
    }

    // For ORM.
    protected Purpose() {}

    public String getPurposeCode()
    {
        return purposeCode;
    }

    public Long getId()
    {
        return id;
    }

    @Override
    public int hashCode()
    {
        return new HashCodeBuilder().append(purposeCode.hashCode()).append(student.hashCode()).toHashCode();
    }

    @Override
    public boolean equals(Object obj)
    {
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        final Purpose other = (Purpose) obj;
        return new EqualsBuilder().append(purposeCode, other.purposeCode)
            .append(student, other.student).isEquals();
    }
}
