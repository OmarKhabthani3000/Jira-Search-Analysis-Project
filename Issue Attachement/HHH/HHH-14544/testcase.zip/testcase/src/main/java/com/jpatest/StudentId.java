package com.jpatest;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class StudentId implements Serializable
{
	private static final long serialVersionUID = -4979335337106343858L;

	@Column(name = "student_id", nullable = false)
    private BigDecimal id;

    @Column(name = "student_partition", nullable = false)
    private Long partition;

    public StudentId()
    {}
    
    public StudentId(BigDecimal id, Long partition)
    {
        this.id = id;
        this.partition = partition;
    }
    
    
}
