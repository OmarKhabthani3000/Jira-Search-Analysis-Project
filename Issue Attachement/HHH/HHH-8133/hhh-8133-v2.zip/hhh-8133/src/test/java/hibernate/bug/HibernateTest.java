package hibernate.bug;

import hibernate.bug.model.Car;
import hibernate.bug.model.Customer;
import java.util.List;
import java.util.Properties;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test", createProperties());
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Customer c1 = new Customer("c1");
        Customer c2 = new Customer("c2");
        
        Car car1 = new Car("A5", c1, "ABC123");
        Car car2 = new Car("S5", c2, "DEF456");
        
        em.persist(c1);
        em.persist(c2);
        em.persist(car1);
        em.persist(car2);
        
        em.flush();
        tx.commit();
        em.close();
    }

    private Properties createProperties() {
        Properties p = new Properties();
//        p.put("javax.persistence.jdbc.url", "jdbc:postgresql://localhost:5432");
//        p.put("javax.persistence.jdbc.user", "postgres");
//        p.put("javax.persistence.jdbc.password", "postgres");
//        p.put("javax.persistence.jdbc.driver", "org.postgresql.Driver");
        
//        p.put("javax.persistence.jdbc.url", "jdbc:db2://localhost:50000/test");
//        p.put("javax.persistence.jdbc.user", "db2admin");
//        p.put("javax.persistence.jdbc.password", "db2admin");
//        p.put("javax.persistence.jdbc.driver", "com.ibm.db2.jcc.DB2Driver");
        
        return p;
    }

	// This test will succeed as no ORDER BY is specified. But the query is still incorrect
    @Test
    public void testIssueWithoutOrderBy() {
        EntityManager em = emf.createEntityManager();
        
        List<Customer> list = em.createQuery("SELECT DISTINCT c.customer FROM Car c WHERE lower(c.customer.name) = 'c1'", Customer.class)
                .getResultList();
        Assert.assertEquals("c1", list.get(0).getName());

        em.close();
    }
	
	// This test will fail because ORDER BY is used and the query is not correct
	//  > only if DISTINCT is used
    @Test
    public void testIssueWithOrderBy() {
        EntityManager em = emf.createEntityManager();
        
        List<Customer> list = em.createQuery("SELECT DISTINCT c.customer FROM Car c WHERE lower(c.customer.name) = 'c1' ORDER BY c.customer.name", Customer.class)
                .getResultList();
        Assert.assertEquals("c1", list.get(0).getName());

        em.close();
    }
	
	// This test will succeed
    @Test
    public void testIssueWithExplicitJoin() {
        EntityManager em = emf.createEntityManager();
        
        List<Customer> list = em.createQuery("SELECT DISTINCT cu FROM Car c INNER JOIN c.customer cu WHERE lower(cu.name) = 'c1' ORDER BY cu.name", Customer.class)
                .getResultList();
        Assert.assertEquals("c1", list.get(0).getName());

        em.close();
    }
	
}
