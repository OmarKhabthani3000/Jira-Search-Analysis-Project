package org.hibernate.bugs;

import org.hibernate.custom.converter.LocalDateAttributeConverter;
import org.hibernate.type.descriptor.WrapperOptions;
import org.hibernate.type.descriptor.java.LocalDateJavaDescriptor;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.sql.Date;
import java.time.LocalDate;
import java.util.TimeZone;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;


@RunWith(MockitoJUnitRunner.class)
public class LocalDateJavaDescriptorTest {
    @InjectMocks
    private LocalDateJavaDescriptor localDateJavaDescriptor;

    @InjectMocks
    private LocalDateAttributeConverter localDateAttributeConverter;

    @Mock
    private WrapperOptions wrapperOptions;

    private Date producerDate;

    @Before
    public void setupProducerDate() {
        // The producer (MySQL) Berlin and returns 1980-01-01
        TimeZone.setDefault(TimeZone.getTimeZone("Europe/Berlin"));
        producerDate = Date.valueOf("1980-01-01");

        // The consumer is in GMT
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
    }

    @Test
    public void descriptorShouldConvertToLocalDate() {
        LocalDate convertedLocalDate = localDateJavaDescriptor.wrap(producerDate, wrapperOptions);

        assertThat(convertedLocalDate.toString(), is("1980-01-01"));
    }

    @Test
    public void customConverterShouldConvertToLocalDate() {
        LocalDate convertedLocalDate = localDateAttributeConverter.convertToEntityAttribute(producerDate);

        assertThat(convertedLocalDate.toString(), is("1980-01-01"));
    }
}
