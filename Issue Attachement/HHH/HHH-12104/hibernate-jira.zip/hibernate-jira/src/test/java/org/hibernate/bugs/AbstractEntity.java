package org.hibernate.bugs;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class AbstractEntity {

    private boolean deleted;

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

}
