package hib5test;

import hib5test.dao.PtxRepository;
import hib5test.domain.Input;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Hib5testApplication.class)
@WebAppConfiguration
public class Hib5testApplicationTests {

  @Autowired
  Hib5Service hibService;

  @Autowired
  PtxRepository ptxRepository;

  public void out(String s) {
    System.out.println(s);
  }

  @Test
  public void hib5test() {
    hibService.createPtx("one");
    List<Input> inputs = ptxRepository.findInputs("one");
    out(Arrays.toString(inputs.toArray()));
  }

}
