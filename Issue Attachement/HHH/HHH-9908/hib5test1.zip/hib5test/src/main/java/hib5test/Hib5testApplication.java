package hib5test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hib5testApplication {

    public static void main(String[] args) {
        SpringApplication.run(Hib5testApplication.class, args);
    }
}
