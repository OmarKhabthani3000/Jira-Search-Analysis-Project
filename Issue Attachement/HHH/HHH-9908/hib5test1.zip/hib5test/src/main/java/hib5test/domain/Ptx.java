package hib5test.domain;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Table;

@Entity
@Table(name = "ptx")
public class Ptx {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Integer id;

  private String x;

  @OrderColumn
  @ManyToMany(cascade = {CascadeType.MERGE, CascadeType.PERSIST}, fetch = FetchType.EAGER)
  private List<Input> inputs1;

  @OrderColumn
  @ManyToMany(cascade = {CascadeType.MERGE, CascadeType.PERSIST}, fetch = FetchType.EAGER)
  private List<Input> inputs2;

  public Ptx() {
  }

  public Ptx(String x, List<Input> inputs1) {
    this.x = x;
    this.inputs1 = inputs1;
  }

  @Override
  public String toString() {
    return "Ptx[" + id + "]";
  }

}
