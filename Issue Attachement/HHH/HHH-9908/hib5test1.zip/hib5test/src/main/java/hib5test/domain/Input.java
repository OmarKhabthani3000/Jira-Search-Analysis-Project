package hib5test.domain;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Alessandro Polverini <alex@nibbles.it>
 */
@Entity
@Table(name = "input")
public class Input implements Serializable {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Integer id;

//  @ManyToMany(mappedBy = "inputs1", fetch = FetchType.LAZY)
//  private List<Ptx> ptxs1;

//  @ManyToMany(mappedBy = "inputs2", fetch = FetchType.LAZY)
//  private List<Ptx> ptxs2;

  public Input() {
  }

  @Override
  public String toString() {
    return "Input[" + id + "]";
  }

}
