package hib5test;

import hib5test.dao.InputRepository;
import hib5test.dao.PtxRepository;
import hib5test.domain.Input;
import hib5test.domain.Ptx;
import java.util.LinkedList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class Hib5Service {

  @Autowired
  PtxRepository ptxRepository;

  @Autowired
  InputRepository inputRepository;

  public Ptx createPtx(String x) {
    Input i1 = new Input();
    Input i2 = new Input();
    List<Input> l = new LinkedList<>();
    l.add(i1);
    l.add(i2);
    return ptxRepository.save(new Ptx(x, l));
  }
}
