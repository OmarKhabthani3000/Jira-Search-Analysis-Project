package br.com.teste;

import javax.persistence.Entity;

import org.hibernate.envers.Audited;

@Entity
public class MallStore extends Store {

	@Audited
	private String mallName;

	public void setMallName(String mallName) {
		this.mallName = mallName;
	}

	public String getMallName() {
		return mallName;
	}
}
