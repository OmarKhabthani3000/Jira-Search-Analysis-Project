package br.com.teste;

import javax.persistence.Entity;

import org.hibernate.envers.Audited;

@Entity
public class StreetStore extends Store {

	@Audited
	private Boolean restrictedStreet;

	public void setRestrictedStreet(Boolean restrictedStreet) {
		this.restrictedStreet = restrictedStreet;
	}

	public Boolean getRestrictedStreet() {
		return restrictedStreet;
	}

}
