package br.com.teste;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import org.hibernate.envers.Audited;


@Entity
public class Mailman {

    @Id
    @GeneratedValue
    private int id;

    @Audited
    private Integer register;
    
	@Audited
	@ManyToMany(
			cascade = {CascadeType.PERSIST, CascadeType.MERGE},
			mappedBy = "mailmen",
			targetEntity = Address.class
	)
	private Collection<Address> addresses;
	
	@Audited
	@Embedded
	private Bag letterBag;
	
	public void setAddresses(Collection<Address> addresses) {
		this.addresses = addresses;
	}

	public Collection<Address> getAddresses() {
		return addresses;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setRegister(Integer register) {
		this.register = register;
	}

	public Integer getRegister() {
		return register;
	}

	public void setLetterBag(Bag letterBag) {
		this.letterBag = letterBag;
	}

	public Bag getLetterBag() {
		return letterBag;
	}


}
