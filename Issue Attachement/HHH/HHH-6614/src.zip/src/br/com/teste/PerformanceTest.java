package br.com.teste;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PerformanceTest {

	private EntityManager entityManager;
	private EntityManagerFactory emf;
	private int MAX_EDITIONS = 1000000;

	@Before public void setUp() { 
		Map<String, String> configurationOverrides = new HashMap<String, String>();
		emf = Persistence.createEntityManagerFactory("jpa", configurationOverrides);
		entityManager = emf.createEntityManager();
	}

	@After public void tearDown() {
		entityManager.close();
		emf.close();
	}

	// 6 hours
	@Test public void tooSlowEditTest() {
		Mailman mm = new Mailman();
		mm.setRegister(64737);
		entityManager.persist(mm);

		for(int i = 1; i <= MAX_EDITIONS; i++) { 
			entityManager.getTransaction().begin();
			mm.setRegister(i);
			entityManager.getTransaction().commit();
		}
	}

	// 30 minutes
	@Test public void fasterEditTest() {
		Mailman mm = new Mailman();
		mm.setRegister(64737);
		entityManager.persist(mm);

		for(int i = 1; i <= MAX_EDITIONS; i++) { 
			entityManager.getTransaction().begin();
			entityManager.find(Mailman.class, mm.getId()).setRegister(i);
			entityManager.getTransaction().commit();
			entityManager.clear();		
		}
	}


}
