package br.com.teste;

import javax.persistence.Embeddable;

import org.hibernate.envers.Audited;

@Embeddable
public class Bag {

	@Audited
	private Integer volume;

	public Bag() {
		super();
	}

	public Bag(Integer volume) {
		super();
		this.volume = volume;
	}

	public void setVolume(Integer volume) {
		this.volume = volume;
	}

	public Integer getVolume() {
		return volume;
	}
}
