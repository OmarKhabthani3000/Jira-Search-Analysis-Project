package br.com.teste;

import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;

@Entity
public class Pet {
    @Id
    @GeneratedValue
    private int id;
    
    @Audited
    private String name;

    @Audited
    @ManyToOne
    private Address address;
    
    @Audited
    @ElementCollection
    private Set<String> flees;
    
	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

	public void setFlees(Set<String> flees) {
		this.flees = flees;
	}

	public Set<String> getFlees() {
		return flees;
	}

}
