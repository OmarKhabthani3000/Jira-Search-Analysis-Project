package org.hibernate.bugs.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name="base")
@Inheritance(strategy = InheritanceType.JOINED)
public class BaseEntity implements Serializable
{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	protected long id;

	@Column
	protected String name;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Column
	protected String message;
	
	@Override
	public int hashCode()
	{
		//@formatter:off
			return new HashCodeBuilder()
				.append(this.message)
				.append(this.name)
					.toHashCode();
		//@formatter:on
	}

	@Override
	public boolean equals(Object obj)
	{
		if (obj == null)
		{
			return false;
		}
		if (obj == this)
		{
			return true;
		}
		if (obj.getClass() != getClass())
		{
			return false;
		}

		final BaseEntity other = (BaseEntity) obj;

		//@formatter:off
		return new EqualsBuilder()
			.append(this.message, other.message)
			.append(this.name, other.name)
				.isEquals();
		//@formatter:on
	}
}

