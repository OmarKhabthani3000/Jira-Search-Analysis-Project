package org.hibernate.bugs;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.hibernate.bugs.entities.BaseEntity;
import org.hibernate.bugs.entities.ChildEntity;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		String matcher = "help";
		ChildEntity child1 = new ChildEntity();
		child1.setMessage("message $!{" + matcher + "}");
		child1.setName("ABC");
		child1.setSubject("DEF");
		entityManager.merge(child1);
		
		List<BaseEntity> list1 = getEntities(matcher, entityManager);
		assertNotNull(list1);
		assertEquals(1, list1.size());
		assertEquals(child1, list1.get(0));
		
		
		ChildEntity child2 = new ChildEntity();
		child2.setMessage("XYZ");
		child2.setName("UVW");
		child2.setSubject("subject $!{" + matcher + "}");
		entityManager.merge(child2);

		List<BaseEntity> list2 = getEntities(matcher, entityManager);
		assertNotNull(list2);
		assertEquals(2, list2.size());
		
		
		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
	private List<BaseEntity> getEntities(String matcher, EntityManager entityManager)
	{
		StringBuilder sb = new StringBuilder("select distinct a from BaseEntity a ");
		sb.append("where a.message like :matcher ");
		sb.append("or a in (from ChildEntity e where e.subject like :matcher) ");
		
		TypedQuery<BaseEntity> query = entityManager.createQuery(sb.toString(),
				BaseEntity.class);
		query.setParameter("matcher", "%" + matcher + "%");
		
		return query.getResultList();
	}
}
