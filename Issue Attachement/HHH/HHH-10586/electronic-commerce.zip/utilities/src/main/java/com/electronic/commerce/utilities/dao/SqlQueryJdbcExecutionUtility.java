package com.electronic.commerce.utilities.dao;

import org.springframework.jdbc.support.JdbcUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author Arthur Kharkivsky
 * @since 26.02.2016
 */
public class SqlQueryJdbcExecutionUtility {
    public static void execute(String query, Connection connection, Object... queryArgumentValues) throws SQLException {
        execute(String.format(query, queryArgumentValues), connection);
    }

    public static void execute(String query, Connection connection) throws SQLException {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(query);
            statement.executeUpdate();
        } finally {
            JdbcUtils.closeStatement(statement);
        }
    }

    public static boolean isExists(String query, Connection connection, Object... queryArgumentValues) throws SQLException {
        return isExists(String.format(query, queryArgumentValues), connection);
    }

    public static boolean isExists(String query, Connection connection) throws SQLException {
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();
            if (resultSet.next()) {

                return true;
            }
        } finally {
            JdbcUtils.closeResultSet(resultSet);
            JdbcUtils.closeStatement(statement);
        }

        return false;
    }
}
