package com.electronic.commerce.utilities.dao;

import org.springframework.jdbc.datasource.DriverManagerDataSource;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * @author Arthur Kharkivsky
 * @since 26.02.2016
 */
public class ConnectionUtility {
    public static Connection getNewConnectionIfExistedIsNull(Connection connectionToCheck,
                                                             DriverManagerDataSource driverManagerDataSource) throws SQLException {
        if (connectionToCheck != null) {

            return connectionToCheck;
        }

        return driverManagerDataSource.getConnection();
    }
}
