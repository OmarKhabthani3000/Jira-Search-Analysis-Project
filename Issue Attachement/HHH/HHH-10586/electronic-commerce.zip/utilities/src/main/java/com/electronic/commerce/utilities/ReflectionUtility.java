package com.electronic.commerce.utilities;

import java.lang.reflect.Field;

/**
 * @author Arthur Kharkivsky
 * @since 28.02.2016
 */
@SuppressWarnings("unused")
public class ReflectionUtility {
    @SuppressWarnings("unused")
    public static Object getFieldValue(Object targetObject, String fieldName) throws NoSuchFieldException, IllegalAccessException {
        return getAccessibleFieldRecursive(targetObject, fieldName).get(targetObject);
    }

    @SuppressWarnings("unused")
    public static void setFieldValue(Object targetObject, String fieldName, Object fieldValue) throws NoSuchFieldException, IllegalAccessException {
        getAccessibleFieldRecursive(targetObject, fieldName).set(targetObject, fieldValue);
    }

    public static Field getAccessibleFieldRecursive(Object targetObject, String fieldName) throws NoSuchFieldException {
        return getAccessibleFieldRecursive(targetObject.getClass(), fieldName);
    }

    public static Field getAccessibleFieldRecursive(Class targetClass, String fieldName) throws NoSuchFieldException {
        Field result;
        try {
            result = targetClass.getDeclaredField(fieldName);
            result.setAccessible(true);
        } catch (NoSuchFieldException e) {
            Class superClass = targetClass.getSuperclass();
            if (superClass.equals(Object.class)) {
                throw e;
            } else {
                return getAccessibleFieldRecursive(superClass, fieldName);
            }
        }

        return result;
    }
}
