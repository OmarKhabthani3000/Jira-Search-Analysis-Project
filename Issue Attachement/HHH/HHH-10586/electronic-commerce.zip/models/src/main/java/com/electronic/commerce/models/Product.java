package com.electronic.commerce.models;

import com.electronic.commerce.models.base.NamedModel;

import java.sql.Date;
import java.util.List;

import static java.util.Collections.addAll;

/**
 * @author Arthur Victorovych Kharkivsky
 */
public class Product extends NamedModel {
    private List<Review> reviews;
    @SuppressWarnings("unused")
    private List<String> images;
    private long numberOfRates;
    private String description;
    private Category category;
    private Date creationDate;
    private boolean isInStock;
    private NamedModel vendor;
    @SuppressWarnings("all")
    private double score;
    private double price;
    private long rate;

    public Product(long id) {
        this.id = id;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    @SuppressWarnings("unused")
    public long getRate() {
        return rate;
    }

    @SuppressWarnings("unused")
    public void setRate(long rate) {
        this.rate = rate;
    }

    @SuppressWarnings("unused")
    public String getDescription() {
        return description;
    }

    @SuppressWarnings("unused")
    public void setDescription(String description) {
        this.description = description;
    }

    @SuppressWarnings("unused")
    public void addReviews(List<Review> reviews) {
        this.reviews = reviews;
    }

    @SuppressWarnings("unused")
    public double getPrice() {
        return price;
    }

    @SuppressWarnings("unused")
    public void setPrice(double price) {
        this.price = price;
    }

    @SuppressWarnings("unused")
    public List<String> getImages() {
        return images;
    }

    @SuppressWarnings("unused")
    public void setImages(List<String> images) {
        this.images = images;
    }

    @SuppressWarnings("unused")
    public void addImages(String... images) {
        addAll(this.images, images);
    }

    @SuppressWarnings("unused")
    public Date getCreationDate() {
        return creationDate;
    }

    @SuppressWarnings("unused")
    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    @SuppressWarnings("unused")
    public boolean isInStock() {
        return isInStock;
    }

    @SuppressWarnings("unused")
    public void setIsInStock(boolean isInStock) {
        this.isInStock = isInStock;
    }

    @SuppressWarnings("unused")
    public NamedModel getVendor() {
        return vendor;
    }

    @SuppressWarnings("unused")
    public void setVendor(NamedModel vendor) {
        this.vendor = vendor;
    }

    @SuppressWarnings("unused")
    public void setScore(long rate, long numberOfRates) {
        score = numberOfRates != 0 ? rate / numberOfRates : 0;
        this.numberOfRates = numberOfRates;
        this.rate = rate;
    }

    @SuppressWarnings("unused")
    public long getNumberOfRates() {
        return numberOfRates;
    }

    @SuppressWarnings("unused")
    public void setNumberOfRates(long numberOfRates) {
        this.numberOfRates = numberOfRates;
    }

    @SuppressWarnings("unused")
    public List<Review> getReviews() {
        return reviews;
    }

    @SuppressWarnings("unused")
    public void setReviews(List<Review> reviews) {
        this.reviews = reviews;
    }
}
