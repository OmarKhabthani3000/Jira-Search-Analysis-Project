package com.electronic.commerce.models;

import com.electronic.commerce.models.base.NamedModel;

/**
 * User: Arthur Victorovych Kharkivsky
 * Date: 29.11.13
 * Time: 23:21
 */
public class Review extends NamedModel {
    private User user;
    private int mark;
    private int positiveMarks;
    private int negativeMarks;
    private String positiveSides;
    private String negativeSides;
    private String review;
    private long productId;
    private long parentId;

    @SuppressWarnings("unused")
    public User getUser() {
        return user;
    }

    @SuppressWarnings("unused")
    public void setUser(User user) {
        this.user = user;
    }

    @SuppressWarnings("unused")
    public String getReview() {
        return review;
    }

    @SuppressWarnings("unused")
    public void setReview(String review) {
        this.review = review;
    }

    @SuppressWarnings("unused")
    public String getPositiveSides() {
        return positiveSides;
    }

    @SuppressWarnings("unused")
    public void setPositiveSides(String positiveSides) {
        this.positiveSides = positiveSides;
    }

    @SuppressWarnings("unused")
    public String getNegativeSides() {
        return negativeSides;
    }

    @SuppressWarnings("unused")
    public void setNegativeSides(String negativeSides) {
        this.negativeSides = negativeSides;
    }

    @SuppressWarnings("unused")
    public long getProductId() {
        return productId;
    }

    @SuppressWarnings("unused")
    public void setProductId(long productId) {
        this.productId = productId;
    }

    @SuppressWarnings("unused")
    public int getMark() {
        return mark;
    }

    @SuppressWarnings("unused")
    public void setMark(int mark) {
        this.mark = mark;
    }

    @SuppressWarnings("unused")
    public long getParentId() {
        return parentId;
    }

    @SuppressWarnings("unused")
    public void setParentId(long parentId) {
        this.parentId = parentId;
    }

    @SuppressWarnings("unused")
    public int getNegativeMarks() {
        return negativeMarks;
    }

    @SuppressWarnings("unused")
    public void setNegativeMarks(int negativeMarks) {
        this.negativeMarks = negativeMarks;
    }

    @SuppressWarnings("unused")
    public int getPositiveMarks() {
        return positiveMarks;
    }

    @SuppressWarnings("unused")
    public void setPositiveMarks(int positiveMarks) {
        this.positiveMarks = positiveMarks;
    }
}
