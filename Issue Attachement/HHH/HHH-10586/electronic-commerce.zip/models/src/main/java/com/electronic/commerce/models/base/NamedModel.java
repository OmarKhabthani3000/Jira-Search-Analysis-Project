package com.electronic.commerce.models.base;

import javax.persistence.MappedSuperclass;

/**
 * @author Arthur Kharkivsky
 * @since 23.02.2016
 */
@MappedSuperclass
public class NamedModel {
    protected long id;
    protected String name;

    @SuppressWarnings("unused")
    public NamedModel(long id) {
        this.id = id;
    }

    public NamedModel() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof NamedModel)) return false;

        NamedModel that = (NamedModel) o;

        return id == that.id && name.equals(that.name);

    }

    @Override
    public int hashCode() {
        int result = (int) (id ^ (id >>> 32));
        result = 31 * result + name.hashCode();

        return result;
    }
}
