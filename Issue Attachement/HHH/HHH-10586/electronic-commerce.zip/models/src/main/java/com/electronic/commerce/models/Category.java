package com.electronic.commerce.models;

import com.electronic.commerce.models.base.NamedModel;

import java.util.List;

/**
 * @author Arthur Victorovych Kharkivsky
 *         Time: 5:13 PM
 */
public class Category extends NamedModel {
    private String image;
    private long parentId;
    private List<Category> children;

    public Category(long id) {
        this.id = id;
    }

    public Category() {
    }

    @SuppressWarnings("unused")
    public String getImage() {
        return image;
    }

    @SuppressWarnings("unused")
    public void setImage(String image) {
        this.image = image;
    }

    public List<Category> getChildren() {
        return children;
    }

    @SuppressWarnings("unused")
    public void setChildren(List<Category> children) {
        this.children = children;
    }

    public long getParentId() {
        return parentId;
    }

    @SuppressWarnings("unused")
    public void setParentId(long parentId) {
        this.parentId = parentId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Category)) return false;
        if (!super.equals(o)) return false;

        Category category = (Category) o;

        return parentId == category.parentId
                && !(image != null ? !image.equals(category.image) : category.image != null);

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (int) (parentId ^ (parentId >>> 32));
        result = 31 * result + (image != null ? image.hashCode() : 0);

        return result;
    }
}
