package com.electronic.commerce.models;


import com.electronic.commerce.models.base.NamedModel;

import javax.persistence.Transient;
import java.sql.Date;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.List;

import static java.util.Collections.addAll;

/**
 * User: Arthur Victorovych Kharkivsky
 * Date: 26.10.13
 * Time: 13:52
 */
public class User extends NamedModel {
    @Transient
    protected List<Long> phones;
    @Transient
    @SuppressWarnings("all")
    private List<Product> favouriteProducts;
    @Transient
    private List<Product> products;
    @SuppressWarnings("unused")
    private int waitingForEmail;
    @Transient
    @SuppressWarnings("unused")
    private Date birthDate;
    private int cashless;
    @Transient
    private List<String> images;
    private String image;
    private String password;
    private String email;
    private long phone;

    @SuppressWarnings("unused")
    public Date getBirthDate() {
        return birthDate != null ? birthDate : new Date(new GregorianCalendar(1800, 0, 1).getTimeInMillis());
    }

    @SuppressWarnings("unused")
    public int getWaitingForEmail() {
        return waitingForEmail;
    }

    @SuppressWarnings("unused")
    public int getCashless() {
        return cashless;
    }

    @SuppressWarnings("unused")
    public void setCashless(boolean cashless) {
        this.cashless = cashless ? 1 : 0;
    }

    @SuppressWarnings("unused")
    public void addFavouriteServices(List<Product> favouriteServices) {
        this.favouriteProducts = favouriteServices;
    }

    @SuppressWarnings("unused")
    public List<Product> getProducts() {
        return products;
    }

    @SuppressWarnings("unused")
    public void setProducts(List<Product> products) {
        this.products = products;
    }

    @SuppressWarnings("unused")
    public long getPhone() {
        return this.phone != 0 ? phone : phones != null && phones.size() > 0 ? phones.get(0) : 0;
    }

    @SuppressWarnings("unused")
    public void setPhone(long phone) {
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @SuppressWarnings("unused")
    public String getPassword() {
        return password;
    }

    @SuppressWarnings("unused")
    public void setPassword(String password) {
        this.password = password;
    }

    @SuppressWarnings("unused")
    public String getEmail() {
        return email;
    }

    @SuppressWarnings("unused")
    public void setEmail(String email) {
        this.email = email;
    }

    @SuppressWarnings("unused")
    public void addPhone(Long... phones) {
        addAll(this.phones, phones);
    }

    @SuppressWarnings("unused")
    public List<String> getImages() {
        return images;
    }

    @SuppressWarnings("unused")
    public void setImages(List<String> images) {
        this.images = images;
    }

    @SuppressWarnings("unused")
    public void addPhoto(String... photos) {
        Collections.addAll(this.images, photos);
    }

    @SuppressWarnings("unused")
    public String getImage() {
        return image != null ? image : images != null && images.size() > 0 ? images.get(0) : "pic/avatar.png";
    }

    @SuppressWarnings("unused")
    public void setImage(String image) {
        this.image = image;
    }
}