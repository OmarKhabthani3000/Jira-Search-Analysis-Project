package com.electronic.commerce.models;

/**
 * User: Arthur Victorovych Kharkivsky
 * Date: 12/3/13
 * Time: 1:30 PM
 */
@SuppressWarnings("unused")
public class MarketingStatus {
    private String description;
    private String bigImage;
    private String image;

    @SuppressWarnings("unused")
    public String getBigImage() {
        return bigImage;
    }

    @SuppressWarnings("unused")
    public void setBigImage(String bigImage) {
        this.bigImage = bigImage;
    }

    @SuppressWarnings("unused")
    public String getDescription() {
        return description;
    }

    @SuppressWarnings("unused")
    public void setDescription(String description) {
        this.description = description;
    }

    @SuppressWarnings("unused")
    public String getImage() {
        return image;
    }

    @SuppressWarnings("unused")
    public void setImage(String image) {
        this.image = image;
    }
}
