package com.electronic.commerce.models;

import com.openpojo.reflection.PojoClass;
import com.openpojo.reflection.filters.FilterPackageInfo;
import com.openpojo.reflection.impl.PojoClassFactory;
import com.openpojo.validation.PojoValidator;
import com.openpojo.validation.rule.impl.NoPublicFieldsRule;
import com.openpojo.validation.test.impl.GetterTester;
import com.openpojo.validation.test.impl.SetterTester;
import org.junit.Test;

public class ModelsTest {

    @Test
    public void models() throws Exception {
        final PojoValidator pojoValidator = new PojoValidator();
        addTesters(pojoValidator);
        addRules(pojoValidator);

        for (PojoClass pojoClass : PojoClassFactory.getPojoClasses(ModelsTest.class.getPackage().getName(),
                new FilterPackageInfo())) {
            if (!pojoClass.getName().endsWith("Test")) {
                pojoValidator.runValidation(pojoClass);
            }
        }
    }

    private void addTesters(PojoValidator pojoValidator) {
        pojoValidator.addTester(new SetterTester());
        pojoValidator.addTester(new GetterTester());
    }

    private void addRules(PojoValidator pojoValidator) {
        pojoValidator.addRule(new NoPublicFieldsRule());
    }
}
