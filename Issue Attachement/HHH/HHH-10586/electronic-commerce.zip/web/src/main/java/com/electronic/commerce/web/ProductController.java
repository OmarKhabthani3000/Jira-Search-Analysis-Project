package com.electronic.commerce.web;

import com.electronic.commerce.dao.ProductDAO;
import com.electronic.commerce.models.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

/**
 * @author Arthur Victorovych Kharkivsky
 */
@Controller
@RequestMapping("/product")
public class ProductController {

    @Autowired
    @Qualifier("productMySqlHibernateDAO")
    protected ProductDAO<Product> productDAO;

    @RequestMapping(value = "/add.do", method = POST)
    public void add(@RequestBody Product requestProduct) throws Exception {
        productDAO.save(requestProduct);
    }

    @RequestMapping(value = "/delete/{id}.do", method = GET)
    public void delete(@PathVariable int id) throws Exception {
        productDAO.delete(new Product(id));
    }

    @RequestMapping(value = "/update.do", method = POST)
    public void update(@RequestBody Product product) throws Exception {
        productDAO.update(product);
    }

    @ResponseBody
    @RequestMapping(value = "/getByCategoryId/{id}/{page}/{limit}.do", method = POST)
    public List<Product> getByCategoryId(@PathVariable int id, @PathVariable int page, @PathVariable int limit)
            throws Exception {
        return productDAO.getByCategoryId(id, page, limit);
    }
}
