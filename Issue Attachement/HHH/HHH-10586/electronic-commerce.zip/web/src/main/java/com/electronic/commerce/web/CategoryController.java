package com.electronic.commerce.web;

import com.electronic.commerce.dao.CategoryDAO;
import com.electronic.commerce.models.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

/**
 * @author Arthur Victorovych Kharkivsky
 */
@Controller
@RequestMapping("/category")
public class CategoryController {
    @Autowired
    @Qualifier("categorySqlHibernateDAO")
    private CategoryDAO<Category> categoryDAO;

    @RequestMapping(value = "/save.do", method = POST)
    public void add(@RequestBody Category category) throws Exception {
        categoryDAO.save(category);
    }

    @RequestMapping(value = "/delete/{categoryId}.do", method = GET)
    public void delete(@PathVariable int categoryId) throws Exception {
        categoryDAO.delete(new Category(categoryId));
    }

    @RequestMapping(value = "/update.do", method = POST)
    public void update(@RequestBody Category category) throws Exception {
        categoryDAO.update(category);
    }

    @ResponseBody
    @RequestMapping(value = "/get/{parentId}.do", method = GET)
    public List<Category> get(@PathVariable int parentId) throws Exception {
        return categoryDAO.getByParentId(parentId);
    }

    @ResponseBody
    @RequestMapping(value = "/getById/{id}.do", method = GET)
    public Category getById(@PathVariable int id) throws Exception {
        return categoryDAO.getById(id);
    }
}
