$(function () {
    $('#enterEmail').html('<br/>' + localization.enterEmail + '<br/><br/>');
    $('#send').html('<a class="button" href="javascript:void(0)" id="sendLink">' + localization.send + '</a>');
    if (saved('mailSent') === 'true') {
        $('#searchResult').html(localization.emailHasBeenSent);
        saved('maleSent', '');
    }
    var email = $('#registrationEmail');
    $('#sendLink').on('click', function () {
        if (email.val() === '') {
            tooltip(localization.emailNotEntered, 'registrationEmail');
        } else {
            function sendEmail() {
                GET('mail/send/' + email.val(), function (data) {
                    if (data === 'notSent') {
                        tooltip(localization.emailNotRegistered, 'registrationEmail');
                        saved('maleSent', '');
                    } else {
                        save('mailSent', 'true');
                        go();
                    }
                }, 'string');
            }

            sendEmail();
        }
    })
});