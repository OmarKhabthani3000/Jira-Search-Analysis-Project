var $services;
var services;
var leftCentralUl;
var rightCentralUl;
$(function () {
    $services = $('#services');
    leftCentralUl = $('#leftCentralUl');
    rightCentralUl = $('#rightCentralUl');
    if (urlContains('main.html')) {
        var service = urlParameter('service');
        if (isEmpty(service) && services === undefined) {
            var categoryId = urlParameter('categoryId');
            clearCategoryUls();
            getCategories(categoryId == null ? 0 : categoryId);
        } else {
            var serviceNameField = $('#serviceName');
            serviceNameField.val(service);
            serviceNameField.focus();
            getServiceByName();
        }
    }
});
var categories;
function getCategories(parentId) {
    GET('category/get.do?parentId=' + parentId + '&page=' + urlParameter('page', 1) + '&perPage=' + urlParameter
        ('perPage', 10) + '&orderBy=' + urlParameter('orderBy', 'free') + '&order=' + urlParameter
        ('order', 'asc'), function (data) {
        categories = fromJSON(data);
        if (action !== 'favourite') {
            if (data.indexOf("parentId") != -1) {
                fillCategoriesTable(categories);
            } else {
                save('services', data);
                fillServicesTable(data);
            }
        }
    }, 'string')
}
/** @namespace item.picture */
function fillCategoriesTable(json) {
    if (!isEmpty(json)) {
        var counter = 0;
        var ul = leftCentralUl;
        leftCentralUl.html('');
        rightCentralUl.html('');
        categories = json = fromJSON(json);
        $.each(json, function (i, item) {
            function changeUl() {
                if (counter == categories.length / 2) {
                    ul = rightCentralUl;
                }
            }

            changeUl();
            ul.append('<li class="selected" id="categoryLi' + i + '" style="margin-bottom: 28px; width:345px"><a class=' +
                '"undecoratedLink" onclick="return clearCategoryUls()" href="' + formURL('main.html?categoryId=' +
                    item.id) + '"><img id="img' + item.id + '" style="width: 48px; height: 36px" src="pic/category/' +
                item.picture + '.png"/><div style="display: inline;color: white">_</div>' + item.name + '</a></li>');
            var li = $('#categoryLi' + i);
            var categoryPicture = $('#img' + item.id);
            li.hover(function () {
                if (i == categories.length / 2 || i - 1 == -1) {
                    li.css('margin-bottom', '24px');
                } else {
                    $('#categoryLi' + (i - 1)).css('margin-bottom', '26px');
                    li.css('margin-bottom', '26px');
                }
                categoryPicture.css('width', '52px');
                categoryPicture.css('height', '40px');
            });
            li.mouseleave(function () {
                if (i - 1 != -1) {
                    $('#categoryLi' + (i - 1)).css('margin-bottom', '28px');
                }
                categoryPicture.css('width', '48px');
                categoryPicture.css('height', '36px');
                li.css('margin-bottom', '28px');
            });
            counter++;
        });
    }
}
function clearCategoryUls() {
    clearTableWithSorterAndPager($services);
    $('#tablePagination').html('');
    rightCentralUl.html('');
    leftCentralUl.html('');
}





