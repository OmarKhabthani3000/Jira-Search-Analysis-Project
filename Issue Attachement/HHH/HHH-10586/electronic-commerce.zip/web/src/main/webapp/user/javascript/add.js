var $register;
$(function () {
    var phones = [];
    var $loginField = $('#loginField');
    var $emailField = $('#emailField');
    var $phoneField = $('#phoneField');
    var $password = $('#passwordField');
    var $retypedPassword = $('#retypedPasswordField');
    var emailValue = $emailField.val();

    function passwordsMatch(password, retypedPassword, htmlElement) {
        if (password !== retypedPassword) {
            showTooltip(htmlElement, localization.mismatch);

            return false;
        } else {

            return true;
        }
    }

    if (urlContains('user/add')) {
        addPhoneListener($phoneField);
        var phone = element('phoneField');
        $('#email').html(localization.email);
        $('#password').html(localization.password);
        $('#retypedPassword').html(localization.repeat);
        $register = $('#register');
        $('#login').html(localization.login);
        $('#phone').html(localization.phone);
        $('#photo').html(localization.photoLogo);
        $('#emailMe').html(localization.emailMe);
        $register.val(localization.register);
        tooltip($loginField, localization.nameMustBe);
        tooltip($emailField, localization.emailMustBe);
        tooltip($phoneField, localization.phoneMustBe);
        tooltip($password, localization.passwordMustBe);
        tooltip($retypedPassword, localization.mismatch);
        $register.on('click', function () {
            $loginField.tooltipster('content', localization.nameMustBe);
            $emailField.tooltipster('content', localization.emailMustBe);
            $phoneField.tooltipster('content', localization.phoneMustBe);
            $password.tooltipster('content', localization.passwordMustBe);
            var isProperLogin = tooltipIfNotProper($loginField, 32, 1);
            var isProperEmail = tooltipIfNotProper($emailField, 32, 5);
            var isProperPhone = tooltipIfNotProper($phoneField, 20, 10);
            var isProperPassword = tooltipIfNotProper($password, 32, 6);
            if (isProperEmail && isProperLogin && isProperPassword && isProperPhone
                && passwordsMatch($password.val(), $retypedPassword.val(), $retypedPassword)) {
                var waitingForEmail = element('emailMeCheckBox').value;
                waitingForEmail = waitingForEmail === 'on' ? 1 : 0;
                phones[0] = phone.value.replaceAll('-', '');
                var passwordHash = hMacSha512($password.val(), emailValue + $password.val().substr(0, 1));
                var requestUser = {
                    email: emailValue, password: passwordHash, name: $loginField.val(),
                    phones: phones, photos: null, waitingForEmail: waitingForEmail
                };
                POST('user/add', requestUser, function (data) {
                    if (data.indexOf('error=') != -1) {
                        if (data.indexOf('name') != -1) {
                            $loginField.tooltipster('content', localization.usedLogin);
                            showTooltip($loginField, localization.usedLogin);
                        }
                        if (data.indexOf('email') != -1) {
                            $emailField.tooltipster('content', localization.usedEmail);
                            showTooltip($emailField, localization.usedEmail);
                        }
                    } else if (data === 'usedPhone') {
                        $phoneField.tooltipster('content', localization.usedPhone);
                        showTooltip($phoneField, localization.usedPhone);
                    } else {
                        var photoPaths = [];
                        upload('file', 'utility/upload', photoPaths, 'pic/user.png');
                        requestUser.photos = photoPaths;
                        updateUser(requestUser);
                    }
                }, 'string');
            }
        })
    }
});
