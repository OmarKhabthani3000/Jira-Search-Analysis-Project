$(function () {
    var user = savedObject('user');
    if (action == null && !isEmpty(user) && !isEmpty(service.user) && user.id != service.user.id && isLogged()) {
        var review = {id: '', @author
        user, mark
    :
        0, review
    :
        '', serviceId
    :
        service.id
    }
    ;
    var $addReviewButtonTd = $('#addReviewTd');
    var $reviewStars = $('#reviewStars');
    var $reviewTd = $('#reviewTd');
    var reviews = $('#reviews');
    $reviewTd.html('<textarea style="font-size: 12pt; width: 500px" id="review" cols="80" rows="3"></textarea>');
    var reviewArea = $('#review');
    $reviewStars.html(formStars(0, true));
    $addReviewButtonTd.html('<input type="button" id="addReview">');
    var $addReviewButton = $('#addReview');
    $addReviewButton.val(localization.leaveReply);
    function addStarListeners() {
        for (var id = 1; id < 6; id++) {
            addStarListener(id);
        }
        function addStarListener(id) {
            var star = element('rateStar' + id);
            star.onclick = function () {
                $reviewStars.html(formStars(id, true));
                addStarListeners();
                review.mark = id;
            };
        }
    }

    function addAddReviewListener() {
        var user = review.user;
        $addReviewButton.on('click', function () {
            var reviewText = review.review = reviewArea.val();
            if (!isEmpty(reviewText) && user != null && user.id != service.user.id) {
                if (review.mark != 0) {
                    ++service.numberOfRates;
                    service.rate += review.mark;
                }
                var requestService = {};//noinspection JSCheckFunctionSignatures
                requestService['reviews'] = service.reviews.concat([review]);
                requestService['category'] = service.category;
                requestService['user'] = service.user;
                requestService.id = service.id;
                requestService.rate = service.rate;
                requestService.numberOfRates = service.numberOfRates;
                POST('review/add', requestService, function (data) {
                    //var stars = formStars(service.rate / service.numberOfRates, null);
                    //review.id = data;
                    //clearAddReview();
                    //reviewArea.val('');
                    //appendReview(review, true);
                    //$stars.html('<tr><td class="text">' + stars + ' (' +
                    //localization.numberOfRates + ': ' + service.numberOfRates + ')</td></tr>');
                    //element('reviewStars').innerHTML = formStars(0, true);
                    go();
                })
            } else {
                tooltip(localization.fillReview, 'reviewStars');
            }
        });
    }

    function getReviews() {
        $.each(service.reviews, function (i, item) {
            appendReview(item)
        });
    }

    var reviewsCounter = 0;

    function appendReview(item, isPrepend) {
        reviewsCounter++;
        var isCurrentUser = user != null && item.user.id == user.id;
        var deleteReviewHRef = isCurrentUser ? '<a id="' + item.id + '" href="javascript:void(0)">x</a>' : '';
        var reviewRow = '<tr id="' + item.id + 'Tr1"><td style="width: 58px">' + formStars(item.mark) +
            '</td><td style="width: 442px" class="text">' + userLink(item.user, null) + '</td><td class="text">' +
            deleteReviewHRef + '</td></tr>' + '<tr id="' + item.id + 'Tr2"><td colspan="3" class="mainText" ' +
            'style="width: 500px">' + item.review + '</td></tr>';
        if (isPrepend) {
            reviews.prepend(reviewRow);
        } else {
            reviews.append(reviewRow);
        }
        if (isCurrentUser) {
            var $deleteReview = $('#' + item.id);
            $deleteReview.on('click', function () {
                if (service.numberOfRates - 1 >= 0) {
                    --service.numberOfRates;
                }
                service.rate -= item.mark;
                var serviceRequest = jQuery.extend(true, {}, service);
                serviceRequest.reviews = [item];
                POST('review/delete', serviceRequest, function () {
                    var reviewTr1 = $('#' + item.id + 'Tr1');
                    var reviewTr2 = $('#' + item.id + 'Tr2');
                    reviewTr1.html('');
                    reviewTr2.html('');
                    $stars.html('<tr><td class="text">' + formStars(service.rate / service.numberOfRates) +
                        ' (' + localization.numberOfRates + ': ' + service.numberOfRates + ')</td></tr>');
                })
            })
        }
    }


    function clearAddReview() {
        if (urlContains('service.html')) {
            $addReviewButtonTd.html('');
            $reviewStars.html('');
            $reviewTd.html('');
        }
    }

    addAddReviewListener();
    addStarListeners();
    getReviews();
}
})
;


