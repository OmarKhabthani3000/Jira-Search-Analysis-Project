var user;
var services;
$(function () {
    var userId = urlParameter('userId');
    GET('user/getById/' + userId + '.do?page=' + urlParameter('page', 1) +
        '&perPage=' + urlParameter('perPage', 10) + '&orderBy=' + urlParameter('orderBy', 'free') +
        '&order=' + urlParameter('order', 'asc'), function (data) {
        if (!isEmpty(data) && userId !== 0) {
            user = data;
            var action = urlParameter('action');
            if (action === 'favourite') {
                services = user.favouriteServices;
                if (services.length == 1) {
                    $searchResult.html(localization.noFavouriteYet);
                } else {
                    $searchResult.html(localization.favouriteServices);
                }
            } else {
                services = user.services;
            }
            fillServicesTable(services);
            function fillUserStatistics() {
                if (user.services.length > 1) {
                    user.services[0].map.totalServicesCount = user.services[0].map['totalServicesCount'];
                    $('#servicesCount').html(user.services[0].map.totalServicesCount);
                } else {
                    $('#servicesCount').html('0');
                }
                $('#user').html(user.name);
                $('#averageRating').html(user['rating']);
                $('#userLabel').html(localization.user + ': ');
                $('#servicesCountLabel').html(localization.servicesCountLabel + ': ');
                $('#averageRatingLabel').html(localization.averageRatingLabel + ': ');
                if (equalsAttribute(savedObject('user').id, userId)) {
                    $('#redactProfile').html('<input type="button" onclick="go(\'user/save.html\')" value="' +
                        localization.redactProfile + '"/>');
                }
            }

            fillUserStatistics();
        } else {
            $searchResult.html(localization.userNotExists);
        }

        save('viewedUser', data);
        $('#user').html(addUserInfo('user'));
    });
});

