$(function () {
    if (urlContains('user/get/messages.html')) {
        var leftUl = element('leftCentralUl');

        function response(message) {
            var li = document.createElement('li');
            li.innerHTML = message;
            leftUl.appendChild(li)
        }

        if (hasRights()) {
            GET('message/getByUserId/' + urlParameter('userId'), function (messages) {
                if (!isEmpty(messages)) {
                    for (var i = 0; i < messages.length; i++) {
                        var message = messages[i];
                        response(message.message);
                    }
                } else {
                    response(localization.noMessages);
                }
            })
        } else if (isLogged()) {
            response(localization.noRights);
        } else {
            response(localization.pleaseLogin);
        }
    }
});
function sendMessage() {
    var modal = element('openModal');
    var modalResult = element('modalResult');
    button(element('sendMessage'), 'javascript:void(0)', localization.sendMessage,
        function () {
            modal.style.opacity = 1;
            modal.style.zIndex = 99999;
            element('closeModal').onclick = function () {
                modal.style.opacity = 0;
                modal.style.zIndex = -1000;
            }
        }, null, 'button', 165);
    function closeOK() {
        modalResult.style.opacity = 0;
        modalResult.style.zIndex = -1000;
    }

    button(element('ok'), 'javascript:void(0)', 'OK', closeOK);
    button(element('send'), 'javascript:void(0)', localization.send, function () {
        var message = {
            senderId: savedObject('user').id, receiverId: service.user.id, dispatchTime: new Date().getTime(),
            message: String(element('message').value)
        };
        element('message').innerHTML = '';
        POST('message/add', message, function (data) {
            modal.style.opacity = 0;
            modal.style.zIndex = -1000;
            modalResult.style.opacity = 1;
            modalResult.style.zIndex = 99999;
            if (isEmpty(data['message'])) {
                element('sendResult').innerHTML = localization.unsuccessfullySent;
            } else {
                element('sendResult').innerHTML = localization.successfullySent;
                element('send').innerHTML = localization.send;
            }
            element('closeResult').onclick = closeOK;
        }, null, function () {
            element('sendResult').innerHTML = localization.unsuccessfullySent;
        });
    }, null, 'button', 100);
}