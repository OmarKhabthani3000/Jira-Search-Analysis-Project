$(function () {
    var phone = urlParameter('phone');
    var findByPhone = $('#findByPhone');
    var searchPhoneField = $('#searchPhoneField');
    $('#hereYouCan').html(localization.hereYouCan + '<br/><br/>' + localization.phone);
    findByPhone.html(localization.search);
    findByPhone.on('click', function () {
        if (isEmpty(phone) || searchPhoneField.val() !== phone) {
            GET('user/getByPhone/' + (phone = isEmpty(phone) ? searchPhoneField.val().replaceAll
                ('-', '') : phone), function (data) {
                var id = !isEmpty(data) && !isEmpty(data.id) ? data.id : 0;
                go(applicationURL + 'user/get/byId.html?userId=' + id + '&page=' + urlParameter('page', 1) +
                    '&perPage=' + urlParameter('perPage', 10) + '&orderBy=' + urlParameter('orderBy', 'free') +
                    '&order=' + urlParameter('order', 'asc'));
            });
        }
    });
    addPhoneListener(searchPhoneField);
});
