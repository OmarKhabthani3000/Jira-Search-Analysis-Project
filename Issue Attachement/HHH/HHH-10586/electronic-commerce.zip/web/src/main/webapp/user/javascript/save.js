var user;
var email;
var waitingForEmail;
var loginField;
function updateUser(requestUser) {
    POST('user/update', requestUser, function (data) {
        if (data.indexOf('error=') != -1) {
            if (data.indexOf('name') != -1 && user.name != requestUser.name) {
                tooltip(localization.usedLogin, loginField);
            } else {
                saveAndRedirect();
            }
            if (data.indexOf('email') != -1 && user.email != requestUser.email) {
                tooltip(localization.usedEmail, email);
            } else {
                saveAndRedirect();
            }
        } else {
            saveAndRedirect();
        }
        function saveAndRedirect() {
            user = requestUser;
            save('logged', 'true');
            save('user', requestUser);
            go(replaceUrlParameter(saved('previousPage'), 'userId', fromJSON(data).id));
            //go('user/get/byId.html?userId=' + user.id);
        }
    }, 'string');
}
$(function () {
    $('#email').html(localization.email);
    $('#password').html(localization.password);
    $('#retypedPassword').html(localization.repeat);
    $('#retypedPasswordField').on('keyup', function () {
        var password = element('passwordField').value;
        var retypedPassword = element('retypedPasswordField').value;
        if (password.length == retypedPassword.length) {
            passwordsMatch(password, retypedPassword);
        }
    });
    $('#emailMe').html(localization.emailMe);
    $('#photo').html(localization.photoLogo);
    $('#login').html(localization.login);
    $('#phone').html(localization.phone);
    user = savedObject('user');
    var phone = $('#phoneField');
    email = element('emailField');
    loginField = element('loginField');
    waitingForEmail = element('emailMeCheckBox');
    loginField.value = user.name;
    var $saveProfile = $('#save');
    if (!isEmpty(user)) {
        email.value = user.email;
        phone.val(user.phones[0]);
        if (user.waitingForEmail == 1) {
            waitingForEmail.checked = 'on';
        }
        var picturesManager = jQuery.extend(true, {}, ImageManager);
        picturesManager.isLink = false;
        picturesManager.imagesHolder = user;
        picturesManager.isMagnificPopup = false;
        picturesManager.resizeImageOnHover = false;
        picturesManager.imagesTable = $('#photos');
        picturesManager.imagePrefix = fullPhotosPath;
        picturesManager.imagesHolderAttribute = 'photos';
        picturesManager.thumbnailBorderColor = '#149bdf';
        picturesManager.imagesDeletionServices = {url: formURL('utility/delete/*'), type: 'get'};
        showPictures(picturesManager);
        addPhoneListener(phone);
    }
    $saveProfile.val(localization.save);
    $saveProfile.on('click', function () {
        var photoPaths = [];
        upload('file', 'utility/upload', photoPaths, 'pic/user.png');
        updateProfile(photoPaths);
    });
});
function updateProfile(photoPaths) {
    var password = element('passwordField');
    var passwordValue = password.value;
    var retypedPassword = element('retypedPasswordField');
    if (passwordsMatch(passwordValue, retypedPassword.value, localization.mismatch, retypedPassword)) {
        var name = loginField.value;
        var phoneField = element('phoneField');
        var phone = phoneField.value.replaceAll('-', '');
        if (tooltipIfNotProper(loginField, localization.nameMustBe, 32)) {
            if (tooltipIfNotProper(password, localization.passwordMustBe, 32, 6)) {
                if (tooltipIfNotProper(email, localization.emailMustBe, 32, 5)) {
                    if (tooltipIfNotProper(phoneField, localization.phoneMustBe, 20, 10)) {
                        var waitingForEmail = element('emailMeCheckBox').value;
                        waitingForEmail = waitingForEmail === 'on' ? 1 : 0;
                        var phones = [];
                        phones[0] = phone;
                        var requestUser = {
                            id: user.id, email: email.value, password: passwordValue, name: name,
                            phones: phones, photos: photoPaths, waitingForEmail: waitingForEmail
                        };
                        user.password = hMacSha512(passwordValue, email.value + passwordValue.substr(0, 1));
                        updateUser(requestUser);
                    } else {
                        tooltip(localization.phoneMustBe, element('phoneField'));
                    }
                } else {
                    tooltip(localization.emailMustBe, email);
                }
            } else {
                tooltip(localization.passwordMustBe, password);
            }
        } else {
            tooltip(localization.nameMustBe, loginField);
        }
    }
}
