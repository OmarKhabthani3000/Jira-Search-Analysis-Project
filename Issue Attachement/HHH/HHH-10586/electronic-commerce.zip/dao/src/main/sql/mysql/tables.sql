SET @OLD_UNIQUE_CHECKS = @@UNIQUE_CHECKS, UNIQUE_CHECKS = 0;
SET @OLD_FOREIGN_KEY_CHECKS = @@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS = 0;
SET @OLD_SQL_MODE = @@SQL_MODE, SQL_MODE = 'TRADITIONAL,ALLOW_INVALID_DATES';

DROP SCHEMA IF EXISTS `electronicCommerce`;
CREATE SCHEMA IF NOT EXISTS `electronicCommerce`
  CHARACTER SET utf8
  COLLATE utf8_general_ci;
SET NAMES utf8;
USE `electronicCommerce`;
SET NAMES utf8;


-- -----------------------------------------------------
-- Table `electronicCommerce`.`Category`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `electronicCommerce`.`Category`;

CREATE TABLE IF NOT EXISTS `electronicCommerce`.`Category` (
  `categoryId`       BIGINT       NOT NULL AUTO_INCREMENT,
  `categoryName`     VARCHAR      NOT NULL,
  `categoryImage`    VARCHAR,
  `categoryParentId` BIGINT       NOT NULL,
  INDEX `categoryParentId` (`categoryParentId` ASC),
  PRIMARY KEY (`categoryId`)
)
  ENGINE = InnoDB
  CHARACTER SET = utf8
  COLLATE utf8_general_ci;


-- -----------------------------------------------------
-- Table `electronicCommerce`.`Product`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `electronicCommerce`.`Product`;

CREATE TABLE IF NOT EXISTS `electronicCommerce`.`Product` (
  `productId`            BIGINT       NOT NULL AUTO_INCREMENT,
  `productName`          VARCHAR(255) NOT NULL,
  `productPrice`         DECIMAL(12, 2),
  `productVendorId`      BIGINT       NOT NULL,
  `productIsInStock`     BOOLEAN      NOT NULL,
  `productCategoryId`    BIGINT       NOT NULL,
  `productDescription`   TEXT         NOT NULL,
  `productCreationDate`  DATETIME     NOT NULL,
  `productNumberOfRates` DECIMAL(16),
  `productRate`          DECIMAL(16),
  PRIMARY KEY (`productId`),
  INDEX `productNameIndex` (`productName` ASC),
  INDEX `productCategoryId` (`productCategoryId` ASC)
)
  ENGINE = InnoDB
  CHARACTER SET = utf8
  COLLATE utf8_general_ci;


DROP TABLE IF EXISTS `electronicCommerce`.`Vendor`;

CREATE TABLE IF NOT EXISTS `electronicCommerce`.`Vendor` (
  `vendorId`   BIGINT       NOT NULL AUTO_INCREMENT,
  `vendorName` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`vendorId`)
)
  ENGINE = InnoDB
  CHARACTER SET = utf8
  COLLATE utf8_general_ci;


-- -----------------------------------------------------
-- Table `electronicCommerce`.`Product`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `electronicCommerce`.`ProductCategory`;

CREATE TABLE IF NOT EXISTS `electronicCommerce`.`ProductCategory` (
  `productId`  BIGINT NOT NULL,
  `categotyId` BIGINT NOT NULL,
  PRIMARY KEY (`productId`, `categotyId`)
)
  ENGINE = InnoDB
  CHARACTER SET = utf8
  COLLATE utf8_general_ci;


-- -----------------------------------------------------
-- Table `electronicCommerce`.`FavouriteProduct`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `electronicCommerce`.`FavouriteProduct`;

CREATE TABLE IF NOT EXISTS `electronicCommerce`.`FavouriteProduct` (
  `favouriteUserId`    BIGINT NOT NULL,
  `favouriteProductId` BIGINT NOT NULL,
  INDEX `id` (`favouriteUserId` ASC)
)
  ENGINE = InnoDB
  CHARACTER SET = utf8
  COLLATE utf8_general_ci;


-- -----------------------------------------------------
-- Table `electronicCommerce`.`MarketingStatus`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `electronicCommerce`.`MarketingStatus`;

CREATE TABLE IF NOT EXISTS `electronicCommerce`.`MarketingStatus` (
  `marketingStatusId`          BIGINT        NOT NULL AUTO_INCREMENT,
  `marketingStatus`            VARCHAR(32)   NOT NULL,
  `marketingStatusDescription` VARCHAR(1024) NULL,
  `marketingStatusImage`       VARCHAR(1024) NULL,
  `marketingStatusBigImage`    VARCHAR(1024) NULL,
  `marketingStatusExporeDate`  DATE          NULL,
  PRIMARY KEY (`marketingStatusId`, `marketingStatus`)
)
  ENGINE = InnoDB
  CHARACTER SET = utf8
  COLLATE utf8_general_ci;


-- -----------------------------------------------------
-- Table `electronicCommerce`.`Message`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `electronicCommerce`.`Message`;

CREATE TABLE IF NOT EXISTS `electronicCommerce`.`Message` (
  `messageId`           BIGINT      NOT NULL AUTO_INCREMENT,
  `messageSenderId`     BIGINT      NOT NULL,
  `messageReceiverId`   BIGINT      NOT NULL,
  `messageText`         VARCHAR(45) NOT NULL,
  `messageDispatchDate` VARCHAR(45) NOT NULL,
  `messageReceiptDate`  VARCHAR(45) NULL,
  PRIMARY KEY (`messageId`),
  INDEX `messageSenderId` (messageSenderId ASC),
  INDEX `messageReceiverId` (messageReceiverId ASC)
)
  ENGINE = InnoDB
  CHARACTER SET = utf8
  COLLATE utf8_general_ci;


-- -----------------------------------------------------
-- Table `electronicCommerce`.`ImageProduct`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `electronicCommerce`.`ImageProduct`;

CREATE TABLE IF NOT EXISTS `electronicCommerce`.`ImageProduct` (
  `imageProductId` BIGINT      NOT NULL,
  `image`          VARCHAR(85) NOT NULL,
  INDEX `imageProductIdImage` (imageProductId, image ASC)
)
  ENGINE = InnoDB
  CHARACTER SET = utf8
  COLLATE utf8_general_ci;


-- -----------------------------------------------------
-- Table `electronicCommerce`.`Review`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `electronicCommerce`.`Review`;

CREATE TABLE IF NOT EXISTS `electronicCommerce`.`Review` (
  `reviewId`        BIGINT        NOT NULL,
  `reviewUserId`    BIGINT        NOT NULL,
  `reviewParentId`  BIGINT        NULL,
  `reviewProductId` BIGINT        NOT NULL,
  `review`          VARCHAR(1024) NOT NULL,
  `positiveSides`   VARCHAR(1024) NULL,
  `negativeSides`   VARCHAR(1024) NULL,
  `positiveMarks`   BIGINT(12)    NULL,
  `negativeMarks`   BIGINT(12)    NULL,
  `mark`            INT           NULL,
  `reviewDate`      DATETIME      NULL,
  PRIMARY KEY (`reviewId`),
  INDEX `reviewProductId` (`reviewProductId` ASC)
)
  ENGINE = InnoDB
  CHARACTER SET = utf8
  COLLATE utf8_general_ci;


-- -----------------------------------------------------
-- Table `electronicCommerce`.`Users`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `electronicCommerce`.`Users`;

CREATE TABLE IF NOT EXISTS `electronicCommerce`.`Users` (
  `userId`    BIGINT       NOT NULL,
  `email`     VARCHAR(32)  NULL,
  `password`  VARCHAR(128) NULL,
  `name`      VARCHAR(32)  NOT NULL,
  `birthDate` DATETIME     NULL,
  `emailUser` INT          NULL,
  `userPhone` BIGINT(20)   NOT NULL,
  `userImage` VARCHAR(512) NULL,
  `cashless`  INT          NULL,
  PRIMARY KEY (`userId`),
  UNIQUE INDEX `name_UNIQUE` (`name` ASC),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC),
  UNIQUE INDEX `userPhone_UNIQUE` (`userPhone` ASC)
)
  ENGINE = InnoDB
  CHARACTER SET = utf8
  COLLATE utf8_general_ci;


-- -----------------------------------------------------
-- Table `electronicCommerce`.`ProductMarketing`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `electronicCommerce`.`ProductMarketing`;

CREATE TABLE IF NOT EXISTS `electronicCommerce`.`ProductMarketing` (
  `marketingProductId`       BIGINT NOT NULL,
  `marketingProductStatusId` BIGINT NOT NULL,
  INDEX `id` (`marketingProductId` ASC)
)
  ENGINE = InnoDB
  CHARACTER SET = utf8
  COLLATE utf8_general_ci;


SET SQL_MODE = @OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS = @OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS = @OLD_UNIQUE_CHECKS;