DELETE FROM mysql.proc
WHERE db IN ('electroniccommerce', 'mysql');
DELIMITER //
CREATE PROCEDURE delImageProduct(IN request_imageProductId NUMERIC(12, 0),
                                 IN request_image          VARCHAR(85))
  BEGIN
    DELETE FROM ImageProduct
    WHERE imageProductId = request_imageProductId AND image = request_image;
  END //


DELIMITER //
CREATE PROCEDURE insImageProduct(IN request_imageProductId NUMERIC(12, 0),
                                 IN request_image          VARCHAR(85))
  BEGIN
    INSERT INTO ImageProduct (imageProductId, image) VALUES (request_imageProductId, request_image);
  END //


DELIMITER //
CREATE PROCEDURE getImageProduct(IN request_imageProductId NUMERIC(12, 0))
  BEGIN
    SELECT image
    FROM ImageProduct
    WHERE imageProductId = request_imageProductId;
  END //


DELIMITER //
CREATE PROCEDURE getPayedProduct(IN request_productCategoryId INT)
  BEGIN
    SELECT
      productId,
      productCategoryId,
      productNumberOfRates,
      productDescription,
      productName,
      productRate,
      productPrice,
      productUserId,
      productUserImage
    FROM Product, Users, MarketingStatus, ProductMarketing
    WHERE userId = productUserId AND productId = marketingProductId AND
          marketingStatusId = marketingProductStatusId AND marketingStatusId = 1 AND
          productCategoryId = request_productCategoryId;
  END //

DELIMITER //
CREATE PROCEDURE isNull(IN toCheck NUMERIC(12), IN nullDelegate INT)
  BEGIN

  END //

DELIMITER //
CREATE PROCEDURE updateProduct
  (IN request_productId         NUMERIC(12),
   IN request_productCategoryId INT,
   IN request_productUserId     NUMERIC(12),
   IN request_product           VARCHAR(256),
   IN request_description       TEXT,
   IN request_rate              NUMERIC(16),
   IN request_price             NUMERIC(12, 2),
   IN request_numberOfRates     NUMERIC(12))
  BEGIN
    IF (CAST(request_description AS CHAR(1)) = '')
    THEN
      UPDATE Product
      SET productUserId      = COALESCE(request_productUserId, productUserId),
        productCategoryId    = COALESCE(request_productCategoryId, productCategoryId),
        productName          = COALESCE(request_product, productName),
        productRate          = COALESCE(request_rate, productRate),
        productNumberOfRates = COALESCE(request_numberOfRates, productNumberOfRates)
      WHERE productId = request_productId;
    ELSE
      UPDATE Product
      SET productUserId      = COALESCE(request_productUserId, productUserId),
        productCategoryId    = COALESCE(request_productCategoryId, productCategoryId),
        productDescription   = COALESCE(request_description, productRDescription),
        productName          = COALESCE(request_product, productProduct),
        productRate          = COALESCE(request_rate, productRRate),
        productNumberOfRates = COALESCE(request_numberOfRates, productRNumberOfRates)
      WHERE productId = request_productId;
    END IF;
  END //


DELIMITER //
CREATE PROCEDURE getProductById(IN request_productId INT)
  BEGIN
    SELECT
      productId,
      productCategoryId,
      numberOfRates,
      description,
      productName,
      productRate,
      productPrice,
      userId,
      userImage
    FROM Product, Users
    WHERE productId = request_productId AND userId = productUserId;
  END //


DELIMITER //
CREATE PROCEDURE getNewProducts(IN request_categoryId INT)
  BEGIN
    SELECT
      productId,
      productNmberOfRates,
      productDescription,
      productName,
      productPrice,
      productRate
    FROM Product
    WHERE productCategoryId = request_categoryId
    ORDER BY productId
    LIMIT 15;
  END //


DELIMITER //
CREATE PROCEDURE deleteProduct(IN request_productId INT)
  BEGIN
    DELETE FROM Product
    WHERE productId = request_productId;

    DELETE FROM ImageProduct
    WHERE imageProductId = request_productId;

    DELETE FROM ProductMarketing
    WHERE marketingProductId = request_productId;

    DELETE FROM Review
    WHERE reviewProductId = request_productId;

    DELETE FROM FavouriteProduct
    WHERE favouriteProductId = request_productId;
  END //


DELIMITER //
CREATE PROCEDURE getTopProducts(IN request_categoryId INT)
  BEGIN
    SELECT
      productId,
      productNumberOfRates,
      productDescription,
      productName,
      productPrice,
      productRate
    FROM Product
    WHERE productNumberOfRates != 0 AND productCategoryId = request_categoryId
    ORDER BY productRate / productNumberOfRates DESC
    LIMIT 5;
  END //


DELIMITER //
CREATE PROCEDURE insertProduct
  (IN request_productCategoryId INT,
   IN request_productUserId     NUMERIC(12),
   IN request_product           VARCHAR(256),
   IN request_description       TEXT,
   IN request_price             NUMERIC(12, 2))
  BEGIN
    SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
    INSERT INTO Product (productCategoryId,
                         productUserId,
                         productName,
                         productDescription,
                         productPrice) VALUES (request_productCategoryId,
                                               request_productUserId,
                                               request_product,
                                               request_description,
                                               request_price);
    SELECT max(productId) productId
    FROM Product;
    SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;
  END //


DELIMITER //
CREATE PROCEDURE delFavouriteProduct(IN request_favouriteUserId    NUMERIC(12),
                                     IN request_favouriteProductId INT)
  BEGIN
    IF request_favouriteUserId = 0
    THEN
      DELETE FROM FavouriteProduct
      WHERE favouriteProductId = request_favouriteProductId;
    ELSE
      DELETE FROM FavouriteProduct
      WHERE favouriteUserId = request_favouriteUserId AND favouriteProductId = request_favouriteProductId;
    END IF;
  END //


DELIMITER //
CREATE PROCEDURE addFavouriteProduct(IN request_favouriteUserId    NUMERIC(12, 0),
                                     IN request_favouriteProductId NUMERIC(12, 0))
  BEGIN
    INSERT INTO FavouriteProduct (favouriteUserId, favouriteProductId)
    VALUES (request_favouriteUserId, request_favouriteProductId);
  END //


DELIMITER //
CREATE PROCEDURE getUsersByPhone(IN request_phone NUMERIC(19, 0))
  BEGIN
    DECLARE request_userId NUMERIC(12);
    DECLARE request_rating NUMERIC(12, 1);
    DECLARE request_numberOfRates NUMERIC(12);

    SET request_userId = (SELECT userId
                          FROM Users
                          WHERE userPhone = request_phone);

    SET request_numberOfRates = (SELECT sum(numberOfRates)
                                 FROM Product
                                 WHERE productUserId = request_userId AND rate IS NOT NULL
                                 LIMIT 1);

    SET request_rating = (SELECT sum(rate)
                          FROM Product
                          WHERE productUserId = request_userId AND rate IS NOT NULL
                          LIMIT 1);

    IF request_numberOfRates = 0
    THEN
      SET request_numberOfRates = 1;
    END IF;

    SELECT
      name,
      email,
      userId                                 id,
      password,
      birthDate,
      emailUser                              waitingForEmail,
      userPhone                              phone,
      userImage                              image,
      cashless,
      request_rating / request_numberOfRates rating
    FROM Users
    WHERE userId = request_userId;
  END //


DELIMITER //
CREATE PROCEDURE updUsers
  (IN request_birthDate DATETIME,
   IN request_cashless  NUMERIC(1, 0),
   IN request_email     VARCHAR(32),
   IN request_emailUser NUMERIC(1, 0),
   IN request_NAME      VARCHAR(32),
   IN request_password  VARCHAR(128),
   IN request_userId    NUMERIC(12, 0),
   IN request_userPhone NUMERIC(20),
   IN request_userImage VARCHAR(512))
  BEGIN
    UPDATE Users
    SET email   = request_email,
      password  = request_password,
      name      = request_name,
      birthDate = request_birthDate,
      emailUser = request_emailUser,
      userPhone = request_userPhone,
      userImage = request_userImage,
      cashless  = request_cashless
    WHERE userId = request_userId;
  END //


DELIMITER //
CREATE PROCEDURE delUsers(IN request_userId NUMERIC(12, 0))
  BEGIN
    DELETE FROM Users
    WHERE userId = request_userId;
  END //


DELIMITER //
CREATE PROCEDURE getUsers(IN request_userId NUMERIC(12, 0))
  BEGIN
    DECLARE request_rating NUMERIC(12, 1);
    DECLARE request_numberOfRates NUMERIC(12);

    SET request_numberOfRates = (SELECT sum(numberOfRates)
                                 FROM Product
                                 WHERE productUserId = request_userId AND rate IS NOT NULL
                                 LIMIT 1);

    SET request_rating = (SELECT sum(rate)
                          FROM Product
                          WHERE productUserId = request_userId AND rate IS NOT NULL
                          LIMIT 1);

    IF request_numberOfRates = 0
    THEN
      SET request_numberOfRates = 1;
    END IF;

    SELECT
      name,
      email,
      userId                                 id,
      password,
      birthDate,
      emailUser                              waitingForEmail,
      userPhone                              phone,
      userImage                              image,
      cashless,
      request_rating / request_numberOfRates rating
    FROM Users
    WHERE userId = request_userId;
  END //


DELIMITER //
CREATE PROCEDURE addUsers(IN request_birthDate DATETIME,
                          IN request_cashless  NUMERIC(1, 0),
                          IN request_email     VARCHAR(32),
                          IN request_emailUser NUMERIC(1, 0),
                          IN request_name      VARCHAR(32),
                          IN request_password  VARCHAR(128),
                          IN request_userPhone NUMERIC(20),
                          IN request_userImage VARCHAR(512))
  BEGIN
    DECLARE newUserId INT;
    DECLARE request_error VARCHAR(9);
    SET request_error = (SELECT 'name;'
                         FROM Users
                         WHERE name = request_name);

    SET request_error = (SELECT request_error + 'email'
                         FROM Users
                         WHERE email = request_email);

    SET newUserId = (SELECT max(userId)
                     FROM Users);

    IF isNull(newUserId) = 1
    THEN SET newUserId = 1;
    ELSE SET newUserId = newUserId + 1;
    END IF;

    IF isNull(request_error)
    THEN
      BEGIN
        INSERT INTO Users (userId,
                           email,
                           password,
                           name,
                           birthDate,
                           emailUser,
                           userPhone,
                           userImage,
                           cashless)
        VALUES (newUserId,
                request_email,
                request_password,
                request_name,
                request_birthDate,
                request_emailUser,
                request_userPhone,
                request_userImage,
                request_cashless);
        SELECT
          newUserId         id,
          request_email     email,
          request_password  password,
          request_name      name,
          request_birthDate birthDate,
          request_emailUser waitingForEmail,
          request_userPhone phone,
          request_userImage image,
          request_cashless  cashless;
      END;
    ELSE
      SELECT 'error' = request_error;
    END IF;
  END //


DELIMITER //
CREATE PROCEDURE getUsersByEmail(IN request_email VARCHAR(32))
  BEGIN
    DECLARE request_userId NUMERIC(12);
    DECLARE request_rating NUMERIC(12, 1);
    DECLARE request_numberOfRates NUMERIC(12);

    SET request_userId = (SELECT userId
                          FROM Users
                          WHERE email = request_email);

    SET request_numberOfRates = (SELECT sum(numberOfRates)
                                 FROM Product
                                 WHERE productUserId = request_userId AND rate IS NOT NULL
                                 LIMIT 1);

    SET request_rating = (SELECT sum(rate)
                          FROM Product
                          WHERE productUserId = request_userId AND rate IS NOT NULL
                          LIMIT 1);

    IF request_numberOfRates = 0
    THEN
      SET request_numberOfRates = 1;
    END IF;

    SELECT
      name,
      email,
      userId                                 id,
      password,
      birthDate,
      emailUser                              waitingForEmail,
      userPhone                              phone,
      userImage                              image,
      cashless,
      request_rating / request_numberOfRates rating
    FROM Users
    WHERE userId = request_userId;
  END //


DELIMITER //
CREATE PROCEDURE insMarketingStatus(IN request_marketingStatus            VARCHAR(256),
                                    IN request_marketingStatusDescription VARCHAR(2048),
                                    IN request_marketingStatusImage       VARCHAR(256))
  BEGIN
    INSERT INTO MarketingStatus (marketingStatus,
                                 marketingStatusDescription,
                                 marketingStatusImage) VALUES (request_marketingStatus,
                                                               request_marketingStatusDescription,
                                                               request_marketingStatusImage);
  END //


DELIMITER //
CREATE PROCEDURE getMarketingStatus(IN request_marketingStatusId NUMERIC(12, 0))
  BEGIN
    SELECT
      marketingStatusId,
      marketingStatus,
      marketingStatusDescription,
      marketingStatusImage,
      marketingStatusBigImage
    FROM MarketingStatus
    WHERE marketingStatusId = request_marketingStatusId;
  END //


DELIMITER //
CREATE PROCEDURE updMarketingStatus(IN request_marketingStatusId          NUMERIC(12, 0),
                                    IN request_marketingStatus            VARCHAR(256),
                                    IN request_marketingStatusDescription VARCHAR(2048),
                                    IN request_marketingStatusImage       VARCHAR(256))
  BEGIN
    UPDATE MarketingStatus
    SET marketingStatus          = request_marketingStatus,
      marketingStatusDescription = request_marketingStatusDescription,
      marketingStatusImage       = request_marketingStatusImage
    WHERE marketingStatusId = request_marketingStatusId;
  END //


DELIMITER //
CREATE PROCEDURE delMarketingStatus(IN request_marketingStatusId NUMERIC(12, 0))
  BEGIN
    DELETE FROM MarketingStatus
    WHERE marketingStatusId = request_marketingStatusId;
  END //


DELIMITER //
CREATE PROCEDURE getMessage(IN request_receiverId INT, request_senderId INT)
  BEGIN
    SELECT
      messageDispatchDate,
      messageText,
      messageId,
      messageReceiverId,
      messageSenderId
    FROM Message
    WHERE messageSenderId = request_senderId OR messageReceiverId = request_receiverId;
  END //


DELIMITER //
CREATE PROCEDURE addMessage(IN request_dispatchDate DATETIME,
                            IN request_message      TEXT,
                            IN request_receiverId   NUMERIC(12, 0),
                            IN request_senderId     NUMERIC(12, 0))
  BEGIN
    DECLARE messageId INT;
    SET messageId = (SELECT MAX(messageId) + 1
                     FROM Message);
    INSERT INTO Message (dispatchDate,
                         messageText,
                         messageReceiverId,
                         messageSenderId) VALUES (request_dispatchDate,
                                                  request_message,
                                                  request_receiverId,
                                                  request_senderId);
    SELECT
      messageId            messageId,
      request_dispatchDate messageDispatchDate,
      request_receiverId   messageReceiverId,
      request_senderId     messageSenderId,
      request_message      messageText;
  END //


DELIMITER //
CREATE PROCEDURE delMessage(IN request_messageId INT)
  BEGIN
    DELETE FROM Message
    WHERE messageId = request_messageId;
  END //
DELIMITER //
CREATE PROCEDURE updMessage(request_dispatchDate DATETIME,
                            request_message      TEXT,
                            request_messageId    NUMERIC(12, 0),
                            request_receiverId   NUMERIC(12, 0),
                            request_senderId     NUMERIC(12, 0))
  BEGIN
    UPDATE Message
    SET messageDispatchDate = request_dispatchDate,
      messageText           = request_message,
      messageReceiverId     = request_receiverId,
      messageSenderId       = request_senderId
    WHERE messageDispatchDate = request_dispatchDate;
  END //


DELIMITER //
CREATE PROCEDURE insProductMarketing(IN request_marketingProductId       NUMERIC(12, 0),
                                     IN request_marketingProductStatusId NUMERIC(12, 0))
  BEGIN
    INSERT INTO ProductMarketing (marketingProductId,
                                  marketingProductStatusId) VALUES (request_marketingProductId,
                                                                    request_marketingProductStatusId);
  END //


DELIMITER //
CREATE PROCEDURE updProductMarketing(IN request_marketingProductId       NUMERIC(12, 0),
                                     IN request_marketingProductStatusId NUMERIC(12, 0))
  BEGIN
    UPDATE ProductMarketing
    SET marketingProductStatusId = request_marketingProductStatusId
    WHERE
      marketingProductId = request_marketingProductId AND marketingProductStatusId = request_marketingProductStatusId;
  END //


DELIMITER //
CREATE PROCEDURE multiDelProductMarketing(IN request_marketingProductId NUMERIC(12, 0))
  BEGIN
    DELETE FROM ProductMarketing
    WHERE marketingProductId = request_marketingProductId;
  END //


DELIMITER //
CREATE PROCEDURE getProductMarketing(IN request_marketingProductId       NUMERIC(12, 0),
                                     IN request_marketingProductStatusId NUMERIC(12, 0))
  BEGIN
    SELECT
      marketingProductId,
      marketingProductStatusId
    FROM ProductMarketing
    WHERE marketingProductId = request_marketingProductId;
  END //


DELIMITER //
CREATE PROCEDURE delProductMarketing(IN request_marketingProductId       NUMERIC(12, 0),
                                     IN request_marketingProductStatusId NUMERIC(12, 0))
  BEGIN
    DELETE FROM ProductMarketing
    WHERE
      marketingProductId = request_marketingProductId AND marketingProductStatusId = request_marketingProductStatusId;
  END //


DELIMITER //
CREATE PROCEDURE insReview(OUT request_reviewId        NUMERIC(12),
                           IN  request_reviewParentId  NUMERIC(12),
                           IN  request_reviewProductId NUMERIC(12, 0),
                           IN  request_review          VARCHAR(1024),
                           IN  request_positiveSides   VARCHAR(1024),
                           IN  request_negativeSides   VARCHAR(1024),
                           IN  request_mark            NUMERIC(12, 0),
                           IN  request_positiveMarks   NUMERIC(12, 0),
                           IN  request_negativeMarks   NUMERIC(12, 0),
                           IN  request_reviewUserId    NUMERIC(12, 0))
  BEGIN
    SET request_reviewId = (SELECT max(reviewId)
                            FROM Review);

    IF isNull(request_reviewId) = 1
    THEN SET request_reviewId = 1;
    ELSE SET request_reviewId = request_reviewId + 1;
    END IF;

    INSERT INTO Review (reviewId,
                        reviewParentId,
                        reviewProductId,
                        review,
                        positiveSides,
                        negativeSides,
                        mark,
                        positiveMarks,
                        negativeMarks,
                        reviewUserId) VALUES (request_reviewId,
                                              request_reviewParentId,
                                              cast(request_reviewProductId AS DECIMAL(12, 0)),
                                              request_review,
                                              request_positiveSides,
                                              request_negativeSides,
                                              request_mark,
                                              request_positiveMarks,
                                              request_negativeMarks,
                                              request_reviewUserId);
  END //


DELIMITER //
CREATE PROCEDURE delReview(IN request_reviewId INT)
  BEGIN
    DELETE FROM Review
    WHERE reviewId = request_reviewId;
  END //


DELIMITER //
CREATE PROCEDURE getReview(IN request_productId NUMERIC(12, 0))
  BEGIN
    SELECT
      DISTINCT
      reviewId,
      userId,
      name,
      reviewParentId,
      reviewProductId,
      review,
      positiveSides,
      negativeSides,
      mark,
      positiveMarks,
      negativeMarks
    FROM Review, Users
    WHERE reviewProductId = request_productId AND userId = reviewUserId
    LIMIT 250;
  END //


DELIMITER //
CREATE PROCEDURE updReview(IN request_reviewId        NUMERIC(12),
                           IN request_reviewParentId  NUMERIC(12),
                           IN request_reviewProductId NUMERIC(12, 0),
                           IN request_review          VARCHAR(1024),
                           IN request_positiveSides   VARCHAR(1024),
                           IN request_negativeSides   VARCHAR(1024),
                           IN request_mark            NUMERIC(12, 0),
                           IN request_positiveMarks   NUMERIC(12, 0),
                           IN request_negativeMarks   NUMERIC(12, 0),
                           IN request_reviewUserId    NUMERIC(12, 0))
  BEGIN
    UPDATE Review
    SET reviewParentId = request_reviewParentId,
      reviewProductId  = request_reviewProductId,
      review           = request_review,
      positiveSides    = request_positiveSides,
      negativeSides    = request_negativeSides,
      mark             = request_mark,
      positiveMarks    = request_positiveMarks,
      negativeMarks    = request_negativeMarks,
      reviewUserId     = request_reviewUserId
    WHERE reviewId = request_reviewId;
  END //


DELIMITER //
CREATE PROCEDURE insertCategory
  (IN request_categoryParentId INT,
   IN request_category         VARCHAR(128),
   IN request_categoryImage    VARCHAR(512))
  BEGIN
    INSERT INTO Category (categoryName, categoryParentId, categoryImage)
    VALUES (request_category, request_categoryParentId, request_categoryImage);
  END //


DELIMITER //
CREATE PROCEDURE deleteCategory(IN categoryIdIn INT)
  BEGIN
    DECLARE productId INT;
    DECLARE currentCategoryId INT;

    WHILE currentCategoryId IS NOT NULL DO
      CALL deleteCategory(currentCategoryId);
      SET currentCategoryId = (SELECT categoryId
                               FROM Category
                               WHERE categoryParentId = categoryIdIn);
    END WHILE;

    WHILE productId IS NOT NULL DO
      CALL deleteProduct(productId);
      SET productId = (SELECT productId
                       FROM Product
                       WHERE productCategoryId = categoryIdIn
                       LIMIT 1);
    END WHILE;

    DELETE FROM Category
    WHERE categoryId = categoryIdIn;
  END //


DELIMITER //
CREATE PROCEDURE updateCategory
  (IN request_categoryParentId INT,
   IN request_category         VARCHAR(128),
   IN request_categoryImage    VARCHAR(512),
   IN request_categoryId       NUMERIC(12))
  BEGIN
    UPDATE Category
    SET categoryName   = request_category,
      categoryParentId = request_categoryParentId,
      categoryImage    = request_categoryImage
    WHERE categoryId = request_categoryId;
  END //


DELIMITER //
CREATE PROCEDURE selectCategory(IN request_categoryParentId INT)
  BEGIN
    SELECT
      categoryId,
      categoryName,
      categoryParentId,
      categoryImage
    FROM Category
    WHERE categoryParentId = request_categoryParentId
    ORDER BY categoryName;
  END //