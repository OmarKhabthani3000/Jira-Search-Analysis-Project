package com.electronic.commerce.dao;

import com.electronic.commerce.dao.base.BaseDAO;

import java.util.List;

/**
 * @author Arthur Kharkivsky
 * @since 23.02.2016
 */
public interface ProductDAO<P> extends BaseDAO<P> {
    List<P> getByCategoryId(long categoryId, int page, int resultLimit);

    int countByCategoryId(long categoryId);
}
