package com.electronic.commerce.dao;

import com.electronic.commerce.dao.base.BaseDAO;

import java.util.List;

/**
 * @author Arthur Kharkivsky
 * @since 23.02.2016
 */
public interface CategoryDAO<C> extends BaseDAO<C> {
    List<C> getByParentIdLazy(long parentId);

    List<C> getByParentId(long parentId);

    C getById(long categoryId);
}
