package com.electronic.commerce.dao.sql.hibernate;

import com.electronic.commerce.dao.CategoryDAO;
import com.electronic.commerce.models.Category;
import org.hibernate.Hibernate;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.io.Serializable;
import java.util.List;

/**
 * @author Arthur Victorovych Kharkivsky
 */
@Repository
public class CategorySqlHibernateDAO extends HibernateDaoSupport implements CategoryDAO<Category> {
    @Override
    public Serializable save(Category category) {
        return getHibernateTemplate().save(category);
    }

    @Override
    public void delete(Category category) {
        getHibernateTemplate().delete(category);
    }

    @Override
    public void update(Category category) {
        getHibernateTemplate().update(category);
    }

    @Override
    public Category getById(long id) {
        return getHibernateTemplate().get(Category.class, id);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Category> getByParentIdLazy(long parentId) {
        return getSessionFactory().getCurrentSession().createQuery(
                "from Category c where c.parentId = :parentId").setLong("parentId", parentId).list();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Category> getByParentId(long parentId) {
        List result = getByParentIdLazy(parentId);
        Hibernate.initialize(result);

        return result;
    }
}
