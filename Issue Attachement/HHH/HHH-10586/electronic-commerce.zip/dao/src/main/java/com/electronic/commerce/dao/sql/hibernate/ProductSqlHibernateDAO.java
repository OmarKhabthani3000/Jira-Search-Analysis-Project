package com.electronic.commerce.dao.sql.hibernate;

import com.electronic.commerce.dao.ProductDAO;
import com.electronic.commerce.models.Product;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import java.io.Serializable;
import java.util.List;

/**
 * To think about aggregation.
 *
 * @author Arthur Kharkivsky
 */
@Repository
public class ProductSqlHibernateDAO extends HibernateDaoSupport implements ProductDAO<Product> {

    @Override
    public Serializable save(Product baseModel) {
        return getHibernateTemplate().save(baseModel);
    }

    @Override
    public void delete(Product product) {
        getHibernateTemplate().delete(product);
    }

    @Override
    public void update(Product baseModel) {
        getHibernateTemplate().save(baseModel);
    }

    @Override
    public Product getById(long id) {
        return getHibernateTemplate().get(Product.class, id);
    }

    /**
     * Obtains a list of products for passed category ID.
     *
     * @param categoryId       is a target category ID.
     * @param resultPageNumber is a desired result page number.
     * @param resultLimit      is a wanted result limit.
     * @return the list of products for selected category in desired threshold range.
     */
    @Override
    @SuppressWarnings("unchecked")
    public List<Product> getByCategoryId(long categoryId, int resultPageNumber, int resultLimit) {
        int firstResult = countByCategoryId(categoryId) / resultLimit;

        return getSessionFactory().getCurrentSession().createQuery(
                "from Product where productCategoryId = :categoryId ").setLong("categoryId", categoryId).
                setMaxResults(resultLimit).setFirstResult(firstResult).list();
    }

    public int countByCategoryId(long categoryId) {
        return (int) getSessionFactory().getCurrentSession().createCriteria(Product.class).
                add(Restrictions.eq("productCategoryId", categoryId)).
                setProjection(Projections.rowCount()).uniqueResult();
    }
}
