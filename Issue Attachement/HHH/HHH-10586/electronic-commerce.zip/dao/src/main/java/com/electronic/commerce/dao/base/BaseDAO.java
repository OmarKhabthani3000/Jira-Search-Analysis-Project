package com.electronic.commerce.dao.base;

import java.io.Serializable;

/**
 * @author Arthur Kharkivsky
 * @since 24.02.2016
 */
public interface BaseDAO<BaseModel> {
    Serializable save(BaseModel baseModel);

    void delete(BaseModel baseModel);

    void update(BaseModel baseModel);

    BaseModel getById(long id);
}
