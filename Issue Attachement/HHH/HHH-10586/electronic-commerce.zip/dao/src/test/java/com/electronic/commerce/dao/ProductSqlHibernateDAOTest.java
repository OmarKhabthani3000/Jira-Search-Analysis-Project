package com.electronic.commerce.dao;

import com.electronic.commerce.models.Product;
import com.electronic.commerce.utilities.dao.ConnectionUtility;
import com.electronic.commerce.utilities.dao.SqlQueryJdbcExecutionUtility;
import org.assertj.core.api.Assertions;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:test-contexts/bean-locations.xml"})
public class ProductSqlHibernateDAOTest {

    private static final long FIRST_ID = Long.MAX_VALUE - 1;
    private static final long SECOND_ID = Long.MAX_VALUE;
    private static final String DELETE_QUERY = "delete from Product where productId = %1$d";
    private static final String INSERT_QUERY = "insert into Product (categoryId, categoryName, categoryImage, " +
            "categoryParentId) select \"%1$s\", \"%2$s\", \"%3$s\", %4$d";
    private static Connection connection;
    private Product product;

    @Autowired
    @Qualifier("productSqlHibernateDAO")
    private ProductDAO<Product> testTarget;
    @Autowired
    private DriverManagerDataSource driverManagerDataSource;

    @AfterClass
    public static void tearDownOnce() throws SQLException {
        SqlQueryJdbcExecutionUtility.execute(DELETE_QUERY, connection, FIRST_ID);
        SqlQueryJdbcExecutionUtility.execute(DELETE_QUERY, connection, SECOND_ID);
        JdbcUtils.closeConnection(connection);
    }

    @Before
    public void setUp() throws Exception {
        connection = ConnectionUtility.getNewConnectionIfExistedIsNull(connection, driverManagerDataSource);



        SqlQueryJdbcExecutionUtility.execute(DELETE_QUERY, connection, FIRST_ID);
        SqlQueryJdbcExecutionUtility.execute(INSERT_QUERY, connection, FIRST_ID, "NAME", "IMAGE");
    }

    @Test
    public void getByCategoryId() throws Exception {
        List result = testTarget.getByCategoryId(2, 1, 1);

        Assertions.assertThat(result).hasSize(1);
    }

    @Test
    public void save() throws Exception {
        SqlQueryJdbcExecutionUtility.execute("delete from Product where categoryId in (%1$d, %2$d)", connection,
                FIRST_ID, SECOND_ID);

        testTarget.save(product);

        assertThat(product.getId()).isNotEqualTo(0);
    }

    @Test
    public void delete() throws Exception {
        testTarget.delete(product);

        assertThat(testTarget.getById(product.getId())).isNull();
    }

    @Test
    public void update() throws Exception {
        product.setId(FIRST_ID);

        testTarget.update(product);

        assertThat(SqlQueryJdbcExecutionUtility.isExists("select 1 from Category where categoryId = %1$d " +
                        "and categoryName = \"%2$s\" and  categoryImage = \"%3$s\" and  categoryParentId = %4$d",
                connection, product.getId(), product.getName()));
    }
}