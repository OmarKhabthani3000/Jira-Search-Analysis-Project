package com.electronic.commerce.dao;

import com.electronic.commerce.dao.utilities.H2Server;
import com.electronic.commerce.models.Category;
import com.electronic.commerce.utilities.dao.ConnectionUtility;
import com.electronic.commerce.utilities.dao.SqlQueryJdbcExecutionUtility;
import org.dbunit.database.DatabaseDataSourceConnection;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.dbunit.operation.DatabaseOperation;
import org.hamcrest.Matchers;
import org.hamcrest.core.Every;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertTrue;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:test-contexts/bean-locations.xml"})
public class CategorySqlHibernateDAOTest {

    private static final long ROOT_ID = 0;
    private static final long FIRST_ID = 1;
    private static Connection connection;
    private Category category;
    @Autowired
    @Qualifier("categorySqlHibernateDAO")
    private CategoryDAO<Category> testTarget;
    private static DriverManagerDataSource driverManagerDataSource = new ClassPathXmlApplicationContext
            ("test-contexts/data-source.xml").getBean(DriverManagerDataSource.class);

    @BeforeClass
    public static void setUpOnce() throws SQLException {
        connection = driverManagerDataSource.getConnection();
        H2Server.initializeIfRequiredAndStart();
    }

    @AfterClass
    public static void tearDownOnce() throws Exception {
        DatabaseOperation.DELETE_ALL.execute(getConnection(), getDataSet());
        JdbcUtils.closeConnection(connection);
    }

    @Before
    public void setUp() throws Exception {
        initializeCategory(FIRST_ID, "NAME", "IMAGE", ROOT_ID);

        connection = ConnectionUtility.getNewConnectionIfExistedIsNull(connection, driverManagerDataSource);

        DatabaseOperation.DELETE_ALL.execute(getConnection(), getDataSet());
        DatabaseOperation.CLEAN_INSERT.execute(getConnection(), getDataSet());
    }

    @Test
    public void getByParentId() throws Exception {
        List<Category> result = testTarget.getByParentId(ROOT_ID);

        List<Category> lastResultCategoryChildren = result.get(result.size() - 1).getChildren();
        assertTrue(Every.everyItem(Matchers.hasProperty("parentId", equalTo(ROOT_ID))).matches(result));
        assertThat(lastResultCategoryChildren).isNotEmpty();
        assertThat(lastResultCategoryChildren.get(0).getParentId()).isEqualTo(FIRST_ID);
    }

    @Test
    public void getByParentIdLazy() throws Exception {
        List<Category> result = testTarget.getByParentIdLazy(ROOT_ID);

        assertTrue(Every.everyItem(Matchers.hasProperty("parentId", equalTo(ROOT_ID))).matches(result));
        assertTrue(Every.everyItem(Matchers.hasProperty("children", Matchers.hasSize(0))).matches(result));
    }

    @Test
    public void save() throws Exception {
        DatabaseOperation.DELETE_ALL.execute(getConnection(), getDataSet());

        testTarget.save(category);

        assertThat(category.getId()).isNotEqualTo(0);
    }

    @Test
    public void delete() throws Exception {
        testTarget.delete(category);

        assertThat(SqlQueryJdbcExecutionUtility.isExists("select 1 from Category where categoryId = %1$d",
                connection, category.getId()));
    }

    @Test
    public void update() throws Exception {
        initializeCategory(FIRST_ID, "NEW NAME", "NEW IMAGE", 3);

        testTarget.update(category);

        assertThat(SqlQueryJdbcExecutionUtility.isExists("select 1 from Category where categoryId = %1$d " +
                        "and categoryName = '%2$s' and  categoryImage = '%3$s' and  categoryParentId = %4$d",
                connection, category.getId(), category.getName(),
                category.getImage(), category.getParentId()));
    }

    private static IDatabaseConnection getConnection() throws Exception {
        return new DatabaseDataSourceConnection(driverManagerDataSource);
    }

    private static IDataSet getDataSet() throws Exception {
        return new FlatXmlDataSetBuilder().build(new FileInputStream("src/test/resources/categories.xml"));
    }

    private void initializeCategory(long id, String name, String image, long parentId) {
        category = new Category(id);
        category.setName(name);
        category.setImage(image);
        category.setParentId(parentId);
        category.setParentId(parentId);
    }
}
