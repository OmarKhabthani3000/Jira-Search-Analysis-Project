package com.electronic.commerce.dao.utilities;

import org.h2.tools.Server;

import java.sql.SQLException;

/**
 * @author Arthur Kharkivsky
 * @since 03.03.2016
 */
public class H2Server {
    private static Server instance;

    public static void initializeIfRequiredAndStart() throws SQLException {
        if (instance == null) {
            instance = Server.createTcpServer("-tcpAllowOthers").start();
        }
    }
}
