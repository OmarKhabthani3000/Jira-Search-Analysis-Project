DROP TABLE IF EXISTS CATEGORY;

CREATE TABLE CATEGORY (
  categoryId       BIGINT          AUTO_INCREMENT,
  categoryName     VARCHAR         NOT NULL,
  categoryImage    VARCHAR,
  categoryParentId BIGINT          NOT NULL,
  PRIMARY KEY (categoryId)
)