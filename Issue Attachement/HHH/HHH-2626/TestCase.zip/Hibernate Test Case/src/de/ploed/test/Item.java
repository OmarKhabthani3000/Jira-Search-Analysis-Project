package de.ploed.test;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Item {
  @Id
  @GeneratedValue
  private long id;
  
  private String description;
  
  private Long articleNumber;
  
  @Embedded
  private MonetaryAmount price;

  public String getDescription() {
    return description;
  }

  public long getId() {
    return id;
  }

  public MonetaryAmount getPrice() {
    return price;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setId(long id) {
    this.id = id;
  }

  public void setPrice(MonetaryAmount price) {
    this.price = price;
  }

  public Long getArticleNumber() {
    return articleNumber;
  }

  public void setArticleNumber(Long articleNumber) {
    this.articleNumber = articleNumber;
  }
  
  @Override
  public int hashCode() {
    final int PRIME = 31;
    int result = 1;
    result = PRIME * result + ((articleNumber == null) ? 0 : articleNumber.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    final Item other = (Item) obj;
    if (articleNumber == null) {
      if (other.articleNumber != null)
        return false;
    } else if (!articleNumber.equals(other.articleNumber))
      return false;
    return true;
  }
 
}
