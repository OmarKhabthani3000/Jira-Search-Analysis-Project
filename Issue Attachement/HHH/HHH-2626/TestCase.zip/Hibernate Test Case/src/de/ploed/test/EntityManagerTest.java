package de.ploed.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Session;


public class EntityManagerTest {

  /**
   * @param args
   */
  public static void main(String[] args) {
//  Use persistence.xml configuration
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("manager1");
    EntityManager em = emf.createEntityManager(); // Retrieve an application managed entity manager
    em.getTransaction().begin();
    
    Item i = new Item();
    i.setArticleNumber(System.currentTimeMillis());
    i.setDescription("iPhone");
    em.merge(i);
    em.getTransaction().commit();
    em.close();
    emf.close(); //close at application end

  }


}
