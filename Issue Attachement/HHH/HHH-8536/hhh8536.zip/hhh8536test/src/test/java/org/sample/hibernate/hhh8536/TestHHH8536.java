package org.sample.hibernate.hhh8536;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Iterator;

import org.hibernate.MappingException;
import org.hibernate.cfg.Configuration;
import org.hibernate.mapping.Column;
import org.hibernate.mapping.Table;
import org.junit.Test;

public class TestHHH8536 {

	private static class ConfigurationForTest extends Configuration {
		private static final long serialVersionUID = 1L;

		@Override
		public void secondPassCompile() throws MappingException {
			// Make this operation available to the test.
			super.secondPassCompile();
		}
	}
	
	private void assertFKLength(Configuration config) {
		Iterator<Table> tabIter = config.getTableMappings();
		Table tableB = null;
		// There should be a table B, with a foreign key column FK_A, with length 8.
		while (tabIter.hasNext()) {
			Table t = tabIter.next();
			if ("B".equals(t.getName())) {
				tableB = t;
				break;
			}
		}
		assertNotNull("Table B should exist", tableB);
		Iterator<?> colIter = tableB.getColumnIterator();
		Column fkCol = null;
		while(colIter.hasNext()) {
			Column c = (Column) colIter.next();
			if ("FK_A".equals(c.getName())) {
				fkCol = c;
				break;
			}
		}
		assertNotNull("Column FK_A should exist", fkCol);
		assertEquals("FK_A length", 8, fkCol.getLength());		
	}
	
	private void doFKTest(ConfigurationForTest config) {
		config.addAnnotatedClass(A.class);
		config.addAnnotatedClass(B.class);
		config.setProperty("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
		config.secondPassCompile();
		assertFKLength(config);		
	}
	
	@Test
	public void testForeignKeyColumnHasCorrectLength() {
		doFKTest(new ConfigurationForTest());
	}

}
