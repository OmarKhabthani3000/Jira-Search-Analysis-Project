package org.sample.hibernate.hhh8536;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class B_Key implements Serializable {
	
	private static final long serialVersionUID = 1L;

	public B_Key() {}
	
	private String aId;
	
	@Column(name = "BB", length = 1)
	private String b;
	
	public String getAId() {
		return aId;
	}
	
	public void setAId(String value) {
		aId = value;
	}
	
	public String getB() {
		return b;
	}
	
	public void setB(String value) {
		b = value;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null || !(obj.getClass().equals(this.getClass()))) return false;
		B_Key other = (B_Key) obj;
		return (aId == null && other.aId == null || aId != null && aId.equals(other.aId)) &&
			(b == null && other.b == null || b != null && b.equals(other.b));
	}
	
	@Override
	public int hashCode() {
		return (aId == null ? 0 : aId.hashCode()) ^ (b == null ? 0 : b.hashCode());
	}
}
