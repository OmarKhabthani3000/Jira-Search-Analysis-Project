package org.sample.hibernate.hhh8536;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;

@Entity
public class B {
	
	@EmbeddedId
	private B_Key id;
	
	@MapsId("aId")
	@ManyToOne
	@JoinColumn(name = "FK_A", nullable=false)
	// Hibernate bug HHH-8536 will make this column have the default length 255 instead of the specified length 8.
	// Only work-around appears to be the non-portable columnDefinition..., or not naming the column.
	private A a;
	
}
