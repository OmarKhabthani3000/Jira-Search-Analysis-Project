package org.sample.hibernate.hhh8536;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class A {
	@Id
	@Column(name="AID", length=8)
	private String id;	
}
