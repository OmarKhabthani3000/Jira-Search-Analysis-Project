package org.hibernate.bugs;

import java.util.Collections;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a standalone test case for Hibernate ORM.  Although this is perfectly
 * acceptable as a reproducer, usage of ORMUnitTestCase is preferred!
 */
public class ORMStandaloneTestCase {

	private SessionFactory sf;

	@Before
	public void setup() {
		StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
			// Add in any settings that are specific to your test. See resources/hibernate.properties for the defaults.
			.applySetting( "hibernate.show_sql", "true" )
			.applySetting( "hibernate.format_sql", "true" )
			.applySetting( "hibernate.hbm2ddl.auto", "update" );

		Metadata metadata = new MetadataSources( srb.build() )
		// Add your entities here.
			.addInputStream( getClass().getResourceAsStream( "/student.hbm.xml" ) )
			.buildMetadata();

		sf = metadata.buildSessionFactory();
	}

	// Add your tests, using standard JUnit.

	@Test
	public void setCompositeElementTest() throws Exception {
		try( Session session = sf.openSession() ) {
			session.beginTransaction();

			EnrollableClass aClass = new EnrollableClass();
			aClass.setId( "123" );
			aClass.setName( "Math");
			session.save( aClass );
			
			Student aStudent = new Student();
			aStudent.setId( "s1" );
			aStudent.setFirstName( "John" );
			aStudent.setLastName( "Smith" );
			
			EnrolledClassSeat seat = new EnrolledClassSeat();
			seat.setId( "seat1" );
			seat.setRow( 10 );
			seat.setColumn( 5 );
			
			StudentEnrolledClass enrClass = new StudentEnrolledClass();
			enrClass.setEnrolledClass( aClass );
			enrClass.setClassStartTime( 130 );
			enrClass.setSeat( seat );
			aStudent.setEnrolledClasses( Collections.singleton( enrClass ) );
			session.save( aStudent );
			
			session.getTransaction().commit();
		}
	}
}
