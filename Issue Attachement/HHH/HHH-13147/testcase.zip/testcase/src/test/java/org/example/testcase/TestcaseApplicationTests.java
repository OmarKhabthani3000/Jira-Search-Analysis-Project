package org.example.testcase;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.transaction.TestTransaction;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class TestcaseApplicationTests {

	@Autowired
	private EntityManager em;

	@Test
	public void failsOnCommit() {
		org.example.testcase.SomeEntity entity = new org.example.testcase.SomeEntity();
		em.persist(entity);
		entity.setName("foo");
		em.persist(entity);
		em.flush();
		em.clear();
		TestTransaction.flagForCommit();
		TestTransaction.end();
	}
}
