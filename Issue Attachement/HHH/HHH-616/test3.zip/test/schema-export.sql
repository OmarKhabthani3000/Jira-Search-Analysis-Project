alter table bar drop foreign key FK17C1350798B16
alter table donut drop foreign key FK5B54F221EEF6F96
alter table foo drop foreign key FK18CC617581076
drop table if exists bar
drop table if exists donut
drop table if exists foo
create table bar (bar_id varchar(255) not null, donut_id varchar(255), primary key (bar_id))
create table donut (id varchar(255) not null, foo_id varchar(255), primary key (id))
create table foo (foo_id varchar(255) not null, prop1 varchar(255), bar_id varchar(255), primary key (foo_id))
alter table bar add index FK17C1350798B16 (donut_id), add constraint FK17C1350798B16 foreign key (donut_id) references donut (id)
alter table donut add index FK5B54F221EEF6F96 (foo_id), add constraint FK5B54F221EEF6F96 foreign key (foo_id) references foo (foo_id)
alter table foo add index FK18CC617581076 (bar_id), add constraint FK18CC617581076 foreign key (bar_id) references bar (bar_id)
