package data;

import java.util.List;

/**
 * User: dtashima
 * Date: May 25, 2005
 * Time: 1:43:03 PM
 */
public class Foo
{
    private String id;
    private String prop1;
    private Bar bar;

    public String getId()
    {
        return this.id;
    }
    public void setId(String x)
    {
        this.id = x;
    }

    public String getProp1()
    {
        return this.prop1;
    }
    public void setProp1(String x)
    {
        this.prop1 = x;
    }

    public Bar getBar()
    {
        return this.bar;
    }
    public void setBar(Bar x)
    {
        this.bar = x;
    }

//    public int getIndex()
//    {
//        Bar b = getBar();
//        if(b != null)
//        {
//            List l = b.getFoos();
//            if(l != null)
//                return l.indexOf(this);
//        }
//        return -1;
//    }
//
//    public void setIndex(int n)
//    {
//    
//    }

}
