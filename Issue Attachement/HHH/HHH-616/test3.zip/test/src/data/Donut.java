package data;
import java.util.Calendar;

public class Donut {
	private Foo foo;
	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Foo getFoo()
	{
		return foo;
	}

	public void setFoo(Foo foo)
	{
		this.foo = foo;
	}

	
}
