import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.hibernate.EntityMode;
import org.hibernate.HibernateException;
import org.hibernate.ReplicationMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import data.Donut;

public class DonutTest {

	    public static void main(String[] args)
	    {
//	        setup();
//	        createDocument();
//	        reconstitute();
	    }
//
//	    private static void reconstitute()
//	    {
//	        try
//	        {
//	            SAXReader reader = new SAXReader();
//	            Document doc = reader.read(new File("content.xml"));
//
//	            Session session = currentSession();
//	            Session s = session.getSession(EntityMode.DOM4J);
//	            Transaction txn = s.beginTransaction();
//
//	            {
//	                List elems = doc.getRootElement().elements();
//	                Iterator it = elems.iterator();
//	                while(it.hasNext())
//	                {
//	                    Element e = (Element)it.next();
//	                    log.debug(e.getName());
//	                    if(e.getName().equals("Donut"))
//	                        s.replicate("data.Donut",e, ReplicationMode.IGNORE);
//	                }
//	            }
//
//	            txn.commit();
//	        }
//	        catch(DocumentException e)
//	        {
//	            log.error(e);
//	        }
//	    }
//	    
//	    private static void createDocument() {
//	        Session sess;
//	        sess = currentSession();
//	        Session s = sess.getSession(EntityMode.DOM4J);
//
//	        Document doc = DocumentHelper.createDocument();
//	        Element root = doc.addElement("root");
//
//	        List results = s.createQuery("from Donut donut").list();
//	        addResultsToNode(results, root);
//
//
//	        OutputFormat format = OutputFormat.createPrettyPrint();
//	        try
//	        {
//	            XMLWriter writer = new XMLWriter(new FileWriter("content.xml"), format);
//	            writer.write(doc);
//	            writer.close();
//	        }
//	        catch(IOException ioe)
//	        {
//
//	        }
//
//	    }
//
//	    private static void setup() {
//	        Session sess;
//	        Transaction txn;
//	        try
//	        {
//	            sess = currentSession();
//	            txn = sess.beginTransaction();
//	            Donut d = new Donut();
//	            d.setDuh(new GregorianCalendar());
//
//	            sess.save(d);
//
//	            sess.flush();
//	            txn.commit();
//	            closeSession();
//	        }
//	        catch(HibernateException he)
//	        {
//	            log.error("error", he);
//	        }
//	    }
//
//	    private static void addResultsToNode(List results, Element root)
//	    {
//	        for (Iterator i = results.iterator(); i.hasNext();) {
//	            Element e = (Element) i.next();
//	            if(e != null)
//	            {
//	                log.debug("e: "+e.toString());
//	                root.add(e);
//	            }
//	        }
//	    }
//	    private static final SessionFactory sessionFactory;
//
//	    private static final Set sessions = new HashSet();
//
//	    static {
//	        try {
//	            sessionFactory = new Configuration()
//	                .configure().buildSessionFactory();
//	        } catch (HibernateException ex) {
//	            throw new RuntimeException("Exception building SessionFactory: " + ex.getMessage(), ex);
//	        }
//	    }
//	    public static final ThreadLocal session = new ThreadLocal();
//
//	    public static Session currentSession() throws HibernateException {
//	        Session s = (Session) session.get();
//	        // Open a new Session, if this Thread has none yet
//	        if (s == null) {
//	            s = sessionFactory.openSession();
//	            session.set(s);
//	            sessions.add(s);
//	            //            if(debug)
//	            {
//	                log.debug("Creating new Hibernate Session: " + Thread.currentThread().getName());
//	            }
//	        }
//	        else
//	        {
//	                log.debug("Returning existing session: "+s.toString());
//	        }
//	        return s;
//	    }
//	    public static void closeSession()
//	        throws HibernateException
//	    {
//	        Session s = (Session) session.get();
//	        session.set(null);
//	        if (s != null)
//	            s.close();
//	        //        if(debug)
//	        {
//	            log.debug("Closing Hibernate Session: "+ (s != null ? s.toString() : "null" ));
//	            sessions.remove(s);
//	        }
//	    }
//	    private static Logger log = null;
//	    static
//	    {
//	        log = Logger.getLogger(DonutTest.class);
//	    }

}
