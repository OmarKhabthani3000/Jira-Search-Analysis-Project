package data;

import java.util.List;

/**
 * User: dtashima
 * Date: May 25, 2005
 * Time: 1:43:30 PM
 */
public class Bar
{
    private String id;
    private String prop2;
    private List foos;

    public String getId()
    {
        return this.id;
    }
    public void setId(String x)
    {
        this.id = x;
    }

    public String getProp2()
    {
        return this.prop2;
    }
    public void setProp2(String x)
    {
        this.prop2 = x;
    }

    public List getFoos()
    {
        return foos;
    }
    public void setFoos(List l)
    {
        this.foos = l;
    }

}
