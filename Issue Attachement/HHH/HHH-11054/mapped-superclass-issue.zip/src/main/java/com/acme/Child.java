package com.acme;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;

@Getter
@Setter
@Entity
public class Child extends Parent {
  private String childProperty;
}
