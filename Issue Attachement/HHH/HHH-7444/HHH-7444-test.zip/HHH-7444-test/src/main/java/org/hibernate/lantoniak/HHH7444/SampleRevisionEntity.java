package org.hibernate.lantoniak.HHH7444;

import org.hibernate.envers.RevisionEntity;
import org.hibernate.envers.RevisionTimestamp;

import javax.persistence.Entity;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@RevisionEntity
@Table(name = "my_revinfo", schema = "ENVERS_AUDIT")
@SequenceGenerator(name = "idgen", sequenceName = "revinfo_sequence", schema = "ENVERS_AUDIT")
public class SampleRevisionEntity extends MyDefaultRevisionEntity {
    private static final long serialVersionUID = 7256725444183445951L;

    @RevisionTimestamp
    private Long timestamp;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SampleRevisionEntity)) return false;
        if (!super.equals(o)) return false;

        SampleRevisionEntity that = (SampleRevisionEntity) o;

        if (timestamp != null ? !timestamp.equals(that.timestamp) : that.timestamp != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (timestamp != null ? timestamp.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SampleRevisionEntity(" + super.toString() + ", timestamp = " + timestamp + ")";
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }
}
