package org.hibernate.lantoniak.HHH7444;

import org.hibernate.envers.RevisionNumber;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;

@MappedSuperclass
public class MyDefaultRevisionEntity implements Serializable {
    private static final long serialVersionUID = 4378851786827555312L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "idgen")
    @RevisionNumber
    private int id;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MyDefaultRevisionEntity)) return false;

        MyDefaultRevisionEntity that = (MyDefaultRevisionEntity) o;

        if (id != that.id) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return id;
    }

    @Override
    public String toString() {
        return "MyDefaultRevisionEntity(id = " + id + ")";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}