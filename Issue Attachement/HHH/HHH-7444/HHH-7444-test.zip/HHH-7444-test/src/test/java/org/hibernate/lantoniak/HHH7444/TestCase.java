package org.hibernate.lantoniak.HHH7444;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionStatus;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/spring-config.xml"})
public class TestCase {
    @Autowired
    JpaTransactionManager transactionManager;

    @PersistenceContext
    private EntityManager em;

    @Test
    public void testSequenceSchema() {
        TransactionStatus tx = transactionManager.getTransaction( null );
        em.persist( new StringEntity( "data" ) );
        Object schemaName = em.createNativeQuery(
                "SELECT owner " +
                        "  FROM all_objects " +
                        " WHERE object_name = 'REVINFO_SEQUENCE'"
        ).getSingleResult();
        Assert.assertEquals( "ENVERS_AUDIT", schemaName );
        transactionManager.commit(tx);
    }
}
