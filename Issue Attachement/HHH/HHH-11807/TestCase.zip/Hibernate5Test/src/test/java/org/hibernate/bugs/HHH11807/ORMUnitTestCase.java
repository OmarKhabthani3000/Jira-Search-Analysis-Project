/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs.HHH11807;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.bugs.HHH11807.entity.PurchaseItem;
import org.hibernate.bugs.HHH11807.entity.PurchaseOrder;
import org.hibernate.bugs.HHH11807.entity.enhance.EnhancedPurchaseItem;
import org.hibernate.bugs.HHH11807.entity.enhance.EnhancedPurchaseOrder;
import org.hibernate.engine.spi.ManagedEntity;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Before;
import org.junit.Test;

public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	@Override
	protected Class<?>[] getAnnotatedClasses() {
		return new Class<?>[] {
			PurchaseOrder.class,
			PurchaseItem.class,
			EnhancedPurchaseOrder.class,
			EnhancedPurchaseItem.class
		};
	}
	
	@Before
	public void prepare() {
		Session s = openSession();
		try {
			s.beginTransaction();
			
			PurchaseOrder purchaseOrder = new PurchaseOrder(1L, 10L, 1000L);
			List<PurchaseItem> purchaseItems = new ArrayList<>();
			purchaseItems.add(new PurchaseItem(1L, 100L, purchaseOrder));
			purchaseItems.add(new PurchaseItem(2L, 200L, purchaseOrder));
			purchaseOrder.setPurchaseItems(purchaseItems);
			s.persist(purchaseOrder);

			EnhancedPurchaseOrder enhancedPurchaseOrder = new EnhancedPurchaseOrder(1L, 10L, 1000L);
			List<EnhancedPurchaseItem> enhancedPurchaseItems = new ArrayList<>();
			enhancedPurchaseItems.add(new EnhancedPurchaseItem(1L, 100L, enhancedPurchaseOrder));
			enhancedPurchaseItems.add(new EnhancedPurchaseItem(2L, 200L, enhancedPurchaseOrder));
			enhancedPurchaseOrder.setPurchaseItems(enhancedPurchaseItems);
			s.persist(enhancedPurchaseOrder);

			s.getTransaction().commit();
			
		} catch (Exception e) {
			s.getTransaction().rollback();
			throw e;
		} finally {
			s.close();
		}
	}

	@Test
	public void test() {
		assertEquals(false, ManagedEntity.class.isAssignableFrom(PurchaseOrder.class));
		assertEquals(true, ManagedEntity.class.isAssignableFrom(EnhancedPurchaseOrder.class));
		
		byte[] serializedPurchaseOrder;
		byte[] serializedEnhancedPurchaseOrder;
		
		{
			Session s = openSession();
			try {
				s.beginTransaction();
	
				PurchaseOrder purchaseOrder = s.get(PurchaseOrder.class, 1L);
				assertEquals(Long.valueOf(2L), (Long)s.createQuery("SELECT COUNT(*) FROM PurchaseItem").getSingleResult());

				EnhancedPurchaseOrder enhancedPurchaseOrder = s.get(EnhancedPurchaseOrder.class, 1L);
				assertEquals(Long.valueOf(2L), (Long)s.createQuery("SELECT COUNT(*) FROM EnhancedPurchaseItem").getSingleResult());
				//enhancedPurchaseOrder.getPurchaseItems().size(); // if collection is loaded, cascade delete works

				s.getTransaction().commit();
				
				// simulate object serialized into http response
				serializedPurchaseOrder = SerializationUtil.serialize(purchaseOrder);
				serializedEnhancedPurchaseOrder = SerializationUtil.serialize(enhancedPurchaseOrder);
				
			} catch (Exception e) {
				s.getTransaction().rollback();
				throw e;
			} finally {
				s.close();
			}
		}
		
		{
			// simulate object deserialized from http request
			PurchaseOrder purchaseOrder = (PurchaseOrder)SerializationUtil.deserialize(serializedPurchaseOrder);
			EnhancedPurchaseOrder enhancedPurchaseOrder = (EnhancedPurchaseOrder)SerializationUtil.deserialize(serializedEnhancedPurchaseOrder);

			Session s = openSession();
			try {
				s.beginTransaction();

				s.delete(purchaseOrder);
				s.flush();
				assertEquals(Long.valueOf(0L), (Long)s.createQuery("SELECT COUNT(*) FROM PurchaseItem").getSingleResult());

				s.delete(enhancedPurchaseOrder);
				s.flush(); // this raises database constant violation error because child entities are not deleted beforehand.
				assertEquals(Long.valueOf(0L), (Long)s.createQuery("SELECT COUNT(*) FROM EnhancedPurchaseItem").getSingleResult());

				s.getTransaction().commit();
				
			} catch (Exception e) {
				s.getTransaction().rollback();
				throw e;
			} finally {
				s.close();
			}
		}
	}
}
