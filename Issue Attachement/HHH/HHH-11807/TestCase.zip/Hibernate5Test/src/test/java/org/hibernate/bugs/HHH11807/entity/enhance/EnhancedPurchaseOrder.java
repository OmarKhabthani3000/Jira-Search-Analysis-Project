package org.hibernate.bugs.HHH11807.entity.enhance;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.ListIndexBase;
import org.hibernate.annotations.SelectBeforeUpdate;

@Entity
@DynamicUpdate
@SelectBeforeUpdate
public class EnhancedPurchaseOrder implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long purchaseOrderId;
	private Long customerId;
	private Long totalAmount;
	
	@OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "purchaseOrderId", nullable = false)
    @OrderColumn(name = "indexNumber")
    @ListIndexBase(1)
	private List<EnhancedPurchaseItem> purchaseItems;

	public EnhancedPurchaseOrder() {
	}
	
	public EnhancedPurchaseOrder(Long purchaseOrderId, Long customerId, Long totalAmount) {
		this.purchaseOrderId = purchaseOrderId;
		this.customerId = customerId;
		this.totalAmount = totalAmount;
	}

	public Long getPurchaseOrderId() {
		return purchaseOrderId;
	}

	public void setPurchaseOrderId(Long purchaseOrderId) {
		this.purchaseOrderId = purchaseOrderId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Long getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Long totalAmount) {
		this.totalAmount = totalAmount;
	}

	public List<EnhancedPurchaseItem> getPurchaseItems() {
		return purchaseItems;
	}

	public void setPurchaseItems(List<EnhancedPurchaseItem> purchaseItems) {
		this.purchaseItems = purchaseItems;
	}

}
