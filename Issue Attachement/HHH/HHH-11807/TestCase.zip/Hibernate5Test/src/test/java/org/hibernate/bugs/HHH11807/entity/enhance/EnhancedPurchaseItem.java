package org.hibernate.bugs.HHH11807.entity.enhance;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.SelectBeforeUpdate;

@Entity
@DynamicUpdate
@SelectBeforeUpdate
public class EnhancedPurchaseItem implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	private Long purchaseItemId;
	private Long itemId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "purchaseOrderId", nullable = false, updatable = false, insertable = false)
	private EnhancedPurchaseOrder purchaseOrder;
	
	public EnhancedPurchaseItem() {
	}

	public EnhancedPurchaseItem(Long purchaseItemId, Long itemId, EnhancedPurchaseOrder purchaseOrder) {
		this.purchaseItemId = purchaseItemId;
		this.itemId = itemId;
		this.purchaseOrder = purchaseOrder;
	}

	public Long getPurchaseItemId() {
		return purchaseItemId;
	}

	public void setPurchaseItemId(Long purchaseItemId) {
		this.purchaseItemId = purchaseItemId;
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public EnhancedPurchaseOrder getPurchaseOrder() {
		return purchaseOrder;
	}

	public void setPurchaseOrder(EnhancedPurchaseOrder purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}

}
