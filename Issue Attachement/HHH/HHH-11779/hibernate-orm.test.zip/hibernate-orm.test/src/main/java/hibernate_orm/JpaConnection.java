package hibernate_orm;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JpaConnection {

    private EntityManagerFactory entityManagerFactory = null;

    private EntityManager entityManager = null;

    public void store(Container container) throws Exception {
        entityManager.getTransaction()
                     .begin();
        entityManager.persist(container);
        entityManager.flush();
        entityManager.getTransaction()
                     .commit();
    }

    public void updateOrder(Container container) throws Exception {
        entityManager.getTransaction()
                     .begin();
        Element first = container.elements.get(0);
        container.elements.remove(0);
        container.elements.add(first);

        entityManager.merge(container);

        entityManager.getTransaction()
                     .commit();
    }

    public JpaConnection open() {
        entityManagerFactory = Persistence.createEntityManagerFactory("default");
        entityManager = entityManagerFactory.createEntityManager();

        return this;
    }

    public void close() {
        if (entityManager != null) {
            entityManager.close();
        }
        if (entityManagerFactory != null) {
            entityManagerFactory.close();
        }
    }
}
