package hibernate_orm.test;

import org.junit.Test;

import hibernate_orm.Container;
import hibernate_orm.Element;
import hibernate_orm.JpaConnection;

public class AppTest {

    @Test
    public void shouldChangeElementOrder() throws Exception {

        Container containerForTest = new Container();
        Element e1 = new Element();
        e1.name = "Foo";
        containerForTest.elements.add(e1);

        Element e2 = new Element();
        e2.name = "Bar";
        containerForTest.elements.add(e2);

        JpaConnection jpaConnection = new JpaConnection().open();
        try {
            jpaConnection.store(containerForTest);

            jpaConnection.updateOrder(containerForTest);
        } finally {
            jpaConnection.close();
        }
    }

}