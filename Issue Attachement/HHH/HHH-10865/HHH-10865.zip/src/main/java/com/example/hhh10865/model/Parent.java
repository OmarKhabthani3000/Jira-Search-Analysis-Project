package com.example.hhh10865.model;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "parents")
public class Parent implements Serializable
{

    private static final long serialVersionUID = 1L;
    private Long id;
    private Set<String> names;
    private Set<Child> children;

    @Id
    @Column(name = "id", unique = true, nullable = false)
    public Long getId()
    {
        return this.id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    @ElementCollection
    @CollectionTable(
            name = "parents_names",
            joinColumns = @JoinColumn(name = "parent")
    )
    @Column(name = "name", unique = true, nullable = false)
    public Set<String> getNames()
    {
        return this.names;
    }

    public void setNames(Set<String> secrets)
    {
        this.names = secrets;
    }

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "parents_children", joinColumns =
    {
        @JoinColumn(name = "parent", nullable = false)
    }, inverseJoinColumns =
    {
        @JoinColumn(name = "child", nullable = false)
    })
    public Set<Child> getChildren()
    {
        return this.children;
    }

    public void setChildren(Set<Child> children)
    {
        this.children = children;
    }

}
