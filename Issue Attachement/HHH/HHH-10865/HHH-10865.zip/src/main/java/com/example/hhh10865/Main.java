package com.example.hhh10865;

import com.example.hhh10865.model.Child;
import com.example.hhh10865.model.Parent;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataBuilder;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.SessionFactoryBuilder;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Main implements AutoCloseable
{

    public static void main(final String[] arguments)
    {
        try (final Main main = new Main())
        {
            main.setup();
            main.test();
        }
    }

    public Main()
    {
        final StandardServiceRegistryBuilder registryBuilder = new StandardServiceRegistryBuilder();
        registryBuilder.configure();
        final StandardServiceRegistry registry = registryBuilder.build();
        final MetadataSources metadataSources = new MetadataSources(registry);
        final MetadataBuilder metadataBuilder = metadataSources.getMetadataBuilder();
        final Metadata metadata = metadataBuilder.build();
        final SessionFactoryBuilder sessionFactoryBuilder = metadata.getSessionFactoryBuilder();
        this.sessionFactory = sessionFactoryBuilder.build();
    }

    private final SessionFactory sessionFactory;

    public void setup()
    {
        try (final Session session = sessionFactory.openSession())
        {
            final Transaction transaction = session.beginTransaction();
            final Parent parent = new Parent();
            parent.setId(1L);
            parent.setNames(Collections.singleton("name"));
            session.save(parent);
            transaction.commit();
        }
    }

    public void test()
    {
        try
        {
            try (final Session session = sessionFactory.openSession())
            {
                final Transaction transaction = session.beginTransaction();
                final Parent parent = session.get(Parent.class, 1L);
                Set<Child> children = parent.getChildren();
                if (children == null)
                {
                    children = new HashSet<>();
                    parent.setChildren(children);
                }
                final Child child = new Child();
                child.setId(1L);
                session.save(child);
                children.add(child);
                //parent.getNames();
                session.save(parent);
                transaction.commit();
            }
            try (final Session session = sessionFactory.openSession())
            {
                final Parent application = session.get(Parent.class, 1L);
                final Set<Child> children = application.getChildren();
                final int count = children.size();
                if (count != 1)
                {
                    throw new RuntimeException("Child count is " + count + ". Child hasn't been added to parent?!");
                }
            }
        } catch (final Exception exception)
        {
            exception.printStackTrace(System.err);
        }
    }

    @Override
    public void close()
    {
        sessionFactory.close();
    }

}
