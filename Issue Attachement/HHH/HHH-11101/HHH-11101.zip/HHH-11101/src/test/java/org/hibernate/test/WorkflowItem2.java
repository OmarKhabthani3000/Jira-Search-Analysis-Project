package org.hibernate.test;

import java.util.List;

public final class WorkflowItem2 {
    private static final long serialVersionUID = 1L;

    private Long id;

    private String name;
    private List<WorkflowItem2> childs;
    public WorkflowItem2() {
    }

    public void setChilds(List<WorkflowItem2> newChilds) {
        childs = newChilds;
    }

    public List<WorkflowItem2> getChilds() {
        return childs;
    }
    public String getName() {
        return name;
    }
    public void setName(String newName) {
        name = newName;
    }
}
