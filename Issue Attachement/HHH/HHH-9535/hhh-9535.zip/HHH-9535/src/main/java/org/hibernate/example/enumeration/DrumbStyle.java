package org.hibernate.example.enumeration;

public enum DrumbStyle {
	SNARE,
	BONGO;

}
