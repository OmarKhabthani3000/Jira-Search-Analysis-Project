package org.hibernate.example.enumeration;

public enum InstrumentType {
	GUITAR,
	DRUMB;

}
