package org.hibernate.example.enumeration;

public enum GuitarType {
	SIXSTRING,
	BASS;

}
