package org.hibernate.cache.test.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE, region="test")
public class Child {

	private long id;
	private Parent parent;

	@Id
	@SequenceGenerator(
			name = "CHILD_SEQ",
			sequenceName = "CHILD_SEQ",
			initialValue = 1,
			allocationSize = 1
			)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CHILD_SEQ")
	public long getId() {
		return id;
	}

	protected void setId(long id) {
		this.id = id;
	}

	@ManyToOne(fetch=FetchType.LAZY)
	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}
}
