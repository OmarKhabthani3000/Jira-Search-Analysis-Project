package org.hibernate.cache.test.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE, region="test")
public class Parent {

	private long id;
	private List<Child> children;

	@Id
	@SequenceGenerator(
			name = "PARENT_SEQ",
			sequenceName = "PARENT_SEQ",
			initialValue = 1,
			allocationSize = 1
			)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PARENT_SEQ")
	public long getId() {
		return id;
	}

	protected void setId(long id) {
		this.id = id;
	}

	@OneToMany(mappedBy="parent",cascade={CascadeType.ALL})
	@Cache(usage=CacheConcurrencyStrategy.READ_WRITE, region="test")
	public List<Child> getChildren() {
		return children;
	}

	public void setChildren(List<Child> children) {
		this.children = children;
	}

}
