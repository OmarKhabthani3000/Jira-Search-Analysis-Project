package org.hibernate.cache.test.application;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cache.test.model.Child;
import org.hibernate.cache.test.model.Parent;
import org.hibernate.cache.test.util.HibernateUtils;
import org.hibernate.stat.Statistics;

public class Test extends TestCase{

	public static void testDefaultHibernateCache(){
		try{
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("org.hibernate.cache.test");
			SessionFactory factory = entityManagerFactory.unwrap(SessionFactory.class);		
			Statistics statistics = factory.getStatistics();
			statistics.setStatisticsEnabled(true);
			Session session;

			// create a parent and its child in one session
			session = factory.openSession();
			session.beginTransaction();
			Parent parent = new Parent();
			List<Child> children = new ArrayList<Child>();
			parent.setChildren(children);
			Child child = new Child();
			child.setParent(parent);
			children.add(child);		
			session.persist(parent);
			session.flush();
			session.getTransaction().commit();
			session.close();

			// now get the whole stuff from the second level cache
			session = factory.openSession();		
			parent = (Parent)session.get(Parent.class, parent.getId());
			child = parent.getChildren().get(0);

			// obviously the cache has missed the collection :(
			assertTrue(statistics.getSecondLevelCacheMissCount()>0);
			factory.close();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}

	public static void testWithForcedCache(){
		try{
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("org.hibernate.cache.test");
			SessionFactory factory = entityManagerFactory.unwrap(SessionFactory.class);		
			Statistics statistics = factory.getStatistics();
			statistics.setStatisticsEnabled(true);
			Session session;

			// create a parent and its child in one session
			session = factory.openSession();
			session.beginTransaction();
			Parent parent = new Parent();
			List<Child> children = new ArrayList<Child>();
			parent.setChildren(children);
			Child child = new Child();
			child.setParent(parent);
			children.add(child);		
			session.persist(parent);
			session.flush();
			session.getTransaction().commit();
			
			///////////////////////////////////////////////////////////
			// BEFORE closing the session, force the cache to have the 
			// collection Lock readable as we could (should?..) expect 
			// from a READ_WRITE cache strategy once the session has 
			// been commited and closed
			///////////////////////////////////////////////////////////
			HibernateUtils.unlockCollections(session);
						
			session.close();

			// now get the whole stuff from the second level cache
			session = factory.openSession();		
			parent = (Parent)session.get(Parent.class, parent.getId());
			child = parent.getChildren().get(0);

			// thanks the little hibernate helper, we can find the 
			// collection without hiting the database 
			assertTrue(statistics.getSecondLevelCacheMissCount()==0);
			
			factory.close();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}



}
