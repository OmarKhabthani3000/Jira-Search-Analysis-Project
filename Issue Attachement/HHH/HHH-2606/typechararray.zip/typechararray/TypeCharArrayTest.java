//$Id: ArrayTest.java 10976 2006-12-12 23:22:26Z steve.ebersole@jboss.com $
package org.hibernate.test.typechararray;

import junit.framework.Test;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;

/**
 * @author Emmanuel Bernard
 */
public class TypeCharArrayTest extends FunctionalTestCase {

	public TypeCharArrayTest(String x) {
		super( x );
	}

	public String[] getMappings() {
		return new String[] { "typechararray/A.hbm.xml" };
	}

	public static Test suite() {
		return new FunctionalTestClassTestSuite( TypeCharArrayTest.class );
	}

	public void testCharArrayDirtyness() throws Exception {
		Session s;
		Transaction tx;
		s = openSession();
		tx = s.beginTransaction();
		A a = new A();
		a.setChars(new char[]{'a','b','c'});
		s.persist( a );
		tx.commit();
		s.close();

		s = openSession();
		tx = s.beginTransaction();
		a = (A) s.get( A.class, a.getId() );

		assertFalse("Session should not be dirty at this point",s.isDirty());		
		
		s.delete(a);
		tx.commit();
		s.close();
	}
}
