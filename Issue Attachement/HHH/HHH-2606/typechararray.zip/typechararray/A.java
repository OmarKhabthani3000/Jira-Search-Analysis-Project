
package org.hibernate.test.typechararray;

/**
 * @author Aymeric Levaux
 */
public class A {
	private Integer id;
	private char[] chars;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public char[] getChars() {
		return chars;
	}

	public void setChars(char[] chars) {
		this.chars = chars;
	}
}
