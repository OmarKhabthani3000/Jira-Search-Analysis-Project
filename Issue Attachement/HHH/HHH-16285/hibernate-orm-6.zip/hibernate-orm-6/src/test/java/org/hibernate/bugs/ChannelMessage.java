package org.hibernate.bugs;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

@Entity
@Table(name = "messages")
@Getter
@Setter
public class ChannelMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private long id;

    @Generated(GenerationTime.INSERT)
    @Column(name = "channel_id", nullable = false, insertable = false, updatable = false)
    private long channelId;

    @ManyToOne(fetch = FetchType.LAZY)
    private ChatChannel channel;
}
