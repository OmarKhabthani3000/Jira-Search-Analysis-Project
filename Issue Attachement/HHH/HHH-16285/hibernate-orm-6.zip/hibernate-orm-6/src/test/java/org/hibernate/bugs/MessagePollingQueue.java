package org.hibernate.bugs;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "message_polling_queue")
@Getter
@Setter
public class MessagePollingQueue {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long revision;

    @Column(insertable = false, updatable = false)
    private long messageId;

    @Column(insertable = false, updatable = false)
    private long channelId;

    @ManyToOne
    @JoinColumns({
            @JoinColumn(name = "channelId", referencedColumnName = "channel_id"),
            @JoinColumn(name = "messageId", referencedColumnName = "id")
    })
    private ChannelMessage message;
}
