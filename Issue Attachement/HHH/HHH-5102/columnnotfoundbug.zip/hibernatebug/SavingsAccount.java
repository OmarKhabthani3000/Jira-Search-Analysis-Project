
package hibernatebug;


import javax.persistence.*;


/**
 * 
 * TODO: [MODEL] Im UML-Modell kommentieren.
 */
@Entity
@Table(name = "SAVINGS_ACCOUNT")
@PrimaryKeyJoinColumn(name = "SAVACC_ACC_ID")
public class SavingsAccount extends SavingsAccountBase
{
}