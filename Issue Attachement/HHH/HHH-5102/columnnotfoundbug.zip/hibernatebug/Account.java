
package hibernatebug;


import javax.persistence.*;


/**
 * 
 * TODO: [MODEL] Im UML-Modell kommentieren.
 */
@Entity
@Table(name = "ACCOUNT")
@Inheritance(strategy = InheritanceType.JOINED)
public class Account extends AccountBase
{
}