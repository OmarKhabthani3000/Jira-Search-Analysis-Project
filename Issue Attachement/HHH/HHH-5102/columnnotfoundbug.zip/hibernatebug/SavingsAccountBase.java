
package hibernatebug;


import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;


/**
 * 
 * WARNING: Please don't edit this .java file.
 * This .java file is generated.
 * 
 * TODO: [MODEL] Im UML-Modell kommentieren.
 */
@MappedSuperclass
public abstract class SavingsAccountBase extends Account
{

	/**
	 * Attribut: withdrawalLimit.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 */
	@Column(name = "SAVACC_WITHDRAWALLIMIT")
	private BigDecimal withdrawalLimit;


	/**
	 * Getter des Attributs: withdrawalLimit:BigDecimal.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 *
	 * @return
	 */
	public BigDecimal getWithdrawalLimit() {
		return withdrawalLimit;
	}

	/**
	 * Setter des Attributs: withdrawalLimit:BigDecimal.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 *
	 * @param withdrawalLimit
	 */
	public void setWithdrawalLimit(BigDecimal withdrawalLimit) {
		this.withdrawalLimit = withdrawalLimit;
	}

	@Override
	public String toString() {
		StringBuffer stringBuffer = new StringBuffer(super.toString()); stringBuffer.append("\n");
		stringBuffer.append("\toid: " + getId() + "\n");
		stringBuffer.append("\twithdrawalLimit:BigDecimal{SAVACC_WITHDRAWALLIMIT} ["); stringBuffer.append(withdrawalLimit); stringBuffer.append("]\n");
		return stringBuffer.toString();
	}
}