
package hibernatebug;


import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;


/**
 * 
 * WARNING: Please don't edit this .java file.
 * This .java file is generated.
 * 
 * TODO: [MODEL] Im UML-Modell kommentieren.
 */
@MappedSuperclass
public abstract class AccountBase /*implements DomainBase*/
{
	/**
	 * Object-Id
	 */
	@Id
	@org.hibernate.annotations.GenericGenerator(name = "generator::at.ing.diba.domain.bug.Account", strategy = "seqhilo",
	                                            parameters = { @org.hibernate.annotations.Parameter(name="sequence", value = "SEQ_ACC"),
	                                                           @org.hibernate.annotations.Parameter(name="max_lo", value = "100"),
	                                                           @org.hibernate.annotations.Parameter(name="parameters", value = "minvalue 1 start with 1 increment by 1 nocache") })
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator::at.ing.diba.domain.bug.Account")
	@Column(name = "ACC_ID", columnDefinition = "NUMBER(38, 0)")
	private Long id;

	/**
	 * Versioning for optimistic locking
	 */
	@Version
	@Column(name = "ACC_VERSION", nullable = false)
	private Integer version;

	/**
	 * Attribut: iban.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 */
	@Column(name = "ACC_IBAN")
	private String iban;

	/**
	 * Getter der Object-Id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Versioning for optimistic locking
	 */
	public Integer getVersion() {
		return version;
	}
	
	/**
	 * Ueberschreibe diese Methode um die grundlegende Initialisierung der Instanz zu erreichen.
	 */
	public void initialize() {
	}

	@Override
	public boolean equals(Object other) {
		if (this == other)
			return true;
		else {
			if (other instanceof Account) {
				if (getId() == null)
					return businessKeyEquals((Account)other);
				else
					return getId().equals(((Account)other).getId());
			} else
				return false;
		}
	}

	/**
	 * 
	 * Override this method for business key equality by using for example
	 * EqualsBuilder().append(..., other....).append(..., other....).isEquals();
	 * 
	 * @return  true if this object is the same as the obj argument; false otherwise.
	 */
	protected boolean businessKeyEquals(Account other) {
		return false;
	}

	/**
	 * Getter des Attributs: iban:String.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 *
	 * @return
	 */
	public String getIban() {
		return iban;
	}

	/**
	 * Setter des Attributs: iban:String.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 *
	 * @param iban
	 */
	public void setIban(String iban) {
		this.iban = iban;
	}

	@Override
	public String toString() {
		StringBuffer stringBuffer = new StringBuffer(super.toString()); stringBuffer.append("\n");
		stringBuffer.append("\toid: " + getId() + "\n");
		stringBuffer.append("\tiban:String{ACC_IBAN} ["); stringBuffer.append(iban); stringBuffer.append("]\n");
		return stringBuffer.toString();
	}
}