package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Version;

@Entity
public class JPAEntity {

    @Id
    @GeneratedValue
    public Long id;

    @Version
    public Long version;

    public String name;
}
