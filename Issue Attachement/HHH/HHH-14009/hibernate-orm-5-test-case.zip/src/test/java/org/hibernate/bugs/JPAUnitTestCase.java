package org.hibernate.bugs;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.LockModeType;
import javax.persistence.Persistence;

import org.hibernate.testing.FailureExpected;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    @Test
    public void lockModeTypeOptimisticForceIncrementWithPristineEntityTest() throws Exception {
        // Arrange
        final EntityManager entityManager = entityManagerFactory.createEntityManager();

        entityManager.getTransaction().begin();
        final JPAEntity arrangeEntity = new JPAEntity();

        arrangeEntity.name = "Name";
        entityManager.persist(arrangeEntity);
        entityManager.getTransaction().commit();

        // Act
        entityManager.getTransaction().begin();
        final JPAEntity actEntity = entityManager.find(JPAEntity.class, 1L);

        entityManager.lock(actEntity, LockModeType.OPTIMISTIC_FORCE_INCREMENT);
        entityManager.getTransaction().commit();

        // Assert
        entityManager.getTransaction().begin();
        final JPAEntity assertEntity = entityManager.find(JPAEntity.class, 1L);

        entityManager.close();
        entityManager.getTransaction().commit();

        assertThat(assertEntity.id, is(1L));
        assertThat(assertEntity.version, is(1L));
        assertThat(assertEntity.name, is("Name"));
    }

    @FailureExpected(jiraKey = "", message = "")
    @Test
    public void lockModeTypeOptimisticForceIncrementWithDirtyEntityTest() throws Exception {
        // Arrange
        final EntityManager entityManager = entityManagerFactory.createEntityManager();

        entityManager.getTransaction().begin();
        final JPAEntity arrangeEntity = new JPAEntity();

        arrangeEntity.name = "Name";
        entityManager.persist(arrangeEntity);
        entityManager.getTransaction().commit();

        // Act
        entityManager.getTransaction().begin();
        final JPAEntity actEntity = entityManager.find(JPAEntity.class, 1L);

        actEntity.name = "NewName";
        entityManager.lock(actEntity, LockModeType.OPTIMISTIC_FORCE_INCREMENT);
        entityManager.getTransaction().commit();

        // Assert
        entityManager.getTransaction().begin();
        final JPAEntity assertEntity = entityManager.find(JPAEntity.class, 1L);

        entityManager.close();
        entityManager.getTransaction().commit();

        assertThat(assertEntity.id, is(1L));
        assertThat(assertEntity.version, is(1L));
        assertThat(assertEntity.name, is("NewName"));
    }
}
