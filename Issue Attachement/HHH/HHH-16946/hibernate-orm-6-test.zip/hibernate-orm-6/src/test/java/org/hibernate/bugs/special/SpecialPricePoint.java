package org.hibernate.bugs.special;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.NonFinal;
import org.hibernate.annotations.Cache;

import java.io.Serializable;

import static jakarta.persistence.CascadeType.*;
import static lombok.AccessLevel.PACKAGE;
import static lombok.AccessLevel.PROTECTED;
import static org.hibernate.annotations.CacheConcurrencyStrategy.READ_WRITE;

@Getter
@Entity
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(onlyExplicitlyIncluded = true)
@Table(name = "SPECIAL_OPERATOR_PRICES_POINTS")
@IdClass(SpecialPricePoint.SpecialPricePointPK.class)
@NoArgsConstructor(access = PROTECTED)
public class SpecialPricePoint {

    public SpecialPricePoint(SpecialOperator operator,
                             String wholesalePrice) {
        this.operator = operator;
        this.wholesalePrice = wholesalePrice;
    }

    @ManyToOne
    @ToString.Include
    @Setter(PACKAGE)
    @EqualsAndHashCode.Include
    @JoinColumn(name = "PROVIDER_ID", referencedColumnName = "PROVIDER_ID")
    @JoinColumn(name = "OPERATOR_ID", referencedColumnName = "OPERATOR_ID")
    @MapsId
    private SpecialOperator operator;

    @Id
    @Column(name = "PRICE_POINT", nullable = false)
    @ToString.Include
    @EqualsAndHashCode.Include
    String wholesalePrice;

    @OneToOne(mappedBy = "wholesalePrice", cascade = {PERSIST, MERGE, REMOVE}, orphanRemoval = true)
    @Cache(usage = READ_WRITE)
    private SpecialProduct product;

    public void setProduct(SpecialProduct product) {
        product.setWholesalePrice(this);
        this.product = product;

    }

    @Value
    @Embeddable
    @NoArgsConstructor(access = PROTECTED)
    @AllArgsConstructor
    public static class SpecialPricePointPK implements Serializable {
        @Embedded
        @NonFinal
        @AttributeOverride(name = "provider", column = @Column(name = "PROVIDER_ID", nullable = false))
        @AttributeOverride(name = "operatorId", column = @Column(name = "OPERATOR_ID", nullable = false))
        SpecialOperator.SpecialOperatorPK operator;

        @NonFinal
        String wholesalePrice;
    }
}
