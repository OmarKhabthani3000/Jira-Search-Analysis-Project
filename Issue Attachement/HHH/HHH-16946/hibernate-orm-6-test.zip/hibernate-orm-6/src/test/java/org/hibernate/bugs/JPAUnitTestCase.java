package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.hibernate.bugs.special.Provider;
import org.hibernate.bugs.special.SpecialOperator;
import org.hibernate.bugs.special.SpecialOperator.SpecialOperatorPK;
import org.hibernate.bugs.special.SpecialPricePoint;
import org.hibernate.bugs.special.SpecialPricePoint.SpecialPricePointPK;
import org.hibernate.bugs.special.SpecialProduct;
import org.hibernate.bugs.special.SpecialProduct.SpecialProductPK;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hibernate.bugs.special.Provider.A;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void shouldDeleteProduct() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        // Do stuff...
        // given
        String operatorId = "OPERATOR_1";
        Provider provider = A;
        SpecialOperator specialOperator = new SpecialOperator(provider, operatorId);
        entityManager.persist(specialOperator);
        String wholesalePrice = "1 EUR";
        SpecialPricePoint specialPricePoint = new SpecialPricePoint(specialOperator, wholesalePrice);
        entityManager.persist(specialPricePoint);
        String productId = "PRODUCT_1";
        SpecialProduct specialProduct = new SpecialProduct(productId, specialPricePoint);
        entityManager.persist(specialProduct);
        entityManager.getTransaction().commit();
        entityManager.getTransaction().begin();
        SpecialPricePoint pricePoint = entityManager.find(SpecialPricePoint.class, new SpecialPricePointPK(new SpecialOperatorPK(provider, operatorId), wholesalePrice));
        assertThat(pricePoint).isNotNull();


        // when
        SpecialProduct product = entityManager.find(SpecialProduct.class, new SpecialProductPK(new SpecialPricePointPK(new SpecialOperatorPK(provider,
                operatorId),
                wholesalePrice),
                productId));
        assertThat(product).isNotNull();
        entityManager.remove(product);
        entityManager.getTransaction().commit();
        entityManager.getTransaction().begin();
        // Then
        SpecialProduct product1 = entityManager.find(SpecialProduct.class, new SpecialProductPK(new SpecialPricePointPK(new SpecialOperatorPK(provider,
                operatorId),
                wholesalePrice),
                productId));
        assertThat(product1).isNull();
        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
