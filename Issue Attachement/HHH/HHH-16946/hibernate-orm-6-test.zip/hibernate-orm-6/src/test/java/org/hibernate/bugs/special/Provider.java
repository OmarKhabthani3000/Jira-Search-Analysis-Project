package org.hibernate.bugs.special;

public enum Provider {
    A,
    B
}
