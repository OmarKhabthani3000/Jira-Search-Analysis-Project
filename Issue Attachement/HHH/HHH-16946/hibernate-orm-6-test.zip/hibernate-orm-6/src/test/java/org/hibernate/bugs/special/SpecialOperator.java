package org.hibernate.bugs.special;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.io.Serializable;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

import static jakarta.persistence.CascadeType.*;
import static lombok.AccessLevel.PROTECTED;
import static org.hibernate.annotations.CacheConcurrencyStrategy.READ_WRITE;

@Getter
@Entity
@ToString(onlyExplicitlyIncluded = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@IdClass(SpecialOperator.SpecialOperatorPK.class)
@Table(name = "SPECIAL_OPERATORS")
@Cacheable
@Cache(usage = READ_WRITE)
@NoArgsConstructor(access = PROTECTED)
public class SpecialOperator {

    @EqualsAndHashCode.Include
    @ToString.Include
    @Id
    private Provider provider;

    @EqualsAndHashCode.Include
    @ToString.Include
    @Id
    private String operatorId;

    @OneToMany(mappedBy = "operator", cascade = {PERSIST, MERGE, REMOVE}, orphanRemoval = true)
    private final Set<SpecialPricePoint> pricePoints = new HashSet<>();

    @CreationTimestamp
    @Column(name = "CREATION_DATE", nullable = false, updatable = false)
    private Instant creationDate;

    @UpdateTimestamp
    @Column(name = "MODIFICATION_DATE", nullable = false)
    private Instant modificationDate;

    public void addPricePoint(SpecialPricePoint pricePoint) {
        pricePoint.setOperator(this);
        pricePoints.add(pricePoint);
    }

    public SpecialOperator(Provider provider, String operatorId) {
        this.provider = provider;
        this.operatorId = operatorId;
    }

    @EqualsAndHashCode
    @ToString
    @Getter
    @NoArgsConstructor(access = PROTECTED)
    @AllArgsConstructor
    @Embeddable
    public static class SpecialOperatorPK implements Serializable {
        @Enumerated(EnumType.STRING)
        @Column(name = "PROVIDER_ID", nullable = false)
        Provider provider;

        @Column(name = "OPERATOR_ID", nullable = false)
        String operatorId;
    }
}
