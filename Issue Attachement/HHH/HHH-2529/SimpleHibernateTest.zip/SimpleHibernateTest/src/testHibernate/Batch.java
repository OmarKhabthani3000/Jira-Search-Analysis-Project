package testHibernate;

import java.util.HashSet;
import java.util.Set;


public class Batch {

    private Integer _id;
    private String _name;
    private Set<Loan> _loans;
    
    public Batch() {
        super();
    }

    
    public Integer getId() {
        return _id;
    }

    
    public void setId(Integer id) {
        _id = id;
    }

    
    public String getName() {
        return _name;
    }

    
    public void setName(String name) {
        _name = name;
    }

    public Set<Loan> getLoans() {
        return _loans;
    }

    public void setLoans(Set<Loan> loans) {
        _loans = loans;
    }
    
    public void addLoan(Loan l) {
        if (getLoans() == null) {
            setLoans(new HashSet<Loan>());
        }
        getLoans().add(l);
    }
    public boolean removeLoan(Loan l) {
        if (getLoans() == null) {
            setLoans(new HashSet<Loan>());
        }
        return getLoans().remove(l);
    }

}
