package testHibernate;


import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class TestMapping {

    private static final Logger logger = Logger.getLogger(TestMapping.class);
    
    //@Test
    public void testCreateMap() {
        Batch b = new Batch();
        b.setName("Batch 2");
        
        Loan l = new Loan();
        l.setLoanNumber("2001");
        b.addLoan(l);
        
        l = new Loan();
        l.setLoanNumber("2002");
        b.addLoan(l);

        l = new Loan();
        l.setLoanNumber("2003");
        b.addLoan(l);
        
        Transaction t = HibernateSessionFactory.getSession().beginTransaction();
        BatchDAO.getInstance().save(b);
        t.commit();
        HibernateSessionFactory.closeSession();
    }
    
    @Test
    public void testRetrieve() {
        
        String queryString = "SELECT b.loans FROM Batch AS b WHERE b.id = :id ORDER BY b.loans.loanNumber DESC";
        String countString = "SELECT count(b.loans.id) FROM Batch AS b WHERE b.id = :id";
        Integer id = new Integer(1);
        Query listQ = HibernateSessionFactory.getSession().createQuery(queryString);
        listQ.setParameter("id", id);
        //HashSet loans = new HashSet();
        //loans.addAll(listQ.list());
        List loansSQL = listQ.list();
        Query countQ = HibernateSessionFactory.getSession().createQuery(countString);
        countQ.setParameter("id", id);
        Long count = (Long) countQ.uniqueResult();        
        
        logger.debug("  Count                  -> " + count);
        logger.debug("  # Retrieved (SQL)      -> " + loansSQL.size());
    }
    
    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

}
