package testHibernate;


public class BatchDAO {

    private static final BatchDAO INSTANCE = new BatchDAO();
    private BatchDAO() {
        
    }
    
    public static BatchDAO getInstance() {
        return INSTANCE;
    }
    
    public void save(Batch batch) {
        for (Loan l : batch.getLoans()) {
            HibernateSessionFactory.getSession().saveOrUpdate(l);
        }
        HibernateSessionFactory.getSession().saveOrUpdate(batch);
    }
}
