package testHibernate;


public class Loan {

    private Integer _id;
    private String _loanNumber;
    
    public Loan() {
        super();
    }
    
    public Integer getId() {
        return _id;
    }
    
    public void setId(Integer id) {
        _id = id;
    }
    
    public String getLoanNumber() {
        return _loanNumber;
    }
    
    public void setLoanNumber(String loanNumber) {
        _loanNumber = loanNumber;
    }

    @Override
    public boolean equals(Object obj) {
        boolean answer = false;
        try {
            Loan other = (Loan) obj;
            answer = (hashCode() == other.hashCode());
        } catch (ClassCastException e) {
        }
        return answer;
    }

    @Override
    public int hashCode() {
        int answer = super.hashCode();
        if (getId() != null) {
            answer = getId().hashCode();
        }
        return answer;
    }
    
    
}
