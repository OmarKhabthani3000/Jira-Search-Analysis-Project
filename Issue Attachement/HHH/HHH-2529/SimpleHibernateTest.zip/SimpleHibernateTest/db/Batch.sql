USE p2sc
go
CREATE TABLE dbo.TestBatch
(
    id   int         NOT NULL,
    name varchar(80) NOT NULL
)
LOCK ALLPAGES
go

USE p2sc
go
ALTER TABLE dbo.TestBatch ADD CONSTRAINT pkTestBatch
PRIMARY KEY NONCLUSTERED (id)
go
