USE p2sc
go
CREATE TABLE dbo.TestMapping
(
    batchId int NOT NULL,
    loanId  int NOT NULL
)
LOCK ALLPAGES
go

USE p2sc
go
ALTER TABLE dbo.TestMapping ADD CONSTRAINT pkTestMapping
PRIMARY KEY NONCLUSTERED (batchId,loanId)
go

USE p2sc
go
ALTER TABLE dbo.TestMapping ADD CONSTRAINT TestMap2Batch
FOREIGN KEY (batchId)
REFERENCES p2sc.dbo.TestBatch (id)
go

USE p2sc
go
ALTER TABLE dbo.TestMapping ADD CONSTRAINT TestMap2Loan
FOREIGN KEY (loanId)
REFERENCES p2sc.dbo.TestLoan (id)
go
