USE p2sc
go
CREATE TABLE dbo.TestLoan
(
    id   int         NOT NULL,
    name varchar(80) NOT NULL
)
LOCK ALLPAGES
go

USE p2sc
go
ALTER TABLE dbo.TestLoan ADD CONSTRAINT pkTestLoan
PRIMARY KEY NONCLUSTERED (id)
go


