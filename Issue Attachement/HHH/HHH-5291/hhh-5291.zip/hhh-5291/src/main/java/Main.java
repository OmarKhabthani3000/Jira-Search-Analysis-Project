import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: inikolaev
 * Date: 12/19/13
 * Time: 11:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class Main {
    public static void main(String[] args) {
        Configuration cfg = new Configuration()
            .addResource("hibernate.hbm.xml")
            .setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect")
            .setProperty("hibernate.hbm2ddl.auto", "update")
            .setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:hhh-5291")
            .setProperty("hibernate.connection.username", "SA")
            .setProperty("hibernate.show_sql", "true")
            .setProperty("hibernate.format_sql", "true")
            ;

        SessionFactory sessions = cfg.buildSessionFactory();
        Session session = sessions.openSession();

        List result = session.createCriteria(TestSubclass.class).list();

        session.close();
        sessions.close();
    }
}
