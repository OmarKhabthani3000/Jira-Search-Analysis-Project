/**
 * Created with IntelliJ IDEA.
 * User: inikolaev
 * Date: 12/20/13
 * Time: 12:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class TestSubclass extends TestClass{
    private String property3;

    public String getProperty3() {
        return property3;
    }

    public void setProperty3(String property3) {
        this.property3 = property3;
    }
}
