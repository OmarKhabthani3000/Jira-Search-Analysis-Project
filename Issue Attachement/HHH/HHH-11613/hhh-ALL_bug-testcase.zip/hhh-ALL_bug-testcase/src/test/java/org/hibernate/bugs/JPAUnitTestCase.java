package org.hibernate.bugs;

import java.util.*;

import javax.persistence.*;

import org.junit.*;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hibernateTest() throws Exception
	{
		EntityManager entityManager = this.entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		// Do stuff...					field 			field2
		MyRecord record1 = new MyRecord(new Integer(50), new Integer(30));
		MyRecord record2 = new MyRecord(new Integer(20), new Integer(40));
		MyRecord record3 = new MyRecord(new Integer(110), new Integer(70));

		entityManager.persist(record1);
		entityManager.persist(record2);
		entityManager.persist(record3);

		// should retrieve 2 records : 1 and 2
		List<MyRecord> records = entityManager.createQuery(
			"select e from MyRecord e WHERE( NOT( e.field > ALL (select t.field2 from MyRecord t) ) )",
			MyRecord.class)
			.getResultList();

		Assert.assertEquals(2, records.size());
		// end off stuff

		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
