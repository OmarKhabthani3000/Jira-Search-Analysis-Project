package org.hibernate.bugs;

import javax.persistence.*;

/**
 */
@Entity
class MyRecord
{
    @Id
    @GeneratedValue
    private Long id;

    private Integer field;

    private Integer field2;

    public MyRecord()
    {
    }

    public MyRecord(Integer field, Integer field2)
    {
        this.field = field;
        this.field2 = field2;
    }

    public Long getId()
    {
        return this.id;
    }

    public Integer getField()
    {
        return this.field;
    }

    public Integer getField2()
    {
        return this.field2;
    }
}