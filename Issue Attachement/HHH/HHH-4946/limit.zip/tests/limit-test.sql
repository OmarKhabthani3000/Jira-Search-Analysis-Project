drop table CCBAG\p\g
drop table Contained\p\g
drop table Container\p\g
drop table Fum\p\g
drop table Fumm\p\g
drop table Holder\p\g
drop table LCCBAG\p\g
drop table Location\p\g
drop table MoreStuff\p\g
drop table Part\p\g
drop table Simple\p\g
drop table Sortable\p\g
drop table Stuff\p\g
drop table Vetoer\p\g
drop table X\p\g
drop table Y\p\g
drop table "bxaxg"\p\g
drop table "foos"\p\g
drop table "glarchez"\p\g
drop table "the fees"\p\g
drop table abcd\p\g
drop table anyToAny\p\g
drop table bar_join_table\p\g
drop table baz\p\g
drop table baz_byte_bag\p\g
drop table baz_floats_bag\p\g
drop table baz_foo\p\g
drop table baz_id_foo\p\g
drop table bazcomponents\p\g
drop table cached_map\p\g
drop table cached_set\p\g
drop table components\p\g
drop table composites\p\g
drop table customs\p\g
drop table fees\p\g
drop table foes\p\g
drop table fooArray\p\g
drop table fooComponentToFoo\p\g
drop table fooComponents\p\g
drop table fooToGlarch\p\g
drop table foo_dates\p\g
drop table foo_dep_table\p\g
drop table foo_times\p\g
drop table foobytes\p\g
drop table fums\p\g
drop table immut\p\g
drop table importantDates\p\g
drop table int_array\p\g
drop table jointable\p\g
drop table many\p\g
drop table manyToAny\p\g
drop table manyToMany\p\g
drop table moreParts\p\g
drop table one\p\g
drop table quux\p\g
drop table stringArray\p\g
drop table stringDateMap\p\g
drop table stringSet\p\g
drop table string_list\p\g
drop table stringmap\p\g
drop table strings\p\g
drop table ternaryMap\p\g
drop table ternarySet\p\g
drop table timeArray\p\g
drop table topcomponents\p\g
drop table xxx\p\g
drop sequence hibernate_sequence restrict\p\g
drop table hibernate_unique_key\p\g
create table CCBAG (container_id bigint not null, contained_id bigint not null)\p\g
create table Contained (container_id bigint not null, primary key (container_id))\p\g
create table Container (container_id bigint not null, primary key (container_id))\p\g
create table Fum (string_ varchar(10) not null, short_ smallint not null, date_ ansidate not null, vid smallint not null, fum varchar(255) not null, TString varchar(255) with null, fo_string varchar(10) with null, fo_short smallint with null, fo_date ansidate with null, count_ integer with null, qux_id bigint with null, posn integer with null, fr_string_ varchar(10) with null, fr_short_ smallint with null, fr_date_ ansidate with null, fum_str_ varchar(10) with null, fum_sho_ smallint with null, fum_dat_ ansidate with null, fummapindex varchar(255) with null, primary key (string_, short_, date_))\p\g
create table Fumm (string_ varchar(10) not null, short_ smallint not null, date_ ansidate not null, locale varchar(255) with null, primary key (string_, short_, date_))\p\g
create table Holder (id_ varchar(32) not null, name varchar(36) not null unique, otherHolder varchar(255) with null, primary key (id_))\p\g
create table LCCBAG (container_id bigint not null, contained_id bigint not null)\p\g
create table Location (streetNumber integer not null, streetName varchar(20) not null, city varchar(20) not null, countryCode varchar(2) not null, locale varchar(255) with null, description varchar(255) with null, primary key (streetNumber, streetName, city, countryCode))\p\g
create table MoreStuff (intId integer not null, stringId varchar(32) not null, name varchar(255) with null, primary key (intId, stringId))\p\g
create table Part (id bigint not null, clazz varchar(255) not null, description varchar(255) with null, baz varchar(32) with null, primary key (id))\p\g
create table Simple (id_ bigint not null, name varchar(255) with null, address varchar(255) with null, count_ integer not null unique, date_ timestamp(9) with time zone with null, pay float with null, other bigint with null, container_id1 bigint with null, list_index integer with null, primary key (id_))\p\g
create table Sortable (id integer not null, name varchar(255) with null, baz varchar(32) with null, primary key (id))\p\g
create table Stuff (id bigint not null, foo varchar(36) not null, moreInt integer not null, moreString varchar(32) not null, property varchar(255) with null, primary key (id, foo, moreInt, moreString))\p\g
create table Vetoer (id_ varchar(32) not null, name varchar(255) with null, strings varbyte(255) with null, primary key (id_))\p\g
create table X (xid bigint not null, primary key (xid))\p\g
create table Y (yid bigint not null, x varchar(255) with null, primary key (yid))\p\g
create table "bxaxg" ("baz_id_" varchar(32) not null, "name_" varchar(255) with null)\p\g
create table "foos" ("foo_idcolumnname123" varchar(36) not null, "foo_subclass_1234" char(1) not null, version integer not null, foo varchar(36) with null, long_ bigint not null, "integer__" integer not null, float_ float not null check (float_ > 0.0), x integer with null, double_ float with null, date_ ansidate with null, timestamp_ timestamp(9) with time zone with null, boolean_ tinyint with null, bool_ tinyint with null, null_ integer with null, short_ smallint with null, char_ char(1) with null, zero_ float with null, int_ integer with null, string_ varchar(48) with null, byte_ tinyint with null, yesno char(1) with null, blobb_ varbyte(255) with null, nullBlob varbyte(255) with null, bin_ varbyte(255) with null, "localeayzabc123" varchar(255) with null, first_name varchar(66) with null, surname varchar(66) with null, count_ integer not null, name_ varchar(32) not null, g__ varchar(32) with null, cmpnt_null_ varchar(255) with null, subname varchar(255) with null, fee_sub varchar(64) with null, null_cmpnt_ varchar(255) with null, the_time time with time zone with null, baz varchar(32) with null, bar_string varchar(24) with null, bar_count integer with null, name varchar(64) with null, clazz char(1) with null, gen_id bigint with null, abstract_id varchar(36) with null, baz_id varchar(32) with null, idtopbar varchar(32) with null, idofbaz varchar(32) with null, baz_compon_id varchar(32) with null, holder1 varchar(32) with null, j1 integer with null, holder2 varchar(32) with null, primary key ("foo_idcolumnname123"), unique (long_, "integer__", float_))\p\g
create table "glarchez" (tha_key varchar(32) not null, version integer not null, namecvbnmasdf varchar(255) with null, next_ varchar(32) with null, order_ smallint with null, foo varchar(255) with null, bar integer with null, x integer with null, immutable varchar(255) not null, "any_id_of_object" varchar(255) with null, "any_class_of_object" varbyte(255) with null, count_ integer with null, glarch_ varchar(255) with null, gtf_baz_id varchar(32) with null, gtf_foo_id varchar(36) with null, idtopglarch varchar(32) with null, mapkey char(1) with null, baz_map_id varchar(32) with null, baz_map_index varchar(255) with null, array_key varchar(32) with null, array_indecks integer with null, set_key varchar(32) with null, primary key (tha_key))\p\g
create table "the fees" (id_ varchar(64) not null, fi varchar(255) with null, fee varchar(64) with null, anotherFee varchar(64) with null, qux bigint with null, count_ integer with null, name varchar(255) with null, null_prop varchar(255) with null, bazid varchar(32) with null, bazind integer with null, primary key (id_), check (bazind is null or (bazind>=0 and bazind<10)))\p\g
create table abcd (container_id bigint not null, name varchar(255) with null, simple bigint with null, one bigint not null, many bigint not null)\p\g
create table anyToAny (baz varchar(32) not null, el_clazz_ varchar(255) with null, el_id_ bigint with null, ind_clazz_ varchar(255) not null, ind_id_ bigint not null, primary key (baz, ind_clazz_, ind_id_))\p\g
create table bar_join_table (bar_id varchar(36) not null, name_name varchar(255) with null, primary key (bar_id))\p\g
create table baz (baz_id_column_ varchar(32) not null, count_count integer with null, name_b varchar(255) with null, foo varchar(36) with null, superBaz varchar(32) with null, str varchar(255) with null, "baz-id" varchar(32) with null, primary key (baz_id_column_), check (count_count > -666))\p\g
create table baz_byte_bag (baz varchar(32) not null, bytez varbyte(255) not null, pkid bigint not null, primary key (pkid))\p\g
create table baz_floats_bag (baz_compon_id varchar(32) not null, float_value float with null)\p\g
create table baz_foo (baz varchar(32) not null, foo varchar(36) not null)\p\g
create table baz_id_foo (baz varchar(32) not null, foo varchar(36) not null, pkid bigint not null, primary key (pkid))\p\g
create table bazcomponents (baz_id varchar(32) not null, name varchar(56) with null, count_ integer with null, x_ varchar(255) with null, y_ integer with null, i integer not null, primary key (baz_id, i))\p\g
create table cached_map (baz varchar(32) not null, foo varchar(255) with null, bar varchar(255) with null, another_baz varchar(32) not null, primary key (baz, another_baz))\p\g
create table cached_set (baz varchar(32) not null, foo varchar(255) not null, bar varchar(255) not null, primary key (baz, foo, bar))\p\g
create table components (container_id bigint not null, name varchar(255) with null, count_ integer with null, simple bigint with null, one bigint with null, many bigint with null, list_index integer not null, primary key (container_id, list_index))\p\g
create table composites (container_id bigint not null, name varchar(255) with null, simple bigint with null, one bigint with null, many bigint with null)\p\g
create table customs (id_ varchar(32) not null, first_ varchar(255) with null, second_ varchar(255) with null, indx integer not null, primary key (id_, indx))\p\g
create table fees (fee_id varchar(64) not null, str_ varchar(255) not null, primary key (fee_id, str_))\p\g
create table foes (string_ varchar(20) not null, short_ smallint not null, date_ ansidate not null, version bigint not null, serial_ varbyte(255) with null, buf varbyte(255) with null, x integer with null, primary key (string_, short_, date_))\p\g
create table fooArray (id_ varchar(32) not null, foo varchar(36) not null, i integer not null, primary key (id_, i), check (i>=0))\p\g
create table fooComponentToFoo (baz_id varchar(32) not null, foo_id varchar(36) not null, name varchar(32) not null, count_ integer not null, primary key (baz_id, name, count_))\p\g
create table fooComponents (glarch_key varchar(32) not null, name_ varchar(255) with null, count_ integer with null, x_ varchar(255) with null, y_ integer with null, fee varchar(64) with null, tha_indecks integer not null, primary key (glarch_key, tha_indecks))\p\g
create table fooToGlarch (baz_id varchar(32) not null, glarch_id varchar(32) not null, foo_id varchar(36) not null, primary key (baz_id, foo_id))\p\g
create table foo_dates (foo_id varchar(36) not null, date_ ansidate with null, i integer not null, primary key (foo_id, i))\p\g
create table foo_dep_table (fooid varchar(36) not null, dependent varchar(64) not null, primary key (fooid))\p\g
create table foo_times (foo_id varchar(36) not null, date_ time with time zone with null, i integer not null, primary key (foo_id, i))\p\g
create table foobytes (id varchar(36) not null, byte_ tinyint with null, i integer not null, primary key (id, i))\p\g
create table fums (qux_id bigint not null, fum_string varchar(10) not null, fum_short smallint not null, fum_date ansidate not null, primary key (qux_id, fum_string, fum_short, fum_date))\p\g
create table immut (id_ varchar(64) not null, foo varchar(255) with null, bar varchar(255) with null, primary key (id_))\p\g
create table importantDates (id varchar(36) not null, date_ ansidate with null, i integer not null, primary key (id, i))\p\g
create table int_array (id varchar(32) not null, j integer with null, i integer not null, primary key (id, i))\p\g
create table jointable (fooid varchar(36) not null, joinedProp varchar(255) with null, primary key (fooid))\p\g
create table many (many_key bigint not null, x integer with null, one_key bigint with null, primary key (many_key))\p\g
create table manyToAny (baz varchar(32) not null, el_clazz_ varchar(255) with null, el_id_ varchar(255) with null, ind integer not null, primary key (baz, ind))\p\g
create table manyToMany (container_id2 bigint not null, elt bigint not null, list_index integer not null, primary key (container_id2, list_index))\p\g
create table moreParts (baz varchar(32) not null, part bigint not null)\p\g
create table one (one_key bigint not null, x integer with null, one_value varchar(255) with null, holder varchar(32) with null, i integer with null, primary key (one_key))\p\g
create table quux (qux_key bigint not null, foo varchar(36) with null, deleted tinyint with null, loaded tinyint with null, stored tinyint with null, created tinyint with null, childKey bigint with null, stuff varchar(255) with null, HOLDER_NAME varchar(255) with null, fum_str_ varchar(10) with null, fum_sho_ smallint with null, fum_dat_ ansidate with null, i integer with null, primary key (qux_key))\p\g
create table stringArray (id_ varchar(32) not null, name varchar(255) with null, i integer not null, primary key (id_, i))\p\g
create table stringDateMap (id_ varchar(32) not null, map_value ansidate with null, map_key varchar(32) not null, primary key (id_, map_key))\p\g
create table stringSet (id_ varchar(32) not null, element varchar(32) not null, primary key (id_, element))\p\g
create table string_list (id varchar(32) not null, element varchar(255) with null, "i" integer not null, primary key (id, "i"))\p\g
create table stringmap (fum_str_ varchar(10) not null, fum_sho_ smallint not null, fum_dat_ ansidate not null, mapelement varchar(255) with null, mapindex varchar(255) not null, primary key (fum_str_, fum_sho_, fum_dat_, mapindex))\p\g
create table strings (glarch_key varchar(32) not null, "tha_stryng" varchar(255) with null, "indx_" integer not null, primary key (glarch_key, "indx_"))\p\g
create table ternaryMap (container_id bigint not null, name varchar(255) with null, foo varchar(36) with null, glarch varchar(32) with null, idx varchar(32) not null, primary key (container_id, idx))\p\g
create table ternarySet (container_id bigint not null, name varchar(255) not null, foo varchar(36) not null, glarch varchar(32) not null, primary key (container_id, name, foo, glarch))\p\g
create table timeArray (baz_id varchar(32) not null, the_time time with time zone with null, j integer not null, primary key (baz_id, j))\p\g
create table topcomponents (id_ varchar(32) not null, name varchar(255) with null, count_ integer with null, i integer not null, primary key (id_, i))\p\g
create table xxx (id bigint not null, x bigint not null, primary key (id))\p\g
alter table CCBAG add constraint FK3CF9B8894011F0B foreign key (contained_id) references Contained\p\g
alter table CCBAG add constraint FK3CF9B8894077C4B foreign key (container_id) references Container\p\g
alter table Fum add constraint FK1155ECFEFBDAD foreign key (fum_str_, fum_sho_, fum_dat_) references Fum\p\g
alter table Fum add constraint FK1155E3BB9E3A0 foreign key (fo_string, fo_short, fo_date) references Fum\p\g
alter table Fum add constraint FK1155EA64DB02B foreign key (qux_id) references quux\p\g
alter table Fum add constraint FK1155EB222E1DE foreign key (fr_string_, fr_short_, fr_date_) references Fum\p\g
alter table Fumm add constraint FK2196CF3E81E0B1 foreign key (string_, short_, date_) references Fum\p\g
alter table Holder add constraint FK812BB9CC3939BDD7 foreign key (otherHolder) references Holder (name)\p\g
alter table LCCBAG add constraint FK857FEABC94011F0B foreign key (contained_id) references Contained\p\g
alter table LCCBAG add constraint FK857FEABC94077C4B foreign key (container_id) references Container\p\g
alter table Part add constraint FK25D813DED29727 foreign key (baz) references baz\p\g
alter table Simple add constraint FK939D1DD2939BE031 foreign key (other) references Simple\p\g
alter table Simple add constraint FK939D1DD289A21C6A foreign key (container_id1) references Container\p\g
alter table Sortable add constraint FK66EDF018DED29727 foreign key (baz) references baz\p\g
alter table Stuff add constraint FK4C81DD41B15BDF0 foreign key (moreInt, moreString) references MoreStuff\p\g
alter table Stuff add constraint FK4C81DD4DED2B87D foreign key (foo) references "foos"\p\g
alter table X add constraint FK58435E773D foreign key (xid) references Y\p\g
alter table "bxaxg" add constraint FK59D06FACB5DD78C foreign key ("baz_id_") references baz\p\g
create index fbmtoidx on "foos" (foo, long_)\p\g
create index fbstridx on "foos" (string_)\p\g
alter table "foos" add constraint FK300C6DBBEAE520 foreign key (holder1) references Holder\p\g
alter table "foos" add constraint FK300C6DBBEAE521 foreign key (holder2) references Holder\p\g
alter table "foos" add constraint FK300C6D601671B4 foreign key (baz_compon_id) references baz\p\g
alter table "foos" add constraint FK300C6DF05E6685 foreign key (idtopbar) references baz\p\g
alter table "foos" add constraint FK300C6DDED29727 foreign key (baz) references baz\p\g
alter table "foos" add constraint FK300C6DA4A2707E foreign key (fee_sub) references "the fees"\p\g
alter table "foos" add constraint FK300C6D423011B5 foreign key (idofbaz) references baz\p\g
alter table "foos" add constraint FK300C6D8B9BD6CB foreign key (baz_id) references baz\p\g
alter table "foos" add constraint FK300C6DDED2B87D foreign key (foo) references "foos"\p\g
alter table "foos" add constraint FK300C6D78F5A0B1 foreign key (g__) references "glarchez"\p\g
alter table "foos" add constraint FK300C6D800DF629 foreign key (abstract_id) references "foos"\p\g
alter table "glarchez" add constraint FKC8B52CB010E640D1 foreign key (gtf_foo_id) references "foos"\p\g
alter table "glarchez" add constraint FKC8B52CB07327568E foreign key (baz_map_id) references baz\p\g
alter table "glarchez" add constraint FKC8B52CB07F31E5F6 foreign key (next_) references "glarchez"\p\g
alter table "glarchez" add constraint FKC8B52CB0EF499B2C foreign key (set_key) references "glarchez"\p\g
alter table "glarchez" add constraint FKC8B52CB0240A7DA3 foreign key (array_key) references "glarchez"\p\g
alter table "glarchez" add constraint FKC8B52CB095284B1 foreign key (gtf_baz_id) references baz\p\g
alter table "glarchez" add constraint FKC8B52CB071902CA1 foreign key (idtopglarch) references baz\p\g
alter table "the fees" add constraint FK3DDCB3FCE4640982 foreign key (bazid) references baz\p\g
alter table "the fees" add constraint FK3DDCB3FCDE3EAC1A foreign key (anotherFee) references "the fees"\p\g
alter table "the fees" add constraint FK3DDCB3FCDED2B5FD foreign key (fee) references "the fees"\p\g
alter table "the fees" add constraint FK3DDCB3FCDED30C99 foreign key (qux) references quux\p\g
alter table abcd add constraint FK2D9442578192D3 foreign key (simple) references Simple\p\g
alter table abcd add constraint FK2D9442FB8A4BED foreign key (many) references many\p\g
alter table abcd add constraint FK2D9442DED2FBBD foreign key (one) references one\p\g
alter table abcd add constraint FK2D944294077C4B foreign key (container_id) references Container\p\g
alter table anyToAny add constraint FKEA8D06E5DED29727 foreign key (baz) references baz\p\g
alter table bar_join_table add constraint FKF39114258B9833CB foreign key (bar_id) references "foos"\p\g
alter table baz add constraint FK17C1BDED2B87D foreign key (foo) references "foos"\p\g
alter table baz add constraint FK17C1B8B9B1B19 foreign key ("baz-id") references baz\p\g
alter table baz add constraint FK17C1B7B14B1CC foreign key (superBaz) references baz on delete cascade\p\g
alter table baz_byte_bag add constraint FK5DC16BF5DED29727 foreign key (baz) references baz\p\g
alter table baz_floats_bag add constraint FK8687FC04601671B4 foreign key (baz_compon_id) references baz\p\g
alter table baz_foo add constraint FKEC8CB2A2DED29727 foreign key (baz) references baz\p\g
alter table baz_foo add constraint FKEC8CB2A2DED2B87D foreign key (foo) references "foos"\p\g
alter table baz_id_foo add constraint FK8DA58046DED29727 foreign key (baz) references baz\p\g
alter table baz_id_foo add constraint FK8DA58046DED2B87D foreign key (foo) references "foos"\p\g
alter table bazcomponents add constraint FK12C9D9718B9BD6CB foreign key (baz_id) references baz\p\g
alter table cached_map add constraint FK1F8B4BFDED29727 foreign key (baz) references baz\p\g
alter table cached_map add constraint FK1F8B4BFCD1093EB foreign key (another_baz) references baz\p\g
alter table cached_set add constraint FK1F8CBC5DED29727 foreign key (baz) references baz\p\g
alter table components add constraint FKE5548316578192D3 foreign key (simple) references Simple\p\g
alter table components add constraint FKE5548316FB8A4BED foreign key (many) references many\p\g
alter table components add constraint FKE5548316DED2FBBD foreign key (one) references one\p\g
alter table components add constraint FKE554831694077C4B foreign key (container_id) references Container\p\g
alter table composites add constraint FKE59CDECC578192D3 foreign key (simple) references Simple\p\g
alter table composites add constraint FKE59CDECCFB8A4BED foreign key (many) references many\p\g
alter table composites add constraint FKE59CDECCDED2FBBD foreign key (one) references one\p\g
alter table composites add constraint FKE59CDECC94077C4B foreign key (container_id) references Container\p\g
alter table customs add constraint FK433AE322DED2B1B0 foreign key (id_) references baz\p\g
alter table fees add constraint FK2FE5AD929E1AEB foreign key (fee_id) references "the fees"\p\g
alter table fooArray add constraint FK14BF0133DED2B87D foreign key (foo) references "foos"\p\g
alter table fooArray add constraint FK14BF0133DED2B1B0 foreign key (id_) references baz\p\g
alter table fooComponentToFoo add constraint FKFD673FB48B9BD6CB foreign key (baz_id) references baz\p\g
alter table fooComponentToFoo add constraint FKFD673FB4932F92EB foreign key (foo_id) references "foos"\p\g
alter table fooComponents add constraint FK498B2C7CDED2B5FD foreign key (fee) references "the fees"\p\g
alter table fooComponents add constraint FK498B2C7CE90DED05 foreign key (glarch_key) references "glarchez"\p\g
alter table fooToGlarch add constraint FKDA19FFC8B9BD6CB foreign key (baz_id) references baz\p\g
alter table fooToGlarch add constraint FKDA19FFC932F92EB foreign key (foo_id) references "foos"\p\g
alter table fooToGlarch add constraint FKDA19FFCC6E46349 foreign key (glarch_id) references "glarchez"\p\g
alter table foo_dates add constraint FKB585C9CC932F92EB foreign key (foo_id) references "foos"\p\g
alter table foo_dep_table add constraint FK489E6365E4A2AC18 foreign key (fooid) references "foos"\p\g
alter table foo_dep_table add constraint FK489E63659CB3B576 foreign key (dependent) references "the fees"\p\g
alter table foo_times add constraint FKB66ACA8D932F92EB foreign key (foo_id) references "foos"\p\g
alter table foobytes add constraint FK16933F65DED138D2 foreign key (id) references "foos"\p\g
alter table fums add constraint FK3022B5A64DB02B foreign key (qux_id) references quux\p\g
alter table fums add constraint FK3022B5AAB22AAB foreign key (fum_string, fum_short, fum_date) references Fum\p\g
alter table importantDates add constraint FKF777B383DED1281F foreign key (id) references "foos"\p\g
alter table int_array add constraint FK12CE7E09DED12827 foreign key (id) references baz\p\g
alter table jointable add constraint FKE3AC08E4E4A2AC18 foreign key (fooid) references "foos" on delete cascade\p\g
alter table many add constraint FK33065F9016265D foreign key (one_key) references one\p\g
alter table manyToAny add constraint FKBB04A52DED29727 foreign key (baz) references baz\p\g
alter table manyToMany add constraint FK6A5E42B98D4AE9CE foreign key (elt) references Simple\p\g
alter table manyToMany add constraint FK6A5E42B989A21C6B foreign key (container_id2) references Container\p\g
alter table moreParts add constraint FK6B3ABC8BDED29727 foreign key (baz) references baz\p\g
alter table moreParts add constraint FK6B3ABC8BFB8D0715 foreign key (part) references Part\p\g
alter table one add constraint FK1AE66329ECAC7 foreign key (holder) references Holder\p\g
alter table quux add constraint FK3523C7CFEFBDAD foreign key (fum_str_, fum_sho_, fum_dat_) references Fum\p\g
alter table quux add constraint FK3523C7DED2B87D foreign key (foo) references "foos"\p\g
alter table quux add constraint FK3523C7AB390E59 foreign key (HOLDER_NAME) references Holder (name)\p\g
alter table stringArray add constraint FKA45284C8DED2B1B0 foreign key (id_) references baz\p\g
alter table stringDateMap add constraint FK5B92297DDED2B1B0 foreign key (id_) references baz\p\g
alter table stringSet add constraint FKF4B79E91DED2B1B0 foreign key (id_) references baz\p\g
alter table string_list add constraint FKA5F66C0CDED12827 foreign key (id) references baz\p\g
alter table stringmap add constraint FKF4B7FFABCFEFBDAD foreign key (fum_str_, fum_sho_, fum_dat_) references Fum\p\g
alter table strings add constraint FK8FD6A282E90DED05 foreign key (glarch_key) references "glarchez"\p\g
alter table ternaryMap add constraint FKD97F3881DED2B87D foreign key (foo) references "foos"\p\g
alter table ternaryMap add constraint FKD97F388194077C4B foreign key (container_id) references Container\p\g
alter table ternaryMap add constraint FKD97F38812ED6F4E5 foreign key (glarch) references "glarchez"\p\g
alter table ternarySet add constraint FKD97F4F87DED2B87D foreign key (foo) references "foos"\p\g
alter table ternarySet add constraint FKD97F4F8794077C4B foreign key (container_id) references Container\p\g
alter table ternarySet add constraint FKD97F4F872ED6F4E5 foreign key (glarch) references "glarchez"\p\g
alter table timeArray add constraint FK87E78C8B9BD6CB foreign key (baz_id) references baz\p\g
alter table topcomponents add constraint FK72C85E2BDED2B1B0 foreign key (id_) references baz\p\g
alter table xxx add constraint FK1D178435CA821 foreign key (x) references X\p\g
create sequence hibernate_sequence\p\g
create table hibernate_unique_key ( next_hi integer )\p\g
insert into hibernate_unique_key values ( 0 )\p\g
insert into "glarchez" (version, namecvbnmasdf, next_, order_, foo, bar, x, immutable, "any_id_of_object", "any_class_of_object", count_, glarch_, tha_key) values (0, null, null, 0, 'foo', 66, 0, 'never changes!', null, null, 0, null, 'ff80808126f72c9d0126f72d8abe0002')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values (null, null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8ac60003')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values ('belongs to foo # ff80808126f72c9d0126f72d8aaf0001', null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8ac70004')\p\g
insert into "foos" (version, long_, "integer__", float_, x, double_, date_, timestamp_, boolean_, bool_, short_, char_, zero_, int_, string_, byte_, yesno, blobb_, bin_, "localeayzabc123", first_name, surname, count_, name_, g__, cmpnt_null_, subname, fee_sub, "foo_subclass_1234", "foo_idcolumnname123") values (0, 696969696969696969, -666, 6666.66, 0, 1.12E-36, '1969-12-31', '2010-02-22 14:35:42.007', 1, 0, 42, '@', 0.0, 2, 'a string', '127', 'N', '[104]', '[22]', 'en_US', 'foo', 'bar', 12, 'foo', 'ff80808126f72c9d0126f72d8abe0002', null, 'bar', 'ff80808126f72c9d0126f72d8ac60003', 'F', 'ff80808126f72c9d0126f72d8aaf0001')\p\g
insert into jointable (fooid) values ('ff80808126f72c9d0126f72d8aaf0001')\p\g
insert into foo_dep_table (dependent, fooid) values ('ff80808126f72c9d0126f72d8ac70004', 'ff80808126f72c9d0126f72d8aaf0001')\p\g
insert into "glarchez" (version, namecvbnmasdf, next_, order_, foo, bar, x, immutable, "any_id_of_object", "any_class_of_object", count_, glarch_, tha_key) values (0, null, null, 0, 'foo', 66, 0, 'never changes!', null, null, 0, null, 'ff80808126f72c9d0126f72d8b130006')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values (null, null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b130007')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values ('belongs to foo # ff80808126f72c9d0126f72d8b120005', null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b130008')\p\g
insert into "foos" (version, long_, "integer__", float_, x, double_, date_, timestamp_, boolean_, bool_, short_, char_, zero_, int_, string_, byte_, yesno, blobb_, bin_, "localeayzabc123", first_name, surname, count_, name_, g__, cmpnt_null_, subname, fee_sub, "foo_subclass_1234", "foo_idcolumnname123") values (0, 696969696969696968, -666, 6666.66, 0, 1.12E-36, '1969-12-31', '2010-02-22 14:35:42.098', 1, 0, 42, '@', 0.0, 2, 'a string', '127', 'N', '[104]', '[22]', 'en_US', 'foo', 'bar', 12, 'foo', 'ff80808126f72c9d0126f72d8b130006', null, 'bar', 'ff80808126f72c9d0126f72d8b130007', 'F', 'ff80808126f72c9d0126f72d8b120005')\p\g
insert into jointable (fooid) values ('ff80808126f72c9d0126f72d8b120005')\p\g
insert into foo_dep_table (dependent, fooid) values ('ff80808126f72c9d0126f72d8b130008', 'ff80808126f72c9d0126f72d8b120005')\p\g
insert into "glarchez" (version, namecvbnmasdf, next_, order_, foo, bar, x, immutable, "any_id_of_object", "any_class_of_object", count_, glarch_, tha_key) values (0, null, null, 0, 'foo', 66, 0, 'never changes!', null, null, 0, null, 'ff80808126f72c9d0126f72d8b14000a')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values (null, null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b15000b')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values ('belongs to foo # ff80808126f72c9d0126f72d8b140009', null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b15000c')\p\g
insert into "foos" (version, long_, "integer__", float_, x, double_, date_, timestamp_, boolean_, bool_, short_, char_, zero_, int_, string_, byte_, yesno, blobb_, bin_, "localeayzabc123", first_name, surname, count_, name_, g__, cmpnt_null_, subname, fee_sub, "foo_subclass_1234", "foo_idcolumnname123") values (0, 696969696969696967, -666, 6666.66, 0, 1.12E-36, '1969-12-31', '2010-02-22 14:35:42.1', 1, 0, 42, '@', 0.0, 2, 'a string', '127', 'N', '[104]', '[22]', 'en_US', 'foo', 'bar', 12, 'foo', 'ff80808126f72c9d0126f72d8b14000a', null, 'bar', 'ff80808126f72c9d0126f72d8b15000b', 'F', 'ff80808126f72c9d0126f72d8b140009')\p\g
insert into jointable (fooid) values ('ff80808126f72c9d0126f72d8b140009')\p\g
insert into foo_dep_table (dependent, fooid) values ('ff80808126f72c9d0126f72d8b15000c', 'ff80808126f72c9d0126f72d8b140009')\p\g
insert into "glarchez" (version, namecvbnmasdf, next_, order_, foo, bar, x, immutable, "any_id_of_object", "any_class_of_object", count_, glarch_, tha_key) values (0, null, null, 0, 'foo', 66, 0, 'never changes!', null, null, 0, null, 'ff80808126f72c9d0126f72d8b17000e')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values (null, null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b18000f')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values ('belongs to foo # ff80808126f72c9d0126f72d8b17000d', null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b180010')\p\g
insert into "foos" (version, long_, "integer__", float_, x, double_, date_, timestamp_, boolean_, bool_, short_, char_, zero_, int_, string_, byte_, yesno, blobb_, bin_, "localeayzabc123", first_name, surname, count_, name_, g__, cmpnt_null_, subname, fee_sub, "foo_subclass_1234", "foo_idcolumnname123") values (0, 696969696969696966, -666, 6666.66, 0, 1.12E-36, '1969-12-31', '2010-02-22 14:35:42.103', 1, 0, 42, '@', 0.0, 2, 'a string', '127', 'N', '[104]', '[22]', 'en_US', 'foo', 'bar', 12, 'foo', 'ff80808126f72c9d0126f72d8b17000e', null, 'bar', 'ff80808126f72c9d0126f72d8b18000f', 'F', 'ff80808126f72c9d0126f72d8b17000d')\p\g
insert into jointable (fooid) values ('ff80808126f72c9d0126f72d8b17000d')\p\g
insert into foo_dep_table (dependent, fooid) values ('ff80808126f72c9d0126f72d8b180010', 'ff80808126f72c9d0126f72d8b17000d')\p\g
insert into "glarchez" (version, namecvbnmasdf, next_, order_, foo, bar, x, immutable, "any_id_of_object", "any_class_of_object", count_, glarch_, tha_key) values (0, null, null, 0, 'foo', 66, 0, 'never changes!', null, null, 0, null, 'ff80808126f72c9d0126f72d8b180012')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values (null, null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b190013')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values ('belongs to foo # ff80808126f72c9d0126f72d8b180011', null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b190014')\p\g
insert into "foos" (version, long_, "integer__", float_, x, double_, date_, timestamp_, boolean_, bool_, short_, char_, zero_, int_, string_, byte_, yesno, blobb_, bin_, "localeayzabc123", first_name, surname, count_, name_, g__, cmpnt_null_, subname, fee_sub, "foo_subclass_1234", "foo_idcolumnname123") values (0, 696969696969696965, -666, 6666.66, 0, 1.12E-36, '1969-12-31', '2010-02-22 14:35:42.104', 1, 0, 42, '@', 0.0, 2, 'a string', '127', 'N', '[104]', '[22]', 'en_US', 'foo', 'bar', 12, 'foo', 'ff80808126f72c9d0126f72d8b180012', null, 'bar', 'ff80808126f72c9d0126f72d8b190013', 'F', 'ff80808126f72c9d0126f72d8b180011')\p\g
insert into jointable (fooid) values ('ff80808126f72c9d0126f72d8b180011')\p\g
insert into foo_dep_table (dependent, fooid) values ('ff80808126f72c9d0126f72d8b190014', 'ff80808126f72c9d0126f72d8b180011')\p\g
insert into "glarchez" (version, namecvbnmasdf, next_, order_, foo, bar, x, immutable, "any_id_of_object", "any_class_of_object", count_, glarch_, tha_key) values (0, null, null, 0, 'foo', 66, 0, 'never changes!', null, null, 0, null, 'ff80808126f72c9d0126f72d8b1a0016')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values (null, null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b1b0017')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values ('belongs to foo # ff80808126f72c9d0126f72d8b1a0015', null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b1b0018')\p\g
insert into "foos" (version, long_, "integer__", float_, x, double_, date_, timestamp_, boolean_, bool_, short_, char_, zero_, int_, string_, byte_, yesno, blobb_, bin_, "localeayzabc123", first_name, surname, count_, name_, g__, cmpnt_null_, subname, fee_sub, "foo_subclass_1234", "foo_idcolumnname123") values (0, 696969696969696964, -666, 6666.66, 0, 1.12E-36, '1969-12-31', '2010-02-22 14:35:42.106', 1, 0, 42, '@', 0.0, 2, 'a string', '127', 'N', '[104]', '[22]', 'en_US', 'foo', 'bar', 12, 'foo', 'ff80808126f72c9d0126f72d8b1a0016', null, 'bar', 'ff80808126f72c9d0126f72d8b1b0017', 'F', 'ff80808126f72c9d0126f72d8b1a0015')\p\g
insert into jointable (fooid) values ('ff80808126f72c9d0126f72d8b1a0015')\p\g
insert into foo_dep_table (dependent, fooid) values ('ff80808126f72c9d0126f72d8b1b0018', 'ff80808126f72c9d0126f72d8b1a0015')\p\g
insert into "glarchez" (version, namecvbnmasdf, next_, order_, foo, bar, x, immutable, "any_id_of_object", "any_class_of_object", count_, glarch_, tha_key) values (0, null, null, 0, 'foo', 66, 0, 'never changes!', null, null, 0, null, 'ff80808126f72c9d0126f72d8b1c001a')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values (null, null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b1c001b')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values ('belongs to foo # ff80808126f72c9d0126f72d8b1c0019', null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b1c001c')\p\g
insert into "foos" (version, long_, "integer__", float_, x, double_, date_, timestamp_, boolean_, bool_, short_, char_, zero_, int_, string_, byte_, yesno, blobb_, bin_, "localeayzabc123", first_name, surname, count_, name_, g__, cmpnt_null_, subname, fee_sub, "foo_subclass_1234", "foo_idcolumnname123") values (0, 696969696969696963, -666, 6666.66, 0, 1.12E-36, '1969-12-31', '2010-02-22 14:35:42.108', 1, 0, 42, '@', 0.0, 2, 'a string', '127', 'N', '[104]', '[22]', 'en_US', 'foo', 'bar', 12, 'foo', 'ff80808126f72c9d0126f72d8b1c001a', null, 'bar', 'ff80808126f72c9d0126f72d8b1c001b', 'F', 'ff80808126f72c9d0126f72d8b1c0019')\p\g
insert into jointable (fooid) values ('ff80808126f72c9d0126f72d8b1c0019')\p\g
insert into foo_dep_table (dependent, fooid) values ('ff80808126f72c9d0126f72d8b1c001c', 'ff80808126f72c9d0126f72d8b1c0019')\p\g
insert into "glarchez" (version, namecvbnmasdf, next_, order_, foo, bar, x, immutable, "any_id_of_object", "any_class_of_object", count_, glarch_, tha_key) values (0, null, null, 0, 'foo', 66, 0, 'never changes!', null, null, 0, null, 'ff80808126f72c9d0126f72d8b1d001e')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values (null, null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b1d001f')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values ('belongs to foo # ff80808126f72c9d0126f72d8b1d001d', null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b1d0020')\p\g
insert into "foos" (version, long_, "integer__", float_, x, double_, date_, timestamp_, boolean_, bool_, short_, char_, zero_, int_, string_, byte_, yesno, blobb_, bin_, "localeayzabc123", first_name, surname, count_, name_, g__, cmpnt_null_, subname, fee_sub, "foo_subclass_1234", "foo_idcolumnname123") values (0, 696969696969696962, -666, 6666.66, 0, 1.12E-36, '1969-12-31', '2010-02-22 14:35:42.109', 1, 0, 42, '@', 0.0, 2, 'a string', '127', 'N', '[104]', '[22]', 'en_US', 'foo', 'bar', 12, 'foo', 'ff80808126f72c9d0126f72d8b1d001e', null, 'bar', 'ff80808126f72c9d0126f72d8b1d001f', 'F', 'ff80808126f72c9d0126f72d8b1d001d')\p\g
insert into jointable (fooid) values ('ff80808126f72c9d0126f72d8b1d001d')\p\g
insert into foo_dep_table (dependent, fooid) values ('ff80808126f72c9d0126f72d8b1d0020', 'ff80808126f72c9d0126f72d8b1d001d')\p\g
insert into "glarchez" (version, namecvbnmasdf, next_, order_, foo, bar, x, immutable, "any_id_of_object", "any_class_of_object", count_, glarch_, tha_key) values (0, null, null, 0, 'foo', 66, 0, 'never changes!', null, null, 0, null, 'ff80808126f72c9d0126f72d8b210022')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values (null, null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b210023')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values ('belongs to foo # ff80808126f72c9d0126f72d8b210021', null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b210024')\p\g
insert into "foos" (version, long_, "integer__", float_, x, double_, date_, timestamp_, boolean_, bool_, short_, char_, zero_, int_, string_, byte_, yesno, blobb_, bin_, "localeayzabc123", first_name, surname, count_, name_, g__, cmpnt_null_, subname, fee_sub, "foo_subclass_1234", "foo_idcolumnname123") values (0, 696969696969696961, -666, 6666.66, 0, 1.12E-36, '1969-12-31', '2010-02-22 14:35:42.113', 1, 0, 42, '@', 0.0, 2, 'a string', '127', 'N', '[104]', '[22]', 'en_US', 'foo', 'bar', 12, 'foo', 'ff80808126f72c9d0126f72d8b210022', null, 'bar', 'ff80808126f72c9d0126f72d8b210023', 'F', 'ff80808126f72c9d0126f72d8b210021')\p\g
insert into jointable (fooid) values ('ff80808126f72c9d0126f72d8b210021')\p\g
insert into foo_dep_table (dependent, fooid) values ('ff80808126f72c9d0126f72d8b210024', 'ff80808126f72c9d0126f72d8b210021')\p\g
insert into "glarchez" (version, namecvbnmasdf, next_, order_, foo, bar, x, immutable, "any_id_of_object", "any_class_of_object", count_, glarch_, tha_key) values (0, null, null, 0, 'foo', 66, 0, 'never changes!', null, null, 0, null, 'ff80808126f72c9d0126f72d8b220026')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values (null, null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b220027')\p\g
insert into "the fees" (fi, fee, anotherFee, qux, count_, name, null_prop, id_) values ('belongs to foo # ff80808126f72c9d0126f72d8b220025', null, null, null, 0, null, null, 'ff80808126f72c9d0126f72d8b220028')\p\g
insert into "foos" (version, long_, "integer__", float_, x, double_, date_, timestamp_, boolean_, bool_, short_, char_, zero_, int_, string_, byte_, yesno, blobb_, bin_, "localeayzabc123", first_name, surname, count_, name_, g__, cmpnt_null_, subname, fee_sub, "foo_subclass_1234", "foo_idcolumnname123") values (0, 696969696969696960, -666, 6666.66, 0, 1.12E-36, '1969-12-31', '2010-02-22 14:35:42.114', 1, 0, 42, '@', 0.0, 2, 'a string', '127', 'N', '[104]', '[22]', 'en_US', 'foo', 'bar', 12, 'foo', 'ff80808126f72c9d0126f72d8b220026', null, 'bar', 'ff80808126f72c9d0126f72d8b220027', 'F', 'ff80808126f72c9d0126f72d8b220025')\p\g
insert into jointable (fooid) values ('ff80808126f72c9d0126f72d8b220025')\p\g
insert into foo_dep_table (dependent, fooid) values ('ff80808126f72c9d0126f72d8b220028', 'ff80808126f72c9d0126f72d8b220025')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8aaf0001', 0, '97')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8aaf0001', 1, '32')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8aaf0001', 2, '115')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8aaf0001', 3, '116')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8aaf0001', 4, '114')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8aaf0001', 5, '105')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8aaf0001', 6, '110')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8aaf0001', 7, '103')\p\g
insert into foo_times (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8aaf0001', 0, '19:02:03')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8aaf0001', 0, '1969-12-31')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8aaf0001', 1, '2010-02-22')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8aaf0001', 3, '2010-02-22')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b120005', 0, '97')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b120005', 1, '32')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b120005', 2, '115')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b120005', 3, '116')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b120005', 4, '114')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b120005', 5, '105')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b120005', 6, '110')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b120005', 7, '103')\p\g
insert into foo_times (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b120005', 0, '19:02:03')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b120005', 0, '1969-12-31')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b120005', 1, '2010-02-22')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b120005', 3, '2010-02-22')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b140009', 0, '97')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b140009', 1, '32')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b140009', 2, '115')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b140009', 3, '116')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b140009', 4, '114')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b140009', 5, '105')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b140009', 6, '110')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b140009', 7, '103')\p\g
insert into foo_times (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b140009', 0, '19:02:03')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b140009', 0, '1969-12-31')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b140009', 1, '2010-02-22')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b140009', 3, '2010-02-22')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b17000d', 0, '97')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b17000d', 1, '32')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b17000d', 2, '115')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b17000d', 3, '116')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b17000d', 4, '114')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b17000d', 5, '105')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b17000d', 6, '110')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b17000d', 7, '103')\p\g
insert into foo_times (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b17000d', 0, '19:02:03')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b17000d', 0, '1969-12-31')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b17000d', 1, '2010-02-22')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b17000d', 3, '2010-02-22')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b180011', 0, '97')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b180011', 1, '32')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b180011', 2, '115')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b180011', 3, '116')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b180011', 4, '114')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b180011', 5, '105')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b180011', 6, '110')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b180011', 7, '103')\p\g
insert into foo_times (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b180011', 0, '19:02:03')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b180011', 0, '1969-12-31')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b180011', 1, '2010-02-22')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b180011', 3, '2010-02-22')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1a0015', 0, '97')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1a0015', 1, '32')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1a0015', 2, '115')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1a0015', 3, '116')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1a0015', 4, '114')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1a0015', 5, '105')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1a0015', 6, '110')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1a0015', 7, '103')\p\g
insert into foo_times (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b1a0015', 0, '19:02:03')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b1a0015', 0, '1969-12-31')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b1a0015', 1, '2010-02-22')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b1a0015', 3, '2010-02-22')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1c0019', 0, '97')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1c0019', 1, '32')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1c0019', 2, '115')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1c0019', 3, '116')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1c0019', 4, '114')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1c0019', 5, '105')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1c0019', 6, '110')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1c0019', 7, '103')\p\g
insert into foo_times (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b1c0019', 0, '19:02:03')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b1c0019', 0, '1969-12-31')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b1c0019', 1, '2010-02-22')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b1c0019', 3, '2010-02-22')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1d001d', 0, '97')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1d001d', 1, '32')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1d001d', 2, '115')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1d001d', 3, '116')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1d001d', 4, '114')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1d001d', 5, '105')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1d001d', 6, '110')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b1d001d', 7, '103')\p\g
insert into foo_times (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b1d001d', 0, '19:02:03')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b1d001d', 0, '1969-12-31')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b1d001d', 1, '2010-02-22')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b1d001d', 3, '2010-02-22')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b210021', 0, '97')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b210021', 1, '32')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b210021', 2, '115')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b210021', 3, '116')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b210021', 4, '114')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b210021', 5, '105')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b210021', 6, '110')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b210021', 7, '103')\p\g
insert into foo_times (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b210021', 0, '19:02:03')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b210021', 0, '1969-12-31')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b210021', 1, '2010-02-22')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b210021', 3, '2010-02-22')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b220025', 0, '97')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b220025', 1, '32')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b220025', 2, '115')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b220025', 3, '116')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b220025', 4, '114')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b220025', 5, '105')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b220025', 6, '110')\p\g
insert into foobytes (id, i, byte_) values ('ff80808126f72c9d0126f72d8b220025', 7, '103')\p\g
insert into foo_times (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b220025', 0, '19:02:03')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b220025', 0, '1969-12-31')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b220025', 1, '2010-02-22')\p\g
insert into foo_dates (foo_id, i, date_) values ('ff80808126f72c9d0126f72d8b220025', 3, '2010-02-22')\p\g
select first 6 foo0_."foo_idcolumnname123" as col_0_0_ from "foos" foo0_ inner join jointable foo0_1_ on foo0_."foo_idcolumnname123"=foo0_1_.fooid inner join foo_dep_table foo0_2_ on foo0_."foo_idcolumnname123"=foo0_2_.fooid where foo0_."foo_subclass_1234" in ('F', 'B', 'T') offset 2\p\g
drop table CCBAG\p\g
drop table Contained\p\g
drop table Container\p\g
drop table Fum\p\g
drop table Fumm\p\g
drop table Holder\p\g
drop table LCCBAG\p\g
drop table Location\p\g
drop table MoreStuff\p\g
drop table Part\p\g
drop table Simple\p\g
drop table Sortable\p\g
drop table Stuff\p\g
drop table Vetoer\p\g
drop table X\p\g
drop table Y\p\g
drop table "bxaxg"\p\g
drop table "foos"\p\g
drop table "glarchez"\p\g
drop table "the fees"\p\g
drop table abcd\p\g
drop table anyToAny\p\g
drop table bar_join_table\p\g
drop table baz\p\g
drop table baz_byte_bag\p\g
drop table baz_floats_bag\p\g
drop table baz_foo\p\g
drop table baz_id_foo\p\g
drop table bazcomponents\p\g
drop table cached_map\p\g
drop table cached_set\p\g
drop table components\p\g
drop table composites\p\g
drop table customs\p\g
drop table fees\p\g
drop table foes\p\g
drop table fooArray\p\g
drop table fooComponentToFoo\p\g
drop table fooComponents\p\g
drop table fooToGlarch\p\g
drop table foo_dates\p\g
drop table foo_dep_table\p\g
drop table foo_times\p\g
drop table foobytes\p\g
drop table fums\p\g
drop table immut\p\g
drop table importantDates\p\g
drop table int_array\p\g
drop table jointable\p\g
drop table many\p\g
drop table manyToAny\p\g
drop table manyToMany\p\g
drop table moreParts\p\g
drop table one\p\g
drop table quux\p\g
drop table stringArray\p\g
drop table stringDateMap\p\g
drop table stringSet\p\g
drop table string_list\p\g
drop table stringmap\p\g
drop table strings\p\g
drop table ternaryMap\p\g
drop table ternarySet\p\g
drop table timeArray\p\g
drop table topcomponents\p\g
drop table xxx\p\g
drop sequence hibernate_sequence restrict\p\g
drop table hibernate_unique_key\p\g

