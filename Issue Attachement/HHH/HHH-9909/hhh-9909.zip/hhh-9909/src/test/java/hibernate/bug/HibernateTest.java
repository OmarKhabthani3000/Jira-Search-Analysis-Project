package hibernate.bug;

import hibernate.bug.model.AbilityCard;
import hibernate.bug.model.AbilityCardInstance;
import hibernate.bug.model.Card;
import hibernate.bug.model.CardInstance;
import hibernate.bug.model.HeroCard;
import hibernate.bug.model.HeroCardInstance;
import hibernate.bug.model.LeaderCard;
import hibernate.bug.model.LeaderCardInstance;
import hibernate.bug.model.Player;
import hibernate.bug.model.UnitCard;
import hibernate.bug.model.UnitCardInstance;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {

    private EntityManagerFactory emf;

    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");

        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        AbilityCard abilityCard = new AbilityCard();
        HeroCard heroCard = new HeroCard();
        LeaderCard leaderCard = new LeaderCard();
        UnitCard unitCard = new UnitCard();
        
        Player jack = new Player("jack");
        Player james = new Player("james");
        Player jean = new Player("jean");
        Player john = new Player("john");
        Player joyce = new Player("joyce");
        
        em.persist(abilityCard);
        em.persist(heroCard);
        em.persist(leaderCard);
        em.persist(unitCard);
        
        em.persist(jack);
        em.persist(james);
        em.persist(jean);
        em.persist(john);
        em.persist(joyce);
        
        em.persist(new HeroCardInstance(heroCard, jack));
        em.persist(new LeaderCardInstance(leaderCard, jack));
        em.persist(new UnitCardInstance(unitCard, jack));
        em.persist(new AbilityCardInstance(abilityCard, james));
        em.persist(new LeaderCardInstance(leaderCard, james));
        em.persist(new LeaderCardInstance(leaderCard, jean));
        em.persist(new LeaderCardInstance(leaderCard, john));

        em.flush();
        tx.commit();
        em.close();
    }

    @Test
    public void testIssue() throws Throwable {
        EntityManager em = emf.createEntityManager();

        final List<Player> players = em.createQuery("FROM Player", Player.class).getResultList();

        assertNotNull(players);
        assertNotEquals(0, players.size());

        for (final Player player : players) {
            assertNotNull(player);
            assertNotNull(player.getCards());
            assertTrue(player.getCards().size() >= 0);
            assertNotNull(player.getHandle());
            assertNotNull(player.getID());

            for (final CardInstance<Card> card : player.getCards()) {
                assertNotNull(card);
                assertNotNull(card.getCard());
                assertNotNull(card.getCard().getID());
                assertNotNull(card.getCard().getType());
                assertNotNull(card.getID());
                assertNotNull(card.getPlayer());
                assertNotNull(card.getType());

                System.out.println(String.format("%3d %10s %3d %10s %20s %3d %10s %15s %3d", player.getID(), player.getHandle(), card.getID(), card.getType(), card.getClass().getSimpleName(), card.getCard().getID(), card.getCard().getType(), card.getCard().getClass().getSimpleName(), card.getCard().getDuration()));
            }
        }

        em.close();
    }
}
