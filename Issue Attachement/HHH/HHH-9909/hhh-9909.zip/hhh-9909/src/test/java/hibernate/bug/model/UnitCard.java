package hibernate.bug.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * Represents a card for a playing unit within a game.
 */
@Entity
@DiscriminatorValue("unit")
public class UnitCard extends Card
{
  public UnitCard()
  {
    super("unit");
  }

    public UnitCard(String type) {
        super(type);
    }

  /**
   * {@inheritDoc}
   */
  public int getDuration()
  {
    return 10;
  }
}
