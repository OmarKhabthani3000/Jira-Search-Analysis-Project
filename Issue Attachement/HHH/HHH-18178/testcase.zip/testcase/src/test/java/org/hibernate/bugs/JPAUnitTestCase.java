package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import jakarta.persistence.Tuple;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Stream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import static org.assertj.core.api.Assertions.assertThat;
import org.hibernate.Session;
import org.hibernate.query.criteria.JpaCriteriaQuery;
import org.hibernate.query.criteria.JpaCteCriteria;
import org.hibernate.query.criteria.JpaDerivedRoot;
import org.hibernate.query.criteria.JpaRoot;
import org.hibernate.query.criteria.JpaSubQuery;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private static final Logger LOGGER = LogManager.getLogger();
	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}


	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void testCase() throws Exception {
		try (EntityManager entityManager = entityManagerFactory.createEntityManager()) {
			entityManager.getTransaction().begin();
			//given
			persistData(entityManager);
			var cb = entityManager.unwrap(Session.class).getCriteriaBuilder();
			JpaCriteriaQuery<Tuple> query = cb.createTupleQuery();
			JpaSubQuery<Tuple> incomeUnionPart = query.subquery(Tuple.class);
			JpaRoot<Income> incomeUnionPartRoot = incomeUnionPart.from(Income.class);
			incomeUnionPart.multiselect(
					incomeUnionPartRoot.get("category").alias("category"),
					incomeUnionPartRoot.get("balance").alias("balance"),
					cb.literal("i").alias("type")
			);
			JpaSubQuery<Tuple> expenseUnionPart = query.subquery(Tuple.class);
			JpaRoot<Expense> expenseUnionPartRoot = expenseUnionPart.from(Expense.class);
			expenseUnionPart.multiselect(
					expenseUnionPartRoot.get("category").alias("category"),
					expenseUnionPartRoot.get("balance").alias("balance"),
					cb.literal("e").alias("type")
			);
			JpaSubQuery<Tuple> unionSq = cb.unionAll(incomeUnionPart, expenseUnionPart);
			JpaCteCriteria<Tuple> unionCte = query.with(unionSq);
			JpaRoot<Tuple> root = query.from(unionCte);
			query.multiselect(
					root.get("category").alias("category"),
				cb.sum(
						cb.<String, BigDecimal>selectCase(root.get("type")).when("i", root.get("balance"))
								.otherwise(BigDecimal.ZERO)
				).alias("income"),
					cb.sum(
							cb.<String, BigDecimal>selectCase(root.get("type")).when("e", root.get("balance"))
									.otherwise(BigDecimal.ZERO)
					).alias("expense")
			).groupBy(
					root.get("category")
			).orderBy(
					cb.asc(
							root.get("category")
					)
			);

			List<Tuple> list = entityManager.createQuery(query).getResultList();
			assertThat(list).hasSize(2);
			Tuple tuple = list.get(0);
			assertThat(tuple.get("category", String.class)).isEqualTo("a");
			assertThat(tuple.get("income", BigDecimal.class)).isEqualByComparingTo("110");
			assertThat(tuple.get("expense", BigDecimal.class)).isEqualByComparingTo("100");
			tuple = list.get(1);
			assertThat(tuple.get("category", String.class)).isEqualTo("b");
			assertThat(tuple.get("income", BigDecimal.class)).isEqualByComparingTo("220");
			assertThat(tuple.get("expense", BigDecimal.class)).isEqualByComparingTo("350");
		} catch (Throwable t) {
			LOGGER.error(t.getMessage(), t);
			throw t;
		}
	}

	private void persistData(EntityManager em) {
		Stream.of(
				createIncome(1, "a", 100),
				createIncome(2, "a", 10),
				createIncome(3, "b", 200),
				createIncome(4, "b", 20),
				createExpense(5, "a", 100),
				createExpense(6, "b", 150),
				createExpense(7, "b", 200)
		).forEach(em::persist);
		em.flush();
		em.clear();
	}


	private Income createIncome(int id, String category, long balance) {
		var entity = new Income();
		entity.setId(id);
		entity.setCategory(category);
		entity.setBalance(BigDecimal.valueOf(balance));
		return entity;
	}

	private Expense createExpense(int id, String category, long balance) {
		var entity = new Expense();
		entity.setId(id);
		entity.setCategory(category);
		entity.setBalance(BigDecimal.valueOf(balance));
		return entity;
	}

}
