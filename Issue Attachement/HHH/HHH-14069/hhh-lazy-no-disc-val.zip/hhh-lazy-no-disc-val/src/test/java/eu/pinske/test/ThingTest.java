package eu.pinske.test;

import static javax.persistence.criteria.JoinType.LEFT;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.junit.Assert;
import org.junit.Test;

import eu.pinske.model.Child1;
import eu.pinske.model.Child2;
import eu.pinske.model.SomeEntity;
import eu.pinske.model.SomeEntity_;

public class ThingTest {

	@Test
	public void testHHH14069() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");

		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();

		SomeEntity entity = new SomeEntity();
		Child1 c1 = new Child1();
		Child2 c2 = new Child2();
		c1.setSomeEntity(entity);
		c2.setSomeEntity(entity);

		em.persist(entity);
		em.persist(c1);
		em.persist(c2);
		em.flush();

		em.getTransaction().commit();
		em.clear();
		em.close();

		em = emf.createEntityManager();
		em.getTransaction().begin();

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<SomeEntity> q = cb.createQuery(SomeEntity.class);
		Root<SomeEntity> from = q.from(SomeEntity.class);
		from.fetch(SomeEntity_.oneChildren, LEFT);
		from.fetch(SomeEntity_.twoChildren, LEFT);
		q.where(cb.equal(from.get(SomeEntity_.id), entity.getId()));

		entity = em.createQuery(q).getSingleResult();
		Assert.assertEquals(1, entity.getOneChildren().size());
		Assert.assertEquals(1, entity.getTwoChildren().size());

		em.clear();

		entity = em.find(SomeEntity.class, entity.getId());
		Assert.assertEquals(1, entity.getOneChildren().size());// Triggers LazyLoad without discriminator value. The
		// loaded objects are of type Child1
		Assert.assertEquals(1, entity.getTwoChildren().size());

		emf.close();
	}

	@Test
	public void testHHH14069_1() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");

		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();

		SomeEntity entity = new SomeEntity();
		Child1 c1 = new Child1();
		Child2 c2 = new Child2();
		c1.setSomeEntity(entity);
		c2.setSomeEntity(entity);

		em.persist(entity);
		em.persist(c1);
		em.persist(c2);

		em.flush();
		em.getTransaction().commit();
		em.clear();
		em.close();

		em = emf.createEntityManager();
		em.getTransaction().begin();

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<SomeEntity> q = cb.createQuery(SomeEntity.class);
		Root<SomeEntity> from = q.from(SomeEntity.class);
		from.fetch(SomeEntity_.oneChildren, LEFT);
		from.fetch(SomeEntity_.twoChildren, LEFT);
		q.where(cb.equal(from.get(SomeEntity_.id), entity.getId()));

		entity = em.createQuery(q).getSingleResult();
		Assert.assertEquals(1, entity.getOneChildren().size());
		Assert.assertEquals(1, entity.getTwoChildren().size());

		em.clear();

		entity = em.find(SomeEntity.class, entity.getId());
		entity.getOneChildren().size();// == 2
		for (Child2 child : entity.getTwoChildren()) {
			System.out.println(child);
		}
		emf.close();
	}

}
