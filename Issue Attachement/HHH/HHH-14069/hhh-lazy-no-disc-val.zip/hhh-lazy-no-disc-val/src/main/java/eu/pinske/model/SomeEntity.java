package eu.pinske.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class SomeEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@OneToMany(mappedBy = "someEntity", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<Child1> oneChildren;

	@OneToMany(mappedBy = "someEntity", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<Child2> twoChildren;

	public Long getId() {
		return id;
	}

	public Set<Child1> getOneChildren() {
		if (oneChildren == null) {
			oneChildren = new HashSet<Child1>();
		}
		return oneChildren;
	}

	public Set<Child2> getTwoChildren() {
		if (twoChildren == null) {
			twoChildren = new HashSet<Child2>();
		}
		return twoChildren;
	}

}
