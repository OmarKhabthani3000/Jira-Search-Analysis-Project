package eu.pinske.model;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CHILDREN")
@DiscriminatorColumn(name = "TYP")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class ParentEntity {

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ENTITY_ID")
	private SomeEntity someEntity;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;


	public Long getId() {
		return id;
	}

	public SomeEntity getSomeEntity() {
		return someEntity;
	}

	public void setSomeEntity(SomeEntity someEntity) {
		this.someEntity = someEntity;
	}

}
