package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;
import org.hibernate.annotations.NaturalId;

@Entity
@Table(name="EXA_FLAT_BOAT")
public class FlatBoat {
	private Long id;
	private Barge barge;
	private String name;
	
    @Id 
    @GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="FLB_ID")
    public Long getId() {
		return id;
	}
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "BAR_ID", nullable=false)
	@ForeignKey(name = "EXAF_FLB_BAR_ID")
	@NaturalId(mutable=false)
	public Barge getBarge() {
		return barge;
	}
	
	@Column(name = "FLB_VALID_START", nullable = false)
	@NaturalId(mutable = true)
	public String getName() {
		return name;
	}
	
	public void setId(Long id) {
		this.id = id;
	}

	
	public void setBarge(Barge barge) {
		this.barge = barge;
	}
	
	public void setName(String name) {
		this.name = name;
	}
}
