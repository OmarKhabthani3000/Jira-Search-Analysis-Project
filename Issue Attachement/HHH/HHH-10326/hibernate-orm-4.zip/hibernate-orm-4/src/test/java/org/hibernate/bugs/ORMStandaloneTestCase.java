package org.hibernate.bugs;

import static org.junit.Assert.*;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

/**
 * This template demonstrates how to develop a standalone test case for
 * Hibernate ORM. Although this is perfectly acceptable as a reproducer, usage
 * of ORMUnitTestCase is preferred!
 */
public class ORMStandaloneTestCase {

	private Configuration cfg;

	private SessionFactory sf;

	@Before
	public void setup() {
		cfg = new Configuration();

		// Add your entities here.
		// cfg.addAnnotatedClass(Foo.class);

		// Add in any settings that are specific to your test. See
		// resources/hibernate.properties for the defaults.
		cfg.setProperty("hibernate.show_sql", "true");
		cfg.setProperty("hibernate.format_sql", "true");
		cfg.setProperty("hibernate.hbm2ddl.auto", "update");
		cfg.addAnnotatedClass(Barge.class);
		cfg.addAnnotatedClass(FlatBoat.class);
		
		StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder();
		ServiceRegistry sr = srb.build();
		sf = cfg.buildSessionFactory(sr);
	}

	// Add your tests, using standard JUnit.

	@Test
	public void testImmutableNaturalIdShouldNotBeChangeable() {
		// https://hibernate.atlassian.net/browse/HHH-10326
		// if there is another @NaturalId for which mutable = true, then the the
		// @NaturalId with mutable = false can also be changed
		Session session = sf.openSession();
		session.beginTransaction();
		Barge first = new Barge();
		session.save(first);

		FlatBoat flatBoat = new FlatBoat();
		flatBoat.setBarge(first);
		flatBoat.setName("name");
		session.save(flatBoat);

		session.getTransaction().commit();
		session.getTransaction().begin();

		Barge second = new Barge();
		session.save(second);

		flatBoat.setBarge(second);

		try {	
			session.getTransaction().commit();
			fail();
		} catch(HibernateException expected) {
			assertTrue(expected.getMessage().contains("An immutable natural identifier"));
		}
	}
}
