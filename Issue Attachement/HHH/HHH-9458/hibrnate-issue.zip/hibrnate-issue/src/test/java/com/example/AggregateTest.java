package com.example;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

public class AggregateTest {

    private static EntityManagerFactory entityManagerFactory;
    private EntityManager entityManager;

    private EntityManagerFactory getEntityManagerFactory() {
        if (entityManagerFactory == null) {
            entityManagerFactory = Persistence.createEntityManagerFactory("service-enabler-unit-test");
        }
        return entityManagerFactory;
    }

    @AfterClass
    public static void afterClass() {
        if (entityManagerFactory != null) {
            entityManagerFactory.close();
            entityManagerFactory = null;
        }
    }

    @Before
    public void openEntityManager() throws Exception {
        entityManager = getEntityManagerFactory().createEntityManager();
    }

    @After
    public void closeEntityManager() {
        if (entityManager != null && entityManager.isOpen()) {
            entityManager.close();
        }
    }

    /**
     * Allows to execute some code in a transaction.
     */
    private <T> T executeInTransaction(final TransactionCallback<T> transactionCallback) {
        final EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();
        T result = null;

        result = transactionCallback.doInTransaction(entityManager);

        transaction.commit();
        entityManager.clear();

        return result;
    }

    public <T> T insert(final T entity) throws Exception {
        return executeInTransaction(new TransactionCallback<T>() {

            @Override
            public T doInTransaction(final EntityManager entityManager) {
                entityManager.persist(entity);
                return entity;
            }
        });
    }

    public <T> T findById(final Class<T> entityType, final Object id) throws Exception {
        return executeInTransaction(new TransactionCallback<T>() {

            @Override
            public T doInTransaction(final EntityManager entityManager) {
                return entityManager.find(entityType, id);
            }
        });
    }

    protected interface TransactionCallback<T> {
        T doInTransaction(EntityManager entityManager);
    }

    @Test
    public void testLowLevelLeafCreationAndRemoval() throws Exception {
        final Long id = 1L;
        final LeafB leaf = new LeafB(id);

        insert(leaf);

        assertThat(findById(LeafB.class, id), notNullValue());

        executeInTransaction(new TransactionCallback<Void>() {

            @Override
            public Void doInTransaction(final EntityManager entityManager) {
                final LeafB found = entityManager.find(LeafB.class, id);
                assertNotNull(found);
                assertNull(found.getParent());
                entityManager.remove(found);
                return null;
            }
        });

        // check if deleted
        assertThat(findById(LeafB.class, id), nullValue());
    }

    @Test
    public void testMidLevelAggregateCreationAndRemoval() throws Exception {
        final Long idB = 2L;
        final LeafB leafB = new LeafB(idB);

        final Long idA = 3L;
        final LeafA leafA = new LeafA(idA);
        leafA.addToLeafB(leafB);

        insert(leafA);

        executeInTransaction(new TransactionCallback<Void>() {

            @Override
            public Void doInTransaction(final EntityManager entityManager) {
                final LeafA foundA = entityManager.find(LeafA.class, idA);
                assertNotNull(foundA);
                assertNull(foundA.getParent());

                final LeafB associatedB = foundA.findLeafB(idB);
                assertNotNull(associatedB);
                assertEquals(foundA, associatedB.getParent());

                assertEquals(1, leafA.getNumberOfLeafB());
                return null;
            }
        });

        executeInTransaction(new TransactionCallback<Void>() {

            @Override
            public Void doInTransaction(final EntityManager entityManager) {
                final LeafA found = entityManager.find(LeafA.class, idA);
                assertNotNull(found);
                assertNull(found.getParent());
                entityManager.remove(found);
                return null;
            }
        });

        // check if deleted
        assertThat(findById(LeafB.class, idB), nullValue());
        assertThat(findById(LeafA.class, idA), nullValue());
    }

    @Test
    public void testTopLevelObjectCreationAndRemoval() throws Exception {
        final Long idB = 4L;
        final LeafB leafB = new LeafB(idB);

        final Long idA = 5L;
        final LeafA leafA = new LeafA(idA);
        leafA.addToLeafB(leafB);

        final Long idTop = 6L;
        final TopLevel top = new TopLevel(idTop);
        top.setLeafA(leafA);

        insert(top);

        executeInTransaction(new TransactionCallback<Void>() {

            @Override
            public Void doInTransaction(final EntityManager entityManager) {
                final TopLevel foundTop = entityManager.find(TopLevel.class, idTop);
                assertNotNull(foundTop);

                final LeafA associatedA = foundTop.getLeafA();
                assertNotNull(associatedA);
                assertEquals(foundTop, associatedA.getTopLevel());
                assertNull(associatedA.getParent());
                assertEquals(1, associatedA.getNumberOfLeafB());

                final LeafB associatedB = associatedA.findLeafB(idB);
                assertNotNull(associatedB);
                assertEquals(associatedA, associatedB.getParent());

                return null;
            }
        });

        executeInTransaction(new TransactionCallback<Void>() {

            @Override
            public Void doInTransaction(final EntityManager entityManager) {
                final TopLevel foundTop = entityManager.find(TopLevel.class, idTop);
                assertNotNull(foundTop);
                entityManager.remove(foundTop);
                return null;
            }
        });

        // check if deleted
        assertThat(findById(LeafB.class, idB), nullValue());
        assertThat(findById(LeafA.class, idA), nullValue());
        assertThat(findById(TopLevel.class, idTop), nullValue());
    }

    @Test
    public void testTopLevelObjectCreationAndMidLevelAggregateRemoval() throws Exception {
        final Long idB = 7L;
        final LeafB leafB = new LeafB(idB);

        final Long idA = 8L;
        final LeafA leafA = new LeafA(idA);
        leafA.addToLeafB(leafB);

        final Long idTop = 9L;
        final TopLevel top = new TopLevel(idTop);
        top.setLeafA(leafA);

        insert(top);

        executeInTransaction(new TransactionCallback<Void>() {

            @Override
            public Void doInTransaction(final EntityManager entityManager) {
                final TopLevel foundTop = entityManager.find(TopLevel.class, idTop);
                assertNotNull(foundTop);

                final LeafA associatedA = foundTop.getLeafA();
                assertNotNull(associatedA);
                assertEquals(foundTop, associatedA.getTopLevel());
                assertNull(associatedA.getParent());
                assertEquals(1, associatedA.getNumberOfLeafB());

                final LeafB associatedB = associatedA.findLeafB(idB);
                assertNotNull(associatedB);
                assertEquals(associatedA, associatedB.getParent());

                return null;
            }
        });

        executeInTransaction(new TransactionCallback<Void>() {

            @Override
            public Void doInTransaction(final EntityManager entityManager) {
                final TopLevel foundTop = entityManager.find(TopLevel.class, idTop);
                // final LeafA leaf = foundTop.getLeafA();
                foundTop.setLeafA(null);
                // entityManager.remove(leaf);
                return null;
            }
        });

        // check if deleted
        assertThat(findById(LeafB.class, idB), nullValue());
        assertThat(findById(LeafA.class, idA), nullValue());
        assertThat(findById(TopLevel.class, idTop), notNullValue());
    }
}
