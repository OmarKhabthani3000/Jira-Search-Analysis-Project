package com.example;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table
public class TopLevel {

    @Id
    @Column(name = "TOP_ID", length = 36)
    private Long id;

    @OneToOne(mappedBy = "top", cascade = CascadeType.ALL, orphanRemoval = true)
    private LeafA leafA;

    @Version
    @Column(name = "VERSION")
    private Long version;

    protected TopLevel() {
        // for hibernate
    }

    public TopLevel(final Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public LeafA getLeafA() {
        return leafA;
    }

    public boolean hasLeafA() {
        return leafA != null;
    }

    public boolean setLeafA(final LeafA newLeafA) {
        boolean changed = false;

        if (leafA == null || !leafA.equals(newLeafA)) {

            final LeafA oldLeafA = leafA;

            if (leafA != null) {
                leafA = null;
                oldLeafA.setTopLevel(null);
            }
            leafA = newLeafA;

            if (newLeafA != null) {
                leafA.setTopLevel(this);
            }

            changed = true;
        }

        return changed;
    }
}
