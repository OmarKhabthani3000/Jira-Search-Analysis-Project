package com.example;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "TYPE", discriminatorType = DiscriminatorType.STRING, length = 50)
public abstract class AbstractAggregate {

    @Id
    @Column(name = "ID", length = 36)
    private Long id;

    @ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH })
    @JoinColumn(name = "PARENT_ID", updatable = false)
    private AbstractAggregate parent;

    @OneToMany(mappedBy = "parent", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<AbstractAggregate> associatedAggregate = new HashSet<>();

    @Version
    @Column(name = "VERSION")
    private Long version;

    protected AbstractAggregate() {
        // for hibernate
    }

    protected AbstractAggregate(final Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    protected boolean setParent(final AbstractAggregate value) {
        boolean changed = false;

        if (parent != value) {

            final AbstractAggregate oldParent = parent;

            if (parent != null) {
                parent = null;
                oldParent.removeFromLeafs(this);
            }
            parent = value;

            if (value != null) {
                value.addToLeafs(this);
            }

            changed = true;
        }
        return changed;
    }

    protected AbstractAggregate getParent() {
        return parent;
    }

    protected boolean addToLeafs(final AbstractAggregate aggregate) {
        boolean changed = false;

        if (associatedAggregate != null) {
            // using vanilla java.util collections one does not need
            // to check for containment, collection.add is sufficient
            // We're here however within a persistence context.
            // This way we've to add this additional check.
            if (!associatedAggregate.contains(aggregate)) {
                changed = associatedAggregate.add(aggregate);
                aggregate.setParent(this);
            }
        }
        return changed;
    }

    protected boolean removeFromLeafs(final AbstractAggregate aggregate) {
        boolean changed = false;

        if (associatedAggregate != null && aggregate != null) {
            changed = associatedAggregate.remove(aggregate);
            if (changed) {
                aggregate.setParent(null);
            }
        }
        return changed;
    }

    protected void removeAllLeafs() {
        final Iterator<AbstractAggregate> iterator = associatedAggregate.iterator();
        while (iterator.hasNext()) {
            final AbstractAggregate container = iterator.next();
            iterator.remove();
            container.setParent(null);
        }
    }

    protected Collection<AbstractAggregate> getAssociatedAggregates() {
        return Collections.unmodifiableCollection(associatedAggregate);
    }

    protected int getNumberOfLeafs() {
        return associatedAggregate.size();
    }

    protected boolean hasAssociatedLeaf() {
        return !associatedAggregate.isEmpty();
    }

    @Override
    public int hashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder();
        builder.append(id);
        return builder.build();
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj instanceof AbstractAggregate) {
            final AbstractAggregate other = (AbstractAggregate) obj;
            final EqualsBuilder builder = new EqualsBuilder();
            builder.append(id, other.id);
            return builder.isEquals();
        }

        return false;
    }
}
