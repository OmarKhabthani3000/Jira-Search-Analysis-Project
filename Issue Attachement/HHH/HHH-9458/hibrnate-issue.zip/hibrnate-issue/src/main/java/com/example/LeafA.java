package com.example;

import static com.google.common.collect.Iterables.find;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.google.common.base.Predicate;

@Entity
@DiscriminatorValue(value = "A")
public class LeafA extends AbstractAggregate {

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TOP_ID")
    private TopLevel top;

    protected LeafA() {
        super();
        // for hibernate
    }

    public LeafA(final Long id) {
        super(id);
    }

    public TopLevel getTopLevel() {
        return top;
    }

    boolean setTopLevel(final TopLevel value) {
        boolean changed = false;

        if (top == null || !top.equals(value)) {

            final TopLevel oldTop = top;

            if (top != null) {
                top = null;
                oldTop.setLeafA(null);
            }
            top = value;

            if (value != null) {
                top.setLeafA(this);
            }

            changed = true;
        }

        return changed;
    }

    public boolean addToLeafB(final LeafB value) {
        return addToLeafs(value);
    }

    public boolean removeFromLeafB(final LeafB value) {
        return removeFromLeafs(value);
    }

    public void removeAllLeafB() {
        removeAllLeafs();
    }

    public Collection<LeafB> getLeafB() {
        final Collection<AbstractAggregate> associateAggregates = getAssociatedAggregates();
        final List<LeafB> tmp = new ArrayList<>(associateAggregates.size());
        for (final AbstractAggregate value : associateAggregates) {
            tmp.add((LeafB) value);
        }
        return Collections.unmodifiableCollection(tmp);
    }

    public int getNumberOfLeafB() {
        return getNumberOfLeafs();
    }

    public boolean hasLeafB() {
        return hasAssociatedLeaf();
    }

    public LeafB findLeafB(final Long id) {
        return (LeafB) find(getAssociatedAggregates(), new Predicate<AbstractAggregate>() {
            @Override
            public boolean apply(final AbstractAggregate value) {
                return ((LeafB) value).getId().equals(id);
            }
        }, null);
    }

    @Override
    public int hashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder();
        builder.appendSuper(super.hashCode());
        return builder.build();
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj instanceof LeafA) {
            final LeafA other = (LeafA) obj;
            final EqualsBuilder builder = new EqualsBuilder();
            builder.appendSuper(super.equals(obj));
            if (top != null && other.top != null) {
                builder.append(top, other.top);
            }
            return builder.isEquals();
        }

        return false;
    }
}
