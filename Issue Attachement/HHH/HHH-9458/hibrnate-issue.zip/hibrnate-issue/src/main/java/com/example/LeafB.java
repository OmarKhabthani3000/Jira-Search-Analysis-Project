package com.example;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "B")
public class LeafB extends AbstractAggregate {

    protected LeafB() {

    }

    public LeafB(final Long id) {
        super(id);
    }

    public LeafA getLeafA() {
        return (LeafA) getParent();
    }
}
