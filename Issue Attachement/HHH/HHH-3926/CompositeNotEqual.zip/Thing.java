import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Thing
{
  @Id
  private ThingId id;
  
  public Thing()
  {
    super();
  }

  public Thing(String aTenant, String anItem)
  {
    id = new ThingId(aTenant, anItem);
  }

  public Object getTenant()
  {
    return id.getTenant();
  }
  
  public Object getItem()
  {
    return id.getItem();
  }

  @Override
  public String toString()
  {
    return "Thing[" + id.getTenant() + "," + id.getItem() + "]";
  }

  @Embeddable
  private static class ThingId implements Serializable
  {
    private static final long serialVersionUID = -3750011301564075542L;

    String tenant;
    String item;
    
    public ThingId()
    {
      super();
    }
    
    public ThingId(String aTenant, String anItem)
    {
      tenant = aTenant;
      item = anItem;
    }

    public String getTenant()
    {
      return tenant;
    }

    public String getItem()
    {
      return item;
    }
  }
}
