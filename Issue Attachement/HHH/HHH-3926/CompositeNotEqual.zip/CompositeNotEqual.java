import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;


public class CompositeNotEqual
{
  public static void main(String[] args)
  {
    AnnotationConfiguration cfg = new AnnotationConfiguration();
    cfg.configure("hibernate.cfg.xml");
    SessionFactory sf = cfg.buildSessionFactory();
    Session session = sf.openSession();
    
    Thing a = new Thing("1", "A");
    Container containerA = new Container(a);
    session.persist(a);
    session.persist(containerA);

    Thing b = new Thing("1", "B");
    Container containerB = new Container(b);
    session.persist(b);
    session.persist(containerB);

    Thing c = new Thing("2", "C");
    Container containerC = new Container(c);
    session.persist(c);
    session.persist(containerC);

    session.flush();
    session.clear();

    Criteria ca = session.createCriteria(Container.class);
    ca.add(Restrictions.ne("thing", a));
    for(Object o : ca.list()) {
      System.out.println("list returned " + o);
    }
  }
}
