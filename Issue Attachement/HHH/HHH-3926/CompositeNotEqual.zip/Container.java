import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Container
{
  @Id
  @GeneratedValue
  private Long id;

  @ManyToOne
  private Thing thing;
  
  public Container()
  {
    super();
  }
  
  public Container(Thing aThing)
  {
    thing = aThing;
  }
  
  @Override
  public String toString()
  {
    return "Container[" + id + "," + thing + "]";
  }
}
