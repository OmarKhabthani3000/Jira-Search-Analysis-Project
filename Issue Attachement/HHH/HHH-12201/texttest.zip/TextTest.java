/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package texttest;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;

/**
 *
 * @author Jürgen Simon
 */
public class TextTest {
    
    private static final String TEXT = "Das ist ein Test";
    
    private void test() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("TextTestPU");
        EntityManager em = emf.createEntityManager();
        Object o = em.createQuery("select count(p) from Parent p").getSingleResult();
        if (Long.valueOf(0).equals(o)) {
            em.getTransaction().begin();
            Parent p = new Parent();
            p.setTestText(TEXT);
            em.persist(p);
            em.getTransaction().commit();
            em.close();
            System.out.println("Testdaten erzeugt.");
        } else {
            try {
                em.createQuery("select p from Parent p where p.testText like '%ist%'", Parent.class).getSingleResult();
                System.out.println("Compare ok");
            } catch (NoResultException ex) {
                System.err.println("Compare failed");
            }
            Parent p = em.createQuery("select p from Parent p", Parent.class).getSingleResult();
            if (TEXT.equals(p.getTestText())) {
                System.out.println("Read OK");
            } else {
                System.err.println("Read Error: " + p.getTestText());
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            new TextTest().test();
        } catch (Throwable ex) {
            while (ex.getCause() != null) {
                ex = ex.getCause();
            }
            System.err.println("Error: " + ex.getMessage());
            System.exit(-1);
        }
        System.exit(0);
    }
    
}
