package otherTests;

import org.hibernate.Session;
import org.hibernate.Transaction;

import test.TestCase;


/**
 * No actual test, but only test data initialization.
 *
 * @author Christian Bauer <christian@hibernate.org>
 */
public abstract class TestCaseWithData extends TestCase {

	protected void initData(){
		Category cat = new Category();
		cat.setName("uniqueName");
		try{
			Session session = openSession();
			Transaction tx = session.beginTransaction();
			session.save(cat);
			tx.commit();
			session.close();
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}

	public TestCaseWithData(String x) {
		super(x);
	}
	

}
