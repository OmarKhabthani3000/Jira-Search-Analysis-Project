package otherTests;

import java.util.List;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import cours4.model.Coach;
import cours4.model.Rookie;
import cours4.model.Team;


/**
 * @author Anthony
 *
 */
public class UniqueAutoFlushTest extends TestCaseWithData{

	public void testUniqueAutoFlushTest() throws Exception  {
		initData();
		Session session = openSession();
		Transaction tx=null;
		try {
		  tx = session.beginTransaction();
		  Category cat1 = (Category)session.get(Category.class, new Long(1));
		  session.delete(cat1);
		  Category cat2 = new Category();
		  cat2.setName("uniqueName");
		  session.persist(cat2);
		  tx.commit();
		  
		}
		catch (Exception e) {
		  if (tx!=null) tx.rollback();	
		  throw e;
		}
		finally {
		  session.close();
		}

	}
	


	
	public UniqueAutoFlushTest(String arg0) {
		super(arg0);
	}
	
	public String[] getMappings() {
		return new String[] {"otherTests/Category.hbm.xml"};
	}

	public static Test suite() {
		return new TestSuite(UniqueAutoFlushTest.class);
	}
	
	public static void main(String[] args) throws Exception {
		TestRunner.run( suite() );
	}
}
