/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package db;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.output.MigrateResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

public abstract class BaseTest {

    protected static final Logger LOGGER = LogManager.getLogger();

    private EntityManagerFactory emf;
    private EntityManager em;

    @BeforeClass
    protected void beforeClass() {
        Flyway flyway = Flyway.configure()
                .dataSource("jdbc:hsqldb:mem:jpa_test", "user", "password")
                .locations("classpath:/db").load();
        MigrateResult migrateResult = flyway.migrate();
        LOGGER.info("Migrations executed: {}", migrateResult.migrationsExecuted);
        emf = Persistence.createEntityManagerFactory("jpa_test");
    }

    @BeforeMethod
    protected void beforeMethod() {
        em = emf.createEntityManager();
        em.getTransaction().begin();
    }

    @AfterMethod
    protected void afterMethod() {
        em.flush();
        em.getTransaction().rollback();
        em.close();
        em = null;
    }

    @AfterClass
    protected void afterClass() {
        emf.close();
        emf = null;
    }

    protected final EntityManager getEm() {
        return em;
    }

    protected final CriteriaBuilder getCb() {
        return getEm().getCriteriaBuilder();
    }
}
