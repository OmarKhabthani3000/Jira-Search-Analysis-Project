/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package db;

import static org.assertj.core.api.Assertions.assertThat;
import org.testng.annotations.Test;

public class SelectTest extends BaseTest {


    @Test
    public void select() {
        //given
        var query = getCb().createQuery(Primary.class);
        var root = query.from(Primary.class);
        query.select(root);
        //when
        var typedQuery = getEm().createQuery(query);
        var list = typedQuery.getResultList();
        //then
        assertThat(list).isNotEmpty();
    }
}
