
create schema test;

create table test.t_secondary (
    tid integer not null,
    nid integer not null,
    constraint t_secondary_pkey primary key (tid, nid)
);
grant all on test.t_secondary to "user";

insert into test.t_secondary(tid, nid) values (1, 2);


create table test.t_primary (
    ptid integer not null,
    pnid integer not null,
    constraint t_primary_pkey primary key (ptid, pnid),
    constraint t_primary_t_secondary_fkey foreign key(ptid, pnid)
        references test.t_secondary(tid, nid) match full
);

grant all on test.t_primary to "user";

insert into test.t_primary(ptid, pnid) values(1, 2);
