/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package db;

import jakarta.persistence.Embeddable;
import jakarta.persistence.Embedded;
import java.io.Serializable;

@Embeddable
public class TopId implements Serializable {

    private int tid;
    @Embedded
    private NestedId nestedId;

    public int getTid() {
        return tid;
    }

    public void setTid(int tid) {
        this.tid = tid;
    }

    public NestedId getNestedId() {
        return nestedId;
    }

    public void setNestedId(NestedId nestedId) {
        this.nestedId = nestedId;
    }
}
