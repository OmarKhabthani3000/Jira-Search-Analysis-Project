/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package db;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(schema = "test", name = "t_secondary")
public class Secondary implements Serializable {

    @EmbeddedId
    private TopId id;

    public TopId getId() {
        return id;
    }

    public void setId(TopId id) {
        this.id = id;
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Secondary record = (Secondary) o;
        return Objects.equals(id, record.id);
    }

    @Override public int hashCode() {
        return Objects.hash(id);
    }
}
