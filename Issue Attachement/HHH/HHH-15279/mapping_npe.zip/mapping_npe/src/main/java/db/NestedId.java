/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package db;

import jakarta.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class NestedId implements Serializable {

    private int nid;

    public int getNid() {
        return nid;
    }

    public void setNid(int nid) {
        this.nid = nid;
    }
}
