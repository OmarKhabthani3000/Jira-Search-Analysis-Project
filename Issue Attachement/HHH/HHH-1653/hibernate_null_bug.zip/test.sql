DROP TABLE IF EXISTS test;
CREATE TABLE test
(
  id int not null primary key auto_increment,
  string varchar(255) default NULL,
  bool   char(1) NOT NULL
);

INSERT INTO test (string, bool) VALUES ('value1', 0);
INSERT INTO test (string, bool) VALUES ('value2', 1);
INSERT INTO test (string, bool) VALUES ('value3', 0);
INSERT INTO test (string, bool) VALUES ('value4', 1);
INSERT INTO test (string, bool) VALUES ('', 0);
INSERT INTO test (string, bool) VALUES ('', 1);
INSERT INTO test (string, bool) VALUES ('', 0);
INSERT INTO test (string, bool) VALUES ('', 1);
INSERT INTO test (string, bool) VALUES (NULL, 0);
INSERT INTO test (string, bool) VALUES (NULL, 1);
INSERT INTO test (string, bool) VALUES (NULL, 0);
INSERT INTO test (string, bool) VALUES (NULL, 1);
