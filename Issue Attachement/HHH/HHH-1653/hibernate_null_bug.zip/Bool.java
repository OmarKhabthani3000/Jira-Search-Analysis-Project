
public class Bool
{
  protected long id = -1;
  protected String string = "";
  protected Boolean bool = Boolean.FALSE;

  public long getId() {
    return this.id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public String getString() {
    return this.string;
  }

  public void setString(String string) {
    this.string = string;
  }

  public Boolean getBool() {
    return this.bool;
  }

  public void setBool(Boolean bool) {
    this.bool = bool;
  }

  public String toString() {
    return getClass().toString() + " - " +
      "id: " + id +
      " string: " + string +
      " bool: " + bool;
  }
}
