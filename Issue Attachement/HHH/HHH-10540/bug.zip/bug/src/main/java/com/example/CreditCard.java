package com.example;

import javax.persistence.Embeddable;

@Embeddable
public class CreditCard implements SomeInterface {
    private String ccNum;

	public String getCcNum() {
		return ccNum;
	}
	
	public void setCcNum(String ccNum) {
		this.ccNum = ccNum;
	}
}
