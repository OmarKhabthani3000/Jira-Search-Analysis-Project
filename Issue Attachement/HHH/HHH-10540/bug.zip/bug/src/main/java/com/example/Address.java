package com.example;

import javax.persistence.Embeddable;

@Embeddable
public class Address implements SomeInterface {
    private String line1;
    
	public String getLine1() {
		return line1;
	}
	
	public void setLine1(String line1) {
		this.line1 = line1;
	}
}
