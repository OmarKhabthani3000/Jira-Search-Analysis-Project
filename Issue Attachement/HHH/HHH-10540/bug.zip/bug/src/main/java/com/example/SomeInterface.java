package com.example;

public interface SomeInterface {
}
