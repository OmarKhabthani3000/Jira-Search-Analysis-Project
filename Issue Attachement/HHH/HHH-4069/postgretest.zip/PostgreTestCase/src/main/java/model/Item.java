package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.SequenceGenerator;

/**
 * Abstract superclass for items: product, project
 * @author Gajo Csaba
 * @version 1.0
 */
@Entity
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)  
public abstract class Item {

	private Integer idItem;
	private String name = "";
	
	public Item() {}
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ir_item_seq")
	@SequenceGenerator(name="ir_item_seq", sequenceName="ir_item_seq")
	@Column(name="id_item")
	public Integer getIdItem() {
		return idItem;
	}

	public void setIdItem(Integer idItem) {
		this.idItem = idItem;
	}

	@Column(name="name")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int hashCode() {
		int result = super.hashCode();
		if (name != null) result *= name.hashCode();
		if (idItem != null) result *= idItem.hashCode();
		return result;
	}

}