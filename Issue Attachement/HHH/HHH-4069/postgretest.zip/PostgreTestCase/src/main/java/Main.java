import model.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;

/**
 * Main class
 * @author Gajo Csaba
 * @version 1.0
 */
public class Main {

	public static void main(String[] args) throws Exception {
		AnnotationConfiguration cfg = new AnnotationConfiguration();
		cfg.addAnnotatedClass(Item.class);
		cfg.addAnnotatedClass(Product.class);
		cfg.addAnnotatedClass(Project.class);
		cfg.setProperty("hibernate.dialect", "org.hibernate.dialect.PostgreSQLDialect");
		cfg.setProperty("hibernate.default_schema", "iprojekti");
		cfg.setProperty("hibernate.query.factory_class", "org.hibernate.hql.ast.ASTQueryTranslatorFactory");
		cfg.setProperty("hibernate.hbm2ddl.auto", "off");
		cfg.setProperty("hibernate.show_sql", "true");
		cfg.setProperty("hibernate.format_sql", "true");
		cfg.setProperty("hibernate.jdbc.batch_size", "30");
		
		cfg.setProperty("hibernate.connection.driver_class", "org.postgresql.Driver");
		cfg.setProperty("hibernate.connection.url", "jdbc:postgresql://localhost/sg");
		cfg.setProperty("hibernate.connection.username", "postgres");
		cfg.setProperty("hibernate.connection.password", "postgres");
		cfg.setProperty("hibernate.c3p0.min_size", "5");
		cfg.setProperty("hibernate.c3p0.max_size", "20");
		cfg.setProperty("hibernate.c3p0.timeout", "1800");
		cfg.setProperty("hibernate.c3p0.max_statements", "50");
		
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		
		try {
			testWithCriteria(sessionFactory);
		} finally {
			sessionFactory.close();
		}

	}
	
	// this does not work
	private static void testWithCriteria(SessionFactory sessionFactory) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			
			DetachedCriteria criteria = DetachedCriteria.forClass(Item.class);
			criteria.add(Property.forName("idItem").eq(1));
			
			// without these projections, the criteria will work fine
			criteria.setProjection(Projections.projectionList()
										.add(Projections.property("idItem"), "idItem")
										.add(Projections.property("name"), "name"));
			
			criteria.getExecutableCriteria(session).list();  // error
			
		} finally {
			if (session != null) session.close();
		}
	}
	
}