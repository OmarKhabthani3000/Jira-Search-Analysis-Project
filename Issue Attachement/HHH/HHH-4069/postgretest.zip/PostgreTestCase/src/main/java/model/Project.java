package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Project item
 * @author Gajo Csaba
 * @version 1.0
 */
@Entity
@Table(name="ir_project")
public class Project extends Item {

	private double profit;
	
	public Project() {}

	@Column(name="profit")
	public double getProfit() {
		return profit;
	}

	public void setProfit(double profit) {
		this.profit = profit;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Project) {
			Project that = (Project)obj;
			if (that == this)
				return true;
			else {
				return this.getIdItem().equals(that.getIdItem()) &&
			       this.getName().equals(that.getName()) &&
			       this.getProfit() == that.getProfit();
			}
		} 
		return false;
	}
	
	@Override
	public int hashCode() {
		int result = super.hashCode();
		if (getProfit() != 0)
			result *= getProfit();
		return result;
	}
	
	public String toString() {
		return "[Project idItem: " + getIdItem() + ", name: " + getName() + ", profit: " + profit + "]";
	}
	
}
