package model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Product item
 * @author Gajo Csaba
 * @version 1.0
 */
@Entity
@Table(name="ir_product")
public class Product extends Item {

	private Date launchDate;

	@Column(name="launch_date")
	@Temporal(TemporalType.DATE)
	public Date getLaunchDate() {
		return launchDate;
	}

	public void setLaunchDate(Date launchDate) {
		this.launchDate = launchDate;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Product) {
			Product that = (Product)obj;
			if (that == this)
				return true;
			else {
				return this.getIdItem().equals(that.getIdItem()) &&
				       this.getName().equals(that.getName()) &&
				       this.getLaunchDate().equals(that.getLaunchDate());
			}
		} 
		return false;
	}
	
	@Override
	public int hashCode() {
		int result = super.hashCode();
		result *= getLaunchDate().hashCode();
		return result;
	}
	
	public String toString() {
		return "[Product idItem: " + getIdItem() + ", name: " + getName() + ", launchDate: " + launchDate + "]";
	}
	
}
