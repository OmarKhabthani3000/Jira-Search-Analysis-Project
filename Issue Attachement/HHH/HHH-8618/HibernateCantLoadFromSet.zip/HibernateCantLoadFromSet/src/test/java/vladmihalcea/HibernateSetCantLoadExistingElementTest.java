package vladmihalcea;

import org.hibernate.exception.ConstraintViolationException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;
import vladmihalcea.hibernate.model.store.Image;
import vladmihalcea.hibernate.model.store.Product;
import vladmihalcea.hibernate.model.store.Version;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring/applicatonContext.xml"})
public class HibernateSetCantLoadExistingElementTest {

    private static final Logger LOG = LoggerFactory.getLogger(HibernateSetCantLoadExistingElementTest.class);

    @PersistenceContext(unitName = "testPersistenceUnit")
    private EntityManager entityManager;

    @Autowired
    private PlatformTransactionManager platformTransactionManager;

    private TransactionTemplate transactionTemplate;

    @PostConstruct
    private void init() {
        transactionTemplate = new TransactionTemplate(platformTransactionManager);
    }

    @Before
    public void beforeTest() {
        clean();
    }

    @Test
    public void testEqualsHashCode() {
        Set<Product> products = new LinkedHashSet<Product>();
        Set<Image> images = new LinkedHashSet<Image>();

        Product product = new Product();
        product.setName("TV");
        products.add(product);
        assertTrue(products.contains(product));
        assertTrue(products.iterator().next().equals(product));


        Image frontImage = new Image();
        frontImage.setName("front image");
        images.add(frontImage);
        assertTrue(images.contains(frontImage));
        assertTrue(images.iterator().next().equals(frontImage));
    }

    @Test
    public void testCantFindEntityInSet() {

        final Long productId = transactionTemplate.execute(new TransactionCallback<Long>() {
            @Override
            public Long doInTransaction(TransactionStatus transactionStatus) {
                Product product = new Product();
                product.setName("TV");

                Image frontImage = new Image();
                frontImage.setName("front image");
                frontImage.setIndex(0);

                Image sideImage = new Image();
                sideImage.setName("side image");
                sideImage.setIndex(1);

                product.addImage(frontImage);
                product.addImage(sideImage);

                entityManager.persist(product);
                return product.getId();
            }
        });
        transactionTemplate.execute(new TransactionCallback<Void>() {
            @Override
            public Void doInTransaction(TransactionStatus transactionStatus) {
                Product product = entityManager.find(Product.class, productId);
                assertEquals(2, product.getImages().size());
                Iterator<Image> imageIterator = product.getImages().iterator();

                Image frontImage = imageIterator.next();
                assertEquals("front image", frontImage.getName());
                Image sideImage = imageIterator.next();
                assertEquals("side image", sideImage.getName());

                Image backImage = new Image();
                sideImage.setName("back image");
                sideImage.setIndex(1);

                assertTrue(new ArrayList<Image>(product.getImages()).contains(sideImage));
                assertTrue(product.getImages().contains(sideImage));

                //No remove since sideImage is not found
                product.removeImage(sideImage);
                product.addImage(backImage);
                product.setName("tv set");

                entityManager.merge(product);
                return null;
            }
        });
    }

    protected void clean() {
        transactionTemplate.execute(new TransactionCallback<Void>() {
            @Override
            public Void doInTransaction(TransactionStatus transactionStatus) {
                entityManager.createQuery("delete from Version where id > 0").executeUpdate();
                entityManager.createQuery("delete from Image where id > 0").executeUpdate();
                entityManager.createQuery("delete from Product where id > 0").executeUpdate();
                return null;
            }
        });
    }
}
