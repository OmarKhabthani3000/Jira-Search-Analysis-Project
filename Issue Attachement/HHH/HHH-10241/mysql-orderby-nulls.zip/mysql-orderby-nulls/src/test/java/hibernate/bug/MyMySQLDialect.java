package hibernate.bug;

import java.util.List;
import org.hibernate.QueryException;
import org.hibernate.dialect.MySQL5InnoDBDialect;
import org.hibernate.dialect.function.SQLFunction;
import org.hibernate.engine.spi.Mapping;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.type.Type;

public class MyMySQLDialect extends MySQL5InnoDBDialect {

    public MyMySQLDialect() {
        registerFunction("limit", new SQLFunction() {

            public boolean hasArguments() {
                return true;
            }

            public boolean hasParenthesesIfNoArguments() {
                return true;
            }

            public Type getReturnType(Type firstArgumentType, Mapping mapping) throws QueryException {
                return firstArgumentType;
            }

            public String render(Type firstArgumentType, List arguments, SessionFactoryImplementor factory) throws QueryException {
                String query = (String) arguments.get(0);
                // NOTE: the problem is that the order by is messed up in the query
                return "(SELECT * FROM (" + unwrap(query) + " limit " + arguments.get(1) + ") AS _tmp_";
            }

            private String unwrap(String query) {
                return query.substring(1, query.length() - 1);
            }
        });
    }
    
}
