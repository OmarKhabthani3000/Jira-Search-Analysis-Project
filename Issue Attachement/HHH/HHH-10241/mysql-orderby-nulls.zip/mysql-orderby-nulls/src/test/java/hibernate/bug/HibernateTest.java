package hibernate.bug;

import hibernate.bug.model.Document;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test", createProperties());
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        em.persist(new Document());
        em.persist(new Document("a"));
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void test() {
        EntityManager em = emf.createEntityManager();
        
        List<String> l = em.createQuery("SELECT d.name FROM Document d WHERE d.id IN (LIMIT((SELECT subDoc.id FROM Document subDoc ORDER BY subDoc.name ASC NULLS LAST),1))", String.class).getResultList();
        Assert.assertEquals(1, l.size());
        Assert.assertNull(l.get(0));
        
        em.close();
    }

    private Map createProperties() {
        Properties p = new Properties();
        p.put("javax.persistence.jdbc.url", "jdbc:mysql://localhost:3306/test?useUnicode=true&amp;characterEncoding=utf8");
        p.put("javax.persistence.jdbc.user", "root");
        p.put("javax.persistence.jdbc.password", "");
        p.put("javax.persistence.jdbc.driver", "com.mysql.jdbc.Driver");
        p.put("hibernate.dialect", MyMySQLDialect.class.getName());
        return p;
    }
}
