package main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Main
{
	private static String PERSISTENCE_UNIT_NAME = "standalonePu";

	private static EntityManagerFactory emf;
	private static EntityManager em;
	private static EntityTransaction trans;

	public static void main(String[] args)
	{
		System.out.println("Classpath = " + System.getProperty("java.class.path"));
		
		setUp(PERSISTENCE_UNIT_NAME);
		trans.begin();

		PQ detachedPq = new PQ(1, "Test PQ");
		Company detachedCompany = new Company(1, "Test Company");
		
		PQ pq = em.merge(detachedPq);
		Company company = em.merge(detachedCompany);
		
		Partnership detachedPartnership = new Partnership(1, 1, 1);
		detachedPartnership.setPQ(pq);
		detachedPartnership.setCompany(company);
		
		Partnership partnership = em.merge(detachedPartnership);
		
		partnership = em.find(Partnership.class, new PartnershipId(1, 1));
		
		System.out.println("Persistent partnership = ("
			+ partnership.getPQId() + ", "
			+ partnership.getCompanyId() + ", "
			+ partnership.getOrdinalNbr() + ")");
		
		trans.commit();
		close();
	}

	private static void setUp(String puName)
	{
		emf = Persistence.createEntityManagerFactory(puName);
		em = emf.createEntityManager();
		trans = em.getTransaction();
	}

	private static void close()
	{
		em.close();
		emf.close();
	}

}