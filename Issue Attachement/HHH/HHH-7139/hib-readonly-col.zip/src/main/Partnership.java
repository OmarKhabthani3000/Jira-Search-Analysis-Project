package main;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Partnerships")
@IdClass(value = PartnershipId.class)
public class Partnership implements Serializable
{
	@Id
	@Column(name = "pq_id", insertable = false, updatable = false)
	private Integer pqId;

	@Id
	@Column(name = "company_id", insertable = false, updatable = false)
	private Integer companyId;

	@Column(name = "ordinal_nbr")
	private Integer ordinalNbr;

	@ManyToOne
	@JoinColumn(name = "pq_id", referencedColumnName = "id")
	private PQ pq;

	@ManyToOne
	@JoinColumn(name = "company_id", referencedColumnName = "id")
	private Company company;

	public Partnership()
	{
	}

	public Partnership(Integer pqId, Integer companyId, Integer ordinalNbr)
	{
		this.pqId = pqId;
		this.companyId = companyId;
		this.ordinalNbr = ordinalNbr;
	}

	public Integer getPQId()
	{
		return pqId;
	}

	public void setPQId(Integer pqId)
	{
		this.pqId = pqId;
	}

	public Integer getCompanyId()
	{
		return companyId;
	}

	public void setCompanyId(Integer companyId)
	{
		this.companyId = companyId;
	}

	public Integer getOrdinalNbr()
	{
		return ordinalNbr;
	}

	public void setOrdinalNbr(Integer ordinalNbr)
	{
		this.ordinalNbr = ordinalNbr;
	}

	public PQ getPQ()
	{
		return pq;
	}

	public void setPQ(PQ pq)
	{
		this.pq = pq;
	}

	public Company getCompany()
	{
		return company;
	}

	public void setCompany(Company company)
	{
		this.company = company;
	}

}
