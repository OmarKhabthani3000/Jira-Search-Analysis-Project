package main;

import java.io.Serializable;

public class PartnershipId implements Serializable
{
	private Integer pqId;

	private Integer companyId;

	public PartnershipId()
	{
	}

	public PartnershipId(Integer pqId, Integer companyId)
	{
		this.pqId = pqId;
		this.companyId = companyId;
	}

	public Integer getPQId()
	{
		return pqId;
	}

	public void setPQId(Integer pqId)
	{
		this.pqId = pqId;
	}

	public Integer getCompanyId()
	{
		return companyId;
	}

	public void setCompanyId(Integer companyId)
	{
		this.companyId = companyId;
	}
}
