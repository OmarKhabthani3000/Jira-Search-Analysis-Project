/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test.convertertest;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

/**
 *
 * @author mcmahanjd
 */
@Converter
public class ArrayToStringConverter implements AttributeConverter<String[], String> {

    @Override
    public String convertToDatabaseColumn(String[] attribute) {
        return (attribute == null || attribute.length == 0) ? "" : String.join(",", attribute);
    }

    @Override
    public String[] convertToEntityAttribute(String dbData) {
        return (dbData == null || dbData.isEmpty()) ? new String[0] : dbData.split(",");
    }
}