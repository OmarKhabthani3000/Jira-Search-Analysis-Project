
package com.checkernet.pickList.model;

import java.util.Collection;
import java.util.List;
import com.checkernet.common.model.BaseModelPOJO;

/**
 * Date: Sep 22, 2005 <br/>
 * Time: 10:54:00 AM <br/>
 * <br/>
 * Notes:<br/>
 * <br/>
 * View the <a id="viewSource" href="PickListInventoryPOJO.java.html">Source</a><br/>
 *
 * @author Walter Barnie
 * @version 0.0.1
 */

public class PickListInventoryPOJO extends BaseModelPOJO implements PickListInventory {

    // data
    private Float inventoryQuantity;

    private String description;

    private List inventoryBin;

    private Integer itemKey;

    private Integer createType;

    private String companyId;

    private String itemId;

    private Collection inventoryBins;

    private Integer additionalQuantity;

    /**
     * Unique ID for concurrency
     */
    private PickListInventoryUID uid;

    /**
     * getter for Unique ID
     *
     * @return PickListInventoryUID uid
     */
    public PickListInventoryUID getUid() {
        return uid;
    }

    /**
     * setter for Unique ID
     *
     * @param uid PickListInventoryUID
     */
    public void setUid(PickListInventoryUID uid) {
        this.uid = uid;
    }


    /**
     * getter for field
     *
     * @return Float
     */
    public Float getInventoryQuantity() {
        return inventoryQuantity;
    }

    /**
     * setter for field
     *
     * @param inventoryQuantity Float
     */
    public void setInventoryQuantity(Float inventoryQuantity) {
        this.inventoryQuantity = inventoryQuantity;
    }


    /**
     * getter for field
     *
     * @return String
     */
    public String getDescription() {
        return description;
    }

    /**
     * setter for field
     *
     * @param description String
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * {@inheritDoc}
     */
    public List getInventoryBin() {
        return inventoryBin;
    }

    /**
     * {@inheritDoc}
     */
    public void setInventoryBin(List inventoryBin) {
        this.inventoryBin = inventoryBin;
    }

    /**
     * getter for field
     *
     * @return String
     */
    public String getItemId() {
        return itemId;
    }

    /**
     * setter for field
     *
     * @param itemId String
     */
    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    /**
     * getter for field
     *
     * @return Integer
     */
    public Integer getItemKey() {
        return itemKey;
    }

    /**
     * setter for field
     *
     * @param itemKey Integer
     */
    public void setItemKey(Integer itemKey) {
        this.itemKey = itemKey;
    }

    /**
     * getter for field
     *
     * @return String
     */
    public String getCompanyId() {
        return companyId;
    }

    /**
     * setter for field
     *
     * @param companyId String
     */
    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    /**
     * getter for field
     *
     * @return Integer
     */
    public Integer getCreateType() {
        return createType;
    }

    /**
     * setter for field
     *
     * @param createType Integer
     */
    public void setCreateType(Integer createType) {
        this.createType = createType;
    }

    /**
     * getter for field
     *
     * @return Collection
     */
    public Collection getInventoryBins() {
        return inventoryBins;
    }

    /**
     * setter for field
     *
     * @param inventoryBins Collection
     */
    public void setInventoryBins(Collection inventoryBins) {
        this.inventoryBins = inventoryBins;
    }

    /**
     * getter for field
     *
     * @return Integer
     */
    public Integer getAdditionalQuantity() {
        return additionalQuantity;
    }

    /**
     * setter for field
     *
     * @param additionalQuantity Integer
     */
    public void setAdditionalQuantity(Integer additionalQuantity) {
        this.additionalQuantity = additionalQuantity;
    }
}
