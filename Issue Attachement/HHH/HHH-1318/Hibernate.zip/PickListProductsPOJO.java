
package com.checkernet.pickList.model;

import java.util.List;
import com.checkernet.common.model.BaseModelPOJO;

/**
 * Date: Sep 21, 2005 <br/>
 * Time: 3:30:12 PM <br/>
 * <br/>
 * Notes:<br/>
 * <br/>
 * View the <a id="viewSource" href="PickListProductsPOJO.java.html">Source</a><br/>
 *
 * @author Walter Barnie
 * @version 0.0.1
 */

public class PickListProductsPOJO extends BaseModelPOJO implements PickListProducts {

    // data
    private PickListProductsUID uid;

    private Boolean stockPicked;

    private String catalogCodeDefault;

    private String pageNumber;

    private String invoiceDescription;

    private List pickListInventory;

    private Integer lineItemQuantity;

    private Integer orderNumber;

    private Integer shipmentNumber;

    private String imageFilePath;

    private String catalogName;

    private Integer productCount;


    /**
     * getter for Unique ID
     *
     * @return PickListProductsUID uid
     */
    public PickListProductsUID getUid() {
        return uid;
    }

    /**
     * setter for Unique ID
     *
     * @param uid PickListProductsUID
     */
    public void setUid(PickListProductsUID uid) {
        this.uid = uid;
    }

    /**
     * getter for field
     *
     * @return Boolean
     */
    public Boolean getStockPicked() {
        return stockPicked;
    }

    /**
     * setter for field
     *
     * @param stockPicked Boolean
     */
    public void setStockPicked(Boolean stockPicked) {
        this.stockPicked = stockPicked;
    }

    /**
     * getter for field
     *
     * @return String
     */
    public String getCatalogCodeDefault() {
        return catalogCodeDefault;
    }

    /**
     * setter for field
     *
     * @param catalogCodeDefault String
     */
    public void setCatalogCodeDefault(String catalogCodeDefault) {
        this.catalogCodeDefault = catalogCodeDefault;
    }

    /**
     * getter for field
     *
     * @return Integer
     */
    public String getPageNumber() {
        return pageNumber;
    }

    /**
     * setter for field
     *
     * @param pageNumber String
     */
    public void setPageNumber(String pageNumber) {
        this.pageNumber = pageNumber;
    }

    /**
     * getter for field
     *
     * @return String
     */
    public String getInvoiceDescription() {
        return invoiceDescription;
    }

    /**
     * setter for field
     *
     * @param invoiceDescription String
     */
    public void setInvoiceDescription(String invoiceDescription) {
        this.invoiceDescription = invoiceDescription;
    }

    /**
     * getter for field
     *
     * @return List
     */
    public List getPickListInventory() {
        return pickListInventory;
    }

    /**
     * setter for field
     *
     * @param pickListInventory List
     */
    public void setPickListInventory(List pickListInventory) {
        this.pickListInventory = pickListInventory;
    }

    /**
     * getter for field
     *
     * @return Integer
     */
    public Integer getLineItemQuantity() {
        return lineItemQuantity;
    }

    /**
     * setter for field
     *
     * @param lineItemQuantity Integer
     */
    public void setLineItemQuantity(Integer lineItemQuantity) {
        this.lineItemQuantity = lineItemQuantity;
    }

    /**
     * getter for field
     *
     * @return Integer
     */
    public Integer getOrderNumber() {
        return orderNumber;
    }

    /**
     * setter for field
     *
     * @param orderNumber Integer
     */
    public void setOrderNumber(Integer orderNumber) {
        this.orderNumber = orderNumber;
    }

    /**
     * getter for field
     *
     * @return Integer ShipmentNumber
     */
    public Integer getShipmentNumber() {
        return shipmentNumber;
    }

    /**
     * setter for field
     *
     * @param shipmentNumber Integer
     */
    public void setShipmentNumber(Integer shipmentNumber) {
        this.shipmentNumber = shipmentNumber;
    }

    /**
     * getter for field
     *
     * @return String
     */
    public String getImageFilePath() {
        return imageFilePath;
    }

    /**
     * setter for field
     *
     * @param imageFilePath String
     */
    public void setImageFilePath(String imageFilePath) {
        this.imageFilePath = imageFilePath;
    }

    /**
     * getter for field
     *
     * @return String
     */
    public String getCatalogName() {
        return catalogName;
    }

    /**
     * setter for field
     *
     * @param catalogName String
     */
    public void setCatalogName(String catalogName) {
        this.catalogName = catalogName;
    }

    /**
     * getter for field
     *
     * @return Integer
     */
    public Integer getProductCount() {
        return productCount;
    }

    /**
     * setter for field
     *
     * @param productCount Integer
     */
    public void setProductCount(Integer productCount) {
        this.productCount = productCount;
    }
}
