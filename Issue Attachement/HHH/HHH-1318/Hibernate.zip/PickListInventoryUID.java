
package com.checkernet.pickList.model;

import com.checkernet.common.model.BaseUniqueID;

/**
 * Date: Sep 22, 2005 <br/>
 * Time: 3:05:21 PM <br/>
 * <br/>
 * Notes:<br/>
 * <br/>
 * View the <a id="viewSource" href="PickListInventoryUID.java.html">Source</a><br/>
 *
 * @author Walter Barnie
 * @version 0.0.1
 */

public class PickListInventoryUID extends BaseUniqueID {

    private String productCode;

    private String inventoryId;

    private String lineItemInkColor;

    /**
     * getter for field
     *
     * @return String
     */
    public String getInventoryId() {
        return inventoryId;
    }


    /**
     * setter for field
     *
     * @param inventoryId String
     */
    public void setInventoryId(String inventoryId) {
        this.inventoryId = inventoryId;
    }

    /**
     * getter for field
     *
     * @return String
     */
    public String getProductCode() {
        return productCode;
    }

    /**
     * setter for field
     *
     * @param productCode String
     */
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    /**
     * getter for field
     *
     * @return String
     */
    public String getLineItemInkColor() {
        return lineItemInkColor;
    }

    /**
     * setter for field
     *
     * @param lineItemInkColor String
     */
    public void setLineItemInkColor(String lineItemInkColor) {
        this.lineItemInkColor = lineItemInkColor;
    }
}
