
package com.checkernet.pickList.model;

import java.util.List;
import com.checkernet.common.model.BaseModel;

/**
 * Date: Sep 21, 2005 <br/>
 * Time: 3:17:11 PM <br/>
 * <br/>
 * Notes:<br/>
 * <br/>
 * View the <a id="viewSource" href="PickListProducts.java.html">Source</a><br/>
 *
 * @author Walter Barnie
 * @version 0.0.1
 */

public interface PickListProducts extends BaseModel {

    /**
     * getter for Unique ID
     *
     * @return PickListProductsUID uid
     */
    PickListProductsUID getUid();

    /**
     * setter for Unique ID
     *
     * @param uid PickListProductsUID
     */
    void setUid(PickListProductsUID uid);

    /**
     * getter for field
     *
     * @return Boolean
     */
    Boolean getStockPicked();

    /**
     * setter for field
     *
     * @param stockPicked Boolean
     */
    void setStockPicked(Boolean stockPicked);

    /**
     * getter for field
     *
     * @return String
     */
    String getCatalogCodeDefault();

    /**
     * setter for field
     *
     * @param catalogCodeDefault String
     */
    void setCatalogCodeDefault(String catalogCodeDefault);

    /**
     * getter for field
     *
     * @return Integer
     */
    String getPageNumber();

    /**
     * setter for field
     *
     * @param pageNumber String
     */
    void setPageNumber(String pageNumber);

    /**
     * getter for field
     *
     * @return String
     */
    String getInvoiceDescription();

    /**
     * setter for field
     *
     * @param invoiceDescription String
     */
    void setInvoiceDescription(String invoiceDescription);

    /**
     * getter for field
     *
     * @return List
     */
    List getPickListInventory();

    /**
     * setter for field
     *
     * @param pickListInventory List
     */
    void setPickListInventory(List pickListInventory);

    /**
     * getter for field
     *
     * @return Integer
     */
    Integer getLineItemQuantity();

    /**
     * setter for field
     *
     * @param lineItemQuantity Integer
     */
    void setLineItemQuantity(Integer lineItemQuantity);

    /**
     * getter for field
     *
     * @return Integer
     */
    Integer getOrderNumber();

    /**
     * setter for field
     *
     * @param orderNumber Integer
     */
    void setOrderNumber(Integer orderNumber);

    /**
     * getter for field
     *
     * @return Integer ShipmentNumber
     */
    Integer getShipmentNumber();

    /**
     * setter for field
     *
     * @param shipmentNumber Integer
     */
    void setShipmentNumber(Integer shipmentNumber);

    /**
     * getter for field
     *
     * @return String
     */
    String getImageFilePath();

    /**
     * setter for field
     *
     * @param imageFilePath String
     */
    void setImageFilePath(String imageFilePath);

    /**
     * getter for field
     *
     * @return String
     */
    String getCatalogName();

    /**
     * setter for field
     *
     * @param catalogName String
     */
    void setCatalogName(String catalogName);

    /**
     * getter for field
     *
     * @return Integer
     */
    Integer getProductCount();

    /**
     * setter for field
     *
     * @param productCount Integer
     */
    void setProductCount(Integer productCount);

}
