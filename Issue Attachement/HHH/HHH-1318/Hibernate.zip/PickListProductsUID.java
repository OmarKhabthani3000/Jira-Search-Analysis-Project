
package com.checkernet.pickList.model;

import com.checkernet.common.model.BaseUniqueID;

/**
 * Date: Oct 11, 2005 <br/>
 * Time: 4:02:43 PM <br/>
 * <br/>
 * Notes:<br/>
 * <br/>
 * View the <a id="viewSource" href="PickListProductsUID.java.html">Source</a><br/>
 *
 * @author Walter Barnie
 * @version 0.0.1
 */

public class PickListProductsUID extends BaseUniqueID {

    // data

    private String productCode;

    private String lineItemInk;

    /**
     * getter for field
     *
     * @return String
     */
    public String getProductCode() {
        return productCode;
    }

    /**
     * setter for field
     *
     * @param productCode String
     */
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    /**
     * getter for field
     *
     * @return String
     */
    public String getLineItemInkColor() {
        return lineItemInk;
    }

    /**
     * setter for field
     *
     * @param lineItemInk Boolean
     */
    public void setLineItemInkColor(String lineItemInk) {
        this.lineItemInk = lineItemInk;
    }

}
