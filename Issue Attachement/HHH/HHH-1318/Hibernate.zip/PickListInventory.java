
package com.checkernet.pickList.model;

import java.util.Collection;
import java.util.List;
import com.checkernet.common.model.BaseModel;

/**
 * Date: Sep 22, 2005 <br/>
 * Time: 10:46:02 AM <br/>
 * <br/>
 * Notes:<br/>
 * <br/>
 * View the <a id="viewSource" href="PickListInventory.java.html">Source</a><br/>
 *
 * @author Walter Barnie
 * @version 0.0.1
 */

public interface PickListInventory extends BaseModel {

    /**
     * getter for Unique ID
     *
     * @return PickListInventoryUID uid
     */
    PickListInventoryUID getUid();

    /**
     * setter for Unique ID
     *
     * @param uid PickListInventoryUID
     */
    void setUid(PickListInventoryUID uid);

    /**
     * getter for field
     *
     * @return Float
     */
    Float getInventoryQuantity();

    /**
     * setter for field
     *
     * @param inventoryQuantity Float
     */
    void setInventoryQuantity(Float inventoryQuantity);

    /**
     * getter for field
     *
     * @return String
     */
    String getDescription();

    /**
     * setter for field
     *
     * @param description String
     */
    void setDescription(String description);

    /**
     * getter for field
     *
     * @return List
     */
    List getInventoryBin();

    /**
     * setter for field
     *
     * @param inventoryBin List
     */
    void setInventoryBin(List inventoryBin);

    /**
     * getter for field
     *
     * @return String
     */
    String getItemId();

    /**
     * setter for field
     *
     * @param itemId String
     */
    void setItemId(String itemId);

    /**
     * getter for field
     *
     * @return Integer
     */
    Integer getItemKey();

    /**
     * setter for field
     *
     * @param itemKey Integer
     */
    void setItemKey(Integer itemKey);

    /**
     * getter for field
     *
     * @return String
     */
    String getCompanyId();

    /**
     * setter for field
     *
     * @param companyId String
     */
    void setCompanyId(String companyId);

    /**
     * getter for field
     *
     * @return Integer
     */
    Integer getCreateType();

    /**
     * setter for field
     *
     * @param createType Integer
     */
    void setCreateType(Integer createType);

    /**
     * getter for field
     *
     * @return Collection
     */
    Collection getInventoryBins();

    /**
     * setter for field
     *
     * @param inventoryBins Collection
     */
    void setInventoryBins(Collection inventoryBins);

    /**
     * getter for field
     *
     * @return Integer
     */
    Integer getAdditionalQuantity();

    /**
     * setter for field
     *
     * @param additionalQuantity Integer
     */
    void setAdditionalQuantity(Integer additionalQuantity);
}
