

import java.io.Serializable;
import java.lang.reflect.Array;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.type.Type;
import org.hibernate.usertype.CompositeUserType;

public class TestCompositeUserType implements CompositeUserType{

	public Object assemble(Serializable cached, SessionImplementor session, Object owner) throws HibernateException {
		return cached;
	}

	public Object deepCopy(Object value) throws HibernateException {
		// TODO Auto-generated method stub
		return null;
	}

	public Serializable disassemble(Object value, SessionImplementor session) throws HibernateException {
		return (Serializable) value;
	}

	public boolean equals(Object x, Object y) throws HibernateException {
		if (x == null || y == null) return false;
		if (! (x instanceof String[]) || ! (y instanceof String[])) return false;
		return (x.equals(y)) ;
	}

	public String[] getPropertyNames() {
		String[] names  = {"a3", "a4", "a5"};
		// TODO Auto-generated method stub
		return names;
	}

	public Type[] getPropertyTypes() {
		return new Type[] {Hibernate.STRING, Hibernate.STRING, Hibernate.STRING };
	}

	public Object getPropertyValue(Object component, int property) throws HibernateException {
		String[] cols = (String[]) component;
		return (String) cols[property];
	}

	public int hashCode(Object x) throws HibernateException {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean isMutable() {
		// TODO Auto-generated method stub
		return false;
	}

	public Object nullSafeGet(ResultSet rs, String[] names, SessionImplementor session, Object owner) throws HibernateException, SQLException {
		if (rs.wasNull()) return null;
//		 if all the cols are null, return a null object
		if (rs.getString(names[0]) == null && rs.getString(names[1]) == null && rs.getString(names[2]) == null) return null;
		// Set the values reading from resultSet
		String cols[] = new String[3];
		cols[0] = rs.getString(names[0]);
		cols[1] = rs.getString(names[1]);
		cols[2] = rs.getString(names[2]);
		return cols;
	}

	public void nullSafeSet(PreparedStatement st, Object value, int index, SessionImplementor session) throws HibernateException, SQLException {
		// TODO Auto-generated method stub
		if (value== null) {
			st.setNull(index,  Types.VARCHAR);
			st.setNull(index + 1,  Types.VARCHAR);
			st.setNull(index + 2,  Types.VARCHAR);
		}else{
			String[] cols = (String[]) value;
			st.setString(index, cols[0]);
			st.setString(index + 1, cols[1]);
			st.setString(index + 2, cols[2]);
		}
	}

	public Object replace(Object original, Object target, SessionImplementor session, Object owner) throws HibernateException {
		// TODO Auto-generated method stub
		return null;
	}

	public Class returnedClass() {
		return Array.class;
	}

	public void setPropertyValue(Object component, int property, Object value) throws HibernateException {
		throw new UnsupportedOperationException("Immutable");
	}

}
