
import java.util.Arrays;


/**
 * To check composition, arrays, sorted maps, mapping same table with two classes.
 *
 *
 */
public class A {
	private int id;
	private B b;
	private C c;
	private String[] cols;
	//private D d;
	public  String a1;
	public String a2;

	public A(){

	}

	public A(String a1,String a2,String[] cols){
		//this.d = new D(a1,a2);
		this.a1=a1;
		this.a2=a2;
		this.cols = cols;
	}

	public String[] getCols() {
		return cols;
	}

	public void setCols(String[] cols) {
		this.cols = cols;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public B getB() {
		return b;
	}
	public void setB(B b) {
		this.b = b;
	}
	public C getC() {
		return c;
	}
	public void setC(C c) {
		this.c = c;
	}
//	public D getD() {
//		return d;
//	}
//	public void setD(D d) {
//		this.d = d;
//	}
	public String getA1() {
		return a1;
	}
	public void setA1(String a1) {
		this.a1 = a1;
	}
	public String getA2() {
		return a2;
	}
	public void setA2(String a2) {
		this.a2 = a2;
	}
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("A(");
		sb.append("id = " + id );
		//if (d != null) {
			sb.append(",a1 = " + a1);
			sb.append(",a2 = " + a2);
//		}else{
//			sb.append(".d = null");
//		}

		if (cols == null) {
			sb.append(",cols = null" );
		}else{
			sb.append(",cols[0] = " + cols[0] );
			sb.append(",cols[1] = " + cols[1] );
			sb.append(",cols[2] = " + cols[2] );
		}
		sb.append(")");
		return sb.toString();
	}
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((b == null) ? 0 : b.hashCode());
		result = PRIME * result + ((c == null) ? 0 : c.hashCode());
		result = PRIME * result + Arrays.hashCode(cols);
		//result = PRIME * result + ((d == null) ? 0 : d.hashCode());
		result = PRIME * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final A other = (A) obj;
		if (b == null) {
			if (other.b != null)
				return false;
		} else if (!b.equals(other.b))
			return false;
		if (c == null) {
			if (other.c != null)
				return false;
		} else if (!c.equals(other.c))
			return false;
		if (!Arrays.equals(cols, other.cols))
			return false;
//		if (d == null) {
//			if (other.d != null)
//				return false;
//		} else if (!d.equals(other.d))
//			return false;
		if (id != other.id)
			return false;
		return true;
	}



}
