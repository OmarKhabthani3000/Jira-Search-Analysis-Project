import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

	static SessionFactory sessionFactory = null;
	static boolean configured = false;

	HibernateUtil() {
	}

	private static void configure() {
		Configuration configuration = new Configuration();
		Properties props = new Properties();
		props.put("dialect", "org.hibernate.dialect.HSQLDialect");
		props.put("connection.driver_class", "org.hsqldb.jdbcDriver");
		props.put("connection.url", "jdbc:hsqldb:hsql:");
		props.put("connection.username", "sa");
		props.put("connection.password", "");

		configuration.addProperties(props);

		configuration.addClass(A.class);

		configured = true;

//		configuration.addFile("A.hbm.xml");
//		configuration.addFile("B.hbm.xml");
//		configuration.addFile("C.hbm.xml");

		configuration.configure();
		sessionFactory = configuration.buildSessionFactory();
	}

	public static SessionFactory getSessionFactory(){
		if (! configured)
			configure();
		return sessionFactory;
	}

}
