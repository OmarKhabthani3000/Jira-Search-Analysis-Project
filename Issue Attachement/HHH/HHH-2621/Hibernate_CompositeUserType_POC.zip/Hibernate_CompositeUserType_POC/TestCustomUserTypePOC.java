import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

public class TestCustomUserTypePOC extends TestCase {
	A aWithColsAndOneNull;
	A aWithNullCols;
	A aWithCols;

	@Override
	protected void setUp() throws Exception {
		aWithColsAndOneNull = new A("1","2",new String[] { "3", "4", null });
		aWithNullCols = new A("1","2",null);
		aWithCols = new A("1","2",new String[] { "6", "7", "8"});

		createObject(aWithColsAndOneNull);
		createObject(aWithNullCols);
		createObject(aWithCols);
	}

	@Override
	protected void tearDown() throws Exception {
		deleteObject(aWithColsAndOneNull);
		deleteObject(aWithNullCols);
		deleteObject(aWithCols);
	}

	public void testInsertAndFetchWithCols() {
		// Fetch the  Object again
	    Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		A retrievedObj = (A) session.get(A.class, aWithColsAndOneNull.getId());
		String[] expectedColsObj  = new String[] {"3", "4", null};

		session.close();
		System.out.println("asfafahahfakljhfaklfhkjhlahlk -" + retrievedObj.toString());
		// Assert
		assertEquals(expectedColsObj[0], retrievedObj.getCols()[0]);
		assertEquals(expectedColsObj[1], retrievedObj.getCols()[1]);
		assertEquals(expectedColsObj[2], retrievedObj.getCols()[2]);
	}

	public void testInsertAndFetchWithNullCols() {
		// Fetch the Object again
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		A retrievedObj = (A) session.get(A.class, aWithNullCols.getId());

		// Assert
		assertNull(retrievedObj.getCols());
		session.close();
	}

	public void testQueryByCols() {

		// Fetch using query
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		 session.beginTransaction();

		Query q = session.createQuery("from A as a where a.cols = :cols and a.id= :id");
		q.setParameter("cols", new String[] { "6", "7", "8" });
		q.setParameter("id", aWithCols.getId());

		List list = q.list();

		// Assert
		assertNotNull(list);
		assertFalse(list.size() == 0);

		A retrievedObject = (A) list.get(0);
		assertEquals(aWithCols, retrievedObject);
		session.close();
	}

	public void testQueryByOneCol() {

		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		Query q = session.createQuery("from A as a where a.cols.A3 = '3'");

		List list = q.list();
		// Assert
		assertNotNull(list);
		assertFalse(list.size() == 0);

		A retrievedObject = (A) list.get(0);
		assertEquals(aWithColsAndOneNull, retrievedObject);
		session.getTransaction().commit();
	}

	public void testQueryColsByNamedParameter() {

		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		// if the named parameter has a dot in it, AST fails to resolve the query, avoid a dot in namedParameter
		// For eg: ":cols.A4" is not a valid named parameter
		Query q = session
				.createQuery("from A as a where a.cols.A3 = ? and a.cols.A4= :colsA4 ");
		q.setParameter(0, "3");
		q.setParameter("colsA4", "4");

		List list = q.list();
		// Assert
		assertNotNull(list);
		assertFalse(list.size() == 0);

		A retrievedObject = (A) list.get(0);
		assertEquals(aWithColsAndOneNull, retrievedObject);
		session.close();
	}

	public void testQueryByProjection() {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();

		// Query for id and cols based on one of the value in cols array
		Query q = session
				.createQuery("select id, cols from A as a where a.cols.A3 = '3'");
		Object[] obj = (Object[]) q.list().get(0);
		// Id
		System.out.println(obj[0]);
		// Cols array
		assertEquals(aWithColsAndOneNull.getCols()[0], (((String[]) obj[1])[0]));
		assertEquals(aWithColsAndOneNull.getCols()[1],(((String[]) obj[1])[1]));
		assertNull ( ((String[]) obj[1]) [2] );
		session.close();
	}

	public void testCriteria() {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		Criteria c = session.createCriteria(A.class);
		c.add(Restrictions.eq("cols.A3", "6"));
		c.setProjection(Projections.property("cols"));

		List ls = (ArrayList) c.list();

		String[] cols = (String[]) ls.get(0);
		assertEquals(aWithCols.getCols()[0], cols[0] );
		assertEquals(aWithCols.getCols()[1], cols[1] );
		assertEquals(aWithCols.getCols()[2], cols[2] );
		session.close();
	}

	public void createObject(A a){
		// Issue: Fires an Insert query first and then an Update query with
		// the three custom columns set
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		session.save(a);
		tx.commit();
	}

	private void deleteObject(A a) {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		session.delete(a);
		tx.commit();
	}

}
