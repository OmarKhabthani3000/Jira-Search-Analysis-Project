package org.hibernate.test.collection.set;

import static org.junit.Assert.assertEquals;

import java.util.Collections;

import org.hibernate.cfg.Configuration;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.testing.FailureExpected;
import org.hibernate.testing.TestForIssue;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;
import junit.framework.TestCase;

/**
 * @author Felix Feisst (feisst dot felix at gmail dot com)
 */
public class UserTypeTest extends TestCase {

	/*@Override
	protected String[] getMappings() {
		return new String[] { "collection/set/UserTypeMapping.hbm.xml" };
	}*/

	private SessionFactory sessionFactory;

	@SuppressWarnings("deprecation")
	@Override
	protected void setUp() throws Exception {
		try {
			// A SessionFactory is set up once for an application
			// configures settings from hibernate.cfg.xml
			sessionFactory = new Configuration().configure().buildSessionFactory();
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	@Override
	protected void tearDown() throws Exception {
		if (sessionFactory != null) {
			sessionFactory.close();
		}
	}
	
	private Session openSession() {
		//if(sessionFactory!=null) {
		return sessionFactory.openSession();
		//}
	}
	//@Test
	/*public void testWithNonNullField() {
		final PersonInfo info1 = new PersonInfo( 160, "brown" );
		final PersonInfo info2 = new PersonInfo( 170, "black" );

		Session session = openSession();

		session.getTransaction().begin();
		final PersonInfoEntity entity = new PersonInfoEntity();
		entity.setId( 1L );
		entity.getInfos().add( info1 );
		entity.getInfos().add( info2 );
		session.save( entity );
		session.getTransaction().commit();

		session.getTransaction().begin();
		entity.getInfos().remove( info1 );
		session.getTransaction().commit();

		session = openSession();
		// reread entity from DB
		PersonInfoEntity reloaded = (PersonInfoEntity) session.get( PersonInfoEntity.class, 1L );
		assertEquals( "Unexpected person infos non-null", Collections.singleton( info2 ), reloaded.getInfos() );
	}*/

	@Test
	@TestForIssue(jiraKey = "HHH-8957")
	@FailureExpected(jiraKey = "HHH-8957")
	public void testWithNullField() {
		
		final PersonInfo info1 = new PersonInfo( 160, "brown" );
		final PersonInfo info2 = new PersonInfo( 170, "black" );

		Session session = openSession();

		session.getTransaction().begin();
		final PersonInfoEntity entity = new PersonInfoEntity();
		entity.setId( 1L );
		entity.getInfos().add( info1 );
		entity.getInfos().add( info2 );
		session.save( entity );
		session.getTransaction().commit();

		session.getTransaction().begin();
		entity.getInfos().remove( info1 );
		session.getTransaction().commit();

		session = openSession();
		// reread entity from DB
		PersonInfoEntity reloaded = (PersonInfoEntity) session.get( PersonInfoEntity.class, 1L );
		assertEquals( "Unexpected person infos non-null", Collections.singleton( info2 ), reloaded.getInfos() );
		final PersonInfo info3 = new PersonInfo( 168, null ); // null field
		final PersonInfo info4 = new PersonInfo( 170, "black" );

		session = openSession();

		session.getTransaction().begin();
		final PersonInfoEntity entity2 = new PersonInfoEntity();
		entity2.setId( 2L );
		entity2.getInfos().add( info3 );
		entity2.getInfos().add( info4);
		session.save( entity2 );
		session.getTransaction().commit();
        //session.clear();
		//session = openSession();
		session.getTransaction().begin();
		entity2.getInfos().remove( info3); // info with null field (= null column) should be removed
		//session.refresh(entity);
		//session.saveOrUpdate(entity);
		//PersonInfoEntity entity1 = (PersonInfoEntity) session.get(PersonInfoEntity.class, 2L);
		//entity1.getInfos().remove(info2);
		//session.saveOrUpdate(entity);
		session.getTransaction().commit();
        session.clear();
		//session = openSession();
		// reread entity from DB
		PersonInfoEntity reloaded2 = (PersonInfoEntity) session.get( PersonInfoEntity.class, 2L );
		assertEquals( "Unexpected person infos null", Collections.singleton( info4), reloaded2.getInfos() );
	}

}
