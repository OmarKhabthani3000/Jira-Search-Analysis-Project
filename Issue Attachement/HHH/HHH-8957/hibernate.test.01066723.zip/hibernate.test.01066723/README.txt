You will need to modify the following in ./src/test/resources/hibernate-cfg.xml for your PostgreSQL database:
- connection.url
- connection.username
- connection.password
- Enable hbm2ddl.auto for the first run then disable and run again 

When using the @Embeddable UserOrgAttributes in a Map owned by UserEntity, the key attributes are ignored on repeat runs
and an attempt is made to re-insert the same row that already exists (TestHibernate - uses UserEntity). If the Map is
changed to not use the @Embeddable, however, but to use a simple String to represent the UserOrgAttributes class (which,
for illustration, has only one real attribute), the test shows that we seem to correctly recognize the join column and
map key and avoid the attempt to re-insert the existing row (TestHibernate2 - uses UserEntity2).

TestHibernate fails on the second run with:

...
2014-02-18 12:05 DEBUG insert into TMP_USER_ORG_ATTRIBUTES (USER_ID, ORGANIZATION_ID, EMAIL) values (?, ?, ?)
2014-02-18 12:05 WARN  SQL Error: 0, SQLState: 23505
2014-02-18 12:05 ERROR ERROR: duplicate key value violates unique constraint "tmp_user_org_attributes_pkey"
  Detail: Key (user_id, organization_id)=(1, 2) already exists.

Note that I've tested with the following and the results are the same with all:
- Hibernate 4.2.0.Final (customer version) and Hibernate 4.3.0.Final
- Oracle (customer database) and PostgreSQL

