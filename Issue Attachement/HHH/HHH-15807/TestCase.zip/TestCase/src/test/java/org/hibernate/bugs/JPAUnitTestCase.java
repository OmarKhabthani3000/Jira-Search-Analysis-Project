package org.hibernate.bugs;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void Test1() throws Exception {
		
		//Create entries
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		OrganisationProfile organisationProfile = new OrganisationProfile();
		organisationProfile.setName("OP 1");
		
		UserProfile userProfile = new UserProfile();
		userProfile.setName("UP 1");
		
		OrganisationProfileBillingAddress organisationProfileBillingAddress = new OrganisationProfileBillingAddress();
		organisationProfileBillingAddress.setName("OPBA 1");
		
		organisationProfile.setBillingAddress(organisationProfileBillingAddress);
		organisationProfileBillingAddress.setOrganisationProfile(organisationProfile);
		userProfile.setOrganisationProfile(organisationProfile);
		Set<UserProfile> userProfiles = new HashSet<UserProfile>();
		userProfiles.add(userProfile);
		organisationProfile.setUserList(userProfiles);
		
		entityManager.persist(organisationProfileBillingAddress);
		entityManager.persist(userProfile);
		entityManager.persist(organisationProfile);
		
		entityManager.getTransaction().commit();
		entityManager.close();
		
		
		//try to load entries
		entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		String query = "SELECT x FROM UserProfile x JOIN FETCH x.organisationProfile";
		Query queryObject = entityManager.createQuery(query);
		
		List<?> foundValues = queryObject.getResultList();
		if(foundValues == null) {
			System.out.println("nothing found");
		}
		else {
			System.out.println("Found " + foundValues.size());
		}
		
		entityManager.getTransaction().commit();
		entityManager.close();
		
	}
}
