package org.hibernate.bugs;

import java.util.Set;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class OrganisationProfile extends BaseEntity {

	@Column(name="name")
	private String name;
	
	@NotFound(action = NotFoundAction.IGNORE)
	@OneToMany(fetch=FetchType.LAZY, cascade={CascadeType.DETACH, CascadeType.REFRESH}, mappedBy="organisationProfile")
	@Fetch(FetchMode.SUBSELECT)
	private Set<UserProfile> userList;
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy="organisationProfile" /*, cascade=CascadeType.ALL, orphanRemoval=true, optional=false*/)
	private OrganisationProfileBillingAddress billingAddress;

	public OrganisationProfileBillingAddress getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(OrganisationProfileBillingAddress billingAddress) {
		this.billingAddress = billingAddress;
	}

	public Set<UserProfile> getUserList() {
		return userList;
	}

	public void setUserList(Set<UserProfile> userList) {
		this.userList = userList;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
