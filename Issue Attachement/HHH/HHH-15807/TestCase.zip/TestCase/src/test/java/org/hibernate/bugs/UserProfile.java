package org.hibernate.bugs;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class UserProfile extends BaseEntity {

	@Column(name="name")
	private String name;
	
	@ManyToOne(fetch=FetchType.LAZY, cascade={CascadeType.DETACH})
	@JoinColumn(name="organisation_profile")
	private OrganisationProfile organisationProfile;

	public OrganisationProfile getOrganisationProfile() {
		return organisationProfile;
	}

	public void setOrganisationProfile(OrganisationProfile organisationProfile) {
		this.organisationProfile = organisationProfile;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
