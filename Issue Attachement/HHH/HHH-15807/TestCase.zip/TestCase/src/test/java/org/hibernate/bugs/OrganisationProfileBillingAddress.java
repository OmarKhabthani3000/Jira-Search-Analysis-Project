package org.hibernate.bugs;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class OrganisationProfileBillingAddress extends BaseEntity {
	
	@Column(name="name")
	private String name;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="organisation_profile_id")
	private OrganisationProfile organisationProfile;

	public OrganisationProfile getOrganisationProfile() {
		return organisationProfile;
	}

	public void setOrganisationProfile(OrganisationProfile organisationProfile) {
		this.organisationProfile = organisationProfile;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
