package org.hibernate.bugs;

import javax.persistence.Entity;

/**
 *
 * @author ziems
 */
@Entity(name = "SpecialAccount")
public class SpecialAccount extends Account {

    private String type;

    public String getType() {
        return type;
    }

    public void setType(String creditLimit) {
        this.type = creditLimit;
    }
}