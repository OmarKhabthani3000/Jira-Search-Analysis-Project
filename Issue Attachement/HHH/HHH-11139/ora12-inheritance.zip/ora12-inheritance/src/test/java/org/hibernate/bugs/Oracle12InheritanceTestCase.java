package org.hibernate.bugs;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import oracle.jdbc.driver.OracleDriver;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Assert;
import org.junit.Test;


/**
 *
 * @author ziems
 */
public class Oracle12InheritanceTestCase extends BaseCoreFunctionalTestCase {

    @Override
    protected Class[] getAnnotatedClasses() {
        return new Class[] {
            Account.class, CreditAccount.class, DebitAccount.class,
            SpecialAccount.class};
    }

    @Override
    protected void configure(Configuration configuration) {
        super.configure(configuration);

        configuration.setProperty(AvailableSettings.DRIVER, OracleDriver.class.getName());
        configuration.setProperty(AvailableSettings.URL, "jdbc:oracle:thin:@(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = hostname)(PORT = 2329))) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = servicename)))");
        configuration.setProperty(AvailableSettings.USER, "");
        configuration.setProperty(AvailableSettings.PASS, "");

        configuration.setProperty(AvailableSettings.SHOW_SQL, Boolean.TRUE.toString());
        configuration.setProperty(AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString());
    }

    @Test
    public void accountTest() throws Exception {
        // BaseCoreFunctionalTestCase automatically creates the SessionFactory and provides the Session.
        final Session s = openSession();

        // insert data
        final Transaction tx = s.beginTransaction();
        s.createNativeQuery("insert into Account (id, balance, INTERESTRATE, owner) values (1, 12.3, 1.1, 'account1')").executeUpdate();
        s.createNativeQuery("insert into CreditAccount (creditLimit, id) values (100, 1)").executeUpdate();
        s.createNativeQuery("insert into Account (id, balance, INTERESTRATE, owner) values (2, 12.4, 1.2, 'account2')").executeUpdate();
        s.createNativeQuery("insert into CreditAccount (creditLimit, id) values (101, 2)").executeUpdate();
        s.createNativeQuery("insert into Account (id, balance, INTERESTRATE, owner) values (3, 12.5, 1.3, 'account3')").executeUpdate();
        s.createNativeQuery("insert into DebitAccount (overdraftFee, id) values (100, 3)").executeUpdate();
        s.createNativeQuery("insert into Account (id, balance, INTERESTRATE, owner) values (4, 12.6, 1.4, 'account4')").executeUpdate();
        s.createNativeQuery("insert into SpecialAccount (type, id) values ('very', 4)").executeUpdate();

        // read data
        final List<Account> lst = s.byMultipleIds(Account.class).multiLoad(1L, 3L, 4L);
        final Set<Class<? extends Account>> types = new HashSet<>();
        for (Account account : lst) {
            types.add(account.getClass());
        }
        tx.commit();
        s.close();

        // verify data
        Assert.assertEquals("CreditAccount not found.", true, types.contains(CreditAccount.class));
        Assert.assertEquals("DebitAccount not found.", true, types.contains(DebitAccount.class));
        Assert.assertEquals("SpecialAccount not found.", true, types.contains(SpecialAccount.class));
    }
}
