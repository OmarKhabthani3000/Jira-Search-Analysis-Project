package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.SecondaryTable;

@Entity
@SecondaryTable(name=B.TABLE_NAME)
public class B extends A {
  protected static final String TABLE_NAME = "B";
  
  @Column(table=TABLE_NAME)
  private String attrB;

  public String getAttrB() {
    return attrB;
  }

  public void setAttrB(String attrB) {
    this.attrB = attrB;
  }
}