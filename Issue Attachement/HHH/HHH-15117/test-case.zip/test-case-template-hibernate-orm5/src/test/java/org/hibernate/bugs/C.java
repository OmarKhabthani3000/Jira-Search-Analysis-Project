package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.SecondaryTable;

@Entity
@SecondaryTable(name = B.TABLE_NAME)
@org.hibernate.annotations.Table(appliesTo = B.TABLE_NAME, optional = true)
public class C extends B {

  @Column(table = B.TABLE_NAME)
  private String attrC;

  public String getAttrC() {
    return attrC;
  }

  public void setAttrC(String attrC) {
    this.attrC = attrC;
  }
}
