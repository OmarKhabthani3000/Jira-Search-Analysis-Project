package com.example.hibernateembeddedid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernateEmbeddedIdApplication {

    public static void main(String[] args) {
        SpringApplication.run(HibernateEmbeddedIdApplication.class, args);
    }

}
