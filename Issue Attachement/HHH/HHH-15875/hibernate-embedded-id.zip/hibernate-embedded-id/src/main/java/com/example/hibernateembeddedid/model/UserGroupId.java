package com.example.hibernateembeddedid.model;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.Embeddable;
import jakarta.persistence.FetchType;
import jakarta.persistence.ManyToOne;
import java.io.Serializable;
import java.util.Objects;

@Setter
@Getter
@Embeddable
public class UserGroupId implements Serializable {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Group group;

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof UserGroupId that)) {
            return false;
        }

        return Objects.equals(user.getId(), that.user.getId()) && Objects.equals(group.getId(), that.group.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(user.getId(), group.getId());
    }
}
