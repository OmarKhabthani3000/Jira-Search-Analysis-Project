package com.example.hibernateembeddedid.model;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;

@Setter
@Getter
@Entity
public class UserGroup {

    @EmbeddedId
    private UserGroupId userGroupId;

    private String joinedPropertyValue;

}
