package com.example.hibernateembeddedid.service;

import com.example.hibernateembeddedid.model.UserGroup;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Fetch;
import jakarta.persistence.criteria.Root;
import java.util.List;

@RequiredArgsConstructor
@Service
public class UserGroupService {

    private final EntityManager entityManager;

    @Transactional(readOnly = true)
    public List<UserGroup> findAll() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<UserGroup> query = criteriaBuilder.createQuery(UserGroup.class);

        Root<UserGroup> root = query.from(UserGroup.class);

        Fetch<?, ?> userGroupFetch = root.fetch("userGroupId");

        userGroupFetch.fetch("user");
        userGroupFetch.fetch("group").fetch("groupType");

        TypedQuery<UserGroup> typedQuery = entityManager.createQuery(query);

        return typedQuery.getResultList();
    }
}
