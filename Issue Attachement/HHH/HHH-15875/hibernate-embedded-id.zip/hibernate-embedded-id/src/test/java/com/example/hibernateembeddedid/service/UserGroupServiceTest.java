package com.example.hibernateembeddedid.service;

import com.example.hibernateembeddedid.model.UserGroup;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.PlatformTransactionManager;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

import static com.example.hibernateembeddedid.testutil.PersistenceTestUtil.executeInTransactionWithoutResult;
import static com.example.hibernateembeddedid.testutil.TestDataGeneratingUtil.createUserGroup;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class UserGroupServiceTest {

    @Autowired
    private UserGroupService userGroupService;

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private PlatformTransactionManager transactionManager;

    @Test
    void shouldEagerlyLoadAllAssociations() {
        // given
        executeInTransactionWithoutResult(transactionManager, () -> createUserGroup(entityManager));

        // when
        List<UserGroup> results = userGroupService.findAll();

        // then
        assertThat(results).hasSize(1);

        assertThat(results).extracting("userGroupId.user.name").containsExactly("user name");
        assertThat(results).extracting("userGroupId.group.groupType.name").containsExactly("group type");
    }
}
