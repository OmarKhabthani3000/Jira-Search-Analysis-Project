package com.example.hibernateembeddedid.testutil;

import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

public final class PersistenceTestUtil {

    private PersistenceTestUtil() {
    }

    public static void executeInTransactionWithoutResult(PlatformTransactionManager transactionManager, Runnable function) {
        new TransactionTemplate(transactionManager).execute(status -> {
            function.run();

            return null;
        });
    }
}
