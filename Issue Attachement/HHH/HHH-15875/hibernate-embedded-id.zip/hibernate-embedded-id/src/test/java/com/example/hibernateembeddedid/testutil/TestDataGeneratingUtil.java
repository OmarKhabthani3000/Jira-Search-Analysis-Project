package com.example.hibernateembeddedid.testutil;

import com.example.hibernateembeddedid.model.Group;
import com.example.hibernateembeddedid.model.GroupType;
import com.example.hibernateembeddedid.model.User;
import com.example.hibernateembeddedid.model.UserGroup;
import com.example.hibernateembeddedid.model.UserGroupId;

import jakarta.persistence.EntityManager;

public final class TestDataGeneratingUtil {

    private TestDataGeneratingUtil() {
    }

    public static UserGroup createUserGroup(EntityManager entityManager) {
        User user = createUser(entityManager);
        Group group = createGroup(entityManager);

        UserGroupId userGroupId = new UserGroupId();

        userGroupId.setUser(user);
        userGroupId.setGroup(group);

        UserGroup userGroup = new UserGroup();

        userGroup.setUserGroupId(userGroupId);
        userGroup.setJoinedPropertyValue("value");

        entityManager.persist(userGroup);

        return userGroup;
    }

    private static User createUser(EntityManager entityManager) {
        User entity = new User();

        entity.setName("user name");

        entityManager.persist(entity);

        return entity;
    }

    private static Group createGroup(EntityManager entityManager) {
        Group entity = new Group();

        entity.setName("user group");
        entity.setGroupType(createGroupType(entityManager));

        entityManager.persist(entity);

        return entity;
    }

    private static GroupType createGroupType(EntityManager entityManager) {
        GroupType entity = new GroupType();

        entity.setName("group type");

        entityManager.persist(entity);

        return entity;
    }
}
