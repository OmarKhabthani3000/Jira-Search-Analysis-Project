package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import jakarta.persistence.Tuple;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.setExtractBareNamePropertyMethods;
import org.hibernate.Session;
import org.hibernate.query.criteria.JpaDerivedJoin;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private static final Logger LOGGER = LogManager.getLogger();
	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh17223Test() throws Exception {
		try(EntityManager entityManager = entityManagerFactory.createEntityManager()) {
			entityManager.getTransaction().begin();
			//given
			persistData(entityManager);
			var cb = entityManager.unwrap(Session.class).getCriteriaBuilder();
			var query = cb.createQuery(Integer.class);
			var root = query.from(Primary.class);
			query.select(
					cb.sum(
							cb.coalesce(root.get("capacity"), 5)
					)
			);
			var result = entityManager.createQuery(query).getSingleResult();
			assertThat(result).isEqualTo(15);
		} catch (Throwable t) {
			LOGGER.error(t.getMessage(), t);
			throw t;
		}
	}

	private void persistData(EntityManager em) {
		Stream.of(
				createPrimary(1, 10),
				createPrimary(2, null)
		).forEach(em::persist);
		em.flush();
		em.clear();
	}

	private Primary createPrimary(int id, Integer capacity) {
		var entity = new Primary();
		entity.setId(id);
		entity.setCapacity(capacity);
		return entity;
	}
}
