/*******************************************************************************
 * Copyright: DOCUFY GmbH (c) 2013
 * Company: DOCUFY GmbH,
 *          Kapuzinerstraße 32,
 *          96047 Bamberg
 *          http://www.docufy.de
 * $LastChangedBy: frank $
 * $LastChangedDate: 2013-02-25 17:47:28 +0100 (Mo, 25 Feb 2013) $
 * $HeadURL: svn://192.168.11.107/projects/viessmann/trunk/server/kernelplugin/src/main/java/de/docufy/viessmann/service/resolver/handler/ViessmannAttributeExtender.java $
 * $LastChangedRevision: 67530 $
 *******************************************************************************/
package model;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author Philipp
 *
 */
@Entity
@Table(name="node")
@Cacheable(false)
public class NodeModel {

	@EmbeddedId
	private NodePk pk;

	@ManyToOne(optional=false)
	@JoinColumns({
		@JoinColumn(name="n_root_id", referencedColumnName="r_id", updatable=false),
		@JoinColumn(name="n_root_version", referencedColumnName="r_version", updatable=false)
	})
	private RootModel parent;

	@Column(name="n_name")
	private String name;

	/**
	 * @return the pk
	 */
	public NodePk getPk() {
		return pk;
	}

	/**
	 * @param pk the pk to set
	 */
	public void setPk(NodePk pk) {
		this.pk = pk;
	}

	/**
	 * @return the parent
	 */
	public RootModel getParent() {
		return parent;
	}

	/**
	 * @param parent the parent to set
	 */
	public void setParent(RootModel parent) {
		this.parent = parent;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "NodeModel [name=" + name + "]";
	}
}
