/*******************************************************************************
 * Copyright: DOCUFY GmbH (c) 2013
 * Company: DOCUFY GmbH,
 *          Kapuzinerstraße 32,
 *          96047 Bamberg
 *          http://www.docufy.de
 * $LastChangedBy: frank $
 * $LastChangedDate: 2013-02-25 17:47:28 +0100 (Mo, 25 Feb 2013) $
 * $HeadURL: svn://192.168.11.107/projects/viessmann/trunk/server/kernelplugin/src/main/java/de/docufy/viessmann/service/resolver/handler/ViessmannAttributeExtender.java $
 * $LastChangedRevision: 67530 $
 *******************************************************************************/
package service;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import model.LeafModel;
import model.NodeModel;
import model.NodePk;
import model.RootModel;
import model.RootPk;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import repository.LeafRepository;
import repository.NodeRepository;
import repository.RootRepository;

/**
 * @author Philipp
 *
 */
@Component
public class BatchProcessor {

	@Autowired
	private RootRepository rootRepo;
	@Autowired
	private NodeRepository nodeRepo;
	@Autowired
	private LeafRepository leafRepo;
	
	@PersistenceContext
	private EntityManager entityManager;

	@PostConstruct
	public void doWork() {
		RootModel root1 = createRoot("root1", "Rootknoten 1");
		RootModel root2 = createRoot("root2", "Rootknoten 2");
		
		NodeModel node1a = createNode("node1a", "Knoten 1A", root1);
		NodeModel node1b = createNode("node1b", "Knoten 1B", root1);
		NodeModel node2 = createNode("node2", "Knoten 2", root2);
		
		LeafModel leaf1a = createLeaf("leaf1a", "Blatt 1A", node1a);
		LeafModel leaf1b = createLeaf("leaf1b", "Blatt 1B", node1b);
		LeafModel leaf2 = createLeaf("leaf2", "Blatt 2", node2);
		System.out.println("Starting querying");
		List<LeafModel> leafs = leafRepo.findAll();
		for (LeafModel leaf : leafs) {
			System.out.println(leaf.getParent().getParent().getName() + ":" + 
					leaf.getParent().getName() + ":" + leaf.getName());
		}
	}

	/**
	 * @param id
	 * @param name
	 * @return
	 */
	protected RootModel createRoot(String id, String name) {
		RootModel ret = new RootModel();
		RootPk pk = new RootPk();
		pk.setId(id);
		pk.setVersion(1);
		ret.setPk(pk);
		ret.setName(name);
		return rootRepo.save(ret);
	}

	/**
	 * @param id
	 * @param name
	 * @return
	 */
	protected NodeModel createNode(String id, String name, RootModel parent) {
		NodeModel ret = new NodeModel();
		NodePk pk = new NodePk();
		pk.setId(id);
		pk.setVersion(1);
		ret.setPk(pk);
		ret.setName(name);
		ret.setParent(parent);
		return nodeRepo.save(ret);
	}

	/**
	 * @param id
	 * @param name
	 * @return
	 */
	protected LeafModel createLeaf(String id, String name, NodeModel node) {
		LeafModel ret = new LeafModel();
		ret.setId(id);
		ret.setName(name);
		ret.setParent(node);
		return leafRepo.save(ret);
	}
}
