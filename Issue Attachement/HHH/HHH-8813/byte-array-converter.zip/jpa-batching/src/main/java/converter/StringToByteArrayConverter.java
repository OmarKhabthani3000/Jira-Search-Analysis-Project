/*******************************************************************************
 * Copyright: DOCUFY GmbH (c) 2013
 * Company: DOCUFY GmbH,
 *          Kapuzinerstraße 32,
 *          96047 Bamberg
 *          http://www.docufy.de
 * $LastChangedBy: philipp $
 * $LastChangedDate: 2013-11-16 17:41:07 +0100 (Sa, 16 Nov 2013) $
 * $HeadURL: svn://192.168.11.107/supplemental/philipp/cosima-api/trunk/persistence/persistence-jpa/src/main/java/de/docufy/cms/persistence/converter/StringToByteArrayConverter.java $
 * $LastChangedRevision: 1345 $
 *******************************************************************************/
package converter;

import java.io.UnsupportedEncodingException;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

/**
 * @author Philipp
 *
 */
@Converter
public class StringToByteArrayConverter implements AttributeConverter<String, byte[]> {

	private static final String ENCODING = "UTF-8";

	/* (non-Javadoc)
	 * @see javax.persistence.AttributeConverter#convertToDatabaseColumn(java.lang.Object)
	 */
	public byte[] convertToDatabaseColumn(String val) {
		if (val != null) {
			try {
				return val.getBytes(ENCODING);
			} catch (UnsupportedEncodingException e) {
				// Should never happen
				e.printStackTrace();
			}
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.persistence.AttributeConverter#convertToEntityAttribute(java.lang.Object)
	 */
	public String convertToEntityAttribute(byte[] val) {
		if (val != null) {
			try {
				return new String(val, ENCODING);
			} catch (UnsupportedEncodingException e) {
				// Should never happen
				e.printStackTrace();
			}
		}
		return null;
	}
}
