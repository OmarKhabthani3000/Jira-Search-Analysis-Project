/*******************************************************************************
 * Copyright: DOCUFY GmbH (c) 2013
 * Company: DOCUFY GmbH,
 *          Kapuzinerstraße 32,
 *          96047 Bamberg
 *          http://www.docufy.de
 * $LastChangedBy: frank $
 * $LastChangedDate: 2013-02-25 17:47:28 +0100 (Mo, 25 Feb 2013) $
 * $HeadURL: svn://192.168.11.107/projects/viessmann/trunk/server/kernelplugin/src/main/java/de/docufy/viessmann/service/resolver/handler/ViessmannAttributeExtender.java $
 * $LastChangedRevision: 67530 $
 *******************************************************************************/
package model;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author Philipp
 *
 */
@Entity
@Table(name="root")
@Cacheable(false)
public class RootModel {

	@EmbeddedId
	private RootPk pk;

	@Column(name="r_name")
	private String name;

	/**
	 * @return the pk
	 */
	public RootPk getPk() {
		return pk;
	}

	/**
	 * @param pk the pk to set
	 */
	public void setPk(RootPk pk) {
		this.pk = pk;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RootModel [name=" + name + "]";
	}
}
