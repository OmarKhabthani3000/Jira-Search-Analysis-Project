/*******************************************************************************
 * Copyright: DOCUFY GmbH (c) 2013
 * Company: DOCUFY GmbH,
 *          Kapuzinerstraße 32,
 *          96047 Bamberg
 *          http://www.docufy.de
 * $LastChangedBy: frank $
 * $LastChangedDate: 2013-02-25 17:47:28 +0100 (Mo, 25 Feb 2013) $
 * $HeadURL: svn://192.168.11.107/projects/viessmann/trunk/server/kernelplugin/src/main/java/de/docufy/viessmann/service/resolver/handler/ViessmannAttributeExtender.java $
 * $LastChangedRevision: 67530 $
 *******************************************************************************/
package model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * @author Philipp
 *
 */
@Embeddable
public class RootPk implements Serializable {

	@Column(name="r_id")
	private String id;

	@Column(name="r_version")
	private int version;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RootPk [id=" + id + ", version=" + version + "]";
	}
}
