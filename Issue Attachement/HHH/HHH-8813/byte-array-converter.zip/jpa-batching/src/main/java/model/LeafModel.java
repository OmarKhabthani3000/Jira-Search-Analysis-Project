/*******************************************************************************
 * Copyright: DOCUFY GmbH (c) 2013
 * Company: DOCUFY GmbH,
 *          Kapuzinerstraße 32,
 *          96047 Bamberg
 *          http://www.docufy.de
 * $LastChangedBy: frank $
 * $LastChangedDate: 2013-02-25 17:47:28 +0100 (Mo, 25 Feb 2013) $
 * $HeadURL: svn://192.168.11.107/projects/viessmann/trunk/server/kernelplugin/src/main/java/de/docufy/viessmann/service/resolver/handler/ViessmannAttributeExtender.java $
 * $LastChangedRevision: 67530 $
 *******************************************************************************/
package model;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author Philipp
 *
 */
@Entity
@Table(name="leaf")
@Cacheable(false)
public class LeafModel {

	@Id
	@Column(name="l_id")
	private String id;
	
	@ManyToOne(optional=false)
	@JoinColumns({
		@JoinColumn(name="l_node_id", referencedColumnName="n_id", updatable=false),
		@JoinColumn(name="l_node_version", referencedColumnName="n_version", updatable=false)
	})
	private NodeModel parent;

	@Column(name="l_name")
	private String name;

	@Convert(converter=converter.StringToByteArrayConverter.class)
	private String errorDump;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the parent
	 */
	public NodeModel getParent() {
		return parent;
	}

	/**
	 * @param parent the parent to set
	 */
	public void setParent(NodeModel parent) {
		this.parent = parent;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "LeafModel [name=" + name + "]";
	}
}
