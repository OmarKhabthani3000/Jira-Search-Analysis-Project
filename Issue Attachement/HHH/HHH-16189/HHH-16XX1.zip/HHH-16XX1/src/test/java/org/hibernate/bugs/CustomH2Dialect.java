package org.hibernate.bugs;

import org.hibernate.dialect.H2Dialect;
import org.hibernate.dialect.SelectItemReferenceStrategy;
import org.hibernate.engine.jdbc.dialect.spi.DialectResolutionInfo;

public class CustomH2Dialect extends H2Dialect {

	public CustomH2Dialect(DialectResolutionInfo info) {
		super(info);
	}

	@Override
	public SelectItemReferenceStrategy getGroupBySelectItemReferenceStrategy() {
		return SelectItemReferenceStrategy.EXPRESSION;
	}
}
