package hibernate.bug.model;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.usertype.UserType;

public class TagUserType implements UserType {

    public static final UserType INSTANCE = new TagUserType();
    
    private final int SQLTYPE = java.sql.Types.VARCHAR;

    @Override
    public void nullSafeSet(PreparedStatement statement, Object value, int index, SessionImplementor session) throws HibernateException, SQLException {
        if (value == null) {
            statement.setNull(index, SQLTYPE);
        } else {
            @SuppressWarnings("unchecked")
            List<String> list = (List<String>) value;
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < list.size(); i++) {
                if (i != 0) {
                    sb.append('|');
                }
                sb.append(list.get(i));
            }

            statement.setString(index, sb.toString());
        }
    }

    @Override
    public Object nullSafeGet(ResultSet rs, String[] names, SessionImplementor session, Object owner) throws HibernateException, SQLException {
        String string = rs.getString(names[0]);

        if (rs.wasNull()) {
            return null;
        }

        List<String> list = new ArrayList<String>();
        int lastIndex = 0, index;

        while ((index = string.indexOf('|', lastIndex)) != -1) {
            list.add(string.substring(lastIndex, index));
            lastIndex = index + 1;
        }

        if (lastIndex != string.length()) {
            list.add(string.substring(lastIndex));
        }

        return list;
    }

    public int[] sqlTypes() {
        return new int[]{SQLTYPE};
    }

    public Class returnedClass() {
        return List.class;
    }

    @Override
    public Object assemble(final Serializable cached, final Object owner) throws HibernateException {
        return cached;
    }

    @Override
    @SuppressWarnings("unchecked")
    public Object deepCopy(final Object o) throws HibernateException {
        return o == null ? null : new ArrayList<String>((List<String>) o);
    }

    @Override
    public Serializable disassemble(final Object o) throws HibernateException {
        return (Serializable) o;
    }

    @Override
    public boolean equals(final Object x, final Object y) throws HibernateException {
        return x == null ? y == null : x.equals(y);
    }

    @Override
    public int hashCode(final Object o) throws HibernateException {
        return o == null ? 0 : o.hashCode();
    }

    @Override
    public boolean isMutable() {
        return true;
    }

    @Override
    public Object replace(final Object original, final Object target, final Object owner) throws HibernateException {
        return original;
    }

}
