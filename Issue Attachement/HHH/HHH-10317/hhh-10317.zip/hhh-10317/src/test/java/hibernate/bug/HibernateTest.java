package hibernate.bug;

import hibernate.bug.model.Document;
import hibernate.bug.model.TagUserType;
import java.util.Arrays;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import org.hibernate.engine.spi.TypedValue;
import org.hibernate.type.CustomType;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    private int docId;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Document a = new Document();
        a.getTags().add("important");
        a.getTags().add("business");
        em.persist(a);
        docId = a.getId();
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testJpa() {
        test(new Binder() {

            public void bind(Query q) {
                q.setParameter("tags", new TypedValue(new CustomType(TagUserType.INSTANCE), Arrays.asList("special","nice")));
                q.setParameter("oldTags", new TypedValue(new CustomType(TagUserType.INSTANCE), Arrays.asList("important","business")));
            }
        });
    }
    
    @Test
    public void testHibernate() {
        test(new Binder() {

            public void bind(Query q) {
                org.hibernate.Query hibernateQuery = q.unwrap(org.hibernate.Query.class);
                hibernateQuery.setParameter("tags", Arrays.asList("special","nice"), new CustomType(TagUserType.INSTANCE));
                hibernateQuery.setParameter("oldTags", Arrays.asList("important","business"), new CustomType(TagUserType.INSTANCE));
            }
        });
    }
    
    private void test(Binder b) {
        EntityManager em = emf.createEntityManager();
        
        Query q = em.createQuery(
                "UPDATE Document d SET d.tags = :tags WHERE CONTAINS_TAGS(d.tags,:oldTags)=true");
        b.bind(q);
        
        EntityTransaction tx = em.getTransaction();
        int updated;
        
        try {
            tx.begin();
            updated = q.executeUpdate();
            tx.commit();
        } catch (RuntimeException ex) {
            tx.rollback();
            throw ex;
        }
        
        Document d = em.find(Document.class, docId);
        em.close();
        
        Assert.assertEquals(1, updated);
        Assert.assertEquals(Arrays.asList("special", "nice"), d.getTags());
    }
    
    private static interface Binder {
        public void bind(Query q);
    }
}
