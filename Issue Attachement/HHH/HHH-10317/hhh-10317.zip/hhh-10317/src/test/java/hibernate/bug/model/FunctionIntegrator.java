package hibernate.bug.model;

import java.lang.reflect.Field;
import java.util.Map;
import org.hibernate.boot.Metadata;
import org.hibernate.dialect.function.SQLFunction;
import org.hibernate.dialect.function.SQLFunctionRegistry;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.integrator.spi.Integrator;
import org.hibernate.service.spi.SessionFactoryServiceRegistry;

public class FunctionIntegrator implements Integrator {

    public void integrate(Metadata metadata, SessionFactoryImplementor sessionFactory, SessionFactoryServiceRegistry serviceRegistry) {
        // Does not work?
        //metadata.getSessionFactoryBuilder().applySqlFunction("contains_tags", new ContainsFunction());
        
        // Does not work either?
        //metadata.getSqlFunctionMap().put("contains_tags", new ContainsFunction());
        
        getFunctionMap(sessionFactory).put("contains_tags", new ContainsFunction());
    }

    private Map<String, SQLFunction> getFunctionMap(SessionFactoryImplementor sessionFactory) {
        SQLFunctionRegistry registry = sessionFactory.getSqlFunctionRegistry();
        Exception ex;

        // We have to retrieve the functionMap the old fashioned way via reflection :(
        try {
            Field f = SQLFunctionRegistry.class.getDeclaredField("functionMap");
            f.setAccessible(true);
            return (Map<String, SQLFunction>) f.get(registry);
        } catch (NoSuchFieldException e) {
            ex = e;
        } catch (IllegalArgumentException e) {
            // This can never happen
            ex = e;
        } catch (IllegalAccessException e) {
            ex = e;
        }

        throw new RuntimeException("Could not access the function map to dynamically register functions.", ex);
    }

    public void disintegrate(SessionFactoryImplementor sessionFactory, SessionFactoryServiceRegistry serviceRegistry) {

    }

}
