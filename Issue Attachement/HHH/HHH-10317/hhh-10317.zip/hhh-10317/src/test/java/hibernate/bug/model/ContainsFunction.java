package hibernate.bug.model;

import java.util.List;
import org.hibernate.QueryException;
import org.hibernate.dialect.function.SQLFunction;
import org.hibernate.engine.spi.Mapping;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.type.BooleanType;
import org.hibernate.type.Type;

public class ContainsFunction implements SQLFunction {

    public boolean hasArguments() {
        return true;
    }

    public boolean hasParenthesesIfNoArguments() {
        return true;
    }

    public Type getReturnType(Type type, Mapping mpng) throws QueryException {
        return BooleanType.INSTANCE;
    }

    public String render(Type type, List list, SessionFactoryImplementor sfi) throws QueryException {
        return sfi.getDialect().getFunctions().get("locate").render(type, list, sfi) + " <> -1";
    }
    
}
