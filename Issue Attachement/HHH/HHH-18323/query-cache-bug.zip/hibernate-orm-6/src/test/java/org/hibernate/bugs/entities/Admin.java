package org.hibernate.bugs.entities;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import java.util.Objects;

@Entity
@Table(name = "ADMIN")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "default-by-id-region")
public class Admin extends BaseEntity {

  @Column(name = "NAME", nullable = false, length = 256)
  private String name;

  @OneToOne(mappedBy = "admin", cascade = CascadeType.ALL, orphanRemoval = true)
  private AdminKey adminKey;

  public Admin() {

  }

  public String getName() {
    return name;
  }

  public void setName(final String name) {
    this.name = name;
  }

  public AdminKey getKey() {
    return adminKey;
  }

  public void setKey(final AdminKey adminKey) {
    this.adminKey = adminKey;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    if (!super.equals(o)) {
      return false;
    }

    final Admin admin = (Admin) o;
    return Objects.equals(name, admin.name) && Objects.equals(adminKey, admin.adminKey);
  }

  @Override
  public int hashCode() {
    int result = super.hashCode();
    result = 31 * result + Objects.hashCode(name);
    result = 31 * result + Objects.hashCode(adminKey);
    return result;
  }
}