/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import jakarta.persistence.EntityNotFoundException;
import org.hibernate.Session;
import org.hibernate.bugs.entities.Admin;
import org.hibernate.bugs.entities.AdminKey;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.jdbc.Work;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

public class QueryCacheWithShallowLayoutTestCase extends BaseCoreFunctionalTestCase {

  // Add your entities here.
  @Override
  protected Class[] getAnnotatedClasses() {
    return new Class[] {
        Admin.class,
        AdminKey.class
    };
  }

  @Override
  protected void configure(Configuration configuration) {
    super.configure(configuration);

    configuration.setProperty(AvailableSettings.SHOW_SQL, Boolean.TRUE.toString());
    configuration.setProperty(AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString());
    configuration.setProperty("hibernate.cache.use_query_cache", "true");
    configuration.setProperty("hibernate.cache.use_second_level_cache", "true");
    configuration.setProperty("hibernate.cache.region.factory_class", "jcache");
    configuration.setProperty("hibernate.javax.cache.provider", "org.ehcache.jsr107.EhcacheCachingProvider");
    configuration.setProperty("hibernate.javax.cache.uri", "ehcache.xml");
    configuration.setProperty("hibernate.cache.query_cache_layout", "SHALLOW");
    configuration.setProperty("hibernate.hbm2ddl.auto", "create-drop");
    configuration.setProperty("hibernate.current_session_context_class", "thread");
  }

  @Test
  public void testAdminAndAdminKeyIsCacheable() {

    try (final var s = openSession()) {
      final var tx1 = s.beginTransaction();
      final var admin = new Admin();
      admin.setName("Bob");
      s.persist(admin);
      tx1.commit();

      final var tx2 = s.beginTransaction();
      final var key = new AdminKey();
      key.setAdmin(admin);
      s.persist(key);
      tx2.commit();
    }

    final Admin adminFromDb2;
    try (final var s = openSession()) {
      adminFromDb2 = findByName(s, "Bob");
      assertThat(adminFromDb2).isNotNull();
    }

    deleteEntitiesSilently();

    try (final var s = openSession()) {
      final var adminFromDb3 = findByName(s, "Bob");
      assertThat(adminFromDb3).isNotNull();
      assertThat(adminFromDb3.getKey()).isNull();
    }

    sessionFactory().getCache().evictAll();

    try (final var s = openSession()) {
      assertThatThrownBy(() -> findByName(s, "Bob")).isInstanceOf(EntityNotFoundException.class);
    }
  }

  private Admin findByName(final Session s, final String name) {
    return s.createQuery(
                "select a " +
                    "from Admin a where a.name = :name", Admin.class)
            .setParameter("name", name)
            .setCacheable(true)
            .getSingleResult();
  }

  private void deleteEntitiesSilently() {
    try (final var s = openSession()) {
      s.doWork(connection -> {
        Statement stmt = null;
        try {
          stmt = connection.createStatement();
          String sql = "DELETE FROM admin_key";
          stmt.executeUpdate(sql);
          sql = "DELETE FROM admin";
          stmt.executeUpdate(sql);
        } finally {
          if (stmt != null) {
            stmt.close();
          }
        }
      });
    }
  }
}
