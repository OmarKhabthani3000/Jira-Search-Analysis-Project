package org.hibernate.bugs.entities;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.Version;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Objects;
import java.util.UUID;

@MappedSuperclass
public abstract class BaseEntity {

  public BaseEntity() {
    schemaVersion = 1;
  }

  @Id
  @GeneratedValue(strategy = GenerationType.UUID)
  @Column(name = "ID")
  protected UUID id;

  @Version
  @Column(name = "VERSION")
  protected int version;

  @Column(name = "SCHEMA_VERSION", nullable = false)
  protected Integer schemaVersion;

  @Column(name = "CREATED_TIME")
  @CreationTimestamp
  protected Timestamp createdTime;

  @Column(name = "MODIFIED_TIME")
  @UpdateTimestamp
  protected Timestamp modifiedTime;

  public UUID getId() {
    return id;
  }

  public void setId(final UUID id) {
    this.id = id;
  }

  public int getVersion() {
    return version;
  }

  public void setVersion(final int version) {
    this.version = version;
  }

  public Integer getSchemaVersion() {
    return schemaVersion;
  }

  public void setSchemaVersion(final Integer schemaVersion) {
    this.schemaVersion = schemaVersion;
  }

  public Timestamp getCreatedTime() {
    return createdTime;
  }

  public void setCreatedTime(final Timestamp createdTime) {
    this.createdTime = createdTime;
  }

  public Timestamp getModifiedTime() {
    return modifiedTime;
  }

  public void setModifiedTime(final Timestamp modifiedTime) {
    this.modifiedTime = modifiedTime;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }

    final BaseEntity that = (BaseEntity) o;
    return version == that.version && Objects.equals(id, that.id) && Objects.equals(schemaVersion,
                                                                                    that.schemaVersion) && Objects.equals(
        createdTime,
        that.createdTime) && Objects.equals(modifiedTime, that.modifiedTime);
  }

  @Override
  public int hashCode() {
    int result = Objects.hashCode(id);
    result = 31 * result + version;
    result = 31 * result + Objects.hashCode(schemaVersion);
    result = 31 * result + Objects.hashCode(createdTime);
    result = 31 * result + Objects.hashCode(modifiedTime);
    return result;
  }
}
