package org.hibernate.bugs.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import java.util.Objects;

@Entity
@Table(name = "ADMIN_KEY")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "default-by-id-region")
public class AdminKey extends BaseEntity {

  @OneToOne(targetEntity = Admin.class)
  @JoinColumn(name = "ADMIN_ID", nullable = false, foreignKey = @ForeignKey(name =
      "FK_ADMIN_KEY"))
  private Admin admin;

  public Admin getAdmin() {
    return admin;
  }

  public void setAdmin(final Admin admin) {
    this.admin = admin;
  }
}
