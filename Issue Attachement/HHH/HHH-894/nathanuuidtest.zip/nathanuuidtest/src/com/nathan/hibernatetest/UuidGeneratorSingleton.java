/*
 * UuidGeneratorSingleton.java
 *
 * Created on October 8, 2004, 9:43 AM
 */

package com.nathan.hibernatetest;

import org.doomdark.uuid.UUIDGenerator;

/**
 * This is a utility class used for generating UUIDs. It is essential to use this class
 * when writting DAOs that insert into tables that require a UUID for identity.  Please
 * refer to the LMS ERD. All fields that require a UUID are name XXXX_UUID.
 * @author  nadenj
 */
public class UuidGeneratorSingleton{
    private static UuidGeneratorSingleton instance = new UuidGeneratorSingleton();
    
    private UuidGeneratorSingleton() {
        
    }
    
    public static UuidGeneratorSingleton getInstance(){
        return instance;
    }
    
    
    
    /**
     *Get a UUID. Guaranteed to be unique across all space and time :).
     *
     *@return A 32 character hexadecimal.
     */
    public static String getUuid(){
        String uuid = UUIDGenerator.getInstance().generateTimeBasedUUID().toString();
//        uuid = uuid.replaceAll("-", "");
        return uuid;
    }
    
}
