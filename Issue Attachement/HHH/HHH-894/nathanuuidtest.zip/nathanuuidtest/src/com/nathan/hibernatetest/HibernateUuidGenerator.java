/*
 * HibernateUuidGenerator.java
 *
 * Created on April 8, 2005, 10:30 AM
 */

package com.nathan.hibernatetest;

import java.io.Serializable;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.HibernateException;
/**
 *
 * @author  nadenj
 */
public class HibernateUuidGenerator implements org.hibernate.id.IdentifierGenerator{
    
    /** Creates a new instance of HibernateUuidGenerator */
    public HibernateUuidGenerator() {
    }
    
    public Serializable generate(SessionImplementor session, Object object) throws HibernateException{
        return UuidGeneratorSingleton.getInstance().getUuid();
        
    }
    
}
