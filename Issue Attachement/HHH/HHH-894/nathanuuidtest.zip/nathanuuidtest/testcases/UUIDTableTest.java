import java.net.URL;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nathan.hibernatetest.OneToOneTable;
import com.nathan.hibernatetest.UUIDTable;

public class UUIDTableTest extends TestCase {

	public void testOne() throws Exception {
		Configuration cfg = new Configuration();
		// read configuration from file
		URL r = this.getClass().getClassLoader().getResource("nathanuuidtest.cfg.xml");
		assertNotNull(r);
		// read configuration from file
		cfg.configure(r);

		SessionFactory sf = cfg.buildSessionFactory();

		try {
			Session s = sf.openSession();
			Transaction t = s.beginTransaction();
			
			OneToOneTable onetooneclass = new OneToOneTable();
			UUIDTable uuidclass = new UUIDTable();
			onetooneclass.setUUIDTable(uuidclass);
			
			s.save(onetooneclass);
			
			t.commit();
			s.close();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
}
