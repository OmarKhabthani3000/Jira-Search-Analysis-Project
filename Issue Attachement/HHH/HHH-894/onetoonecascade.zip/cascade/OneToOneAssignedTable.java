package org.hibernate.test.onetoone.cascade;

public class OneToOneAssignedTable {

    // Fields    

     private Long Id;
     private AssignedIdTable AssignedIdTable;


    // Constructors

    /** default constructor */
    public OneToOneAssignedTable() {
    }
    
    /** constructor with id */
    public OneToOneAssignedTable(Long Id) {
        this.Id = Id;
    }
   
    // Property accessors

    /**
     * 
     */
    public Long getId() {
        return this.Id;
    }
    
    public void setId(Long Id) {
        this.Id = Id;
    }

    /**
     * 
     */
    public AssignedIdTable getAssignedIdTable() {
        return this.AssignedIdTable;
    }
    
    public void setAssignedIdTable(AssignedIdTable AssignedIdTable) {
        this.AssignedIdTable = AssignedIdTable;
    }

}