package org.hibernate.test.onetoone.cascade;

public class NativeIdTable {

    // Fields    

     private Long NativeIdTableId;


    // Constructors

    /** default constructor */
    public NativeIdTable() {
    }
    
    /** constructor with id */
    public NativeIdTable(Long NativeIdTableId) {
        this.NativeIdTableId = NativeIdTableId;
    }

    // Property accessors

    /**
     * 
     */
    public Long getNativeIdTableId() {
        return this.NativeIdTableId;
    }
    
    public void setNativeIdTableId(Long NativeIdTableId) {
        this.NativeIdTableId = NativeIdTableId;
    }

}