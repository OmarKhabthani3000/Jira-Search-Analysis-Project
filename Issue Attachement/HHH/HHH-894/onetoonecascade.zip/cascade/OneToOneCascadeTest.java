//$Id:  $
package org.hibernate.test.onetoone.cascade;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.TestCase;

/**
 * @author Nathan Moon
 */
public class OneToOneCascadeTest extends TestCase {
	
	public OneToOneCascadeTest(String str) {
		super(str);
	}
	
	public void testOneToOneCascadeNative() {
	
		// THIS TEST PASSES - THE ONLY DIFFERENCE FROM THE SECOND TEST
		// IS THAT NativeIdTable HAS A NATIVE GENERATED ID
		
		NativeIdTable nid = new NativeIdTable();
		OneToOneNativeTable oton = new OneToOneNativeTable();
		oton.setNativeIdTable(nid);
		
		Session s = openSession();
		Transaction t = s.beginTransaction();
		s.persist(oton);
		t.commit();
		s.close();
	
		s = openSession();
		t = s.beginTransaction();
		oton = (OneToOneNativeTable) s.createQuery("from OneToOneNativeTable").uniqueResult();
		assertNotNull( oton.getNativeIdTable() );

		s.delete(oton);
		t.commit();
		s.close();
		
	}
	
	public void testOneToOneCascadeAssigned() {
		
		// THIS TEST FAILS - THE ONLY DIFFERENCE FROM THE FIRST TEST
		// IS THAT AssignedIdTable HAS AN ASSIGNED ID
		
		AssignedIdTable aid = new AssignedIdTable();
		aid.setAssignedIdTableId(new Long(1));
		OneToOneAssignedTable otoa = new OneToOneAssignedTable();
		otoa.setAssignedIdTable(aid);
		
		Session s = openSession();
		Transaction t = s.beginTransaction();
		s.persist(otoa);
		t.commit();
		s.close();
	
		s = openSession();
		t = s.beginTransaction();
		otoa = (OneToOneAssignedTable) s.createQuery("from OneToOneAssignedTable otoa where otoa.AssignedIdTable.AssignedIdTableId = 1").uniqueResult();
		assertEquals( otoa.getAssignedIdTable().getAssignedIdTableId(), new Long(1) );
		s.clear();

		s.delete(otoa);
		t.commit();
		s.close();
		
	}
	
	protected String[] getMappings() {
		return new String[] { "onetoone/cascade/OneToOneCascade.hbm.xml" };
	}

	public static Test suite() {
		return new TestSuite(OneToOneCascadeTest.class);
	}

}

