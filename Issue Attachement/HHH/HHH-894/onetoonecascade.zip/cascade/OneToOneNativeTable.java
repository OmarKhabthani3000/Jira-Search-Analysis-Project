package org.hibernate.test.onetoone.cascade;

public class OneToOneNativeTable {

    // Fields    

     private Long Id;
     private NativeIdTable NativeIdTable;


    // Constructors

    /** default constructor */
    public OneToOneNativeTable() {
    }
    
    /** constructor with id */
    public OneToOneNativeTable(Long Id) {
        this.Id = Id;
    }
   
    // Property accessors

    /**
     * 
     */
    public Long getId() {
        return this.Id;
    }
    
    public void setId(Long Id) {
        this.Id = Id;
    }

    /**
     * 
     */
    public NativeIdTable getNativeIdTable() {
        return this.NativeIdTable;
    }
    
    public void setNativeIdTable(NativeIdTable NativeIdTable) {
        this.NativeIdTable = NativeIdTable;
    }

}