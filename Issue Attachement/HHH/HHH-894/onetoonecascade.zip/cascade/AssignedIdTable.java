package org.hibernate.test.onetoone.cascade;

public class AssignedIdTable {

    // Fields    

     private Long AssignedIdTableId;


    // Constructors

    /** default constructor */
    public AssignedIdTable() {
    }
    
    /** constructor with id */
    public AssignedIdTable(Long AssignedIdTableId) {
        this.AssignedIdTableId = AssignedIdTableId;
    }

    // Property accessors

    /**
     * 
     */
    public Long getAssignedIdTableId() {
        return this.AssignedIdTableId;
    }
    
    public void setAssignedIdTableId(Long AssignedIdTableId) {
        this.AssignedIdTableId = AssignedIdTableId;
    }

}