package jpaunittest;

import entity.Veranstalter;
import entity.Veranstaltungsort;
import entity.primarykey.VeranstalterPK;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;
import java.util.logging.Logger;
import javax.naming.NamingException;

import org.junit.After;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM,
 * using the Java Persistence API.
 */
public class JPAUnitTestCase {
private static final Logger log = Logger
            .getLogger(JPAUnitTestCase.class.getName());
    private EntityManagerFactory entityManagerFactory;

    private static final String AOL_ARENA = "AOL-Arena";
    private static final String HAMBURG_VOLKSPARK = "Hamburg Volkspark";
    private static final int KAPAZITAET = 51500;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("ticket2rock-test");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
 /*   @Test
    public void hhh123Test() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        // Do stuff...
        entityManager.getTransaction().commit();
        entityManager.close();
    }

*/
     @Test
    public void testInsertVeranstaltungsort() throws NamingException, Exception {
        Veranstaltungsort ort = new Veranstaltungsort();
        // id wird automatisch vergeben
        ort.setName(AOL_ARENA);
        ort.setAdresse(HAMBURG_VOLKSPARK);
        ort.setKapazitaet(KAPAZITAET);
        ort.setKoordinaten(null);
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        Boolean isActive = entityManager.getTransaction().isActive();
        log.info((isActive?"Yes":"No"));
        //          garnichts...
        entityManager.persist(ort);
        // und die neue automatisch vergebene ID ist im Objekt vorhanden
        int volksparkId = ort.getId();
        log.info("Query mit Ort: " + volksparkId);
        // Kontrolle �ber JPAQL
        Query query = entityManager.createQuery("from Veranstaltungsort v where v.id = "
                + volksparkId);
        Veranstaltungsort ort2 = entityManager.find(Veranstaltungsort.class, volksparkId);
        log.info("gefunden : " + ort2.getName());
        assertEquals(AOL_ARENA, ort2.getName());
        assertEquals(HAMBURG_VOLKSPARK, ort2.getAdresse());
        assertEquals(KAPAZITAET, ort2.getKapazitaet());
        entityManager.getTransaction().rollback(); // jetzt koennen wir den Kram auch
        // wegschmeissen

     //   entityManager.getTransaction().commit();
        entityManager.close();
    }

    @Test
    public void testInsertVeranstalter() throws NamingException, Exception {
        Veranstalter veranstalter = new Veranstalter();
        // id wird automatisch vergeben
        veranstalter.setName("MCT Konzertagentur GmbH");
        VeranstalterPK id  = new VeranstalterPK(new Long(4712), "Sexau");
        veranstalter.setPk(id);
        
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        Boolean isActive = entityManager.getTransaction().isActive();
        log.info((isActive?"Yes":"No"));
        //          garnichts...
        entityManager.persist(veranstalter);
        // und die neue automatisch vergebene ID ist im Objekt vorhanden
        String name = veranstalter.getName();
        log.info("Query mit Veranstalter: " + name);
        // Kontrolle �ber JPAQL
        Query query = entityManager.createQuery("from Veranstalter v where v.name = \""
                + name + "\"");
        Veranstalter veranst = entityManager.find(Veranstalter.class, id);
        log.info("gefunden : " + veranst.getName());
        assertEquals("MCT Konzertagentur GmbH", veranst.getName());
        assertEquals("Sexau", veranst.getPk().getAmtsgericht());
        assertEquals(4712, veranst.getPk().getHandelsregisternummer());
      
      //  entityManager.getTransaction().rollback(); // jetzt koennen wir den Kram auch
        // wegschmeissen

     //   entityManager.getTransaction().commit();
        entityManager.close();
    }
}
