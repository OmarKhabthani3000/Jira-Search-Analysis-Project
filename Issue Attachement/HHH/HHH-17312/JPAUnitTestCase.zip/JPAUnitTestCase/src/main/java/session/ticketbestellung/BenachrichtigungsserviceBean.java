/**
 * Ticket2Rock ist die Beispielanwendung des Buchs "EJB 3.1 professionell"
 * (dpunkt). Es implementiert eine einfache Webanwendung zur Onlinebuchung von
 * Tickets für Rockkonzerten.
 *
 * Copyright (C) 2006-2011 Holisticon AG
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 51
 * Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */
package session.ticketbestellung;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import jakarta.annotation.Resource;
import jakarta.ejb.Stateless;
import jakarta.ejb.Timeout;
import jakarta.ejb.Timer;
import jakarta.ejb.TimerService;

import entity.Konzert;
import entity.Ticketbestellung;
import java.text.NumberFormat;
import jakarta.mail.Address;
import jakarta.mail.Message;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Currency;
import java.util.Date;
import java.util.logging.Logger;

@Stateless
public class BenachrichtigungsserviceBean implements
        BenachrichtigungsserviceLocal {

    static final Logger logger = Logger.getLogger(BenachrichtigungsserviceBean.class.getName());

    @Resource
    private TimerService timerService;

    @Resource(mappedName = "java:jboss/mail/Default")
    private Session mailSession;

    public void installiereKonzerterinnerungen(String email,
            List<Ticketbestellung> ticketBestellungen) {
        for (Ticketbestellung bestellung : ticketBestellungen) {
            Konzert konzert = bestellung.getKonzert();
            SimpleDateFormat sd = new SimpleDateFormat("dd.MM.yyyy");
            NumberFormat nf = NumberFormat.getInstance();
            nf.setMinimumFractionDigits(2);
            nf.setMaximumFractionDigits(2);
            String dateString = sd.format(konzert.getDatum());
            String gesamtPreis = nf.format(konzert.getTicketpreis() * bestellung.getAnzahl());
            String[] benachrichtigungsInfo = new String[]{email,
                konzert.getInterpret().getName(),
                konzert.getOrt().getAdresse(),
                dateString,
                Integer.toString(bestellung.getAnzahl()),
                gesamtPreis,
                Integer.toString(bestellung.getId())};
            Calendar timerCalendar = GregorianCalendar.getInstance();
            timerCalendar.setTime(konzert.getDatum());
            timerCalendar.add(Calendar.DATE, -1);
            timerService.createTimer(timerCalendar.getTime(),
                    benachrichtigungsInfo);
        }
    }

    @Timeout
    public void benachrichtigeKunde(Timer timer) {
        String[] infos = (String[]) timer.getInfo();
        String mailAdresse = infos[0];
        String interpret = infos[1];
        String stadt = infos[2];
        String termin = infos [3];
        String tickets = infos[4];
        String gesamtPreis = infos[5];
        String bestNr = infos[6];
        GregorianCalendar cal = new GregorianCalendar();
        String today = String.format("%1$td.%1$tm.%1$tY", cal);
        logger.info("Mail-Versand an " + mailAdresse);
       // logger.info("Sehr geehrter Kunde, bitte vergessen Sie das Konzert von "
       //         + interpret + " in " + stadt + " am morgigen Tag nicht.");
        try {
            MimeMessage m = new MimeMessage(mailSession);
        //    Address from = new InternetAddress("w.mayer.55@web.de"); // in WildFly hinterlegt
            Address[] to = new InternetAddress[]{new InternetAddress(mailAdresse)};

        //   m.setFrom(from);
            m.setFrom(new InternetAddress(mailSession.getProperty("mail.from")));
            m.setRecipients(Message.RecipientType.TO, to);
            m.setSubject("Ticket2Rock: Ticketbestellung");
            m.setSentDate(new java.util.Date());
            m.setText("Sehr geehrter Kunde,\n\n"
                    + "Wir bestätigen Ihre Bestellung vom " + today + "\n"
                    + "Bestell-Nr: " + bestNr  + "\n"
                    + tickets + " Tickets zum Gesamtpreis von "
                    + gesamtPreis 
                    + Currency.getInstance(Locale.getDefault()).getSymbol() 
                    + " für " + interpret + " am " + termin + " in " + stadt 
                    + "\n\nGruss\nAdministrator\n");
            Transport.send(m);
        }
        catch (jakarta.mail.MessagingException e) {
            e.printStackTrace();
            logger.warning("Error in Sending Mail: " + e);
        }
    }
}
