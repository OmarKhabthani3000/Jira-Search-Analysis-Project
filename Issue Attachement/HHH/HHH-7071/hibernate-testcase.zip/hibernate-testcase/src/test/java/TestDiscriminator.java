import java.sql.Connection;
import java.sql.SQLException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.jdbc.Work;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(value = SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:context.xml")
public class TestDiscriminator {

    @Autowired
    private SessionFactory sessionFactory;

    @Before
    public void injectData() {
        Session session = sessionFactory.openSession();

        session.doWork(new Work() {
            @Override
            public void execute(Connection connection) throws SQLException {
                int execute = connection.prepareCall(
                        "INSERT INTO product (ID, code, type) values (1, 'Test product', 'MY BAD DISCRIMINATOR')")
                                        .executeUpdate();
                execute = connection.prepareCall("INSERT INTO ProductCategory (ID, code ) values (1, 'Test category')")
                                    .executeUpdate();
                execute = connection.prepareCall(
                        "INSERT INTO product_productcategory (productCategoryID, productID ) values (1, 1)")
                                    .executeUpdate();
            }
        });
        session.flush();
        session.close();
    }

    @Test
    public void testDiscriminator() {

        Session session = sessionFactory.openSession();

        ProductCategory productCategory = (ProductCategory) session.get(ProductCategory.class, 1);

        System.out.println(productCategory);

        session.close();
    }
}
