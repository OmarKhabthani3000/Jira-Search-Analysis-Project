import java.util.List;

public class ProductCategory {
    private Integer id;
    private String code;
    private List<Product> products;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String toString() {
        return "ProductCategory{" +
                "id=" + id +
                ", code='" + code + '\'' +
                ", products=" + products +
                '}';
    }
}
