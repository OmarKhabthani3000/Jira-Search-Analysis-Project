public class ChildProduct extends Product {
}
