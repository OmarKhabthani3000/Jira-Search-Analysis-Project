package org.jboss.testcase.duplicatefield.entite;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "STUDENT")
public class Student implements Serializable {
    
	
    /**
	 * 
	 */
	private static final long serialVersionUID = -3933041835352883185L;
	
	
	private long id;
    private String fName;
    private String lName;

    
	@Column(name="SCHOOL_ID")
	private Long schoolId;


    
    @Id
    @Column(name="ID")
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Column(name="FNAME")
	public String getfName() {
		return fName;
	}
	
	public void setfName(String fName) {
		this.fName = fName;
	}

	@Column(name="LNAME")
	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

//	@ManyToOne(fetch=FetchType.LAZY, optional=false)
//	@JoinColumn(name="SCHOOL_ID", nullable = false)
//	public School getSchool() {
//		return school;
//	}
//
//	public void setSchool(School school) {
//		this.school = school;
//	}
	






}
