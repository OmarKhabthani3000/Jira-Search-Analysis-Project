package org.jboss.testcase.duplicatefield.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Root;


import org.jboss.testcase.duplicatefield.dao.SchoolDAO;
import org.jboss.testcase.duplicatefield.entite.School;

public class SchoolDAOImpl implements SchoolDAO {

	

	  private EntityManager entityManager;
	  
	  
	  public List<School> findSchoolByZip (String zip) {
		  
		  CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		    CriteriaQuery<School> criteriaQuery = criteriaBuilder.createQuery(School.class);
		    Root<School> root = criteriaQuery.from(School.class);
		    criteriaQuery.select(root);
		    List<Order> listeOrdre = new ArrayList<Order>();
		      listeOrdre.add(criteriaBuilder.asc(root.get("id")));
		      
		    ParameterExpression<String> zipParam = criteriaBuilder.parameter(String.class);
		   

		    criteriaQuery.where(criteriaBuilder.equal(root.get("zipCode"), zipParam)).orderBy(listeOrdre);
		    
		    TypedQuery<School> typedQuery = entityManager.createQuery(criteriaQuery);
		    typedQuery.setParameter(zipParam, zip);

		    
		    return typedQuery.getResultList();
		  
	  }
	  
	  public List<School> findSchoolByZipJPQLFetch (String zip) {
		  
		  	Query q = entityManager.createQuery("SELECT s FROM School s INNER JOIN FETCH s.students where s.zipCode = :zipParam order by s.id");
		    q.setParameter("zipParam", zip);
		  
		  
		    return  (List<School>) q.getResultList();
		  
	  }
	  
	  
	  public List<School> findSchoolByZipJPQL (String zip) {
		  
		  	Query q = entityManager.createQuery("SELECT s FROM School s where s.zipCode = :zipParam order by s.id");
		    q.setParameter("zipParam", zip);
		  
		  
		    return  (List<School>) q.getResultList();
		  
	  }


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
}
