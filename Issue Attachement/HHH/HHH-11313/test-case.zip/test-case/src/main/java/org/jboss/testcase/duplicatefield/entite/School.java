package org.jboss.testcase.duplicatefield.entite;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "SCHOOL")
public class School implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7724880349160587635L;
	
	
	private long id;
	private String name;
	private String zipCode;
	private List<Student> students = new ArrayList<Student>();

	@Id
	@Column(name = "ID")
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Column(name = "NAME")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "ZIP_CODE")
	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

//	@OneToMany(mappedBy = "school")
	@OneToMany
//	@JoinColumn(name="STUDENT_ID", nullable = false)
	@JoinColumn(name="SCHOOL_ID", referencedColumnName="ID")
	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

}
