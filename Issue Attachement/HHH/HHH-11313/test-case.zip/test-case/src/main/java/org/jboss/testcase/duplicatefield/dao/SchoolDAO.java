package org.jboss.testcase.duplicatefield.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.testcase.duplicatefield.entite.School;

public interface SchoolDAO {

	  List<School> findSchoolByZip (String zip);
	  
	  void setEntityManager(EntityManager entityManager);
	  
	  List<School> findSchoolByZipJPQLFetch (String zip);
	  List<School> findSchoolByZipJPQL (String zip);
	  
}
