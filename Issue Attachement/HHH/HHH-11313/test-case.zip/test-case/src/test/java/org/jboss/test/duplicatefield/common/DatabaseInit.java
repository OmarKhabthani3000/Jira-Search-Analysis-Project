package org.jboss.test.duplicatefield.common;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.h2.tools.RunScript;


public class DatabaseInit {

	private String connectionString;

	private Properties connectionProps = new Properties();

	private List<String> scriptsBefore = new ArrayList<>();

	private List<String> scriptsAfter = new ArrayList<>();

	public void before() throws FileNotFoundException, SQLException {
		for (String script : scriptsBefore) {
			executeScript(script);
		}
		scriptsBefore.clear();
	}
	
	

	public void after() throws FileNotFoundException, SQLException {
		for (String script : scriptsAfter) {
			executeScript(script);
		}
		scriptsAfter.clear();
	}

	public void executeScript(String script) throws FileNotFoundException, SQLException {
		FileReader reader = new FileReader(script);
		RunScript.execute(DriverManager.getConnection(connectionString, connectionProps), reader);
	}
	
	public String getConnectionString() {
		return connectionString;
	}

	public void setConnectionString(String connectionString) {
		this.connectionString = connectionString;
	}

	public Properties getConnectionProps() {
		return connectionProps;
	}

	public void setConnectionProps(Properties connectionProps) {
		this.connectionProps = connectionProps;
	}

	public List<String> getScriptsBefore() {
		return scriptsBefore;
	}

	public void setScriptsBefore(List<String> scriptsBefore) {
		this.scriptsBefore = scriptsBefore;
	}

	public List<String> getScriptsAfter() {
		return scriptsAfter;
	}

	public void setScriptsAfter(List<String> scriptsAfter) {
		this.scriptsAfter = scriptsAfter;
	}

}
