package org.jboss.test.duplicatefield.common;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;


public abstract class H2BaseTest extends JpaBaseRolledBackTestCase {

	private static final String JDBC_H2 = "jdbc:h2:mem:test;DB_CLOSE_DELAY=0;DATABASE_TO_UPPER=false;MODE=Oracle";

	protected DatabaseInit initialiseur = new DatabaseInit();



	@Before
	public void initBase() throws SQLException, FileNotFoundException {
		if (baseNeedInit()) {
			initialiseur.setConnectionString(JDBC_H2);
			initialiseur.getConnectionProps().setProperty("user", "sa");
			initialiseur.getConnectionProps().setProperty("password", "");
			initialiseur.getScriptsBefore().add("src/test/resources/sql/tools.sql");
			initialiseur.getScriptsBefore().add("src/test/resources/sql/initSchema.sql");
			initialiseur.getScriptsBefore().addAll(getScriptsBefore());
			initialiseur.before();
		}
		super.beginTransaction();
	}
	
	@After
	public void rollbackTransaction() {
		super.rollbackTransaction();
	}

	protected abstract Boolean baseNeedInit();

	protected abstract Collection<String> getScriptsBefore();

	@Override
	protected String getDsName() {
		return "jpa-test-h2";
	}

	public DatabaseInit getInitialiseur() {
		return initialiseur;
	}
	
	
	
}
