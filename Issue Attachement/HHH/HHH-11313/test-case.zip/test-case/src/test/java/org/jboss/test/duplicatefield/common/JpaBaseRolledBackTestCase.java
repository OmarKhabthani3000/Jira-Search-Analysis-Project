package org.jboss.test.duplicatefield.common;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.jglue.cdiunit.CdiRunner;
import org.junit.runner.RunWith;


@RunWith(CdiRunner.class)
public abstract class JpaBaseRolledBackTestCase {

	protected EntityManagerFactory emf;


	protected EntityManager em;


	protected abstract String getDsName();



	public void beginTransaction() {
		emf = Persistence.createEntityManagerFactory(getDsName());
		em = emf.createEntityManager();
		em.getTransaction().begin();
	}


	public void rollbackTransaction() {
		if (em.getTransaction().isActive()) {
			em.getTransaction().rollback();
		}

		if (em.isOpen()) {
			em.clear();
			em.close();
		}
		if (emf.isOpen()) {
			emf.close();
		}
		emf = null;
		em = null;
	}
}