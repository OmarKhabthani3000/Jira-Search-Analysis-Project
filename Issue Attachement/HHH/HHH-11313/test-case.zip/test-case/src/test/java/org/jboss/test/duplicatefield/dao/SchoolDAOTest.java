package org.jboss.test.duplicatefield.dao;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.inject.Inject;

import org.jboss.testcase.duplicatefield.dao.SchoolDAO;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.jboss.test.duplicatefield.common.H2BaseTest;
import org.jboss.testcase.duplicatefield.dao.impl.SchoolDAOImpl;
import org.jboss.testcase.duplicatefield.entite.School;



@RunWith(CdiRunner.class)
@AdditionalClasses({ SchoolDAOImpl.class })
public class SchoolDAOTest extends H2BaseTest {

	 @Inject
	  private SchoolDAO schoolDAO;

	  public SchoolDAOTest() throws FileNotFoundException, SQLException {
	    super();
	  }


	  @Test
	  public void testFindByZip() {
		  schoolDAO.setEntityManager(this.em);
		  

		  List<School> listSchoolTours = schoolDAO.findSchoolByZip("37000");
		  
		  Assert.assertNotNull(listSchoolTours);
		  Assert.assertEquals(2, listSchoolTours.size());
		  
		  School s = listSchoolTours.get(0);
		  
		  Assert.assertEquals(s.getName(), "Polytech");
		  

		  Assert.assertEquals(3, s.getStudents().size());
		  
		  
		  
	  }
	  
	  @Test
	  public void testFindByZipJPQL() {
		  schoolDAO.setEntityManager(this.em);
		  

		  List<School> listSchoolTours = schoolDAO.findSchoolByZipJPQL("37000");
		  
		  Assert.assertNotNull(listSchoolTours);
		  Assert.assertEquals(2, listSchoolTours.size());
		  
		  School s = listSchoolTours.get(0);
		  
		  Assert.assertEquals(s.getName(), "Polytech");
		  

		  Assert.assertEquals(3, s.getStudents().size());
		  
		  
		  
	  }
	  
	  @Test
	  public void testFindByZipJPQLFetch() {
		  schoolDAO.setEntityManager(this.em);
		  

		  List<School> listSchoolTours = schoolDAO.findSchoolByZipJPQLFetch("37000");
		  
		  Assert.assertNotNull(listSchoolTours);
		  
		  School s = listSchoolTours.get(0);
		  
		  Assert.assertEquals(s.getName(), "Polytech");
		  
		  Assert.assertEquals(3, s.getStudents().size());
		  
		  
		  
	  }
	  
	  @Override
	  protected Boolean baseNeedInit() {
	    return Boolean.TRUE;
	  }

	  @Override
	  protected Collection<String> getScriptsBefore() {
	    Collection<String> retour = new ArrayList<String>();
	    retour.add("src/test/resources/sql/initSchoolDAOTest.sql");
	    return retour;
	  }
}
