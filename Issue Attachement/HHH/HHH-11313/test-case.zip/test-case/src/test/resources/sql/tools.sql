drop alias TO_DATE if exists;
-- TO_DATE
create alias TO_DATE as $$
java.util.Date toDate(String s) throws Exception {
    return new java.text.SimpleDateFormat("dd-MM-yyyy").parse(s);
}
$$;