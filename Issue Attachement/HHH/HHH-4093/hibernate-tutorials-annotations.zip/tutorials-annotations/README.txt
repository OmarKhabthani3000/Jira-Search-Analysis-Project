Hibernate Example Tutorial Annotation 
--------------------------------------------------------------------------------
The project object model (pom) is defined in the file pom.xml.
The application is ready to run as a web application. The pom.xml file is
pre-defined with Hibernate as a persistence model and Spring MVC as the web framework.

This project was created for the main purpose of unit testing a Hibernate enhancement (HH-3579)
that added uuid sql types to hibernate. Specifically, for unit testing against Postgresql
which allows uuid data types. Additionally, it demonstrates how to use Hibernate with Annotations.
This tutorial implements a basic web application using Hibernate 3.5 (trunk), Spring Framework 3.0 (trunk), Spring's MVC, and Atomikos Transaction Manager 3.5.5.
This project utilizes Maven with automatically downloads its dependencies for you.
However, (IMPORTANT NOTE) that Atomikos 3.5.5 has not been posted as of this writing to the Maven Repositories, so it will need to be
downloaded manually and installed. To download Atomikos, go to http://www.atomikos.com/Main/TransactionsEssentials

--------------------------------------------------------------------------


Prerequisites:
1. Install Maven, http://maven.apache.org
 
To get started, please complete the following steps:

1. Download or utilize Eclipse Ganymede or compatible IDE that integrates with Maven (if you wish to execute Maven from an IDE)
2. Download/Install Postgresql 8.3 or higher from http://www.postgresql.org, or compatible database that implements uuid datatype and has hibernate dialect mapping for uuid datatype. If you choose to not use Postgresql, you will need to update Persistence.xml and applicationcontext.xml according to the database vendors specifications.
3. 
  a. Create an empty database named: hibernate_unittest. 
  b. Update hibernate.connection.password property in Persistence.xml and applicationcontext.xml with your database password. 
  c. Update hibernate.connection.username property in Persistence.xml and applicationcontext.xml.  
  d. Update hibernate.connection.url property in Persistence.xml and applicationcontext.xml to point to your database server. 
4. Download Atomikos (Atomikos Transactions Essentials 3.5.5) ,go to http://www.atomikos.com/Main/TransactionsEssentials. Install this third party jar (Atomikos Transaction Essentials)
via Maven. See http://maven.apache.org/guides/mini/guide-3rd-party-jars-local.html  
5. To Run Unit Tests:
    From Eclipse IDE: Right click Project choose Run As - Maven Install
	Optionally From a command line (assumes Maven installed), navigate to project directory then command line type: mvn install
    IMPORTANT NOTE: First time it is run you will see errors in ActivityTypeControllerTest, since SureFire may run the Controller tests first before running the ActivitytypeDaoTests. The ActivitytypeDaoTest will create the database table for you the first time it is run.
    This hibernate_unittest database is considered a unit testing database, so all the data is considered temporary. Each time tests are run in ActivitytypeDao the table is deleted and re-created.
6. Debugging Project from within Eclipse. You can utilize Jetty as a runtime web server to debug the project.
   See separate section below titled: Debugging with Jetty.
7. Optionally to just run the webapp from a command line: Run "mvn jetty:run-war" and view the application at http://localhost:8080.

Debug with Jetty from Eclipse
---------------------------------------------------------------------
You will need to setup an External Tools Configuration in Eclipse to enable the Jetty WebServer.
You will also need to setup a Debugging Configuration in Eclipse.
Another reference site is: http://cwiki.apache.org/WICKET/maven-jetty-plugin.html

Setting Up External Tools Configuration
Select In Eclipse Run -> External Tools -> External Tools Configuration
Select the New Launch Configuration, name it "Maven-Jetty"
In the Main tab, fill in Location box with your Maven execution location. (i.e D:\Maven\bin\mvn.bat)
In the Main tab, fill in the Working Directory of your project. ( i.e ${workspace_loc:/myproject} )
In the Main tab, fill in the Arguments box with : jetty:run-war -f pom.xml
Select the Enironment tab, click New Variable enter Name : JAVA_HOME, value: (location of your JAVA_HOME, i.e c:\SUN\sdk\jdk)
click New again, enter Name: MAVEN_OPTS,
value: -Xdebug -Xnoagent -Djava.compiler=NONE -Xrunjdwp:transport=dt_socket,address=8080,server=y,susp

Setup Debug Configuration
Select Run - Debug -> Remote Java Application. Click New Launch Configuration icon, name this: " Debug Maven Jetty".
Fill in the dialog by selecting your project: SHINDIG.
In the connection properties, set Host to: localhost, Port: 8080.
