/**
 * This class is a used address the issue mentioned in Bug: HHH-3110
 */
package org.hibernate.tutorials.annotations.transactionfix;
import javax.transaction.UserTransaction;

import org.hibernate.transaction.JTATransactionFactory;

import com.atomikos.icatch.jta.UserTransactionImp;
/**
 * @author David Driscoll
 *
 */
public class AtomikosJTATransactionFactory extends JTATransactionFactory{
	UserTransaction userTransaction;
	
	@Override
	protected UserTransaction getUserTransaction() {
		if (this.userTransaction == null) 
		{
			this.userTransaction = new UserTransactionImp();
		}
		
		return this.userTransaction;
				
	}

}

