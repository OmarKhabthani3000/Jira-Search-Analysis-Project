package org.hibernate.tutorials.annotations.dao;

import java.io.Serializable;
import java.util.Dictionary;
import java.util.List;


import org.hibernate.criterion.*;
public interface IDao <T extends Serializable, IdT >{

	T GetById(IdT id, boolean shouldLock);
	List<T> GetAll();
	List<T> GetAllOrderByCreateDate();
	List<T> GetByProperty(String property, Object value);
	List<T> GetByPropertyAndBySortOrder(String property, Object value, String orderBy, String sortDirection);
    List<T> GetByPropertiesAndBySortOrder(Dictionary<String, Object> properties, String orderBy, String sortDirection);
    List<T> GetByPropertiesAndBetweenAndSort(Dictionary<String, Object> properties, String betweenPropertyName, Object lowObject, Object hiObject, String orderBy, String sortDirection);
        
    T Save(T entity);
    T Update(T entity);
    void Delete(T entity);
    
	
}
