package org.hibernate.tutorials.annotations.dao;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.Array;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.*;
import org.hibernate.mapping.PersistentClass;

import org.hibernate.tutorials.annotations.model.*;
import org.springframework.stereotype.Repository;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

/*@TransactionConfiguration(transactionManager="jtaTransactionManager", defaultRollback=false)*/
@Transactional
@Repository
public abstract class AbstractDao<T extends Serializable, IdT > implements IDao<T, IdT> {

	
	private static final Logger log = Logger.getLogger(AbstractDao.class);
	
	
    private SessionFactory sessionFactory;
	
	protected Class<T> persistentType;
	
	public AbstractDao(){
		this.persistentType = getDomainClass();
		
	}
	
	
	@SuppressWarnings("unchecked")
	protected Class<T> getDomainClass() {
        if (persistentType == null) {
           
        	//Need to determine if superclass is class or interface
        	if(!getClass().getSuperclass().isInterface())
        	{
        		//ParameterizedType thisType = (ParameterizedType) getClass().getGenericSuperclass();
        		final Type thisType = getClass().getGenericSuperclass();
        		
        		final Type type;
        		if (thisType instanceof ParameterizedType) {
        			type = ((ParameterizedType) thisType).getActualTypeArguments()[0];
        		} else if (thisType instanceof Class) {
        			type = ((ParameterizedType) ((Class) thisType).getGenericSuperclass()).getActualTypeArguments()[0];
        		} else {
        			throw new IllegalArgumentException("Problem handling type construction for " + getClass());
        		}
        		
        		if (type instanceof Class) {
        			return (Class<T>) type;
        		} else if (type instanceof ParameterizedType) {
        			return (Class<T>) ((ParameterizedType) type).getRawType();
        		} else {
        			throw new IllegalArgumentException("Problem determining the class of the generic for " + getClass());
        		}
        		
        	}
        	else
        	{
        	  Type[] genericInterfaces = getClass().getGenericInterfaces();	
        	  for (int i = 0; i < genericInterfaces.length; i++) {
                  Type interfaceType = genericInterfaces[i]; 
                  
                  // there is no guarantee that *all* the interfaces are generic
                  if (interfaceType instanceof ParameterizedType) {
                      ParameterizedType genericInterface = (ParameterizedType) interfaceType;
                      
                      if (genericInterface.getRawType() != null) {
                          return (Class<T>) genericInterface.getActualTypeArguments()[0];
                      }
                      
                  }
                  
              }
        	  
        	}
        	           
        }
        throw new AssertionError("Unable to find generic superclass information for class '"
                + getClass() + "'");
    }
	
	
    public SessionFactory getSessionFactory()
    {
    	return sessionFactory;
    }
	public void setSessionFactory(SessionFactory sessionFactory)
	{
	  this.sessionFactory = sessionFactory;			
	}
	
	protected Session GetCurrentSession(Class<T> c)
	{
		if(this.sessionFactory == null)
		{
			log.info("sessionFactory is null");
		}
		
		Session mySession = this.sessionFactory.getCurrentSession();
		return mySession;
		
	}
	
	
	
    /// <summary>
    /// Loads an instance of type T from the DB based on its ID.
    /// </summary>
    @SuppressWarnings("unchecked")
	public T GetById(IdT id, boolean shouldLock)
    {
        T entity;       
        entity = (T) GetCurrentSession(persistentType).get(persistentType.getClass(),(Serializable) id);
        return entity;
    }

    
    
    /// <summary>
    /// Loads every instance of the requested type with no filtering.
    /// </summary>
    @SuppressWarnings(value = "unchecked")
    public List<T> GetAll()
    {
    	List<T> entities = new ArrayList<T>(); 
        try { 
          String s = "select c from " + persistentType.getSimpleName() + " as c"; 
          Session session = GetCurrentSession(persistentType);
          
          if(session!=null)
          {
        	  Query myQuery = session.createQuery(s);
        	  entities = myQuery.list();
        	  
        	  
          }
          
        } catch (Exception e) { 
          e.printStackTrace(); 
        } 
        return entities; 

    }
    
    /**
     * Retrieve objects using criteria. It is equivalent to <code>criteria.list()</code>.
     *
     * @param criteria criteria which will be executed
     * @return list of founded objects
     * @see javax.persistence.Query#getResultList()
     */
    @SuppressWarnings(value = "unchecked")
    protected final List findByCriteria(Criteria criteria)
    {
    	return criteria.list();
    }

    @SuppressWarnings("unchecked")
	public List<T> GetAllOrderBy(String orderBy)
    {
    	
    
        Order[] orders = new Order[] { Order.asc(orderBy) };
       
        List<T> genericList = GetAll(orders);

        return genericList;


    }

    /// <summary>
    /// Get All and sort by Create Date desc
    /// </summary>
    /// <returns></returns>
    public List<T> GetAllOrderByCreateDate()
    {
        Order order = Order.desc("InsertDate");
        Order [] orders = new Order[] { order };
        List<T> genericList = GetAll(orders);
        return genericList;

    }
    
    @SuppressWarnings("unchecked")
	public List<T> GetAll(Order[] orders)
    {
    	Session session = GetCurrentSession(persistentType);
    	//Criteria Query 
    	Criteria crit = session.createCriteria(persistentType.getClass());
    	
    	//loop thru for multiple criteria
       
	    for (Order o : orders)
	    {
	       crit.addOrder(o);   
	    }
       
        List<T> genericList = crit.list();

        return genericList;
    }

    /// <summary>
    /// Retrieves all records the have the passed in property value
    /// </summary>
    /// <param name="property"></param>
    /// <param name="value"></param>
    /// <returns>List</returns>
    /*@Transactional*/
    public List<T> GetByProperty(String property, Object value)
    {
    	
    	log.info("persistentType is:" + this.persistentType.getName());
    	log.info("property name is:" + property);
    	
    	boolean isSessionFactorynull;
    	if(this.getSessionFactory() == null)
    	{
    		isSessionFactorynull = true;
    	}
    	else
    	{
    		isSessionFactorynull = false;
    		
    	}
    	log.info("isSessionFactorynull equals:" + isSessionFactorynull);
    	
    	if(this.getSessionFactory()!=null)
    	{
    	  Session verifySession = GetCurrentSession(persistentType);
    	  if(verifySession == null)
    	  {
    		  log.info("Session is Null");
    	  }
    	  else
    	  {
    		  log.info("Session is NOT Null");
    		  
    		  //determine if it contains this object
    		  
    		  //determine what the connection is being used
    		  Connection conn = verifySession.connection();
    		  if(conn != null)
    		  {
    			  try{
    			  String catalog = conn.getCatalog();
    			  log.info("connection catalog is " + catalog);
    			  }
    			  catch(Exception e){
    				  log.info("connection getCatalog throw exception");
    			  }
    		  }
    		  else
    		  {
    			  log.info("connection is null");
    		  }
    		  
    		 //Determine Transaction
    		 Transaction verifyTransaction = verifySession.getTransaction();
    		 if(verifyTransaction == null)
    		 {
    			 log.info("verifyTransaction is Null");
    		 }
    		 else
    		 {
    			 log.info("verifyTransaction is not Null");
    		 }
    		  
    	  }
    	}
       
        List<T> genericList = FindAllByProperty(persistentType, property, value);

        if(genericList.size() > 0)
        {
        	log.info("GetByProperty List Size > 0");
        }
        else
        {
        	log.info("GetByProperty List Size = 0");
        }
        return genericList;

    }
    
    /*@Transactional*/
    public List<T> FindAllByProperty(Class<T> c, String property, Object value)
    {
      	Criterion criteria ;
    	if(value != null)
      	{
    		log.info("Criteria value is NOT Null");
    		criteria = Restrictions.eq(property, value);
      	}
    	else
      	{
      		log.info("Criteria value is null");
    		criteria = Restrictions.isNull(property);
      	}
      	return FindAll(c,new Criterion[]{criteria});
    }
    
    /*@Transactional*/
    public List<T> FindAllByProperty(Class<T> c, String orderBy, String property, Object value)
    {
    	Criterion criteria;
    	if(value != null)
      	{
    		criteria = Restrictions.eq(property, value);
      	}
    	else
      	{
      		criteria = Restrictions.isNull(property);
      	}
      	
      	Order[] orders = new Order[] { Order.asc(orderBy) };
      	
      	
      	return FindAll(c,orders,new Criterion[]{criteria});
    }
    
    public List<T> FindAll(Class<T> c, Criterion[] criteria)
    {
    	return FindAll(c,new Order[]{},criteria);
    }
    
    @SuppressWarnings("unchecked")
	public List<T> FindAll(Class<T> c, Order[] orders, Criterion[] criteria)
    {
    	Session session = GetCurrentSession(persistentType);
    	if(session==null)
    	{
    		log.info("FindAll session is null");
    	}
    	else
    	{
    		log.info("FindAll session is NOT null");
    	}
    	
    	if(criteria == null)
    	{
    		log.info("FindAll, criterion array is null");
    	}
    	else
    	{
    		log.info("FindAll, criterion array is not null");
    	}
    	
    	//Criteria Query 
    	Criteria crit = session.createCriteria(c);
    	if(crit == null)
    	{
    		log.info("crit is null");
    	}
    	else
    	{
    		log.info("crit is NOT null");
    	}
    	
    	for(Criterion myCriterion : criteria)
    	{
    	  	crit.add(myCriterion);
    	}
    	
    	for (Order o : orders)
	    {
	       crit.addOrder(o);   
	    }
    	
    	List<T> myGenericList = crit.list();
    	return myGenericList;
    	
    }
    
    private List<T> FindAll(Class<T> persistentType2, DetachedCriteria dt,
			Order[] orders) {   
    	
    	for(Order o : orders)
    	{
    	  dt.addOrder(o);	
    	}
    	
    	Criteria dCriteria = dt.getExecutableCriteria(GetCurrentSession(persistentType2));
    	
    	List<T> myGenericList = dCriteria.list();
    	return myGenericList;
	}

    private List<T> FindAll(Class<T> persistentType2, DetachedCriteria criterias) {
    	
    	Criteria dCriteria = criterias.getExecutableCriteria(GetCurrentSession(persistentType2));
    	
    	List<T> myGenericList = dCriteria.list();
    	
    	return myGenericList;
		
	}
    /// <summary>
    /// Get By Property and By Sort Column, sorts ascending
    /// </summary>
    /// <param name="property"></param>
    /// <param name="value"></param>
    /// <param name="orderBy"></param>
    /// <returns></returns>
    public List<T> GetByPropertyAndBySortOrder(String property, Object value, String orderBy)
    {

        List<T> genericList = FindAllByProperty(persistentType, orderBy, property, value);

        return genericList;


    }


    public List<T> GetByPropertyAndBySortOrder(String property, Object value, String orderBy, String sortDirection)
    {

        Criterion criterium = (value == null) ? Expression.isNull(property) : Expression.eq(property, value);
        
        Order order;
        if (sortDirection.toUpperCase() == "ASC")
        {
            order = Order.asc(orderBy);
        }
        else
        {
            order = Order.desc(orderBy);
        }


        Criterion[] criterias = new Criterion[] { criterium };
        Order[] orders = new Order[] { order };

        List<T> genericList = FindAll(persistentType, orders, criterias);

        return genericList;
                 

    }

    public List<T> GetByPropertiesAndBySortOrder(Dictionary<String, Object> properties, String orderBy, String sortDirection)
    {
        Order order;

        if (sortDirection.toUpperCase() == "ASC")
        {
        	order = Order.asc(orderBy);
        }
        else
        {
        	order = Order.desc(orderBy);
        }
        
      
      //Detached Criteria example
       DetachedCriteria criterias = DetachedCriteria.forClass(persistentType.getClass(),"currentType");
    
    	
        
        Enumeration<String> keys;
        String keyString;
        keys = properties.keys();
        while(keys.hasMoreElements())
        {
        	keyString = keys.nextElement();
        	Object valueObject = properties.get(keyString);
        	if((valueObject != null) && (keyString !=null))
        	{
        		Criterion criterium = Expression.eq(keyString, valueObject);
        	    criterias.add(criterium);
        	}
        }
        
        
        Order[] orders = new Order[] { order };

        List<T> genericList = FindAll(persistentType, criterias, orders );

        return genericList;


    }

    
	public List<T> GetByPropertiesAndBetweenAndSort(Dictionary<String, Object> properties, String betweenPropertyName, Object lowObject, Object hiObject, String orderBy, String sortDirection)
    {
		 Order order;
		
        if (sortDirection.toUpperCase() == "ASC")
        {
            order = Order.asc(orderBy);
        }
        else
        {
        	order = Order.desc(orderBy);
        }

        
        DetachedCriteria criterias = DetachedCriteria.forClass(persistentType.getClass(),"currentType");
        
        
        Criterion criterium = Restrictions.between(betweenPropertyName, lowObject, hiObject);
       
        criterias.add(criterium);
 
        Enumeration<String> keys;
        String keyString;
        keys = properties.keys();
        while(keys.hasMoreElements())
        {
        	keyString = keys.nextElement();
        	Object valueObject = properties.get(keyString);
        	if((valueObject != null) && (keyString !=null))
        	{
        		Criterion myCriterium = Expression.eq(keyString, valueObject);        		
        	    criterias.add(myCriterium);
        	}
        }
        
        Order[] orders = new Order[] { order };        

        List<T> genericList = FindAll(persistentType, criterias, orders);

        return genericList;


    }


    public List<T> GetBetweenAndSort(String betweenPropertyName, Object lowObject, Object hiObject, String orderBy, String sortDirection)
    {


    	Order order;
		
        if (sortDirection.toUpperCase() == "ASC")
        {
            order = Order.asc(orderBy);
        }
        else
        {
        	order = Order.desc(orderBy);
        }

        DetachedCriteria criterias = DetachedCriteria.forClass(persistentType.getClass(),"currentType");

        Criterion criterium = Restrictions.between(betweenPropertyName, lowObject, hiObject);
        criterias.add(criterium);

        Order[] orders = new Order[] { order };

        List<T> genericList = FindAll(persistentType, criterias, orders);

        return genericList;

    }

    public List<T> GetInListOfValues(String fieldname,ArrayList listofvalues)
    {
    	DetachedCriteria criterias = DetachedCriteria.forClass(persistentType.getClass(),"currentType");

        Criterion criterium = Restrictions.in(fieldname, listofvalues);

        List<T> genericList = FindAll(persistentType, new Criterion[]{criterium});

        return genericList;

    }

    public List<T> GetByPropertyAndInListOfValues(String property, Object value,String fieldname, ArrayList listofvalues)
    {
    	DetachedCriteria criterias = DetachedCriteria.forClass(persistentType.getClass(),"currentType");

        Criterion propcriterium = (value == null) ? Restrictions.isNull(property) : Restrictions.eq(property, value);

        criterias.add(propcriterium);
        
        Criterion criterium = Restrictions.in(fieldname, listofvalues);

        criterias.add(criterium);

        List<T> genericList = FindAll(persistentType, criterias);;

        return genericList;
    }
   
	public List<T> GetByExample( Object exampleInstance, String associationProperty) throws InstantiationException, IllegalAccessException 
    {
    	
		Session session = GetCurrentSession(persistentType);		
		
		//Detached Criteria example
    	Object baseExampleInstance = persistentType.newInstance();
    	
    	
		Example exampleBase = Example.create(baseExampleInstance)
		.ignoreCase()
		.enableLike(MatchMode.ANYWHERE);     
      
		 Example exampleFilter = Example.create(exampleInstance)
			.ignoreCase()
			.enableLike(MatchMode.ANYWHERE);        

		 DetachedCriteria dt = DetachedCriteria.forClass(baseExampleInstance.getClass())
 		.add(exampleBase).createCriteria(associationProperty)
 		.add(exampleFilter);

        Criteria criteria = dt.getExecutableCriteria(session);
        
        
        List<?> theList = criteria.list();
        log.info("GetByExample Successful");
		log.info("GetByExample theList.size = " + theList.size());
        return criteria.list();
        
    }

    /// <summary>
    /// Looks for a single instance using the example provided.
    /// </summary>
    /// <exception cref="NonUniqueResultException" />
    public T GetUniqueByExample(Object exampleInstance, String associationProperty) throws Exception
    {
        List<T> foundList = GetByExample(exampleInstance, associationProperty);

        if (foundList.size() > 0)
        {
            throw new Exception("GetUniqueByExample larger than one, size:"+Integer.toString(foundList.size()));
        }

        if (foundList.size() > 0)
        {
            return foundList.get(0);
        }
        else
        {
            return null;
        }
    }

    /// <summary>
    /// For entities that have assigned ID's, you must explicitly call Save to add a new one.
    /// See http://www.hibernate.org/hib_docs/reference/en/html/mapping.html#mapping-declaration-id-assigned.
    /// </summary>
    public T Save(T entity)
    {
        //getHibernateTemplate().persist(entity);
    	GetCurrentSession(persistentType).persist(entity);
    	return entity;
    }

    /// <summary>
    /// For entities with automatatically generated IDs, such as identity, SaveOrUpdate may 
    /// be called when saving a new entity.  SaveOrUpdate can also be called to update any 
    /// entity, even if its ID is assigned.
    /// </summary>
    public T Update(T entity)
    {
    	GetCurrentSession(persistentType).update(entity);
    	return entity;
    }

    public void Delete(T entity)
    {
    	
    	GetCurrentSession(persistentType).delete(entity);
    	
    }

    

    

   
}

