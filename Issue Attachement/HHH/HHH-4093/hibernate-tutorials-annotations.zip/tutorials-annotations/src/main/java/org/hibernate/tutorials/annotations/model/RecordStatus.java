/**
 * 
 */
package org.hibernate.tutorials.annotations.model;

/**
 * @author David
 *
 */
public enum RecordStatus { 
	INACTIVE (0),
	ACTIVE (1);
	
	private final int statusInteger;
	
	RecordStatus(int statusInteger){
		this.statusInteger = statusInteger;
	}
	
	public int statusInteger() {return statusInteger;}
	

}
