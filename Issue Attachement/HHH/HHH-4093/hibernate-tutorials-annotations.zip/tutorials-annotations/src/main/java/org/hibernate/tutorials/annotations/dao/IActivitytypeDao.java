package org.hibernate.tutorials.annotations.dao;
import org.hibernate.tutorials.annotations.model.*;

public interface IActivitytypeDao extends IDao<Activitytype, String> {

}
