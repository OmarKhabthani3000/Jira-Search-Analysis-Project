/**
 * 
 */
package org.hibernate.tutorials.annotations.server.web.controllers;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.springframework.stereotype.Controller;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.beans.factory.annotation.*;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import org.hibernate.tutorials.annotations.model.*;
import org.hibernate.tutorials.annotations.dao.*;





/**
 * @author David Driscoll
 *
 */
@Controller
@TransactionConfiguration(transactionManager="jtaTransactionManager", defaultRollback=false)
@Transactional
@SessionAttributes("activitytype")
public class ActivityTypeController {
	
	ActivitytypeDao activitytypeDao;
	
	
	@InitBinder
	public void initBinder(WebDataBinder binder){
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		dateFormat.setLenient(false);
        binder.registerCustomEditor(Date.class, new CustomDateEditor(
                dateFormat, true));
        
       
		
	}
	
	public ActivityTypeController(){		
	}
	
	
	@ModelAttribute("activitytype")
	public Activitytype formBackingObject(String id)
	{
	  if(id != null){
		  //return activitytypeDao.GetById(id, false);
		  UUID uniqueId = UUID.fromString(id);
		  List<Activitytype> activityTypes = activitytypeDao.GetByProperty("activitytypeid", uniqueId);
		  return activityTypes.get(0);
		  
	  }
	  else{
		  return new Activitytype();
	  }
	
	}
	@Autowired
	public ActivityTypeController(ActivitytypeDao activitytypeDao){
			
		this.activitytypeDao = activitytypeDao;
		
	}
	
	@RequestMapping("/activityType/list.html")
	public ModelAndView list()
	{
		List<Activitytype> activityTypes;
		
		if(activitytypeDao != null)
		{
			
			Integer recordstatus = 1;
			activityTypes = activitytypeDao.GetByProperty("recordstatus", recordstatus);
		}
		else
		{
			activityTypes = null;	
		}
		
		return new ModelAndView("list","activityTypes",activityTypes);
		
	}
	
	@RequestMapping("/activityType/new.html")
	public ModelAndView newActivityType()
	{
		Activitytype activityType = new Activitytype();
		ModelMap model = new ModelMap();
		model.addAttribute("activitytype",activityType);
		return new ModelAndView("new",model);
				
	}
	
	@RequestMapping("/activityType/create.html")
	public ModelAndView create(@ModelAttribute("activitytype") Activitytype activitytype)
	{
		
		
		activitytype.setInsertby("admin");
		activitytype.setUpdateby("admin");
		
		Calendar cal = Calendar.getInstance();
    	SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
 	    java.util.Date currentDate = cal.getInstance().getTime();
 	    String insertDate=dateFormat.format(currentDate);
 	    
 	   activitytype.setInsertdate(currentDate);
 	   activitytype.setUpdatedate(currentDate);
 	   activitytype.setRecordstatus(RecordStatus.ACTIVE.statusInteger());
		
		activitytypeDao.Save(activitytype);
		
        List<Activitytype> activityTypes;
		
		if(activitytypeDao != null)
		{
			
			Integer recordstatus = 1;
			activityTypes = activitytypeDao.GetByProperty("recordstatus", recordstatus);
		}
		else
		{
			activityTypes = null;	
		}
		
		return new ModelAndView("list","activityTypes",activityTypes);
		
	}
	
	@RequestMapping("/activityType/edit.html")
	public ModelAndView edit(@RequestParam String id)
	{
		UUID uniqueId = UUID.fromString(id);
		//Activitytype activityType = activitytypeDao.GetById(uniqueIdentifier, false);
		List<Activitytype> activityTypes = activitytypeDao.GetByProperty("activitytypeid", uniqueId);
		return new ModelAndView("edit","activitytype",activityTypes.get(0));
	}
	
	@RequestMapping("/activityType/update.html")
	public ModelAndView update(@ModelAttribute("activitytype") Activitytype activitytype)
	{
        
		activitytype.setInsertby("admin");
		activitytype.setUpdateby("admin");
		
		Calendar cal = Calendar.getInstance();
    	SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
 	    java.util.Date currentDate = cal.getInstance().getTime();
 	    String insertDate=dateFormat.format(currentDate);
 	    
 	    activitytype.setInsertdate(currentDate);
 	    activitytype.setUpdatedate(currentDate);
 	    
 	   activitytype.setRecordstatus(RecordStatus.ACTIVE.statusInteger());
		
		//activitytypeDao.Save(activitytype);
		activitytypeDao.Update(activitytype);
		
		
		List<Activitytype> activityTypes;
		
		if(activitytypeDao != null)
		{
			
			Integer recordstatus = 1;
			activityTypes = activitytypeDao.GetByProperty("recordstatus", recordstatus);
		}
		else
		{
			activityTypes = null;	
		}
		
		return new ModelAndView("list","activityTypes",activityTypes);
		
	}

}
