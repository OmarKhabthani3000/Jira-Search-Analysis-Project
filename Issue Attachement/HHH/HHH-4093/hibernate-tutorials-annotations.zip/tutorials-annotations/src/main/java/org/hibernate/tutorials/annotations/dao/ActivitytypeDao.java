package org.hibernate.tutorials.annotations.dao;
import org.springframework.stereotype.Repository;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import org.springframework.test.context.transaction.TransactionConfiguration;

import org.hibernate.tutorials.annotations.model.*;

@TransactionConfiguration(transactionManager="jtaTransactionManager", defaultRollback=false)
@Transactional
@Repository
public class ActivitytypeDao extends AbstractDao<Activitytype,String> implements IActivitytypeDao {

}
