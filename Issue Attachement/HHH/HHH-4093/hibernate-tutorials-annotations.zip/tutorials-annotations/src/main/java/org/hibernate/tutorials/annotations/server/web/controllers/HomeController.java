package org.hibernate.tutorials.annotations.server.web.controllers;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
//import org.springframework.security.AuthenticationException;
//import org.springframework.security.ui.AbstractProcessingFilter;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.*;
import org.springframework.web.bind.annotation.*;

import org.hibernate.tutorials.annotations.model.*;
import org.hibernate.tutorials.annotations.dao.*;

@Controller
public class HomeController {
	
	private static final Logger log = Logger
    .getLogger(HomeController.class);
	
	@RequestMapping("/homeIndex.html")
	public String homeIndexHandler()
	{
		return "homeIndex";
		
	}
	
	@RequestMapping("/error.html")
	public String errorHandler()
	{
		return "error";
		
	}
	
	

}
