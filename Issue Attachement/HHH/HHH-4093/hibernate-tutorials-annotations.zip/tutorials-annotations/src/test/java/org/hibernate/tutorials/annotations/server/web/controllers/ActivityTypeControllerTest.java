/**
 * 
 */
package org.hibernate.tutorials.annotations.server.web.controllers;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.tutorials.annotations.dao.ActivitytypeDao;
import org.hibernate.tutorials.annotations.model.Activitytype;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.web.ModelAndViewAssert;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author David Driscoll
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml","/jndi.xml" })
@TransactionConfiguration(transactionManager="jtaTransactionManager", defaultRollback=false)
@Transactional
public class ActivityTypeControllerTest {
	
	@Autowired
	ActivitytypeDao activitytypeDao;
	
	private static final Logger log = Logger.getLogger(ActivityTypeControllerTest.class);	
	ActivityTypeController activityTypeController;
	
	@Before
	public void init() throws Exception {
		
		activityTypeController = new ActivityTypeController(		
				activitytypeDao);
		
	}
	
	@Test
	public void testNewView() {
		
		if(activityTypeController != null)
		{
			if(activitytypeDao != null)
			{
				ModelAndView modelAndView = activityTypeController.newActivityType();
				ModelAndViewAssert.assertViewName(modelAndView, "new");
			}
			
		}
	}
	
	@Test
	public void testCreateView() {
		
		if(activityTypeController != null)
		{
			if(activitytypeDao != null)
			{
				Activitytype activitytype = new Activitytype();
				activitytype.setActivitytypename("TV");
				activitytype.setActivitytypedescription("Watch TV");
				activitytype.setInsertby("admin");
				activitytype.setUpdateby("admin");
				Calendar cal = Calendar.getInstance();
		    	SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		 	    java.util.Date currentDate = cal.getInstance().getTime();
		 	    String insertDate=dateFormat.format(currentDate);
		 	    
				activitytype.setInsertdate(currentDate);
				activitytype.setUpdatedate(currentDate);
				
				ModelAndView modelAndView = activityTypeController.create(activitytype);
				ModelAndViewAssert.assertViewName(modelAndView, "list");
			}
			
		}
	}
	
	@Test
	public void testEditView() {
		
		if(activityTypeController != null)
		{
			if(activitytypeDao != null)
			{				
				List<Activitytype> activityTypes = activitytypeDao.GetAll();
				if(activityTypes.size()>0) {
				Activitytype activityType = activityTypes.get(0);
				ModelAndView modelAndView = activityTypeController.edit(activityType.getActivitytypeid().toString());
				ModelAndViewAssert.assertViewName(modelAndView, "edit");
				}
			}
			
		}
	}
	
	@Test
	public void testUpdateView() {
		
		if(activityTypeController != null)
		{
			if(activitytypeDao != null)
			{
				//Create a Activity Type
				Activitytype activitytype = new Activitytype();
				activitytype.setActivitytypename("Movie");
				activitytype.setActivitytypedescription("Watch a Movie");
				activitytype.setInsertby("admin");
				activitytype.setUpdateby("admin");
				Calendar cal = Calendar.getInstance();
		    	SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		 	    java.util.Date currentDate = cal.getInstance().getTime();
		 	    String insertDate=dateFormat.format(currentDate);
		 	    
				activitytype.setInsertdate(currentDate);
				activitytype.setUpdatedate(currentDate);
				activitytypeDao.Save(activitytype);
				
				//Call Update Controller to update it
				
				ModelAndView modelAndView = activityTypeController.update(activitytype);
				ModelAndViewAssert.assertViewName(modelAndView, "list");
			}
			
		}
	}
}
