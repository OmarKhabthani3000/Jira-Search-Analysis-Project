/**
 * 
 */
package org.hibernate.tutorials.annotations.dao;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;

import junit.framework.Assert;


import org.hibernate.tutorials.annotations.dao.ActivitytypeDao;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import org.springframework.test.context.ContextConfiguration;

import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import org.hibernate.tutorials.annotations.model.*;

/**
 * @author David
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml","/jndi.xml" })
@TransactionConfiguration(transactionManager="jtaTransactionManager", defaultRollback=false)
@Transactional
public class ActivitytypeDaoTest {
	
	private static final Logger log = Logger.getLogger(ActivitytypeDaoTest.class);
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private ActivitytypeDao activitytypeDao;
	
	@Resource
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Before
	public void deleteTable() {
			jdbcTemplate.execute("drop table if exists activitytype");
			jdbcTemplate.execute("CREATE TABLE activitytype (activitytypeid uuid NOT NULL,  activitytypename text,  activitytypedescription text, updateby character varying(50),  insertby character varying(50), insertdate timestamp with time zone, updatedate timestamp with time zone, recordstatus integer, CONSTRAINT pk_activitytype PRIMARY KEY (activitytypeid)) WITH (OIDS=FALSE);");
	}
	
	@Test
	public void testGetActivitytype()
	{
        //insert a record
		Activitytype activitytype = new Activitytype();
		
		activitytype.setActivitytypedescription("TV");
		activitytype.setActivitytypename("Watch TV");
		activitytype.setInsertby("david");
		activitytype.setUpdateby("david");
							
		Calendar cal = Calendar.getInstance();
    	SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
 	    java.util.Date currentDate = cal.getInstance().getTime();
 	    activitytype.setInsertdate(currentDate);
 	    activitytype.setUpdatedate(currentDate);
 	    activitytype.setRecordstatus(1);
 	    activitytypeDao.Save(activitytype);
		
		//Retrieve a Record
		List<Activitytype> activityTypes;
		Integer recordstatus = 1;
		activityTypes = activitytypeDao.GetByProperty("recordstatus", recordstatus);
		boolean sizeGreaterThanZero = false;
		if(activityTypes.size() > 0)
		{
			sizeGreaterThanZero = true;
			Assert.assertEquals(true, sizeGreaterThanZero);
		}
		else
		{
			Assert.assertEquals(true, sizeGreaterThanZero);
		}
		
	}
	
	@Test
	public void testInsertActivitytype(){
		
		Activitytype activitytype = new Activitytype();
		
		activitytype.setActivitytypedescription("test Activity");
		activitytype.setActivitytypename("testActivity");
		activitytype.setInsertby("david");
		activitytype.setUpdateby("david");
							
		Calendar cal = Calendar.getInstance();
    	SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
 	    java.util.Date currentDate = cal.getInstance().getTime();
 	    activitytype.setInsertdate(currentDate);
 	    activitytype.setUpdatedate(currentDate);
 	    activitytype.setRecordstatus(1);
 	    activitytypeDao.Save(activitytype);
 	    
 	    
		
	}
	

}
