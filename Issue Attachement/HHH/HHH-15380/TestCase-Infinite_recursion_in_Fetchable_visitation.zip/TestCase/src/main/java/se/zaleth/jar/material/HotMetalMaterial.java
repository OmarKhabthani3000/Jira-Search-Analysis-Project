/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.material;

import se.zaleth.jar.plant.BlastFurnace;

/**
 *
 * @author krister
 */
public class HotMetalMaterial extends RawMaterial {
    
    private BlastFurnace furnace;
    private CarbonSourceMaterial coke;
    private CarbonSourceMaterial injectionOne;
    private AbstractMaterial injectionTwo;
    private ProcessGasMaterial blastSource;
    private ProcessGasMaterial oxygenSource;
    private ElectricityMaterial electricitySource;
    private MediaMaterial waterSource;
    
    public BlastFurnace getFurnace() {
        return furnace;
    }

    public void setFurnace(BlastFurnace furnace) {
        this.furnace = furnace;
    }

    public int getHeatBalanceMode() {
        return 0;
    }

    public void setHeatBalanceMode(int mode) {
        
    }
    
    public CarbonSourceMaterial getCoke() {
        return coke;
    }

    public void setCoke(CarbonSourceMaterial coke) {
        this.coke = coke;
    }

    public CarbonSourceMaterial getInjectionOne() {
        return injectionOne;
    }

    public void setInjectionOne(CarbonSourceMaterial injectionOne) {
        this.injectionOne = injectionOne;
    }

    public AbstractMaterial getInjectionTwo() {
        return injectionTwo;
    }

    public void setInjectionTwo(AbstractMaterial injectionTwo) {
        this.injectionTwo = injectionTwo;
    }

    public ProcessGasMaterial getBlastSource() {
        return blastSource;
    }

    public void setBlastSource(ProcessGasMaterial blastSource) {
        this.blastSource = blastSource;
    }

    public ProcessGasMaterial getOxygenSource() {
        return oxygenSource;
    }

    public void setOxygenSource(ProcessGasMaterial oxygenSource) {
        this.oxygenSource = oxygenSource;
    }

    public ElectricityMaterial getElectricitySource() {
        return electricitySource;
    }

    public void setElectricitySource(ElectricityMaterial electricitySource) {
        this.electricitySource = electricitySource;
    }

    public MediaMaterial getWaterSource() {
        return waterSource;
    }

    public void setWaterSource(MediaMaterial waterSource) {
        this.waterSource = waterSource;
    }

}
