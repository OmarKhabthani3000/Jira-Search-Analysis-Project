/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

import se.zaleth.jar.material.AbstractMaterial;
import se.zaleth.jar.material.CarbonSourceMaterial;
import se.zaleth.jar.material.MediaMaterial;
import se.zaleth.jar.material.ProcessGasMaterial;

/**
 *
 * @author krister
 */
public class ProductionUnit {
    
    private long id;
    private CarbonSourceMaterial electrodeMaterial;
    private MediaMaterial waterSource;
    private CarbonSourceMaterial electrodeMaterialSecondary;
    private ProcessGasMaterial secondaryGasMaterial;
    private AbstractMaterial electricitySecondary;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public AbstractMaterial getElectricitySecondary() {
        return electricitySecondary;
    }

    public void setElectricitySecondary(AbstractMaterial electricitySecondary) {
        this.electricitySecondary = electricitySecondary;
    }

    public CarbonSourceMaterial getElectrodeMaterial() {
        return electrodeMaterial;
    }

    public void setElectrodeMaterial(CarbonSourceMaterial electrodeMaterial) {
        this.electrodeMaterial = electrodeMaterial;
    }

    public MediaMaterial getWaterSource() {
        return waterSource;
    }

    public void setWaterSource(MediaMaterial waterSource) {
        this.waterSource = waterSource;
    }

    public CarbonSourceMaterial getElectrodeMaterialSecondary() {
        return electrodeMaterialSecondary;
    }

    public void setElectrodeMaterialSecondary(CarbonSourceMaterial electrodeMaterialSecondary) {
        this.electrodeMaterialSecondary = electrodeMaterialSecondary;
    }

    public ProcessGasMaterial getSecondaryGasMaterial() {
        return secondaryGasMaterial;
    }

    public void setSecondaryGasMaterial(ProcessGasMaterial secondaryGasMaterial) {
        this.secondaryGasMaterial = secondaryGasMaterial;
    }
    
}
