/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.zaleth.jar.plant;

import se.zaleth.jar.material.AbstractMaterial;
import se.zaleth.jar.material.CarbonSourceMaterial;
import se.zaleth.jar.material.ElectricityMaterial;
import se.zaleth.jar.material.ProcessGasMaterial;

/**
 *
 * @author krister
 */
public class BlastFurnace extends ProductionUnit {
    
    private CarbonSourceMaterial coke;
    private CarbonSourceMaterial injectionOne;
    private AbstractMaterial injectionTwo;
    private ProcessGasMaterial blastSource;
    private ProcessGasMaterial oxygenSource;
    private ElectricityMaterial electricitySource;

    public CarbonSourceMaterial getCoke() {
        return coke;
    }

    public void setCoke(CarbonSourceMaterial coke) {
        this.coke = coke;
    }

    public CarbonSourceMaterial getInjectionOne() {
        return injectionOne;
    }

    public void setInjectionOne(CarbonSourceMaterial injectionOne) {
        this.injectionOne = injectionOne;
    }

    public AbstractMaterial getInjectionTwo() {
        return injectionTwo;
    }

    public void setInjectionTwo(AbstractMaterial injectionTwo) {
        this.injectionTwo = injectionTwo;
    }

    public ProcessGasMaterial getBlastSource() {
        return blastSource;
    }

    public void setBlastSource(ProcessGasMaterial blastSource) {
        this.blastSource = blastSource;
    }

    public ProcessGasMaterial getOxygenSource() {
        return oxygenSource;
    }

    public void setOxygenSource(ProcessGasMaterial oxygenSource) {
        this.oxygenSource = oxygenSource;
    }

    public ElectricityMaterial getElectricitySource() {
        return electricitySource;
    }

    public void setElectricitySource(ElectricityMaterial electricitySource) {
        this.electricitySource = electricitySource;
    }

}
