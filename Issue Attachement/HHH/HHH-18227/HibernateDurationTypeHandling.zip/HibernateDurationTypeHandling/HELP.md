## Highlight what I believe is an Hibernate issue with the AttributeConverter during batch update operations.

The project define a very simple Hibernate model

* A DurationModel entity with an id and a duration field
* A DurationConverter to convert the Duration field to a Long value to store the duration milliseconds in the database

And a unit test for highlighting the current behavior of Hibernate and the workaround I found:
com.hibernateduration.demo.HibernateDurationUpdateTest

The project was written with JDK 17

