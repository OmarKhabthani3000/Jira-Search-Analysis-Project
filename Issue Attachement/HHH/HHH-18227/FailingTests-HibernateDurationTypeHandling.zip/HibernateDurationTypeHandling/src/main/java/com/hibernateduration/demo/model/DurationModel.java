package com.hibernateduration.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import java.time.Duration;

@Entity
public class DurationModel {

    @Id
    private Long id;

    private Duration duration;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Duration getDuration() {
        return duration;
    }

    public void setDuration(Duration duration) {
        this.duration = duration;
    }
}
