package com.hibernateduration.demo.HibernateDurationTypeHandling;

import com.hibernateduration.demo.model.DurationConverter;
import com.hibernateduration.demo.model.DurationModel;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ContextConfiguration;

import java.time.Duration;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@ContextConfiguration(classes = HibernateDurationUpdateTest.Configuration.class)
class HibernateDurationUpdateTest {


    @EnableAutoConfiguration
    @EntityScan(basePackageClasses = DurationModel.class)
    static class Configuration {}

    @Autowired
    EntityManager entityManager;

    @Test
    @DisplayName("""
                    Highlight the fact that the converter is called by entityManager when persisting or reading.
                    But during batch update operations it's called only for the where clause.
                """)
    void testConverterIsNotCalledForSetButIsCalledForWhere() {
        var seconds10 = Duration.ofSeconds(10);
        var seconds15 = Duration.ofSeconds(15);
        var seconds20 = Duration.ofSeconds(20);

        // ==> Insert some data for testing the update
        var e1 = createDurationEntity(1L, seconds10);
        var e2 = createDurationEntity(2L, seconds10);
        var e3 = createDurationEntity(3L, seconds15);

        entityManager.persist(e1);
        entityManager.persist(e2);
        entityManager.persist(e3);

        // ==> Update the durations of some entities
        // update duration_model set duration = 20000 where duration = 10000;
        var cb = entityManager.getCriteriaBuilder();
        var updateQuery = cb.createCriteriaUpdate(DurationModel.class);
        var root = updateQuery.from(DurationModel.class);
        updateQuery
                // Here the converter is not called (@see org.hibernate.query.sqm.internal.SqmCriteriaNodeBuilder.value(T))
                // So the value updated in the database will be in nanoseconds, but will be read as milliseconds in select queries
                .set(root.get("duration"), seconds20)
                // Here the converter is called so the where clause will be consistent with the inserted values
                .where(cb.equal(root.get("duration"), seconds10));
        var rowUpdated = entityManager.createQuery(updateQuery).executeUpdate();
        assertThat(rowUpdated).isEqualTo(2);

        entityManager.flush();
        entityManager.clear();

        // ==> Load from the database and verify what are the duration values
        // ->  I expect the following assertions to ba valid
        assertDurationFromEntity(1L, seconds20);
        assertDurationFromEntity(2L, seconds20);
        assertDurationFromEntity(3L, seconds15);
        // ->  But instead I have to do the following ones
//        assertDurationFromEntity(1L, Duration.ofSeconds(20 * 1_000_000) /* should be seconds20 */);
//        assertDurationFromEntity(2L, Duration.ofSeconds(20 * 1_000_000) /* should be seconds20 */);
//        assertDurationFromEntity(3L, seconds15);
    }

    @Test
    @DisplayName("The workaround I found")
    void testWorkaround() {
        var seconds10 = Duration.ofSeconds(10);
        var seconds15 = Duration.ofSeconds(15);
        var seconds20 = Duration.ofSeconds(20);

        // ==> Insert some data for testing the update
        var e1 = createDurationEntity(1L, seconds10);
        var e2 = createDurationEntity(2L, seconds10);
        var e3 = createDurationEntity(3L, seconds15);

        entityManager.persist(e1);
        entityManager.persist(e2);
        entityManager.persist(e3);

        // ==> Update the durations of some entities
        // update duration_model set duration = 20000 where duration = 10000;
        var cb = entityManager.getCriteriaBuilder();
        var updateQuery = cb.createCriteriaUpdate(DurationModel.class);
        var root = updateQuery.from(DurationModel.class);

        var converter = new DurationConverter();
        updateQuery
                // I have to call the converter myself before setting the value
                .set("duration", cb.literal(converter.convertToDatabaseColumn(seconds20)))
                // Here the converter is called so the where clause will be consistent with the inserted values
                .where(cb.equal(root.get("duration"), seconds10));
        var rowUpdated = entityManager.createQuery(updateQuery).executeUpdate();
        assertThat(rowUpdated).isEqualTo(2);

        entityManager.flush();
        entityManager.clear();

        // ==> Load from the database and verify what are the duration values
        // ->  This time the expectation looks better
        assertDurationFromEntity(1L, seconds20);
        assertDurationFromEntity(2L, seconds20);
        assertDurationFromEntity(3L, seconds15);
    }

    private void assertDurationFromEntity(long primaryKey, Duration seconds20) {
        var loadedEntity = entityManager.find(DurationModel.class, primaryKey);
        assertThat(loadedEntity)
                .isNotNull()
                .extracting(DurationModel::getDuration)
                .isEqualTo(seconds20);
    }

    private static DurationModel createDurationEntity(long id, Duration duration) {
        var e1 = new DurationModel();
        e1.setId(id);
        e1.setDuration(duration);
        return e1;
    }
}
