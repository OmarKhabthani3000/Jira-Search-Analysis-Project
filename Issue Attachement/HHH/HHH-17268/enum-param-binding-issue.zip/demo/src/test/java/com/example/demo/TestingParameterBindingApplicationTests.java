package com.example.demo;

import jakarta.persistence.EntityManager;
import org.assertj.core.api.ThrowableAssert.ThrowingCallable;
import org.hibernate.Session;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.assertj.core.api.Assertions.*;

@SpringBootTest
class TestingParameterBindingApplicationTests {

	@Nested
	@Transactional
	class UsingHibernate {

		@Autowired
		private EntityManager em;
		private Session session;

		@BeforeEach
		void setUp() {
			session = em.unwrap(Session.class);
		}

		@Test
		void updateEnum_UseSingleParamToUpdateBothFields_Exception() {
			MyEntity entity = MyEntity.builder().enumField1(MyEnum.FIRST).enumField2(MyEnum.SECOND).build();
			session.persist(entity);

			ThrowingCallable methodUnderTest = () -> session.createMutationQuery("""
					UPDATE MyEntity me
					SET
						me.enumField1 = :myEnum,
						me.enumField2 = :myEnum
					""")
				.setParameter("myEnum", MyEnum.THIRD)
				.executeUpdate();

			assertThatNoException().isThrownBy(methodUnderTest);
		}

		@Test
		void updateEnum_UseSeparateParamsToUpdateFields_Works() {
			MyEntity entity = MyEntity.builder().enumField1(MyEnum.FIRST).enumField2(MyEnum.SECOND).build();
			session.persist(entity);

			session.createMutationQuery("""
					UPDATE MyEntity me
					SET
						me.enumField1 = :myEnum1,
						me.enumField2 = :myEnum2
					""")
				.setParameter("myEnum1", MyEnum.THIRD)
				.setParameter("myEnum2", MyEnum.THIRD)
				.executeUpdate();

			session.flush();
			session.clear();

			List<MyEntity> allEntities = session.createQuery("SELECT me FROM MyEntity me", MyEntity.class).list();
			assertThat(allEntities).singleElement()
				.returns(MyEnum.THIRD, from(MyEntity::getEnumField1))
				.returns(MyEnum.THIRD, from(MyEntity::getEnumField2));

		}

		@Test
		void updateStrings_UseSingleParamToUpdateBothFields_Works() {
			MyEntity entity = MyEntity.builder().textField1("first").textField2("second").build();
			session.persist(entity);

			session.createMutationQuery("""
					UPDATE MyEntity me
					SET
						me.textField1 = :text,
						me.textField2 = :text
					""")
				.setParameter("text", "updated")
				.executeUpdate();

			session.flush();
			session.clear();

			List<MyEntity> allEntities = session.createQuery("SELECT me FROM MyEntity me", MyEntity.class).list();
			assertThat(allEntities).singleElement()
				.returns("updated", from(MyEntity::getTextField1))
				.returns("updated", from(MyEntity::getTextField2));
		}

	}

	@Nested
	class UsingSpringDataJpa {

		@Autowired
		private MyRepository repository;

		@AfterEach
		void tearDown() {
			repository.deleteAll();
		}

		@Test
		void updateEnum_UseSingleParamToUpdateBothFields_Exception() {
			MyEntity entity = MyEntity.builder().enumField1(MyEnum.FIRST).enumField2(MyEnum.SECOND).build();
			repository.save(entity);

			ThrowingCallable methodUnderTest = () -> repository.updateEnum(MyEnum.THIRD);

			assertThatNoException().isThrownBy(methodUnderTest);
		}

		@Test
		void updateEnum_UseSeparateParamsToUpdateFields_Works() {
			MyEntity entity = MyEntity.builder().enumField1(MyEnum.FIRST).enumField2(MyEnum.SECOND).build();
			repository.save(entity);

			repository.updateEnum(MyEnum.THIRD, MyEnum.THIRD);

			assertThat(repository.findAll()).singleElement()
				.returns(MyEnum.THIRD, from(MyEntity::getEnumField1))
				.returns(MyEnum.THIRD, from(MyEntity::getEnumField2));

		}

		@Test
		void updateStrings_UseSingleParamToUpdateBothFields_Works() {
			MyEntity entity = MyEntity.builder().textField1("first").textField2("second").build();
			repository.save(entity);

			repository.updateText("updated");

			assertThat(repository.findAll()).singleElement()
				.returns("updated", from(MyEntity::getTextField1))
				.returns("updated", from(MyEntity::getTextField2));
		}

	}
}

