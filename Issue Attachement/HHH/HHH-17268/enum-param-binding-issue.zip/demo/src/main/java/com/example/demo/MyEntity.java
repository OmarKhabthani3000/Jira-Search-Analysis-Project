package com.example.demo;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UuidGenerator;

import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class MyEntity {

	@Id
	@UuidGenerator
	private UUID id;

	@Enumerated
	private MyEnum enumField2;
	@Enumerated
	private MyEnum enumField1;

	private String textField1;
	private String textField2;

}
