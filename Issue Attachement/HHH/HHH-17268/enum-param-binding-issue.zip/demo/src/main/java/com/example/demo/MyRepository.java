package com.example.demo;

import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.*;

import java.util.UUID;

public interface MyRepository extends JpaRepository<MyEntity, UUID> {
	@Modifying
	@Transactional
	@Query("""
		UPDATE MyEntity me
		SET
			me.enumField1 = :myEnum,
			me.enumField2 = :myEnum
		""")
	void updateEnum(MyEnum myEnum);

	@Modifying
	@Transactional
	@Query("""
		UPDATE MyEntity me
		SET
			me.enumField1 = :myEnum1,
			me.enumField2 = :myEnum2
		""")
	void updateEnum(MyEnum myEnum1, MyEnum myEnum2);

	@Modifying
	@Transactional
	@Query("""
		UPDATE MyEntity me
		SET
			me.textField1 = :text,
			me.textField2 = :text
		""")
	void updateText(String text);
}
