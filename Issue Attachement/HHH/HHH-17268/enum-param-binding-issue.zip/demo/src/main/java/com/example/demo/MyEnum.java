package com.example.demo;

public enum MyEnum {
	FIRST,
	SECOND,
	THIRD;
}
