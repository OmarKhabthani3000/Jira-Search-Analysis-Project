package com.example.demo;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequestMapping("/test")
@RestController
@CrossOrigin
@AllArgsConstructor
class TestController {
    private final ParentEntityRepository repository;

    @PostMapping
    public void createParentEntity() {
        ParentEntity parentEntity = new ParentEntity(
                new ChildEntityWrapper(List.of(new ChildEntity()))
        );
        repository.save(parentEntity);
    }

    @DeleteMapping
    public void deleteParentEntity() {
        repository.deleteById(1);
    }
}
