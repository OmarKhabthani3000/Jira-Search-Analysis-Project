package com.example.demo;

import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "parent_entity")
@NoArgsConstructor
@Getter
class ParentEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Embedded
    private ChildEntityWrapper childEntityWrapper = new ChildEntityWrapper();

    ParentEntity(ChildEntityWrapper childEntityWrapper) {
        this.childEntityWrapper = childEntityWrapper;
    }
}
