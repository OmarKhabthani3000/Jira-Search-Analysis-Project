package hibernateBugProof;

import javax.persistence.*;

/**
 * @author Scott Albertine
 */
@Access(AccessType.FIELD)
@MappedSuperclass
public abstract class GenericEntity implements GenericEntityIf, Cloneable{
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;

    protected GenericEntity() {
    }

    protected GenericEntity(GenericEntity genericEntity) {
        // we do not want to copy its id; hiberate will not like that.
    }

    public Long getId() {
        return this.id;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        GenericEntity genericEntity = (GenericEntity) super.clone();
        genericEntity.id = null;
        return genericEntity;
    }

    @Override
    public String toString() {
        return this.getClass() + ": id=" + this.getId();
    }

    @Transient
    public Class<? extends GenericEntity> getUnderlyingClass() {
        return this.getClass();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof GenericEntityIf)) {
            return false;
        }

        GenericEntityIf keyed = (GenericEntityIf) o;
        if (!this.getUnderlyingClass().isAssignableFrom(keyed.getUnderlyingClass())) {
            return false;
        }
        if (this.getId() == null && keyed.getId() == null) {
            return false;
        }
        if (this.getId() != null ? !this.getId().equals(keyed.getId()) : keyed.getId() != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return this.getId() != null ? this.getId().hashCode() : 0;
    }

}
