package hibernateBugProof;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.Test;

import java.util.*;

/**
 * @author Scott Albertine
 */

@ContextConfiguration(locations = {
        "/spring/datasource.xml",
        "/spring/applicationcontext-persistence.xml"
})
@Test(groups="integration.proof")
public class HibernateBugTest extends AbstractTransactionalTestNGSpringContextTests {

    @Qualifier("sessionFactory")
    @Autowired
    private SessionFactory sf;

    @Test
    public void showHibernateLackOfBugWithFlush(){
        Session currentSession = createHibernateSession();
        proveBug(currentSession, true);
    }

    @Test
    public void showHibernateLackOfBugWithoutFlush(){
        Session currentSession = createHibernateSession();
        proveBug(currentSession, false);
    }

    @Test
    public void showFlushSolvesBugButPoorly(){
        proveBug(sf.getCurrentSession(), true);
    }

    //The bug only happens when the session comes from a spring SessionFactory.
    @Test
    public void showBug(){
        proveBug(sf.getCurrentSession(), false);
    }

    private Session createHibernateSession() {
        Configuration config = new Configuration();
        config.addAnnotatedClass(ParentEntity.class);
        config.addAnnotatedClass(ChildEntity.class);
        config.addAnnotatedClass(LinkedEntity.class);
        config.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQLInnoDBDialect");
        config.setProperty("hibernate.show_sql","false");
        config.setProperty("hibernate.connection.useUnicode","true");
        config.setProperty("hibernate.connection.characterEncoding","UTF-8");
        config.setProperty("hibernate.cache.use_second_level_cache","true");
        config.setProperty("hibernate.cache.use_query_cache","true");
        config.setProperty("hibernate.cache.region.factory_class","org.hibernate.cache.ehcache.SingletonEhCacheRegionFactory");
        config.setProperty("hibernate.cache.use_structured_entries","false");
        config.setProperty("hibernate.generate_statistics","true");
        config.setProperty("hibernate.connection.driver_class","com.mysql.jdbc.Driver");
        config.setProperty("hibernate.connection.url","jdbc:mysql://localhost:3305/hibernateTest");
        config.setProperty("hibernate.connection.username","root");
        config.setProperty("hibernate.connection.password","");
        SessionFactory sessionFactory = config.buildSessionFactory();
        return sessionFactory.openSession();
    }

    private void proveBug(Session currentSession, boolean flushSessionAfterCollectionReplacement) {
        ParentEntity parent = new ParentEntity();
        ChildEntity child1 = new ChildEntity();
        parent.addChild(child1);

        currentSession.saveOrUpdate(parent);
        currentSession.flush();

        LinkedEntity linkedEntity = new LinkedEntity();
        currentSession.saveOrUpdate(linkedEntity);

        Set<LinkedEntity> linkedEntities = new HashSet<LinkedEntity>();
        linkedEntities.add(linkedEntity);
        parent.setLinkedEntities(linkedEntities);

        //a flush here solves it, but poorly.  if you don't flush here, the creation+removal pair for the set continues to exist, and an extra removal gets added by the query below.
        //The addition by the query below induces the bug, this linked entities stuff is just the setup
        if(flushSessionAfterCollectionReplacement){
            currentSession.flush();
        }

        //part 2

        Collection<ChildEntity> children = parent.getChildren();
        Collection<Long> childIds = new ArrayList<Long>();
        for(ChildEntity child : children){
            childIds.add(child.getId());
        }
        //doing a HQL query on any collection on an object while a many-to-many collection replace is pending on that object causes problems
        String queryString = "from " + ChildEntity.class.getName() + " where id in (" + StringUtils.join(childIds, ",") + ")";
        Query queryObject = currentSession.createQuery(queryString);
        List<ChildEntity> loadedChildren = (List<ChildEntity>) queryObject.list();

        currentSession.flush();
    }
}
