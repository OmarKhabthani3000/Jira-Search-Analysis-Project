package hibernateBugProof;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author Scott Albertine
 */
@Entity
@Access(AccessType.FIELD)
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class ParentEntity extends GenericEntity{

    private String propertyOne;

    @OneToMany(mappedBy = "parentEntity", targetEntity = ChildEntity.class, fetch = FetchType.LAZY)
    @Cascade(value = org.hibernate.annotations.CascadeType.ALL)
    private List<ChildEntity> children;

    @ManyToMany(targetEntity = LinkedEntity.class, fetch = FetchType.LAZY, mappedBy = "linkedParents")
    @Cache(usage = CacheConcurrencyStrategy.NONE)
    private Set<LinkedEntity> linkedEntities = new HashSet<LinkedEntity>();

    public void addChild(ChildEntity child) {
        if(children == null){
            children = new ArrayList<ChildEntity>();
        }
        children.add(child);
    }

    public String getPropertyOne() {
        return propertyOne;
    }

    public void setPropertyOne(String propertyOne) {
        this.propertyOne = propertyOne;
    }

    public List<ChildEntity> getChildren() {
        return children;
    }

    public void setChildren(List<ChildEntity> children) {
        this.children = children;
    }

    public Set<LinkedEntity> getLinkedEntities() {
        return linkedEntities;
    }

    public void setLinkedEntities(Set<LinkedEntity> linkedEntities) {
        this.linkedEntities = linkedEntities; //very important that it works like this with a direct overwrite, may modify later to show how doing an add instead isn't feasible.
    }
}
