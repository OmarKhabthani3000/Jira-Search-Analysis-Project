package hibernateBugProof;

import java.io.Serializable;

/**
 * @author Scott Albertine
 */
public interface GenericEntityIf extends Serializable {

    Long getId();

    Class<? extends GenericEntity> getUnderlyingClass();

}
