package hibernateBugProof;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

/**
 * @author Scott Albertine
 */
@Entity
@Access(AccessType.FIELD)
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class LinkedEntity extends GenericEntity implements Comparable<LinkedEntity> {

    private String propertyOne;

    @ManyToMany(targetEntity = ParentEntity.class, fetch = FetchType.LAZY)
    @JoinTable(
            name = "ParentEntity_LinkedEntity",
            joinColumns = @JoinColumn(name = "linkedId"),
            inverseJoinColumns = {@JoinColumn(name = "parentId")}
    )

    @Cache(usage = CacheConcurrencyStrategy.NONE)
    private Set<ParentEntity> linkedParents = new HashSet<ParentEntity>();

    @Override
    public int compareTo(LinkedEntity o) {
        return (int) (this.getId() - o.getId());
    }

    public String getPropertyOne() {
        return propertyOne;
    }

    public void setPropertyOne(String propertyOne) {
        this.propertyOne = propertyOne;
    }

    public Set<ParentEntity> getLinkedParents() {
        return linkedParents;
    }

    public void setLinkedParents(Set<ParentEntity> linkedParents) {
        this.linkedParents = linkedParents;
    }
}
