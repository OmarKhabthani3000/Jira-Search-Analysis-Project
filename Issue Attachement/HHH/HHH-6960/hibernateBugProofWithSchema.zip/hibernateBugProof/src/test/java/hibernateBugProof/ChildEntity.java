package hibernateBugProof;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

/**
 * @author Scott Albertine
 */

@Entity
@Access(AccessType.FIELD)
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class ChildEntity extends GenericEntity{

    private String propertyOne;

    @ManyToOne(fetch = FetchType.LAZY, targetEntity = ParentEntity.class)
    @JoinColumn(name = "parentId")
    private ParentEntity parentEntity;


    public String getPropertyOne() {
        return propertyOne;
    }

    public void setPropertyOne(String propertyOne) {
        this.propertyOne = propertyOne;
    }

    public ParentEntity getParentEntity() {
        return parentEntity;
    }

    public void setParentEntity(ParentEntity parentEntity) {
        this.parentEntity = parentEntity;
    }
}
