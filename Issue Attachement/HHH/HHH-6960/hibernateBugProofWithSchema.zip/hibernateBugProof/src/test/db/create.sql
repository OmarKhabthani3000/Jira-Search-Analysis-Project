DROP TABLE IF EXISTS auditedentity;
DROP TABLE IF EXISTS auditedentity_aud;
DROP TABLE IF EXISTS childentity;
DROP TABLE IF EXISTS linkedentity;
DROP TABLE IF EXISTS parententity;
DROP TABLE IF EXISTS parententity_linkedentity;

CREATE TABLE AuditedEntity (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  propertyOne varchar(255) DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE AuditedEntity_AUD (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  propertyOne varchar(255) DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE ParentEntity (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  propertyOne varchar(255) DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE ChildEntity (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  propertyOne varchar(255) DEFAULT NULL,
  parentId bigint(20) DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE LinkedEntity (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  propertyOne varchar(255) DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE ParentEntity_LinkedEntity (
  parentId bigint(20) NOT NULL,
  linkedId bigint(20) NOT NULL,
  PRIMARY KEY (parentId,linkedId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;