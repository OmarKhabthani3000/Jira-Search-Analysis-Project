package org.example.shard.context;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ShardContextHolder {

    protected static Logger LOG = LoggerFactory.getLogger(ShardContextHolder.class);
    
    static ThreadLocal<ShardContext> holder = new ThreadLocal<ShardContext>();

    public static void set(ShardContext shardContext) {
        LOG.info(String.format("setting context to [%s]", shardContext));
        
        holder.set(shardContext);
        
        LOG.info(String.format("context set to [%s]", shardContext));
    }

    public static ShardContext get() {
        return holder.get();
    }

    public static void unset() {
        LOG.info("unsetting context");
        
        holder.remove();
        
        LOG.info("context unset");
    }
}
