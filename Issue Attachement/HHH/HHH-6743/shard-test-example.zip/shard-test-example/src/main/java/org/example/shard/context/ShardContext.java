package org.example.shard.context;

public class ShardContext {

    Object shardId;

    public ShardContext(Object shardId) {
        setShardId(shardId);
    }

    public Object getShardId() {
        return shardId;
    }

    protected void setShardId(Object shardId) {
        this.shardId = shardId;
    }

    @Override
    public String toString() {
        return String.format("[%s]:shardId=[%s]", ShardContext.class.getName(),
                shardId);
    }
}
