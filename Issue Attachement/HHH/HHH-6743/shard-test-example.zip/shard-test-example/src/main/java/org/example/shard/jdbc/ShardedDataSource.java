package org.example.shard.jdbc;

import java.sql.Connection;
import java.sql.SQLException;

import org.example.shard.context.ShardContext;
import org.example.shard.context.ShardContextHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

public class ShardedDataSource extends AbstractRoutingDataSource {

    protected static Logger LOG = LoggerFactory
            .getLogger(ShardedDataSource.class);

    @Override
    protected Object determineCurrentLookupKey() {
        ShardContext context = ShardContextHolder.get();
        if (context == null) {
            LOG.warn("no context found");
            return null;
        }

        LOG.info(String.format("found context [%s]; returning lookupKey [%s]",
                context, context.getShardId().toString()));

        return context.getShardId().toString();
    }

    @Override
    public Connection getConnection() throws SQLException {
        return adjustConnectionSettings(super.getConnection());
    }

    @Override
    public Connection getConnection(String username, String password)
            throws SQLException {
        return adjustConnectionSettings(super.getConnection(username, password));
    }

    protected Connection adjustConnectionSettings(Connection c)
            throws SQLException {
        // c.setAutoCommit(false);
        return c;
    }
}
