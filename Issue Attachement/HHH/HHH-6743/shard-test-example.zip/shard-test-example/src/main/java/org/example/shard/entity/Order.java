package org.example.shard.entity;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * An order.
 */
@Entity
@Table(name = "T_ORDER") // need this for unit test!
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customer;

    private long millis;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "order")
    private Collection<Item> items = new LinkedHashSet<Item>();

    /**
     * @return the customer
     */
    public String getCustomer() {
        return customer;
    }

    /**
     * @param customer
     *            the customer to set
     */
    public void setCustomer(String customer) {
        this.customer = customer;
    }

    /**
     * @return the items
     */
    public Collection<Item> getItems() {
        return Collections.unmodifiableCollection(items);
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    protected void add(Item item) {
        items.add(item);
    }

    public long getMillis() {
        return millis;
    }

    public void setMillis(long millis) {
        this.millis = millis;
    }
}
