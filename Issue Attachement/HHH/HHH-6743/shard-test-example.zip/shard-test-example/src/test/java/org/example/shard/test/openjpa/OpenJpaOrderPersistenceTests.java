package org.example.shard.test.openjpa;

import org.example.shard.test.OrderPersistenceTests;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles({ "openjpa", "derby" })
public class OpenJpaOrderPersistenceTests extends OrderPersistenceTests {
}
