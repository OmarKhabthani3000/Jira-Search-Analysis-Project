package org.example.shard.test.hib;

import org.example.shard.test.OrderPersistenceTests;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles({ "hib", "derby" })
public class HibernateOrderPersistenceTests extends OrderPersistenceTests {
}
