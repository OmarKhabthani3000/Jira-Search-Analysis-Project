package org.example.shard.test.dn;

import org.example.shard.test.OrderPersistenceTests;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles({ "dn", "derby" })
public class DataNucleusOrderPersistenceTests extends OrderPersistenceTests {
}
