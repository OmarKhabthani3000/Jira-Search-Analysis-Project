package org.example.shard.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Table;
import javax.sql.DataSource;

import org.example.shard.context.ShardContext;
import org.example.shard.context.ShardContextHolder;
import org.example.shard.entity.Item;
import org.example.shard.entity.Order;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaTemplate;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@ContextConfiguration("classpath:/org/example/shard/test/test-context.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public abstract class OrderPersistenceTests {

    private static Map<String, DataSource> TARGET_DATA_SOURCES;
    private static Set<EntityManagerFactory> TARGET_EMFS;
    private static boolean TOUCHED_EMFS = false;

    static int SHARD_COUNTER = 0;
    static int[] SHARD_IDS = new int[] { 0, 1 };
    static Map<Object, Integer> ITEM_COUNTS = new HashMap<Object, Integer>();
    static Map<Object, Integer> ORDER_COUNTS = new HashMap<Object, Integer>();
    static long MILLIS = System.currentTimeMillis();

    static String ts(String s) {
        return (s == null ? "" : s) + new Date();
    }

    static void incrementOrderCount() {
        incrementCount(ORDER_COUNTS);
    }

    static void incrementItemCount() {
        incrementCount(ITEM_COUNTS);
    }

    static void incrementCount(Map<Object, Integer> counts) {
        Object shardId = ShardContextHolder.get().getShardId();

        int count = 0;
        if (counts.containsKey(shardId)) {
            count = counts.get(shardId);
        }
        counts.put(shardId, ++count);
    }

    @SuppressWarnings("deprecation")
    public static void touch() {
        if (!TOUCHED_EMFS) {
            // touch databases via JPA for schema creation
            for (EntityManagerFactory emf : TARGET_EMFS) {
                JpaTemplate t = new JpaTemplate(emf);
                t.find(Order.class, -1L);
            }
            TOUCHED_EMFS = true;
        }
    }

    @AfterClass
    public static void afterAllTests() {
        if (TARGET_DATA_SOURCES == null) {
            return;
        }

        String table = AnnotationUtils.findAnnotation(Order.class, Table.class)
                .name();
        assertCountsViaSql(ORDER_COUNTS, table);
        table = AnnotationUtils.findAnnotation(Item.class, Table.class).name();
        assertCountsViaSql(ITEM_COUNTS, table);
    }

    @PersistenceContext
    private EntityManager em;

    @SuppressWarnings("unchecked")
    @Autowired
    @Qualifier(value = "targetDataSources")
    public void setTargetDataSources(Object map) {
        TARGET_DATA_SOURCES = (Map<String, DataSource>) map;
    }

    @SuppressWarnings("unchecked")
    @Autowired
    @Qualifier(value = "targetEmfs")
    public void setTargetEmfs(Object set) {
        TARGET_EMFS = (Set<EntityManagerFactory>) set;
    }

    @Before
    public void beforeTest() {
        touch();

        int i = SHARD_COUNTER++ % SHARD_IDS.length;
        ShardContextHolder.set(new ShardContext(SHARD_IDS[i]));
    }

    @After
    public void afterTest() {
        assertCountsViaJpaql(
                ORDER_COUNTS.get(ShardContextHolder.get().getShardId())
                        .intValue(), "Order");

        assertCountsViaJpaql(
                ITEM_COUNTS.get(ShardContextHolder.get().getShardId())
                        .intValue(), "Order");

        ShardContextHolder.unset(); // just to make sure
    }

    protected static void assertCountsViaSql(Map<Object, Integer> counts,
            String table) {
        for (String key : TARGET_DATA_SOURCES.keySet()) {
            JdbcTemplate t = new JdbcTemplate(TARGET_DATA_SOURCES.get(key));

            int count = t
                    .queryForInt(String.format(
                            "select count(*) from %s where millis = %s", table,
                            MILLIS));
            assertEquals("count from database differs from expected count",
                    counts.get(Integer.parseInt(key)).intValue(), count);
        }
    }

    void assertCountsViaJpaql(int count, String entityName) {
        em.flush(); // just to make sure

        String jpaql = "SELECT COUNT(o) FROM " + entityName
                + " o WHERE o.millis = " + MILLIS;

        long orderCountInShard = (Long) em.createQuery(jpaql).getSingleResult();

        System.out.println(jpaql + " returned " + orderCountInShard);

        assertEquals(count, orderCountInShard);
    }

    @Test
    @Transactional
    @Rollback(false)
    public void testSaveOrderWithItems() throws Exception {
        Order order = new Order();
        order.setMillis(MILLIS);
        incrementOrderCount();
        order.setCustomer(ts("testSaveOrderWithItems @"));

        Item item = new Item(order);
        item.setMillis(MILLIS);
        incrementItemCount();
        item.setProduct(ts("testSaveOrderWithItems @"));

        em.persist(order);
        em.flush();

        assertNotNull(order.getId());
    }

    @Test
    @Transactional
    @Rollback(false)
    public void testSaveAndGet() throws Exception {
        Order order = new Order();
        order.setMillis(MILLIS);
        incrementOrderCount();
        order.setCustomer(ts("testSaveAndGet @"));

        Item item = new Item(order);
        item.setMillis(MILLIS);
        incrementItemCount();
        item.setProduct(ts("testSaveAndGet @"));

        em.persist(order);
        em.flush();
        // Otherwise the query returns the existing order (and we didn't set the
        // parent in the item)...
        em.clear();
        Order other = (Order) em.find(Order.class, order.getId());
        assertEquals(1, other.getItems().size());
        assertEquals(other, other.getItems().iterator().next().getOrder());
    }

    @Test
    @Transactional
    @Rollback(false)
    public void testSaveAndFind() throws Exception {
        Order order = new Order();
        order.setMillis(MILLIS);
        incrementOrderCount();
        order.setCustomer(ts("testSaveAndFind @"));

        Item item = new Item(order);
        item.setMillis(MILLIS);
        incrementItemCount();
        String product = ts("testSaveAndFind @");
        item.setProduct(product);

        em.persist(order);
        em.flush();
        // Otherwise the query returns the existing order (and we didn't set the
        // parent in the item)...
        em.clear();
        Order other = (Order) em
                .createQuery(
                        "select o from Order o join o.items i where i.product=:product")
                .setParameter("product", product).getSingleResult();
        assertEquals(1, other.getItems().size());
        assertEquals(other, other.getItems().iterator().next().getOrder());
    }
}
