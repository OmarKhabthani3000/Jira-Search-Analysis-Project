package com.bytecode.common;

import java.util.Date;
import org.hibernate.Session;

import com.bytecode.persistence.HibernateUtil;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println("Maven + Hibernate example + Byte code enhancement");
        Session session = HibernateUtil.getSessionFactory().openSession();
        
        session.beginTransaction();
        
        Stock stock = new Stock();
        
        stock.setStockCode("4715");
        stock.setStockName("GENM");
     
        session.save(stock);

        session.getTransaction().commit();
        
        
    }
}
