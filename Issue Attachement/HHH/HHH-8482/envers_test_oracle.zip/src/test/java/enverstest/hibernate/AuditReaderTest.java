package enverstest.hibernate;

import java.sql.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class AuditReaderTest {

	private static EntityManagerFactory eMgrFactory = null;
	private static EntityManager eMgr = null;
	private static long id = 0L;

	/**
	 * Set up whole test
	 *
	 * @throws Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		String persistenceUnitName = System.getProperty("persistenceUnitName", "ENVERSTEST");
		eMgrFactory = Persistence.createEntityManagerFactory(persistenceUnitName);
		eMgr = eMgrFactory.createEntityManager();

		// Create entity (first revision)
		eMgr.getTransaction().begin();
		AuditedEntity entity = new AuditedEntity();
		entity.setFirstName("John");
		entity.setLastName("Doe");
		eMgr.persist(entity);
		eMgr.getTransaction().commit();
		// Store id for further use
		id = entity.getId();
		System.out.println("ID " + id);

		// Update (second revision)
		eMgr.getTransaction().begin();
		Date dob = new Date(new GregorianCalendar(1970, 1, 1).getTimeInMillis());
		entity.setDateOfBirth(dob);
		eMgr.getTransaction().commit();
	}

	/**
	 * Clean up after test
	 *
	 * @throws Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		eMgr.getTransaction().begin();
		AuditedEntity entity = eMgr.find(AuditedEntity.class, id);
		eMgr.remove(entity);
		eMgr.getTransaction().commit();
	}

	/**
	 * Set up single test case: starts a transaction
	 */
	@Before
	public void setUp() {
		eMgr.getTransaction().begin();
	}

	/**
	 * Clean up after single test case: commits transaction
	 */
	@After
	public void tearDown() {
		eMgr.getTransaction().commit();
	}

	/**
	 * Load the entity which was created during setup
	 */
	@Test
	public void load() {
		AuditedEntity entity = eMgr.find(AuditedEntity.class, id);
		System.out.println(entity.toString());
		Assert.assertNotNull(entity);
	}

	/**
	 * Check the number of revisions - should be two
	 */
	@Test
	public void enversNumberOfRevisions() {
		AuditReader aRdr = AuditReaderFactory.get(eMgr);
		List<Number> revisionList = aRdr.getRevisions(AuditedEntity.class, id);
		System.out.println("Revisions for entity with id " + id);
		for (Number n : revisionList) {
			System.out.println(n.longValue());
		}
		Assert.assertEquals(2, revisionList.size());
	}

	/**
	 * Get the revisions from the database and display them
	 */
	@Test
	public void enversGetRevisions() {
		AuditReader aRdr = AuditReaderFactory.get(eMgr);
		List<Number> revisionList = aRdr.getRevisions(AuditedEntity.class, id);
		System.out.println("Revisions for entity with id " + id);
		for (Number n : revisionList) {
			System.out.println("Fetching Revision " + n.longValue());
			AuditedEntity ae = aRdr.find(AuditedEntity.class, id, n);
			Assert.assertNotNull(ae);
			System.out.println(ae.toString());
		}
	}

}
