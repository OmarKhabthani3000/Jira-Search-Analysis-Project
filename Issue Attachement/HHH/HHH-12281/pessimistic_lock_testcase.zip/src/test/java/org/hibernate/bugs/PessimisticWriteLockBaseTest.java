package org.hibernate.bugs;

import com.google.common.base.Stopwatch;
import org.awaitility.Awaitility;
import org.awaitility.core.ConditionTimeoutException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.LockModeType;
import javax.persistence.LockTimeoutException;
import javax.persistence.Persistence;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

public abstract class PessimisticWriteLockBaseTest {

    Logger logger = LoggerFactory.getLogger(MySQLJPAUnitTestCase.class);

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory(getPersistenceUnitName());
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    public abstract String getPersistenceUnitName();

    @Test
    public void pessimisticWriteLock_lockAlreadyLockedElementWithZeroTimeout_throwsCorrectExceptionClass() {
        createLockObject();
        long timeoutInSeconds = 0L;
        long maxWaitInSeconds = 20L;

        AtomicBoolean firstLockIsAcquired = new AtomicBoolean(false);
        AtomicBoolean concurrentLockAttemptFinished = new AtomicBoolean(false);
        AtomicBoolean done = new AtomicBoolean(false);

        try {
            new Thread(() -> lockAndWait(firstLockIsAcquired, concurrentLockAttemptFinished, done, maxWaitInSeconds)).start();
            new Thread(() -> tryToGetLock(firstLockIsAcquired, concurrentLockAttemptFinished, timeoutInSeconds)).start();

            Awaitility.await().atMost(5, TimeUnit.SECONDS).until(firstLockIsAcquired::get);
            Stopwatch stopwatch = Stopwatch.createStarted();

            Awaitility.await().atMost(timeoutInSeconds + 5, TimeUnit.SECONDS).until(concurrentLockAttemptFinished::get);
            stopwatch.stop();
            logger.info("Time until concurrent lock acquisition failed: " + stopwatch.elapsed(TimeUnit.MILLISECONDS) + " ms.");

            Awaitility.await().atMost(5, TimeUnit.SECONDS).until(done::get);
        } catch (ConditionTimeoutException e) {
            fail("Failed to complete test within time limit of " + maxWaitInSeconds + " seconds.", e);
        }
    }

    @Test
    public void pessimisticWriteLock_lockAlreadyLockedElementWithZeroTimeout_throwsImmediateTimeOutException() {
        createLockObject();
        long timeoutInSeconds = 0L;
        long maxWaitInSeconds = 20L;

        AtomicBoolean firstLockIsAcquired = new AtomicBoolean(false);
        AtomicBoolean concurrentLockAttemptFinished = new AtomicBoolean(false);
        AtomicBoolean done = new AtomicBoolean(false);

        try {
            new Thread(() -> lockAndWait(firstLockIsAcquired, concurrentLockAttemptFinished, done, maxWaitInSeconds)).start();
            new Thread(() -> tryToGetLock(firstLockIsAcquired, concurrentLockAttemptFinished, timeoutInSeconds)).start();

            Awaitility.await().atMost(5, TimeUnit.SECONDS).until(firstLockIsAcquired::get);
            Stopwatch stopwatch = Stopwatch.createStarted();

            Awaitility.await().atMost(timeoutInSeconds + 5, TimeUnit.SECONDS).until(concurrentLockAttemptFinished::get);
            stopwatch.stop();
            long elapsedMilliseconds = stopwatch.elapsed(TimeUnit.MILLISECONDS);
            logger.info("Time until concurrent lock acquisition failed: " + elapsedMilliseconds + " ms.");

            assertThat(elapsedMilliseconds).isLessThan(500);

            Awaitility.await().atMost(5, TimeUnit.SECONDS).until(done::get);
        } catch (ConditionTimeoutException e) {
            fail("Failed to complete test within time limit of " + maxWaitInSeconds + " seconds.", e);
        }
    }

    @Test
    public void pessimisticWriteLock_lockAlreadyLockedElementWithNonZeroTimeout_throwsTimeOutExceptionAfterSpecifiedTimeout() {
        createLockObject();
        long timeoutInSeconds = 10L;
        long maxWaitInSeconds = 20L;

        AtomicBoolean firstLockIsAcquired = new AtomicBoolean(false);
        AtomicBoolean concurrentLockAttemptFinished = new AtomicBoolean(false);
        AtomicBoolean done = new AtomicBoolean(false);

        try {
            new Thread(() -> lockAndWait(firstLockIsAcquired, concurrentLockAttemptFinished, done, maxWaitInSeconds)).start();
            new Thread(() -> tryToGetLock(firstLockIsAcquired, concurrentLockAttemptFinished, timeoutInSeconds)).start();

            Awaitility.await().atMost(5, TimeUnit.SECONDS).until(firstLockIsAcquired::get);
            Stopwatch stopwatch = Stopwatch.createStarted();

            Awaitility.await().atMost(timeoutInSeconds + 5, TimeUnit.SECONDS).until(concurrentLockAttemptFinished::get);
            stopwatch.stop();
            long elapsedMilliseconds = stopwatch.elapsed(TimeUnit.MILLISECONDS);
            logger.info("Time until concurrent lock acquisition failed: " + elapsedMilliseconds + " ms.");

            assertThat(elapsedMilliseconds).isGreaterThanOrEqualTo(timeoutInSeconds * 1000);

            Awaitility.await().atMost(5, TimeUnit.SECONDS).until(done::get);
        } catch (ConditionTimeoutException e) {
            fail("Failed to complete test within time limit of " + maxWaitInSeconds + " seconds.", e);
        }
    }

    private void createLockObject() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        LockObject lockObject = new LockObject();
        lockObject.setId("1");
        entityManager.persist(lockObject);

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    private void lockAndWait(AtomicBoolean firstLockIsAcquired, AtomicBoolean concurrentLockAttemptFinished, AtomicBoolean done, long maxWaitInSeconds) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        LockObject lockObject = null;
        try {
            lockObject = entityManager.find(LockObject.class, "1", LockModeType.PESSIMISTIC_WRITE);
        } catch (Exception e) {
            fail("Exception while executing select for update", e);
        }
        assertThat(lockObject).isNotNull();
        assertThat(lockObject.getId()).isEqualTo("1");

        firstLockIsAcquired.set(true);
        try {
            Awaitility.await().atMost(maxWaitInSeconds, TimeUnit.SECONDS).until(concurrentLockAttemptFinished::get);
        }catch (Exception e) {
            fail("Caught await exception.", e);
        } finally {
            entityManager.getTransaction().commit();
            entityManager.close();
            done.set(true);
        }
    }

    private void tryToGetLock(AtomicBoolean firstLockIsAcquired, AtomicBoolean concurrentLockAttemptFinished, Long timeoutInSeconds) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        Awaitility.await().until(firstLockIsAcquired::get);
        try {
            logger.info("Try to get lock for object");
            Map<String, Object> properties = Collections.singletonMap("javax.persistence.lock.timeout", timeoutInSeconds * 1000);
            LockObject lockObject = entityManager.find(LockObject.class, "1", LockModeType.PESSIMISTIC_WRITE, properties);
            assertThat(lockObject).isNotNull();
            assertThat(lockObject.getId()).isEqualTo("1");
            fail("Expected a LockTimeOutException, but lock acquisition was successful instead.");
        } catch (LockTimeoutException e) {
            logger.info("Successfully caught LockTimeoutException!");
        } catch (Exception e) {
            fail("Unexpected exception while executing select for update", e);
        } finally {
            entityManager.getTransaction().commit();
            entityManager.close();
            concurrentLockAttemptFinished.set(true);
        }
    }
}
