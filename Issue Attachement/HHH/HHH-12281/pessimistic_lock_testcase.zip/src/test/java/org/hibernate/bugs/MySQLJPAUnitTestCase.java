package org.hibernate.bugs;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class MySQLJPAUnitTestCase extends PessimisticWriteLockBaseTest {

    @Override
    public String getPersistenceUnitName() {
        return "mysql";
    }

}

