package org.hibernate.bugs.entities;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "LINK_ENTITY")
public class LinkEntity {

    @EmbeddedId
    private LinkEntityPK id;

    protected LinkEntity() {}

    public LinkEntity(Entity1 entity1, Entity2 entity2) {
        id = new LinkEntityPK(entity1, entity2);
    }
}
