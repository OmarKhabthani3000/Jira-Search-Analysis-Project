package org.hibernate.bugs.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ENTITY2")
public class Entity2 {

    @Id
    private long id;

    protected Entity2() {}

    public Entity2(long id) {
        this.id = id;
    }
}
