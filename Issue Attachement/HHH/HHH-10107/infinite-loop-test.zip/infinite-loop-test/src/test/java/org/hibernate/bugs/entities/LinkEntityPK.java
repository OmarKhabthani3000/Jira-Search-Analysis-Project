package org.hibernate.bugs.entities;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class LinkEntityPK implements Serializable {

    @ManyToOne
    @JoinColumn(name = "id1")
    private Entity1 entity1;

    @ManyToOne
    @JoinColumn(name = "id2")
    private Entity2 entity2;

    protected LinkEntityPK() {}

    public LinkEntityPK(Entity1 entity1, Entity2 entity2) {
        this.entity1 = entity1;
        this.entity2 = entity2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LinkEntityPK that = (LinkEntityPK) o;
        return Objects.equals(entity1, that.entity1) &&
                Objects.equals(entity2, that.entity2);
    }

    @Override
    public int hashCode() {
        return Objects.hash(entity1, entity2);
    }
}
