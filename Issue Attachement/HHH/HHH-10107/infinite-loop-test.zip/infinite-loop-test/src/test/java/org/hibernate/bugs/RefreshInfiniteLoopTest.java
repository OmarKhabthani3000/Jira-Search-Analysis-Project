/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.bugs.entities.Entity1;
import org.hibernate.bugs.entities.Entity2;
import org.hibernate.bugs.entities.LinkEntity;
import org.hibernate.bugs.entities.LinkEntityPK;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Before;
import org.junit.Test;

public class RefreshInfiniteLoopTest extends BaseCoreFunctionalTestCase {

	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
				Entity1.class,
				Entity2.class,
				LinkEntity.class,
				LinkEntityPK.class
		};
	}

	@Before
	public void insertData() {
		Entity1 entity1 = new Entity1(1l);

		Entity2 first = new Entity2(1l);
		Entity2 second = new Entity2(2l);
		Entity2 third = new Entity2(3l);

		entity1.addLinkEntities(
				new LinkEntity(entity1, first),
				new LinkEntity(entity1, second),
				new LinkEntity(entity1, third)
		);

		Session s = openSession();
		s.getTransaction().begin();

		s.save(first);
		s.save(second);
		s.save(third);
		s.save(entity1);

		s.getTransaction().commit();
		s.close();
	}

	@Test
	public void refresh_doesNotCauseInfiniteLoop() throws Exception {
		Session s = openSession();

		Entity1 entity1 = (Entity1) s.get(Entity1.class, 1l);

		// This causes the infinite loop
		s.refresh(entity1);

		s.close();
	}
}
