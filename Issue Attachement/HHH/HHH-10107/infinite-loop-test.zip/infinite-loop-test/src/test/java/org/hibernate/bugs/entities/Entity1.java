package org.hibernate.bugs.entities;

import javax.persistence.*;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "ENTITY1")
public class Entity1 {

    @Id
    private long id;

    @OneToMany(mappedBy = "id.entity1", cascade = CascadeType.ALL)
    private Set<LinkEntity> linkEntities;

    protected Entity1() {}

    public Entity1(long id) {
        this.id = id;
    }

    public void addLinkEntities(LinkEntity... entities) {
        if (linkEntities == null) {
            linkEntities = new HashSet<>();
        }
        linkEntities.addAll(Arrays.asList(entities));
    }
}
