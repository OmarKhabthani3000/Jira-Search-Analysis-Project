package org.hibernate.test.session;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.service.ServiceRegistryBuilder;
import org.hibernate.service.internal.StandardServiceRegistryImpl;
import org.hibernate.test.annotations.Country;
import org.hibernate.testing.FailureExpected;
import org.hibernate.testing.TestForIssue;
import org.hibernate.testing.env.ConnectionProviderBuilder;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.hibernate.testing.junit4.BaseUnitTestCase;
import org.junit.*;

public class SessionWithOptionsConnectionTest extends BaseCoreFunctionalTestCase {
    @Test
    @TestForIssue( jiraKey = "HHH-7020" )
    @FailureExpected( jiraKey = "HHH-7020" )
    public void testSharedTransactionContextSessionClosing() {
        Session session = sessionFactory().openSession();
        session.getTransaction().begin();

        Session secondSession = session.sessionWithOptions().connection()
                .openSession();
        Criteria criteria = secondSession.createCriteria(Anything.class);
        criteria.list();

        //the list should have registered and then released a JDBC resource
        Assert.assertFalse(((SessionImplementor) secondSession).getTransactionCoordinator().getJdbcCoordinator().getLogicalConnection().getResourceRegistry().hasRegisteredResources());
        
        secondSession.close();

        //there should be no registered JDBC resources on the original session
        Assert.assertFalse(((SessionImplementor) session).getTransactionCoordinator().getJdbcCoordinator().getLogicalConnection().getResourceRegistry().hasRegisteredResources());
        
        session.getTransaction().commit();
        //the session should be allowed to close properly as well
        session.close();
    }

    @Test
    @TestForIssue( jiraKey = "HHH-7020" )
    @FailureExpected( jiraKey = "HHH-7020" )
    public void testSharedTransactionContextAutoClosing() {
        Session session = sessionFactory().openSession();
        session.getTransaction().begin();

        Session secondSession = session.sessionWithOptions().connection().autoClose(true)
                .openSession();
        Criteria criteria = secondSession.createCriteria(Anything.class);
        criteria.list();

        //the list should have registered and then released a JDBC resource
        Assert.assertFalse(((SessionImplementor) secondSession).getTransactionCoordinator().getJdbcCoordinator().getLogicalConnection().getResourceRegistry().hasRegisteredResources());

        secondSession.close();

        //there should be no registered JDBC resources on the original session
        Assert.assertFalse(((SessionImplementor) session).getTransactionCoordinator().getJdbcCoordinator().getLogicalConnection().getResourceRegistry().hasRegisteredResources());
    }

    @Override
    protected Class<?>[] getAnnotatedClasses() {
        return new Class[]{Anything.class};
    }
}