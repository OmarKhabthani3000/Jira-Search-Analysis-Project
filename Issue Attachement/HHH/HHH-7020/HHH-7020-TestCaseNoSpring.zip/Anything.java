package org.hibernate.test.session;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Anything {
    public Integer id;

    @Id
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
