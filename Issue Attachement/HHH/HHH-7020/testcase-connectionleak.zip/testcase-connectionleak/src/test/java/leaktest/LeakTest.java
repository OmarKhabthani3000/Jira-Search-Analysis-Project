package leaktest;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.persistence.EntityManager;

import org.apache.commons.dbcp.BasicDataSource;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.jdbc.Work;
import org.junit.AfterClass;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.support.JdbcUtils;

public class LeakTest {

    private static final String TESTVALUE = "xx";

    private static ClassPathXmlApplicationContext applicationContext;

    private static PersistenceService persistenceService;
    
    private static BasicDataSource dataSource;

    @BeforeClass
    public static void beforeClass() {
        applicationContext = new ClassPathXmlApplicationContext("/leaktest/spring.xml");
        persistenceService = applicationContext.getBean(PersistenceService.class);
        dataSource = applicationContext.getBean(BasicDataSource.class);

    }

    @AfterClass
    public static void afterClass() {
        if (applicationContext != null) {
            applicationContext.close();
        }
    }
    
    @Test
    public void test1() {
        runWork(new WorkJdbc());
    }
    
    @Test
    public void test2() {
        runWork(new WorkHib());
    }
    
    
    @Test
    public void test3() {
        
        final int numActiveOrig = dataSource.getNumActive();
        
        persistenceService.executeTransactionally(new Runnable() {
            @Override
            public void run() {
                EntityManager entityManager = persistenceService.getEntityManager();
                Entity entity = entityManager.find(Entity.class, 1L);
                entity.setValue1(TESTVALUE);
                
                entityManager.flush();
                
                assertEquals(numActiveOrig + 1, dataSource.getNumActive());
                
                // Hibernate 4.x
                Session session = persistenceService.getSession().sessionWithOptions().connection().openSession();
                
                // Hibernate 3.x
//                Session session = persistenceService.getSession().getSessionFactory().openSession(persistenceService.getSession().connection());

                
                Query q = session.createQuery("select e from Entity e");
                @SuppressWarnings("unchecked")
                List<Entity> list = q.list();
                System.out.println("Value1: " + list.get(0).getValue1());
                
                // make sure we're using the same connection
                assertEquals(TESTVALUE, list.get(0).getValue1());
                
                session.close();
                
                System.out.println("executeTransactionally() finished.");
                
            }
        });
        assertEquals("Number of active connection should be the same before transaction.", numActiveOrig, dataSource.getNumActive());
    }
    
    private void runWork(final Work work) {
        
        final int numActiveOrig = dataSource.getNumActive();

        persistenceService.executeTransactionally(new Runnable() {
            @Override
            public void run() {
                EntityManager entityManager = persistenceService.getEntityManager();
                Entity entity = entityManager.find(Entity.class, 1L);
                entity.setValue1(TESTVALUE);

                entityManager.flush();
                
                assertEquals(numActiveOrig + 1, dataSource.getNumActive());
                
                persistenceService.getSession().doWork(work);
                
                System.out.println("executeTransactionally() finished.");
            }
        });
        assertEquals("Number of active connection should be the same before transaction.", numActiveOrig, dataSource.getNumActive());
    }
    
    
    @Before
    public void resetDatabase() {
        Connection connection = null;
        Statement stmt = null;
        try {
            
            connection = dataSource.getConnection();
            stmt = connection.createStatement();
            stmt.execute("TRUNCATE TABLE ENTITY");
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        } finally {
            JdbcUtils.closeStatement(stmt);
            JdbcUtils.closeConnection(connection);
        }
        
        persistenceService.executeTransactionally(new Runnable() {
            @Override
            public void run() {
                EntityManager entityManager = persistenceService.getEntityManager();

                Entity entity = new Entity();
                entity.setId(1);
                entity.setValue1("1");
                entity.setValue2("2");

                entityManager.persist(entity);
            }
        });

    }
    
    
    private class WorkHib implements Work {
        @Override
        public void execute(Connection connection) throws SQLException {
            
            // Hibernate 4.x
            Session session = persistenceService.getSession().sessionWithOptions().connection(connection).openSession();
            
            // Hibernate 3.x
//            Session session = persistenceService.getSession().getSessionFactory().openSession(persistenceService.getSession().connection());
            Query q = session.createQuery("select e from Entity e");
            @SuppressWarnings("unchecked")
            List<Entity> list = q.list();
            System.out.println("Value1: " + list.get(0).getValue1());
            
            // make sure we're using the same connection
            assertEquals(TESTVALUE, list.get(0).getValue1());
            session.close();
        }
    }

    
    private class WorkJdbc implements Work {
        @Override
        public void execute(Connection connection) throws SQLException {
            
            Statement stmt = null;
            ResultSet rs = null;
            try {
                 stmt = connection.createStatement();          
                 rs = stmt.executeQuery("select * from entity");
                 rs.next();
                 System.out.println("Value1: " + rs.getString("value1"));
                 
                 // make sure we're using the same connection
                 assertEquals(TESTVALUE, rs.getString("value1"));
            } finally {
                JdbcUtils.closeResultSet(rs);
                JdbcUtils.closeStatement(stmt);
            }
        }
    }
    
    
}
