package leaktest;

import javax.persistence.Id;
import javax.persistence.Version;

@javax.persistence.Entity
@org.hibernate.annotations.Entity(dynamicInsert = true, dynamicUpdate = true)
public class Entity {
    private long id;

    private int version;

    private String value1;

    private String value2;

    @Id
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Version
    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public String getValue1() {
        return value1;
    }

    public void setValue1(String value1) {
        this.value1 = value1;
    }

    public String getValue2() {
        return value2;
    }

    public void setValue2(String value2) {
        this.value2 = value2;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Entity)) {
            return false;
        }

        Entity other = (Entity) obj;

        if (getId() == 0 || other.getId() == 0) {
            throw new IllegalStateException("ID not assigned!");
        }

        return getId() == other.getId();
    }

    @Override
    public int hashCode() {
        if (getId() == 0) {
            throw new IllegalStateException("ID not assigned!");
        }

        return Long.valueOf(getId()).hashCode();
    }
}
