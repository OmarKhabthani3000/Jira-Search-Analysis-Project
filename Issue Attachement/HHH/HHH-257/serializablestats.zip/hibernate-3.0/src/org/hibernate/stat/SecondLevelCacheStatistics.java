//$Id: SecondLevelCacheStatistics.java,v 1.9 2005/02/12 07:19:46 steveebersole Exp $
package org.hibernate.stat;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.hibernate.cache.Cache;
import org.hibernate.cache.CacheKey;

import java.io.Serializable;

/**
 * Second level cache statistics of a specific region
 *
 * @author Gavin King
 */
public class SecondLevelCacheStatistics implements Serializable {
    private Cache cache;
	long hitCount;
	long missCount;
	long putCount;

	public SecondLevelCacheStatistics(Cache cache) {
		this.cache = cache;
	}
	public long getHitCount() {
		return hitCount;
	}
	public long getMissCount() {
		return missCount;
	}
	public long getPutCount() {
		return putCount;
	}
	public long getElementCountInMemory() {
		return cache.getElementCountInMemory();
	}
	public long getElementCountOnDisk() {
		return cache.getElementCountOnDisk();
	}
	public long getSizeInMemory() {
		return cache.getSizeInMemory();
	}

	public Map getEntries() {
		Map map = new HashMap();
		Iterator iter = cache.toMap().entrySet().iterator();
		while ( iter.hasNext() ) {
			Map.Entry me = (Map.Entry) iter.next();
			map.put( ( (CacheKey) me.getKey() ).getKey(), me.getValue() );
		}
		return map;
	}
        public String toString () {
          StringBuffer sb = new StringBuffer(70);
          sb.append("hitCount=")
            .append(getHitCount())
            .append("\nmissCount=")
            .append(getMissCount())
            .append("\nputCount=")
            .append(getPutCount())
            .append("\nelementCountInMemory=")
            .append(getElementCountInMemory())
            .append("\nelementCountOnDisk=")
            .append(getElementCountOnDisk())
            .append("\nsizeInMemory=")
            .append(getSizeInMemory());
          return sb.toString();
        }
}
