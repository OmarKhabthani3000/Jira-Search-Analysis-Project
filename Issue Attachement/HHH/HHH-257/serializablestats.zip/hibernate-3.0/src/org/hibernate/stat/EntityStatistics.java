//$Id: EntityStatistics.java,v 1.5 2004/08/08 10:18:20 oneovthafew Exp $
package org.hibernate.stat;

import java.io.Serializable;

/**
 * Entity related statistics
 *
 * @author Gavin King
 */
public class EntityStatistics implements Serializable {

	long loadCount;
	long updateCount;
	long insertCount;
	long deleteCount;
	long fetchCount;

	public long getDeleteCount() {
		return deleteCount;
	}
	public long getInsertCount() {
		return insertCount;
	}
	public long getLoadCount() {
		return loadCount;
	}
	public long getUpdateCount() {
		return updateCount;
	}
	public long getFetchCount() {
		return fetchCount;
	}
        public String toString () {
          StringBuffer sb = new StringBuffer(70);
          sb.append("loadCount=")
            .append(getLoadCount())
            .append("\nfetchCount=")
            .append(getFetchCount())
            .append("\nupdateCount=")
            .append(getUpdateCount())
            .append("\ndeleteCount=")
            .append(getDeleteCount());
          return sb.toString();
        }

}
