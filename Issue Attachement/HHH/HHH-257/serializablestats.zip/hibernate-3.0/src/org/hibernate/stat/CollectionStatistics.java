//$Id: CollectionStatistics.java,v 1.5 2004/08/08 10:18:20 oneovthafew Exp $
package org.hibernate.stat;

import java.io.Serializable;

/**
 * Collection related statistics
 *
 * @author Gavin King
 */
public class CollectionStatistics implements Serializable {

	long loadCount;
	long fetchCount;
	long updateCount;
	long removeCount;
	long recreateCount;

	public long getLoadCount() {
		return loadCount;
	}
	public long getFetchCount() {
		return fetchCount;
	}
	public long getRecreateCount() {
		return recreateCount;
	}
	public long getRemoveCount() {
		return removeCount;
	}
	public long getUpdateCount() {
		return updateCount;
	}
        public String toString () {
          StringBuffer sb = new StringBuffer(70);
          sb.append("loadCount=")
            .append(getLoadCount())
            .append("\nfetchCount=")
            .append(getFetchCount())
            .append("\nupdateCount=")
            .append(getUpdateCount())
            .append("\nremoveCount=")
            .append(getRemoveCount())
            .append("\nrecreateCount=")
            .append(getRecreateCount());
          return sb.toString();
        }

}
