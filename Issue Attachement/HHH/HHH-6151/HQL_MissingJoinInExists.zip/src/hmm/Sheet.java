package hmm;

public class Sheet {
    public int getId() {return 0;}
    public void setId(int value) {}

    public Folder getFolder() {return null;}
    public void setFolder(Folder value) {}

    public String getName() {return "";}
    public void setName(String value) {}

}
