package hmm;
//package NHibernate.Test.NHSpecificTest.HQL_MissingJoinInExists;

    public class Shelf
    {
        public int getId() {return 0;}
        public void setId(int value) {}

        public String getName() {return "";}
        public void setName(String value) {}
    }

