package hmm;

public class Folder {
    public int getId() {return 0;}
    public void setId(int value) {}

    public Shelf getShelf() {return null;}
    public void setShelf(Shelf value) {}
    
    public String getName() {return "";}
    public void setName(String value) {}

}
