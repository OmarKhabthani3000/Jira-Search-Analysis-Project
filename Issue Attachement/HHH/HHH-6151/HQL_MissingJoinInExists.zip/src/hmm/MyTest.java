package hmm;
import junit.framework.Test;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.testing.junit.functional.FunctionalTestCase;
import org.hibernate.testing.junit.functional.FunctionalTestClassTestSuite;

public class MyTest extends FunctionalTestCase {
	public MyTest(String string) {
		super(string);
	}

	public String[] getMappings() {
		return new String[]{
			"Mappings.hbm.xml",
		};
	}
	
	public static Test suite() {
		return new FunctionalTestClassTestSuite( MyTest.class );
	}

	public boolean createSchema() {
		return true;
	}

	public void testHQLExistsWithJoin() throws Exception {
		Session s = openSession();
		Transaction t = s.beginTransaction();
		s.createQuery( 
				"SELECT ROOT FROM hmm.Sheet AS ROOT " +
				"WHERE (EXISTS (FROM hmm.Shelf AS inv " +
				"               left JOIN ROOT.Folder AS ROOT_Folder " +
				"               WHERE (((ROOT_Folder.Shelf) = (inv) AND inv.Id = 1)) )) " +
				"      AND ROOT.Name = 'SomeName'").list();
		t.commit();
		s.close();
	}
	
}
