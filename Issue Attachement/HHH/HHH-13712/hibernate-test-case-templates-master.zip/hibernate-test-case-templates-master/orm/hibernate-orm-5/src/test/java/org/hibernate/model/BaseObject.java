package org.hibernate.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "base_object")
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn
public abstract class BaseObject implements Serializable {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    @Column(name = "name", nullable = false, unique = true)
    private String name;

    //Parent is in inherited class - this is important when ding query with it's name
    @ManyToOne
    @JoinColumn(name = "parent_id", nullable = false)
    private ParentObject parent;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ParentObject getParent() {
        return parent;
    }

    public void setParent(ParentObject parent) {
        this.parent = parent;
    }
}
