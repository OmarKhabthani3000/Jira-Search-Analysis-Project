package org.hibernate.bugs;

import org.hibernate.model.BigObject;
import org.hibernate.model.ParentObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh123Test() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        //My test case
        createTestCaseEntities(entityManager);
        //Count similar to spring boot
		Long count = failedQuery(entityManager);
		assert count==1L : "Count failed or not working properly";

        entityManager.getTransaction().commit();
        entityManager.close();

    }

    private void createTestCaseEntities(EntityManager entityManager) {
        ParentObject parentObject = new ParentObject();
        parentObject.setName("tomasz bozek");
        entityManager.persist(parentObject);
        //Create big object with reference to parent - base object has parent reference id which is not included in query :(
        BigObject rootObject = new BigObject();
        rootObject.setSecondName("root object second name");
        rootObject.setName("root object firstName");
        rootObject.setParent(parentObject);
        entityManager.persist(rootObject);
    }

    private Long failedQuery(EntityManager em) {

        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Long> query = builder.createQuery(Long.class);
		Root<BigObject> root = query.from(BigObject.class);
		Join<BigObject, ParentObject> parent = root.join("parent");

		Predicate predicate = builder.like(builder.lower(parent.get("name")), "%bozek%");

		if (query.isDistinct()) {
            query.select(builder.countDistinct(root));
        } else {
            query.select(builder.count(root));
        }
		builder.and(predicate);
        TypedQuery<Long> query1 = em.createQuery(query);

        Long count = query1.getSingleResult();
        return count;
    }
}
