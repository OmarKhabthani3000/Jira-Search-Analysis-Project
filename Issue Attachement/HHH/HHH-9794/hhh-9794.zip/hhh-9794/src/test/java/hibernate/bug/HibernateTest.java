package hibernate.bug;

import hibernate.bug.model.Employee;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    private Employee e;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        e = new Employee("e");
        em.persist(e);
        
        tx.commit();
        em.close();
    }
    
    @Test
    public void test() throws Throwable {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        try {
            int updated = em.createQuery("UPDATE Employee e SET name = ',Employee 123' WHERE e.id = :id")
                    .setParameter("id", e.getId())
                    .executeUpdate();
            Assert.assertEquals(1, updated);
            tx.commit();
        } catch (Throwable t) {
            tx.rollback();
            throw t;
        }
            
        Employee emp = em.createQuery("FROM Employee e WHERE e.id = :id", Employee.class)
                .setParameter("id", e.getId())
                .getSingleResult();

        Assert.assertEquals(",Employee 123", emp.getName());
        
        em.close();
    }
}
