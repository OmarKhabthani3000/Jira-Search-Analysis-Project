package test.hibernate;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.sql.JoinType;
import org.junit.Before;
import org.junit.Test;
import org.hibernate.hql.internal.QuerySplitter;

import annotations.Employee;
import annotations.HibernateUtil;

public class issueHHH9794 {

	private static final String Query_Employees_All = "from Employee";
	
	private static SessionFactory sessionFactory;
	private static Session session;

	private static final String VALUE_NAME = "Employee Number 1";
	private static final String COMMA = ",";
	
	Criteria criteria;
	
	
	@Before
	public void setUp() {

		try {
			sessionFactory = HibernateUtil.getSessionFactory();
		} catch (Exception e) {
				e.printStackTrace();
		}

	}

	
	@Test
	public void testCreateRecord() {

		String strRecord = null;
		Transaction tx = null;

		try {

				System.out.println("Create one record in the sql database");

				session = sessionFactory.openSession();

				tx = session.beginTransaction();

				Employee employee = new Employee();
				employee.setName(VALUE_NAME);
				session.save(employee);
				tx.commit();

				strRecord = "Record ID: " + employee.getId()
						+ " --> field value is: " + employee.getName();

				System.out
						.println("One Database record created in SQL database:");
				System.out.println(strRecord);

		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}
			e.printStackTrace();

		} finally {
			session.close();
		}
	}

	@Test
	public void testUpdateRecord() {

		// update the record
		System.out.println("Update a record in the sql database.");

		Transaction tx = null;
		Query query;
		List list;

		try {
				session = sessionFactory.openSession();

				// here is the bug the word "Employee" in the comment string
				// will be replaced with "annotations.Employee" if a comma is
				// preceding the word "Employee" is replaced with the employee
				// class name
				
				System.out.println("Get the record number 1 from the database.");
				System.out.println("The NAME column will be set to: |->" + COMMA + VALUE_NAME + "<-|");
				
				String Query_Update_EmployeeName_ByID = "UPDATE Employee set Name = '"
						+ COMMA + VALUE_NAME + "'" + " WHERE ID = '1'";

				System.out.println("Query Update= " + Query_Update_EmployeeName_ByID);
				
				// update Employee employee set employee.empID='Test'

				tx = session.beginTransaction();
				
				query = session.createQuery(Query_Update_EmployeeName_ByID);
				query.executeUpdate();

				tx.commit();

		} catch (Exception e) {
			System.out.println("ERROR Query Update was not successful !");

			if (tx != null) {
				tx.rollback();
			}
			e.printStackTrace();

		} finally {
			session.close();
		}

		// READ Records() after update;
		System.out.println("Read the records in sql database after the update");

		try {
				session = sessionFactory.openSession();

				// here is the bug the word "Employee" in the comment string
				// will be
				// replaced with "test.hibernate.bug1.Employee" if a comma is
				// preceding the word "Employee" is replaced with the employee
				// class name

				query = session.createQuery(Query_Employees_All);
				list = query.list();

				for (int j = 0; j < list.size(); j++) {
					Employee employee = (Employee) list.get(j);

					System.out.println("Record ID: " + employee.getId()
							+ " --> field value should be: " + COMMA
							+ VALUE_NAME);
					System.out.println("Record ID: " + employee.getId()
							+ " --> but field value is: " + employee.getName());

					assertEquals(COMMA + VALUE_NAME, employee.getName());
				}

		} catch (Exception e) {
			System.out.println("ERROR Query after update was not successful !");
			e.printStackTrace();

		} finally {
			session.close();
		}

	}
	
	@Test
	public void testConcreteQueries() {

		// get a collection by criteria 
		System.out.println("test replacement with concrete queries.");

		try {
				session = sessionFactory.openSession();
				SessionFactoryImplementor  sfi = (SessionFactoryImplementor) session.getSessionFactory();

				System.out.println("Value to give to QuerySplitter: " + COMMA + VALUE_NAME);
				String[] results = QuerySplitter.concreteQueries(COMMA + VALUE_NAME, sfi);
				
				for (String result : results) {
					System.out.println("Value after running QuerySplitter.concreteQueries: " 
							+ result);
				}
				assertEquals(COMMA + VALUE_NAME, results.toString());
				
				
		} catch (Exception e) {
			System.out.println("ERROR Query after update was not successful !");
			e.printStackTrace();

		} finally {
			session.close();
		}

	}	
}
