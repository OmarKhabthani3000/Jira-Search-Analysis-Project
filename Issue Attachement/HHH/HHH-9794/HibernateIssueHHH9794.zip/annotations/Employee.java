package annotations;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity  
@Table(name= "tabEmployees")  
public class Employee {
	
	public static final String SQL_TABLE_EMPLOYEES = "tabemployees";
	public static final String SQL_TABLE_EMPLOYEE_FIELD_KEY_ID = "ID";
	public static final String SQL_TABLE_EMPLOYEE_FIELD_NAME = "NAME";
	public static final String SQL_TABLE_EMPLOYEE_FIELD_ADDR_ID = "ADDRESSID";
	
	@TableGenerator(
            name="empGen", 
            table="ID_GEN", 
            pkColumnName="GEN_KEY", 
            valueColumnName="GEN_VALUE", 
            pkColumnValue="EMP_ID", 
            allocationSize=1)
	
/*
        @TableGenerator(
			name="empIDGenerator"
			,table=SQL_TABLE_EMPLOYEES
			,pkColumnName= SQL_TABLE_EMPLOYEE_FIELD_KEY_ID
			,valueColumnName=SQL_TABLE_EMPLOYEE_FIELD_KEY_ID 
			,pkColumnValue=SQL_TABLE_EMPLOYEE_FIELD_KEY_ID 
			,allocationSize=1)

	@GeneratedValue(strategy=GenerationType.TABLE, generator="empIDGenerator")
*/
	
	@Id
	@Column(name=SQL_TABLE_EMPLOYEE_FIELD_KEY_ID, nullable=false,unique=true)
    @GeneratedValue(strategy=GenerationType.TABLE, generator="empGen")
  	private long id;

	public Employee() {

	}

	public Employee(String strName) {
		this(); 
		this.name = strName;  
	}
	
	public long getId() {  
	    return id;  
	}  
	
	@Column(name=SQL_TABLE_EMPLOYEE_FIELD_NAME)
	private String name;  
	public String getName() {  
	    return name;  
	}  
	public void setName(String strName) {  
	    this.name = strName;  
	}  
	
	@Column(name=SQL_TABLE_EMPLOYEE_FIELD_ADDR_ID)
	private long addressID;  
	public long getAddressID() {  
	    return addressID;  
	}  

}
