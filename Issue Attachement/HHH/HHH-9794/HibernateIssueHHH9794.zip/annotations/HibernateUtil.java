package annotations;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataBuilder;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.spi.MetadataImplementor;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class HibernateUtil {

	   private static SessionFactory sessionFactory;
	   
	    public static SessionFactory getSessionFactory() throws Exception {
	        if (sessionFactory == null) {
	            // loads configuration and mappings
	            Configuration configuration = new Configuration();
	            configuration.addAnnotatedClass(annotations.Employee.class);
	            configuration.configure();
	            ServiceRegistry serviceRegistry
	                = new StandardServiceRegistryBuilder()
	                    .applySettings(configuration.getProperties()).build();
	            
	            createDatabase(configuration, serviceRegistry);
	            
	            // builds a session factory from the service registry
	            sessionFactory = configuration.buildSessionFactory(serviceRegistry);           
	        }
	         
	        return sessionFactory;
	    }
	    
		private static void createDatabase(Configuration cfg, ServiceRegistry serviceRegistry) throws Exception {
			
			MetadataSources metadataSources =  new MetadataSources(serviceRegistry);
			MetadataBuilder metadataBuilder = metadataSources
				    .getMetadataBuilder(cfg.getStandardServiceRegistryBuilder().build());
			
			Metadata metadata = metadataBuilder.build();

			MetadataImplementor metadataImpl = (MetadataImplementor) metadata;
			SchemaExport schema = new SchemaExport(metadataImpl);
			schema.create(true, true);
			
		}
}
