package org.hibernate.test;

import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration(locations = {
        "classpath:/dataSourceContext.xml", "classpath:/configurerContext.xml"
})
public abstract class TestCaseForDAOComponents extends AbstractDatabaseTestCase {
}
