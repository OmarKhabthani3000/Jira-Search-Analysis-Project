package org.hibernate.test;

import java.io.InputStream;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dbunit.DefaultDatabaseTester;
import org.dbunit.IDatabaseTester;
import org.dbunit.database.DatabaseConfig;
import org.dbunit.database.DatabaseDataSourceConnection;
import org.dbunit.dataset.DataSetException;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ReplacementDataSet;
import org.dbunit.dataset.datatype.IDataTypeFactory;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.dataset.xml.FlatXmlProducer;
import org.dbunit.ext.hsqldb.HsqldbDataTypeFactory;
import org.dbunit.ext.mssql.MsSqlDataTypeFactory;
import org.dbunit.ext.mysql.MySqlDataTypeFactory;
import org.dbunit.operation.DatabaseOperation;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.xml.sax.InputSource;

/**
 * Base class for database driven tests. Setups database before each test from
 * XML data set. Data set is expected to be located in the same package as the
 * test case. Data set name is determined by method {@link #getDataSetName()}.
 * 
 * <p>Note: DataSource bean name must be 'dataSource'.</p>
 * 
 * <p>Required dependencies: spring-test, dbunit</p>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Rollback(true)
@Transactional(readOnly = false)
@Ignore
public class AbstractDatabaseTestCase {
    private static Log log = LogFactory.getLog(AbstractDatabaseTestCase.class);
    
    @Autowired
    @Qualifier("dataSource")
    private DataSource dataSource;
    private IDatabaseTester databaseTester;
    private IDataSet dataSet;

    public IDatabaseTester getDatabaseTester() {
		return databaseTester;
	}

	@Before
    public void setupDatabase() throws Exception {
    	createDatabaseTester();
        databaseTester.setDataSet(getDataSet());
        databaseTester.setSetUpOperation(DatabaseOperation.CLEAN_INSERT);
        databaseTester.onSetup();
    }
    
    protected void createDatabaseTester() throws Exception {
    	// We use TransactionAwareDataSourceProxy because it helps in cases 
    	// where we have to use JdbcTemplate to assert some values were persisted correctly in database
    	// See:
    	// http://stackoverflow.com/questions/8591487/getting-dbunit-to-work-with-hibernate-transaction
    	// http://tadaya.wordpress.com/2008/04/27/transaction-aware-datasource-use-dbunit-hibernate-in-spring/
        DatabaseDataSourceConnection connection = new DatabaseDataSourceConnection(new TransactionAwareDataSourceProxy(dataSource));
        DatabaseConfig databaseConfig = connection.getConfig();
        databaseConfig.setProperty(DatabaseConfig.PROPERTY_DATATYPE_FACTORY, getDataTypeFactory());
        databaseTester = new DefaultDatabaseTester(connection);
    }

    /**
     * Returns data type factory for DBUnit. Defaults to
     * {@link HsqldbDataTypeFactory}. Override this method if you wish to
     * provide another {@link IDataTypeFactory} implementation.
     * 
     * @return
     * @see HsqldbDataTypeFactory
     * @see MySqlDataTypeFactory
     * @see MsSqlDataTypeFactory
     */
	protected IDataTypeFactory getDataTypeFactory() {
		return new HsqldbDataTypeFactory();
	}

    protected IDataSet getDataSet() {
        if (this.dataSet == null) {
            String dataSetName = getDataSetName();

            if (log.isInfoEnabled()) {
                log.info("Using dataset: " + dataSetName);
            }
            
            try {
            	InputStream inputStream = getClass().getResourceAsStream(dataSetName);
				InputSource xmlSource = new InputSource(inputStream);
				FlatXmlProducer flatXMLProducer = new FlatXmlProducer(xmlSource );
				IDataSet flatXmlDataSet = new FlatXmlDataSet(flatXMLProducer );
                ReplacementDataSet replacementDataSet = new ReplacementDataSet(flatXmlDataSet);
                replacementDataSet.addReplacementObject("[NULL]", null);
                return replacementDataSet;
            }
            catch (DataSetException e) {
                String message = "Unable to create dataset: " + dataSetName;
                log.error(message);
                throw new RuntimeException(message, e);
            }
        }
        return this.dataSet;
    }
    

    /**
     * Returns the name to use for finding data set for the test case. Default
     * is "[test case class name]-dataset.xml". Override this method to specify
     * a different data set name to use.
     * 
     * @return
     */
    protected String getDataSetName() {
            String className = getClass().getSimpleName();
            return className + "-dataset.xml";
    }
    
    @After
    public void tearDownDatabase() throws Exception {
    	databaseTester.setTearDownOperation(DatabaseOperation.DELETE_ALL);
        databaseTester.onTearDown();
    }
}
