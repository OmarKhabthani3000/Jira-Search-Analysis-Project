package org.hibernate.test.entity.model;

import javax.persistence.Entity;

@Entity
public class EntityWithName extends org.hibernate.test.entity.model.Entity {
    private String name;

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }
}
