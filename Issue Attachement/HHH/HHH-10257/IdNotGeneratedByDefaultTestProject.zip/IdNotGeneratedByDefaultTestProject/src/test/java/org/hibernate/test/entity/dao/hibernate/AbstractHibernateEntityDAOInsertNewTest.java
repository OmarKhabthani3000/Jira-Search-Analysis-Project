package org.hibernate.test.entity.dao.hibernate;

import java.util.Date;

import org.hibernate.SessionFactory;
import org.hibernate.test.TestCaseForDAOComponents;
import org.hibernate.test.entity.model.EntityWithName;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class AbstractHibernateEntityDAOInsertNewTest extends TestCaseForDAOComponents {
    @Autowired
    SessionFactory sessionFactory;
    
    @Test
    public void testInsertNewWithoutId(){
        EntityWithName entityWithName = new EntityWithName();
        entityWithName.setCreated(new Date());
        entityWithName.setModified(new Date());
        entityWithName.setName("two");
        
        sessionFactory.getCurrentSession().saveOrUpdate(entityWithName);
        
        sessionFactory.getCurrentSession().flush();
    }
}