package org.hibernate.test.entity.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

@MappedSuperclass
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class Entity implements Serializable {
    private Integer id;
    private Integer version;
    private Date created;
    private Date modified;
    private Date deleted;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Integer getId(){
        return id;
    }

    public void setId(Integer id){
        this.id = id;
    }

    @Version
    public Integer getVersion(){
        return version;
    }

    public void setVersion(Integer version){
        this.version = version;
    }

    @Temporal(TemporalType.TIMESTAMP)
    @Column(nullable = false)
    public Date getCreated(){
        return created;
    }

    public void setCreated(Date created){
        this.created = created;
    }

    @Temporal(TemporalType.TIMESTAMP)
    public Date getModified(){
        return modified;
    }

    public void setModified(Date modified){
        this.modified = modified;
    }

    @Temporal(TemporalType.TIMESTAMP)
    public Date getDeleted(){
        return deleted;
    }

    public void setDeleted(Date deleted){
        this.deleted = deleted;
    }

    @Override
    public String toString(){
        StringBuilder value = new StringBuilder();
        value.append("id=");
        value.append(getId());
        value.append(",version=");
        value.append(getVersion());
        value.append(",created=");
        value.append(getCreated());
        value.append(",modified=");
        value.append(getModified());
        if(getDeleted() != null){
            value.append(",deleted=");
            value.append(getDeleted());
        }
        return value.toString();
    }
}