package hibernate.scroll_types;

public class A
{
  protected long id;
  protected int a;
}
