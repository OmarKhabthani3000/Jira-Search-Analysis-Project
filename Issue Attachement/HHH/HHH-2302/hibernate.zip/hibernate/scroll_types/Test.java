package hibernate.scroll_types;

import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test
{
  public static void main (String[] args)
  {
    try
    {
      Configuration config = new Configuration();
      config.configure("hibernate/scroll_types/hibernate.cfg.xml");
      SessionFactory factory = config.buildSessionFactory();
      Session session = factory.openSession();
      Transaction tx = session.beginTransaction();
      
      A a = new A();
      a.a = 1;
      session.save(a);
      session.flush();
      
      ScrollableResults scroll = session.createSQLQuery("select a from a").scroll(ScrollMode.FORWARD_ONLY);
      while (scroll.next())
      {
        Integer result = scroll.getInteger(0);
        System.out.println(result);
      }
      
      tx.commit();
      session.close();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}
