This example has been written for Glassfish v3.
It uses maven2 for building and deploying.

mvn clean package
mvn glassfish:deploy

with those instructions maven automatically creates a new domain called heatseekerdomain and deploy the simple ejb into it.

No database set up is needed because the error cames before the db connection.

Please, in pom.xml put the right directory of your glassfish installation (<glassfishDirectory>).

In my environment I put hibernate into glassfish/lib dir, I don't know other methods to use hibernate in glassfish, sorry.

I think there are no problems to deploy heatseeker-test.jar into other application server, but I'm able to set up maven only for glassfish.
