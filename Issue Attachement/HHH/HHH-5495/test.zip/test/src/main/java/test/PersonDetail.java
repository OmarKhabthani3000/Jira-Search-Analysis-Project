package test;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;


@Entity
public class PersonDetail {

	@Id
	@OneToOne
	private Person person;

	@Column( nullable = true )
	private int age;

	@Column( nullable = true )
	private String city;

	public PersonDetail() {
		super();
	}

	public Person getPerson() {
		return this.person;
	}

	public void setPerson( Person person ) {
		this.person = person;
	}

	public int getAge() {
		return this.age;
	}

	public void setAge( int age ) {
		this.age = age;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity( String city ) {
		this.city = city;
	}

}
