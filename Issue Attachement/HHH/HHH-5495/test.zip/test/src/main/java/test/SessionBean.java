package test;

import java.io.Serializable;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class SessionBean implements Serializable {
	private static final long serialVersionUID = 1L;

	@PersistenceContext(unitName="test-persistence")
	private EntityManager em;

	public SessionBean() {
	}

	public void doNothing() {
	}
}
