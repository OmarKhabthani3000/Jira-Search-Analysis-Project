package test;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;


@Entity
public class Person {

	@Id
	private String ssn;

	@Column( nullable = false )
	private String name;

	@Column( nullable = false )
	private String surname;
	
	@OneToOne( mappedBy = "person" )
	private PersonDetail personDetail;

	public Person() {
		super();
	}
	
	public String getSsn() {
		return this.ssn;
	}

	public void setSsn( String ssn ) {
		this.ssn = ssn;
	}

	public String getName() {
		return this.name;
	}

	public void setName( String name ) {
		this.name = name;
	}

	public String getSurname() {
		return this.surname;
	}

	public void setSurname( String surname ) {
		this.surname = surname;
	}

	public void setPersonDetail( PersonDetail personDetail ) {
		this.personDetail = personDetail;
	}

	public PersonDetail getPersonDetail() {
		return personDetail;
	}
}
