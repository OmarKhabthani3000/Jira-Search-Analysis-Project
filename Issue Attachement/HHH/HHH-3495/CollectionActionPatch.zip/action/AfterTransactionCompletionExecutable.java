package org.hibernate.action;

import java.io.Serializable;

import org.hibernate.HibernateException;

/**
 * AfterTransactionCompletionExecutable is responsible for cleaning
 * up after transactions.  Implementations should take care to not hold
 * on to unnecessary state since they will remain in memory until transaction
 * completion.
 * 
 * @author Tim Downey
 *
 */
public interface AfterTransactionCompletionExecutable {

	/**
	 * Called after the transaction completes
	 */
	public void afterTransactionCompletion(boolean success) throws HibernateException;

	/**
	 * What spaces (tables) are affected by this action?
	 */
	public Serializable[] getPropertySpaces();	
}
