package org.hibernate.action;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.cache.CacheKey;
import org.hibernate.cache.access.SoftLock;
import org.hibernate.persister.collection.CollectionPersister;

/**
 * CollectionAfterTransactionCompletionAction is called after transaction
 * completion for collection actions.
 * 
 * @author Tim Downey
 *
 */
public class CollectionAfterTransactionCompletionAction implements
		AfterTransactionCompletionExecutable, Serializable {

	private final CacheKey cacheKey;
	private transient CollectionPersister persister;
	private final SoftLock lock;
	private final Serializable[] propertySpaces;
	
	public CollectionAfterTransactionCompletionAction(CollectionPersister persister, 
			CacheKey cacheKey, SoftLock lock, Serializable[] propertySpaces) {
		this.cacheKey = cacheKey;
		this.persister = persister;
		this.lock = lock;
		this.propertySpaces = propertySpaces;
	}
	
	public void afterTransactionCompletion(boolean success)
			throws HibernateException {
		if (persister.hasCache()) {
			persister.getCacheAccessStrategy().unlockItem( cacheKey, lock );			
		}
	}
	
	public Serializable[] getPropertySpaces() {
		return propertySpaces;
	}

}
