package eu.xtrf.hibernate.bug.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Marek Guzowski
 */
@Entity
@Table(name="child_element")
public class ChildElement {

    @Id
    private Long id;

    @Column(name ="value")
    private String value = "anything goes";

    public ChildElement() {
    }

    public void setId(Long id) {
        this.id = id;
    }
}
