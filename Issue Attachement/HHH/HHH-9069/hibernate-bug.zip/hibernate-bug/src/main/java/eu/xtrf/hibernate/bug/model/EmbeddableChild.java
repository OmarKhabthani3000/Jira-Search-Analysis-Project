package eu.xtrf.hibernate.bug.model;

import org.hibernate.annotations.ForeignKey;
import org.hibernate.annotations.Formula;

import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

/**
 * @author Marek Guzowski
 */
@Embeddable
public class EmbeddableChild {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ELEMENT_ID", nullable = true)
    @ForeignKey(name = "ELEMENT_ID_CONSTRAINT")
    private ChildElement nullableElement;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ELEMENT2_ID", nullable = true)
    @ForeignKey(name = "ELEMENT2_ID_CONSTRAINT")
    private ChildElement nullableElement2;

    @Formula("0")
    private int element;

    @Transient
    private boolean transientField = false;

    public ChildElement getNullableElement() {
        return nullableElement;
    }

    public void setNullableElement(ChildElement nullableElement) {
        this.nullableElement = nullableElement;
    }

    public ChildElement getNullableElement2() {
        return nullableElement2;
    }

    public void setNullableElement2(ChildElement nullableElement2) {
        this.nullableElement2 = nullableElement2;
    }

    public int getElement() {
        return element;
    }

    public void setElement(int element) {
        this.element = element;
    }

    public boolean isTransientField() {
        return transientField;
    }

    public void setTransientField(boolean transientField) {
        this.transientField = transientField;
    }
}
