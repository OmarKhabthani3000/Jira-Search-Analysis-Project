package eu.xtrf.hibernate.bug.model;


import org.hibernate.annotations.ForeignKey;

import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Table;
import java.util.HashSet;
import java.util.Set;

/**
 * @author Marek Guzowski
 */
@Entity
@Table(name = "parent")
public class Parent {

    @Id
    private long id;

    @ElementCollection(fetch = FetchType.EAGER)
    @JoinTable(name = "PARENTS_CHILD",
            joinColumns = @JoinColumn(name = "PARENT_ID"))
    @ForeignKey(name = "PARENT_ID")
    @Embedded
    private Set<EmbeddableChild> children = new HashSet<EmbeddableChild>();

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Set<EmbeddableChild> getChildren() {
        return children;
    }

    public void addChild(EmbeddableChild child) {
        this.children.add(child);
    }

    public void setChildren(Set<EmbeddableChild> children) {
        this.children = children;
    }

    public void removeChild(EmbeddableChild child) {
        children.remove(child);
    }
}


