package eu.xtrf.hibernate.bug;

import eu.xtrf.hibernate.bug.model.ChildElement;
import eu.xtrf.hibernate.bug.model.EmbeddableChild;
import eu.xtrf.hibernate.bug.model.Parent;
import org.hibernate.Hibernate;
import org.hibernate.SessionFactory;
import org.postgresql.Driver;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.LocalSessionFactoryBean;
import org.springframework.orm.hibernate3.annotation.AnnotationSessionFactoryBean;
import org.springframework.transaction.support.TransactionSynchronizationUtils;

import java.util.HashSet;

/**
 * @author Marek Guzowski
 */
public class Runner {


    public static void main(String[] args) throws Exception {
        new Runner();
    }

    public Runner() throws Exception {
        SimpleDriverDataSource dataSource = new SimpleDriverDataSource();
        dataSource.setUrl("jdbc:postgresql://127.0.0.1:5432/bug");
        dataSource.setUsername("your-username");
        dataSource.setPassword("your-password");
        dataSource.setDriverClass(Driver.class);

        AnnotationSessionFactoryBean sessionFactoryBean = new AnnotationSessionFactoryBean();
        sessionFactoryBean.setConfigLocation(new ClassPathResource("hibernate.cfg.xml"));
        sessionFactoryBean.setPackagesToScan(new String[] {"eu.xtrf"});
        sessionFactoryBean.setDataSource(dataSource);

        sessionFactoryBean.afterPropertiesSet();

        SessionFactory sessionFactory = sessionFactoryBean.getObject();
        HibernateTemplate hibernateTemplate = new HibernateTemplate(sessionFactory);
        hibernateTemplate.setAllowCreate(true);
        hibernateTemplate.setAlwaysUseNewSession(false);


        Parent parent = new Parent();
        parent.setId(1L);
        hibernateTemplate.persist(parent);
        hibernateTemplate.flush();

        ChildElement element = new ChildElement();
        element.setId(1L);
        hibernateTemplate.persist(element);

        EmbeddableChild child1 = new EmbeddableChild();
        child1.setNullableElement(element);
        EmbeddableChild child2 = new EmbeddableChild();

        parent.addChild(child1);
        parent.addChild(child2);
        hibernateTemplate.update(parent);

        hibernateTemplate.clear();

        parent = hibernateTemplate.get(Parent.class, 1L);
        Thread.sleep(1000);
//        Hibernate.initialize(parent.getChildren());

        parent.removeChild(parent.getChildren().iterator().next());

        hibernateTemplate.update(parent);
    }
}
