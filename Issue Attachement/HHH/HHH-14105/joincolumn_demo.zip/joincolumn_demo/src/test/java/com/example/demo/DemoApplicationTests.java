package com.example.demo;

import java.util.List;
import java.util.UUID;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
@ActiveProfiles("test")
class DemoApplicationTests {
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private ProfileRepository profileRepository;

	private static UUID TEST_UUID = UUID.fromString("e6cc2986-eda5-4226-98e0-14698146981b");

	@BeforeEach
	void init() {
		productRepository.deleteAll();
		profileRepository.deleteAll();

		Profile profile = new Profile();
		profile.setId(new Profile.Id("name", TEST_UUID));
		profile.setAge(18);
		profileRepository.save(profile);
		Product product = new Product();
		product.setId(1);
		product.setProfile(profile);
		productRepository.save(product);
	}

	@Test
	@Transactional
	void testProductExists() {
		List<Product> products = productRepository.findAll();
		Product product = new Product(1, new Profile(new Profile.Id("name", TEST_UUID), 18));
		Assert.assertEquals(1, products.size());
		Assert.assertEquals(product, products.get(0));
	}

	@Test
	@Transactional
	void testProductFound() {
		List<Product> products = productRepository.findAllByProfileId(new Profile.Id("name", TEST_UUID));
		Product product = new Product(1, new Profile(new Profile.Id("name", TEST_UUID), 18));
		Assert.assertEquals(1, products.size());
		Assert.assertEquals(product, products.get(0));
	}

}
