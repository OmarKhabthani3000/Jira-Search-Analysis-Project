create table product ( id int primary key not null, name varchar(255) not null, last_name uuid not null );
create table profile ( name varchar(255) not null, last_name uuid not null, age int not null);
alter table profile add constraint profile_pkey primary key (name, last_name);
