package com.blueriq.hibernate.binding.entity;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "author")
public class AuthorEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "authorSequenceGenerator")
  @SequenceGenerator(name = "authorSequenceGenerator", sequenceName = "authors_s", initialValue = 1, allocationSize = 1)
  @Column(name = "id")
  private long id;

  @OneToMany(mappedBy = "author", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
  @OnDelete(action = OnDeleteAction.CASCADE)
  @Fetch(FetchMode.SUBSELECT)
  private final List<BookEntity> books = new ArrayList<>();

  public AuthorEntity() {

  }

  public long getId() {
    return id;
  }

  public Collection<BookEntity> getBooks() {
    return books;
  }
}
