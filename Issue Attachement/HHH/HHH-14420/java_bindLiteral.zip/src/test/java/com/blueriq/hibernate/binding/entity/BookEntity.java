package com.blueriq.hibernate.binding.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "book")
public class BookEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bookSequenceGenerator")
  @SequenceGenerator(name = "bookSequenceGenerator", sequenceName = "book_s", initialValue = 1, allocationSize = 1)
  @Column(name = "id")
  private long id;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "author", foreignKey = @ForeignKey(name = "fk_book_author"))
  private AuthorEntity author;

  public BookEntity() {

  }

  public long getId() {
    return id;
  }

  public AuthorEntity getAuthor() {
    return author;
  }

  public void setAuthor(AuthorEntity author) {
    this.author = author;
  }
}
