package com.blueriq.hibernate.binding.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.blueriq.hibernate.binding.entity.AuthorEntity;
import com.blueriq.hibernate.binding.entity.BookEntity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

public class hibernateTest {
  public static SessionFactory getSessionFactory(boolean useBind) {
    final StandardServiceRegistryBuilder standardServiceRegistryBuilder = new StandardServiceRegistryBuilder();

    Map<String, String> settings = new HashMap<>();
    settings.put("hibernate.connection.driver_class", "org.h2.Driver");
    settings.put("hibernate.connection.url", "jdbc:h2:mem:");
    settings.put("hibernate.connection.username", "sa");
    settings.put("hibernate.connection.password", "");
    settings.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
    settings.put("hibernate.hbm2ddl.auto", "create");
    settings.put("hibernate.show_sql", "true");
    settings.put("hibernate.format_sql", "true");
    settings.put("hibernate.cache.use_second_level_cache", "false");
    if (useBind) {
      settings.put("hibernate.criteria.literal_handling_mode", "BIND");
    }
    standardServiceRegistryBuilder.applySettings(settings);

    final StandardServiceRegistry registry = standardServiceRegistryBuilder.build();

    MetadataSources sources = new MetadataSources(registry);
    sources.addAnnotatedClass(AuthorEntity.class);
    sources.addAnnotatedClass(BookEntity.class);

    Metadata metadata = sources.getMetadataBuilder().build();

    return metadata.buildSessionFactory();
  }

  private void executeTest(SessionFactory sessionFactory) {
    final Session session = sessionFactory.openSession();
    Transaction transaction = session.beginTransaction();

    final BookEntity bookEntity = new BookEntity();

    final AuthorEntity authorEntity = new AuthorEntity();
    authorEntity.getBooks().add(bookEntity);
    bookEntity.setAuthor(authorEntity);
    session.save(authorEntity);
    transaction.commit();

    final CriteriaBuilder criteriaBuilder = sessionFactory.getCriteriaBuilder();

    final Object value = authorEntity.getId();

    final CriteriaQuery<BookEntity> criteriaQuery = criteriaBuilder.createQuery(BookEntity.class);
    final Root<BookEntity> root = criteriaQuery.from(BookEntity.class);

    criteriaQuery //
        .select(root) //
        .distinct(true) //
        .where(criteriaBuilder.equal(root.get("author"), value));

    final List<BookEntity> bookEntityList = session.createQuery(criteriaQuery).getResultList();

    session.close();

    assertNotNull(bookEntityList);
    assertEquals(1, bookEntityList.size());

    BookEntity firstBookEntity = bookEntityList.get(0);
    assertEquals(bookEntity.getId(), firstBookEntity.getId());
    assertEquals(authorEntity.getId(), firstBookEntity.getAuthor().getId());

  }

  @Test
  public void testAutoLiteralHandlingMode() {
    SessionFactory sessionFactory = getSessionFactory(false);
    try {
      executeTest(sessionFactory);
    } finally {
      sessionFactory.close();
    }
  }

  @Test
  public void testBindLiteralHandlingMode() {
    SessionFactory sessionFactory = getSessionFactory(true);
    try {
      executeTest(sessionFactory);
    } finally {
      sessionFactory.close();
    }
  }

}
