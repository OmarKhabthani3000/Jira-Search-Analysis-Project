package org.hibernate.test.a123;

import java.io.Serializable;

public class DocumentKey implements Serializable {

	private String key1;

	private String key2;

	private String documentType;

	public DocumentKey(String key1, String key2, String documentType) {
		this.key1 = key1;
		this.key2 = key2;
		this.documentType = documentType;
	}

	protected DocumentKey() {
	}

	/**
	 * @return Returns the key1.
	 */
	public String getKey1() {
		return key1;
	}

	/**
	 * @param key1
	 *            The key1 to set.
	 */
	public void setKey1(String key1) {
		this.key1 = key1;
	}

	/**
	 * @return Returns the key2.
	 */
	public String getKey2() {
		return key2;
	}

	/**
	 * @param key2
	 *            The key2 to set.
	 */
	public void setKey2(String key2) {
		this.key2 = key2;
	}

	/**
	 * @return Returns the documentType.
	 */
	public String getDocumentType() {
		return documentType;
	}

	/**
	 * @param documentType
	 *            The documentType to set.
	 */
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		DocumentKey other = (DocumentKey) obj;
		return other.key1.equals(this.key1) && other.key2.equals(this.key2)
				&& other.documentType.equals(this.documentType);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return key1.hashCode() + key2.hashCode() + documentType.hashCode();
	}

}
