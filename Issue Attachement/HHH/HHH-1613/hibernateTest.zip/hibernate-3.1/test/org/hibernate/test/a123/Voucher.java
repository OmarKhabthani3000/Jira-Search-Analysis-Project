package org.hibernate.test.a123;

public class Voucher extends BaseDocument {
    
    public Voucher(DocumentKey documentKey) {
		super(documentKey);
	}

    protected Voucher() {}   
}
