package org.hibernate.test.a123;

import java.util.List;

public class BaseDocument {
    protected DocumentKey documentKey;    
    private List advances;

    protected BaseDocument() {
    }
	public BaseDocument(DocumentKey documentKey) {
		this.documentKey = documentKey;
	}    
    public DocumentKey getDocumentKey() {
        return documentKey;
    }
    public void setDocumentKey(DocumentKey documentKey) {
        this.documentKey = documentKey;
    }
	public List getAdvances() {
		return advances;
	}
	public void setAdvances(List advances) {
		this.advances = advances;
	}
}
