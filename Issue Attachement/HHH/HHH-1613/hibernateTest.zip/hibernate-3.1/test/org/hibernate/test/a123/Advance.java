package org.hibernate.test.a123;



public class Advance {

	private long id;
	
	private DocumentKey documentKey;
	
	private double advanceAmount;
	
	protected Advance() {}

	/**
	 * @return Returns the id.
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id The id to set.
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return Returns the documentKey.
	 */
	public DocumentKey getDocumentKey() {
		return documentKey;
	}

	/**
	 * @param documentKey The documentKey to set.
	 */
	public void setDocumentKey(DocumentKey documentKey) {
		this.documentKey = documentKey;
	}

	/**
	 * @return Returns the advanceAmount.
	 */
	public double getAdvanceAmount() {
		return advanceAmount;
	}

	/**
	 * @param advanceAmount The advanceAmount to set.
	 */
	public void setAdvanceAmount(double advanceAmount) {
		this.advanceAmount = advanceAmount;
	}
}
