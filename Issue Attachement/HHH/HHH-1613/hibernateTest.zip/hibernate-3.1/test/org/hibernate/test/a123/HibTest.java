package org.hibernate.test.a123;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.TestCase;


public class HibTest extends TestCase {
    
    public HibTest(String x) {
        super(x);
    }
    
	protected boolean recreateSchema() {
		return false;
	}    
    
    protected String[] getMappings() {
        return new String[] { "a123/BaseDocument.hbm.xml", "a123/Advance.hbm.xml", "a123/Trip.hbm.xml" };
    }    

    public void testFoo() {
        Session s = openSession();
        Transaction t = s.beginTransaction();
        DocumentKey vchKey = new DocumentKey("A", "A", "VCH");
        Voucher v1 = new Voucher(vchKey);
        s.persist(v1);
        
        String refNumber = "ABC123";
        Trip t1 = new Trip(vchKey);
        t1.setRefNumber(refNumber);
        s.persist(t1);
        
        DocumentKey authKey = new DocumentKey("A", "A", "AUTH");
        Authorization a1 = new Authorization(authKey);
        s.persist(a1);
        
        Trip t2 = new Trip(authKey);
        t2.setRefNumber(refNumber);
        s.persist(t2);        
        
        Advance adv1 = new Advance();
        adv1.setDocumentKey(authKey);
        adv1.setAdvanceAmount(100.00);
        s.persist(adv1);
        Long id = new Long(adv1.getId());
        t.commit();
		s.close();
		
		s = openSession();
		t = s.beginTransaction();
		
//		adv1 = (Advance)s.load(Advance.class, id);
//		assertNotNull(adv1);
//		assertEquals(adv1.getDocumentKey(), authKey);
		
		a1 = (Authorization)s.load(Authorization.class, authKey);
		assertNotNull(a1);
		assertEquals(a1.getAdvances().size(), 1);
		List authAdvances = a1.getAdvances();
		System.out.println("*************** authAdvances: " + authAdvances);
		
        t.commit();
		s.close();		
		
		s = openSession();
		t = s.beginTransaction();
		
		v1 = (Voucher)s.load(Voucher.class, vchKey);
		assertNotNull(v1);
		List vchAdvances = v1.getAdvances();
		System.out.println("*************** vchAdvances: " + vchAdvances);
		assertEquals(v1.getAdvances().size(), 1);
		
		t.commit();
		s.close();
    }

}
