package org.hibernate.test.a123;





public class Authorization extends BaseDocument {
    
    public Authorization(DocumentKey documentKey) {
		super(documentKey);
	}

    protected Authorization() {}   
}
