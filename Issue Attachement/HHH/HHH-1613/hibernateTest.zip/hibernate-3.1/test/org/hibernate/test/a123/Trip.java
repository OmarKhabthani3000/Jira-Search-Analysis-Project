package org.hibernate.test.a123;

public class Trip {

	private DocumentKey documentKey;
	
	private String refNumber;
	
	protected Trip() {}
	
	public Trip(DocumentKey documentKey) {
		this.documentKey = documentKey;
	}

	/**
	 * @return Returns the documentKey.
	 */
	public DocumentKey getDocumentKey() {
		return documentKey;
	}

	/**
	 * @param documentKey The documentKey to set.
	 */
	public void setDocumentKey(DocumentKey documentKey) {
		this.documentKey = documentKey;
	}

	/**
	 * @return Returns the refNumber.
	 */
	public String getRefNumber() {
		return refNumber;
	}

	/**
	 * @param refNumber The refNumber to set.
	 */
	public void setRefNumber(String refNumber) {
		this.refNumber = refNumber;
	}
}
