package foo;

import static org.junit.Assert.fail;
import org.junit.Before;
import org.junit.Test;

import javax.naming.Context;
import javax.naming.InitialContext;

public class ManyToManyTestCase //extends junit.framework.TestCase
{
    public ManyToManyTest test;

    @Test
    public void testLinks() throws Exception
    {
        try
        {
            test.createA( 1 );
            test.createA( 2 );

            test.createB( 1 );

            test.addLinkA2B( 1, 1 );
            test.addLinkA2B( 2, 1 );

            test.createB( 2 );

            test.addLinkA2B( 1, 2 );
            test.addLinkA2B( 2, 2 );
        }
        catch( Exception e )
        {
            e.printStackTrace( );
            fail();
        }
        finally
        {
            try{test.removeA( 1 );}catch(Exception e){}
            try{test.removeA( 2 );}catch(Exception e){}
            try{test.removeB( 1 );}catch(Exception e){}
            try{test.removeB( 2 );}catch(Exception e){}
        }
    }

    @Before
    public void setUp() throws Exception
    {
        final Context ic = new InitialContext();
        final Object ref = ic.lookup( "ManyToManyTestEJB/remote" );
        final ManyToManyTestHome home = 
                ( ManyToManyTestHome )javax.rmi.PortableRemoteObject.narrow( ref, ManyToManyTestHome.class );
        test = home.create();
    }
}
