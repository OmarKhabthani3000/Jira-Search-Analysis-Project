/*
  Copyright 2006 SEC "Knowledge Genesis", Ltd.
  http://www.kg.ru, http://www.knowledgegenesis.com
  $HeadURL$
  $Author$
  $Revision$
  $Date::                           $
 */
package foo;

import javax.ejb.EJBHome;
import javax.ejb.CreateException;
import java.rmi.RemoteException;

public interface ManyToManyTestHome extends EJBHome
{
    ManyToManyTest create() throws RemoteException, CreateException;
}
