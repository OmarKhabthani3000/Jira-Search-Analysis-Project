package foo;

import org.hibernate.EntityMode;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.rmi.RemoteException;

//@Stateless( name = "ManyToManyTestEJB" )
//@Remote( ManyToManyTest.class )
public class ManyToManyTestBean implements SessionBean //implements ManyToManyTest
{
    public ManyToManyTestBean()
    {
    }

    public void createA( Integer id ) throws CreateException
    {
        final HashMap<String, Object> av = new HashMap<String, Object>( 1 );
        av.put( "id", id );
        create( "A", av );
    }

    public void createB( Integer id ) throws CreateException
    {
        final HashMap<String, Object> av = new HashMap<String, Object>( 1 );
        av.put( "id", id );
        create( "B", av );
    }

    public void removeA( Integer id ) throws RemoveException
    {
        remove( "A", id );
    }

    public void removeB( Integer id ) throws RemoveException
    {
        remove( "B", id );
    }

    public void addLinkA2B( Integer a_id, Integer b_id )
            throws FinderException, CreateException
    {
        final Session session = getSession();
        final Session dSession = session.getSession( EntityMode.MAP );
        try
        {
            final Map a_instance = ( Map )dSession.get( "A", a_id );
            if( a_instance == null )
            {
                throw new FinderException( "Add link failed for due to '" + a_id + "' not found" );
            }

            final Map b_instance = ( Map )dSession.get( "B", b_id );
            if( b_instance == null )
            {
                throw new FinderException( "Add link failed for due to '" + b_id + "' not found" );
            }

            final Collection links = ( Collection )a_instance.get( "Bs" );
            links.add( b_instance );

            dSession.flush();
        }
        catch( HibernateException e1 )
        {
            throw new CreateException( "Add link failed due to " + e1.toString() );
        }
        finally
        {
            session.close();
        }
    }

    protected void remove( final String entityName, final Integer id ) throws RemoveException
    {
        final Session session = getSession();
        final Session dSession = session.getSession( EntityMode.MAP );
        try
        {
            final Map entity = ( Map )dSession.get( entityName, id );
            if( entity != null )
            {
                dSession.delete( entityName, entity );
                dSession.flush();
            }
        }
        catch( HibernateException e1 )
        {
            throw new RemoveException( "Remove instance " + id + " failed due to " + e1.toString() );
        }
        finally
        {
            session.close();
        }
    }

    protected void create( final String entityName, final Map attrValues )
            throws CreateException
    {
        final Session session = getSession();
        final Session dSession = session.getSession( EntityMode.MAP );
        try
        {
            dSession.save( entityName, attrValues );
            dSession.flush();
        }
        catch( HibernateException e1 )
        {
            throw new CreateException( "Create entity object " + entityName +
                    " failed due to " + e1.toString() );
        }
        finally
        {
            session.close();
        }
    }

    private Session getSession()
    {
        final SessionFactory sessionFactory;
        try
        {
            final Context jndiContext = new InitialContext();
            sessionFactory = ( SessionFactory )jndiContext.lookup( "java:/hibernate/SessionFactory" );
        }
        catch( NamingException e )
        {
            throw new EJBException( e.toString() );
        }
        Session session = sessionFactory.getCurrentSession();
        if( session.isConnected() ) session = sessionFactory.openSession();
        return session;
    }

    public void ejbActivate()
    {
    }

    public void ejbPassivate()
    {
    }

    public void ejbRemove()
    {
    }

    public void setSessionContext( SessionContext sessionContext )
    {
    }

    public void ejbCreate()
    {
    }
}
