package foo;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;

//@Remote
public interface ManyToManyTest extends EJBObject
{
    void createA( Integer id ) throws CreateException, RemoteException;

    void createB( Integer id ) throws CreateException, RemoteException;

    void addLinkA2B( Integer a_id, Integer b_id )
            throws FinderException, CreateException, RemoteException;

    void removeA( Integer id ) throws RemoveException, RemoteException;

    void removeB( Integer id ) throws RemoveException, RemoteException;
}
