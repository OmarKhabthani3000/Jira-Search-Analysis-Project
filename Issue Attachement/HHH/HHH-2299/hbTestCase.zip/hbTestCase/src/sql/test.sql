create table TABLE_A (ID number(10,0) not null, primary key (ID) );
create table TABLE_B (ID number(10,0) not null, primary key (ID) );
create table TABLE_AB (A_ID number(10,0) not null, B_ID number(10,0) not null, primary key (A_ID, B_ID) );
