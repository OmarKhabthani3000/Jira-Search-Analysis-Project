package org.hibernate.hhh13560;

import java.util.List;

public class Matrix {
    protected String name;

    protected List<?>[] data;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<?>[] getData() {
        return data;
    }

    public void setData(List<?>[] data) {
        this.data = data;
    }
}
