package org.hibernate.hhh13560;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.type.StandardBasicTypes;
import org.hibernate.type.Type;
import org.hibernate.usertype.CompositeUserType;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class MatrixType implements CompositeUserType {

    @Override
    public String[] getPropertyNames() {
        return new String[] {
            "matrix_name",
            "matrix_data"
        };
    }

    @Override
    public Type[] getPropertyTypes() {
        return new Type[] {
            StandardBasicTypes.STRING,
            StandardBasicTypes.CLOB
        };
    }

    @Override
    public Object getPropertyValue(Object component, int property) throws HibernateException {
        Matrix matrix = (Matrix)component;
        switch (property) {
            case 0 : return matrix.getName();
            case 1 : return matrix.getData();
            default : throw new HibernateException("Property index invalid : " + property);
        }
    }

    @Override
    public void setPropertyValue(Object component, int property, Object value) throws HibernateException {
        Matrix matrix = (Matrix)component;
        switch (property) {
            case 0 : matrix.setName((String)value); break;
            case 1 : matrix.setData((List<?>[])value); break;
            default : throw new HibernateException("Property index invalid : " + property);
        }
    }

    @Override
    public Class returnedClass() {
        return Matrix.class;
    }

    @Override
    public boolean equals(Object x, Object y) throws HibernateException {
        if (x == y) {
            return true;
        } else if (x != null && y != null) {
            return x.equals(y);
        } else {
            return false;
        }
    }

    @Override
    public int hashCode(Object x) throws HibernateException {
        return x.hashCode();
    }

    @Override
    public Object nullSafeGet(ResultSet rs, String[] names, SharedSessionContractImplementor session, Object owner) throws HibernateException, SQLException {
        return null;
    }

    @Override
    public void nullSafeSet(PreparedStatement st, Object value, int index, SharedSessionContractImplementor session) throws HibernateException, SQLException {

    }

    @Override
    public Object deepCopy(Object value) throws HibernateException {
        return null;
    }

    @Override
    public boolean isMutable() {
        return false;
    }

    @Override
    public Serializable disassemble(Object value, SharedSessionContractImplementor session) throws HibernateException {
        return null;
    }

    @Override
    public Object assemble(Serializable cached, SharedSessionContractImplementor session, Object owner) throws HibernateException {
        return null;
    }

    @Override
    public Object replace(Object original, Object target, SharedSessionContractImplementor session, Object owner) throws HibernateException {
        return null;
    }
}
