package org.hibernate.hhh13560;

import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.UUID;

@Entity
public class Population {

    @Id
    protected UUID id;

    protected String name;

    @Type(type = "org.hibernate.hhh13560.MatrixType")
    @Columns(columns = {
        @Column(name="matrix_name"),
        @Column(name="matrix_data")
    })
    protected Matrix efffective;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Matrix getEfffective() {
        return efffective;
    }

    public void setEfffective(Matrix efffective) {
        this.efffective = efffective;
    }
}
