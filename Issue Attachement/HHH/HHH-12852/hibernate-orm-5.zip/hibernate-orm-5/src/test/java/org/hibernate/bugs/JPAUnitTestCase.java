package org.hibernate.bugs;

import org.hibernate.entity.TestEmbeddable;
import org.hibernate.entity.TestEntity;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void justPersistTest() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		//just provide id.
		TestEntity entity1 = new TestEntity();
        entity1.setId(1);
		entityManager.persist(entity1);
		//provide all properties.
        TestEntity entity2 = new TestEntity();
        entity2.setId(2);
        entity2.setIntValue(1);
        entity2.setStringValue("a");
        entity2.setValueWithDefault("b");
		TestEmbeddable embeddable = new TestEmbeddable();
		embeddable.setV1("a");
		embeddable.setV2("b");
		List<TestEmbeddable> embeddables = new ArrayList<>();
		embeddables.add(embeddable);
        entity2.setEmbeddables(embeddables);
		entityManager.persist(entity2);
        //just provide id. then update after persist
        TestEntity entity3= new TestEntity();
        entity3.setId(3);
        entityManager.persist(entity3);
        //provide all properties. then update after persist
        TestEntity entity4 = new TestEntity();
        entity4.setId(4);
        entity4.setIntValue(1);
        entity4.setStringValue("a");
        entity4.setValueWithDefault("b");
        embeddable = new TestEmbeddable();
        embeddable.setV1("a");
        embeddable.setV2("b");
        embeddables = new ArrayList<>();
        embeddables.add(embeddable);
        entity4.setEmbeddables(embeddables);
        entityManager.persist(entity4);
        entity3.setStringValue("a"); //just set stringValue
        entity4.setEmbeddables(embeddables); //set embeddables again, but not change it.

		entityManager.getTransaction().commit();
		Query query;
		Object[] result;
		query = entityManager.createNativeQuery("select id, rev, revtype, revend, revend_tstmp, stringValue, stringValue_MOD, intValue, intValue_MOD, valueWithDefault, valueWithDefault_MOD, embeddables_MOD, embeddablesWithDefault_MOD from TestEntity_AUD where id = ?");
		query.setParameter(1, 1);
        result = (Object[]) query.getSingleResult();
        Assert.assertEquals(1, ((Number) result[0]).intValue()); //id
        Assert.assertEquals(0, ((Number) result[2]).intValue()); //revType
        Assert.assertNull(result[3]); //revEnd
        Assert.assertNull(result[4]); //revEnd_tstmp
        Assert.assertNull(result[5]); //stringValue
        Assert.assertFalse((Boolean) result[6]); //stringValue_MOD
        Assert.assertEquals(0, result[7]); //intValue
        Assert.assertTrue((Boolean) result[8]); //intValue_MOD
        Assert.assertEquals("default", result[9]); //valueWithDefault
        Assert.assertTrue((Boolean) result[10]); //valueWithDefault_MOD
        Assert.assertFalse((Boolean) result[11]); //embeddables_MOD
        Assert.assertTrue((Boolean) result[12]); //embeddablesWithDefault_MOD

        query = entityManager.createNativeQuery("select id, rev, revtype, revend, revend_tstmp, stringValue, stringValue_MOD, intValue, intValue_MOD, valueWithDefault, valueWithDefault_MOD, embeddables_MOD, embeddablesWithDefault_MOD from TestEntity_AUD where id = ?");
        query.setParameter(1, 2);
        result = (Object[]) query.getSingleResult();
        Assert.assertEquals(2, ((Number) result[0]).intValue()); //id
        Assert.assertEquals(0, ((Number) result[2]).intValue()); //revType
        Assert.assertNull(result[3]); //revEnd
        Assert.assertNull(result[4]); //revEnd_tstmp
        Assert.assertEquals("a", result[5]); //stringValue
        Assert.assertTrue((Boolean) result[6]); //stringValue_MOD
        Assert.assertEquals(1, result[7]); //intValue
        Assert.assertTrue((Boolean) result[8]); //intValue_MOD
        Assert.assertEquals("b", result[9]); //valueWithDefault
        Assert.assertTrue((Boolean) result[10]); //valueWithDefault_MOD
        Assert.assertTrue((Boolean) result[11]); //embeddables_MOD
        Assert.assertTrue((Boolean) result[12]); //embeddablesWithDefault_MOD

        // we just change stringValue after persist. So only column stringValue should be changed.
        query = entityManager.createNativeQuery("select id, rev, revtype, revend, revend_tstmp, stringValue, stringValue_MOD, intValue, intValue_MOD, valueWithDefault, valueWithDefault_MOD, embeddables_MOD, embeddablesWithDefault_MOD from TestEntity_AUD where id = ?");
        query.setParameter(1, 3);
        result = (Object[]) query.getSingleResult();
        Assert.assertEquals(3, ((Number) result[0]).intValue()); //id
        Assert.assertEquals(0, ((Number) result[2]).intValue()); //revType
        Assert.assertNull(result[3]); //revEnd
        Assert.assertNull(result[4]); //revEnd_tstmp
        Assert.assertEquals("a", result[5]); //stringValue
        Assert.assertTrue((Boolean) result[6]); //stringValue_MOD
        Assert.assertEquals(0, result[7]); //intValue
        Assert.assertTrue((Boolean) result[8]); //intValue_MOD
        Assert.assertEquals("default", result[9]); //valueWithDefault
        Assert.assertTrue((Boolean) result[10]); //valueWithDefault_MOD
        Assert.assertFalse((Boolean) result[11]); //embeddables_MOD
        Assert.assertTrue((Boolean) result[12]); //embeddablesWithDefault_MOD

        // though we update the entity after persist, we change nothing. So the result should same as entity2.
        query = entityManager.createNativeQuery("select id, rev, revtype, revend, revend_tstmp, stringValue, stringValue_MOD, intValue, intValue_MOD, valueWithDefault, valueWithDefault_MOD, embeddables_MOD, embeddablesWithDefault_MOD from TestEntity_AUD where id = ?");
        query.setParameter(1, 4);
        result = (Object[]) query.getSingleResult();
        Assert.assertEquals(4, ((Number) result[0]).intValue()); //id
        Assert.assertEquals(0, ((Number) result[2]).intValue()); //revType
        Assert.assertNull(result[3]); //revEnd
        Assert.assertNull(result[4]); //revEnd_tstmp
        Assert.assertEquals("a", result[5]); //stringValue
        Assert.assertTrue((Boolean) result[6]); //stringValue_MOD
        Assert.assertEquals(1, result[7]); //intValue
        Assert.assertTrue((Boolean) result[8]); //intValue_MOD
        Assert.assertEquals("b", result[9]); //valueWithDefault
        Assert.assertTrue((Boolean) result[10]); //valueWithDefault_MOD
        Assert.assertTrue((Boolean) result[11]); //embeddables_MOD
        Assert.assertTrue((Boolean) result[12]); //embeddablesWithDefault_MOD

		entityManager.close();
	}
}
