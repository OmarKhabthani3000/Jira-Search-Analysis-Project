package org.hibernate.entity;

import org.hibernate.envers.Audited;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OrderColumn;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by vipcxj on 2018/7/25.
 */
@Audited
@Entity
public class TestEntity {
    @Id
    private long id;
    private String stringValue;
    private int intValue;
    private String valueWithDefault = "default";
    @OrderColumn
    @ElementCollection
    private List<TestEmbeddable> embeddables;
    @OrderColumn
    @ElementCollection
    private List<TestEmbeddable> embeddablesWithDefault = new ArrayList<>();

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getStringValue() {
        return stringValue;
    }

    public void setStringValue(String stringValue) {
        this.stringValue = stringValue;
    }

    public int getIntValue() {
        return intValue;
    }

    public void setIntValue(int intValue) {
        this.intValue = intValue;
    }

    public String getValueWithDefault() {
        return valueWithDefault;
    }

    public void setValueWithDefault(String valueWithDefault) {
        this.valueWithDefault = valueWithDefault;
    }

    public List<TestEmbeddable> getEmbeddables() {
        return embeddables;
    }

    public void setEmbeddables(List<TestEmbeddable> embeddables) {
        this.embeddables = embeddables;
    }

    public List<TestEmbeddable> getEmbeddablesWithDefault() {
        return embeddablesWithDefault;
    }

    public void setEmbeddablesWithDefault(List<TestEmbeddable> embeddablesWithDefault) {
        this.embeddablesWithDefault = embeddablesWithDefault;
    }
}
