package com.isencia.sherpa.test;
import java.sql.Connection;
import java.util.List;
import java.util.Set;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import com.isencia.sherpa.security.authorization.persistence.ApplicationGroup;
import com.isencia.sherpa.security.authorization.persistence.ApplicationRole;
import com.isencia.sherpa.security.authorization.persistence.ApplicationUser;
import com.isencia.sherpa.security.authorization.persistence.Principal;
import com.isencia.sherpa.security.authorization.persistence.PrincipalPrincipal;

@SuppressWarnings("unchecked")
public class HibernateTest extends TestCase {
    SessionFactory sf;
    Session s;
    Connection conn;

    protected void setUp() throws Exception {
        sf = new AnnotationConfiguration().addAnnotatedClass(Principal.class).addAnnotatedClass(ApplicationUser.class).addAnnotatedClass(
                ApplicationGroup.class).addAnnotatedClass(ApplicationRole.class).addAnnotatedClass(PrincipalPrincipal.class)
                .setProperty("hibernate.show_sql", "true").setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:security").setProperty(
                        "hibernate.connection.username", "sa").setProperty("hibernate.connection.password", "").setProperty(
                        "hibernate.connection.driver_class", "org.hsqldb.jdbcDriver").setProperty("hibernate.dialect",
                        "org.hibernate.dialect.HSQLDialect").buildSessionFactory();

        s = sf.openSession();
        s.connection().createStatement().execute(
                        "create table SHB_Principal (TYPE integer not null, ID integer , NAME varchar(250) not null, STATUS integer, E_MAIL varchar(250), FIRST_NAME varchar(50), LAST_NAME varchar(50), LOGON_ATTEMPTS integer, PASSWORD varchar(250), PASSWORD_EXPIRE_DATE timestamp, primary key (ID))");
        s.connection().createStatement().execute(
                        "create table SHB_PrincipalToPrincipal (ID integer , TO_PRINCIPAL_ID integer, FROM_PRINCIPAL_ID integer)");
        s.connection().createStatement().execute(
                "insert into shb_principal(ID,TYPE,NAME,STATUS,FIRST_NAME,LAST_NAME,PASSWORD) values(1,0,'geewim',1,'Wim','Geeraerts','passwd')");

        s.connection().createStatement().execute("insert into SHB_Principal (ID, NAME, STATUS, TYPE) values (2, 'role1', 1, 1)");
        s.connection().createStatement().execute("insert into SHB_Principal (ID, NAME, STATUS, TYPE) values (3, 'role2', 1, 1)");
        s.connection().createStatement().execute("insert into SHB_Principal (ID, NAME, STATUS, TYPE) values (4, 'group1', 1, 2)");
        s.connection().createStatement().execute("insert into SHB_Principal (ID, NAME, STATUS, TYPE) values (5, 'group2', 1, 2)");

        s.connection().createStatement().execute("insert into SHB_PRINCIPALTOPRINCIPAL(TO_PRINCIPAL_ID,FROM_PRINCIPAL_ID) VALUES (5,1)");
        s.connection().createStatement().execute("insert into SHB_PRINCIPALTOPRINCIPAL(TO_PRINCIPAL_ID,FROM_PRINCIPAL_ID) VALUES (4,1)");
        s.connection().createStatement().execute("insert into SHB_PRINCIPALTOPRINCIPAL(TO_PRINCIPAL_ID,FROM_PRINCIPAL_ID) VALUES (3,1)");
        s.connection().createStatement().execute("insert into SHB_PRINCIPALTOPRINCIPAL(TO_PRINCIPAL_ID,FROM_PRINCIPAL_ID) VALUES (2,1)");
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testGroupsAndRoles() throws Exception {
        List<ApplicationUser> users = s.createQuery("from ApplicationUser au where au.name = 'geewim'").list();
        assertEquals(1, users.size());
        assertEquals("geewim", users.get(0).getName());
        //assertEquals(2, users.get(0).getRoles().size());
        //assertEquals(2, users.get(0).getGroups().size());
        
        Set<ApplicationGroup> groups = users.get(0).getGroups();
        //assertEquals(2, groups.size());
        for (ApplicationGroup applicationGroup : groups) {
            System.out.println(applicationGroup.getName());
        }

        
        Set<ApplicationRole> roles = users.get(0).getRoles();
        //assertEquals(2, roles.size());
        for (ApplicationRole applicationRole : roles) {
            System.out.println(applicationRole.getName());
        }
    }

}
