package com.isencia.sherpa.security.authorization.persistence;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import com.isencia.sherpa.security.authorization.persistence.enums.PrincipalType;

@Entity
@DiscriminatorValue(PrincipalType.ROLE_NR)
public class ApplicationRole extends Principal {

	private static final long serialVersionUID = 1L;
	
	public final static String _USERS = "users";
	
	@ManyToMany(fetch=FetchType.LAZY, cascade={CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH})
	@JoinTable(name="SHB_PrincipalToPrincipal",
		joinColumns=@JoinColumn(name="TO_PRINCIPAL_ID"),
		inverseJoinColumns=@JoinColumn(name="FROM_PRINCIPAL_ID"))		
	// TODO This is included due to a bug? in Hibernate. (No Discriminator when using Inheritance with ManyToMany) 
//	@Where(clause=Principal._TYPE+"="+PrincipalType.USER_NR) 	
	private Set<ApplicationUser> users;
	
	public ApplicationRole() {
		super();
		this.type = PrincipalType.ROLE;
	}

	public Set<ApplicationUser> getUsers() {
		return users;
	}
	public void setUsers(Set<ApplicationUser> users) {
		this.users = users;
	}

}