package com.isencia.sherpa.security.authorization.persistence;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.isencia.sherpa.security.authorization.persistence.enums.PrincipalType;


@Entity
@Table(name="SHB_Principal")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="TYPE",discriminatorType=DiscriminatorType.INTEGER)
public class Principal implements Serializable, Comparable<Principal>{
	
	private static final long serialVersionUID = 1L;
	
	public final static String _ID = "id";
	public final static String _TYPE = "type";
	public final static String _NAME = "name";
	public final static String _STATUS = "status";
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private Integer id;
	
	@Transient
	protected PrincipalType type;
	
	@Column(name="NAME",length=250,nullable=false)
	private String name;
	
	@Column(name="STATUS",length=10)
	private Boolean status;
	
	
	public Principal() {
		super();
		
		status = true;
	}

	public Integer getId() {
		return this.id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	
	public PrincipalType getType() {
		return type;
	}
	/**
	 * Returns <code>true</code> if this <code>Principal</code> is the same as the o argument.
	 *
	 * @return <code>true</code> if this <code>Principal</code> is the same as the o argument.
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null) {
			return false;
		}
		if (o.getClass() != getClass()) {
			return false;
		}
		Principal castedObj = (Principal) o;
		return ((this.id == null ? castedObj.id == null : this.id
			.equals(castedObj.id)));
	}

	@Override
	public String toString() {
		return getName();
	}

	/**
	 * Override hashCode.
	 *
	 * @return the Objects hashcode.
	 */
	@Override
	public int hashCode() {
		int hashCode = 1;
		hashCode = 31
			* hashCode
			+ (int) (+serialVersionUID ^ (serialVersionUID >>> 32));
		hashCode = 31 * hashCode + (id == null ? 0 : id.hashCode());
		hashCode = 31 * hashCode + (type == null ? 0 : type.hashCode());
		hashCode = 31 * hashCode + (name == null ? 0 : name.hashCode());
		hashCode = 31 * hashCode + (status == null ? 0 : status.hashCode());
		return hashCode;
	}
	
	public int compareTo(Principal o) {
		int result = 0;
		result = o.getType().compareTo(getType());
		if( result!= 0 )
			return result;
		return (o.getName().compareTo(getName()));
	}

	
}