package com.isencia.sherpa.security.authorization.persistence;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Transient;

import com.isencia.sherpa.security.authorization.persistence.enums.PrincipalType;


@Entity
@DiscriminatorValue(PrincipalType.USER_NR)
public class ApplicationUser extends Principal {
	private static final long serialVersionUID = 1L;
	
		
	public final static String _FIRSTNAME = "firstname";
	public final static String _LASTNAME = "lastname";
	public final static String _EMAIL = "email";
	public final static String _PASSWORD = "password";
	public static final String _PASSWORD_EXPIRE_DATE = "passwordExpireDate";
	public static final String _LOGON_ATTEMPTS = "logonAttempts";
	public final static String _ROLES = "roles";
	public final static String _GROUPS = "groups";
	
	public static final String _OLDPASSWORD = "oldpwd";
	public static final String _NEWPASSWORD = "newpwd";
	public static final String _CONFIRMEDPASSWORD = "confirmpwd";
	
	
	@Column(name="FIRST_NAME",length=50)
	private String firstname;
	
	@Column(name="LAST_NAME",length=50)
	private String lastname;
	
	@Column(name="E_MAIL",length=250)
	private String email;
	
	@Column(name="PASSWORD",length=250)
	private String password;
	
	@Column(name="PASSWORD_EXPIRE_DATE",length=20)
	private Date passwordExpireDate;
	
	@Column(name="LOGON_ATTEMPTS")
	private Integer logonAttempts;

	@ManyToMany(fetch=FetchType.LAZY, cascade={CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH},
			targetEntity=ApplicationRole.class)
	@JoinTable(name="SHB_PrincipalToPrincipal",
		joinColumns=@JoinColumn(name="FROM_PRINCIPAL_ID"),
		inverseJoinColumns=@JoinColumn(name="TO_PRINCIPAL_ID"))
	// TODO This is included due to a bug in Hibernate. (No Discriminator when using Inheritance with ManyToMany) 
	//@Where(clause=Principal._TYPE+"="+PrincipalType.ROLE_NR) 	
	private Set<ApplicationRole> roles;
	
	@ManyToMany(fetch=FetchType.LAZY, cascade={CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH},
			targetEntity=ApplicationGroup.class)
	@JoinTable(name="SHB_PrincipalToPrincipal",
		joinColumns=@JoinColumn(name="FROM_PRINCIPAL_ID"),
		inverseJoinColumns=@JoinColumn(name="TO_PRINCIPAL_ID"))		
	// TODO This is included due to a bug in Hibernate. (No Discriminator when using Inheritance with ManyToMany) 
	//@Where(clause=Principal._TYPE+"="+PrincipalType.GROUP_NR) 	
	private Set<ApplicationGroup> groups;
	
	@Transient
	private String oldpwd;
	
	@Transient
	private String newpwd;
	
	@Transient
	private String confirmpwd;
	
	
	public ApplicationUser() {
		super();
		this.type = PrincipalType.USER;
	}	

	public ApplicationUser(String userName) {
		super();
		setName(userName);
	}
	
	public Set<ApplicationRole> getRoles() {
		return roles;
	}
	public void setRoles(Set<ApplicationRole> roles) {
		this.roles = roles;
	}

	public Set<ApplicationGroup> getGroups() {
		return groups;
	}
	public void setGroups(Set<ApplicationGroup> groups) {
		this.groups = groups;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getPasswordExpireDate() {
		return passwordExpireDate;
	}

	public void setPasswordExpireDate(Date passwordExpireDate) {
		this.passwordExpireDate = passwordExpireDate;
	}

	public Integer getLogonAttempts() {
		return logonAttempts;
	}

	public void setLogonAttempts(Integer logonAttempts) {
		this.logonAttempts = logonAttempts;
	}

	public String getOldpwd() {
		return oldpwd;
	}

	public void setOldpwd(String oldpwd) {
		this.oldpwd = oldpwd;
	}

	public String getNewpwd() {
		return newpwd;
	}

	public void setNewpwd(String newpwd) {
		this.newpwd = newpwd;
	}

	public String getConfirmpwd() {
		return confirmpwd;
	}

	public void setConfirmpwd(String confirmpwd) {
		this.confirmpwd = confirmpwd;
	}
}