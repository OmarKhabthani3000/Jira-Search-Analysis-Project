package com.isencia.sherpa.security.authorization.persistence;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="SHB_PrincipalToPrincipal")
public class PrincipalPrincipal implements Serializable, Comparable<PrincipalPrincipal> {
	
	public final static String _ID = "id";
	public final static String _FROM_PRINCIPAL = "fromPrincipal";
	public final static String _TO_PRINCIPAL = "toPrincipal";
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private Integer id;

	@ManyToOne 
	@JoinColumn(name="FROM_PRINCIPAL_ID")
	private Principal fromPrincipal;
	
	@ManyToOne 
	@JoinColumn(name="TO_PRINCIPAL_ID")
	private Principal toPrincipal;
	
	public PrincipalPrincipal() {
		super();
	}

	public Integer getId() {
		return this.id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public Principal getFromPrincipal() {
		return fromPrincipal;
	}

	public void setFromPrincipal(Principal fromPrincipal) {
		this.fromPrincipal = fromPrincipal;
	}

	public Principal getToPrincipal() {
		return toPrincipal;
	}

	public void setToPrincipal(Principal toPrincipal) {
		this.toPrincipal = toPrincipal;
	}

	public int compareTo(PrincipalPrincipal o) {
		int result = 0;
		Principal oToPrincipal = o.getToPrincipal();
		if( oToPrincipal==null || toPrincipal==null)
			return result;
		return toPrincipal.compareTo(oToPrincipal);
	}
}