package com.isencia.sherpa.security.authorization.persistence.enums;



public enum PrincipalType {
	USER,
	ROLE,
	GROUP;
	
	public final static String USER_NR="0";
	public final static String ROLE_NR="1";
	public final static String GROUP_NR="2";
}
