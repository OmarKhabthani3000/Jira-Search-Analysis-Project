package org.hibernate.bugs.interceptor;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class GlobalInterceptorTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		MyIntegrator.resetInstallCount();
		GlobalInterceptor.resetPersistCount();
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void interceptPersistTest() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		assertEquals(1, MyIntegrator.getInstallCount());
		assertEquals(0, GlobalInterceptor.getPersistCount());
		
		Event event = new Event( new Date() );
	    entityManager.persist( event );

	    assertEquals(1, GlobalInterceptor.getPersistCount());
	    
	    Event dbEvent = entityManager.createQuery(
	            "select e " +
	            "from Event e", Event.class)
	        .getSingleResult();
	    assertEquals(event.getCreatedOn(), dbEvent.getCreatedOn());
		
		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
}
