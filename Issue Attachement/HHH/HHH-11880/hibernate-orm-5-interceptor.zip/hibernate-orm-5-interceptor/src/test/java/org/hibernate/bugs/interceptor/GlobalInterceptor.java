package org.hibernate.bugs.interceptor;

import java.io.Serializable;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;
import org.jboss.logging.Logger;

public class GlobalInterceptor extends EmptyInterceptor {
	private static final long serialVersionUID = -8430823977556222622L;
	private static Logger logger = Logger.getLogger(MyIntegrator.class);
	
	private static int persistCount = 0;
	
	public static int getPersistCount() {
		return persistCount;
	}
	
	public static void resetPersistCount() {
		persistCount = 0;
	}
	
	@Override
	public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
		logger.info("Intercept onSave: " + entity);
		persistCount++;
		return false;
	}
	
}