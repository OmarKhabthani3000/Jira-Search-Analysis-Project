package org.hibernate.bugs.interceptor;

import org.hibernate.boot.Metadata;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.integrator.spi.Integrator;
import org.hibernate.service.spi.SessionFactoryServiceRegistry;
import org.jboss.logging.Logger;

public class MyIntegrator implements Integrator {
	private static Logger logger = Logger.getLogger(MyIntegrator.class);
	
	private static int installCount = 0;
	
	public static int getInstallCount() {
		return installCount;
	}
	
	public static void resetInstallCount() {
		installCount = 0;
	}
	
	@Override
	public void integrate(Metadata metadata, SessionFactoryImplementor sessionFactory, SessionFactoryServiceRegistry serviceRegistry) {
		logger.info("Installing GlobalInterceptor ...");
		metadata.getSessionFactoryBuilder().applyInterceptor(new GlobalInterceptor());
		installCount++;
	}

	@Override
	public void disintegrate(SessionFactoryImplementor sessionFactory, SessionFactoryServiceRegistry serviceRegistry) {
	}

}
