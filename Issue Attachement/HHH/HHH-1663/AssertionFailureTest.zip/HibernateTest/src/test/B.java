package test;

import java.util.HashSet;
import java.util.Set;

/**
 * @author herschke
 * @since 12.04.2006
 */
public class B
{
	private Set<A> as = new HashSet<A>();
	private String idx;
	/**
	 * @return Returns the as.
	 * @since 12.04.2006
	 * @author herschke
	 */
	public Set<A> getAs()
	{
		return as;
	}
	/**
	 * @param as The as to set.
	 * @since 12.04.2006
	 * @author herschke
	 */
	public void setAs(Set<A> as)
	{
		this.as = as;
	}
	/**
	 * @return Returns the idx.
	 * @since 12.04.2006
	 * @author herschke
	 */
	public String getIdx()
	{
		return idx;
	}
	/**
	 * @param idx The idx to set.
	 * @since 12.04.2006
	 * @author herschke
	 */
	public void setIdx(String idx)
	{
		this.idx = idx;
	}
}
