package test;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaUpdate;

/**
 * @author herschke
 * @since 12.04.2006
 */
public class Test
{

	public static void main(String[] args) throws Exception
	{
		Configuration cfg = new Configuration();
		cfg.configure("/resources/hibernate.ora.cfg.xml");
		cfg.addResource("test/A.hbm.xml");
		cfg.addResource("test/B.hbm.xml");
		new SchemaUpdate(cfg).execute(false, true);
		SessionFactory sf = cfg.buildSessionFactory();
		
		// create test
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();
		
		A a = new A();
		Serializable idx = s.save(a);
		B b = new B();
		s.save(b);
		
		a.setAny(b);
		s.update(a);
		
		b.getAs().add(a);
		s.update(b);
		
		tx.commit();
		s.close();
		
		// modify test
		s = sf.openSession();
		tx = s.beginTransaction();

		A a2 = (A)s.get(A.class, idx);
		a2.setTest("hallo!");
		s.update(a2);
		
		tx.commit();
		s.close();
		
		// ready
		sf.close();
		
	}
}
