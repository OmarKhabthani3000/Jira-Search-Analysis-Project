package test;
/**
 * @author herschke
 * @since 12.04.2006
 */
public class C
{
	private A a;
	private String idx;
	/**
	 * @return Returns the a.
	 * @since 12.04.2006
	 * @author herschke
	 */
	public A getA()
	{
		return a;
	}
	/**
	 * @param a The a to set.
	 * @since 12.04.2006
	 * @author herschke
	 */
	public void setA(A a)
	{
		this.a = a;
	}
	/**
	 * @return Returns the idx.
	 * @since 12.04.2006
	 * @author herschke
	 */
	public String getIdx()
	{
		return idx;
	}
	/**
	 * @param idx The idx to set.
	 * @since 12.04.2006
	 * @author herschke
	 */
	public void setIdx(String idx)
	{
		this.idx = idx;
	}
}
