package test;

/**
 * @author herschke
 * @since 12.04.2006
 */
public class A
{
	private Object any;
	private String idx;
	private String test;

	/**
	 * @return Returns the idx.
	 * @since 12.04.2006
	 * @author herschke
	 */
	public String getIdx()
	{
		return idx;
	}

	/**
	 * @param idx
	 *            The idx to set.
	 * @since 12.04.2006
	 * @author herschke
	 */
	public void setIdx(String idx)
	{
		this.idx = idx;
	}

	/**
	 * @return Returns the test.
	 * @since 12.04.2006
	 * @author herschke
	 */
	public String getTest()
	{
		return test;
	}

	/**
	 * @param test
	 *            The test to set.
	 * @since 12.04.2006
	 * @author herschke
	 */
	public void setTest(String test)
	{
		this.test = test;
	}

	/**
	 * @return Returns the any.
	 * @since 12.04.2006
	 * @author herschke
	 */
	public Object getAny()
	{
		return any;
	}

	/**
	 * @param any
	 *            The any to set.
	 * @since 12.04.2006
	 * @author herschke
	 */
	public void setAny(Object any)
	{
		this.any = any;
	}
}
