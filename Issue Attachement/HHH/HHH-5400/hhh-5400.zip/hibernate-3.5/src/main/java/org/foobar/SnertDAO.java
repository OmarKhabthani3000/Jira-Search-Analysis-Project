package org.foobar;

import javax.inject.Inject;

import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class SnertDAO {
	
	@Inject
	private SessionFactory sessionFactory;
	
	@Transactional
	public void persist(Snert snert) {
		sessionFactory.getCurrentSession().save(snert);
	}

	@Transactional
	public void merge(Snert snert) {
		sessionFactory.getCurrentSession().merge(snert);
	}

	@Transactional
	public void remove(Snert snert) {
		sessionFactory.getCurrentSession().delete(snert);
	}
}
