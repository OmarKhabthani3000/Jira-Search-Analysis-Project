package org.hibernate.bugs.models;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Parent {

    private Integer id;
    private Set<Child> children = new HashSet<Child>();
    private int nrOfChildren;
    
    public Parent() {
        
    }
    
    @Id
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    @OneToMany(mappedBy="daddy", cascade= CascadeType.ALL)
    public Set<Child> getChildren() {
        return children;
    }
    public void setChildren(Set<Child> children) {
        this.children = children;
    }

}