/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.BootstrapServiceRegistryBuilder;
import org.hibernate.bugs.listeners.DummyLoadListener;
import org.hibernate.bugs.models.Child;
import org.hibernate.bugs.models.Parent;
import org.hibernate.cfg.Configuration;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.event.service.spi.EventListenerRegistry;
import org.hibernate.event.spi.EventType;
import org.hibernate.integrator.spi.Integrator;
import org.hibernate.metamodel.source.MetadataImplementor;
import org.hibernate.service.spi.SessionFactoryServiceRegistry;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;

public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	// Add your entities here.
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
				Parent.class,
				Child.class
		};
	}

	@Override
	protected void prepareBootstrapRegistryBuilder(BootstrapServiceRegistryBuilder builder) {
		super.prepareBootstrapRegistryBuilder(builder);
		builder.with(
				new Integrator() {

					@Override
					public void integrate(
							Configuration configuration,
							SessionFactoryImplementor sessionFactory,
							SessionFactoryServiceRegistry serviceRegistry) {
						integrate(serviceRegistry);
					}

					@Override
					public void integrate(MetadataImplementor metadata,
										  SessionFactoryImplementor sessionFactory,
										  SessionFactoryServiceRegistry serviceRegistry) {
						integrate(serviceRegistry);
					}

					private void integrate(SessionFactoryServiceRegistry serviceRegistry) {
						serviceRegistry.getService(EventListenerRegistry.class).prependListeners(EventType.LOAD,
								new DummyLoadListener());
					}

					@Override
					public void disintegrate(
							SessionFactoryImplementor sessionFactory, SessionFactoryServiceRegistry serviceRegistry) {
					}
				}
		);
	}

	@Test
	public void hhh123Test() throws Exception {
		Session s = openSession();
		Transaction tx = s.beginTransaction();
		Child child = new Child();
		child.setId(1);
		Parent daddy = new Parent();
		daddy.setId(1);
		child.setDaddy(daddy);
		child.setName("steve");
		Set<Child> children = new HashSet<Child>();
		children.add(child);
		daddy.setChildren(children);

		s.persist(daddy);
		s.flush();
		s.clear();

		daddy = (Parent) s.load(Parent.class, 1);
		assertEquals(1, daddy.getChildren().size());
		tx.commit();
		s.close();
	}
}
