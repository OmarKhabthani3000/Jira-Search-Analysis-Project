package org.hibernate.bugs.listeners;

import org.hibernate.bugs.models.Child;
import org.hibernate.engine.spi.EntityKey;
import org.hibernate.event.internal.DefaultLoadEventListener;
import org.hibernate.event.spi.LoadEvent;
import org.hibernate.persister.entity.EntityPersister;

import static org.junit.Assert.assertNotNull;


public class DummyLoadListener
        extends DefaultLoadEventListener {

    @Override
    protected Object load(LoadEvent event, EntityPersister persister, EntityKey keyToLoad, LoadType options) {
        Object loaded = super.load(event, persister, keyToLoad, options);
        setSomeValue(loaded);

        return loaded;
    }

    private void setSomeValue(Object loaded) {
        if (loaded instanceof Child) {
            Child child = (Child) loaded;
            assertNotNull(child.getName());
        }
    }
}
