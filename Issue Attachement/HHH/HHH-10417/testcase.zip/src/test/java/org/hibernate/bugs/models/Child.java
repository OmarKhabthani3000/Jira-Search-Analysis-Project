package org.hibernate.bugs.models;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Child {

    private Integer id;
    private Parent daddy;
    private String name;

    public Child() {
        
    }
    
    @Id
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    @ManyToOne
    public Parent getDaddy() {
        return daddy;
    }
    public void setDaddy(Parent daddy) {
        this.daddy = daddy;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}