/*
 * Copyright (C) 2007-2008 by Netcetera AG.
 * All rights reserved.
 *
 * The copyright to the computer program(s) herein is the property of
 * Netcetera AG, Switzerland. The program(s) may be used and/or copied
 * only with the written permission of Netcetera AG or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the program(s) have been supplied.
 *
 * @(#) $Id: Person.java,v 1.2 2009/05/08 12:48:27 corsin Exp $
 */
package ch.stefanrufer.hibernate4594;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Person DTO.
 */
@Entity
public class Person implements Serializable {

  /** Serialization identifier. */
  private static final long serialVersionUID = -6960875845511184261L;

  /** Identifier. */
  @Id
  private String id;

  /**
   * Name field/column.
   */
  private String name;

  /**
   * Get the id.
   * 
   * @return the id
   */
  public String getId() {
    return this.id;
  }

  /**
   * Set the id.
   * 
   * @param id the id to set
   */
  public void setId(final String id) {
    this.id = id;
  }

  /**
   * Get the name.
   * 
   * @return the name
   */
  public String getName() {
    return this.name;
  }

  /**
   * Set the name.
   * 
   * @param name the name to set
   */
  public void setName(final String name) {
    this.name = name;
  }

}
