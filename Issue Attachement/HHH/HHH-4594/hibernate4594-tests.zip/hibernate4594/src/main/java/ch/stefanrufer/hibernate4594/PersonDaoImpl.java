/*
 * Copyright (C) 2007-2008 by Netcetera AG.
 * All rights reserved.
 *
 * The copyright to the computer program(s) herein is the property of
 * Netcetera AG, Switzerland. The program(s) may be used and/or copied
 * only with the written permission of Netcetera AG or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the program(s) have been supplied.
 *
 * @(#) $Id: PersonDaoImpl.java,v 1.1 2009/05/08 12:48:27 corsin Exp $
 */
package ch.stefanrufer.hibernate4594;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * DAO object for access to the person database.
 */
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class PersonDaoImpl implements PersonDao {

  @PersistenceContext
  private EntityManager em;

  /** {@inheritDoc} */
  @SuppressWarnings("unchecked")
  @Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
  public List<Person> findPersons() {
    final Query query = em.createQuery("from Person as person order by person.id");
    return query.getResultList();
  }

  /** {@inheritDoc} */
  @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
  public void insertPerson(final Person person1) {
    em.persist(person1);
  }

}
