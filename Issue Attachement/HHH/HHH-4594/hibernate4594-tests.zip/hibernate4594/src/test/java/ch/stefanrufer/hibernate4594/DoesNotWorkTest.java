package ch.stefanrufer.hibernate4594;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
public class DoesNotWorkTest {

  /** Person DAO. */
  @Autowired
  private PersonDao personDao;


  /**
   * Runs {@code Main.main()}.
   */
  @Test
  public void testMain() {
    final Person person1 = new Person();
    person1.setId("1");
    person1.setName("John Doe");
    personDao.insertPerson(person1);
  }
}
