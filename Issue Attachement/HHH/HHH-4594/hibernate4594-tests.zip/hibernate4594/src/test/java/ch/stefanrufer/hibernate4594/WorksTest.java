package ch.stefanrufer.hibernate4594;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;



@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
public class WorksTest {

  private final Logger logger = LoggerFactory.getLogger(WorksTest.class);

  /** Person DAO. */
  @Autowired
  private PersonDao personDao;


  /**
   * Runs {@code Main.main()}.
   */
  @Test
  public void testMain() {
    logger.info("foo bar");
    final Person person1 = new Person();
    person1.setId("1");
    person1.setName("John Doe");
    personDao.insertPerson(person1);
  }
}
