package test

import jakarta.persistence.Basic
import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.FetchType
import jakarta.persistence.Id
import jakarta.persistence.Table

@Entity
@Table(name = "test")
class TestEntity(
    @Id
    @Column(name = "id", nullable = false, updatable = false, length = 10)
    val id: String,

    @Basic(fetch = FetchType.EAGER)
    @Column(name = "eager_data")
    val eagerData: ByteArray,

    @Basic(fetch = FetchType.LAZY)
    @Column(name = "lazy_data")
    val lazyData: ByteArray
)