package test

import org.hibernate.testing.bytecode.enhancement.BytecodeEnhancerRunner
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase
import org.junit.Test
import org.junit.jupiter.api.Assertions
import org.junit.runner.RunWith

@RunWith(BytecodeEnhancerRunner::class)
class QuarkusLikeORMUnitTestCase : BaseCoreFunctionalTestCase() {
	override fun getAnnotatedClasses(): Array<Class<*>> {
		return arrayOf(TestEntity::class.java)
	}

	@Test
	fun test() {
		val s = openSession()
		val tx = s.beginTransaction()

		val entity = s.find(TestEntity::class.java, "id")

		Assertions.assertNotNull(entity)
		Assertions.assertEquals("id", entity.id)

		Assertions.assertNotNull(entity.eagerData)
		Assertions.assertArrayEquals(byteArrayOf(0x01, 0x02, 0x03, 0x04), entity.eagerData)

		Assertions.assertNotNull(entity.lazyData)
		Assertions.assertArrayEquals(byteArrayOf(0x01, 0x02, 0x03, 0x04), entity.lazyData)

		// Do stuff...
		tx.commit()
		s.close()
	}
}
