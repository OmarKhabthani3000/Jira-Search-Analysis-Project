package org.hibernate.aliascompositekey;

import java.io.Serializable;

public class IssueId implements Serializable {
    // We assume that for one project we can have only one issue of a given issue type
    private Project project;
    private IssueType issueType;

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public IssueType getIssueType() {
        return issueType;
    }

    public void setIssueType(IssueType issueType) {
        this.issueType = issueType;
    }
}
