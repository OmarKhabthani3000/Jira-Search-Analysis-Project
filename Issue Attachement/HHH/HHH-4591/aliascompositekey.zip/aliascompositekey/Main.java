package org.hibernate.aliascompositekey;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

public class Main {

    private SessionFactory factory;

    public void createTestData() throws Exception {
        System.out.println("Setting up some test data");

        Session s = factory.openSession();
        Transaction tx = s.beginTransaction();

        IssueType issueType1 = new IssueType();
        issueType1.setId(1);
        issueType1.setName("issueType1");
        issueType1.setImportance(3);
        s.save(issueType1);

        IssueType issueType2 = new IssueType();
        issueType2.setId(2);
        issueType2.setName("issueType2");
        issueType2.setImportance(7);
        s.save(issueType2);

        IssueType issueType3 = new IssueType();
        issueType3.setId(3);
        issueType3.setName("issueType3");
        issueType3.setImportance(2);
        s.save(issueType3);

        Project project1 = new Project();
        project1.setId(1);
        project1.setName("Project1");
        s.save(project1);

        Issue project1Issue1 = new Issue();
        IssueId issueId1 = new IssueId();
        issueId1.setProject(project1);
        issueId1.setIssueType(issueType1);
        project1Issue1.setId(issueId1);
        project1Issue1.setDescription("red");
        s.save(project1Issue1);

        Issue project1Issue2 = new Issue();
        IssueId issueId2 = new IssueId();
        issueId2.setProject(project1);
        issueId2.setIssueType(issueType2);
        project1Issue2.setId(issueId2);
        project1Issue2.setDescription("green");
        s.save(project1Issue2);

        Issue project1Issue3 = new Issue();
        IssueId issueId3 = new IssueId();
        issueId3.setProject(project1);
        issueId3.setIssueType(issueType3);
        project1Issue3.setId(issueId3);
        project1Issue3.setDescription("blue");
        s.save(project1Issue3);

        tx.commit();
        s.close();
    }

    public void testSelectOrderByCompositeKeyProperty() throws Exception {
        System.out.println("START testSelectOrderByCompositeKeyProperty");

        Session s = factory.openSession();
        Transaction tx=null;
        try {
            tx = s.beginTransaction();

            Project p = (Project)
                    s.createCriteria(Project.class)
                    .add(Restrictions.eq("name", "Project1"))
                    .uniqueResult();
            Criteria c = s.createCriteria(Issue.class)
                    .createAlias("id.issueType", "issueType")
                    .add(Restrictions.eq("id.project", p))
                    .addOrder(Order.asc("issueType.importance"));
            List list = c.list();
            tx.commit();

            System.out.println("list.size() = " + list.size());
        }
        catch (Exception e) {
            if (tx!=null) tx.rollback();
            throw e;
        }
        finally {
            s.close();
        }

        System.out.println("END testSelectOrderByCompositeKeyProperty");
    }


    public static void main(String[] args) throws Exception {

        final Main test = new Main();

        Configuration cfg = new Configuration()
                .setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect")
                .setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver")
                .setProperty("hibernate.connection.url", "jdbc:hsqldb:target/test/db/hsqldb/hibernate")
                .setProperty("hibernate.connection.username", "sa")
                .setProperty("hibernate.connection.password", "")
                .setProperty("hibernate.connection.pool_size", "1")
                .setProperty("hibernate.connection.autocommit", "true")
                .setProperty("hibernate.cache.provider_class", "org.hibernate.cache.HashtableCacheProvider")
                .setProperty("hibernate.query.factory_class", "org.hibernate.hql.ast.ASTQueryTranslatorFactory")
//                .setProperty("hibernate.query.factory_class", "org.hibernate.hql.classic.ClassicQueryTranslatorFactory")
//                .setProperty(Environment.HBM2DDL_AUTO, "create")
                .setProperty("hibernate.hbm2ddl.auto", "create-drop")
                .setProperty("hibernate.show_sql", "true")
                .addClass(Project.class)
                .addClass(Issue.class)
                .addClass(IssueType.class);

        test.factory = cfg.buildSessionFactory();

        test.createTestData();
        test.testSelectOrderByCompositeKeyProperty();
    }

}
