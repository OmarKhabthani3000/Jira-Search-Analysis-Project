package org.hibernate.aliascompositekey;

public class Issue {
    private IssueId id;
    private String description;

    public IssueId getId() {
        return id;
    }

    public void setId(IssueId id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
