package org.hibernate.test;

import static javax.persistence.AccessType.FIELD;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.hibernate.envers.Audited;


@Entity
@Access(FIELD)
@Audited
public class OneToOneFirstEntity implements Serializable {

	private static final long serialVersionUID = -6569166099381202659L;

	@Id
	private long id;

	@OneToOne(mappedBy = "first")
	private OneToOneSecondEntity second;

	private String data;


	public OneToOneFirstEntity() {}

	public OneToOneFirstEntity(long id, String data) {
		this.id = id;
		this.data = data;
	}

	public OneToOneSecondEntity getSecond() {
		return second;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public void setSecond(OneToOneSecondEntity second) {
		this.second = second;
	}
}
