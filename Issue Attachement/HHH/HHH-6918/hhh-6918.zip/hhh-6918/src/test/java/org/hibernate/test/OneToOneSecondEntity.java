package org.hibernate.test;

import static javax.persistence.AccessType.FIELD;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.hibernate.envers.Audited;


@Entity
@Access(FIELD)
@Audited
public class OneToOneSecondEntity implements Serializable {

	private static final long serialVersionUID = -8973901177691254169L;

	@Id 
	@OneToOne
	private OneToOneFirstEntity first;

	private String data;


	public OneToOneSecondEntity() {}

	public OneToOneSecondEntity(OneToOneFirstEntity first, String data) {

		this.first = first;
		this.data = data;
	}

	public OneToOneFirstEntity getFirst() {
		return first;
	}

	public String getData() {
		return data;
	}
}
