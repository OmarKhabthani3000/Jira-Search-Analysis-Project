package org.hibernate.bugs.entity;

import org.hibernate.HibernateException;
import org.hibernate.type.descriptor.WrapperOptions;
import org.hibernate.type.descriptor.java.AbstractClassJavaType;
import org.hibernate.type.descriptor.java.StringJavaType;
import org.hibernate.type.descriptor.jdbc.JdbcType;
import org.hibernate.type.descriptor.jdbc.JdbcTypeIndicators;

import static java.sql.Types.VARCHAR;

public class CountryAdapter extends AbstractClassJavaType<Country> {
    public static final CountryAdapter INSTANCE = new CountryAdapter();

    protected CountryAdapter() {
        super(Country.class);
    }

    @Override
    public String toString(Country value) throws HibernateException {
        return value == null ? null : value.name();
    }

    @Override
    public <X> X unwrap(Country provider, Class<X> type, WrapperOptions options) {
        return StringJavaType.INSTANCE.unwrap(provider == null ? null : provider.name(),
                type,
                options);
    }

    @Override
    public <X> Country wrap(X value, WrapperOptions wrapperOptions) {
        return value == null ? null : Country.valueOf(StringJavaType.INSTANCE.wrap(value, wrapperOptions));
    }

    @Override
    public Country fromString(CharSequence sequence) throws HibernateException {
        return sequence == null ? null : Country.valueOf(sequence.toString());
    }

    @Override
    public JdbcType getRecommendedJdbcType(JdbcTypeIndicators indicators) {
        return indicators.getTypeConfiguration()
                .getJdbcTypeRegistry()
                .getDescriptor(VARCHAR);
    }
}
