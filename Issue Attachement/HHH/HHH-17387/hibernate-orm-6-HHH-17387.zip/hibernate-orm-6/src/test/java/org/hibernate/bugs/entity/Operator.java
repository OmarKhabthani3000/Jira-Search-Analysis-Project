package org.hibernate.bugs.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.NonFinal;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.OptimisticLocking;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import static jakarta.persistence.CascadeType.*;
import static jakarta.persistence.FetchType.LAZY;
import static lombok.AccessLevel.PROTECTED;
import static org.hibernate.annotations.CacheConcurrencyStrategy.READ_WRITE;
import static org.hibernate.annotations.OptimisticLockType.DIRTY;
import static org.hibernate.bugs.entity.Country.USA;

@Getter
@Entity
@ToString(onlyExplicitlyIncluded = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor(access = PROTECTED)
@Table(name = "OPERATORS")
@IdClass(Operator.OperatorPK.class)
@OptimisticLocking(type = DIRTY)
@DynamicUpdate
@Cacheable
@Cache(usage = READ_WRITE)
public class Operator {

    @EqualsAndHashCode.Include
    @ToString.Include
    @Id
    @Column(name = "COUNTRY", nullable = false)
    private Country country;

    @EqualsAndHashCode.Include
    @ToString.Include
    @Id
    @Column(name = "OPERATOR_ID", nullable = false)
    private String operatorId;

    @ManyToOne
    @JoinColumn(name = "meta_operator_id", referencedColumnName = "ID")
    private MetaOperator metaOperator;

    @OneToMany(mappedBy = "operator",
            cascade = {PERSIST, MERGE, REMOVE},
            orphanRemoval = true,
            fetch = LAZY)
    @Cache(usage = READ_WRITE)
    private List<Product> products = new ArrayList<>();

    public Operator(String operatorId) {
        this.operatorId = operatorId;
        // default country
        this.country = USA;
    }

    public void setMetaOperator(MetaOperator metaOperator) {
        this.metaOperator = metaOperator;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    @Embeddable
    @Value
    @AllArgsConstructor
    @NoArgsConstructor(access = PROTECTED)
    public static class OperatorPK implements Serializable {
        @NonFinal
        String operatorId;
        @NonFinal
        @Convert(converter = CountryConverter.class)
        Country country;
    }

}
