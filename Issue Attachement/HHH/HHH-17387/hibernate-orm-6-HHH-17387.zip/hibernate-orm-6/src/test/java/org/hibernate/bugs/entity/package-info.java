// Needed because @Enumerated(String) is broken on pk (https://hibernate.atlassian.net/browse/HHH-17020)
@JavaTypeRegistration(javaType = Country.class, descriptorClass = CountryAdapter.class)
package org.hibernate.bugs.entity;

import org.hibernate.annotations.JavaTypeRegistration;
