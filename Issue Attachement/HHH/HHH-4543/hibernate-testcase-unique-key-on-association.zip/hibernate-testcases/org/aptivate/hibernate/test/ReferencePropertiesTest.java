package org.aptivate.hibernate.test;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import junit.framework.TestCase;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.impl.SessionFactoryImpl;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class ReferencePropertiesTest extends TestCase
{
    public void testReferenceToProperties() throws Exception
    {
        Configuration conf = new Configuration();
        URL url = ReferencePropertiesTest.class.getResource(".");
        
        File classDir = new File(url.getPath());
        List<String> files = new ArrayList<String>(Arrays.asList(classDir.list()));
        Collections.sort(files);
        
        for (String hbmFile : files)
        {
            if (hbmFile.endsWith(".hbm.xml"))
                // && !hbmFile.endsWith("SiteCost.hbm.xml"))
            {
                conf.addFile(new File(classDir, hbmFile));
            }
        }
        
        String propertiesFile = "database.properties";
        Properties props = new Properties();
        
        props.load(ReferencePropertiesTest.class.getResourceAsStream(propertiesFile));
        conf.setProperties(props);
        
        conf.setProperty("hibernate.connection.driver_class",
            props.getProperty("db.driver"));
        conf.setProperty("hibernate.connection.url",
            props.getProperty("db.url"));
        conf.setProperty("hibernate.connection.username",
            props.getProperty("db.user"));
        conf.setProperty("hibernate.connection.password",
            props.getProperty("db.password"));
        conf.setProperty("hibernate.connection.pool_size",
            props.getProperty("dbpool.max"));

        SessionFactory fact = conf.buildSessionFactory();
        // Session session = fact.openSession();
        
        SchemaExport exporter = new SchemaExport(conf,
            ((SessionFactoryImpl)fact).getSettings());
        
        exporter.setHaltOnError(false);
        exporter.execute(true, true, true, false);
        exporter.execute(true, true, false, true);
        for (Object e : exporter.getExceptions())
        {
            throw (Exception) e;
        }
    }
    
    public static void main(String[] args)
    {
        junit.textui.TestRunner.run(ReferencePropertiesTest.class);
    }
}
