package org.aptivate.hibernate.test.pojo;

import java.util.HashSet;
import java.util.Set;


/**
 * SiteCost entity. @author MyEclipse Persistence Tools
 */

public class SiteCost  implements java.io.Serializable {


    // Fields    

    private Integer id;
    private ProjectSite projectSite;


    // Constructors

    /** default constructor */
    public SiteCost() {
    }
    
    // Property accessors

    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }

    public ProjectSite getProjectSite() {
        return this.projectSite;
    }
    
    public void setProjectSite(ProjectSite projectSite) {
        this.projectSite = projectSite;
    }
}