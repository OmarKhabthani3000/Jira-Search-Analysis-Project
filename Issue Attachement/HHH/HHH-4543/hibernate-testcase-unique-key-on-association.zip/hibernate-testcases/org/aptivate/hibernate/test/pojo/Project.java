package org.aptivate.hibernate.test.pojo;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.aptivate.hibernate.test.pojo.VersionedRecord;


/**
 * Project entity. @author MyEclipse Persistence Tools
 */

public class Project extends VersionedRecord
{
    // Fields    

    private Integer id;

    // Constructors

    /** default constructor */
    public Project()
    {
        super(0, false);
    }
    
    // Property accessors

    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
}