package org.aptivate.hibernate.test.pojo;

import java.util.HashSet;
import java.util.Set;

import com.sun.xml.internal.ws.wsdl.writer.document.PortType;


/**
 * Site entity. @author MyEclipse Persistence Tools
 */

public class Site  implements java.io.Serializable {

    // Fields    

    private Integer siteId;
    private Set projectSites = new HashSet(0);

    // Property accessors

    public Integer getSiteId() {
        return this.siteId;
    }
    
    public void setSiteId(Integer siteId) {
        this.siteId = siteId;
    }

    public Set getProjectSites() {
        return this.projectSites;
    }
    
    public void setProjectSites(Set projectSites) {
        this.projectSites = projectSites;
    }
}