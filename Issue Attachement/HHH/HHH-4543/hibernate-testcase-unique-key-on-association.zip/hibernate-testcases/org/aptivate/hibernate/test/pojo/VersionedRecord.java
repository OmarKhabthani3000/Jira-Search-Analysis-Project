package org.aptivate.hibernate.test.pojo;

public abstract class VersionedRecord implements java.io.Serializable
{
    private long recordVersion;
    private boolean isDeleted;

    public VersionedRecord(long recordVersion, boolean isDeleted)
    {
        this.recordVersion = recordVersion;
        this.isDeleted = isDeleted;
    }
    
    public long getRecordVersion()
    {
        return this.recordVersion;
    }
    
    public void setRecordVersion(long recordVersion)
    {
        this.recordVersion = recordVersion;
    }

    public boolean getIsDeleted()
    {
        return this.isDeleted;
    }
    
    public void setIsDeleted(boolean recordIsDeleted)
    {
        this.isDeleted = recordIsDeleted;
    }
}
