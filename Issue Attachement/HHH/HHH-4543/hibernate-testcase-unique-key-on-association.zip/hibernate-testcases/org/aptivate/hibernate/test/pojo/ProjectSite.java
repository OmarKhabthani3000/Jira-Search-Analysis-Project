package org.aptivate.hibernate.test.pojo;

import java.util.HashSet;
import java.util.Set;


/**
 * ProjectSite entity. @author MyEclipse Persistence Tools
 */

public class ProjectSite  implements java.io.Serializable {


    // Fields    

     private Integer id, projectId, siteId;
     private Project project;
     private Site site;

   
    // Property accessors

    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }

    public Project getProject() {
        return this.project;
    }
    
    public void setProject(Project project) {
        this.project = project;
    }

    public Site getSite() {
        return this.site;
    }
    
    public void setSite(Site site) {
        this.site = site;
    }

    public Integer getProjectId()
    {
        return projectId;
    }

    public void setProjectId(Integer projectId)
    {
        this.projectId = projectId;
    }

    public Integer getSiteId()
    {
        return siteId;
    }

    public void setSiteId(Integer siteId)
    {
        this.siteId = siteId;
    }

}