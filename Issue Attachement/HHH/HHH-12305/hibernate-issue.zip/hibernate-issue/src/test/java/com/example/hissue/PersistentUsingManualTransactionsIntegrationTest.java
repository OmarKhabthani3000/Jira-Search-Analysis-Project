package com.example.hissue;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.support.TransactionTemplate;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = HissueConfiguration.class)
@SuppressWarnings({ "SpringJavaAutowiredMembersInspection", "SpringJavaAutowiringInspection" })
public class PersistentUsingManualTransactionsIntegrationTest {

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private TransactionTemplate txTemplate;

    @Test
    public void shouldRemoveDependEntityIfItSetToNullOnRootEntity() {
        // 1. when
        final Long rootEntityId = txTemplate.execute(status -> {
            final RootEntity rootEntity = RootEntity.builder().description("rootEntity alone").build();
            entityManager.persist(rootEntity);
            return rootEntity.getId();
        });

        // then
        assertThat(rootEntityId).isNotNull();
        final RootEntity foundRootEntity = txTemplate.execute(status -> entityManager.find(RootEntity.class, rootEntityId));
        assertThat(foundRootEntity).isNotNull();

        // 2. when
        final Long dependEntityId = txTemplate.execute(status -> {
            final RootEntity rootEntity = entityManager.find(RootEntity.class, rootEntityId);

            // create dependent entity and set on root
            final DependEntity dependEntity = DependEntity.builder().description("dependEntity").build();
            rootEntity.setDependEntity(dependEntity);
            rootEntity.setDescription("rootEntity+dependEntity");
            entityManager.persist(rootEntity);

            final Long dependEntityId1 = dependEntity.getId();
            assertThat(dependEntityId1).isNotNull();

            final DependEntity foundDependEntity = entityManager.find(DependEntity.class, dependEntityId1);
            assertThat(foundDependEntity).isNotNull();

            // set dependent entity on root to null -> should as result delete dependent entity in the database
            foundDependEntity.setDescription("to-delete");
            rootEntity.setDependEntity(null);
            entityManager.persist(rootEntity);

            return dependEntityId1;
        });

        final DependEntity dependEntityOnRoot = txTemplate
                .execute(status -> entityManager.find(RootEntity.class, rootEntityId).getDependEntity());
        assertThat(dependEntityOnRoot).isNull(); // no relation between root<->depend entities anymore

        final DependEntity foundDependEntity = txTemplate
                .execute(status -> entityManager.find(DependEntity.class, dependEntityId));
        // TODO according https://hibernate.atlassian.net/browse/HHH-9663 this problem should be solved in 5.2.10, but...
        assertThat(foundDependEntity).isNull(); // fails -> depend-entity still in the database :(
    }
}
