package com.example.hissue;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@Transactional
@SpringBootTest(classes = HissueConfiguration.class)
@SuppressWarnings({ "SpringJavaAutowiredMembersInspection", "SpringJavaAutowiringInspection" })
public class PersistentUsingTransactionAnnotationIntegrationTest {

    @PersistenceContext
    private EntityManager entityManager;

    @Test
    public void shouldSaveRootEntityAlone() {
        // given
        final RootEntity rootEntity = RootEntity.builder().description("rootEntity alone").build();

        // when
        persistAndForceRefresh(rootEntity);
    }

    private void persistAndForceRefresh(final Object entity) {
        entityManager.persist(entity);
        entityManager.flush();
    }

    @Test
    public void shouldSaveDependEntityAlone() {
        // given
        final DependEntity dependEntity = DependEntity.builder().description("dependEntity alone").build();

        // when
        persistAndForceRefresh(dependEntity);
    }

    @Test
    public void shouldSaveRootEntityWithDependEntity() {
        // given
        final DependEntity dependEntity = DependEntity.builder().description("dependEntity").build();
        final RootEntity rootEntity = RootEntity.builder()
                .description("rootEntity+dependEntity")
                .dependEntity(dependEntity)
                .build();

        // when
        persistAndForceRefresh(rootEntity);
    }

    @Test
    public void shouldRemoveDependEntityIfItSetToNullOnRootEntity() {
        // given
        final RootEntity rootEntity = RootEntity.builder().description("rootEntity alone").build();

        // 1. when
        entityManager.persist(rootEntity);
        entityManager.flush();

        // then
        final Long rootEntityId = rootEntity.getId();
        final RootEntity foundRootEntity = entityManager.find(RootEntity.class, rootEntityId);
        assertThat(foundRootEntity).isNotNull();

        // 2. when
        final DependEntity dependEntity = DependEntity.builder().description("dependEntity").build();
        foundRootEntity.setDependEntity(dependEntity);
        foundRootEntity.setDescription("rootEntity+dependEntity");
        entityManager.persist(foundRootEntity);

        // then
        final Long dependEntityId = dependEntity.getId();
        assertThat(dependEntityId).isNotNull();

        DependEntity foundDependEntity = entityManager.find(DependEntity.class, dependEntityId);
        assertThat(foundDependEntity).isNotNull();

        // 3. when
        foundDependEntity.setDescription("to-delete");
        foundRootEntity.setDependEntity(null); // no relation between root<->depend entities anymore
        entityManager.persist(foundRootEntity);
        entityManager.flush();

        // then
        foundDependEntity = entityManager.find(DependEntity.class, dependEntityId);
        // TODO according https://hibernate.atlassian.net/browse/HHH-9663 this problem should be solved in 5.2.10, but...
        assertThat(foundDependEntity).isNull(); // fails -> depend-entity still in the database :(
    }
}
