package com.example.hissue;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "DEPEND_ENTITY")
@SequenceGenerator(name = AbstractPersistableEntity.SEQUENCE_GENERATOR_NAME, sequenceName = "SEQ_DEPEND_ENTITY")
@Builder
public class DependEntity extends AbstractPersistableEntity {

    @Column(name = "DESCRIPTION")
    private String description;
}
