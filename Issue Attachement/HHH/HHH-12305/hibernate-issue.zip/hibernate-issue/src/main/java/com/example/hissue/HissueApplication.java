package com.example.hissue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HissueApplication {

	public static void main(String[] args) {
		SpringApplication.run(HissueApplication.class, args);
	}
}
