package com.example.hissue;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import org.springframework.data.domain.Persistable;

import lombok.Getter;
import lombok.Setter;

@MappedSuperclass
public abstract class AbstractPersistableEntity implements Persistable<Long> {

    private static final long serialVersionUID = 1L;

    static final String SEQUENCE_GENERATOR_NAME = "id_generator";

    @Id
    @Getter
    @Setter
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = SEQUENCE_GENERATOR_NAME)
    private Long id;

    @Override
    public boolean isNew() {
        return getId() == null;
    }

    @Override
    public int hashCode() {
        int hashCode = 17;
        hashCode += null == getId() ? 0 : getId().hashCode() * 31;
        return hashCode;
    }

    @Override
    public boolean equals(final Object obj) {
        if (null == obj) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        if (!getClass().equals(obj.getClass())) {
            return false;
        }
        final AbstractPersistableEntity that = (AbstractPersistableEntity) obj;
        return (null != getId()) && getId().equals(that.getId());
    }

    @Override
    public String toString() {
        return String.format("Entity of type %s with id: %s", getClass().getName(), getId());
    }
}
