package com.example.hissue;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "ROOT_ENTITY")
@SequenceGenerator(name = AbstractPersistableEntity.SEQUENCE_GENERATOR_NAME, sequenceName = "SEQ_ROOT_ENTITY")
@Builder
public class RootEntity extends AbstractPersistableEntity {

    @Column(name = "DESCRIPTION")
    private String description;

    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "DEPEND_ENTITY_ID", unique = true)
    private DependEntity dependEntity;
}
