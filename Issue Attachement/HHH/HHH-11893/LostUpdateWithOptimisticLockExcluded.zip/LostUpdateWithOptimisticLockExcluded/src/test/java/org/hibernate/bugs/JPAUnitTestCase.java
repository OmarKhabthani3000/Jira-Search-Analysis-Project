package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.hibernate.bugs.entities.TestEntity;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {
	
	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		long regularValueInitial = 1;
		long optimisticLockExcludedValueInitial=1;
		Long testEntityId = createTestEntityAndReturnId(regularValueInitial, optimisticLockExcludedValueInitial);
		
		//Transaction1 changes regular value
		EntityManager entityManager1 = entityManagerFactory.createEntityManager();
		entityManager1.getTransaction().begin();
		entityManager1.find(TestEntity.class, testEntityId).setRegularValue(2);
		
		//Transaction2 changes optimistic lock excluded value
		EntityManager entityManager2 = entityManagerFactory.createEntityManager();
		entityManager2.getTransaction().begin();
		entityManager2.find(TestEntity.class, testEntityId).setOptimisticLockExcludedValue(2);
		
		//Transaction1 commits and yields expected result
		entityManager1.getTransaction().commit();
		entityManager1.close();
		
		//Transaction2 commits and resets the regular value to 1 without changing the version
		entityManager2.getTransaction().commit();
		entityManager2.close();
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		TestEntity loadedTestEntity = entityManager.find(TestEntity.class, testEntityId);
		long actualRegularValue = loadedTestEntity.getRegularValue();
		long actualOptimisticLockExcludedValue = loadedTestEntity.getOptimisticLockExcludedValue();
		entityManager.getTransaction().commit();
		entityManager.close();
		
		Assert.assertEquals(2, actualRegularValue);
		Assert.assertEquals(2, actualOptimisticLockExcludedValue);
	}

	private long createTestEntityAndReturnId(long regularValue, long lockExcludedValue) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		TestEntity createdTestEntity = new TestEntity();
		entityManager.persist(createdTestEntity);
		createdTestEntity.setRegularValue(regularValue);
		createdTestEntity.setOptimisticLockExcludedValue(lockExcludedValue);
		entityManager.getTransaction().commit();
		entityManager.close();
		return createdTestEntity.getId();
	}
}
