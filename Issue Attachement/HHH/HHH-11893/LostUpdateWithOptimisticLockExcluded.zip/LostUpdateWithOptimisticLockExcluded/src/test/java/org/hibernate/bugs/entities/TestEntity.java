package org.hibernate.bugs.entities;


import javax.persistence.Basic;
import javax.persistence.Entity;
import org.hibernate.annotations.OptimisticLock;

@Entity
public class TestEntity extends BaseEntity {
	
	public TestEntity() {
		// TODO Auto-generated constructor stub
	}
	
	@Basic
	protected long regularValue;
	
	@Basic
	@OptimisticLock(excluded=true)
	protected long optimisticLockExcludedValue;
	
	public long getRegularValue() {
		return regularValue;
	}
	
	public void setRegularValue(long regularValue) {
		this.regularValue = regularValue;
	}
	
	public long getOptimisticLockExcludedValue() {
		return optimisticLockExcludedValue;
	}
	
	public void setOptimisticLockExcludedValue(long optimisticLockExcludedValue) {
		this.optimisticLockExcludedValue = optimisticLockExcludedValue;
	}
}