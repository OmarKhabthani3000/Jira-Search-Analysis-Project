package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.hibernate.bugs.test.LegacyEntity;
import org.hibernate.bugs.test.ModernEntity;
import org.hibernate.bugs.test.NestedLegacyEntity;

import java.io.Serializable;

/**
 * This template demonstrates how to develop a org.hibernate.bugs.test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	/**
	 * Persisting entity with a nested IdClass which already exists in the db, but is detached.
	 * @throws Exception
	 */
	@Test
	public void manyToOneInIdClassTest() throws Exception {

		// Create entities
		ModernEntity modernEntity = new ModernEntity();
		modernEntity.setFoo(2);

		LegacyEntity legacyEntity = new LegacyEntity();
		legacyEntity.setPrimitivePk1(1);
		legacyEntity.setPrimitivePk2(2);
		legacyEntity.setFoo("Foo");

		// 1st transaction
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		entityManager.persist(modernEntity);
		entityManager.merge(legacyEntity);

		entityManager.getTransaction().commit();
		entityManager.close();

		// Now creating and saving entity with nested IdClass
		NestedLegacyEntity nestedLegacyEntity = new NestedLegacyEntity();
		nestedLegacyEntity.setModernEntity(modernEntity);
		nestedLegacyEntity.setLegacyEntity(legacyEntity);

		// 2nd transaction
		entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		entityManager.merge(nestedLegacyEntity);

		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
