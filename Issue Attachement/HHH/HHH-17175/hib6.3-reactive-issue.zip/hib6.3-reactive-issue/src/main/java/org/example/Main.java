package org.example;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.example.domain.*;
import org.example.domain.dto.PetDto;
import org.hibernate.reactive.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testcontainers.containers.PostgreSQLContainer;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public class Main {

    private static final Logger LOG = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {
        try (PostgreSQLContainer<?> postgreSQLContainer = new PostgreSQLContainer<>("postgres:13")
                .withDatabaseName("pets")
                .withUsername("postgres")
                .withPassword("postgres")) {
            postgreSQLContainer.start();

            System.setProperty("db.port", postgreSQLContainer.getFirstMappedPort().toString());
            EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("sample-persistence-unit");
            Stage.SessionFactory sessionFactory = entityManagerFactory.unwrap(Stage.SessionFactory.class);

            OwnerRepository ownerRepository = new OwnerRepository(sessionFactory);
            PetRepository petRepository = new PetRepository(sessionFactory);

            Owner fred = new Owner();
            fred.setId(1L);
            fred.setName("Fred");
            fred.setAge(45);
            Owner barney = new Owner();
            barney.setId(2L);
            barney.setName("Barney");
            barney.setAge(40);

            Pet dino = new Pet();
            dino.setId(1L);
            dino.setName("Dino");
            dino.setType(Pet.PetType.DOG);
            dino.setOwner(fred);
            Pet bp = new Pet();
            bp.setId(2L);
            bp.setName("Baby Puss");
            bp.setOwner(fred);
            bp.setType(Pet.PetType.CAT);
            Pet hoppy = new Pet();
            hoppy.setId(3L);
            hoppy.setName("Hoppy");
            hoppy.setOwner(barney);
            hoppy.setType(Pet.PetType.CAT);

            ownerRepository.save(fred).block();
            ownerRepository.save(barney).block();
            petRepository.save(dino).block();
            // As soon as more than one pet is saved and petRepository.findAll returns more than 1 then an exception is thrown
            petRepository.save(bp).block();
            //petRepository.save(hoppy).block();

            Flux<Pet> petsFlux = petRepository.findAll();
            Mapper mapper = new Mapper();

            Mono<List<PetDto>> monoPets = petsFlux.map(mapper::toPetDto).collectList();
            List<PetDto> pets = monoPets.block();

            LOG.warn("Pets: {}", pets);
            entityManagerFactory.close();
        }

    }
}