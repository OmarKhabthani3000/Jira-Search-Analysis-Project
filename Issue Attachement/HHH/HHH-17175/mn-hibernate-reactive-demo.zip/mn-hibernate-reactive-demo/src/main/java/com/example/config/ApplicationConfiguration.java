package com.example.config;

public interface ApplicationConfiguration {
    int getMax();
}