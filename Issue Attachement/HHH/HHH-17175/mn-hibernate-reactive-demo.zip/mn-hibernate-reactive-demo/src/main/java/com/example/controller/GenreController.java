package com.example.controller;

import com.example.entity.Genre;
import com.example.repository.GenreRepository;
import io.micronaut.core.annotation.Nullable;
import io.micronaut.core.async.annotation.SingleResult;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Delete;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.annotation.Put;
import io.micronaut.http.annotation.Status;
import org.reactivestreams.Publisher;
import reactor.core.publisher.Mono;

import jakarta.persistence.PersistenceException;
import jakarta.validation.Valid;
import java.net.URI;

import static io.micronaut.http.HttpHeaders.LOCATION;

@Controller("/genres")
class GenreController {

    private final GenreRepository genreRepository;

    GenreController(GenreRepository genreRepository) {
        this.genreRepository = genreRepository;
    }

    @Get("/{id}")
    @SingleResult
    Publisher<Genre> show(Long id) {
        return Mono.from(genreRepository.findById(id))
                .flatMap(g -> g.map(Mono::just).orElseGet(Mono::empty));
    }

    @Put
    Publisher<HttpResponse<?>> update(@Body @Valid GenreUpdateCommand command) {
        return Mono.from(genreRepository.update(command.getId(), command.getName()))
                .map(i -> HttpResponse
                        .noContent()
                        .header(LOCATION, location(command.getId()).getPath()));
    }

    @Get(value = "/list{?args*}")
    Publisher<Genre> list(@Valid @Nullable SortingAndOrderArguments args) {
        return genreRepository.findAll(args);
    }

    @Post
    @SingleResult
    Publisher<HttpResponse<Genre>> save(@Body @Valid GenreSaveCommand cmd) {
        return Mono.from(genreRepository.save(cmd.getName()))
                .map(genre -> HttpResponse
                        .created(genre)
                        .headers(headers -> headers.location(location(genre.getId())))
                );
    }

    @Post("/ex")
    @SingleResult
    Publisher<MutableHttpResponse<Genre>> saveExceptions(@Body @Valid GenreSaveCommand cmd) {
        return Mono.from(genreRepository.saveWithException(cmd.getName()))
                .map(genre -> HttpResponse
                        .created(genre)
                        .headers(headers -> headers.location(location(genre.getId()))))
                .onErrorReturn(PersistenceException.class, HttpResponse.noContent());
    }

    @Delete("/{id}")
    @Status(HttpStatus.NO_CONTENT)
    <T> HttpResponse<T> delete(Long id) {
        genreRepository.deleteById(id);
        return HttpResponse.noContent();
    }

    private URI location(Long id) {
        return URI.create("/genres/" + id);
    }
}
