package com.example.repository;

import com.example.config.ApplicationConfiguration;
import com.example.controller.SortingAndOrderArguments;
import com.example.entity.Genre;
import jakarta.inject.Singleton;
import org.hibernate.SessionFactory;
import org.hibernate.reactive.stage.Stage;
import org.reactivestreams.Publisher;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import jakarta.persistence.PersistenceException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletionStage;

@Singleton
public class GenreRepositoryImpl implements GenreRepository {

    private static final List<String> VALID_PROPERTY_NAMES = Arrays.asList("id", "name");
    private final ApplicationConfiguration applicationConfiguration;
    private final Stage.SessionFactory sessionFactory;

    public GenreRepositoryImpl(
            ApplicationConfiguration applicationConfiguration,
            SessionFactory sessionFactory
    ) {
        this.applicationConfiguration = applicationConfiguration;
        this.sessionFactory = sessionFactory.unwrap(Stage.SessionFactory.class);
    }

    @Override
    public Publisher<Optional<Genre>> findById(long id) {
        return Mono.fromCompletionStage(sessionFactory.withTransaction(session ->
                find(session, id)
        ));
    }

    CompletionStage<Optional<Genre>> find(Stage.Session session, Long id) {
        return session.find(Genre.class, id).thenApply(Optional::ofNullable);
    }

    @Override
    public Publisher<Genre> save(String name) {
        return Mono.fromCompletionStage(sessionFactory.withTransaction(session -> {
            Genre entity = new Genre(name);
            return session.persist(entity).thenApply(v -> entity);
        }));
    }

    @Override
    public Publisher<Genre> saveWithException(String name) {
        return Mono.fromCompletionStage(sessionFactory.withTransaction(session -> {
            Genre entity = new Genre(name);
            return session.persist(entity).thenApply(v -> {
                throw new PersistenceException();
            });
        }));
    }

    @Override
    public void deleteById(long id) {
        sessionFactory.withTransaction(session -> session.find(Genre.class, id).thenApply(session::remove));
    }

    @Override
    public Publisher<Genre> findAll(SortingAndOrderArguments args) {
        String qlString = createQuery(args);
        return Mono.fromCompletionStage(sessionFactory.withTransaction(session -> {
                    Stage.SelectionQuery<Genre> query = session.createQuery(qlString, Genre.class);
                    query.setMaxResults(args.max() != null ? args.max() : applicationConfiguration.getMax());
                    if (args.offset() != null) {
                        query.setFirstResult(args.offset());
                    }
                    return query.getResultList();
                }))
                .flatMapMany(Flux::fromIterable);
    }

    private String createQuery(SortingAndOrderArguments args) {
        String qlString = "SELECT g FROM Genre as g";
        String order = args.order();
        String sort = args.sort();
        if (order != null && sort != null && VALID_PROPERTY_NAMES.contains(sort)) {
            qlString += " ORDER BY g." + sort + ' ' + order.toLowerCase();
        }
        return qlString;
    }

    @Override
    public Publisher<Integer> update(long id, String name) {
        return Mono.fromCompletionStage(sessionFactory.withTransaction(session -> session.createQuery("UPDATE Genre g SET name = :name where id = :id")
                .setParameter("name", name)
                .setParameter("id", id)
                .executeUpdate()));
    }
}
