package nicolson.domain.common.party;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class PartyTest {
	protected static EntityManagerFactory entityManagerFactory;
	protected static EntityManager entityManager;

	public static final String FIND_ALL_PARTIES = "select p from Party p";

	@BeforeClass
	public static void initEntityManager() {
		entityManagerFactory = Persistence
				.createEntityManagerFactory("nicolson-bugreports-hibernate-PU");
		entityManager = entityManagerFactory.createEntityManager();
		
		createAPerson();
	}

	@AfterClass
	public static void closeEntityManager() {
		entityManager.close();
		entityManagerFactory.close();
	}

	@Test
	public void shouldExecuteParameterisedPolymorphicQuery() {
		entityManager.getTransaction().begin();

		try {
			List<Party> retrievedParties = entityManager
					.createNamedQuery(
							Party.JPQL_NAME_FIND_ALL_PARTIES_WITH_TYPE,
							Party.class)
					.setParameter(
							Party.JPQL_PARAM_FIND_ALL_PARTIES_WITH_TYPE_PARTY_TYPE,
							Person.class).getResultList();

			assertEquals("resultset Size is incorrect", 1,
					retrievedParties.size());

		} catch (Exception e) {
			entityManager.getTransaction().rollback();
			throw e;
		}

		entityManager.getTransaction().commit();
	}

	@Test
	public void shouldExecuteHardCodedPolymorphicQuery() {
		entityManager.getTransaction().begin();

		try {
			List<Party> retrievedParties = entityManager.createNamedQuery(
					Party.JPQL_NAME_FIND_ALL_PERSONS, Party.class)
					.getResultList();

			assertEquals("resultset Size is incorrect", 1,
					retrievedParties.size());

		} catch (Exception e) {
			entityManager.getTransaction().rollback();
			throw e;
		}

		entityManager.getTransaction().commit();
	}

	@Test
	public void shouldExecuteHardCodedPolymorphicQueryUsingIn() {
		entityManager.getTransaction().begin();

		try {
			List<Party> retrievedParties = entityManager.createNamedQuery(
					Party.JPQL_NAME_FIND_ALL_PERSONS_USING_IN, Party.class)
					.getResultList();

			assertEquals("resultset Size is incorrect", 1,
					retrievedParties.size());

		} catch (Exception e) {
			entityManager.getTransaction().rollback();
			throw e;
		}

		entityManager.getTransaction().commit();
	}
	
	public static void createAPerson() {
		entityManager.getTransaction().begin();
		try {
			Person person = null;

			person = new Person();
			person.setGivenName("Tom");
			person.setSurName("Smith");

			entityManager.persist(person);
			entityManager.flush();

			List<Party> retrievedParties = entityManager.createQuery(
					FIND_ALL_PARTIES, Party.class).getResultList();

			assertEquals("resultset Size is incorrect", 1,
					retrievedParties.size());

		} catch (Exception e) {
			entityManager.getTransaction().rollback();
			throw e;
		}
		entityManager.getTransaction().commit();
	}
}
