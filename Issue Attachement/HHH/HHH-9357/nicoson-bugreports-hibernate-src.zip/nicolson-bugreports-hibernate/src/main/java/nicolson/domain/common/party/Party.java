package nicolson.domain.common.party;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
// @Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "partyType")
@NamedQueries({
		@NamedQuery(name = Party.JPQL_NAME_FIND_ALL_PARTIES_WITH_TYPE, query = Party.JPQL_QUERY_FIND_ALL_PARTIES_WITH_TYPE),
		@NamedQuery(name = Party.JPQL_NAME_FIND_ALL_PERSONS, query = Party.JPQL_QUERY_FIND_ALL_PERSONS),
		@NamedQuery(name = Party.JPQL_NAME_FIND_ALL_PERSONS_USING_IN, query = Party.JPQL_QUERY_FIND_ALL_PERSONS_USING_IN) })
@Access(AccessType.PROPERTY)
public abstract class Party implements Serializable {

	public static final String JPQL_NAME_FIND_ALL_PARTIES_WITH_TYPE = "Party.findAllPartiesWithType";
	public static final String JPQL_PARAM_FIND_ALL_PARTIES_WITH_TYPE_PARTY_TYPE = "partyType";
	public static final String JPQL_QUERY_FIND_ALL_PARTIES_WITH_TYPE = "SELECT p"
			+ " FROM Party p"
			+ " WHERE TYPE (p) ="
			+ " :"
			+ JPQL_PARAM_FIND_ALL_PARTIES_WITH_TYPE_PARTY_TYPE;

	public static final String JPQL_NAME_FIND_ALL_PERSONS = "Party.findAllPersons";
	public static final String JPQL_QUERY_FIND_ALL_PERSONS = "SELECT p"
			+ " FROM Party p" + " WHERE TYPE (p) =" + " Person";

	public static final String JPQL_NAME_FIND_ALL_PERSONS_USING_IN = "Party.findAllPersonsUsingIn";
	public static final String JPQL_QUERY_FIND_ALL_PERSONS_USING_IN = "SELECT p"
			+ " FROM Party p" + " WHERE TYPE (p) IN (" + " Person" + " )";
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;

	public Party() {
		super();
	}

	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}

	protected void setId(Long id) {
		this.id = id;
	}
}
