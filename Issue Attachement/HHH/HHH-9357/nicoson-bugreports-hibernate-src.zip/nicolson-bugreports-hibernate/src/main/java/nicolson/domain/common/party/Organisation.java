package nicolson.domain.common.party;

import javax.persistence.Entity;

@Entity
public class Organisation extends Party {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// FormalOrganisation
	private String formalName;

	// FormalOrganisation:CommercialOrganisation
	private String tradingAsName;
	private String registrationIdentifier;

	public Organisation() {
		super();
	}

	public String getFormalName() {
		return formalName;
	}

	public String getTradingAsName() {
		return tradingAsName;
	}

	public String getRegistrationIdentifier() {
		return registrationIdentifier;
	}

	public void setFormalName(String formalName) {
		this.formalName = formalName;
	}

	public void setTradingAsName(String tradingAsName) {
		this.tradingAsName = tradingAsName;
	}

	public void setRegistrationIdentifier(String registrationIdentifier) {
		this.registrationIdentifier = registrationIdentifier;
	}
}
