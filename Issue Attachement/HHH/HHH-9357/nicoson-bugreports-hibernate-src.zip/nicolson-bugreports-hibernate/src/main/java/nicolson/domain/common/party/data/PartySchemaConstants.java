package nicolson.domain.common.party.data;

public abstract class PartySchemaConstants {

	public static final String PARTY_SUBCLASS_PERSON = "Person";
	public static final String PARTY_SUBCLASS_ORGANISATION = "Organisation";	
		
}
