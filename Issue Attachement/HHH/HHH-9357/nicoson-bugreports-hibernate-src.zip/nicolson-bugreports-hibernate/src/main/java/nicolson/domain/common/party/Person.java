package nicolson.domain.common.party;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import nicolson.domain.common.party.data.PartySchemaConstants;

@Entity
@DiscriminatorValue(PartySchemaConstants.PARTY_SUBCLASS_PERSON)
public class Person extends Party {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String givenName;
	private String surName;

	public Person() {
		super();
	}

	public String getGivenName() {
		return givenName;
	}

	public String getSurName() {
		return surName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	public void setSurName(String surName) {
		this.surName = surName;
	}
}
