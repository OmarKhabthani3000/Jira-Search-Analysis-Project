package com.acme;

import lombok.extern.log4j.Log4j2;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.assertEquals;

@Log4j2
public class MappedSuperTests {

  private SessionFactory sessionFactory;

  @BeforeEach
  public void beforeEach() {
    sessionFactory = new Configuration().
        configure("hibernate.cfg.xml").
        buildSessionFactory();
  }

  @Test
  @DisplayName("@MappedSuper class's fields should be included in the dirty check")
  public void mappedSuperProperties() {
    withNewSession(session -> {
      Child child = new Child();
      child.setId(1L);
      child.setChildProperty("Child val");
      child.setParentProperty("Parent val");
      session.persist(child);
    });

    withNewSession(session -> {
      Child child = session.get(Child.class, 1L);
//      child.setChildProperty("New child val");
      child.setParentProperty("New parent val");
    });

    withNewSession(session -> {
      Child child = session.get(Child.class, 1L);
      assertEquals("New parent val", child.getParentProperty());
    });
  }

  private void withNewSession(Consumer<Session> withSessionFunction) {
    Session session = sessionFactory.openSession();
    try {
      session.beginTransaction();
      withSessionFunction.accept(session);
      session.getTransaction().commit();
    } catch (Exception e) {
      session.getTransaction().rollback();
    } finally {
      session.close();
    }
  }

}
