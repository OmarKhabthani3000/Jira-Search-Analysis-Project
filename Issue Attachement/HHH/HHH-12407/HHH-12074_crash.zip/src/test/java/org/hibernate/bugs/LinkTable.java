package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class LinkTable
{
    @Id
    @GeneratedValue()
    public int sysId;

    @ManyToOne
    public TableA refToA;

    @ManyToOne
    public TableB refToB;
}
