package org.hibernate.bugs;

import javax.persistence.Entity;

@Entity
public class TableA extends OwnedTable
{
}


