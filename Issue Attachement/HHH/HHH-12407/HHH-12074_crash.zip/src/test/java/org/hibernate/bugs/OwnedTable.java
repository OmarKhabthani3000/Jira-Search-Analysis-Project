package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

@Entity
public abstract class OwnedTable extends RootTable
{
    @ManyToOne
    public OwningTable owning;
}
