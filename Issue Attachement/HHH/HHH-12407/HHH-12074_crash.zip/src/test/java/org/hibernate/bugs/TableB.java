package org.hibernate.bugs;

import javax.persistence.Entity;

@Entity
public class TableB extends OwnedTable
{
}
