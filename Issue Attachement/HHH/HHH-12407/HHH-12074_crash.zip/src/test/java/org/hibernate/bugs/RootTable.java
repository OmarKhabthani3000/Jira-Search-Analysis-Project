package org.hibernate.bugs;

import javax.persistence.*;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class RootTable
{
    @Id
    @GeneratedValue()
    public int sysId;
}
