package com.rms;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.stream.Collectors;

public class TestCase {

    private SessionFactory sf;
    private Session ss;
    private long id;

    @Before
    public void setup() {
        StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder()
                .applySetting( "hibernate.show_sql", "true" )
                .applySetting( "hibernate.format_sql", "true" )
                .applySetting( "hibernate.hbm2ddl.auto", "update" );

        Metadata metadata = new MetadataSources( srb.build() )
                .addAnnotatedClass( TestEntity.class )
                .buildMetadata();

        sf = metadata.buildSessionFactory();
        ss = sf.openSession();

        // Create a single record in the test database.
        TestEntity te = new TestEntity(9223372036854775807L, 2147483647, (short)32767, (byte)127,
                1.3,
                new BigDecimal("17.34"),
                "Foo");
        Transaction t = ss.beginTransaction();
        ss.persist(te);
        t.commit();
        id = te.getId();
    }

    // Add your tests, using standard JUnit.
    @Test
    public void simpleTest() {
        TestEntity te = ss.get(TestEntity.class, id);

        // Execute a native query to get the entity that was just created.
        Object o = ss.createNativeQuery("select id, byteValue, shortValue, integerValue, longValue," +
                " doubleValue, decimalValue, stringValue from TestEntity")
                .getSingleResult();

        // Verify that the returned fields are of the expected types.
        String expectedTypes = String.join(",", Arrays.stream(new Object[] {
                te.getId(),
                te.getByteValue(),
                te.getShortValue(),
                te.getIntegerValue(),
                te.getLongValue(),
                te.getDoubleValue(),
                te.getDecimalValue(),
                te.getStringValue()
        }).map(f -> f.getClass().getSimpleName()).collect(Collectors.toList()));
        String receivedTypes = String.join(",", Arrays.stream((Object[])o).map(f -> f.getClass().getSimpleName()).collect(Collectors.toList()));
        Assert.assertEquals(expectedTypes, receivedTypes);
    }
}

@Entity
class TestEntity {
    @Id
    @GeneratedValue
    private Long id;
    private Long longValue;
    private Integer integerValue;
    private Short shortValue;
    private Byte byteValue;
    private Double doubleValue;
    private BigDecimal decimalValue;
    private String stringValue;

    public TestEntity() {}

    public TestEntity(Long longValue, Integer integerValue, Short shortValue, Byte byteValue, Double doubleValue, BigDecimal decimalValue, String stringValue) {
        this.longValue = longValue;
        this.integerValue = integerValue;
        this.shortValue = shortValue;
        this.byteValue = byteValue;
        this.doubleValue = doubleValue;
        this.decimalValue = decimalValue;
        this.stringValue = stringValue;
    }

    public Long getId() {
        return id;
    }

    public Long getLongValue() {
        return longValue;
    }

    public Integer getIntegerValue() {
        return integerValue;
    }

    public Short getShortValue() {
        return shortValue;
    }

    public Byte getByteValue() {
        return byteValue;
    }

    public Double getDoubleValue() {
        return doubleValue;
    }

    public BigDecimal getDecimalValue() {
        return decimalValue;
    }

    public String getStringValue() {
        return stringValue;
    }

    @Override
    public String toString() {
        return "TestEntity{" +
                "id=" + id +
                ", longValue=" + longValue +
                ", integerValue=" + integerValue +
                ", shortValue=" + shortValue +
                ", byteValue=" + byteValue +
                ", doubleValue=" + doubleValue +
                ", decimalValue=" + decimalValue +
                ", stringValue='" + stringValue + '\'' +
                '}';
    }
}
