package com.example.collectionofembeddables1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollectionOfEmbeddables1Application {

    public static void main(String[] args) {
        SpringApplication.run(CollectionOfEmbeddables1Application.class, args);
    }

}
