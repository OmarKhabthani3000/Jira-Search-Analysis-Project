package com.example.collectionofembeddables1;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Callbacks {

    public static void userPrePersist() {
    }

    public static void userPostLoad() {
    }

    public static void userPreUpdate() {
    }

    public static void userPreRemove() {
    }

    public static void auditPrePersist() {
    }

    public static void auditPostLoad() {
    }

    public static void contactAddressPrePersist() {
    }

    public static void contactAddressPostLoad() {
    }

    public static void auditPreUpdate() {
    }

    public static void auditPreRemove() {
    }
}
