package com.example.collectionofembeddables1.domain;

public enum UserType {
    EMPLOYEE,
    STUDENT;
}
