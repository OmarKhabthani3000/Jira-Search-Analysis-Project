package org.hibernate.test;

import java.util.SortedMap;
import java.util.TreeMap;

public class Foo {

	private int id;
	private SortedMap<String, String> sortedMap = new TreeMap<>();
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public SortedMap<String, String> getSortedMap() {
		return sortedMap;
	}
	public void setSortedMap(SortedMap<String, String> sortedMap) {
		this.sortedMap = sortedMap;
	}
}
