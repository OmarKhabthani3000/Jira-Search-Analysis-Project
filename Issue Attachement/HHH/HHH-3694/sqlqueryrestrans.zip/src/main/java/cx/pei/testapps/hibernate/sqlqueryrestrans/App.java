package cx.pei.testapps.hibernate.sqlqueryrestrans;


/**
 * Demonstrate problem with using a ResultTransformer with a SQLQuery.
 */
public class App
  {
  public static void main(String[] args)
    {
    System.out.println("Nothing to see here...");
    }
  }
