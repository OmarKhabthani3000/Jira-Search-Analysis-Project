package cx.pei.testapps.hibernate.sqlqueryrestrans;

import java.util.List;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.hibernate.Query;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.hibernate.transform.ResultTransformer;

/**
 * Unit test for simple App.
 */
public class AppTest extends TestCase
  {
  /**
   * Create the test case
   * 
   * @param testName name of the test case
   */
  public AppTest(String testName)
    {
    super(testName);
    }

  /**
   * @return the suite of tests being tested
   */
  public static Test suite()
    {
    return new TestSuite(AppTest.class);
    }

  public void testApp() throws Exception
    {
    Class.forName("org.hsqldb.jdbcDriver");
    Configuration cfg = new Configuration().configure();
    SchemaExport export = new SchemaExport(cfg);
    export.create(false, true);
    SessionFactory sf = cfg.buildSessionFactory();
    Session session = sf.openSession();
    RelationA a = new RelationA();
    a.setName("Relation A");
    RelationB b = new RelationB();
    b.setName("Relation B");
    DomainObject obj1 = new DomainObject();
    obj1.setName("DomainObject");
    obj1.setA(a);
    obj1.setB(b);
    Transaction tx = session.beginTransaction();
    session.save(a);
    session.save(b);
    session.save(obj1);
    tx.commit();
    assertEquals(1, obj1.getId().intValue());
    Session s = sf.openSession();
    Query q = s.getNamedQuery(DomainObject.class.getName() + ".testQuery");
    q.setFetchSize(100);
    q.setResultTransformer(new ResultTransformer()
      {
        public Object transformTuple(Object[] arg0, String[] arg1)
          {
          // return only the RelationA object from the query
          return arg0[1];
          }

        public List transformList(List arg0)
          {
          return arg0;
          }
      });
    ScrollableResults sr = q.scroll();
    sr.first();
    Object[] row = sr.get();
    assertEquals(1, row.length);
    Object obj = row[0];
    assertTrue(obj instanceof RelationA);
    RelationA obj2 = (RelationA) obj;
    assertEquals("Relation A", obj2.getName());
    s.close();
    }
  }
