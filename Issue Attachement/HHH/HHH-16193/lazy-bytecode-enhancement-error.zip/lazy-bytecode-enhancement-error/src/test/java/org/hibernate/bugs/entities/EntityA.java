package org.hibernate.bugs.entities;

import jakarta.persistence.*;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import org.hibernate.annotations.*;
import org.hibernate.annotations.Cache;

@Entity
@NamedQueries({
        @NamedQuery(name = "PersonType.selectAll",
                query = "SELECT a" +
                        "  FROM EntityA a"),
})
@BatchSize(size = 500)
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class EntityA {
    @Id
    @GeneratedValue
    private Long id;

    private String name;

    @ManyToOne
    private EntityB entityB;

    public EntityA() {
    }

    public EntityA(String name, EntityB entityB) {
        this.name = name;
        this.entityB = entityB;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public EntityB getEntityB() {
        return entityB;
    }

    public void setEntityB(EntityB entityB) {
        this.entityB = entityB;
    }
}
