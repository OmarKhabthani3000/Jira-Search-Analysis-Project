package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import org.hibernate.bugs.entities.EntityA;
import org.hibernate.bugs.entities.EntityB;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh123Test() throws Exception {
        createEntities();

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        List<EntityA> aList =
                entityManager.createNamedQuery("PersonType.selectAll", EntityA.class)
                        .getResultList();

        entityManager.getTransaction().commit();
        entityManager.close();

        Assert.assertEquals(1, aList.size());
        Assert.assertEquals("B1", aList.get(0).getEntityB().getName()); // LazyInitializationException
    }

    private void createEntities() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        EntityB b1 = new EntityB("B1");
        entityManager.persist(b1);
        EntityA a1 = new EntityA("A1", b1);
        entityManager.persist(a1);

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
