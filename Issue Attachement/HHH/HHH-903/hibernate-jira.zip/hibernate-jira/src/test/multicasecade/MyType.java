package test.multicasecade;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Properties;

import org.hibernate.EntityMode;
import org.hibernate.HibernateException;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.metadata.ClassMetadata;
import org.hibernate.usertype.ParameterizedType;
import org.hibernate.usertype.UserType;

import test.base.TestBase;

/**
 * my type class<br>
 * 
 * @author Giangnh <br>
 */
public class MyType implements UserType, ParameterizedType {

	/**
	 * sql types<br>
	 * 
	 * @return int[]
	 */
	public int[] sqlTypes() {
		return new int[]{Types.VARCHAR};
	}

	/**
	 * returned class<br>
	 * 
	 * @return Class
	 */
	public Class returnedClass() {
		return Name.class;
	}

	/**
	 * equals<br>
	 * 
	 * @param arg0
	 * @param arg1
	 * @return boolean
	 * @exception HibernateException
	 */
	public boolean equals(Object arg0, Object arg1) throws HibernateException {
		return arg0 == arg1;
	}

	/**
	 * hash code<br>
	 * 
	 * @param arg0
	 * @return int
	 * @exception HibernateException
	 */
	public int hashCode(Object arg0) throws HibernateException {
		return arg0.hashCode();
	}

	/**
	 * null safe get<br>
	 * 
	 * @param resultSet
	 * @param names
	 * @param owner
	 * @return Object
	 * @exception HibernateException
	 * @exception SQLException
	 */
	public Object nullSafeGet(ResultSet resultSet, String[] names, Object owner)
			throws HibernateException, SQLException {
		String _name = resultSet.getString(names[0]);
		Name name = new Name(_name);

		Serializable id = getIdentifier(owner);
		String prefix = (String) getSession().createCriteria(owner.getClass())//
				.setProjection(Projections.property("prefix"))//
				.add(Restrictions.idEq(id))//
				.uniqueResult();

		if (prefix != null) {
			String prefixName = (String) getSession().createCriteria(
					Prefix.class)//
					.add(Restrictions.eq("prefix", prefix))//
					.list()//
					.get(0);

			name.setPrfeix(prefixName);
		}

		return name;
	}

	/**
	 * get identifier<br>
	 * 
	 * @param owner
	 * @return Serializable
	 */
	private Serializable getIdentifier(Object owner) {
		ClassMetadata metadata = getSession().getSessionFactory()
				.getClassMetadata(owner.getClass());
		return metadata.getIdentifier(owner, EntityMode.POJO);
	}
	/**
	 * null safe set<br>
	 * 
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @exception HibernateException
	 * @exception SQLException
	 */
	public void nullSafeSet(PreparedStatement arg0, Object arg1, int arg2)
			throws HibernateException, SQLException {
		Name name = (Name) arg1;
		arg0.setString(arg2, name.toString());
	}

	/**
	 * deep copy<br>
	 * 
	 * @param arg0
	 * @return Object
	 * @exception HibernateException
	 */
	public Object deepCopy(Object arg0) throws HibernateException {
		return arg0;
	}

	/**
	 * is mutable<br>
	 * 
	 * @return boolean
	 */
	public boolean isMutable() {
		return false;
	}

	/**
	 * disassemble<br>
	 * 
	 * @param arg0
	 * @return Serializable
	 * @exception HibernateException
	 */
	public Serializable disassemble(Object arg0) throws HibernateException {
		return (Serializable) arg0;
	}

	/**
	 * assemble<br>
	 * 
	 * @param arg0
	 * @param arg1
	 * @return Object
	 * @exception HibernateException
	 */
	public Object assemble(Serializable arg0, Object arg1)
			throws HibernateException {
		return arg0;
	}

	/**
	 * replace<br>
	 * 
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @return Object
	 * @exception HibernateException
	 */
	public Object replace(Object arg0, Object arg1, Object arg2)
			throws HibernateException {
		return arg0;
	}

	/**
	 * set parameter values<br>
	 * 
	 * @param arg0
	 */
	public void setParameterValues(Properties arg0) {
	}

	private Session getSession() {
		return TestBase.session;
	}

}
