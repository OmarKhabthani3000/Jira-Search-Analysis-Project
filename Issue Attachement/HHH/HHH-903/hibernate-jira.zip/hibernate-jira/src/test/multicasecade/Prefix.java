package test.multicasecade;

/**
 *  prefix class<br>
 * @author Giangnh
 * <br>
 */
public class Prefix {
	/**
	 * Contructor Prefix<br>
	 */
	public Prefix() {
	}
	/**
	 * field id<br>
	 */
	String id;
	/**
	 * field prefix<br>
	 */
	String prefix;
	/**
	 * field prefix name<br>
	 */
	private String prefixName;
	/**
	 * Contructor Prefix<br>
	 * @param prefixName
	 * @param prefix
	 */
	public Prefix(String prefixName, String prefix) {
		this.prefixName = prefixName;
		this.prefix = prefix;
	}
	/**
	 * get id<br>
	 * @return String
	 */
	public String getId() {
		return id;
	}
	/**
	 * set id<br>
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * get prefix<br>
	 * @return String
	 */
	public String getPrefix() {
		return prefix;
	}
	/**
	 * set prefix<br>
	 * @param prefix
	 */
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	/**
	 * get prefix name<br>
	 * @return String
	 */
	public String getPrefixName() {
		return prefixName;
	}
	/**
	 * set prefix name<br>
	 * @param prefixName
	 */
	public void setPrefixName(String prefixName) {
		this.prefixName = prefixName;
	}
}
