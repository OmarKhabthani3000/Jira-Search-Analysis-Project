package test.multicasecade;

/**
 * entity2 class<br>
 * 
 * @author Giangnh <br>
 */
public class Entity2 implements java.io.Serializable {
	/**
	 * field name type<br>
	 */
	Name nameType;
	// Fields
	/**
	 * field prefix<br>
	 */
	String prefix;
	/**
	 * field id<br>
	 */
	private Long id;
	/**
	 * field name<br>
	 */
	private String name;
	/**
	 * field root<br>
	 */
	private RootEntity root;

	// Constructors

	/**
	 * Contructor Entity2<br>
	 */
	public Entity2() {
	}

	/**
	 * Contructor Entity2<br>
	 * 
	 * @param id
	 */
	public Entity2(Long id) {
		this.id = id;
	}

	// Property accessors

	/**
	 * get id<br>
	 * 
	 * @return Long
	 */
	public Long getId() {
		return this.id;
	}

	/**
	 * set id<br>
	 * 
	 * @param id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * get name<br>
	 * 
	 * @return String
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * set name<br>
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * get root<br>
	 * 
	 * @return RootEntity
	 */
	public RootEntity getRoot() {
		return this.root;
	}

	/**
	 * set root<br>
	 * 
	 * @param root
	 */
	public void setRoot(RootEntity root) {
		this.root = root;
	}

	/**
	 * get name type<br>
	 * 
	 * @return Name
	 */
	public Name getNameType() {
		return nameType;
	}

	/**
	 * set name type<br>
	 * 
	 * @param nameType
	 */
	public void setNameType(Name nameType) {
		this.nameType = nameType;
	}

	/**
	 * get prefix<br>
	 * 
	 * @return String
	 */
	public String getPrefix() {
		return prefix;
	}

	/**
	 * set prefix<br>
	 * 
	 * @param prefix
	 */
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

}