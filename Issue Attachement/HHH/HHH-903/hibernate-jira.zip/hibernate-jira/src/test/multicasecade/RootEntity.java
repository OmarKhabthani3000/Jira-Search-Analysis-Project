package test.multicasecade;

import java.util.HashSet;
import java.util.Set;

/**
 * root entity class<br>
 * 
 * @author Giangnh <br>
 */
public class RootEntity implements java.io.Serializable {

	// Fields

	/**
	 * field id<br>
	 */
	private Long id;
	/**
	 * field name<br>
	 */
	private String name;
	/**
	 * field one to many1<br>
	 */
	private Set oneToMany1;
	/**
	 * field one to many2<br>
	 */
	private Set oneToMany2;

	// Constructors

	/**
	 * Contructor RootEntity<br>
	 */
	public RootEntity() {
	}

	/**
	 * Contructor RootEntity<br>
	 * 
	 * @param id
	 */
	public RootEntity(Long id) {
		this.id = id;
	}

	// Property accessors

	/**
	 * get id<br>
	 * 
	 * @return Long
	 */
	public Long getId() {
		return this.id;
	}

	/**
	 * set id<br>
	 * 
	 * @param id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * get name<br>
	 * 
	 * @return String
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * set name<br>
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * get one to many1<br>
	 * 
	 * @return Set
	 */
	public Set getOneToMany1() {
		return this.oneToMany1;
	}

	/**
	 * set one to many1<br>
	 * 
	 * @param oneToMany1
	 */
	public void setOneToMany1(Set oneToMany1) {
		this.oneToMany1 = oneToMany1;
	}

	/**
	 * get one to many2<br>
	 * 
	 * @return Set
	 */
	public Set getOneToMany2() {
		return this.oneToMany2;
	}

	/**
	 * set one to many2<br>
	 * 
	 * @param oneToMany2
	 */
	public void setOneToMany2(Set oneToMany2) {
		this.oneToMany2 = oneToMany2;
	}

	/**
	 * add entity1<br>
	 * 
	 * @param entity1
	 */
	public void addEntity1(Entity1 entity1) {
		if (oneToMany1 == null) {
			oneToMany1 = new HashSet();
		}
		oneToMany1.add(entity1);
		entity1.setRoot(this);
	}

	/**
	 * add entity2<br>
	 * 
	 * @param entity2
	 */
	public void addEntity2(Entity2 entity2) {
		if (oneToMany2 == null) {
			oneToMany2 = new HashSet();
		}
		oneToMany2.add(entity2);
		entity2.setRoot(this);
	}

}