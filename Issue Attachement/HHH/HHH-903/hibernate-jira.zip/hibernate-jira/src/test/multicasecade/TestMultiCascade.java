package test.multicasecade;

import java.io.Serializable;

import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import test.base.TestBase;

/**
 * test multi cascade class<br>
 * 
 * @author Giangnh <br>
 */
public class TestMultiCascade extends TestBase {
	/**
	 * test delete<br>
	 * 
	 * @exception Exception
	 */
	public void testDelete() throws Exception {
		Serializable id;
		{
			initPrefixData();

			RootEntity rootEntity = new RootEntity();
			rootEntity.setName("root entity");

			for (int i = 0; i < 100; i++) {
				rootEntity.addEntity1(genEntity1());
				rootEntity.addEntity2(genEntity2());
			}

			id = save(rootEntity);

			restartSession();
		}

		{
			RootEntity rootEntity = (RootEntity) get(RootEntity.class, id);
			delete(rootEntity);
		}
	}

	/**
	 * init prefix data<br>
	 */
	private void initPrefixData() {
		save(new Prefix("nguyen", "Mr."));
		save(new Prefix("giang", "Ms."));
	}

	/**
	 * gen entity2<br>
	 * 
	 * @return Entity2
	 */
	private Entity2 genEntity2() {
		Entity2 entity2 = new Entity2();
		entity2.setName("entity 2");
		entity2.setNameType(new Name("nguyen giang"));
		return entity2;
	}

	/**
	 * gen entity1<br>
	 * 
	 * @return Entity1
	 */
	private Entity1 genEntity1() {
		Entity1 entity1 = new Entity1();
		entity1.setName("entity 1");
		entity1.setNameType(new Name("giang nguyen"));
		return entity1;
	}
}
