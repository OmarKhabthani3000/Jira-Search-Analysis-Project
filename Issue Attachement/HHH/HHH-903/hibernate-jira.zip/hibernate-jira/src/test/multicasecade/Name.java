package test.multicasecade;

/**
 * type class<br>
 * 
 * @author Giangnh <br>
 */
public class Name {
	/**
	 * field name1<br>
	 */
	String prfeix;
	
	/**
	 * field f name<br>
	 */
	String fName;
	/**
	 * field name2<br>
	 */
	String lName;
	/**
	 * Contructor Name<br>
	 * 
	 * @param name
	 */
	public Name(String name) {
		String[] split = name.split(" ");
		if (split.length > 0) {
			fName = split[0];
			if (split.length > 1) {
				lName = split[1];
			}
		}
	}
	/**
	 * get name1<br>
	 * 
	 * @return String
	 */
	public String getFName() {
		return fName;
	}
	/**
	 * set name1<br>
	 * 
	 * @param name1
	 */
	public void setFName(String name1) {
		this.fName = name1;
	}
	/**
	 * get name2<br>
	 * 
	 * @return String
	 */
	public String getLName() {
		return lName;
	}
	/**
	 * set name2<br>
	 * 
	 * @param name2
	 */
	public void setLName(String name2) {
		this.lName = name2;
	}
	/**
	 * to string<br>
	 * 
	 * @return String
	 */
	public String toString() {
		return n2b(fName) + " " + n2b(lName);
	}
	/**
	 * n2b<br>
	 * 
	 * @param name
	 * @return String
	 */
	private String n2b(String name) {
		return name == null ? "" : name;
	}
	/**
	 * get prfeix<br>
	 * @return String
	 */
	public String getPrfeix() {
		return prfeix;
	}
	/**
	 * set prfeix<br>
	 * @param prfeix
	 */
	public void setPrfeix(String prfeix) {
		this.prfeix = prfeix;
	}
}
