package hibernate.issues.hhhh3534;

/**
 * Created by emaus on 20.12.13.
 */
public class Hhhh3534 {
}
