package hibernate.issues.hhhh3534;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.GenericGenerator;

/**
 * Created by emaus on 20.12.13.
 */
@Entity
public class Issue {

    @Id
    @GeneratedValue(generator="increment")
    @GenericGenerator(name="increment", strategy = "increment")
    private Long id;

    @ManyToOne
    private User reporter;

    private String issueId;

    private String state;

    public Issue() {
    }

    public Issue(User reporter, String issueId, String state) {
        this.id = id;
        this.reporter = reporter;
        this.issueId = issueId;
        this.state = state;
    }

    public Long getId() {
        return id;
    }

    public User getReporter() {
        return reporter;
    }

    public String getIssueId() {
        return issueId;
    }

    public String getState() {
        return state;
    }
}
