package hibernate.issues.hhhh3534;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Created by emaus on 20.12.13.
 */
public class Hhhh3534Test {

    private static SessionFactory sessionFactory;
    private Session session;
    private static Configuration config;
    private Transaction transaction;
    long nextId = 1L;

    @BeforeClass
    public static void setUpClass() throws Exception {
        config = new Configuration();
        config.addAnnotatedClass(User.class).addAnnotatedClass(Issue.class);
        config.setProperty("show_sql", "true");
        config.configure();
        sessionFactory = config.buildSessionFactory();
    }
    @Before
    public void setUp() throws Exception {
        session = sessionFactory.openSession();
        transaction = session.beginTransaction();
    }

    @After
    public void tearDown() throws Exception {
        session.close();
        transaction.rollback();
        nextId = 1;
    }

    @Test
    public void detachedQueryShouldNotUse_thisAsQueryAlias() {
        final User brett = new User("Brett Meyer");
        session.persist(brett);
        final User eirik = new User("Eirik Maus");
        session.persist(eirik);

        session.persist(new Issue(eirik, "hhhh-3435", "awaiting testcase"));
        session.persist(new Issue(eirik, "hhhh-2852", "closed"));

        session.flush();
        session.clear();

        Criteria criteria = session.createCriteria(User.class);
        DetachedCriteria subquery = DetachedCriteria.forClass(Issue.class);
        subquery.add(Restrictions.eq("state", "awaiting testcase"));
        subquery.add(Restrictions.eqProperty("reporter.id", "this.id"));
        criteria.add(Subqueries.exists(subquery));
        assertThat(criteria.list().size(), is(1));
    }
}
