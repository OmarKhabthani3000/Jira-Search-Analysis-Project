package org.hibernate.bugs;

import java.util.Collections;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.hql.internal.ast.ASTQueryTranslatorFactory;
import org.hibernate.hql.spi.QueryTranslator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import junit.framework.Assert;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		String queryString = "select dummy2.id,dummy2.dummy1.sourceId from Dummy2 dummy2";
		Session session = entityManager.unwrap(Session.class);
		SessionFactory sessionFactory = session.getSessionFactory();
		final QueryTranslator translator 
		= new ASTQueryTranslatorFactory().createQueryTranslator(queryString, queryString, Collections.EMPTY_MAP, 
				(SessionFactoryImplementor) sessionFactory,null);
        translator.compile(Collections.EMPTY_MAP, false);
        String strQuery = translator.getSQLString();
        System.out.println(strQuery);
		entityManager.getTransaction().commit();
		entityManager.close();
		Assert.assertEquals(true, strQuery.contains("dummy1x1_.SOURCE_ID"));
	}
}
