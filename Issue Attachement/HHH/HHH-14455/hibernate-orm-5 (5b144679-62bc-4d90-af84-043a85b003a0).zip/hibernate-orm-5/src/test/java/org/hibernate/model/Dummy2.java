package org.hibernate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "dummy2")
public class Dummy2 {

    private int id;
    
    private Dummy1 dummy1;

    private String dummy1Id;
    
    public Dummy2() {

    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Student [id=" + id + ", sourceId=" + "]";
    }

    @ManyToOne(fetch = FetchType.LAZY)
   	@JoinColumn(name = "SOURCE_ID",referencedColumnName="SOURCE_ID")
	public Dummy1 getDummy1() {
		return dummy1;
	}

	public void setDummy1(Dummy1 dummy1) {
		this.dummy1 = dummy1;
	}

	@Column(name = "SOURCE_ID", length = 300, updatable = false, insertable=false)
	public String getDummy1Id() {
		return dummy1Id;
	}

	public void setDummy1Id(String dummy1Id) {
		this.dummy1Id = dummy1Id;
	}
}