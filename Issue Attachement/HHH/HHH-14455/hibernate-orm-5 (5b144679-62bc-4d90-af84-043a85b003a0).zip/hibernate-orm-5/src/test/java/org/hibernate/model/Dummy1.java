package org.hibernate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dummy1")
public class Dummy1 {

    private int id;

    private String sourceId;

    public Dummy1() {

    }
    
    public Dummy1(String sourceId) {
        this.sourceId = sourceId;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "SOURCE_ID",unique = true, length = 20)
    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }


    @Override
    public String toString() {
        return "Student [id=" + id + ", sourceId=" + sourceId + "]";
    }
}