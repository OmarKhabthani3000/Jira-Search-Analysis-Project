package org.hibernate.bugs;

import java.io.Serializable;
import java.time.temporal.TemporalAccessor;

import javax.persistence.Column;
//import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

//import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@MappedSuperclass
//@EntityListeners(AuditingEntityListener.class)
public abstract class AbstractJpaAuditedEntity<I extends Serializable, U, T extends TemporalAccessor> implements Serializable, HasJpaAuditing<U, T> {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	protected I id;

	@Column(updatable = false)
	protected U createUser;
	@Column(updatable = false)
	protected T createTime;

	protected U updateUser;
	protected T updateTime;

	@Override
	public U getCreateUser() {
		return createUser;
	}

	@Override
	public T getCreateTime() {
		return createTime;
	}

	@Override
	public U getUpdateUser() {
		return updateUser;
	}

	@Override
	public T getUpdateTime() {
		return updateTime;
	}

	public I getId() {
		return id;
	}

	public void setId(I id) {
		this.id = id;
	}

}