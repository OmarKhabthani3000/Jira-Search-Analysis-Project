package org.hibernate.bugs;

import java.time.LocalDateTime;

import javax.persistence.Entity;

@Entity
public class TestEntity extends AbstractJpaAuditedEntity<Long, String, LocalDateTime> {

	private static final long serialVersionUID = 1L;

}