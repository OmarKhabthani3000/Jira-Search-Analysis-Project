package org.hibernate.bugs;

import java.time.temporal.TemporalAccessor;

//import org.springframework.data.annotation.CreatedBy;
//import org.springframework.data.annotation.CreatedDate;
//import org.springframework.data.annotation.LastModifiedBy;
//import org.springframework.data.annotation.LastModifiedDate;

public interface HasJpaAuditing<U, T extends TemporalAccessor> {

	//@CreatedBy
	U getCreateUser();

	//@CreatedDate
	T getCreateTime();

	//@LastModifiedBy
	U getUpdateUser();

	//@LastModifiedDate
	T getUpdateTime();

}