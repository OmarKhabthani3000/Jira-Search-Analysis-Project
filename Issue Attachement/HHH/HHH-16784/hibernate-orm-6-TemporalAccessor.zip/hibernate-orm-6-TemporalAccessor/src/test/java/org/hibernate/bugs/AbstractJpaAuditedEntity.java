package org.hibernate.bugs;

import java.io.Serial;
import java.io.Serializable;
import java.time.temporal.TemporalAccessor;

import jakarta.persistence.Column;
//import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;

//import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@MappedSuperclass
//@EntityListeners(AuditingEntityListener.class)
public abstract class AbstractJpaAuditedEntity<I extends Serializable, U, T extends TemporalAccessor> implements Serializable, HasJpaAuditing<U, T> {

	@Serial
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	protected I id;

	@Column(updatable = false)
	protected U createUser;
	@Column(updatable = false)
	protected T createTime;

	protected U updateUser;
	protected T updateTime;

	@Override
	public U getCreateUser() {
		return createUser;
	}

	@Override
	public T getCreateTime() {
		return createTime;
	}

	@Override
	public U getUpdateUser() {
		return updateUser;
	}

	@Override
	public T getUpdateTime() {
		return updateTime;
	}

	public I getId() {
		return id;
	}

	public void setId(I id) {
		this.id = id;
	}

}