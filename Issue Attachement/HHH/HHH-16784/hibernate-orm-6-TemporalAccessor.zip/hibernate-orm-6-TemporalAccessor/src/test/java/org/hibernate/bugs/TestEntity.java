package org.hibernate.bugs;

import java.io.Serial;
import java.time.LocalDateTime;

import jakarta.persistence.Entity;

@Entity
public class TestEntity extends AbstractJpaAuditedEntity<Long, String, LocalDateTime> {
	@Serial
	private static final long serialVersionUID = 1L;

}