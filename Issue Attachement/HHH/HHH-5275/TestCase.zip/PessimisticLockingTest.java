package org.hibernate.test.pessimisticlocking;

import junit.framework.Test;

import org.hibernate.Criteria;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;

/**
 * @author Bj�rn Moritz
 */
public class PessimisticLockingTest extends FunctionalTestCase {

	public PessimisticLockingTest(String x) {
		super(x);
	}

	public String[] getMappings() {
		return new String[] { "pessimisticlocking/A.hbm.xml" };
	}

	public static Test suite() {
		return new FunctionalTestClassTestSuite(PessimisticLockingTest.class);
	}

	public void testInsert() throws Exception {
		final Session s;
		Transaction tx;

		s = openSession();
		tx = s.beginTransaction();

		A a = new A();
		a.setValue("Test");

		s.save(a);

		tx.commit();

		// first runnable: Tries to load A with id 1 in lock mode with wait
		Runnable runnable1 = new Runnable() {
			public void run() {
				try {
					Transaction tx = s.beginTransaction();
					Criteria crit = s.createCriteria(A.class);
					crit.setLockMode(LockMode.PESSIMISTIC_WRITE);
					crit.add(Restrictions.eq("value", "Test"));
					assertNotNull(crit.uniqueResult());
					Thread.sleep(1000);
					tx.commit();
				} catch (Exception e) {

				}
			}
		};

		// second runnable: Waits for 500ms and then tries to load A with id 1
		// in lock mode without wait (expected to fail!)
		Runnable runnable2 = new Runnable() {
			public void run() {
				Transaction tx = null;
				try {
					Thread.sleep(500);
					tx = s.beginTransaction();
					Criteria crit = s.createCriteria(A.class);
					crit.add(Restrictions.eq("id", 1));
					assertNotNull(crit.uniqueResult());
					fail("Expected exception did not occur!");
				} catch (Exception e) {
					if (tx != null) {
						tx.commit();
					}
				}
			}
		};

		new Thread(runnable1).run();
		new Thread(runnable2).run();
		s.close();
	}
}