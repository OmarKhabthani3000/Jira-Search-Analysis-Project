create table [BDS_2_GDDEMO_VEHICLE] ([BDS_ID] numeric(19,0) not null, [VEHICLEID] nvarchar(400) not null unique, primary key ([BDS_ID]));

create table [BDS_2_GDDEMO_CAR] ([VEHICLE_BDSID] numeric(19,0) not null, [MODEL] nvarchar(400) null, [CAR_CUSTOMER_BDSID] numeric(19,0) null, [CUSTOMER_CARS_IDX] int null, primary key ([VEHICLE_BDSID]));

create table [BDS_2_GDDEMO_CUSTOMER] ([BDS_ID] numeric(19,0) not null, [NAME] nvarchar(400) null, primary key ([BDS_ID]));


create index IDX_2_GDDEMO_4D7D759B8442F2418 on [BDS_2_GDDEMO_CAR] ([CAR_CUSTOMER_BDSID]);

alter table [BDS_2_GDDEMO_CAR] add constraint FK9503290FABE5971 foreign key ([CAR_CUSTOMER_BDSID]) references [BDS_2_GDDEMO_CUSTOMER];

alter table [BDS_2_GDDEMO_CAR] add constraint FK9503290583BDD8 foreign key ([VEHICLE_BDSID]) references [BDS_2_GDDEMO_VEHICLE];

create index IDX_2_GDDEMO_50956F9F9DD406186 on [BDS_2_GDDEMO_CUSTOMER] ([NAME]);

