package business;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import things.Car;
import things.Customer;

public class HibernateTest
{
	public static void main(String[] args)
	{
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		Car theCar = new Car();
		theCar.setBdsId(new Long(1));
		theCar.setVehicleID("123");
		theCar.setModel("Ford");
		session.save(theCar);
		
		Customer theCustomer = new Customer();
		theCustomer.setBdsId(new Long(2));
		theCustomer.setName("My Name");
		theCustomer.getCars().add(theCar);
		theCar.setCustomer(theCustomer);
		session.save(theCustomer);

		session.flush();
		session.getTransaction().commit();
		
		System.out.println("Setup initial data");

		Query q = session.createQuery("SELECT DISTINCT co.bdsId, co.name FROM things.Customer co WHERE EXISTS (FROM co.cars t0 WHERE (t0.vehicleID = :hp0)) ORDER BY co.name, co.bdsId");
		q.setParameter("hp0", "123");
		
		List<?> result = q.list();
		System.out.println(result);
		
		session.close();
	}
}
