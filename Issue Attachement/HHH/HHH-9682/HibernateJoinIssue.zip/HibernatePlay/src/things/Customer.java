package things;

import java.util.ArrayList;
import java.util.List;

public class Customer {
	private Long bdsId;

	private String name;

	private List<Car> cars = new ArrayList<Car>();

	public Customer() {}

	public Long getBdsId() {
		return bdsId;
	}

	public void setBdsId(Long bdsId) {
		this.bdsId = bdsId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Car> getCars() {
		return cars;
	}

	public void setCars(List<Car> cars) {
		this.cars = cars;
	}

}
