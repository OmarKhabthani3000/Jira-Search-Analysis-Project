package things;

public class Vehicle {
	private Long bdsId;

	private String vehicleID;

	public Vehicle() {}

	public Long getBdsId() {
		return bdsId;
	}

	public void setBdsId(Long bdsId) {
		this.bdsId = bdsId;
	}

	public String getVehicleID() {
		return vehicleID;
	}

	public void setVehicleID(String vehicleID) {
		this.vehicleID = vehicleID;
	}

}
