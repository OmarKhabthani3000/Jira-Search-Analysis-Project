package hibernate.bug;

import hibernate.bug.model.Car;
import hibernate.bug.model.Customer;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Customer c1 = new Customer("c1");
        Customer c2 = new Customer("c2");
        
        Car car1 = new Car("A5", c1, "ABC123");
        Car car2 = new Car("S5", c2, "DEF456");
        
        em.persist(c1);
        em.persist(c2);
        em.persist(car1);
        em.persist(car2);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testIssue1() {
        EntityManager em = emf.createEntityManager();
        
        // Apart from missing select, this is JPA syntax
        // See examples from JPA spec 4.6.16
        List<String> list = em.createQuery("SELECT DISTINCT customer.name FROM Customer customer WHERE EXISTS (FROM customer.cars car WHERE car.vehicleId = :vehicleId)", String.class)
                .setParameter("vehicleId", "ABC123")
                .getResultList();
        Assert.assertEquals("c1", list.get(0));

        em.close();
    }
    
    @Test
    public void testIssue2() {
        EntityManager em = emf.createEntityManager();
        
        // This is JPA syntax
        // See examples from JPA spec 4.6.16
        List<String> list = em.createQuery("SELECT DISTINCT customer.name FROM Customer customer WHERE EXISTS (SELECT 1 FROM customer.cars car WHERE car.vehicleId = :vehicleId)", String.class)
                .setParameter("vehicleId", "ABC123")
                .getResultList();
        Assert.assertEquals("c1", list.get(0));

        em.close();
    }
    
    @Test
    public void testIssue3() {
        EntityManager em = emf.createEntityManager();
        
        // Apart from missing select, this is JPA syntax
        // see derived_collection_member_declaration in BNF
        List<String> list = em.createQuery("SELECT DISTINCT customer.name FROM Customer customer WHERE EXISTS (FROM IN customer.cars car WHERE car.vehicleId = :vehicleId)", String.class)
                .setParameter("vehicleId", "ABC123")
                .getResultList();
        Assert.assertEquals("c1", list.get(0));

        em.close();
    }
    
    @Test
    public void testIssue4() {
        EntityManager em = emf.createEntityManager();
        
        // This is JPA syntax
        // see derived_collection_member_declaration in BNF
        List<String> list = em.createQuery("SELECT DISTINCT customer.name FROM Customer customer WHERE EXISTS (SELECT 1 FROM IN customer.cars car WHERE car.vehicleId = :vehicleId)", String.class)
                .setParameter("vehicleId", "ABC123")
                .getResultList();
        Assert.assertEquals("c1", list.get(0));

        em.close();
    }
}
