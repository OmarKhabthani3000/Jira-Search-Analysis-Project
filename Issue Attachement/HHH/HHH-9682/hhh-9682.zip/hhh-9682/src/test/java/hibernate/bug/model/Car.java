
package hibernate.bug.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

@Entity
public class Car extends Vehicle {
    
    private String model;
    private Customer customer;

    public Car() {
    }

    public Car(String model, Customer customer, String vehicleId) {
        super(vehicleId);
        this.model = model;
        this.customer = customer;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

}
