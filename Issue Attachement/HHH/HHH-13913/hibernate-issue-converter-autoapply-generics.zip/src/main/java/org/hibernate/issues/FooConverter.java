package org.hibernate.issues;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class FooConverter implements AttributeConverter<Foo, String> {

    @Override
    public String convertToDatabaseColumn(final Foo attribute) {
        return attribute.value();
    }

    @Override
    public Foo convertToEntityAttribute(final String dbData) {
        return Foo.from(dbData);
    }
}
