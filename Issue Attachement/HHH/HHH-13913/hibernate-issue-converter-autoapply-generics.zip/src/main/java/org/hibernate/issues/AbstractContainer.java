package org.hibernate.issues;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class AbstractContainer<T> {

    @Id
    @GeneratedValue
    private Integer id;

    private T value;

    protected AbstractContainer() {
        super();
    }

    protected AbstractContainer(final T value) {
        super();
        setValue(value);
    }

    public Integer getId() {
        return id;
    }

    public T getValue() {
        return value;
    }

    public final void setValue(final T value) {
        this.value = value;
    }
}
