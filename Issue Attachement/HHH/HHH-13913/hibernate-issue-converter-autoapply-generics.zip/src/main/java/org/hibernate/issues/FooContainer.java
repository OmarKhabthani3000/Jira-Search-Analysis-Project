package org.hibernate.issues;

import javax.persistence.Entity;

@Entity
public class FooContainer extends AbstractContainer<Foo> {
    protected FooContainer() {
        super();
    }

    public FooContainer(Foo value) {
        super(value);
    }
}
