package org.hibernate.issues;

public interface Foo {

    String value();

    public static Foo from(String value) {
        return new Foo() {
            @Override
            public String value() {
                return value;
            }
        };
    }
}
