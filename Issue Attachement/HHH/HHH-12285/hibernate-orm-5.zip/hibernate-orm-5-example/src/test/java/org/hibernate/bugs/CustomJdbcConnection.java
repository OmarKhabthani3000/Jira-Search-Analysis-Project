package org.hibernate.bugs;

import org.h2.jdbc.JdbcConnection;

import java.sql.SQLException;
import java.util.Properties;

public class CustomJdbcConnection extends JdbcConnection {
    private boolean throwErrorOnNextRollback;
    private boolean throwErrorOnNextCommit;

    public CustomJdbcConnection(String s, Properties properties) throws SQLException {
        super(s, properties);
    }

    void setThrowErrorOnNextRollback(boolean throwErrorOnNextRollback) {
        this.throwErrorOnNextRollback = throwErrorOnNextRollback;
    }

    void setThrowErrorOnNextCommit(boolean throwErrorOnNextCommit) {
        this.throwErrorOnNextCommit = throwErrorOnNextCommit;
    }

    public synchronized void rollback() throws SQLException {
        if (throwErrorOnNextRollback) {
            throwErrorOnNextRollback = false;
            throw new SQLException("Connection error during rollback");
        } else {
            super.rollback();
        }
    }

    public synchronized void commit() throws SQLException {
        if (throwErrorOnNextCommit) {
            throwErrorOnNextCommit = false;
            throw new SQLException("Connection error during commit");
        } else {
            super.commit();
        }
    }
}
