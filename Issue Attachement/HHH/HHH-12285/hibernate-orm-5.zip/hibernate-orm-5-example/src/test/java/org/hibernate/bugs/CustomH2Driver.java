package org.hibernate.bugs;

import org.h2.Driver;
import org.h2.message.DbException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class CustomH2Driver extends org.h2.Driver {
    private static final Driver INSTANCE = new CustomH2Driver();

    public static final String START_URL = "jdbc:h2test:";

    private static volatile boolean registered;

    static {
        load();
    }

    public static synchronized Driver load() {
        try {
            if (!registered) {
                registered = true;
                DriverManager.registerDriver(INSTANCE);
            }
        } catch (SQLException e) {
        }
        return INSTANCE;
    }

    @Override
    public boolean acceptsURL(String url) {
        if (url != null) {
            if (url.startsWith(START_URL)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public Connection connect(String url, Properties info) throws SQLException {
        try {
            if (info == null) {
                info = new Properties();
            }
            if (!acceptsURL(url)) {
                return null;
            }
            return new CustomJdbcConnection(url.replace("jdbc:h2test", "jdbc:h2"), info);
        } catch (Exception e) {
            throw DbException.toSQLException(e);
        }
    }
}
