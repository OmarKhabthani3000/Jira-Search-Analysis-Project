package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.RollbackException;

import org.hibernate.TransactionException;
import org.junit.Assert;
import org.hibernate.engine.jdbc.spi.JdbcCoordinator;
import org.hibernate.internal.SessionImpl;
import org.hibernate.resource.jdbc.LogicalConnection;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void cleanupOnRollbackError() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		JdbcCoordinator connector = ((SessionImpl)entityManager).getJdbcCoordinator();
		LogicalConnection logicalConnection = connector.getLogicalConnection();

        CustomJdbcConnection connection = (CustomJdbcConnection)((SessionImpl)entityManager).connection();
        connection.setThrowErrorOnNextRollback(true);

        assertThrows(() -> entityManager.getTransaction().rollback(), TransactionException.class);

        // This should release the connection back to the pool, but does not
		entityManager.close();

        boolean isConnected = logicalConnection.isPhysicallyConnected();

        // This fails, the connection is still active in the connection pool and is never released
        Assert.assertEquals(false, isConnected);
	}

	// This one is ok (provided the underlying connection only throws one exception on the first commit)
    @Test
	public void cleanupOnCommitError() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

        JdbcCoordinator connector = ((SessionImpl)entityManager).getJdbcCoordinator();
        LogicalConnection logicalConnection = connector.getLogicalConnection();

        CustomJdbcConnection connection = (CustomJdbcConnection)((SessionImpl)entityManager).connection();
        connection.setThrowErrorOnNextCommit(true);

        assertThrows(() -> entityManager.getTransaction().commit(), RollbackException.class);

		entityManager.close();

        boolean isConnected = logicalConnection.isPhysicallyConnected();

        // This one is ok
        Assert.assertEquals(false, isConnected);
	}

    private void assertThrows(Runnable function, Class<? extends Throwable> exceptionClass) {
        Throwable throwable = null;
        try {
            function.run();
        } catch (Throwable t) {
            throwable = t;
        }
        Assert.assertNotNull(throwable);
        Assert.assertEquals(exceptionClass, throwable.getClass());
    }
}
