package org.hibernate.params.test.domain;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.FilterDefs;
import org.hibernate.annotations.Filters;
import org.hibernate.annotations.ParamDef;

/**
 * 
 * @author szacharov
 */
@FilterDefs({
        @FilterDef(defaultCondition = "name in (:allowedCustomerNames)", name = "customerNameFilter", parameters = {
                @ParamDef(type = "string", name = "allowedCustomerNames") }) })
@Filters({ @Filter(name = "customerNameFilter") })
@Entity
@Table(name = "CustomerEntity")
public class Customer {

    @Id
    @GeneratedValue
    private Long customerId;

    private String name;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn()
    @Cascade(org.hibernate.annotations.CascadeType.ALL)
    private CustomerDetail customerDetail;

    private Date registration;

    private boolean archivedInd;

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public CustomerDetail getCustomerDetail() {
        return customerDetail;
    }

    public void setCustomerDetail(CustomerDetail customerDetail) {
        this.customerDetail = customerDetail;
    }

    public Date getRegistration() {
        return registration;
    }

    public void setRegistration(Date registration) {
        this.registration = registration;
    }

    public boolean isArchivedInd() {
        return archivedInd;
    }

    public void setArchivedInd(boolean archivedInd) {
        this.archivedInd = archivedInd;
    }
}