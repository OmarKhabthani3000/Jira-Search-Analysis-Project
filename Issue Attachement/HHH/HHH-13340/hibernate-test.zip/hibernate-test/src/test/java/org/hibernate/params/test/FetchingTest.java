package org.hibernate.params.test;

import static org.junit.Assert.assertFalse;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.annotations.FetchMode;
import org.hibernate.params.test.domain.Customer;
import org.hibernate.params.test.domain.CustomerDetail;
import org.hibernate.params.test.domain.CustomerOrder;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

/**
 * Test filter in conjunction with fetching.
 * 
 * @author Sergej Zacharov
 * @author Vit Novak
 */
public class FetchingTest extends BaseCoreFunctionalTestCase {

    private static final String QUERY = "SELECT c FROM Customer c " + 
                                        "LEFT OUTER JOIN FETCH c.customerDetail det " + 
                                        "WHERE c.name IN (SELECT name FROM Customer WHERE id = (:id) " + 
                                        "AND registration <= (SELECT c2.registration FROM Customer c2 WHERE c2.id=:id)) " + 
                                        "ORDER BY name DESC";

    @Override
    protected Class<?>[] getAnnotatedClasses() {
        return new Class[] { Customer.class, CustomerOrder.class, CustomerDetail.class};
    }

    /**
     * Tests fetching a collection using {@link FetchMode.SUBSELECT} when the parent
     * uses parametrized filter.
     * 
     * There are some "user" params (id) and Filter params (allowedCustomerNames).
     * The issue occurs when hibernate is trying to set "IBM" onto "id" parameter.
     * Most likely because id parameter is used twice in the query.
     * 
     */
    @Test
    public void testSubselect() {
        openSession();

        session.enableFilter("customerNameFilter").setParameter("allowedCustomerNames", "IBM");

        Query q = session.createQuery(QUERY);
        q.setParameter("id", 1L);

        @SuppressWarnings("unchecked")
        List<Customer> result = q.getResultList();

        assertFalse(result.isEmpty());
        assertFalse(result.get(0).getCustomerDetail().getOrders().isEmpty());
    }
}
