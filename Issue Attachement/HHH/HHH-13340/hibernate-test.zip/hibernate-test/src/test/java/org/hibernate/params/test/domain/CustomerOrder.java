package org.hibernate.params.test.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * 
 * @author szacharov
 */
@Entity
public class CustomerOrder {

    @Id
    @GeneratedValue
    private Long orderId;

    private Long total;
    
    private String name;

    public Long getOrderId() {
        return orderId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }
}