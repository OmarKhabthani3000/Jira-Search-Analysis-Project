insert into CustomerDetail(id) values(1);
insert into CustomerDetail(id) values(2);

insert into CustomerEntity(customerId, customerDetail_id, name, registration, archivedInd) values(1, 1, 'IBM', '2017-01-01', 'false');
insert into CustomerEntity(customerId, customerDetail_id, name, registration, archivedInd) values(2, 2, 'IBM', '2017-01-01', 'false');

insert into CustomerOrder(orderId, customerDetail_id, total, name) values(1, 1, 100, 'IBM');
insert into CustomerOrder(orderId, customerDetail_id, total, name) values(2, 1, 200, 'IBM');
insert into CustomerOrder(orderId, customerDetail_id, total, name) values(3, 1, 200, 'IBM');
insert into CustomerOrder(orderId, customerDetail_id, total, name) values(4, 2, 300, 'IBM');
insert into CustomerOrder(orderId, customerDetail_id, total, name) values(5, 2, 400, 'IBM');
insert into CustomerOrder(orderId, customerDetail_id, total, name) values(6, 2, 500, 'IBM');