
package org.hibernate.test.instrument2.domain2;


import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;


@Entity
@DiscriminatorValue("SAVINGS")
public class SavingsCustomerAccount extends SavingsCustomerAccountBase
{
}