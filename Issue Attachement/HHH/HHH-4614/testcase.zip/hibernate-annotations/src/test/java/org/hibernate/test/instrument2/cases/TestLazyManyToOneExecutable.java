package org.hibernate.test.instrument2.cases;

import junit.framework.Assert;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.instrument2.domain2.AccountProduct;
import org.hibernate.test.instrument2.domain2.CustomerAccount;
import org.hibernate.test.instrument2.domain2.SavingsCustomerAccount;
import org.hibernate.test.instrument2.domain2.SavingsProduct;

/**
 * @author Steve Ebersole
 */
public class TestLazyManyToOneExecutable extends AbstractExecutable {
	public void execute() {
		Session s = getFactory().openSession();
		Transaction t = s.beginTransaction();
		
		SavingsCustomerAccount savingsCustomerAccount = new SavingsCustomerAccount();
		SavingsProduct savingsProduct = new SavingsProduct();
		savingsProduct.setName("blah");
		savingsCustomerAccount.setAccountProduct(savingsProduct);
		s.persist(savingsCustomerAccount);
		t.commit();
		s.close();
//
//		// NOTE : child is mapped with lazy="proxy"; sibling with lazy="no-proxy"...
//
		s = getFactory().openSession();
		t = s.beginTransaction();
		CustomerAccount customerAccount = ( CustomerAccount )s.get(SavingsCustomerAccount.class, savingsCustomerAccount.getId());
		AccountProduct accountProduct = customerAccount.getAccountProduct();
		Assert.assertTrue( Hibernate.isInitialized(accountProduct) );
		Assert.assertEquals(accountProduct.getName(), savingsProduct.getName() );
		

		//s.delete(savingsCustomerAccount);
		t.commit();
		s.close();
	}
}
