
package org.hibernate.test.instrument2.domain2;


import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.SequenceGenerator;
import javax.persistence.Transient;


@MappedSuperclass
public abstract class CustomerAccountBase /*implements DomainBase*/
{

	@Id
	@SequenceGenerator(name = "generator::at.ing.diba.domain.testcase.CustomerAccount", sequenceName = "SEQ_CAC", allocationSize = 20, initialValue = 1)
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator::at.ing.diba.domain.testcase.CustomerAccount")
	@Column(name = "CAC_ID")
	private Long id;




	@ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH}, fetch = FetchType.LAZY)
//	@org.hibernate.annotations.LazyToOne(value = org.hibernate.annotations.LazyToOneOption.PROXY /*vormals: NO_PROXY*/)
	@org.hibernate.annotations.LazyToOne(value = org.hibernate.annotations.LazyToOneOption.NO_PROXY)
	@org.hibernate.annotations.ForeignKey(name = "ACC_PRODUCT_FK")
	@org.hibernate.annotations.Index(name = "IX_ACC_PRODUCT")
	@JoinColumn(name = "ACC_PRODUCT")
	private AccountProduct accountProduct;


	public Long getId() {
		return id;
	}

	@Transient
	abstract public BigDecimal getInterestRate();


	public AccountProduct getAccountProduct() {
		return accountProduct;
	}


	public void setAccountProduct(AccountProduct accountProduct) {
		this.accountProduct = accountProduct;
	}

}