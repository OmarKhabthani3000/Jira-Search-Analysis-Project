//$Id: $
package org.hibernate.test.instrument2.runtime;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.bytecode.BytecodeProvider;
import org.hibernate.bytecode.javassist.BytecodeProviderImpl;

/**
 * @author Steve Ebersole
 */
public class JavassistInstrumentationTest extends AbstractTransformingClassLoaderInstrumentTestCase {
	public JavassistInstrumentationTest(String string) {
		super( string );
	}

	protected BytecodeProvider buildBytecodeProvider() {
		return new BytecodeProviderImpl();
	}

	public static Test suite() {
		return new TestSuite( JavassistInstrumentationTest.class );
	}


	public void testLazyManyToOne() {
		super.testLazyManyToOne();
	}



	
	
}
