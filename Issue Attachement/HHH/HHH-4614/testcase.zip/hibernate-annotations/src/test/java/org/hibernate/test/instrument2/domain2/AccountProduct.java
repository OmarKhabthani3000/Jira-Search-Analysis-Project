
package org.hibernate.test.instrument2.domain2;


import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.hibernate.annotations.AccessType;


@Entity
@Table(name = "ACCOUNTPRODUCT")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "ACP_DISCRIMINATOR", discriminatorType = DiscriminatorType.STRING)
abstract public class AccountProduct extends AccountProductBase
{
}