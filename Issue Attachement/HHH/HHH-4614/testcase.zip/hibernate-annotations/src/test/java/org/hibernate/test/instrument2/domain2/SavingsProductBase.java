
package org.hibernate.test.instrument2.domain2;


import javax.persistence.MappedSuperclass;


@MappedSuperclass
public abstract class SavingsProductBase extends AccountProduct
{

}