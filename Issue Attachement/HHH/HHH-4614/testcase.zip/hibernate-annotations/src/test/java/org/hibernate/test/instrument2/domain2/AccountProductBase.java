
package org.hibernate.test.instrument2.domain2;


import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.SequenceGenerator;
import javax.persistence.Version;

import org.hibernate.annotations.AccessType;


@MappedSuperclass
public abstract class AccountProductBase /*implements DomainBase*/
{

	@Id
	@SequenceGenerator(name = "generator::at.ing.diba.domain.testcase.AccountProduct", sequenceName = "SEQ_ACP", allocationSize = 20, initialValue = 1)
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator::at.ing.diba.domain.testcase.AccountProduct")
	@Column(name = "ACP_ID")
	private Long id;

	public Long getId() {
		return id;
	}

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}