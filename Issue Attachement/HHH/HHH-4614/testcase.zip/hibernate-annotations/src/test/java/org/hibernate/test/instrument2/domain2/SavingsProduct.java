
package org.hibernate.test.instrument2.domain2;


import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;


@Entity
@DiscriminatorValue("SAVINGSPRODUCT")
public class SavingsProduct extends SavingsProductBase
{

	
}