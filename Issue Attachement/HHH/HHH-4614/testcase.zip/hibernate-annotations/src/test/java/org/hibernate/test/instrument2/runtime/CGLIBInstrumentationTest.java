package org.hibernate.test.instrument2.runtime;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.bytecode.BytecodeProvider;
import org.hibernate.bytecode.cglib.BytecodeProviderImpl;

/**
 * @author Steve Ebersole
 */
public class CGLIBInstrumentationTest extends AbstractTransformingClassLoaderInstrumentTestCase {
	public CGLIBInstrumentationTest(String string) {
		super( string );
	}

	protected BytecodeProvider buildBytecodeProvider() {
		return new BytecodeProviderImpl();
	}

	public static Test suite() {
		return new TestSuite( CGLIBInstrumentationTest.class );
	}



	public void testLazyManyToOne() {
		super.testLazyManyToOne();    //To change body of overridden methods use File | Settings | File Templates.
	}


}
