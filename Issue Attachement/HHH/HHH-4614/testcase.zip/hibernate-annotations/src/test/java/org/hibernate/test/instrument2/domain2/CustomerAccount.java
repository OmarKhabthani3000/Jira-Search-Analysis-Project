
package org.hibernate.test.instrument2.domain2;


import java.math.BigDecimal;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.Transient;



@Entity
@Table(name = "CUSTOMERACCOUNT")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "CAC_DISCRIMINATOR", discriminatorType = DiscriminatorType.STRING)
abstract public class CustomerAccount extends CustomerAccountBase
{

	@Override
	@Transient
	public BigDecimal getInterestRate() {
		// TODO: [MODEL] This method must be implemented!
		throw new UnsupportedOperationException("The method isn't implemented!");
	}
}