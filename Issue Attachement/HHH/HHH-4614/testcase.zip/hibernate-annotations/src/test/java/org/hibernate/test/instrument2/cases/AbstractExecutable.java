package org.hibernate.test.instrument2.cases;

import java.io.InputStream;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.test.instrument2.domain2.AccountProduct;
import org.hibernate.test.instrument2.domain2.AccountProductBase;
import org.hibernate.test.instrument2.domain2.CustomerAccount;
import org.hibernate.test.instrument2.domain2.CustomerAccountBase;
import org.hibernate.test.instrument2.domain2.SavingsCustomerAccount;
import org.hibernate.test.instrument2.domain2.SavingsCustomerAccountBase;
import org.hibernate.test.instrument2.domain2.SavingsProduct;
import org.hibernate.test.instrument2.domain2.SavingsProductBase;

/**
 * @author Steve Ebersole
 */
public abstract class AbstractExecutable implements Executable {

	private SessionFactory factory;

	public final void prepare() {
		AnnotationConfiguration cfg = new AnnotationConfiguration().setProperty( Environment.HBM2DDL_AUTO, "create-drop" );
		
		Class[] classes = getAnnotatedClasses();
		for ( Class<?> aClass : classes ) {
			cfg.addAnnotatedClass( aClass );
		}
		String[] xmlFiles = getXmlFiles();
		for ( String xmlFile : xmlFiles ) {
			InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream( xmlFile );
			cfg.addInputStream( is );
		}
		factory = cfg.buildSessionFactory();
	}

	public final void complete() {
		try {
			cleanup();
		}
		finally {
			factory.close();
		}
	}

	protected SessionFactory getFactory() {
		return factory;
	}

	protected void cleanup() {
	}

	protected Class[] getAnnotatedClasses() {
		//return new String[] { "org/hibernate/test/instrument2/domain2/mappings.hbm.xml" };
		return new Class[] { AccountProductBase.class, 
				AccountProduct.class, 
				SavingsProductBase.class,
				SavingsProduct.class,
				CustomerAccountBase.class,
				CustomerAccount.class,
				SavingsCustomerAccountBase.class,
				SavingsCustomerAccount.class };
		//return new Class[] { };
	}
	
	protected String[] getXmlFiles() {
		return new String[] { };
		//return new String[] { "org/hibernate/test/instrument2/domain2/mappings.hbm.xml" };
	}
}
