package org.hibernate.test.instrument2.runtime;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.bytecode.BytecodeProvider;
import org.hibernate.bytecode.cglib.BytecodeProviderImpl;

/**
 * @author Steve Ebersole
 */
public class SimpleCGLIBInstrumentationTest extends SimpleTransformingClassLoaderInstrumentTestCase {
	public SimpleCGLIBInstrumentationTest(String string) {
		super( string );
	}

	protected BytecodeProvider buildBytecodeProvider() {
		return new BytecodeProviderImpl();
	}

	public static Test suite() {
		return new TestSuite( SimpleCGLIBInstrumentationTest.class );
	}

	public void testDumb() {
		super.testDumb();
	}


}