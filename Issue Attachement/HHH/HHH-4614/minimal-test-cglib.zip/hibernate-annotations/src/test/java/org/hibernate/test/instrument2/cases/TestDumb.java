package org.hibernate.test.instrument2.cases;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.annotation.Annotation;

import junit.framework.Assert;


/**
 * @author Steve Ebersole
 */
public class TestDumb implements Executable {
	public void prepare() {

	}

	public void execute() {
		try {
			ClassLoader loader = Thread.currentThread().getContextClassLoader();
			Class<?> aClass = loader.loadClass( "org.hibernate.test.instrument2.domain2.Simple" );
			displayAnnotations( aClass.getAnnotations() );

			System.out.println("list all fields and their annotations:");
			for (Field f : aClass.getDeclaredFields() ) {
				System.out.println(f.getName());
				displayAnnotations( f.getAnnotations() );
			}

			System.out.println("Method getId annotations:");
			Method method = aClass.getDeclaredMethod( "getId" );
			displayAnnotations( method.getAnnotations() );
			Assert.assertEquals( "cannot read annotations on methods", 1, method.getAnnotations().length );

			System.out.println("Field id annotations:");
			Field field = aClass.getDeclaredField( "id" );
			displayAnnotations( field.getAnnotations() );
			Assert.assertEquals( "cannot read annotations on fields", 1, field.getAnnotations().length );

		}
		catch ( NoSuchMethodException e ) {
			e.printStackTrace();
		}
		catch ( NoSuchFieldException e ) {
			e.printStackTrace();
		}
		catch ( ClassNotFoundException e ) {
			e.printStackTrace(); 
		}
	}

	public void complete() {
	}


	private void displayAnnotations(Annotation[] annotations) {
		for ( Annotation a : annotations ) {
			System.out.println(a.toString());
		}
	}
}