package org.hibernate.test.instrument2.domain2;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * @author Emmanuel Bernard
 */
@Entity
public class Simple {
	@Id
	private String id;
	@Id
	public String getId() {
		return null;
	}
}
