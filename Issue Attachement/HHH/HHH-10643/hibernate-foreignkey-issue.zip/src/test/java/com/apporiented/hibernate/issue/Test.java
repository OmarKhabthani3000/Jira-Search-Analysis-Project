package com.apporiented.hibernate.issue;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataBuilder;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.hibernate.tool.schema.TargetType;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;

import java.io.File;
import java.util.EnumSet;

import static org.junit.Assert.assertTrue;

public class Test {

    private static Metadata metadata;
    private static File file;

    @BeforeClass
    public static void setupClass() {

        StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder();
        srb.applySetting("hibernate.connection.driver_class", "org.h2.Driver");
        srb.applySetting("hibernate.connection.url", "jdbc:h2:mem:test;MODE=PostgreSQL");
        srb.applySetting("hibernate.connection.username", "sa");
        srb.applySetting("hibernate.connection.password", "sa");
        srb.applySetting("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
        srb.applySetting("hibernate.id.new_generator_mappings", "true");
        srb.applySetting("hibernate.show_sql", "true");
        srb.applySetting("hibernate.format_sql", "true");
        srb.applySetting("hibernate.hbm2ddl.auto", "create-drop");
        srb.applySetting("hibernate.cache.use_query_cache", "false");
        srb.applySetting("hibernate.cache.use_second_level_cache", "false");
        srb.applySetting("hibernate.current_session_context_class", "thread");
        srb.applySetting("hibernate.bytecode.provider", "javassist");
        srb.applySetting("hibernate.discriminator.ignore_explicit_for_joined", "true");

        MetadataSources metadataSources = new MetadataSources(srb.build());
        metadataSources.addAnnotatedClass(Student.class);
        metadataSources.addAnnotatedClass(Course.class);

        MetadataBuilder metadataBuilder = metadataSources.getMetadataBuilder();
        metadata = metadataBuilder.build();
    }

    @Before
    public void setup() throws Exception {
         file = File.createTempFile("test_", ".sql");
    }

    @After
    public void tearDown() {
        file.delete();
    }

    @org.junit.Test
    public void testExportSchema() throws Exception  {
        new SchemaExport()
                .setOutputFile(file.getPath())
                .setFormat(true)
                .setDelimiter(";")
                .execute(EnumSet.of(TargetType.SCRIPT, TargetType.STDOUT),
                        SchemaExport.Action.CREATE, metadata);

        String script = FileUtils.readFileToString(file);
        assertTrue(script.toLowerCase().contains("on delete cascade"));

    }
}
