package com.apporiented.hibernate.issue;

import javax.persistence.*;
import java.util.SortedSet;

@Entity
@Table(name = "students")
public class Student {

    private Long id;
    private SortedSet<Course> courses;

    @Id
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            joinColumns = {
                    @JoinColumn(name = "sudent_id", nullable = false, foreignKey = @ForeignKey(name = "student2course_sudent_fkc",
                            foreignKeyDefinition = "foreign key (sudent_id) references students (id) on delete cascade"))},
            inverseJoinColumns = {
                    @JoinColumn(name = "course_id", nullable = false, foreignKey = @ForeignKey(name = "student2course_course_fkc",
                            foreignKeyDefinition = "foreign key (course_id) references courses (id) on delete cascade"))}
    )
    @OrderBy("name")
    public SortedSet<Course> getCourses() {
        return courses;
    }

}
