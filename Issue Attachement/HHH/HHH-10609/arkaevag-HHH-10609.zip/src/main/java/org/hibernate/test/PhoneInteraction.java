package org.hibernate.test;

public class PhoneInteraction extends ContactInteraction {


}
