package org.hibernate.test;

import java.util.Date;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.hibernate.annotations.Index;
import org.hibernate.annotations.Proxy;

@Entity
@Proxy(lazy = false)
@Access(AccessType.FIELD)
@Table(name = "TBL_CONTACT_INTERACTION")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "discr", discriminatorType = DiscriminatorType.STRING, length = 32)
@DiscriminatorValue("base")
public class ContactInteraction {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SequenceIdGenerator")
    @SequenceGenerator(name = "SequenceIdGenerator", sequenceName = "TBL_CONTACT_INTER_ID_GEN", allocationSize = 1)
    private long uuid;

    @Index(name = "IDX_CONTACT_INT_CRDATE")
    private Date creationDate;

    public long getUuid() {
        return uuid;
    }

    public void setUuid(long uuid) {
        this.uuid = uuid;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }
}
