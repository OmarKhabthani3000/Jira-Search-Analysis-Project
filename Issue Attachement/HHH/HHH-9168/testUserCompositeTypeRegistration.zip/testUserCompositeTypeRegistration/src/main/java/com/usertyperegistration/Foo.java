/*******************************************************************************
 * Copyright 2010 PATRONAS Financial Systems GmbH. All rights reserved.
 ******************************************************************************/
package com.usertyperegistration;

import org.joda.time.Interval;

public class Foo {
  private long id;
  private Interval bar;

  public Interval getBar() {
    return bar;
  }

  public void setBar(final Interval bar) {
    this.bar = bar;
  }

  public long getId() {
    return id;
  }

  public void setId(final long id) {
    this.id = id;
  }

}
