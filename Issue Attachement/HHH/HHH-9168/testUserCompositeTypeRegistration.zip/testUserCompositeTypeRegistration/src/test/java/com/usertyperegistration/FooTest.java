package com.usertyperegistration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.joda.time.DateTime;
import org.joda.time.Interval;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class FooTest {

  private static EntityManagerFactory emf;
  private EntityManager em;

  public FooTest() {
  }

  @BeforeClass
  public static void setUpClass() throws Exception {
    emf = Persistence.createEntityManagerFactory("testunit");
  }

  @AfterClass
  public static void tearDownClass() throws Exception {
    if (emf != null && emf.isOpen()) {
      emf.close();
    }
  }

  @Before
  public void setUp() {
    em = emf.createEntityManager();
    em.getTransaction().begin();
  }

  @After
  public void tearDown() {
    if (em.getTransaction().isActive())
      em.getTransaction().rollback();

    if (em.isOpen())
      em.close();

  }

  /**
   * Test of persisting a JodaTime interval, which is auto registered by Jadira.
   */
  @Test
  public void testFooBar1() {
    final Foo foo = new Foo();
    final DateTime start = DateTime.now();
    final DateTime end = new DateTime(3000, 1, 1, 0, 0);
    final Interval interval = new Interval(start, end);
    foo.setBar(interval);
    em.persist(foo);
    em.getTransaction().commit();

    // prevent caching etc
    em = emf.createEntityManager();
    final String getFoo = "select a from Foo a where a.id=" + foo.getId();
    final TypedQuery<Foo> query = em.createQuery(getFoo, Foo.class);
    final Foo fooResult = query.getSingleResult();
    assertNotNull("expected that bar property is set", fooResult.getBar());
    assertEquals("unexpected interval", interval, fooResult.getBar());
  }
}
