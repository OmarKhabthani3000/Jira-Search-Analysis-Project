/*
 * $HeadURL$
 * Copyright(c) ISC-EJPD - Alle Rechte vorbehalten
 *
 * Letzter Commit
 *   $LastChangedDate: 2009-07-16 13:32:48 +0200 (Do, 16 Jul 2009) $
 *   $Author: isc-kap $
 *   $Revision: 41657 $ 
 */
package org.hibernate.mapping;

import java.util.Iterator;

import org.hibernate.dialect.Dialect;

/** 
 * TODO: Bitte durch Klassenbeschreibung ersetzen
 */
public class PrimaryKey extends Constraint {

    public String sqlConstraintString(Dialect dialect) {
        String constraintName = this.getName();
        StringBuffer buf = new StringBuffer("constraint ").append(constraintName).append(" primary key (");
        Iterator iter = getColumnIterator();
        while ( iter.hasNext() ) {
            buf.append( ( (Column) iter.next() ).getQuotedName(dialect) );
            if ( iter.hasNext() ) buf.append(", ");
        }
        return buf.append(')').toString();
    }

    public String sqlConstraintString(Dialect dialect, String constraintName, String defaultCatalog, String defaultSchema) {
        StringBuffer buf = new StringBuffer(
            dialect.getAddPrimaryKeyConstraintString(constraintName)
        ).append('(');
        Iterator iter = getColumnIterator();
        while ( iter.hasNext() ) {
            buf.append( ( (Column) iter.next() ).getQuotedName(dialect) );
            if ( iter.hasNext() ) buf.append(", ");
        }
        return buf.append(')').toString();
    }
}