package org.maximkir;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.junit.*;
import org.maximkir.hibernate.domain.Event;
import org.maximkir.hibernate.domain.EventGroup;

import java.util.*;
import java.util.function.Consumer;

/**
 * Created by Maxim.Kirilov on 2/22/2016.
 */
public class CollectionLoadTest {

    private static SessionFactory sf;


    @BeforeClass
    public static void createSessionFactory() throws Exception{
        final StandardServiceRegistry registry =
                new StandardServiceRegistryBuilder()
                .configure()
                .build();
        sf = new MetadataSources( registry ).buildMetadata().buildSessionFactory();

        populateTestData(sf);
    }

    @AfterClass
    public static void destroySessionFactory(){
        sf.close();
    }


    @Test
    public void collectionInnerJoinLoadTest(){
        executeWithinTX(sf, session -> {
            Criteria criteria = session.createCriteria(EventGroup.class);
            criteria.createCriteria("events", "event", JoinType.INNER_JOIN);
            criteria.add(Restrictions.gt("event.date", new Date()));

            List result = criteria.list();
            Assert.assertEquals(1, result.size());
            EventGroup eventGroup = (EventGroup) result.get(0);
            Assert.assertEquals(2, eventGroup.getEvents().size());
        });
    }

    @Test
    public void collectionLeftOuterJoinLoadTest(){
        executeWithinTX(sf, session -> {
            Criteria criteria = session.createCriteria(EventGroup.class);
            criteria.createCriteria("events", "event", JoinType.LEFT_OUTER_JOIN);
            criteria.add(Restrictions.gt("event.date", new Date()));

            List result = criteria.list();
            Assert.assertEquals(1, result.size());
            EventGroup eventGroup = (EventGroup) result.get(0);
            Assert.assertEquals(2, eventGroup.getEvents().size());
        });
    }

    @Test
    public void collectionRightOuterJoinLoadTest(){
        executeWithinTX(sf, session -> {
            Criteria criteria = session.createCriteria(EventGroup.class);
            criteria.createCriteria("events", "event", JoinType.RIGHT_OUTER_JOIN);
            criteria.add(Restrictions.gt("event.date", new Date()));

            List result = criteria.list();
            Assert.assertEquals(1, result.size());
            EventGroup eventGroup = (EventGroup) result.get(0);
            Assert.assertEquals(2, eventGroup.getEvents().size());
        });
    }


    @Test
    public void collectionFullJoinLoadTest(){
        executeWithinTX(sf, session -> {
            Criteria criteria = session.createCriteria(EventGroup.class);
            criteria.createCriteria("events", "event", JoinType.FULL_JOIN);
            criteria.add(Restrictions.gt("event.date", new Date()));

            List result = criteria.list();
            Assert.assertEquals(1, result.size());
            EventGroup eventGroup = (EventGroup) result.get(0);
            Assert.assertEquals(2, eventGroup.getEvents().size());
        });
    }




    private static void populateTestData(SessionFactory sf){
        executeWithinTX(sf, session -> {
            Calendar now = Calendar.getInstance();
            Calendar calendar = Calendar.getInstance();
            calendar.clear();
            calendar.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DATE));
            calendar.add(Calendar.DATE, -1);
            Date yesterday = calendar.getTime();
            calendar.add(Calendar.DATE, 2);
            Date tomorrow = calendar.getTime();

            Event event1 = new Event();
            event1.setDate(yesterday);

            Event event2 = new Event();
            event2.setDate(tomorrow);

            EventGroup eventGroup = new EventGroup();
            eventGroup.getEvents().add(event1);
            eventGroup.getEvents().add(event2);

            session.save(eventGroup);
            session.save(event1);
            session.save(event2);
        });
    }


    private static void executeWithinTX(SessionFactory sf, Consumer<Session> consumer){
        Session session = sf.openSession();
        try{
            session.getTransaction().begin();
            consumer.accept(session);
            session.getTransaction().commit();
        } finally {
            session.close();
        }
    }
}
