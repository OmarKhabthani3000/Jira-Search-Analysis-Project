// $Id: RefreshTest.java 10976 2006-12-12 23:22:26Z steve.ebersole@jboss.com $
package patchTest.notFoundKeep;

import junit.framework.Test;

import org.hibernate.Hibernate;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;


/**
 * Implementation of test for patch not-found-keep.
 * 
 * @author Heinz Huber
 */
public class NotFoundKeepTest extends FunctionalTestCase {
    
    public NotFoundKeepTest( String name ) {
        super( name );
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see FunctionalTestCase#getBaseForMappings()
     */
    public String getBaseForMappings() {
        return "patchTest/";
    }
    
    public String[] getMappings() {
        return new String[] { "notFoundKeep/mapping.hbm.xml" };
    }
    
    public static Test suite() {
        return new FunctionalTestClassTestSuite( NotFoundKeepTest.class );
    }
    
    public void testNotFoundKeep() throws Throwable {
        Session session = openSession();
        Transaction txn = session.beginTransaction();
        
        Currency curr = new Currency( "CUR" );
        curr.setName( "existing currency" );
        Currency currNot = new Currency( "NOT" );
        currNot.setName( "missing currency" );
        
        session.persist( curr );
        // insert now. has to be deleted later.
        session.persist( currNot );
        
        Account account = new Account( "bank", "ok", curr );
        account.setCurrencyIgnore( curr );
        account.setCurrencyException( curr );
        session.persist( account );
        Long ok = account.getId();
        
        account = new Account( "bank", "keep", currNot );
        account.setCurrencyIgnore( curr );
        account.setCurrencyException( curr );
        session.persist( account );
        Long keep = account.getId();
        
        account = new Account( "bank", "ignore", curr );
        account.setCurrencyIgnore( currNot );
        account.setCurrencyException( curr );
        session.persist( account );
        Long ignore = account.getId();
        
        account = new Account( "bank", "exception", curr );
        account.setCurrencyIgnore( curr );
        account.setCurrencyException( currNot );
        session.persist( account );
        Long exception = account.getId();
        
        session.flush();
        session.clear();
        
        session.delete( currNot );
        session.flush();
        session.clear();
        
        check( session, ok, "ok", curr, curr, curr );
        check( session, keep, "keep", currNot, curr, curr );
        check( session, ignore, "ignore", curr, null, curr );
        try {
            check( session, exception, "exception", curr, curr, currNot );
            // TODO doesn't work!! apperently inconsistent keep-settings for the same target class don't work.
            assertTrue( "exception not thrown", false );
        }
        catch ( ObjectNotFoundException ex ) {
            assertEquals( "exception entity", Currency.class.getName(), ex.getEntityName() );
            assertEquals( "exception id", currNot.getCurrency(), ex.getIdentifier() );
        }
        
        txn.rollback();
        session.close();
    }
    
    private void check( Session session, Long id, String acc, Currency currency, Currency ignore, Currency exception ) {
        Account account = (Account) session.get( Account.class, id );
        assertEquals( acc + " account", acc, account.getAccount() );
        Hibernate.initialize( account.getCurrency() );
        assertEquals( acc + " currency", currency, account.getCurrency() );
        Hibernate.initialize( account.getCurrencyIgnore() );
        assertEquals( acc + " ignore", ignore, account.getCurrencyIgnore() );
        Hibernate.initialize( account.getCurrencyException() );
        assertEquals( acc + " exception", exception, account.getCurrencyException() );
    }
}
