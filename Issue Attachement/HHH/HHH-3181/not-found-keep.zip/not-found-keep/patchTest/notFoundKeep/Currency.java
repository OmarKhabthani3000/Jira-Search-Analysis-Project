package patchTest.notFoundKeep;

public class Currency {
    private String currency;
    
    private String name;
    
    public Currency() {
        super();
    }
    
    public Currency( String currency ) {
        super();
        this.currency = currency;
    }
    
    public String getCurrency() {
        return currency;
    }
    
    public void setCurrency( String currency ) {
        this.currency = currency;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName( String name ) {
        this.name = name;
    }
    
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + ( ( getCurrency() == null ) ? 0 : getCurrency().hashCode() );
        return result;
    }
    
    public boolean equals( Object obj ) {
        if ( this == obj )
            return true;
        if ( ! ( obj instanceof Currency ) )
            return false;
        final Currency other = (Currency) obj;
        if ( getCurrency() == null ) {
            if ( other.getCurrency() != null )
                return false;
        }
        else if ( !getCurrency().equals( other.getCurrency() ) )
            return false;
        return true;
    }
    
    public String toString() {
        return super.toString() + ":" + currency;
    }
}
