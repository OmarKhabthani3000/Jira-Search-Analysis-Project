package patchTest.notFoundKeep;

public class Account {
    private Long     id;
    
    private String   bank;
    
    private String   account;
    
    private Currency currency;
    
    private Currency currencyIgnore;
    
    private Currency currencyException;
    
    public Account() {
        super();
    }
    
    public Account( String bank, String account, Currency currency ) {
        super();
        this.bank = bank;
        this.account = account;
        this.currency = currency;
    }
    
    public String getAccount() {
        return account;
    }
    
    public void setAccount( String account ) {
        this.account = account;
    }
    
    public String getBank() {
        return bank;
    }
    
    public void setBank( String bank ) {
        this.bank = bank;
    }
    
    public Currency getCurrency() {
        return currency;
    }
    
    public void setCurrency( Currency currency ) {
        this.currency = currency;
    }
    
    public Currency getCurrencyIgnore() {
        return currencyIgnore;
    }
    
    public void setCurrencyIgnore( Currency currencyIgnore ) {
        this.currencyIgnore = currencyIgnore;
    }
    
    public Currency getCurrencyException() {
        return currencyException;
    }
    
    public void setCurrencyException( Currency currencyException ) {
        this.currencyException = currencyException;
    }
    
    public Long getId() {
        return id;
    }
    
    public void setId( Long id ) {
        this.id = id;
    }
}
