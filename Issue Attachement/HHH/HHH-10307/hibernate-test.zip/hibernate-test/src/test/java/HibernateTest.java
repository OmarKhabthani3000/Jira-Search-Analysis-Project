import org.hibernate.cfg.Configuration;
import org.junit.Test;

public class HibernateTest {

    @Test
    public void newConfigurationTest() throws Exception {
    	new Configuration();
    }
}
