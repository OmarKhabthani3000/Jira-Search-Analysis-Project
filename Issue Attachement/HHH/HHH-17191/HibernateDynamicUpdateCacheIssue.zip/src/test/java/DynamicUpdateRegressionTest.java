import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.hibernate.bugs.Person;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DynamicUpdateRegressionTest {


  private EntityManagerFactory entityManagerFactory;

  @BeforeEach
  void init() {
    entityManagerFactory = Persistence.createEntityManagerFactory( "regression" );
  }

  @AfterEach
  void destroy() {
    entityManagerFactory.close();
  }

  @Test
  void shouldGiveMergedEntity() {
    // Arrange: Create a person
    EntityManager em = entityManagerFactory.createEntityManager();
    em.getTransaction().begin();
    Person person = new Person();
    person.setId(1L);
    person.setFirstName("John");
    person.setLastName("Doe");
    em.persist(person);
    em.getTransaction().commit();
    em.close();

    // Act: Update different attributes within two different transacitons / entity managers
    EntityManager em1 = entityManagerFactory.createEntityManager();
    EntityManager em2 = entityManagerFactory.createEntityManager();

    em1.getTransaction().begin();
    em2.getTransaction().begin();

    Person person1 = em1.find(Person.class, 1L);
    person1.setFirstName("Bob");

    Person person2 = em2.find(Person.class, 1L);
    person2.setLastName("Smith");

    em1.getTransaction().commit();
    em2.getTransaction().commit();

    // Assert: Both attributes should be visible immediately after update
    em = entityManagerFactory.createEntityManager();
    em.getTransaction().begin();
    person = em.find(Person.class, 1L);
    em.getTransaction().rollback();

    assertEquals("Bob", person.getFirstName());
    assertEquals("Smith", person.getLastName());
  }

}
