package com.example.model;

import java.io.Serializable;
import java.util.Map;
import java.util.TreeMap;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;

@Entity
public class Match implements Serializable {
	private static final long serialVersionUID = 795832280311186376L;
	
	@Id
	private Long id;

	@ElementCollection(fetch = FetchType.EAGER)
	@CollectionTable
	private Map<Integer, Integer> awayTeamGoalTimeline = new TreeMap<>();
}
