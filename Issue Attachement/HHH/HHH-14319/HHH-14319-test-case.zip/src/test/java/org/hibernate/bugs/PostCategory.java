package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "PostCategory")
@Table(name = "post_category")
public class PostCategory {

    @Id
    @GeneratedValue
    private Long id;

    private String category;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public PostCategory setCategory(String category) {
        this.category = category;
        return this;
    }
}
