package org.hibernate.bugs;

import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class Comment implements Serializable {

    private String comment;

    private String author;

    public String getComment() {
        return comment;
    }

    public Comment setComment(String comment) {
        this.comment = comment;
        return this;
    }

    public String getAuthor() {
        return author;
    }

    public Comment setAuthor(String author) {
        this.author = author;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Comment)) return false;
        Comment comment1 = (Comment) o;
        return Objects.equals(comment, comment1.comment) &&
               Objects.equals(author, comment1.author);
    }

    @Override
    public int hashCode() {
        return Objects.hash(comment, author);
    }
}
