package org.hibernate.bugs;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity(name = "Post")
@Table(name = "post")
public class Post {

    @Id
    private Long id;

    private String title;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(
        name = "post_comment",
        joinColumns = @JoinColumn(name = "post_id")
    )
    private Set<Comment> comments = new HashSet<>();

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(
        name = "post_tag",
        joinColumns = @JoinColumn(name = "post_id")
    )
    private Set<Tag> tags = new HashSet<>();

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "post_categories",
        joinColumns = @JoinColumn(name = "category_id"),
        inverseJoinColumns = @JoinColumn(name = "post_id")
    )
    private Set<PostCategory> categories = new HashSet<>();

    public Long getId() {
        return id;
    }

    public Post setId(Long id) {
        this.id = id;
        return this;
    }

    public String getTitle() {
        return title;
    }

    public Post setTitle(String title) {
        this.title = title;
        return this;
    }

    public Set<Comment> getComments() {
        return comments;
    }

    public void setComments(Set<Comment> comments) {
        this.comments = comments;
    }

    public Set<Tag> getTags() {
        return tags;
    }

    public void setTags(Set<Tag> tags) {
        this.tags = tags;
    }

    public Set<PostCategory> getCategories() {
        return categories;
    }

    public void setCategories(Set<PostCategory> categories) {
        this.categories = categories;
    }

    public Post addComment(Comment comment) {
        comments.add(comment);
        return this;
    }

    public Post addTag(Tag tag) {
        tags.add(tag);
        return this;
    }

    public Post addCategory(PostCategory category) {
        categories.add(category);
        return this;
    }
}
