package org.hibernate.bugs;

import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class Tag implements Serializable {

    private String name;

    private String author;

    public String getName() {
        return name;
    }

    public Tag setName(String name) {
        this.name = name;
        return this;
    }

    public String getAuthor() {
        return author;
    }

    public Tag setAuthor(String author) {
        this.author = author;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Tag)) return false;
        Tag tag = (Tag) o;
        return Objects.equals(name, tag.name) &&
               Objects.equals(author, tag.author);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, author);
    }
}
