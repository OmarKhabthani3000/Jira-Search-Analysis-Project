package org.hibernate.bugs;

import javax.persistence.*;

import org.hibernate.Session;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.BeanUtils;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.assertEquals;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		PostCategory category1 = new PostCategory()
			.setCategory("Post");
		PostCategory category2 = new PostCategory()
			.setCategory("Archive");
		entityManager.persist(category1);
		entityManager.persist(category2);

		entityManager.persist(
			new Post()
				.setId(1L)
				.setTitle("High-Performance Java Persistence")
				.addCategory(category1)
				.addCategory(category2)
				.addComment(new Comment().setComment("firstComment"))
		);

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Replicating test case for https://hibernate.atlassian.net/browse/HHH-14319
	@Test
	public void testHHH14319() {
		PostDTO postDTO = getPostDTO();

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		//second find and copy from dto
		Post post = entityManager.find(Post.class, 1L);
		BeanUtils.copyProperties(postDTO, post);

		// find posts by category
		List<Post> posts = entityManager.createQuery(
			"select p " +
			"from Post p " +
			"join p.categories c " +
			"where c.id = :categoryId", Post.class)
		.setParameter("categoryId", post.getCategories().iterator().next().getId())
		.getResultList();

		// update post
		post = entityManager.find(Post.class, 1L);
		BeanUtils.copyProperties(postDTO, post);
		Object mergedEntity = update(entityManager, post);

		entityManager.getTransaction().commit();
		entityManager.close();

		entityManager = entityManagerFactory.createEntityManager();
		post = entityManager.find(Post.class, 1L);

		assertEquals(2, post.getTags().size());
		//The comments collection is empty here
		assertEquals(3, post.getComments().size());
		assertEquals(2, post.getCategories().size());
		entityManager.close();
	}

	private PostDTO getPostDTO() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Post post = entityManager.find(Post.class, 1L);
		entityManager.close();

		PostDTO postDTO = new PostDTO();
		postDTO.id = post.getId();
		postDTO.title = post.getTitle();
		postDTO.categories = post.getCategories();
		postDTO.tags = post.getTags();
		postDTO.comments = new HashSet<>();
		postDTO.addComment(new Comment().setComment("Best book on JPA and Hibernate!").setAuthor("Alice"))
			.addComment(new Comment().setComment("A must-read for every Java developer!").setAuthor("Bob"))
			.addComment(new Comment().setComment("A great reference book").setAuthor("Carol"))
			.addTag(new Tag().setName("JPA").setAuthor("Alice"))
			.addTag(new Tag().setName("Hibernate").setAuthor("Alice"));
		return postDTO;
	}

	private Object update(EntityManager entityManager, Object object) {
		Object mergedEntity = entityManager.merge(object);
		entityManager.detach(object);
		Object merged2 = entityManager.merge(mergedEntity);
		return merged2;
	}

	public static class PostDTO {

		private Long id;

		private String title;

		private Set<Comment> comments = new HashSet<>();

		private Set<Tag> tags = new HashSet<>();

		private Set<PostCategory> categories = new HashSet<>();

		public PostDTO() {
		}

		public PostDTO(Post post) {
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public Set<Comment> getComments() {
			return comments;
		}

		public void setComments(Set<Comment> comments) {
			this.comments = comments;
		}

		public Set<Tag> getTags() {
			return tags;
		}

		public void setTags(Set<Tag> tags) {
			this.tags = tags;
		}

		public Set<PostCategory> getCategories() {
			return categories;
		}

		public void setCategories(Set<PostCategory> categories) {
			this.categories = categories;
		}

		public PostDTO addComment(Comment comment) {
			comments.add(comment);
			return this;
		}

		public PostDTO addTag(Tag tag) {
			tags.add(tag);
			return this;
		}

		public PostDTO addCategory(PostCategory category) {
			categories.add(category);
			return this;
		}
	}
}
