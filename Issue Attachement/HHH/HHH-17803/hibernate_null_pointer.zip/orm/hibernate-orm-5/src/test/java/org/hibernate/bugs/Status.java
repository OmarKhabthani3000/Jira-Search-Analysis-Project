package org.hibernate.bugs;

public enum Status {
    VALID,INVALID
}
