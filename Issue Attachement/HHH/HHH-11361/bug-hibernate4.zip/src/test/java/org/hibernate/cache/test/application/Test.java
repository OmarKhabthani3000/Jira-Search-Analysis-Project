package org.hibernate.cache.test.application;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import junit.framework.TestCase;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Test extends TestCase{

	public static void testGrammar1() throws Exception{
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("org.hibernate.test");
		SessionFactory factory = entityManagerFactory.unwrap(SessionFactory.class);		
		Session session = factory.openSession();
		session.beginTransaction();

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));

		Query query = session.createQuery("SELECT f FROM Foo f ORDER BY f.bar");
		query.list();		
		String sql = baos.toString();		
		assertTrue(sql.contains("order by"));
		
		session.close();
		factory.close();	
	}
	
	public static void testGrammar2() throws Exception{
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("org.hibernate.test");
		SessionFactory factory = entityManagerFactory.unwrap(SessionFactory.class);		
		Session session = factory.openSession();
		session.beginTransaction();

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));

		Query query = session.createQuery("SELECT f FROM Foo f ) ORDER BY f.bar");
		query.list();		
		String sql = baos.toString();		
		assertTrue(sql.contains("order by"));
		
		session.close();
		factory.close();	
	}
}
