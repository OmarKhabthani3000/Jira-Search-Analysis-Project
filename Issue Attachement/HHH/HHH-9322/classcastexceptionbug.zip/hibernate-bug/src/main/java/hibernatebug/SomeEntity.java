package hibernatebug;

import org.hibernate.annotations.Type;

import javax.persistence.*;

@Entity
@Table(name = "some_entity")
public class SomeEntity {

    @Id
    @Type(type = "customId")
    @Column(name = "id")
    private CustomId customId;

    @Column(name = "value")
    private Integer value;

    public CustomId getCustomId() {
        return customId;
    }

    public void setCustomId(final CustomId customId) {
        this.customId = customId;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(final Integer value) {
        this.value = value;
    }
}
