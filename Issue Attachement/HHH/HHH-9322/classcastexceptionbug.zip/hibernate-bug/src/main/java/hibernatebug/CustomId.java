package hibernatebug;

import java.io.Serializable;

public class CustomId implements Serializable {

    private final Long value;

    public CustomId(final Long value) {
        this.value = value;
    }

    public Long getValue() {
        return value;
    }
}
