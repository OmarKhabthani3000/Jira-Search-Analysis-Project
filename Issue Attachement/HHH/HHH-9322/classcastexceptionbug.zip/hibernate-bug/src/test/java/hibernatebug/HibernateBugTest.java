package hibernatebug;

import org.h2.Driver;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.dialect.H2Dialect;
import org.junit.Before;
import org.junit.Test;

import java.util.Properties;

public class HibernateBugTest {

    private static final CustomId ID1 = new CustomId(1L);
    private static final CustomId ID2 = new CustomId(2L);
    private static final int INITIAL_VALUE = 1;

    private SessionFactory sessionFactory;

    @Before
    public void setUp() throws Exception {
        Properties properties = new Properties();
        properties.setProperty(AvailableSettings.DRIVER, Driver.class.getName());
        properties.setProperty(AvailableSettings.DIALECT, H2Dialect.class.getName());
        properties.setProperty(AvailableSettings.URL, "jdbc:h2:mem:bugtest;INIT=CREATE TABLE some_entity (id BIGINT NOT NULL PRIMARY KEY, value INT NOT NULL)");
        properties.setProperty(AvailableSettings.USER, "sa");
        properties.setProperty(AvailableSettings.PASS, "");
        properties.setProperty(AvailableSettings.CURRENT_SESSION_CONTEXT_CLASS, "thread");

        Configuration configuration = new Configuration()
                .addAnnotatedClass(SomeEntity.class)
                .addProperties(properties);

        configuration.registerTypeOverride(new CustomIdType(), new String[]{"customId"});

        StandardServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
                .applySettings(configuration.getProperties())
                .build();

        sessionFactory = configuration.buildSessionFactory(serviceRegistry);

        persistTwoNewEntitiesWithValue(INITIAL_VALUE);
    }

    @Test
    public void shouldNotThrowAClassCastExceptionWhenTryingToUpdateMultipleInstancesWithTheSameEntityNameInASingleCommit() throws Exception {
        Transaction tx = session().beginTransaction();

        SomeEntity e1 = (SomeEntity) session().load(SomeEntity.class, ID1);
        e1.setValue(2);

        SomeEntity e2 = (SomeEntity) session().load(SomeEntity.class, ID2);
        e2.setValue(2);

        tx.commit();
    }

    private void persistTwoNewEntitiesWithValue(final Integer value) {
        Transaction tx = session().beginTransaction();

        SomeEntity e1 = new SomeEntity();
        e1.setCustomId(ID1);
        e1.setValue(value);

        SomeEntity e2 = new SomeEntity();
        e2.setCustomId(ID2);
        e2.setValue(value);

        session().persist(e1);
        session().persist(e2);

        tx.commit();
    }

    private Session session() {
        return sessionFactory.getCurrentSession();
    }
}
