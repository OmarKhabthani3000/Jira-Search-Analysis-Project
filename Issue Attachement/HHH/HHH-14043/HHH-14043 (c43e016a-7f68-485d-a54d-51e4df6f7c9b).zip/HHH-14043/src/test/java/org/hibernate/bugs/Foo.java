package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Version;

@Entity
public class Foo {

	@Id
	String id = "foo";
        
        @Version
        Long version;
                

	Foo() {
		this.bars = new ArrayList<>();
	}

	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER, orphanRemoval = true)
	@JoinColumn(referencedColumnName="id",name="foo_id")
	@OrderColumn
	List<Bar> bars;

	@Override
	public String toString() {
		return bars.toString();
	}
}
