package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This unit test shows that the concurrent moving of two list elements causes the database to
 * become inconsistent and list elements get lost.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void hhh123Test() throws Exception {

		// Step 1: We create a Foo containing three bars and persist it.
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Foo foo = new Foo();
		foo.bars.add(new Bar("bar1"));
		foo.bars.add(new Bar("bar2"));
		foo.bars.add(new Bar("bar3"));
		entityManager.persist(foo);
		entityManager.getTransaction().commit();
		entityManager.close();

		// Step 2: We start two transactions reading the Foo created in step 1.
		EntityManager e1 = entityManagerFactory.createEntityManager();
		e1.getTransaction().begin();
		Foo foo1 = e1.find(Foo.class,"foo");

		EntityManager e2 = entityManagerFactory.createEntityManager();
		e2.getTransaction().begin();
		Foo foo2 = e2.find(Foo.class,"foo");

		// In transaction 1 we move element 0 to index 1 and commit.
		Bar bar1 = foo1.bars.remove(0);
		foo1.bars.add(1,bar1);
                e1.flush();
		e1.getTransaction().commit();
		e1.close();

		// In transaction 2 we move element 2 to index 1 and commit.
		Bar bar2 = foo2.bars.remove(2);
		foo2.bars.add(1,bar2);
                e2.flush();
		e2.getTransaction().commit();
		e2.close();

		// Now when load Foo again and log its content.
		EntityManager e3 = entityManagerFactory.createEntityManager();
		Foo foo3 = e3.find(Foo.class,"foo");
		Logger.getLogger(getClass()).info(foo3);

		// We also log the indices found in the table.
		for(Object row : e3.createNativeQuery("SELECT bars_ORDER FROM bar;").getResultList()) {
			Logger.getLogger(getClass()).info(row);
		}
	}
}
