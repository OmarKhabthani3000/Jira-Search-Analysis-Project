package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;

@Entity
public class Foo {

	@Id
	String id = "foo";

	Foo() {
		this.bars = new ArrayList<>();
	}

	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(referencedColumnName="id",name="foo_id")
	@OrderColumn
	List<Bar> bars;

	@Override
	public String toString() {
		return bars.toString();
	}
}
