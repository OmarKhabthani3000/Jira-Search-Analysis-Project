package test;

public class Child
{

  private Long id;
  private Parent parent;
  
  public Long getId() { return this.id; }
  public void setId( Long id ) { this.id = id; }

  public Parent getParent() { return this.parent; }
  public void setParent( Parent parent ) { this.parent = parent; }
  
}
