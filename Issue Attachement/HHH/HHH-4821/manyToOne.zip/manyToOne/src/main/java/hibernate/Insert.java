package hibernate;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import domain.Attribute;
import domain.AttributeMapping;
import domain.Source;

public class Insert {
  
  public static void main(String[] args) {
    
    AnnotationConfiguration annotationConfiguration = new AnnotationConfiguration();
    annotationConfiguration.addAnnotatedClass(Source.class);
    annotationConfiguration.addAnnotatedClass(Attribute.class);
    annotationConfiguration.addAnnotatedClass(AttributeMapping.class);
    
    SessionFactory sessionFactory = null;
    
    try {
      sessionFactory = annotationConfiguration.configure().buildSessionFactory();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    finally {
      
      if (sessionFactory != null){
        sessionFactory.close();
      }
      
    }
    
  }

}
