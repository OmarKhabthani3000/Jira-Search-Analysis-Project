package domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import org.hibernate.annotations.IndexColumn;

@Entity
public class Source implements Comparable<Source> {
	
	private Long id;
	private String name;
	private List<AttributeMapping> mappings = new ArrayList<AttributeMapping>();
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public Long getId() {
		return id;
	}
	private void setId(Long id) {
		this.id = id;
	}
	
	@Basic
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@OneToMany(cascade = CascadeType.ALL)
  @JoinColumn(name = "source_id", nullable=false)
  @IndexColumn(name="source_priority")
	public List<AttributeMapping> getMappings() {
		return mappings;
	}
  
	public void setMappings(List<AttributeMapping> mappings) {
		this.mappings = mappings;
	}
	
  @Override
  public int compareTo(Source o) {
    return this.getName().compareTo(o.getName());
  }
	
}
