package lt.gama;

import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.util.List;

@Entity
public class EntityB {

    @Id
    private int id;

    @Embedded
    private ComponentEmbeddable component;

    @JdbcTypeCode(SqlTypes.JSON)
    private List<ComponentEmbeddable> componentsList;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ComponentEmbeddable getComponent() {
        return component;
    }

    public void setComponent(ComponentEmbeddable component) {
        this.component = component;
    }

    public List<ComponentEmbeddable> getComponentsList() {
        return componentsList;
    }

    public void setComponentsList(List<ComponentEmbeddable> componentsList) {
        this.componentsList = componentsList;
    }
}
