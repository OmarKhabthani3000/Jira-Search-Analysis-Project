package lt.gama.test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import lt.gama.Component;
import lt.gama.EntityA;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;


public class EntityATest {

    @Test
    public void testA() {
        try (EntityManagerFactory emf = Persistence.createEntityManagerFactory("DB1")) {

            EntityA sample1, sample2;

            try (EntityManager em = emf.createEntityManager()) {
                em.getTransaction().begin();

                sample1 = new EntityA();
                sample1.setId(1);
                sample1.setComponent(new Component("name1", "address1"));
                sample1.setComponentsList(List.of(new Component("name2", "address2"), new Component("name3", "address3")));
                em.persist(sample1);

                em.getTransaction().commit();
            }

            try (EntityManager em = emf.createEntityManager()) {
                sample2 = em.find(EntityA.class, 1);
                assertNotEquals(sample1, sample2);
                assertEquals("name1", sample2.getComponent().getName());
                assertEquals("name2", sample2.getComponentsList().get(0).getName());
            }
        }
    }

}
