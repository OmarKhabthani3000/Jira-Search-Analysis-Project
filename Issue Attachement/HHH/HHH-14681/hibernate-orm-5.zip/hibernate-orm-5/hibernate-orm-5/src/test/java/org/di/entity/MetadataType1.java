package org.di.entity;

import org.hibernate.annotations.Where;

@Where(clause = "indicator = \'M\'")
public class MetadataType1 extends Metadata {
    public void setOrderMetadataPk(Long id) {
        setOrderMetadataPk(new OrderPk(id, "M"));
    }


    public static abstract class MetadataType1Builder<C extends MetadataType1, B extends MetadataType1Builder<C, B>> extends Metadata.MetadataBuilder<C, B> {
        @Override
        protected B $fillValuesFrom(final C instance) {
            super.$fillValuesFrom(instance);
            MetadataType1Builder.$fillValuesFromInstanceIntoBuilder(instance, this);
            return self();
        }

        private static void $fillValuesFromInstanceIntoBuilder(final MetadataType1 instance, final MetadataType1Builder<?, ?> b) {
        }

        @Override
        protected abstract B self();

        @Override
        public abstract C build();

        @Override
        public String toString() {
            return "MetadataType1.MetadataType1Builder(super=" + super.toString() + ")";
        }
    }


    private static final class MetadataType1BuilderImpl extends MetadataType1Builder<MetadataType1, MetadataType1BuilderImpl> {
        private MetadataType1BuilderImpl() {
        }

        @Override
        protected MetadataType1BuilderImpl self() {
            return this;
        }

        @Override
        public MetadataType1 build() {
            return new MetadataType1(this);
        }
    }

    protected MetadataType1(final MetadataType1Builder<?, ?> b) {
        super(b);
    }

    public static MetadataType1Builder<?, ?> builder() {
        return new MetadataType1BuilderImpl();
    }

    public MetadataType1Builder<?, ?> toBuilder() {
        return new MetadataType1BuilderImpl().$fillValuesFrom(this);
    }

    @Override
    public String toString() {
        return "MetadataType1()";
    }

    @Override
    public boolean equals(final Object o) {
        if (o == this) return true;
        if (!(o instanceof MetadataType1)) return false;
        final MetadataType1 other = (MetadataType1) o;
        if (!other.canEqual((Object) this)) return false;
        if (!super.equals(o)) return false;
        return true;
    }

    protected boolean canEqual(final Object other) {
        return other instanceof MetadataType1;
    }

    @Override
    public int hashCode() {
        final int result = super.hashCode();
        return result;
    }

    public MetadataType1() {
    }
}
