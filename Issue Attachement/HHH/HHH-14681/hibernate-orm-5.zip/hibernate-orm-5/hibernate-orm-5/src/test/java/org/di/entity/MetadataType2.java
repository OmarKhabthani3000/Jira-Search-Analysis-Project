package org.di.entity;

import org.hibernate.annotations.Where;
//@AllArgsConstructor
@Where(clause = "indicator = W")
public class MetadataType2 extends Metadata {
    public void setOrderMetadataPk(Long id) {
        setOrderMetadataPk(new OrderPk(id, "W"));
    }


    public static abstract class MetadataType2Builder<C extends MetadataType2, B extends MetadataType2Builder<C, B>> extends Metadata.MetadataBuilder<C, B> {
        @Override
        protected B $fillValuesFrom(final C instance) {
            super.$fillValuesFrom(instance);
            MetadataType2Builder.$fillValuesFromInstanceIntoBuilder(instance, this);
            return self();
        }

        private static void $fillValuesFromInstanceIntoBuilder(final MetadataType2 instance, final MetadataType2Builder<?, ?> b) {
        }

        @Override
        protected abstract B self();

        @Override
        public abstract C build();

        @Override
        public String toString() {
            return "MetadataType2.MetadataType2Builder(super=" + super.toString() + ")";
        }
    }


    private static final class MetadataType2BuilderImpl extends MetadataType2Builder<MetadataType2, MetadataType2BuilderImpl> {
        private MetadataType2BuilderImpl() {
        }

        @Override
        protected MetadataType2BuilderImpl self() {
            return this;
        }

        @Override
        public MetadataType2 build() {
            return new MetadataType2(this);
        }
    }

    protected MetadataType2(final MetadataType2Builder<?, ?> b) {
        super(b);
    }

    public static MetadataType2Builder<?, ?> builder() {
        return new MetadataType2BuilderImpl();
    }

    public MetadataType2Builder<?, ?> toBuilder() {
        return new MetadataType2BuilderImpl().$fillValuesFrom(this);
    }

    @Override
    public String toString() {
        return "MetadataType2()";
    }

    @Override
    public boolean equals(final Object o) {
        if (o == this) return true;
        if (!(o instanceof MetadataType2)) return false;
        final MetadataType2 other = (MetadataType2) o;
        if (!other.canEqual((Object) this)) return false;
        if (!super.equals(o)) return false;
        return true;
    }

    protected boolean canEqual(final Object other) {
        return other instanceof MetadataType2;
    }

    @Override
    public int hashCode() {
        final int result = super.hashCode();
        return result;
    }

    public MetadataType2() {
    }
}
