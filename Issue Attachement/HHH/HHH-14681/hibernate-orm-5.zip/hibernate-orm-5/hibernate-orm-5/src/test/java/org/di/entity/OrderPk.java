package org.di.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class OrderPk implements Serializable {
    private Long orderId;
    @Column(name = "indicator", insertable = false, updatable = false)
    private String indicator;

    public Long getOrderId() {
        return this.orderId;
    }

    public String getIndicator() {
        return this.indicator;
    }

    public void setOrderId(final Long orderId) {
        this.orderId = orderId;
    }

    public void setIndicator(final String indicator) {
        this.indicator = indicator;
    }

    @Override
    public boolean equals(final Object o) {
        if (o == this) return true;
        if (!(o instanceof OrderPk)) return false;
        final OrderPk other = (OrderPk) o;
        if (!other.canEqual((Object) this)) return false;
        final Object this$orderId = this.getOrderId();
        final Object other$orderId = other.getOrderId();
        if (this$orderId == null ? other$orderId != null : !this$orderId.equals(other$orderId)) return false;
        final Object this$indicator = this.getIndicator();
        final Object other$indicator = other.getIndicator();
        if (this$indicator == null ? other$indicator != null : !this$indicator.equals(other$indicator)) return false;
        return true;
    }

    protected boolean canEqual(final Object other) {
        return other instanceof OrderPk;
    }

    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $orderId = this.getOrderId();
        result = result * PRIME + ($orderId == null ? 43 : $orderId.hashCode());
        final Object $indicator = this.getIndicator();
        result = result * PRIME + ($indicator == null ? 43 : $indicator.hashCode());
        return result;
    }

    @Override
    public String toString() {
        return "OrderPk(orderId=" + this.getOrderId() + ", indicator=" + this.getIndicator() + ")";
    }

    public OrderPk() {
    }

    public OrderPk(final Long orderId, final String indicator) {
        this.orderId = orderId;
        this.indicator = indicator;
    }
}
