package org.di.entity;

import org.hibernate.annotations.Where;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "orders")
@DiscriminatorValue("A")
@Where(clause = "indicator = \'A\'")
public class OrderType1 extends Order {
    public void setOrderPk(Long id) {
        setOrderPk(new OrderPk(id, "A"));
    }


    public static abstract class OrderType1Builder<C extends OrderType1, B extends OrderType1Builder<C, B>> extends Order.OrderBuilder<C, B> {
        @Override
        protected B $fillValuesFrom(final C instance) {
            super.$fillValuesFrom(instance);
            OrderType1Builder.$fillValuesFromInstanceIntoBuilder(instance, this);
            return self();
        }

        private static void $fillValuesFromInstanceIntoBuilder(final OrderType1 instance, final OrderType1Builder<?, ?> b) {
        }

        @Override
        protected abstract B self();

        @Override
        public abstract C build();

        @Override
        public String toString() {
            return "OrderType1.OrderType1Builder(super=" + super.toString() + ")";
        }
    }


    private static final class OrderType1BuilderImpl extends OrderType1Builder<OrderType1, OrderType1BuilderImpl> {
        private OrderType1BuilderImpl() {
        }

        @Override
        protected OrderType1BuilderImpl self() {
            return this;
        }

        @Override
        public OrderType1 build() {
            return new OrderType1(this);
        }
    }

    protected OrderType1(final OrderType1Builder<?, ?> b) {
        super(b);
    }

    public static OrderType1Builder<?, ?> builder() {
        return new OrderType1BuilderImpl();
    }

    public OrderType1Builder<?, ?> toBuilder() {
        return new OrderType1BuilderImpl().$fillValuesFrom(this);
    }

    @Override
    public boolean equals(final Object o) {
        if (o == this) return true;
        if (!(o instanceof OrderType1)) return false;
        final OrderType1 other = (OrderType1) o;
        if (!other.canEqual((Object) this)) return false;
        if (!super.equals(o)) return false;
        return true;
    }

    protected boolean canEqual(final Object other) {
        return other instanceof OrderType1;
    }

    @Override
    public int hashCode() {
        final int result = super.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "OrderType1()";
    }

    public OrderType1() {
    }
}
