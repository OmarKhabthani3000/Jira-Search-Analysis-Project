package org.di.entity;

import org.hibernate.annotations.DiscriminatorOptions;
import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import static javax.persistence.InheritanceType.SINGLE_TABLE;

@Entity
@Table(name = "orders")
@Inheritance(strategy = SINGLE_TABLE)
@DiscriminatorColumn(name = "indicator", discriminatorType = DiscriminatorType.STRING)
@DiscriminatorOptions(insert = false)
public class Order {
    @EmbeddedId
    private OrderPk orderPk;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "order", orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumns({@JoinColumn(name = "orderId", referencedColumnName = "orderId"), @JoinColumn(name = "indicator", referencedColumnName = "indicator")})
    private Metadata metadata;


    public static abstract class OrderBuilder<C extends Order, B extends OrderBuilder<C, B>> {
        private OrderPk orderPk;
        private Metadata metadata;

        protected B $fillValuesFrom(final C instance) {
            OrderBuilder.$fillValuesFromInstanceIntoBuilder(instance, this);
            return self();
        }

        private static void $fillValuesFromInstanceIntoBuilder(final Order instance, final OrderBuilder<?, ?> b) {
            b.orderPk(instance.orderPk);
            b.metadata(instance.metadata);
        }

        protected abstract B self();

        public abstract C build();

        public B orderPk(final OrderPk orderPk) {
            this.orderPk = orderPk;
            return self();
        }

        public B metadata(final Metadata metadata) {
            this.metadata = metadata;
            return self();
        }

        @Override
        public String toString() {
            return "Order.OrderBuilder(orderPk=" + this.orderPk + ", metadata=" + this.metadata + ")";
        }
    }


    private static final class OrderBuilderImpl extends OrderBuilder<Order, OrderBuilderImpl> {
        private OrderBuilderImpl() {
        }

        @Override
        protected OrderBuilderImpl self() {
            return this;
        }

        @Override
        public Order build() {
            return new Order(this);
        }
    }

    protected Order(final OrderBuilder<?, ?> b) {
        this.orderPk = b.orderPk;
        this.metadata = b.metadata;
    }

    public static OrderBuilder<?, ?> builder() {
        return new OrderBuilderImpl();
    }

    public OrderBuilder<?, ?> toBuilder() {
        return new OrderBuilderImpl().$fillValuesFrom(this);
    }

    public OrderPk getOrderPk() {
        return this.orderPk;
    }

    public Metadata getMetadata() {
        return this.metadata;
    }

    public void setOrderPk(final OrderPk orderPk) {
        this.orderPk = orderPk;
    }

    public void setMetadata(final Metadata metadata) {
        this.metadata = metadata;
    }

    @Override
    public boolean equals(final Object o) {
        if (o == this) return true;
        if (!(o instanceof Order)) return false;
        final Order other = (Order) o;
        if (!other.canEqual((Object) this)) return false;
        final Object this$orderPk = this.getOrderPk();
        final Object other$orderPk = other.getOrderPk();
        if (this$orderPk == null ? other$orderPk != null : !this$orderPk.equals(other$orderPk)) return false;
        final Object this$metadata = this.getMetadata();
        final Object other$metadata = other.getMetadata();
        if (this$metadata == null ? other$metadata != null : !this$metadata.equals(other$metadata)) return false;
        return true;
    }

    protected boolean canEqual(final Object other) {
        return other instanceof Order;
    }

    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $orderPk = this.getOrderPk();
        result = result * PRIME + ($orderPk == null ? 43 : $orderPk.hashCode());
        final Object $metadata = this.getMetadata();
        result = result * PRIME + ($metadata == null ? 43 : $metadata.hashCode());
        return result;
    }

    @Override
    public String toString() {
        return "Order(orderPk=" + this.getOrderPk() + ", metadata=" + this.getMetadata() + ")";
    }

    public Order() {
    }

    public Order(final OrderPk orderPk, final Metadata metadata) {
        this.orderPk = orderPk;
        this.metadata = metadata;
    }
}
