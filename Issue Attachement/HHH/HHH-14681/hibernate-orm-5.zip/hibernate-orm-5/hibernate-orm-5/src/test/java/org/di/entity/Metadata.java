package org.di.entity;

import org.hibernate.annotations.DiscriminatorOptions;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import static javax.persistence.InheritanceType.SINGLE_TABLE;

@Entity
@Table(name = "order_metadata")
@Inheritance(strategy = SINGLE_TABLE)
@DiscriminatorColumn(name = "indicator", discriminatorType = DiscriminatorType.STRING)
@DiscriminatorOptions(insert = false)
public class Metadata {
    @EmbeddedId
    private OrderPk orderMetadataPk;
    private Long revisionId;

    public void setOrderMetadataPk(Long id, String wipIndicator) {
        setOrderMetadataPk(new OrderPk(id, wipIndicator));
    }

    @OneToOne
    @JoinColumns({@JoinColumn(name = "orderId", referencedColumnName = "orderId", updatable = false, insertable = false), @JoinColumn(name = "indicator", referencedColumnName = "indicator", updatable = false, insertable = false)})
    private Order order;


    public static abstract class MetadataBuilder<C extends Metadata, B extends MetadataBuilder<C, B>> {
        private OrderPk orderMetadataPk;
        private Long revisionId;
        private Order order;

        protected B $fillValuesFrom(final C instance) {
            MetadataBuilder.$fillValuesFromInstanceIntoBuilder(instance, this);
            return self();
        }

        private static void $fillValuesFromInstanceIntoBuilder(final Metadata instance, final MetadataBuilder<?, ?> b) {
            b.orderMetadataPk(instance.orderMetadataPk);
            b.revisionId(instance.revisionId);
            b.order(instance.order);
        }

        protected abstract B self();

        public abstract C build();

        public B orderMetadataPk(final OrderPk orderMetadataPk) {
            this.orderMetadataPk = orderMetadataPk;
            return self();
        }

        public B revisionId(final Long revisionId) {
            this.revisionId = revisionId;
            return self();
        }

        public B order(final Order order) {
            this.order = order;
            return self();
        }

        @Override
        public String toString() {
            return "Metadata.MetadataBuilder(orderMetadataPk=" + this.orderMetadataPk + ", revisionId=" + this.revisionId + ", order=" + this.order + ")";
        }
    }


    private static final class MetadataBuilderImpl extends MetadataBuilder<Metadata, MetadataBuilderImpl> {
        private MetadataBuilderImpl() {
        }

        @Override
        protected MetadataBuilderImpl self() {
            return this;
        }

        @Override
        public Metadata build() {
            return new Metadata(this);
        }
    }

    protected Metadata(final MetadataBuilder<?, ?> b) {
        this.orderMetadataPk = b.orderMetadataPk;
        this.revisionId = b.revisionId;
        this.order = b.order;
    }

    public static MetadataBuilder<?, ?> builder() {
        return new MetadataBuilderImpl();
    }

    public MetadataBuilder<?, ?> toBuilder() {
        return new MetadataBuilderImpl().$fillValuesFrom(this);
    }

    public OrderPk getOrderMetadataPk() {
        return this.orderMetadataPk;
    }

    public Long getRevisionId() {
        return this.revisionId;
    }

    public void setOrderMetadataPk(final OrderPk orderMetadataPk) {
        this.orderMetadataPk = orderMetadataPk;
    }

    public void setRevisionId(final Long revisionId) {
        this.revisionId = revisionId;
    }

    @Override
    public boolean equals(final Object o) {
        if (o == this) return true;
        if (!(o instanceof Metadata)) return false;
        final Metadata other = (Metadata) o;
        if (!other.canEqual((Object) this)) return false;
        final Object this$orderMetadataPk = this.getOrderMetadataPk();
        final Object other$orderMetadataPk = other.getOrderMetadataPk();
        if (this$orderMetadataPk == null ? other$orderMetadataPk != null : !this$orderMetadataPk.equals(other$orderMetadataPk)) return false;
        final Object this$revisionId = this.getRevisionId();
        final Object other$revisionId = other.getRevisionId();
        if (this$revisionId == null ? other$revisionId != null : !this$revisionId.equals(other$revisionId)) return false;
        return true;
    }

    protected boolean canEqual(final Object other) {
        return other instanceof Metadata;
    }

    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $orderMetadataPk = this.getOrderMetadataPk();
        result = result * PRIME + ($orderMetadataPk == null ? 43 : $orderMetadataPk.hashCode());
        final Object $revisionId = this.getRevisionId();
        result = result * PRIME + ($revisionId == null ? 43 : $revisionId.hashCode());
        return result;
    }

    @Override
    public String toString() {
        return "Metadata(orderMetadataPk=" + this.getOrderMetadataPk() + ", revisionId=" + this.getRevisionId() + ")";
    }

    public Metadata() {
    }

    public Metadata(final OrderPk orderMetadataPk, final Long revisionId, final Order order) {
        this.orderMetadataPk = orderMetadataPk;
        this.revisionId = revisionId;
        this.order = order;
    }

    private Order getOrder() {
        return this.order;
    }

    private void setOrder(final Order order) {
        this.order = order;
    }
}
