import java.util.LinkedList;
import java.util.List;

public class Cheque
{
    private Long id;
    private String cmc7;
    private List<Situacao> situacoes;
    
    public Cheque()
    {
        situacoes = new LinkedList<Situacao>();
        Situacao situacaoInicial = new Situacao(this); // recebido
        situacoes.add(situacaoInicial);
    }
        
    public Long getId()
    {
        return id;
    }
    public void setId(Long id)
    {
        this.id = id;
    }

    public String getCmc7()
    {
        return cmc7;
    }
    public void setCmc7(String cmc7)
    {
        this.cmc7 = cmc7;
    }
    
    public List<Situacao> getSituacoes()
    {
        return situacoes;
    }
    public void setSituacoes(List<Situacao> situacoes)
    {
            this.situacoes = situacoes;
    }

    @Override
    public int hashCode()
    {
        return cmc7.hashCode();
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) {
            return true;
        }
        
        if (!(o instanceof Cheque)) {
            return false;
        }
        
        Cheque cheque = (Cheque)o;
        
        return this.getCmc7().equals(cheque.getCmc7());
    }

}
