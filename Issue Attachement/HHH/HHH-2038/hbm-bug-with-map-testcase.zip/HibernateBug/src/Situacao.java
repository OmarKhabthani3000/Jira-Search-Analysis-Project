import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Situacao
{
    private Cheque cheque;
    private Long id;
    private Date dataInicio;
    private Date dataFim;
    private Map<String, String> contexto;
    
    protected Situacao()
    {

    }
    
    public Situacao(Cheque cheque)
    {
        this.cheque = cheque;
        contexto = new HashMap<String, String>();
        dataInicio = new Date();
    }

    public Map<String, String> getContexto()
    {
        return contexto;
    }    
    public void setContexto(Map<String, String> contexto)
    {
        this.contexto = contexto;
    }
    
    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public Cheque getCheque()
    {
        return cheque;
    }
    public void setCheque(Cheque cheque)
    {
        this.cheque = cheque;
    }

    public Date getDataInicio()
    {
        return dataInicio;
    }
    public void setDataInicio(Date data)
    {
        this.dataInicio = data;
    }

    public Date getDataFim()
    {
        return dataFim;
    }
    public void setDataFim(Date dataFim)
    {
        this.dataFim = dataFim;
    }
    
    public int hashCode()
    {
        return this.dataInicio.hashCode();
    }

}
