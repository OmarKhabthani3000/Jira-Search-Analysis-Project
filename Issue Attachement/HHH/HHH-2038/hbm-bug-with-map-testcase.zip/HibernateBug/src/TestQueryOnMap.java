import junit.framework.TestCase;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.exception.SQLGrammarException;

public class TestQueryOnMap
    extends TestCase
{
    public void testQueryOnMap()
        throws Exception
    {
        Session session = HibernateUtil.currentSession();
        Query query = session.createQuery("from Cheque as cheque "
                + "where cheque.situacoes.contexto['foo'] = 'bar'");
        try {
            query.list();
        } catch (SQLGrammarException ex) {
            fail("Shouldn't throw an exception");
        }
    }
}
