/*
 * MainAction.java
 * @author Juan F. Arjona
 *
 */

package org.hibernate.test;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.ArrayList;
import java.util.List;
import javax.naming.InitialContext;

/**
 *
 * @author jarjona
 */
public class MainAction {
    Logger log = LoggerFactory.getLogger(MainAction.class);

    /**
     * Method description
     *
     *
     * @return
     */
    public List<Book> getBooks() {
        List<Book> answ = new ArrayList<>();

        try {
            log.info("Loading all books");

            TestTimer bean = (TestTimer) new InitialContext().lookup("java:module/TestTimer");

            answ.addAll(bean.getAllBooks());
            log.info("All books have been loaded");
        } catch (Exception ex) {
            log.error("Cannot get EJB", ex);
        }
        return answ;
    }

    /**
     * Method description
     *
     *
     * @return
     */
    @Action(value = "main", results = {@Result(name = "success", location = "/index.jsp") })
    public String main() {
        return "success";
    }
}
