/*
 * Book.java
 * @author Juan F. Arjona
 *
 */

package org.hibernate.test;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

/**
 *
 * @author jarjona
 */
@Entity
public class Book implements Serializable {
    private static final long serialVersionUID = 1L;
    @Column
    private String            author;
    @Column
    private String            code;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long              id;
    @Column
    private String            name;
    @Column
    @Lob
    private byte[]            pdf;

    /**
     * Method description
     *
     *
     * @param object
     *
     * @return
     */
    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Book)) {
            return false;
        }

        Book other = (Book) object;

        if (((this.id == null) && (other.id != null)) || ((this.id != null) &&!this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    /**
     * @return the author
     */
    public String getAuthor() {
        return author;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Method description
     *
     *
     * @return
     */
    public Long getId() {
        return id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the pdf
     */
    public byte[] getPdf() {
        return pdf;
    }

    /**
     * Method description
     *
     *
     * @return
     */
    @Override
    public int hashCode() {
        int hash = 0;

        hash += ((id != null)
                 ? id.hashCode()
                 : 0);
        return hash;
    }

    /**
     * @param author the author to set
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Method description
     *
     *
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @param pdf the pdf to set
     */
    public void setPdf(byte[] pdf) {
        this.pdf = pdf;
    }

    /**
     * Method description
     *
     *
     * @return
     */
    @Override
    public String toString() {
        return "org.hibernate.test.Book[ id=" + id + " ]";
    }
}
