/*
 * DataManagement.java
 * @author Juan F. Arjona
 *
 */

package org.hibernate.test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;
import javax.transaction.UserTransaction;

/**
 *
 * @author jarjona
 */
@Stateless
@LocalBean
@TransactionManagement(TransactionManagementType.BEAN)
public class DataManagement {
    Logger                       log = LoggerFactory.getLogger(DataManagement.class);
    @PersistenceUnit(name = "test")
    private EntityManagerFactory factory;
    @PersistenceContext(unitName = "test")
    private EntityManager        manager;
    @Resource
    private UserTransaction      transaction;

    /**
     * Method description
     *
     *
     * @return
     */
    public EntityManager getEM() {
        return manager;
    }

    /**
     * Method description
     *
     *
     * @param b
     */
    public void store(Book b) {
        try {
            transaction.begin();
            manager.persist(b);
            transaction.commit();
        } catch (Exception e) {
            log.warn("Cannot store book", e);
            try {
                transaction.rollback();
            } catch (Exception k) {
                log.info("Error rolling back...", k);
            }
        }
    }
}
