/*
 * TestTimer.java
 * @author Juan F. Arjona
 *
 */

package org.hibernate.test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Schedule;
import javax.ejb.Stateless;
import javax.ejb.TimerService;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

/**
 * Test hibernate running in a timed bean.
 * @author Juan Arjona
 */
@Stateless
@LocalBean
@TransactionManagement(TransactionManagementType.BEAN)
public class TestTimer {
    private static final List<Book> books = new ArrayList<>();
    Logger                          log   = LoggerFactory.getLogger(TestTimer.class);
    @EJB
    DataManagement                  dataManagement;
    @Resource
    TimerService                    timerservice;

    /**
     * Method description
     *
     *
     * @return
     */
    public List<Book> getAllBooks() {
        return books;
    }

    /**
     * Method description
     *
     */
    @Schedule(hour = "*", minute = "*")
    public void testTimer() {
        log.info("Timer started...");

        List<Book>       allBooks = dataManagement.getEM().createQuery("SELECT b FROM Book b", Book.class).getResultList();
        SimpleDateFormat fmt      = new SimpleDateFormat("dd-mmm-yyyy HH:mm");
        Date             now      = new Date();
        Book             b        = new Book();

        b.setName(fmt.format(now));
        b.setAuthor("My test: " + Math.round(Math.random() * 100));
        b.setCode(String.valueOf(Math.round(Math.random() * 100)));

        // Store the book
        dataManagement.store(b);
        books.clear();
        books.add(b);
        books.addAll(allBooks);
    }
}
