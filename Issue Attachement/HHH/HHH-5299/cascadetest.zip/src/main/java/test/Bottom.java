package test;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BOTTOM")
public class Bottom {
    @Id
    @GeneratedValue
    private Long id;
    @OneToOne(mappedBy = "bottom")
    private Middle middle;

    Long getId() {
        return id;
    }

    void setId(Long id) {
        this.id = id;
    }

    Middle getMiddle() {
        return middle;
    }

    void setMiddle(Middle middle) {
        this.middle = middle;
    }
}
