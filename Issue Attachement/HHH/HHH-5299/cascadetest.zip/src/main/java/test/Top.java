package test;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "TOP")
public class Top {
    @Id
    @GeneratedValue
    private Long id;

    @OneToMany(cascade = { CascadeType.ALL }, mappedBy = "top")
    List<Middle> middles;

    Long getId() {
        return id;
    }

    void setId(Long id) {
        this.id = id;
    }

    List<Middle> getMiddles() {
        if (middles == null) {
            middles = new ArrayList<Middle>();
        }
        return middles;
    }

    void setMiddles(List<Middle> middles) {
        this.middles = middles;
    }

    void addMiddle(Middle middle) {
        this.getMiddles().add(middle);
        middle.setTop(this);
    }
}
