package test;

import static org.junit.Assert.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.Test;

public class CascadeTest {

    @Test
    public void test() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("cascadetest");
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        Top top = new Top();
        em.persist(top);
        System.out.println("*****Flush 1:");
        em.flush();
        Middle middle = new Middle(1l);
        middle.setBottom(new Bottom());
        top.addMiddle(middle);
        Middle middle2 = new Middle(2l);
        middle2.setBottom(new Bottom());
        top.addMiddle(middle2);
        System.out.println("*****Flush 2:");
        em.flush();
        tx.commit();
        em.close();

        em = emf.createEntityManager();
        tx = em.getTransaction();
        tx.begin();

        top = em.find(Top.class, top.getId());

        assertEquals(2, top.getMiddles().size());
        for (Middle loadedMiddle : top.getMiddles()) {
            assertSame(top, loadedMiddle.getTop());
            assertNotNull(loadedMiddle.getBottom());
        }
        emf.close();
    }
}
