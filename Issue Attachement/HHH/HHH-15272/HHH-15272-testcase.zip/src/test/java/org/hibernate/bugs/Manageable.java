package org.hibernate.bugs;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
public  class Manageable
{
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Long id;

	@Basic
	private String name;

	@ManyToMany(mappedBy = "manager")
	@NotFound(action = NotFoundAction.IGNORE)
	private Set<Manageable> managed = new HashSet<>();

	@ManyToMany
	@JoinTable(name =  "managed",
		joinColumns = @JoinColumn(name = "managed"),
		inverseJoinColumns = @JoinColumn(name = "manager")
	)
	@NotFound(action = NotFoundAction.IGNORE)
	private Set<Manageable> manager = new HashSet<>();

	public Manageable()
	{
	}

	public Manageable(String name)
	{
		this.name = name;

	}

	public Long getId()
	{
		return id;
	}


	public String getName()
	{
		return name;
	}


	public void addManager(Manageable manager)
	{
		if(this.manager.contains(manager) == false)
		{
			this.manager.add(manager);
			manager.addManaged(this);
		}
	}

	public void addManaged(Manageable managed)
	{
		if(this.managed.contains(managed) == false)
		{
			this.managed.add(managed);
			managed.addManager(this);

		}
	}

	public Set<Manageable> getManagers()
	{
		return manager;
	}

	public Set<Manageable> getManaged()
	{
		return managed;
	}
}
