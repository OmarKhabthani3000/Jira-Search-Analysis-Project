package test.com.getronics.slg.civmk.magazijn.service.vragen;
import java.io.Serializable;
import java.util.Set;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * create table SJJORDM00 (
 * ORDKEY numeric(14) not null,
 * ORDERCOMMENT VARCHAR(40))   
 * */
public class Order implements Serializable {

 private static final long serialVersionUID = 1L;

/** identifier field */
  private Long key;

  /** persistent field */
  private String comment;
  
  private Set lines;

  /** default constructor */
  public Order() {
  }

  public Long getKey() {
    return this.key;
  }

  public void setKey(Long key) {
    this.key = key;
  }

  public Set getLines() { return lines; }

  public void setLines(Set lines) { this.lines=lines; }

  public String toString() {
    return new ToStringBuilder(this)
        .append("key", getKey())
        .toString();
  }

  public boolean equals(Object other) {
    if (! (other instanceof Order)) {
      return false;
    }
    Order castOther = (Order) other;
    return new EqualsBuilder()
        .append(this.getKey(), castOther.getKey())
        .isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder()
        .append(getKey())
        .toHashCode();
  }


public String getComment() {
	return comment;
}

public void setComment(String comment) {
	this.comment = comment;
}

}
