//Java testing code to demonstrate error
//======================================

  boolean found = false;

  Session sess
  //get a Session into "sess" ....

  //this example works OK when Order table is empty
  ScrollableResults foundRecs = sess.createQuery("from Order ord").scroll(ScrollMode.FORWARD_ONLY);
  found = foundRecs.next(); // uses to ScrollableResultsImpl.next()
  if (!found) System.out.println("nothing found");
  foundRecs.close();

  // This does NOT work when Order & OrderLine tables are both empty
  // We must catch the exception to be able to continue
  foundRecs = sess.createQuery("from Order ord left join fetch ord.lines").scroll(ScrollMode.FORWARD_ONLY);
	try {
		found = foundRecs.next(); // uses to FetchingScrollableResultsImpl.next()
	} catch (GenericJDBCException e) {
	  // kludge: there no discernable way to test if query.scroll(..) has returned an empty set
		if (e.getMessage().equalsIgnoreCase("could not perform sequential read of results (forward)")) {
			found=false;
		}
		else throw new DatabaseException(e.getMessage(), e);
	}
	if (!found) System.out.println("nothing found");
