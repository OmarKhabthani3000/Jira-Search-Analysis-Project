package test.com.getronics.slg.civmk.magazijn.service.vragen;
import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * create table SJJODLM00 (
 * ORDKEY numeric(14) not null,
 * LINEKEY numeric(14) not null,
 * PRODUCT VARCHAR(20))
 */
public class OrderLine implements Serializable {

  private static final long serialVersionUID = 1L;

/** identifier field */
  private Long key;
  
  /** link to parent entity */
  private Order order;

  /** persistent field */
  private String product;

  /** default constructor */
  public OrderLine() {
  }

  public Long getKey() {
    return this.key;
  }

  public void setKey(Long key) {
    this.key = key;
  }

  public String toString() {
    return new ToStringBuilder(this)
        .append("key", getKey())
        .toString();
  }

  public boolean equals(Object other) {
    if (! (other instanceof Order)) {
      return false;
    }
    Order castOther = (Order) other;
    return new EqualsBuilder()
        .append(this.getKey(), castOther.getKey())
        .isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder()
        .append(getKey())
        .toHashCode();
  }

public String getProduct() {
	return product;
}

public void setProduct(String product) {
	this.product = product;
}

public Order getOrder() {
	return order;
}

public void setOrder(Order order) {
	this.order = order;
}

}
