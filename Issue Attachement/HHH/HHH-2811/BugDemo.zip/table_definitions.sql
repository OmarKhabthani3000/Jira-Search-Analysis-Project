-- Order line table
create table SJJORDM00 (
 ORDKEY numeric(14) not null,
 ORDERCOMMENT VARCHAR(40));

-- Order line table
create table SJJODLM00 (
 ORDKEY numeric(14) not null,
 LINEKEY numeric(14) not null,
 PRODUCT VARCHAR(20));
