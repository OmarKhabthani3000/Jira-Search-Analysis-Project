package org.hibernate.bugs;

import static org.junit.Assert.assertTrue;

import java.util.function.Function;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    @Test
    public void test() {
        withEm(em -> em.merge(new Basket()));

        Basket basket = withEm(em -> em.createQuery("SELECT b FROM Basket b", Basket.class)
            .getResultStream()
            .findFirst()
            .get());

        assertTrue(basket.getFruits().isEmpty()); // not ok since 5.4.3
    }

    private Basket withEm(Function<EntityManager, Basket> function) {
        EntityManager em = entityManagerFactory.createEntityManager();
        try {
            em.getTransaction().begin();
            return function.apply(em);
        } finally {
            em.getTransaction().commit();
            em.close();
        }
    }
}
