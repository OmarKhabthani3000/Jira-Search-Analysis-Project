CREATE TABLE IF NOT EXISTS school_setting (
    school_id VARCHAR(32)       NOT NULL,
    setting_key VARCHAR(100)    NOT NULL,
    activated boolean           NOT NULL,
    CONSTRAINT school_setting_key_unique PRIMARY KEY(school_id, setting_key)
);