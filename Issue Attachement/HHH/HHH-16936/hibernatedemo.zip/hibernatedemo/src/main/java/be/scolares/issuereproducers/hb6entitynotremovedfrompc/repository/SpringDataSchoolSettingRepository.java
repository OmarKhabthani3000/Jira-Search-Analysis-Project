package be.scolares.issuereproducers.hb6entitynotremovedfrompc.repository;

import be.scolares.issuereproducers.hb6entitynotremovedfrompc.model.SchoolSetting;
import be.scolares.issuereproducers.hb6entitynotremovedfrompc.model.SchoolSettingId;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface SpringDataSchoolSettingRepository extends CrudRepository<SchoolSetting, SchoolSettingId> {
    @Query("delete from SchoolSetting s WHERE s.id = :id")
    @Modifying
    void deleteById(@Param("id") SchoolSettingId id);
}