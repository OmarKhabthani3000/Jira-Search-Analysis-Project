package be.scolares.issuereproducers.hb6entitynotremovedfrompc.model;

import jakarta.persistence.Embeddable;

import java.io.Serializable;

@Embeddable
public class SchoolSettingId implements Serializable {

    private final String schoolId;

    private final String settingKey;

    public SchoolSettingId(final String schoolId,
                           final String settingKey) {
        this.schoolId = schoolId;
        this.settingKey = settingKey;
    }
}