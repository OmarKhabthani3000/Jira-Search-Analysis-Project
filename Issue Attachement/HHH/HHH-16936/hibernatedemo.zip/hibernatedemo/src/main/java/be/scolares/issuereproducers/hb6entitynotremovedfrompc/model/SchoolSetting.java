package be.scolares.issuereproducers.hb6entitynotremovedfrompc.model;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;

@Entity
public class SchoolSetting {

    @EmbeddedId
    private final SchoolSettingId id;

    private boolean activated;

    public SchoolSetting(final String schoolId,
                         final String settingKey,
                         final boolean activated) {
        this.id = new SchoolSettingId(schoolId, settingKey);
        this.activated = activated;
    }
}