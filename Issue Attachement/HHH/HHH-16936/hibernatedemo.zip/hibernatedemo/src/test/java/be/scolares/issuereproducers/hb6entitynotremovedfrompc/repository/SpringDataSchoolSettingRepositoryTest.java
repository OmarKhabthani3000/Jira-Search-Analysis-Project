package be.scolares.issuereproducers.hb6entitynotremovedfrompc.repository;

import be.scolares.issuereproducers.hb6entitynotremovedfrompc.model.SchoolSettingId;
import be.scolares.issuereproducers.hb6entitynotremovedfrompc.model.SchoolSetting;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class SpringDataSchoolSettingRepositoryTest {

    static String SCHOOL_ID = "MY_SCHOOL";

    @Autowired
    TestEntityManager testEntityManager;

    @Autowired
    SpringDataSchoolSettingRepository springDataSchoolSettingRepository;

    @Test
    void deleteWithJpqlDoesntRemoveEntityFromPersistenceContext() {
        testEntityManager.persistAndFlush(createSetting());

        assertThat(springDataSchoolSettingRepository.findById(new SchoolSettingId(SCHOOL_ID, "ABSENCE_FOR_DAY_OFF")))
                .isNotEmpty();
        springDataSchoolSettingRepository.deleteById(new SchoolSettingId(SCHOOL_ID, "ABSENCE_FOR_DAY_OFF"));

        //testEntityManager.clear();
        assertThat(springDataSchoolSettingRepository.findById(new SchoolSettingId(SCHOOL_ID, "ABSENCE_FOR_DAY_OFF")))
                .isEmpty(); // should be true but is false (but work if we clear the persistence context before)
        assertThatCode(() -> springDataSchoolSettingRepository.deleteById(new SchoolSettingId(SCHOOL_ID, "ABSENCE_FOR_DAY_OFF")))
                .doesNotThrowAnyException();
    }

    private SchoolSetting createSetting() {
        return new SchoolSetting(SCHOOL_ID, "ABSENCE_FOR_DAY_OFF", true);
    }
}