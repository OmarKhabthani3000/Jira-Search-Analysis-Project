package org.hibernate.bugs;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "Event", schema = "db1")
public class Event {
    private Long id;
    @Temporal(TemporalType.TIMESTAMP )
    private Date createdOn;
    private Set<Location> locations;

    public Event() {
    }
    public Event(Date createdOn) {
        this.createdOn = createdOn;
    }


    @Id
    @GeneratedValue
    public Long getId() {
        return id;
    }

    @OneToMany(fetch = FetchType.EAGER, cascade = {CascadeType.REFRESH}, targetEntity = Location.class)
    public Set<Location> getLocations() {
        return locations;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setLocations(Set<Location> locations) {
        this.locations=locations;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public void setId(Long id) {

        this.id = id;
    }



}