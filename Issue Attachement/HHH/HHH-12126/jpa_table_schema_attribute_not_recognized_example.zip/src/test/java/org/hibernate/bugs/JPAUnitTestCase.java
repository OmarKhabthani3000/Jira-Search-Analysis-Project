package org.hibernate.bugs;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;
	private EntityManagerFactory entityManagerFactory2;

	@Before
	public void init() {

		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
		entityManagerFactory2 = Persistence.createEntityManagerFactory( "templatePU2" );
	}

	@After
	public void destroy() {
		entityManagerFactory2.close();
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void twoSchemaJoinTest() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		try {
			entityManager.getTransaction().begin();

			Location location1 = new Location("city1");
			Location location2 = new Location("city2");
			entityManager.persist(location1);
			entityManager.persist(location2);
			Set<Location> locations = new HashSet<>();
			locations.add(location1);
			locations.add(location2);
			Event event = new Event(new Date());
			event.setLocations(locations);
			entityManager.persist(event);
			entityManager.getTransaction().commit();

			entityManager.getTransaction().begin();
			String queryString = "Select distinct t from Event t join fetch t.locations";
			Query query = entityManager.createQuery(queryString);
			Event event1 = (Event) query.getSingleResult();
			System.out.println(event1.getId());

			//assertEquals(event.getCreatedOn(), dbEvent.getCreatedOn());
			entityManager.getTransaction().commit();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			entityManager.close();
		}

	}

	private void createLocations(){
		EntityManager entityManager2 = entityManagerFactory2.createEntityManager();
		entityManager2.getTransaction().begin();

		Location location1 = new Location("city1");
		Location location2 = new Location("city2");


		entityManager2.persist( location1 );
		entityManager2.persist( location2 );


		entityManager2.getTransaction().commit();
		entityManager2.close();
	}
}
