package org.svaor.sscce;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * @author Smelik Evgeniy
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/org/svaor/sscce/context-test.xml"})
public class HQLElementsTest {
	private final Logger log = LoggerFactory.getLogger(HQLElementsTest.class);

	@Autowired
	private SessionFactory sessionFactory;
	@Autowired
	private TransactionTemplate transactionTemplate;

	@Before
	public void before() {
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				final Session session = sessionFactory.getCurrentSession();

				Player player = new Player("player 1, expected");
				player.getScores().add(new Score(1));
				player.getScores().add(new Score(1));
				player.getScores().add(new Score(2));
				session.save(player);

				player = new Player("player 2, unexpected");
				player.getScores().add(new Score(4));
				player.getScores().add(new Score(5));
				player.getScores().add(new Score(6));
				session.save(player);
			}
		});
	}

	@After
	public void after() {
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				final Session session = sessionFactory.getCurrentSession();

				final DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Player.class);
				final Criteria criteria = detachedCriteria.getExecutableCriteria(session);
				//noinspection unchecked
				final List<Player> players = criteria.list();

				for (Player player : players) {
					session.delete(player);
				}
			}
		});
	}

	@Test
	public void testAsIs() {
		log.info("Test as is in the hibernate manual");

		final List<Player> players = transactionTemplate.execute(new TransactionCallback<List<Player>>() {
			@Override
			public List<Player> doInTransaction(TransactionStatus status) {
				final Session session = sessionFactory.getCurrentSession();

				final Query query = session.createQuery("FROM Player p WHERE 3 > ALL ELEMENTS(p.scores)");
				//noinspection unchecked
				return query.list();
			}
		});
		assertThat(players.size(), is(1));

		final Player player = players.get(0);
		log.info("Selected player: {}", player);
		assertThat(player.getName(), is("player 1, expected"));
	}

	@Test
	public void testWithField() {
		log.info("Test with additional join and field");

		final List<Player> players = transactionTemplate.execute(new TransactionCallback<List<Player>>() {
			@Override
			public List<Player> doInTransaction(TransactionStatus status) {
				final Session session = sessionFactory.getCurrentSession();

				final Query query = session.createQuery("FROM Player p JOIN p.scores s WHERE 3 > ALL ELEMENTS(s.score)");
				//noinspection unchecked
				return query.list();
			}
		});
		assertThat(players.size(), is(1));

		final Player player = players.get(0);
		log.info("Selected player: {}", player);
		assertThat(player.getName(), is("player 1, expected"));
	}
}
