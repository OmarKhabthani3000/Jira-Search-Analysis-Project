package org.svaor.sscce;

import java.util.Date;

/**
 * @author Smelik Evgeniy
 */
public class Score {
	private long id;
	private Date date;
	private int score;

	public Score() {
		date = new Date();
	}

	public Score(int score) {
		this();
		this.score = score;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
}
