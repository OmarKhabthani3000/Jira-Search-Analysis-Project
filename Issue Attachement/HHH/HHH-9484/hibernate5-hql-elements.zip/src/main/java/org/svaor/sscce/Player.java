package org.svaor.sscce;

import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Smelik Evgeniy
 */
public class Player {
	private long id;
	private String name;
	private List<Score> scores = new ArrayList<>();

	public Player() {
	}

	public Player(String name) {
		this.name = name;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Score> getScores() {
		return scores;
	}

	public void setScores(List<Score> scores) {
		this.scores = scores;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).
				append("name", name).
				toString();
	}
}
