package be;

import java.io.Serializable;

public class Relation implements Serializable {

	private Long id;
	private String one;
	private String two;

	// for hibernate
	Relation() {
	}

	public Relation(String one, String two) {
		this.one = one;
		this.two = two;
	}

	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getOne() {
		return one;
	}

	public String getTwo() {
		return two;
	}

	@Override
	public String toString() {
		return "Relation[one=" + one + ", two=" + two + "]";
	}
}
