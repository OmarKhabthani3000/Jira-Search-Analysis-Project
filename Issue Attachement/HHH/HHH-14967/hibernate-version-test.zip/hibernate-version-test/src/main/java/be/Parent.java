package be;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

public class Parent implements Serializable {

	private Long id;

	private Long version;

	private final Collection<Relation> relationTrace = new ArrayList<>();


	public Long getId() {
		return id;
	}

	@SuppressWarnings("unused")
	private void setId(Long id) {
		this.id = id;
	}

	public Long getVersion() {
		return version;
	}

	public void setVersion(final Long version) {
		this.version = version;
	}

	public Collection<Relation> getRelationTrace() {
		return relationTrace;
	}


	@Override
	public String toString() {
		return String.valueOf(id);
	}

	// for testing purposes
}
