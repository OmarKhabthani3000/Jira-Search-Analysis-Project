package be;

public interface TransactionalCodeRunner {
	void run(Runnable code);
}
