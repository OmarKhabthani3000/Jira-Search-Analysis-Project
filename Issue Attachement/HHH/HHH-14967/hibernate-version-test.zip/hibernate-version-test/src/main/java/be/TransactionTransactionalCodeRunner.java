package be;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Transactional(rollbackFor = Throwable.class, propagation = Propagation.REQUIRED)
public class TransactionTransactionalCodeRunner implements TransactionalCodeRunner {

	@Override
	public void run(Runnable code) {
		code.run();
	}
}
