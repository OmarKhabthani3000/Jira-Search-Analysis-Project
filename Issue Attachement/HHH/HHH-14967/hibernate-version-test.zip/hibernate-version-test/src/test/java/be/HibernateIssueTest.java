package be;

import static org.testng.Assert.assertEquals;

import org.apache.commons.lang3.mutable.MutableObject;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.Test;

@Test
@ContextConfiguration(locations = { "classpath:/hibernate-config-embedded.xml" })
public class HibernateIssueTest extends AbstractTestNGSpringContextTests {

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private TransactionalCodeRunner transactionalCodeRunner;

	public void testCaseNewEntity() {
		MutableObject<ParentTo> transferObject = new MutableObject<>();

		transactionalCodeRunner.run(() -> {
			Parent parent = new Parent();
			sessionFactory.getCurrentSession().save(parent);
			parent.getRelationTrace().add(new Relation("1", "2"));
			ParentTo parentTo = new ParentTo();
			sessionFactory.getCurrentSession().flush();
			parentTo.setVersion(parent.getVersion());
			transferObject.setValue(parentTo);
		});

		assertEquals(transferObject.getValue().getVersion().longValue(), 0L, "version alert");
	}
}
