package hhh951;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	private EntityManagerFactory emf;
	private EntityManager em;
	private String PERSISTENCE_UNIT_NAME = "hhh951";

	public static void main(String[] args) {
		Main hello = new Main();
		hello.initEntityManager();
		hello.read();
		hello.closeEntityManager();
	}

	private void initEntityManager() {
		emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		em = emf.createEntityManager();
	}

	private void closeEntityManager() {
		em.close();
		emf.close();
	}

	private void read() {
		/* works */
		runQueryWithMaxResults("SELECT b    FROM Book b inner join fetch b.category");

//		/* works */
//		runQuery(			   "SELECT b    FROM Book b inner join fetch b.category");
		
		/* doesn't work  - ORA-00918: column ambiguously defined */
		runQueryWithMaxResults("SELECT b, 1 FROM Book b inner join fetch b.category");
	}

	private List runQueryWithMaxResults(String queryString) {
		return em.createQuery(queryString).setMaxResults(10).getResultList();
	}
	
	private List runQuery(String queryString) {
		return em.createQuery(queryString).getResultList();
	}
	
}
