package org.hibernate.bugs;

import javax.persistence.*;

@Entity(name = "webtaskentity")
public class WebTaskEntity extends AbstractTaskEntity {

    @Column(name = "sessionid")
    private String sessionId;

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }
}