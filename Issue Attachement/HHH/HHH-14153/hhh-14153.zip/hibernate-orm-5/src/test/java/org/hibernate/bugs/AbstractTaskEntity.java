package org.hibernate.bugs;

import java.util.*;

import org.hibernate.annotations.*;

import javax.persistence.*;
import javax.persistence.Entity;

@Entity(name = "abstracttaskentity")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class AbstractTaskEntity {

    @Id
    @Type(type = "uuid-char")
    @Column(name = "id")
    private UUID taskId;
    private String name;
    private String description;
    private boolean locked;
    public UUID getTaskId() {
        return taskId;
    }
    public void setTaskId(UUID taskId) {
        this.taskId = taskId;
    }
    public boolean isLocked() {
        return locked;
    }

    /**
     * @param locked
     */
    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    public String getName() {
        return name;
    }

    /**
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    /**
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

}