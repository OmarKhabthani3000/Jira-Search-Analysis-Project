package org.hibernate.bugs;

import java.util.*;

import javax.persistence.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hh14153test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		WebTaskEntity e = new WebTaskEntity();
		e.setTaskId(UUID.randomUUID());
		e.setName("name");
		e.setSessionId("sessid");
		e.setDescription("description");
		entityManager.merge(e);
		entityManager.persist(e);
		entityManager.getTransaction().commit();
		entityManager.getTransaction().begin();
		Query q = entityManager.createQuery("UPDATE abstracttaskentity e SET "
				+ "e.locked = true "
				+ "WHERE e.locked = false AND e.taskId = :id");
		q.setParameter("id", e.getTaskId());
		q.executeUpdate();
		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
