package org.hibernate.bugs;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.Set;
import lombok.Data;

@Entity
@Table(name="role_scope_permissions")
@Data
public class RoleScopePermission implements Serializable {

    @Id
    @GeneratedValue
    private Long id;

    private String roleName;

    private String scopeName;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "roleName", referencedColumnName = "roleName")
    @JoinColumn(name = "scopeName", referencedColumnName = "scopeName")
    private Set<RoleScopeOperationPermission> operationPermissions;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "roleName", referencedColumnName = "roleName")
    @JoinColumn(name = "scopeName", referencedColumnName = "scopeName")
    private Set<RoleScopeOperationObjectPermission> operationObjectPermissions;

}
