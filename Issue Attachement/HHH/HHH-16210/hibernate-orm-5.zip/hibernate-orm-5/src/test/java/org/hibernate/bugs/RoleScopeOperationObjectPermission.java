package org.hibernate.bugs;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Table(name="role_scope_operation_object_permissions")
@Data
public class RoleScopeOperationObjectPermission implements Serializable {

    @Id
    @GeneratedValue
    private Long id;

    private String roleName;

    private String scopeName;

    private String operationName;

    private String objectName;
}
