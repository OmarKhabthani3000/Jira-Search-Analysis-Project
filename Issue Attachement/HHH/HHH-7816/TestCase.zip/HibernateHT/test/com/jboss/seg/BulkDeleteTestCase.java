package com.jboss.seg;

import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.transaction.UserTransaction;

import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import bitronix.tm.resource.jdbc.PoolingDataSource;


/**
 * This is a test case related to HHH-1361 - JBPAPP6-1628
 * @author <a href="mailto:alazarot@redhat.com">Alessandro Lazarotti</a>
 *
 */
public class BulkDeleteTestCase {
	protected static EntityManagerFactory emf;
	protected static UserTransaction tx;
	protected EntityManager em;
	protected static PoolingDataSource pds;

	@BeforeClass
	public static void buildSessionFactory() throws Exception {
			/*
			 * It uses Bitronix to reproduce a XA DataSource (needed to face this issue)
			 * For Bitronix work with Two-Phase commit, the oracle user *MUST* receive as privileges:
			 * grant select on sys.dba_pending_transactions to myUser;
			 * grant select on sys.pending_trans$ to myUser;
			 * grant select on sys.dba_2pc_pending to myUser;
			 * grant execute on sys.dbms_system to myUser;
			 */
			pds = OracleXaDatasourceHelper.setupDataSource();
			
			emf = Persistence.createEntityManagerFactory("testPU_XA");
			tx = (UserTransaction) new InitialContext().lookup("java:comp/UserTransaction");
			
			tx.begin();
			EntityManager em = emf.createEntityManager();
			em.createQuery("DELETE FROM LpvrProgramRecordingEntity lpre").executeUpdate();
			em.createQuery("DELETE FROM LpvrTimebasedRecordingEntity ltre").executeUpdate();
			tx.commit();
			em.close();
			
			insertTwoEntities();
	}

	@AfterClass
	public static void after() throws Exception {
			pds.close();
	}
	
	private static void insertTwoEntities() throws Exception {
		tx.begin();
		EntityManager em = emf.createEntityManager();
		
		em.joinTransaction();
		
		LpvrProgramRecordingEntity programRecordingEntity = new LpvrProgramRecordingEntity();
		programRecordingEntity.setEquipmentId("equipx");
		programRecordingEntity.setProgramId("programx");
		programRecordingEntity.setRecordingId("recx");
		
		LpvrTimebasedRecordingEntity timebasedRecordingEntity = new LpvrTimebasedRecordingEntity();
		timebasedRecordingEntity.setEquipmentId("equipx");
		timebasedRecordingEntity.setRecordingId("rec2x");
		timebasedRecordingEntity.setRecordingName("RecAx");

		em.persist(programRecordingEntity);
		em.persist(timebasedRecordingEntity);		
		
		tx.commit();
		em.close();			
	}

	@Before
	public void openSession() throws Exception {
		em = emf.createEntityManager();
	}

	@After
	public void closeSession() throws Exception {
		em.close();
	}
	
	@Test
	@SuppressWarnings("unchecked")
	public void testBulkDeletes() throws Exception {		
		try {
			tx.begin();
			em.joinTransaction();
			
			Long count = (Long) em.createQuery("SELECT count(*)FROM LpvrRecordingEntity e WHERE e.equipmentId = 'equipx' ").getSingleResult();
			Assert.assertEquals(2L, count.longValue());
			
//			em.createQuery("DELETE FROM LpvrRecordingEntity e WHERE e.equipmentId = 'equip' ").executeUpdate();
//			count = (Long) em.createQuery("SELECT count(*)FROM LpvrRecordingEntity e WHERE e.equipmentId = 'equip' ").getSingleResult();
//			
//			Assert.assertEquals(0L, count.longValue());
			
			tx.commit();
						
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
			throw e;
		}

	}	
}
