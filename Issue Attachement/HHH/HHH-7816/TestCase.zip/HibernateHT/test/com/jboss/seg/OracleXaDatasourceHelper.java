package com.jboss.seg;

import bitronix.tm.resource.jdbc.PoolingDataSource;

public final class OracleXaDatasourceHelper {
	
 	
	public static PoolingDataSource setupDataSource() {
 		        
        PoolingDataSource myDataSource = new PoolingDataSource();                                         
        myDataSource.setClassName("oracle.jdbc.xa.client.OracleXADataSource");                            
        myDataSource.setUniqueName("jdbc/oracle-ds");                                                             
        myDataSource.setMinPoolSize(0);                                                                   
        myDataSource.setMaxPoolSize(10);                                                                   
        myDataSource.setAcquireIncrement(1);                                                              
        myDataSource.setAllowLocalTransactions(true);                                                     
        myDataSource.setTestQuery("SELECT 1 FROM DUAL");                                                 
        myDataSource.setUseTmJoin(true);                                                                  
        myDataSource.setDeferConnectionRelease(true);                                                     
        myDataSource.setAutomaticEnlistingEnabled(true);                                                  
        myDataSource.setAcquisitionTimeout(30);                                                           
        myDataSource.setAcquisitionInterval(1);                                                           
        myDataSource.setPreparedStatementCacheSize(5);                                                    
        myDataSource.setTwoPcOrderingPosition(0);                                                         
        myDataSource.setApplyTransactionTimeout(true);                                                    
        myDataSource.setIgnoreRecoveryFailures(false);                                                    
        myDataSource.setIsolationLevel("READ_COMMITTED");                                                 
       //myDataSource.getDriverProperties().put("user", "GUEST2");
       //myDataSource.getDriverProperties().put("password",  "GUEST2");
        
        myDataSource.getDriverProperties().put("user", "lazarotti");
        myDataSource.getDriverProperties().put("password", "lazarotti");
        
        
        //myDataSource.getDriverProperties().put("URL","jdbc:oracle:thin:@mackoy:1521:orcl");
        myDataSource.getDriverProperties().put("URL","jdbc:oracle:thin:@zen.usersys.redhat.com:1521:oracle");
                 
        myDataSource.init();
        return myDataSource;
	}
	
}