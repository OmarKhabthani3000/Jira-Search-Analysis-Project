package com.jboss.seg;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name = "IAP_PVR_L_RECORDINGS")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class LpvrRecordingEntity implements Serializable{
  
    @Id
    @Column(name = "RECORDING_ID", nullable = false)
    private String recordingId;

    @Column(name = "EQUIPMENT_ID")
    private String equipmentId;

	public String getRecordingId() {
		return recordingId;
	}

	public void setRecordingId(String recordingId) {
		this.recordingId = recordingId;
	}

	public String getEquipmentId() {
		return equipmentId;
	}

	public void setEquipmentId(String equipmentId) {
		this.equipmentId = equipmentId;
	}
       
}