package com.jboss.seg;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "IAP_PVR_L_TIMEBASED_REC")
public class LpvrTimebasedRecordingEntity extends LpvrRecordingEntity implements Serializable {

    @Column(name = "RECORDING_NAME")
    private String recordingName;

	public String getRecordingName() {
		return recordingName;
	}

	public void setRecordingName(String recordingName) {
		this.recordingName = recordingName;
	}
    
    
}