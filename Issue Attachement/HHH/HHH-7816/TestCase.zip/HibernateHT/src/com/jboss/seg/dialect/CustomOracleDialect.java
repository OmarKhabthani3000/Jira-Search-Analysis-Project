package com.jboss.seg.dialect;

import org.hibernate.dialect.Oracle10gDialect;

public class CustomOracleDialect extends Oracle10gDialect {

	@Override
	public Boolean performTemporaryTableDDLInIsolation() {
		return true;
	}

	@Override
	public boolean dropTemporaryTableAfterUse() {
		return false;
	}
	
	
}
