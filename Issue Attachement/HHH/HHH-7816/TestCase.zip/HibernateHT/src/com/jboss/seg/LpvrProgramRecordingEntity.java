package com.jboss.seg;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "IAP_PVR_L_PROGRAM_REC")
public class LpvrProgramRecordingEntity extends LpvrRecordingEntity implements Serializable {
  
    @Column(name = "PROGRAM_ID", nullable = false)
    private String programId;

	public String getProgramId() {
		return programId;
	}

	public void setProgramId(String programId) {
		this.programId = programId;
	}    
}