import org.hibernate.*;
import org.hibernate.cfg.*;
//import model.Contact;

public class HibernateUtil {

	private static final SessionFactory sessionFactory;

    static {
        try {
            sessionFactory = new AnnotationConfiguration()
            .addAnnotatedClass(Contact.class)
            .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQLMyISAMDialect")
            .setProperty("hibernate.connection.url", "jdbc:mysql://localhost/test")
            .setProperty("hibernate.connection.driver_class", "com.mysql.jdbc.Driver")
            .setProperty("hibernate.connection.username", "username")
            .setProperty("hibernate.connection.password", "99123123")
            
//            .setProperty("hibernate.dialect", "org.hibernate.dialect.SQLServerDialect")
//            .setProperty("hibernate.connection.url", "jdbc:sqlserver://localhost:1433;DatabaseName=test")
//            .setProperty("hibernate.connection.driver_class", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
//            .setProperty("hibernate.connection.username", "sa")
//            .setProperty("hibernate.connection.password", "1212399")
            
            .setProperty(Environment.HBM2DDL_AUTO, "update")
            .setProperty(Environment.SHOW_SQL, "true")
            .setProperty("hibernate.cache.provider_class", "org.hibernate.cache.NoCacheProvider")
            .buildSessionFactory();
        } catch (Throwable ex) {
            // Log exception!
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static Session getSession()
            throws HibernateException {
        return sessionFactory.openSession();
    }
}
