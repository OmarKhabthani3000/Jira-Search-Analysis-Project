import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;

import org.hibernate.annotations.*;

@Entity
@Table(name = "CONTACTS")

// The below statement should generate an error if uncommented? But it gives no errors.
//@SQLInsert( sql="INSERT INTO CHAOS(size, name, nickname, id) VALUES(?,upper(?),?,?)")

// The below statement does not work too.
//@SQLInsert(sql="{ call sp_insert(?, ?) }", callable=true)

// The below statement should cause AAA and BBB values in the CONTACTS table? But it doesn't.
@SQLInsert(sql="INSERT INTO CONTACT(FIRST_NAME, LAST_NAME) VALUES(upper('aaa'),upper('bbb'))")
public class Contact {

  private Long contactId;
  private String firstName;
  private String lastName;

  @Id
  @GeneratedValue
  @Column(name = "CONTACT_ID")
  public Long getContactId() {
    return contactId;
  }

  public void setContactId(Long contactId) {
    this.contactId = contactId;
  }

  @Column(name = "FIRST_NAME")
  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  @Column(name = "LAST_NAME")
  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }
}