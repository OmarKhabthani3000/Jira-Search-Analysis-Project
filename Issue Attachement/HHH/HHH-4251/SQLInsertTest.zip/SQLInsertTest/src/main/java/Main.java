import org.hibernate.Session;

public class Main {
	public static void main(String[] args) {
		try {
			Contact newContact = new Contact();
			newContact.setFirstName(new StringBuilder("John").toString());
			newContact.setLastName(new StringBuilder("Smith").toString());

			Session session = HibernateUtil.getSession();
			session.beginTransaction();
			session.saveOrUpdate(newContact);
			session.getTransaction().commit();
			session.close();
		} catch (Throwable ex) {
			throw new ExceptionInInitializerError(ex);
		} finally {
		}
	}
}
