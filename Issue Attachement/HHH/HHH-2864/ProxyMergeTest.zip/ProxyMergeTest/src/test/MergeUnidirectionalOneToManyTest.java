package test;

import junit.framework.TestCase;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.hibernate.proxy.HibernateProxy;

public class MergeUnidirectionalOneToManyTest extends TestCase {
  private SessionFactory sf = new Configuration().configure().buildSessionFactory();
  private Session session;
  private Transaction transaction;
  
  protected void setUp() throws Exception {
    session = sf.getCurrentSession();
    transaction = session.beginTransaction();
  }
  
  public void testShouldNotCrashWithProxyInSession() throws Exception {
    // create new One
    One one = new One();
    one.setOneOther(new One());
    session.save(one);
    commitAndGetNewSession();
    /*
     * load saved instance as a proxy, but do not use it. we could use get() so we wouldn't get a proxy, but a real-world
     * application might have only loaded this instance transitively as a proxy before merging a detached instance, so this is a
     * real problem.
     */
    Object proxyWeDontUse = session.load(One.class, new Integer(one.getId()));
    assertTrue(proxyWeDontUse instanceof HibernateProxy);
    // use detached instance and add a Many
    one.getToMany().add(new Many());
    // merge the detached instance. this should work, but doesn't. the backref-getter doesn't correctly
    // find the parent object of the new Many, because the copyCache/mergeMap only contains the proxy loaded
    // above, but the entityEntries in PersistenceContext contain the raw unproxied object.
    session.merge(one);
  }
  
  public void testDoesNotCrashWithProxyEvictedFromSession() throws Exception {
    // create new One
    One one = new One();
    one.setOneOther(new One());
    session.save(one);
    commitAndGetNewSession();
    /*
     * load saved instance as a proxy, evict it immediately. we can't reliably do this in a real-world application
     */
    Object proxyWeWillEvict = session.load(One.class, new Integer(one.getId()));
    assertTrue(proxyWeWillEvict instanceof HibernateProxy);
    session.evict(proxyWeWillEvict);
    // use detached instance and add a Many
    one.getToMany().add(new Many());
    // merge the detached instance. this should work, and does.
    session.merge(one);
  }
  
  public void testDoesNotCrashWithoutProxyInSession() throws Exception {
    // create new One
    One one = new One();
    one.setOneOther(new One());
    session.save(one);
    commitAndGetNewSession();
    // do not use proxy this time
    Object notAProxy = session.get(One.class, new Integer(one.getId()));
    assertFalse(notAProxy instanceof HibernateProxy);
    // use detached instance and add a Many
    one.getToMany().add(new Many());
    // merge the detached instance. this should work, and does.
    session.merge(one);
  }
  
  public void commitAndGetNewSession() throws Exception {
    transaction.commit();
    session = sf.getCurrentSession();
    transaction = session.beginTransaction();
  }
  
  protected void tearDown() throws Exception {
    transaction.commit();
  }
}
