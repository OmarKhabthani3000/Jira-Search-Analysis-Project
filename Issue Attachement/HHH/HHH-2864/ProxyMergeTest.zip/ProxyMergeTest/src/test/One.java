package test;

import java.util.HashSet;
import java.util.Set;

public class One {
  private One oneOther;
  private int id;
  private int version = -1;
  private Set toMany = new HashSet();
  
  public One getOneOther() {
    return this.oneOther;
  }
  
  public void setOneOther(One oneOther) {
    this.oneOther = oneOther;
  }
  
  public int getId() {
    return this.id;
  }
  
  public void setId(int id) {
    this.id = id;
  }
  
  public int getVersion() {
    return this.version;
  }
  
  public void setVersion(int version) {
    this.version = version;
  }
  
  public Set getToMany() {
    return this.toMany;
  }
  
  public void setToMany(Set toMany) {
    this.toMany = toMany;
  }
  
}
