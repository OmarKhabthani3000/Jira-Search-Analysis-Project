package hibernate.bug;

import hibernate.bug.model.Address;
import hibernate.bug.model.Bro;
import hibernate.bug.model.Person;
import java.util.Arrays;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Bro p1 = new Bro();
        Bro p2 = new Bro();
        
        Address a = new Address("a", "a", "a");
        Address b = new Address("b", "b", "b");
        
        p1.setAddress(a);
        p2.setAddress(b);
        
        em.persist(p1);
        em.persist(p2);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testRveInList() throws Throwable {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        try {
            int updated = em.createQuery("DELETE Bro p WHERE p IN (SELECT p2 FROM Bro p2 WHERE p2.address.street = 'a')")
                .executeUpdate();
            Assert.assertEquals(1, updated);

            tx.commit();
        } catch (Throwable t) {
            tx.rollback();
            throw t;
        }
        
        em.close();
    }
}
