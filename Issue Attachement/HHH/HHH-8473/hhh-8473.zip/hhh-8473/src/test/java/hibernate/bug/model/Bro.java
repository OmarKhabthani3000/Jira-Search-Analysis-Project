
package hibernate.bug.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

@Entity
public class Bro extends Person {
    
    private Person bro;

    @ManyToOne(fetch = FetchType.LAZY)
    public Person getBro() {
        return bro;
    }

    public void setBro(Person bro) {
        this.bro = bro;
    }
    
}
