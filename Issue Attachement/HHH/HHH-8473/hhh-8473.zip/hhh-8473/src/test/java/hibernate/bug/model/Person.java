
package hibernate.bug.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Person implements Serializable {
    
    private Integer id;
    private Address address;
    private Set<Address> alternativeAddresses = new HashSet<Address>();

    @Id
    @GeneratedValue
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Embedded
    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    @ElementCollection
    public Set<Address> getAlternativeAddresses() {
        return alternativeAddresses;
    }

    public void setAlternativeAddresses(Set<Address> alternativeAddresses) {
        this.alternativeAddresses = alternativeAddresses;
    }
    
}
