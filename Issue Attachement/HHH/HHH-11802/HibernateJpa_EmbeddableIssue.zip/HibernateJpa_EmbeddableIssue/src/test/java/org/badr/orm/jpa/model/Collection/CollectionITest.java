/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.badr.orm.jpa.model.Collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.badr.orm.jpa.BaseClassITest;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author OBD
 */
public class CollectionITest extends BaseClassITest {
	
	@Test //@Ignore
	public void shouldInsertImageWithComputers(){
		
		Image image2 = new Image();
		Computer computer1 = new Computer();
		Computer computer2 = new Computer();
		
		image2.setName("MINE");
		computer1.setIpAddress("10.10.10.10");
		computer2.setIpAddress("20.20.20.20");
		
		List<String> locations = Arrays.asList("HardDisk", "USB");
		image2.setLocations(locations);
		
		Map<Integer, Computer> computerLocations = new HashMap<>();
		computerLocations.put(1, computer1);
		computerLocations.put(2, computer2);
		image2.setComputerLocation(computerLocations);
		
		List<Computer> computers = new ArrayList<>();
		computers.add(computer1);
		computers.add(computer2);
		image2.setComputers(computers);
		
		transaction.begin();
		entityManager.persist(image2);
		transaction.commit();
		
		entityManager.clear();
		
		transaction.begin();
		Image imageDB = entityManager.find(Image.class, image2.getId());
		transaction.commit();
		
		assertEquals(image2.getId(), imageDB.getId());
	}
	
}
