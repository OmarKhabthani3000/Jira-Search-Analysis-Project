package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Example for HHH-11345.
 */
public class HHH11345TestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void hhh11345Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		HHH11345Entity testEntity = new HHH11345Entity();
		entityManager.persist(testEntity);

		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<HHH11345Entity> query = criteriaBuilder.createQuery(HHH11345Entity.class);

		Root<HHH11345Entity> selection = query.from(HHH11345Entity.class);
		query.select(selection);

		Subquery<HHH11345Entity> subQuery = createSubQuery(query);

		// Add an additional condition to the created subquery
		// (just suppose we know nothing about that query, except the type of
		// the selection)
		subQuery.where(criteriaBuilder.and(subQuery.getRestriction(),
				criteriaBuilder.equal(subQuery.getSelection(), testEntity)));

		query.where(criteriaBuilder.exists(subQuery));

		// This creates a StackOverflowException
		entityManager.createQuery(query).getResultList();

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	private Subquery<HHH11345Entity> createSubQuery(CriteriaQuery<HHH11345Entity> query) {
		Subquery<HHH11345Entity> subQuery = query.subquery(HHH11345Entity.class);

		Root<HHH11345Entity> subSelection = subQuery.from(HHH11345Entity.class);
		subQuery.select(subSelection);
		subQuery.where(subSelection.isNotNull());
		return subQuery;
	}
}
