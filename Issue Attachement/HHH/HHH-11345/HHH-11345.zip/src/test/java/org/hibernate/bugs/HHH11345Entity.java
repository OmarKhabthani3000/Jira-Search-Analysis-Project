package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * Example entity for HHH-11345.
 * 
 * @author Tobias Liefke
 */
@Entity
public class HHH11345Entity {

	@Id
	@GeneratedValue
	private Long id;

}
