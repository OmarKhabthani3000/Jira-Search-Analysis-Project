package testapp;


import testapp.domain.Address;
import testapp.domain.Person;

import javax.persistence.*;


public class Main {


    /** Entity Manager factory. */
    private static final EntityManagerFactory emFactory =
        Persistence.createEntityManagerFactory( "lgp-core" );



    /**
     * App entry point.
     */
    public static void main( String[] args ) {
        Person  person1;
        Person  person2;



        System.out.println( "Creating person 1 ..." );
        person1 = new Person( "person1", 1, new Address("address1",null,null,null) );

        System.out.println( "Persisting person 1 ..." );
        try {
            save( person1, 0 );
        } catch( Exception x ) {
            System.out.println( "Exception whilst persisting person 1:" );
            x.printStackTrace();
            System.exit( 1 );
        }



        System.out.println( "Creating person 2 (accountNumber is the same as person 1's) ..." );
        person2 = new Person( "person2", 1, new Address("address2",null,null,null) );

        System.out.println( "Persisting person 2 ..." );
        try {
            save( person2, 0 );
        } catch( Exception x ) {
            System.out.println( "Exception whilst persisting person 2:" );
            x.printStackTrace();
            System.exit( 1 );
        }
    }



    /**
     * Has a person created or updated, cascading to their address.
     *
     * @param person The new or updated person's details.
     * @param retryCount This is used internally by this method when calling
     * recursively.  Any other calling method should pass zero.
     *
     * @throws Exception If an error prevents the person being saved.
     */
    private static void save( Person person, int retryCount ) throws Exception {
        final int                   MAX_ATTEMPTS = 5;
        boolean                     retryRequired;
        int                         oldAccountNumber;
        int                         newAccountNumber;
        EntityManager               em;
        EntityTransaction           txn;


        retryRequired = false;
        em            = emFactory.createEntityManager();
        em.setFlushMode( FlushModeType.COMMIT );
        txn = em.getTransaction();
        txn.begin();


        //Save the person:-
        try {
            System.out.println( "  Prior to merge/persist, person.getId()="
                + person.getId() + ", person.getAddress().getId()="
                + person.getAddress().getId() );
            if( person.getId() != 0 ) {
                em.merge( person );
            } else {
                em.persist( person );
            }
            txn.commit();
            System.out.println( "  merge/persist succeeded." );

        } catch( Exception x ) {
            System.out.println( "  Prior to rollback, person.getId()="
                + person.getId() + ", person.getAddress().getId()="
                + person.getAddress().getId() );
            txn.rollback();
            System.out.println( "  After rollback,    person.getId()="
                + person.getId() + ", person.getAddress().getId()="
                + person.getAddress().getId() );

            //Find out whether the failure was due to a duplicate key or not:-
            boolean     duplicateKeyException = false;
            Throwable   cause                 = x;
            while( !duplicateKeyException  &&  cause!=null ) {
                if( cause instanceof EntityExistsException ) {
                    duplicateKeyException = true;
                } else {
                    cause = cause.getCause();
                }
            }

            //If the exception was due to a duplicate key, then there was an
            //AccountNumber collision, so retry with a different value:-
            if( duplicateKeyException ) {
                retryRequired = true;
            } else {
                throw new Exception( "Unable to save person", x );
            }
        } finally {
            em.close();
        }


        //If a retry is required then do so:-
        if( retryRequired ) {
            retryCount++;
            oldAccountNumber = person.getAccountNo();
            newAccountNumber = oldAccountNumber + 1;
            person.setAccountNo( newAccountNumber );
            if( retryCount < MAX_ATTEMPTS ) {
                System.out.println( "Creation of new person failed due to" +
                    " duplicate account number (" + oldAccountNumber +
                    ") - retrying with different account number (" +
                    newAccountNumber + ", retry# " + retryCount + ") ..." );
                save( person, retryCount );
            } else {
                throw new Exception(
                    "Creation of new person failed due to duplicate"
                    + " account number - this was retried " + MAX_ATTEMPTS
                    + " times, but failed every time and the"
                    + " maximum-attempt-count has now been exceeded." );
            }
        }
    }
}