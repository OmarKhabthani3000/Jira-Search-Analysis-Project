package testapp.domain;


public class Person {

    private int     id;
    private int     accountNo;
    private String  name;
    private Address address;





    /**
     * Creates a new Person.
     *
     * @param name The person's name.
     * @param accountNo The person's unique Account Number.
     * @param address The person's address.
     */
    public Person( String name, int accountNo, Address address ) {
        this.name       = name;
        this.accountNo  = accountNo;
        this.address    = address;
    }



    /**
     * Default constructor required by Java Persistence specification - this is
     * not for application use.
     */
    protected Person() {
    }



    public int getId() {
        return id;
    }



    public String getName() {
        return name;
    }



    public int getAccountNo() {
        return accountNo;
    }



    public void setAccountNo( int accountNo ) {
        this.accountNo = accountNo;
    }



    public Address getAddress() {
        return address;
    }
}