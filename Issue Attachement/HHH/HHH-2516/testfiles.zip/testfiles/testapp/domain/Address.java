package testapp.domain;


public class Address {

    private int     id;
    private String  addr1;
    private String  addr2;
    private String  addr3;
    private String  addr4;





    /**
     * Creates a new Address.
     *
     * @param addr1 First line of the address (compulsory).
     * @param addr2 Second line of the address (optional).
     * @param addr3 Third line of the address (optional).
     * @param addr4 Fourth line of the address (optional).
     */
    public Address( String addr1, String addr2, String addr3, String addr4 ) {
        this.addr1 = addr1;
        this.addr2 = addr2;
        this.addr3 = addr3;
        this.addr4 = addr4;
    }



    /**
     * Default constructor required by Java Persistence specification - this is
     * not for application use.
     */
    protected Address() {
    }



    public int getId() {
        return id;
    }



    public String getAddr1() {
        return addr1;
    }



    public String getAddr2() {
        return addr2;
    }



    public String getAddr3() {
        return addr3;
    }



    public String getAddr4() {
        return addr4;
    }
}