package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import jakarta.persistence.Tuple;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.setExtractBareNamePropertyMethods;
import org.hibernate.Session;
import org.hibernate.query.criteria.JpaCriteriaQuery;
import org.hibernate.query.criteria.JpaCteCriteria;
import org.hibernate.query.criteria.JpaDerivedJoin;
import org.hibernate.query.criteria.JpaDerivedRoot;
import org.hibernate.query.criteria.JpaEntityJoin;
import org.hibernate.query.criteria.JpaJoin;
import org.hibernate.query.criteria.JpaRoot;
import org.hibernate.query.criteria.JpaSubQuery;
import org.hibernate.query.criteria.JpaWindow;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private static final Logger LOGGER = LogManager.getLogger();
	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}


	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void testCase() throws Exception {
		try (EntityManager entityManager = entityManagerFactory.createEntityManager()) {
			entityManager.getTransaction().begin();
			//given
			persistData(entityManager);
			var cb = entityManager.unwrap(Session.class).getCriteriaBuilder();
			JpaCriteriaQuery<Tuple> cteQuery = cb.createTupleQuery();
			JpaRoot<Primary> cteRoot = cteQuery.from(Primary.class);
			cteQuery.multiselect(
					cteRoot.get("id").alias("id"),
					cteRoot.get("nextFk").alias("nextId")
			).where(
					cteRoot.get("id").in(1, 2)
			);
			JpaCriteriaQuery<String> query = cb.createQuery(String.class);
			JpaSubQuery<Integer> subquery = query.subquery(Integer.class);
			JpaCteCriteria<Tuple> sqCte = subquery.with(cteQuery);
			JpaRoot<Tuple> sqRoot = subquery.from(sqCte);
			subquery.select(sqRoot.get("id"));


			JpaRoot<Primary> root = query.from(Primary.class);
			query.select(
					root.get("path")
			).where(
					root.get("id").in(subquery)
			).orderBy(
					cb.asc(root.get("path"))
			);
			List<String> list = entityManager.createQuery(query).getResultList();
			assertThat(list).hasSize(2);
			assertThat(list).isEqualTo(List.of("a", "a_a"));
		} catch (Throwable t) {
			LOGGER.error(t.getMessage(), t);
			throw t;
		}
	}

	private void persistData(EntityManager em) {
		Primary aa = createPrimary(1, "a_a", null);
		Primary a = createPrimary(2, "a", aa);

		Primary bb = createPrimary(3, "b_b", null);
		Primary b = createPrimary(4, "b", bb);

		Stream.of(a, aa, b, bb).forEach(em::persist);
		em.flush();
		em.clear();
	}


	private Primary createPrimary(int id, String path, Primary nextOrNull) {
		var entity = new Primary();
		entity.setId(id);
		entity.setPath(path);
		entity.setNext(nextOrNull);
		return entity;
	}

}
