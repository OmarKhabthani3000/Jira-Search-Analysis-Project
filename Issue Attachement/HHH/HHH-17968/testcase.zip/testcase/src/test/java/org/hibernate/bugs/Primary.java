/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package org.hibernate.bugs;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(schema = "public", name = "t_primary")
public class Primary implements Serializable {

    @Id
    private int id;
    private String path;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "t_primary_id")
    private Primary next;
    @Column(name = "t_primary_id", insertable = false, updatable = false)
    private Integer nextFk;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Primary getNext() {
        return next;
    }

    public void setNext(Primary next) {
        this.next = next;
    }

    public Integer getNextFk() {
        return nextFk;
    }

    public void setNextFk(Integer nextFk) {
        this.nextFk = nextFk;
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Primary primary = (Primary) o;
        return id == primary.id;
    }

    @Override public int hashCode() {
        return Objects.hash(id);
    }
}
