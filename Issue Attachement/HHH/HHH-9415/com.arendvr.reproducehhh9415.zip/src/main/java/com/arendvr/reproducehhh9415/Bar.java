package com.arendvr.reproducehhh9415;

public final class Bar {
    private final Integer integer;

    private Bar(Integer integer) {
        this.integer = integer;
    }

    public Integer toInteger() {
        return integer;
    }

    public static Bar create(Integer integer) {
        return new Bar(integer);
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Bar [integer=");
        builder.append(integer);
        builder.append("]");
        return builder.toString();
    }
}
