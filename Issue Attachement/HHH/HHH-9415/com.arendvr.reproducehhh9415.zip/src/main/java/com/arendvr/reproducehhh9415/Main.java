package com.arendvr.reproducehhh9415;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("FooPersistenceUnit");
        try {
            EntityManager em = emf.createEntityManager();

            EntityTransaction transaction = em.getTransaction();
            transaction.begin();

            Foo foo = new Foo();
            foo.setBar(Bar.create(3));
            em.persist(foo);

            transaction.commit();

            List<Foo> foos = em.createQuery("select f from Foo f", Foo.class).getResultList();
            System.out.println(foos);
        } finally {
            emf.close();
        }
    }
}
