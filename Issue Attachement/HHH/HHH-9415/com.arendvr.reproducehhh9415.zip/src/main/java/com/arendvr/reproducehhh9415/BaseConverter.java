package com.arendvr.reproducehhh9415;

import javax.persistence.AttributeConverter;

public abstract class BaseConverter implements AttributeConverter<Bar, Integer> {
    abstract Bar create(Integer value);

    @Override
    public Bar convertToEntityAttribute(Integer t) {
        return create(t);
    }

    @Override
    public Integer convertToDatabaseColumn(Bar t) {
        return t.toInteger();
    }
}
