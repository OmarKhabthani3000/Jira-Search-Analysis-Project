package com.arendvr.reproducehhh9415;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class ConverterImpl extends BaseConverter

// workaround for HHH-9415 for hibernate-entitymanager <= 4.3.10.Final
// implements AttributeConverter<Bar, Integer>

{
    @Override
    Bar create(Integer value) {
        return Bar.create(value);
    }
}
