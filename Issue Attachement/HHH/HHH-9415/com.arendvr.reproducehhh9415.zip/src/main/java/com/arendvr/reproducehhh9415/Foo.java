package com.arendvr.reproducehhh9415;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Foo {
    @Id
    @GeneratedValue
    private Integer id;

    @Column
    @Convert(converter = ConverterImpl.class)
    private Bar bar;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Bar getBar() {
        return bar;
    }

    public void setBar(Bar bar) {
        this.bar = bar;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Foo [id=");
        builder.append(id);
        builder.append(", bar=");
        builder.append(bar);
        builder.append("]");
        return builder.toString();
    }
}
