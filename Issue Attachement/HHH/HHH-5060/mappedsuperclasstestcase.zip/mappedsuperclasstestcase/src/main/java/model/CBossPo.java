package model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "3")
public class CBossPo extends CBossPoBasic {

    // modify after changing class content
    private static final long serialVersionUID = 0L;

}
