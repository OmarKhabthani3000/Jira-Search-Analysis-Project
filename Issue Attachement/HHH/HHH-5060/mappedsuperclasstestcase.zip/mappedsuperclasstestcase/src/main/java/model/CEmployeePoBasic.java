package model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToMany;

@MappedSuperclass
public class CEmployeePoBasic extends CPersonPo {

    private static final long serialVersionUID = -838673525242893L;

    @Column(name = "SALARY")
    private Long salary;

    @Column(name = "LOGIN")
    private String login;

    @ManyToOne(targetEntity = CEmployeePo.class)
    @JoinColumn(name = "SUPERVISOR_ID")
    private CEmployeePo supervisor;

    @ManyToOne(targetEntity = CCompanyPo.class)
    @JoinColumn(name = "company_id")
    private CCompanyPo company;

    @OneToMany(targetEntity = CEmployeePo.class, mappedBy = "supervisor")
    private Set<CEmployeePo> subordinates;

    public CEmployeePoBasic() {
        //
    }

    public Long getSalary() {
        return salary;
    }

    public void setSalary(Long salary) {
        this.salary = salary;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public CEmployeePo getSupervisor() {
        return supervisor;
    }

    public void setSupervisor(CEmployeePo supervisor) {
        this.supervisor = (CEmployeePo) supervisor;
    }

    public CCompanyPo getCompany() {
        return company;
    }

    public void setCompany(CCompanyPo company) {
        this.company = company;
    }

    public Set<CEmployeePo> getSubordinates() {
        return subordinates;
    }

    public void setSubordinates(Set<CEmployeePo> subordinates) {
        this.subordinates = subordinates;
    }

    public void addToSubordinates(CEmployeePo subordinates) {
        this.subordinates.add(subordinates);
    }

    public void removeFromSubordinates(CEmployeePo subordinates) {
        this.subordinates.remove(subordinates);
    }
}
