package model2;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
@DiscriminatorValue(value = "2")
public class CEmployee2Po extends CPerson2Po {

    private static final long serialVersionUID = -838673525242893L;

    @Column(name = "SALARY")
    private Long salary;

    @Column(name = "LOGIN")
    private String login;

    @ManyToOne(targetEntity = CEmployee2Po.class)
    @JoinColumn(name = "SUPERVISOR_ID")
    private CEmployee2Po supervisor;

    @ManyToOne(targetEntity = CCompany2Po.class)
    @JoinColumn(name = "company_id")
    private CCompany2Po company;

    @OneToMany(targetEntity = CEmployee2Po.class, mappedBy = "supervisor")
    private Set<CEmployee2Po> subordinates;

    public CEmployee2Po() {
        //
    }

    public Long getSalary() {
        return salary;
    }

    public void setSalary(Long salary) {
        this.salary = salary;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public CEmployee2Po getSupervisor() {
        return supervisor;
    }

    public void setSupervisor(CEmployee2Po supervisor) {
        this.supervisor = (CEmployee2Po) supervisor;
    }

    public CCompany2Po getCompany() {
        return company;
    }

    public void setCompany(CCompany2Po company) {
        this.company = company;
    }

    public Set<CEmployee2Po> getSubordinates() {
        return subordinates;
    }

    public void setSubordinates(Set<CEmployee2Po> subordinates) {
        this.subordinates = subordinates;
    }

    public void addToSubordinates(CEmployee2Po subordinates) {
        this.subordinates.add(subordinates);
    }

    public void removeFromSubordinates(CEmployee2Po subordinates) {
        this.subordinates.remove(subordinates);
    }
}
