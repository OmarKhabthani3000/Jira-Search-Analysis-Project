package model2;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
@DiscriminatorValue(value = "3")
public class CBoss2Po extends CEmployee2Po {

    private static final long serialVersionUID = 4272535232L;

    @Column(name = "TITLE")
    private String title;

    @OneToOne(targetEntity = CCompany2Po.class)
    @JoinColumn(name = "OWNED_COMPANY_ID")
    private CCompany2Po ownedCompany;

    public CBoss2Po() {
        //
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public CCompany2Po getOwnedCompany() {
        return ownedCompany;
    }

    public void setOwnedCompany(CCompany2Po ownedCompany) {
        this.ownedCompany = (CCompany2Po) ownedCompany;
    }

}
// Do not modify! Code generated from UML Model class org.jcas.unittestmodel::Boss
