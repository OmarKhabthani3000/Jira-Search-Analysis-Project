package model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "TAB_COMPANY")
public class CCompanyPo extends CCompanyPoBasic {

    // modify after changing class content
    private static final long serialVersionUID = 0L;

}
