package model2;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TAB_COMPANY")
public class CCompany2Po {

    private static final long serialVersionUID = -1489869236357L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
    @SequenceGenerator(name = "seq", sequenceName = "SEQ_COMPANY", allocationSize = 1)
    @Column(name = "ID")
    private Long id;

    @Column(name = "NAME")
    private String name;

    @OneToMany(targetEntity = CEmployee2Po.class, mappedBy = "company")
    private Set<CEmployee2Po> employees;

    @OneToOne(targetEntity = CBoss2Po.class, mappedBy = "ownedCompany")
    private CBoss2Po owner;

    public CCompany2Po() {
        //
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<CEmployee2Po> getEmployees() {
        return employees;
    }

    public void setEmployees(Set<CEmployee2Po> employees) {
        this.employees = employees;
    }

    public void addToEmployees(CEmployee2Po employees) {
        this.employees.add(employees);

    }

    public void removeFromEmployees(CEmployee2Po employees) {
        this.employees.remove(employees);

    }

    public CBoss2Po getOwner() {
        return owner;
    }

    public void setOwner(CBoss2Po owner) {
        this.owner = owner;
    }

}
