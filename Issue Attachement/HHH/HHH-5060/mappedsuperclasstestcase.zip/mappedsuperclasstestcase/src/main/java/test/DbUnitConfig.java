/**
 * 
 */
package test;


import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Properties;

import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.ReplacementDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.operation.DatabaseOperation;
import org.hibernate.cfg.Environment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Klasa ułatwiająca przygotowanie danych testowych za pomocą DbUnit.
 */
public class DbUnitConfig {

    private static final Logger logger = LoggerFactory.getLogger(DbUnitConfig.class);

    private static final String DB_FOR_UNIT_TESTS_PROPERTIES = "/db-for-unit-tests.properties";

    private Properties dbProps;

    public DbUnitConfig() {
        this.dbProps = loadDbProps();
        createSchema();
    }

    private final Properties loadDbProps() {
        Properties props = new Properties();
        try {
            props.load(JUnitHsqldbTestCase.class.getClass().getResourceAsStream(DB_FOR_UNIT_TESTS_PROPERTIES));
        } catch (IOException e) {
            logger.error("Błąd przy ładowaniu pliku resources. ", e);
            throw new IllegalStateException(e);
        }
        logger.debug("props: " + DB_FOR_UNIT_TESTS_PROPERTIES + " ...:");
        return props;
    }

    public Properties getDbProps() {
        return dbProps;
    }

    public Connection getDbConnection() throws Exception {
        String jdbcDriver = dbProps.getProperty("jdbc.driver");
        String jdbcURL = dbProps.getProperty("jdbc.url");
        String jdbcUser = dbProps.getProperty("jdbc.user");
        String jdbcPass = dbProps.getProperty("jdbc.pass");

        logger.debug("jdbc.driver  :  " + jdbcDriver);
        logger.debug("jdbc.url     :  " + jdbcURL);
        logger.debug("jdbc.user    :  " + jdbcUser);
        logger.debug("jdbc.pass    :  " + jdbcPass);

        Class.forName(jdbcDriver);
        return DriverManager.getConnection(jdbcURL, jdbcUser, jdbcPass);
    }

    public void shutdown() {
        execute("SHUTDOWN");
    }

    public void dumpDatabase(String file) {
        execute("SCRIPT '" + file + "'");
    }

    public void createSchema() {
        String schema = dbProps.getProperty(Environment.DEFAULT_SCHEMA);
        execute("CREATE SCHEMA " + schema + " AUTHORIZATION DBA");
    }

    public void execute(String sql) {
        Connection dbConnection = null;
        java.sql.Statement statement = null;
        try {
            dbConnection = getDbConnection();
            statement = dbConnection.createStatement();
            statement.execute(sql);
        } catch (Exception e) {
            logger.error("Błąd podczas wykonywania: " + sql, e);
        } finally {
            close(statement, dbConnection);
        }
    }
    
    private void close(Statement statement, Connection dbConnection) {
        if (statement != null) {
            try {
                statement.close();
            } catch (Exception e) {
                logger.warn("Błąd przy zamykaniu statement: ", e);
            }
        }
        if (dbConnection != null) {
            try {
                dbConnection.close();
            } catch (Exception e) {
                logger.warn("Błąd przy zamykaniu połączenia", e);
            }
        }
    }

    /**
     * Przygotowywuje dane na testowej bazie. Z bazy usuwane są wszystkie dane z tabelek jakie są
     * wymienione w pliku <code>dataSetUrl</code> i dodawane są tylko te dane które są pliku.
     * 
     * @param classRef klasa określająca w kórym miejscu należy szukać pliku.
     * @param dataSetFile nazwa pliku z danymi.
     */
    public void setup(Class<?> classRef, String dataSetFile) {
        URL dataSetUrl = classRef.getResource(dataSetFile);
        if (dataSetUrl == null) {
            String message = "Nie znaleziono pliku " + dataSetFile + ", szukając względem klasy: " + classRef.getName();
            logger.error(message);
            throw new IllegalArgumentException(message);
        }
        Connection dbConnection = null;
        Statement statement = null;
        try {
            FlatXmlDataSet dataSetRaw = new FlatXmlDataSet(dataSetUrl, false, true);
            ReplacementDataSet dataSet = new ReplacementDataSet(dataSetRaw);
            dataSet.setStrictReplacement(true);
            dataSet.addReplacementObject("[null]", null);

            dbConnection = getDbConnection();
            statement = dbConnection.createStatement();

            IDatabaseConnection connection = new DatabaseConnection(dbConnection);
            connection.getConfig().setFeature("http://www.dbunit.org/features/qualifiedTableNames", true);

            statement.executeUpdate("SET REFERENTIAL_INTEGRITY FALSE");
            DatabaseOperation.DELETE_ALL.execute(connection, dataSet);
            statement.executeUpdate("SET REFERENTIAL_INTEGRITY TRUE");
            DatabaseOperation.INSERT.execute(connection, dataSet);
        } catch (Exception e) {
            logger.error("Błąd przy przygotowywaniu bazy: ", e);
            throw new IllegalArgumentException(e);
        } finally {
            close(statement, dbConnection);
        }
    }

    public Properties getDriverProperties() {
        Properties properties = new Properties();
        properties.put("driverClassName", dbProps.getProperty("jdbc.driver"));
        properties.put("url", dbProps.getProperty("jdbc.url"));
        properties.put("user", dbProps.getProperty("jdbc.user"));
        properties.put("password", dbProps.getProperty("jdbc.pass"));

        return properties;
    }
}
