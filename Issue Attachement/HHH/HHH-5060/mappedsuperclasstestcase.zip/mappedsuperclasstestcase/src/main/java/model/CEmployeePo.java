package model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "2")
public class CEmployeePo extends CEmployeePoBasic {

    // modify after changing class content
    private static final long serialVersionUID = 0L;

}
