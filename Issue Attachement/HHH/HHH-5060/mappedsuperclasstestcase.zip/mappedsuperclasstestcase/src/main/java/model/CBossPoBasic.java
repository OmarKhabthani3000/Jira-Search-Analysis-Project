package model;

import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToOne;

@MappedSuperclass
public class CBossPoBasic extends CEmployeePo {

    private static final long serialVersionUID = 4272535232L;

    @Column(name = "TITLE")
    private String title;

    @OneToOne(targetEntity = CCompanyPo.class)
    @JoinColumn(name = "OWNED_COMPANY_ID")
    private CCompanyPo ownedCompany;

    public CBossPoBasic() {
        //
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public CCompanyPo getOwnedCompany() {
        return ownedCompany;
    }

    public void setOwnedCompany(CCompanyPo ownedCompany) {
        this.ownedCompany = (CCompanyPo) ownedCompany;
    }

}
// Do not modify! Code generated from UML Model class org.jcas.unittestmodel::Boss
