package test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import junit.framework.Assert;

import org.junit.Test;

public class CMappedSuperclassTestCase extends JUnitHsqldbTestCase {

    @Override
    protected String getDataSetUrl() {
        return "daoTestData.xml";
    }

    public void setUp() {
        super.setUp();
    }

    @Test
    public void testSimpleQueryModel() {
        EntityManager em = getEntityManager();
        Query q = em.createQuery("SELECT p1 FROM model.CEmployeePo p1");
        q.setFirstResult(0);
        q.setMaxResults(3);
        List<?> resultList = q.getResultList();
        Assert.assertEquals(2, resultList.size());
    }

    @Test
    public void testSimpleQueryModel2() {
        EntityManager em = getEntityManager();
        Query q = em.createQuery("SELECT p1 FROM model2.CEmployee2Po p1");
        q.setFirstResult(0);
        q.setMaxResults(3);
        List<?> resultList = q.getResultList();
        Assert.assertEquals(2, resultList.size());
    }
    
}
