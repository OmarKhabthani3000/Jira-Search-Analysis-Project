package test;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

public abstract class JUnitHsqldbTestCase {

    private static final String PERSISTENCE_UNIT_NAME = "TestPersistenceUnit";

    private static EntityManagerFactory entityManagerFactory;

    private static EntityManager entityManager;

    protected static DbUnitConfig dbunitConnection;

    public JUnitHsqldbTestCase() {
    }

    @BeforeClass
    public static void setupEntityManager() throws IOException {
        dbunitConnection = new DbUnitConfig();
        entityManagerFactory =
                Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME, dbunitConnection.getDbProps());
    }

    @AfterClass
    public static void closeEntityManagerAndShutdownDatabase() {
        dbunitConnection.shutdown();
    }

    @Before
    public void setUp() {
        dbunitConnection.setup(getClass(), getDataSetUrl());
        // dbunitConnection.execute("select top 15 cemployeep0_.ID as ID7_, cemployeep0_.AGE as AGE7_, cemployeep0_.NAME as NAME7_, cemployeep0_.SURNAME as SURNAME7_, cemployeep0_.VERSION1 as VERSION6_7_,         cemployeep0_.COMPANY_ID as COMPANY10_7_,         cemployeep0_.LOGIN as LOGIN7_,         cemployeep0_.SALARY as SALARY7_,         cemployeep0_.SUPERVISOR_ID as SUPERVISOR11_7_,         cemployeep0_.DTYPE as DTYPE7_  from DEVEL_PO_FILTERED.TAB_PERSON cemployeep0_     where cemployeep0_.DTYPE in ( 2, 3 )");
        // dbunitConnection.dumpDatabase("c:\\test1.sql");
        entityManager = entityManagerFactory.createEntityManager();
    }

    /**
     * Zwraca url DataSeta do zasilenia testowej bazy.
     * 
     * @return
     */
    abstract protected String getDataSetUrl();

    @After
    public void tearDown() {
        if (entityManager != null) {
            entityManager.close();
            entityManager = null;
        }
    }

    /**
     * Zwraca zainicjowanego EntityManagera do użytku w testach.
     * 
     * @return
     */
    protected EntityManager getEntityManager() {
        return entityManager;
    }
}
