package model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@MappedSuperclass
public class CCompanyPoBasic {

    private static final long serialVersionUID = -1489869236357L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
    @SequenceGenerator(name = "seq", sequenceName = "SEQ_COMPANY", allocationSize = 1)
    @Column(name = "ID")
    private Long id;

    @Column(name = "NAME")
    private String name;

    @OneToMany(targetEntity = CEmployeePo.class, mappedBy = "company")
    private Set<CEmployeePo> employees;

    @OneToOne(targetEntity = CBossPo.class, mappedBy = "ownedCompany")
    private CBossPo owner;

    public CCompanyPoBasic() {
        //
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<CEmployeePo> getEmployees() {
        return employees;
    }

    public void setEmployees(Set<CEmployeePo> employees) {
        this.employees = employees;
    }

    public void addToEmployees(CEmployeePo employees) {
        this.employees.add(employees);

    }

    public void removeFromEmployees(CEmployeePo employees) {
        this.employees.remove(employees);

    }

    public CBossPo getOwner() {
        return owner;
    }

    public void setOwner(CBossPo owner) {
        this.owner = owner;
    }

}
