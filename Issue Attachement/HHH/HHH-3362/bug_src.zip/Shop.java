package shop_product_stock;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Shop {
	private Long myId;
	private String myName;
	private Map<Product, Integer> myStock = new HashMap<Product, Integer>();
	private Set<Employee> myEmployees = new HashSet<Employee>();

	Shop() {
		super();
	}

	public Shop(String name) {
		setName(name);
	}

	public void setProductStock(Product p, int amount) {
		getStock().put(p, amount);
	}

	public int getProductStock(Product p) {
		Integer amount = getStock().get(p);
		if (null == amount) {
			amount = 0;
		}
		return amount;
	}

	private Map<Product, Integer> getStock() {
		return myStock;
	}

	private void setStock(Map<Product, Integer> stock) {
		myStock = stock;
	}

	public String getName() {
		return myName;
	}

	private void setName(String name) {
		myName = name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Shop))
			return false;
		final Shop other = (Shop) obj;
		if (getName() == null) {
			if (other.getName() != null)
				return false;
		} else if (!getName().equals(other.getName()))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return getName();
	}

	public String longDesc() {
		StringBuilder sb = new StringBuilder(this.toString());
		sb.append(getName()).append(", selling ");
		for (Map.Entry<Product, Integer> productStock : getStock().entrySet()) {
			sb.append("\n\t").append(productStock.getKey()).append(" - ").append(productStock.getValue());
		}
		return sb.toString();
	}

	public Long getId() {
		return myId;
	}

	private void setId(Long id) {
		myId = id;
	}
	public Set<Employee> getEmployees() {
	    return myEmployees;
    }
	private void setEmployees(Set<Employee> employees) {
	    myEmployees = employees;
    }
	public Shop employ(Employee employee, int salary) {
		Shop currentShop = employee.getShop();
		if (currentShop != null && currentShop != this) {
			currentShop.dismiss(employee);
		}
		myEmployees.add(employee);
		employee.setShop(this);
		employee.setSalary(salary);
		return this;
	}
	public Shop dismiss(Employee employee) {
		if (myEmployees.remove(employee)) {
			employee.setShop(null);
			employee.setSalary(0);
		}
		return this;
	}
}
