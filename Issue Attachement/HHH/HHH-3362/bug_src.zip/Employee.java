package shop_product_stock;

public class Employee {
	private Long myId;
	private String myName;
	private Shop myShop;
	private int mySalary;

	Employee() {
		super();
	}

	public Employee(String name) {
		setName(name);
	}

	public Long getId() {
		return myId;
	}

	private void setId(Long id) {
		myId = id;
	}

	public String getName() {
		return myName;
	}

	private void setName(String name) {
		myName = name;
	}

	public Shop getShop() {
		return myShop;
	}

	void setShop(Shop shop) {
		myShop = shop;
	}
	@Override
	public String toString() {
	    return getName();
	}
	public int getSalary() {
	    return mySalary;
    }
	public void setSalary(int salary) {
	    mySalary = salary;
    }
	@Override
	public boolean equals(Object obj) {
	    return ((Employee) obj).getName().equals(this.getName());
	}
	@Override
	public int hashCode() {
	    return myName.hashCode();
	}
}
