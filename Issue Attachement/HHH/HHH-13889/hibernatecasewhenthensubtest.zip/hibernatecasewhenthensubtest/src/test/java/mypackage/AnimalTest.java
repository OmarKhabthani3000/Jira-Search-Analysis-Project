package mypackage;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;

import java.util.Collections;

import org.hibernate.cfg.AvailableSettings;
import org.hibernate.query.criteria.LiteralHandlingMode;
import org.hibernate.query.internal.QueryImpl;
import org.junit.Before;
import org.junit.Test;

public class AnimalTest {

  private EntityManager entityManager;

  @Before
  public void setUp() {
    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("casewhenthennosub");
    entityManager = entityManagerFactory.createEntityManager(
        Collections.singletonMap(AvailableSettings.CRITERIA_LITERAL_HANDLING_MODE, LiteralHandlingMode.BIND));
  }

  @Test
  public void testCaseWhenOtherwise() {
    CriteriaBuilder cb = entityManager.getCriteriaBuilder();
    CriteriaQuery<Animal> criteriaQuery = cb.createQuery(Animal.class);

    Root<Animal> animalRoot = criteriaQuery.from(Animal.class);
    CriteriaBuilder.Case<String> sCase = cb.selectCase();
    Expression<String> caseSelect = sCase.when(cb.equal(animalRoot.get("name"), cb.literal("kitty")), cb.literal("Cat"))
        .otherwise("escapez'moi"); // CASE a.name = 'kitty' THEN 'Cat' ELSE <Hibernate throws up>
    criteriaQuery.multiselect(caseSelect);
    criteriaQuery
        .where(cb.equal(animalRoot.get("name"), "myFavoriteAnimal")); // myFavorite will be bound by a variable as I would expect
    TypedQuery<?> typedQuery = entityManager.createQuery(criteriaQuery);

    QueryImpl<?> query = typedQuery.unwrap(QueryImpl.class);
    System.out.println(query.getQueryString()); // will throw up due to the apostrophe in the 'otherwise' expression
  }

  @Test
  public void testCaseWhenOtherwiseParameter() {
    CriteriaBuilder cb = entityManager.getCriteriaBuilder();
    CriteriaQuery<Animal> criteriaQuery = cb.createQuery(Animal.class);

    Root<Animal> animalRoot = criteriaQuery.from(Animal.class);
    CriteriaBuilder.Case<String> sCase = cb.selectCase();
    Expression<String> caseSelect = sCase.when(cb.equal(animalRoot.get("name"), cb.literal("kitty")), cb.literal("Cat"))
        .otherwise(cb.parameter(String.class, "otherwiseParam")); // CASE a.name = 'kitty' THEN 'Cat' ELSE :otherwiseParam
    criteriaQuery.multiselect(caseSelect);
    criteriaQuery.where(cb.equal(animalRoot.get("name"), "myFavoriteAnimal"));
    TypedQuery<?> typedQuery = entityManager.createQuery(criteriaQuery).setParameter("otherwiseParam", "escapez'moi");

    QueryImpl<?> query = typedQuery.unwrap(QueryImpl.class);
    System.out.println(query.getQueryString());
  }
}