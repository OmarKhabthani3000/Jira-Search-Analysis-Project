package mypackage;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Animal {
  @Id
  public Long id;
  public String name;

  public Animal() {
  }

  public Animal(String name) {
    this.name = name;
  }
}