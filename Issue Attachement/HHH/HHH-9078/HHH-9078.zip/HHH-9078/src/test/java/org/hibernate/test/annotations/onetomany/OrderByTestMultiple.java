/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2011, Red Hat Inc. or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Inc.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.test.annotations.onetomany;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.NullPrecedence;
import org.hibernate.Session;
import org.hibernate.dialect.H2Dialect;
import org.hibernate.dialect.MySQLDialect;
import org.hibernate.dialect.Oracle8iDialect;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.persister.collection.CollectionPersister;
import org.hibernate.persister.collection.QueryableCollection;
import org.hibernate.sql.SimpleSelect;
import org.hibernate.testing.RequiresDialect;
import org.hibernate.testing.TestForIssue;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Assert;
import org.junit.Test;

/**
 * @author Emmanuel Bernard
 * @author Lukasz Antoniak (lukasz dot antoniak at gmail dot com)
 * @author Brett Meyer
 */
public class OrderByTestMultiple extends BaseCoreFunctionalTestCase {
	
	@Test
	@TestForIssue( jiraKey = "HHH-8083" )
	public void testInverseIndexCascaded() {
		final Session s = openSession();
		s.getTransaction().begin();

		Forum forum = new Forum();
		forum.setName( "forum1" );
		forum = (Forum) s.merge( forum );

		s.flush();
		s.clear();
		sessionFactory().getCache().evictEntityRegions();

		forum = (Forum) s.get( Forum.class, forum.getId() );

		Post post = new Post();
		post.setName( "post1" );
		post.setForum( forum );
		forum.getPosts().add( post );

		final User user = new User();
		user.setName( "john" );
		user.setForum( forum );
		forum.getUsers().add( user );

		forum = (Forum) s.merge( forum );

		s.flush();
		s.clear();
		sessionFactory().getCache().evictEntityRegions();

		forum = (Forum) s.get( Forum.class, forum.getId() );
		
		post = new Post();
		post.setName( "post2" );
		post.setForum( forum );
		forum.getPosts().add( post );

		s.flush();
		s.clear();
		sessionFactory().getCache().evictEntityRegions();

		forum = (Forum) s.get( Forum.class, forum.getId() );
		
		assertEquals( 2, forum.getPosts().size() );
		assertEquals( "post1", forum.getPosts().get( 0 ).getName() );
		assertEquals( "post2", forum.getPosts().get( 1 ).getName() );

	}
  
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
				Comment.class, Forum.class, Post.class, User.class,
		};
	}
}
