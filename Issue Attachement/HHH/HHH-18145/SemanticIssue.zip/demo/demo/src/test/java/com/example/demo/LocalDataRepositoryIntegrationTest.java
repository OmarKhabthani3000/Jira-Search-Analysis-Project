package com.example.demo;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.support.TransactionTemplate;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = H2Setup.class)
@Sql("classpath:cleanup.sql")
public class LocalDataRepositoryIntegrationTest {

	@Autowired
	private LocalDataRepository dataRepository;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private TransactionTemplate transactionTemplate;

	/**
	 * Should fetch data.
	 *
	 * @param dataFetcher the data fetcher
	 */
	@Test
	void testShouldFindAnotherById() {
		CompositeEntity populated = populateData();
		List<CompositeEntity> result = dataRepository
				.grouped(CompositeEntity.class, "another", populated.getAnother().getId()).collect(Collectors.toList());
		Assertions.assertThat(result).hasSize(1);
		Assertions.assertThat(result.get(0).getId()).isEqualTo(populated.getId());
	}

	@Transactional
	private CompositeEntity populateData() {
		return transactionTemplate.execute(status -> {
			CompositeEntity e = new CompositeEntity(ZonedDateTime.now().minusMinutes(1L),
					new CompositeEntity.Another());
			e.setManyToOneAnother(new CompositeEntity.Another());
			entityManager.persist(e);
			return e;
		});
	}
}
