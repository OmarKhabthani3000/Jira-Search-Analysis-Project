package com.example.demo;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.time.ZonedDateTime;

/**
 * The Class CompositeEntity.
 */
@Entity
@Table(name = "COMPOSITE_ENTITY")
public class CompositeEntity implements Identity<Long> {

    private static final long serialVersionUID = -2615877480421104618L;

    @Id
    @GeneratedValue
    private Long id;

    private ZonedDateTime timestamp;

    @OneToOne(cascade = CascadeType.ALL)
    private Another another;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "manyToOneAnother")
    private Another manyToOneAnother;

    private int someValueToCheck;

    /**
     * Instantiates a new composite entity.
     */
    public CompositeEntity() {
    }

    /**
     * Instantiates a new composite entity.
     *
     * @param timestamp
     *     the timestamp
     * @param another
     *     the another
     */
    public CompositeEntity(ZonedDateTime timestamp, Another another) {
        this.timestamp = timestamp;
        this.another = another;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public ZonedDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(ZonedDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public Another getAnother() {
        return another;
    }

    public void setAnother(Another another) {
        this.another = another;
    }

    public Another getManyToOneAnother() {
        return manyToOneAnother;
    }

    public void setManyToOneAnother(Another manyToOneAnother) {
        this.manyToOneAnother = manyToOneAnother;
    }

    public int getSomeValueToCheck() {
        return someValueToCheck;
    }

    public void setSomeValueToCheck(int someValueToCheck) {
        this.someValueToCheck = someValueToCheck;
    }

    @Override
    public String toString() {
        return "CompositeEntity{" + "id=" + id + ", timestamp=" + timestamp + ", another=" + another
                + ", manyToOneAnother=" + manyToOneAnother + ", someValueToCheck=" + someValueToCheck + '}';
    }

    /**
     * The Class Another.
     */
    @Entity
    @Table(name = "COMPOSITE_ANOTHER_ENTITY")
    public static class Another implements Identity<Long> {

        private static final long serialVersionUID = 8343131562133829890L;

        @Id
        @GeneratedValue
        private Long id;

        @OneToOne(mappedBy = "another")
        private CompositeEntity entity;

        @Override
        public Long getId() {
            return id;
        }

        @Override
        public void setId(Long id) {
            this.id = id;
        }

        public CompositeEntity getEntity() {
            return entity;
        }

        public void setEntity(CompositeEntity entity) {
            this.entity = entity;
        }
    }

}