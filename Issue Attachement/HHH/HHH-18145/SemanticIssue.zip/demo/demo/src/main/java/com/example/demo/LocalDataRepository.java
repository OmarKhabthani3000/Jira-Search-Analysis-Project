package com.example.demo;

import java.io.Serializable;
import java.util.Objects;
import java.util.function.Supplier;
import java.util.stream.Stream;

import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

public class LocalDataRepository {

	private final Supplier<EntityManager> entityManager;

	public LocalDataRepository(Supplier<EntityManager> entityManager) {
		Objects.requireNonNull(entityManager);
		this.entityManager = entityManager;
	}

	public <T extends Identity<?>> Stream<T> grouped(Class<T> clazz, String propName, Serializable groupId) {
		CriteriaBuilder cb = entityManager.get().getCriteriaBuilder();
		CriteriaQuery<T> q = cb.createQuery(clazz);

		Root<T> root = q.from(clazz);
		CriteriaQuery<T> query;
		Predicate predicate = (groupId == null) ? cb.isNull(root.get(propName)) : cb.equal(root.get(propName), groupId);
		query = q.select(root).where(predicate);
		return entityManager.get().createQuery(query).getResultList().stream();
	}

}