package com.example.demo;

import java.io.Serializable;

public interface Identity<I extends Serializable> extends Serializable {

    /**
     * Gets the id.
     *
     * @return the id
     */
    I getId();

    /**
     * Sets the id.
     *
     * @param id
     *     the new id
     */
    void setId(I id);

}