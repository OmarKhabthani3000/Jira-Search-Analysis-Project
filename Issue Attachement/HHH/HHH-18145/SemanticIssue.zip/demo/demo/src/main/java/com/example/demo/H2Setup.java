package com.example.demo;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.dialect.H2Dialect;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.support.TransactionTemplate;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.PersistenceContext;

/**
 * The Class H2Setup.
 */
@SpringBootConfiguration
@EnableTransactionManagement
public class H2Setup {

	@PersistenceContext
	private EntityManager entityManager;

	/**
	 * Data source.
	 *
	 * @return the data source
	 */
	@Bean
	public DataSource dataSource() {
		return new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.H2).build();
	}

	/**
	 * Entity manager factory.
	 *
	 * @param dataSource the data source
	 *
	 * @return the factory bean
	 */
	@Bean
	public FactoryBean<EntityManagerFactory> entityManagerFactory(DataSource dataSource) {
		LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
		factory.setDataSource(dataSource);
		factory.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
		factory.setPackagesToScan(H2Setup.class.getPackage().getName());

		Properties jpaProps = new Properties();
		jpaProps.setProperty("hibernate.dialect", H2Dialect.class.getName());
		jpaProps.setProperty("hibernate.hbm2ddl.auto", "create");
		jpaProps.setProperty("hibernate.show_sql", "true");
		factory.setJpaProperties(jpaProps);
		return factory;
	}

	/**
	 * Transaction manager.
	 *
	 * @param factory the factory
	 *
	 * @return the platform transaction manager
	 */
	@Bean
	public PlatformTransactionManager transactionManager(EntityManagerFactory factory) {
		return new JpaTransactionManager(factory);
	}

	/**
	 * Data repository.
	 *
	 * @param transactionHandler the transaction handler
	 *
	 * @return the data repository
	 */
	@Bean
	public LocalDataRepository dataRepository() {
		return new LocalDataRepository(() -> entityManager);
	}

	@Bean
	public TransactionTemplate transactionTemplate(PlatformTransactionManager transactionManager) {
		return new TransactionTemplate(transactionManager);
	}

}
