package org.hibernate.envers.test.integration.hhh5845.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.envers.Audited;

@Entity
public class RefIngEntity {
	
	public RefIngEntity() {
		// TODO Auto-generated constructor stub
	}

	@Id
	@GeneratedValue
	private Integer id;

	@Audited
	private String data;

	@OneToOne
	@Cascade(value = CascadeType.ALL)
	@Audited
	private RefEdEntity reference;

	public RefIngEntity(String data, RefEdEntity reference) {
		this.data = data;
		this.reference = reference;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public RefEdEntity getOtherClass() {
		return reference;
	}

	public void setOtherClass(RefEdEntity otherClass) {
		this.reference = otherClass;
	}

}
