package org.hibernate.envers.test.integration.hhh5845;

import static org.testng.Assert.assertEquals;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Hibernate;
import org.hibernate.ejb.Ejb3Configuration;
import org.hibernate.envers.RevisionType;
import org.hibernate.envers.query.AuditEntity;
import org.hibernate.envers.query.AuditQuery;
import org.hibernate.envers.test.AbstractEntityTest;
import org.hibernate.envers.test.integration.hhh5845.entities.RefEdEntity;
import org.hibernate.envers.test.integration.hhh5845.entities.RefIngEntity;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestCase extends AbstractEntityTest {

	Integer id;

	@Override
	public void configure(Ejb3Configuration cfg) {
		cfg.addAnnotatedClass(RefEdEntity.class);
		cfg.addAnnotatedClass(RefIngEntity.class);

		cfg.setProperty("org.hibernate.envers.store_data_at_delete", "true");
	}

	@BeforeClass(dependsOnMethods = "init")
	public void initData() {
		EntityManager em = getEntityManager();

		RefEdEntity refEdEntity = new RefEdEntity("DemoData");
		RefIngEntity refIngEntity = new RefIngEntity("ExampleData", refEdEntity);

		em.getTransaction().begin();
		em.persist(refIngEntity);

		id = refIngEntity.getId();

		em.getTransaction().commit();

		em.getTransaction().begin();
		refIngEntity = em.find(RefIngEntity.class, id);
		em.remove(refIngEntity);
		em.getTransaction().commit();
	}

	@SuppressWarnings("rawtypes")
	@Test
	public void testFindDeletedReferences() {
		AuditQuery query = getAuditReader().createQuery().forRevisionsOfEntity(RefIngEntity.class, false, true).add(AuditEntity.revisionType().eq(RevisionType.DEL));
		List queryResult = (List) query.getResultList();

		Object[] objArray = (Object[]) queryResult.get(0);
		RefIngEntity refIngEntity = (RefIngEntity) objArray[0];
		assertEquals(refIngEntity.getData(), "ExampleData");
		
		Hibernate.initialize(refIngEntity.getOtherClass());
		assertEquals(refIngEntity.getOtherClass().getData(), "DemoData");
	}

}
