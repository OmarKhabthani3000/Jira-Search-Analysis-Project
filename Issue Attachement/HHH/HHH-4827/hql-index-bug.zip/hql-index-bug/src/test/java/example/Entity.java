package example;

import java.util.HashMap;
import java.util.Map;


public class Entity {
    private int id;
    private Map<String, String> map = new HashMap<String, String>();


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Map<String, String> getMap() {
        return map;
    }

    public void setMap(Map<String, String> map) {
        this.map = map;
    }
}
