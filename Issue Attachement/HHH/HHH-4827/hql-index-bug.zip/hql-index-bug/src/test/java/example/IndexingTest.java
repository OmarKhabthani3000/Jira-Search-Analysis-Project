package example;

import org.hibernate.SessionFactory;

import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

import org.hibernate.classic.Session;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class IndexingTest {
    private SessionFactory sf;
    private Session s;

    public IndexingTest() {

        try {
            Configuration cfg = new Configuration();
            cfg.configure();
            cfg.setProperty(Environment.HBM2DDL_AUTO, "update");
            cfg.setProperty(Environment.DRIVER, "org.hsqldb.jdbcDriver");
            cfg.setProperty(Environment.URL, "jdbc:hsqldb:mem:hsqldb");
            cfg.setProperty(Environment.USER, "sa");
            cfg.setProperty(Environment.PASS, "");

            sf = cfg.buildSessionFactory();
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    @Before public void setUp() {
        s = sf.openSession();
    }

    @Test public void testIndexHQL() throws Exception {
        Session s = sf.openSession();
        s.createQuery("from Entity e where ( map['aaa'] = 'foo' or map['bbb'] = 'bar')").list();
    }

    @After public void tearDown() {
        s.close();
    }
}
