package org.hibernate.bugs;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

public class UKManyToOneTest extends BaseCoreFunctionalTestCase {

	@Override
	protected Class<?>[] getAnnotatedClasses() {
		return new Class[]{
				Parent.class, 
				Child.class
				};
	}
	
	@Override
	protected void configure(Configuration configuration) {
		super.configure(configuration);
		configuration.setProperty(AvailableSettings.GENERATE_STATISTICS, "true");
	}
	
	@Test
	public void test1(){
		
		//Setup
		Session s = sessionFactory().openSession();
		Transaction tx = s.beginTransaction();
		Parent parent = new Parent(1, 1, 1, "description");
		s.persist(parent);
		s.persist(new Child(1, parent));
		s.persist(new Child(2, parent));
		tx.commit();
		s.close();
		
		sessionFactory().getStatistics().clear();
		
		s = sessionFactory().openSession();
		tx = s.beginTransaction();
		s.byId(Child.class).load(1);
		s.byId(Child.class).load(2);
		tx.commit();
		s.close();
		
		assertThat(sessionFactory().getStatistics().getPrepareStatementCount(), is(3L));
		
	}
}
