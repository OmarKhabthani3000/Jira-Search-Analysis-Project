package org.hibernate.bugs;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

@Entity
public class Child implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	private Integer id;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="prop_code", referencedColumnName="code"),
		@JoinColumn(name="prop_item", referencedColumnName="item")
	})
	private Parent property;

	protected Child() {}
	
	public Child(Integer id, Parent property) {
		this.id = id;
		this.property = property;
	}

	public Integer getId() {
		return id;
	}

	public Parent getProperty() {
		return property;
	}
	
}
