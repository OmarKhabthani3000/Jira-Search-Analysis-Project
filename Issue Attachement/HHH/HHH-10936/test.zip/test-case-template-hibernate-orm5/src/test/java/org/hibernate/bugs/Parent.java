package org.hibernate.bugs;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Parent implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	private Integer id;
	private Integer code;
	private Integer item;
	private String description;

	protected Parent(){}
	
	public Parent(Integer id, Integer code, Integer item, String description) {
		this.id = id;
		this.code = code;
		this.item = item;
		this.description = description;
	}

	public Integer getId() {
		return id;
	}

	public Integer getCode() {
		return code;
	}

	public Integer getItem() {
		return item;
	}

	public String getDescription() {
		return description;
	}
	
	
	
}
