package org.hibernate.bugs.entity;

public enum FruitColor
{
    RED,
    GREEN,
    ORANGE,
    YELLOW
}
