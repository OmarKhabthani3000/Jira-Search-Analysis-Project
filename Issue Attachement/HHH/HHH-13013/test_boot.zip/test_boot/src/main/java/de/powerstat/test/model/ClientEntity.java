package de.powerstat.test.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Version;

import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;


@Entity
@Table(name = "Client")
public class ClientEntity implements Serializable
 {
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id;

  @Version
  @Column(nullable = false)
  private long version;

  @NonNull
  @Column(nullable = false)
  private Timestamp created;

  @NonNull
  @Column(nullable = false, length = 255)
  private String createdby;

  @NonNull
  @Column(nullable = false)
  private Timestamp lastmodified;

  @NonNull
  @Column(nullable = false, length = 255)
  private String modifiedby;

  @NonNull
  @Column(nullable = false, length = 255, unique = true)
  private String name;

  @Column(name = "accountPolicies_id", nullable = false, unique = true)
  private long accountPoliciesId;

  @Column(name = "accounting_id", nullable = false, unique = true)
  private long accountingId;

  @Column(name = "address_id", nullable = false, unique = true)
  private long addressId;

  @Column(name = "firstLevelSupport_id", nullable = false, unique = true)
  private long firstLevelSupportId;

  @Nullable
  @Column(name = "theme_id", nullable = true)
  private Long themeId;

  @Nullable
  @Column(nullable = true)
  private Timestamp expireDate;

  @Nullable
  @Column(nullable = true)
  private Long maxDocVolume;

  @Nullable
  @Column(nullable = true)
  private Long maxSessions;

  @Nullable
  @Column(nullable = true, length = 255)
  private String urlLoginKey;

  @Nullable
  @Column(nullable = true)
  private Boolean logVersionHistory;

  @Nullable
  @Column(nullable = true, length = 255)
  private String applicationName;

  @Nullable
  @Column(nullable = true, length = 255)
  private String licenceKey;

  @Nullable
  @Column(nullable = true)
  private Boolean locked;

  @Nullable
  @Column(name = "profile_id", nullable = true)
  private Long profileId;

  @OneToMany(mappedBy = "client", fetch = FetchType.LAZY, orphanRemoval = true, cascade = {CascadeType.REMOVE, CascadeType.PERSIST})
  @OrderBy("name ASC")
  private List<UserEntity> users;


  protected ClientEntity()
   {
    super();
   }


  public ClientEntity(@NonNull final String name, final long accountPoliciesId, final long accountingId, final long addressId, final long firstLevelSupportId, @NonNull final String createdBy)
   {
    super();
    this.version = 1;
    this.name = name;
    this.accountPoliciesId = accountPoliciesId;
    this.accountingId = accountingId;
    this.addressId = addressId;
    this.firstLevelSupportId = firstLevelSupportId;
    this.createdby = createdBy;
    this.modifiedby = createdBy;
    this.created = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
    this.lastmodified = this.created;
   }


  public @NonNull Timestamp getLastmodified()
   {
    return this.lastmodified;
   }


  public void setLastmodified(@NonNull final Timestamp lastmodified)
   {
    this.lastmodified = lastmodified;
   }


  public @NonNull String getModifiedby()
   {
    return this.modifiedby;
   }


  public void setModifiedby(@NonNull final String modifiedby)
   {
    this.modifiedby = modifiedby;
   }


  public long getId()
   {
    return this.id;
   }


  public long getVersion()
   {
    return this.version;
   }


  public @NonNull Timestamp getCreated()
   {
    return this.created;
   }


  public @NonNull String getCreatedby()
   {
    return this.createdby;
   }


  public @NonNull String getName()
   {
    return this.name;
   }


  public @Nullable Long getThemeId()
   {
    return this.themeId;
   }


  public void setTheme(@Nullable final Long theme)
   {
    this.themeId = theme;
   }


  public @Nullable Timestamp getExpireDate()
   {
    return this.expireDate;
   }


  public void setExpireDate(@Nullable final Timestamp expireDate)
   {
    this.expireDate = expireDate;
   }


  public @Nullable Long getMaxDocVolume()
   {
    return this.maxDocVolume;
   }


  public void setMaxDocVolume(@Nullable final Long maxDocVolume)
   {
    this.maxDocVolume = maxDocVolume;
   }


  public @Nullable Long getMaxSessions()
   {
    return this.maxSessions;
   }


  public void setMaxSessions(@Nullable final Long maxSessions)
   {
    this.maxSessions = maxSessions;
   }


  public @Nullable String getUrlLoginKey()
   {
    return this.urlLoginKey;
   }


  public void setUrlLoginKey(@Nullable final String urlLoginKey)
   {
    this.urlLoginKey = urlLoginKey;
   }


  public @Nullable Boolean isLogVersionHistory()
   {
    return this.logVersionHistory;
   }


  public void setLogVersionHistory(@Nullable final Boolean logVersionHistory)
   {
    this.logVersionHistory = logVersionHistory;
   }


  public @Nullable String getApplicationName()
   {
    return this.applicationName;
   }


  public void setApplicationName(@Nullable final String applicationName)
   {
    this.applicationName = applicationName;
   }


  public @Nullable String getLicenceKey()
   {
    return this.licenceKey;
   }


  public void setLicenceKey(@Nullable final String licenceKey)
   {
    this.licenceKey = licenceKey;
   }


  public @Nullable Boolean isLocked()
   {
    return this.locked;
   }


  public void setLocked(@Nullable final Boolean locked)
   {
    this.locked = locked;
   }


  public @Nullable Long getProfile()
   {
    return this.profileId;
   }


  public void setProfile(@Nullable final Long profile)
   {
    this.profileId = profile;
   }


  public long getAccountPolicies()
   {
    return this.accountPoliciesId;
   }


  public long getAccounting()
   {
    return this.accountingId;
   }


  public long getAddress()
   {
    return this.addressId;
   }


  public long getFirstLevelSupport()
   {
    return this.firstLevelSupportId;
   }

 }
