package de.powerstat.test.model;


import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;


@Entity
@Table(name = "User_", uniqueConstraints = @UniqueConstraint(columnNames={"client_id", "name"}))
public class UserEntity implements Serializable
 {
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id;

  @Version
  @Column(nullable = false)
  private long version;

  @NonNull
  @Column(nullable = false)
  private Timestamp created;

  @NonNull
  @Column(nullable = false, length = 255)
  private String createdby;

  @NonNull
  @Column(nullable = false)
  private Timestamp lastmodified;

  @NonNull
  @Column(nullable = false, length = 255)
  private String modifiedby;

  @NonNull
  @Column(nullable = false, length = 255)
  private String name;

  @Nullable
  @Column(nullable = true)
  private Timestamp lastlogindate;

  @NonNull
  @ManyToOne
  @JoinColumn(name = "client_id", nullable = false, table = "Client")
  private ClientEntity client;

  @Column(name = "credentials_id", nullable = false, unique = true)
  private long credentialsId;

  @Column(name = "functionrights_id", nullable = false, unique = true)
  private long functionRightsId;

  @Nullable
  @Column(name = "contactdata_id", nullable = true)
  private Long contactDataId;

  @Nullable
  @Column(name = "userprofile_id", nullable = true)
  private Long userProfileId;

  @Nullable
  @Column(nullable = true)
  private Date expiredate;


  protected UserEntity()
   {
    super();
   }


  public UserEntity(@NonNull final String name, @NonNull final ClientEntity client, final long credentialsId, final long functionRightsId, @NonNull final String createdBy)
   {
    super();
    this.name = name;
    this.client = client;
    this.credentialsId = credentialsId;
    this.functionRightsId = functionRightsId;
    this.version = 1;
    this.createdby = createdBy;
    this.modifiedby = createdBy;
    this.created = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
    this.lastmodified = this.created;
   }


  public @NonNull Timestamp getLastmodified()
   {
    return this.lastmodified;
   }


  public void setLastmodified(@NonNull final Timestamp lastModified)
   {
    this.lastmodified = lastModified;
   }


  public @NonNull String getModifiedby()
   {
    return this.modifiedby;
   }


  public void setModifiedby(@NonNull final String modifiedBy)
   {
    this.modifiedby = modifiedBy;
   }


  public long getId()
   {
    return this.id;
   }


  public long getVersion()
   {
    return this.version;
   }


  public @NonNull Timestamp getCreated()
   {
    return this.created;
   }


  public @NonNull String getCreatedby()
   {
    return this.createdby;
   }


  public @NonNull String getName()
   {
    return this.name;
   }


  public @Nullable Timestamp getLastlogindate()
   {
    return this.lastlogindate;
   }


  public void setLastlogindate(@NonNull final Timestamp lastLoginDate)
   {
    this.lastlogindate = lastLoginDate;
   }


  public @NonNull ClientEntity getClient()
   {
    return this.client;
   }


  public long getFunctionRightsId()
   {
    return this.functionRightsId;
   }


  public void setFunctionRightsId(final long functionRights)
   {
    this.functionRightsId = functionRights;
   }


  public @Nullable Long getContactDataId()
   {
    return this.contactDataId;
   }


  public void setContactDataId(@Nullable final Long contactData)
   {
    this.contactDataId = contactData;
   }


  public @Nullable Date getExpiredate()
   {
    return this.expiredate;
   }


  public void setExpiredate(@Nullable final Date exprireDate)
   {
    this.expiredate = exprireDate;
   }


  public long getCredentials()
   {
    return this.credentialsId;
   }


  public @Nullable Long getUserProfile()
   {
    return this.userProfileId;
   }

 }
