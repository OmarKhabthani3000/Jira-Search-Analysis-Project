package de.powerstat.test.repositories;


import org.springframework.data.jpa.repository.JpaRepository;

import de.powerstat.test.model.UserEntity;



public interface IUserJpaRepository extends JpaRepository<UserEntity, Integer>
 {
 }
