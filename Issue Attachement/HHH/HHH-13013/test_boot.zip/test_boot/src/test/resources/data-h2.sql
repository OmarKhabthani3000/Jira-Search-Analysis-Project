INSERT INTO User_ (id, version, created, createdBy, lastModified, modifiedBy, lastLoginDate, name, client_id, credentials_id, functionRights_id, contactData_id, userProfile_id, expireDate) VALUES
  (1, 1232, '2009-04-15 13:55:00.393', 'n/a', '2018-07-01 13:03:42.410', 'test/superadmin', '2018-04-17 13:43:06.000', 'sa', 1, 1, 1, 62, NULL, NULL),
  (4, 346, '2009-04-15 19:22:27.043', 'test/sa', '2010-05-13 20:31:29.303', 'anonymous', '2010-05-13 20:31:29.283', 'usr-all', 2, 4, 4, NULL, NULL, NULL),
  (5, 2124, '2009-04-26 17:53:00.907', 'test/sa', '2018-08-06 13:25:46.047', 'anonymous', '2018-08-06 13:25:46.017', 'admin', 1, 5, 5, NULL, NULL, NULL);
