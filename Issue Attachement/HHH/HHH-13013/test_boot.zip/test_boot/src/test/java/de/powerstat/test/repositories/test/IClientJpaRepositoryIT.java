package de.powerstat.test.repositories.test;


import static org.junit.Assert.assertTrue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import org.junit.Test;
import org.junit.runner.RunWith;

import de.powerstat.test.repositories.IClientJpaRepository;


@RunWith(SpringRunner.class)
@DataJpaTest
public class IClientJpaRepositoryIT
 {
  @Autowired
  private IClientJpaRepository clientRepository;


  @Test
  public void findAll()
   {
    assertTrue("No users found!", this.clientRepository.findAll().size() > 0); //$NON-NLS-1$
   }

 }
