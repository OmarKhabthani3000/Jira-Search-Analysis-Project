package com.titan.clients;

public class ReservationSummary {
   public String cruise;
   public int numReservations;
   public double cashflow;

   public ReservationSummary(String c, int num, double cash) {
     this.cruise = c;
     this.numReservations = num;
     this.cashflow = cash;
   }
}
