package com.titan.clients;

import com.titan.domain.*;
import java.util.*;
import javax.persistence.*;

public class Bulk
{
   public static void main(String[] args) throws Exception 
   {
      EntityManagerFactory factory =
         Persistence.createEntityManagerFactory("titan", new HashMap());
      EntityManager entityManager = factory.createEntityManager();
      entityManager.getTransaction().begin();
      try 
      {
         System.out.println("Initialize DB");
         InitializeDB.initialize(entityManager);
         System.out.println();
         System.out.println();
         entityManager.flush();
         entityManager.clear();

         bulkUpdate(entityManager);
         /*
         entityManager.clear();
         bulkDelete(entityManager);
         */
      } 
      finally 
      {
         entityManager.getTransaction().commit();
         entityManager.close();
         factory.close();
      }
   }

   public static void bulkUpdate(EntityManager manager)
   {
      System.out.println("Bulk Update");
      System.out.println("--------------------------------");
      System.out.println("UPDATE Reservation res set res.amountPaid = (res.amountPaid + 10)");
      System.out.println("WHERE EXISTS (");
      System.out.println("   SELECT c FROM res.customers c WHERE c.firstName = 'Bill' AND c.lastName='Burke'");
      System.out.println(")");


      System.out.println("Show all amount paid for all of Bill's reservations before update:");
      Customer bill = (Customer)manager.createQuery("FROM Customer c " +
                                                    "where c.firstName = 'Bill' and " +
                                                    "c.lastName='Burke'").getSingleResult();
      Collection<Reservation> reservations = bill.getReservations();
      for (Reservation res : reservations)
      {
         System.out.println("amountPaid: " + res.getAmountPaid());
      }

      Query query;
      query = manager.createQuery("UPDATE Reservation res " +
                                  "SET res.amountPaid = (res.amountPaid + 10) " +
                                  "WHERE EXISTS (" +
                                  "SELECT c FROM res.customers c " +
                                  "where c.firstName = 'Bill' and " +
                                  "c.lastName='Burke')");
      query.executeUpdate();
      manager.flush();
      System.out.println("Show all amount paid for all of Bill's reservations after update:");
      /*
      bill = (Customer)manager.createQuery("FROM Customer c " +
                                           "where c.firstName = 'Bill' and " +
                                           "c.lastName='Burke'").getSingleResult();
      */
      manager.refresh(bill);
      reservations = bill.getReservations();
      for (Reservation res : reservations)
      {
         System.out.println("amountPaid: " + res.getAmountPaid());
      }
   }
}
      
