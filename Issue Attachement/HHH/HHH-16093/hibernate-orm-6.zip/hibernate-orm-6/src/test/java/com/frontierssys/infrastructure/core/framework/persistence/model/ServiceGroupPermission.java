package com.frontierssys.infrastructure.core.framework.persistence.model;


import jakarta.persistence.Basic;			// NOPMD
import jakarta.persistence.Column;			// NOPMD
import jakarta.persistence.Id;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumns;		// NOPMD
import jakarta.persistence.Table;			// NOPMD
import jakarta.persistence.ManyToOne;		// NOPMD
import jakarta.persistence.JoinColumn;		// NOPMD
import jakarta.persistence.CascadeType;		// NOPMD
import jakarta.persistence.TemporalType;		// NOPMD
import jakarta.persistence.Temporal;			// NOPMD
import jakarta.persistence.UniqueConstraint;	// NOPMD
import jakarta.persistence.Cacheable;		// NOPMD
import jakarta.persistence.FetchType;		// NOPMD
import jakarta.persistence.Version;			// NOPMD

import java.util.ArrayList;
import java.util.Calendar;	//NOPMD
import java.util.List;	//NOPMD
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.hibernate.annotations.CacheConcurrencyStrategy;	// NOPMD
import org.hibernate.annotations.Cache;		// NOPMD

/**
 *
 * @author Tom Leung, Frontiers System Ltd..
 *
 */
@Cacheable(true)
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
@Table(name="PM_SERVICE_GRP_PERMISSION", uniqueConstraints={	// NOPMD
		@UniqueConstraint(name="IDX_SERVICE_GRP_PERMISSION", columnNames={"COMPANY_CODE", "SERVICE_GROUP_ID_FK", "PERMISSION_ID_FK"})	// NOPMD
	})
@Entity
public class ServiceGroupPermission {

	//
	// Default Values
	//

	private static Map<String, Object> constantMap = new ConcurrentHashMap<String, Object>();		// NOPMD

	private static List<List<String>> uniqueObjectKeyList = new ArrayList<List<String>>();			// NOPMD

	//
	// Static variables
	//

	static {				// NOPMD
	}

	//
	// Attributes
	//

	/**
	 *
	 */
	@Id			// NOPMD
	@Column(name="SERVICE_GRP_PERMISSION_ID", nullable=false, length=50, columnDefinition="NVARCHAR(50)" )			// NOPMD
	private String  primaryKey;	// NOPMD

	/**
	 *
	 */
	@ManyToOne(targetEntity=ServiceGroup.class, optional=false, fetch=FetchType.LAZY, cascade=CascadeType.REFRESH)			// NOPMD
	@JoinColumns( {			// NOPMD
		@JoinColumn(name = "SERVICE_GROUP_ID_FK", referencedColumnName = "SERVICE_GROUP_ID", nullable=false),			// NOPMD
	} )	
	private ServiceGroup serviceGroup;	// NOPMD

	/**
	 *
	 */
	@ManyToOne(targetEntity=Permission.class, optional=false, fetch=FetchType.LAZY, cascade=CascadeType.REFRESH)			// NOPMD
	@JoinColumns( {			// NOPMD
		@JoinColumn(name = "PERMISSION_ID_FK", referencedColumnName = "PERMISSION_ID", nullable=false),			// NOPMD
	} )
	private Permission permission;	// NOPMD

	/* Common attributes */

	/**
	 *
	 */
	@Basic
	@Column(name="CRE_DATET", nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Calendar creationDateTime;								// NOPMD

	/**
	 *
	 */
	@Basic
	@Column(name="CRE_BY", nullable=false, length=150, columnDefinition="NVARCHAR(150)")
	private String createdBy;										// NOPMD

	/**
	 *
	 */
	@Basic
	@Column(name="UPDATE_DATET", nullable=true)
	@Temporal(TemporalType.TIMESTAMP)
	private Calendar modifiedDateTime;								// NOPMD

	/**
	 *
	 */
	@Basic
	@Column(name="UPDATE_BY", nullable=true, length=150, columnDefinition="NVARCHAR(150)")
	private String modifiedBy;										// NOPMD

	/**
	 *
	 */
	@Column(name="ROW_VERSION")
	@Version
	private int version;	// NOPMD, it is no need to set set method for VERSION method

	/**
	 *
	 */
	@Column(name="SYNC_DATET", nullable=true)
	@Temporal(TemporalType.TIMESTAMP)
	private Calendar syncDateTime;									// NOPMD

	/**
	 *
	 */
	@Column(name="SYNC_ID_FK", nullable=true, length=150, columnDefinition="NVARCHAR(150)")
	private String syncId;

	/**
	 *
	 */
	@Column(name="COMPANY_CODE", nullable=false, length=150, columnDefinition="NVARCHAR(150)")	// should be nullable=true
	private String companyCode;

	//
	// Static methods
	//
	public static List<List<String>> findUniqueObjectKeyList() {

		return uniqueObjectKeyList;
	}

	//
	// Constructors
	//

	/**
	 *
	 */
	public ServiceGroupPermission() {
	
		super();
	}

	//
	// Getter/Setter Methods
	//

	/**
	 *
	 * @return
	 */
	public String getPrimaryKey() {
	
		return this.primaryKey;
	}

	/**
	 *
	 * @param primaryKey
	 */
	public void setPrimaryKey(final String primaryKey) {
 	
		this.primaryKey = primaryKey;
	}

	/**
	 *
	 * @return
	 */
	public ServiceGroup getServiceGroup() {
	
		return this.serviceGroup;
	}

	/**
	 *
	 * @param serviceGroup
	 */
	public void setServiceGroup(final ServiceGroup serviceGroup) {
 	
		this.serviceGroup = serviceGroup;
	}

	/**
	 *
	 * @return
	 */
	public Permission getPermission() {
	
		return this.permission;
	}

	/**
	 *
	 * @param permission
	 */
	public void setPermission(final Permission permission) {
 	
		this.permission = permission;
	}

	/* Common Getter/Setter Methods */

	/**
	 *
	 * @return
	 */
	public Calendar getSyncDateTime() {

		return this.syncDateTime;
	}

	/**
	 *
	 * @param syncDateTime
	 */
	public void setSyncDateTime(final Calendar syncDateTime) {

		this.syncDateTime = (Calendar) syncDateTime;
	}

	/**
	 *
	 * @return
	 */
	public String getSyncId() {

		return this.syncId;
	}

	/**
	 *
	* @param syncId
	 */
	public void setSyncId(final String syncId) {

		this.syncId = syncId;
	}

	/**
	 *
	 * @return
	 */
	public String getCompanyCode() {

		return this.companyCode;
	}

	/**
	 *
	 * @param companyCode
	 */
	public void setCompanyCode(final String companyCode) {

		this.companyCode = companyCode;
	}

	/**
	 *
	 * @return
	 */
	public Calendar getCreationDateTime() {

		return creationDateTime;
	}

	/**
	 *
	 * @param creationDateTime
	 */
	public void setCreationDateTime(final Calendar creationDateTime) {

		this.creationDateTime = (Calendar) creationDateTime;
	}

	/**
	 *
	 * @return
	 */
	public String getCreatedBy() {

		return this.createdBy;
	}

	/**
	 *
	 * @param createdBy
	 */
	public void setCreatedBy(final String createdBy) {

		this.createdBy = createdBy;
	}

	/**
	 *
	 * @return
	 */
	public Calendar getModifiedDateTime() {

		return this.modifiedDateTime;
	}

	/**
	 *
	 * @param modifiedDateTime
	 */
	public void setModifiedDateTime(final Calendar modifiedDateTime) {

		this.modifiedDateTime = (Calendar) modifiedDateTime;
	}

	/**
	 *
	 * @return
	 */
	public String getModifiedBy() {

		return this.modifiedBy;
	}

	/**
	 *
	 * @param modifiedBy
	 */
	public void setModifiedBy(final String modifiedBy) {

		this.modifiedBy = modifiedBy;
	}

	/**
	 *
	 * @return
	 */
	public int getVersion() {

		return this.version;
	}

	//
	// Methods
	//

	/**
	 *
	 * @return
	 */
	public static Map<String, Object> getConstantMap() {

		return constantMap;
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
	
		return primaryKey.hashCode();
	}
	
	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(final Object obj) {
	
		if (obj instanceof ServiceGroupPermission) {
			if (this.hashCode() == ((ServiceGroupPermission) obj).hashCode() && this.getPrimaryKey().equals(((ServiceGroupPermission) obj).getPrimaryKey())) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}


}