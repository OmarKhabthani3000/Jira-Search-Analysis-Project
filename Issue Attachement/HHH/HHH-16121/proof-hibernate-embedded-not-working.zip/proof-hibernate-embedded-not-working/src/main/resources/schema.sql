CREATE TABLE productCategory (
     parent_id INTEGER UNSIGNED,
     id INTEGER UNSIGNED NOT NULL,
     name VARCHAR(255) NOT NULL,
     picture_name VARCHAR(64),
     picture_width SMALLINT UNSIGNED,
     picture_height SMALLINT UNSIGNED,
     PRIMARY KEY (id),
     FOREIGN KEY (parent_id) REFERENCES productCategory(id) ON UPDATE CASCADE
);

CREATE TABLE product (
    category_id INTEGER UNSIGNED NOT NULL,
    id INTEGER UNSIGNED NOT NULL,
    name VARCHAR(255) NOT NULL,
    picture_name VARCHAR(64),
    picture_width SMALLINT UNSIGNED,
    picture_height SMALLINT UNSIGNED,
    PRIMARY KEY (id),
    FOREIGN KEY (category_id) REFERENCES productCategory(id) ON UPDATE CASCADE
);

INSERT INTO productCategory(parent_id, id, name)
VALUES
    (null, 1, 'Cat 1'),
    (null, 2, 'Cat 2'),

    (1, 11, 'Cat 1-1'),
    (1, 12, 'Cat 1-2'),
    (2, 21, 'Cat 2-1'),
    (2, 22, 'Cat 2-2');

INSERT INTO product(category_id, id, name)
VALUES
    (11, 122, 'Product 1-1-1'),
    (21, 123, 'Product 2-1-1');
