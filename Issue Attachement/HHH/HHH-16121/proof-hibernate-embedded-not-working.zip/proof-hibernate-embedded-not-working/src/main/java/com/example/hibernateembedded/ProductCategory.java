package com.example.hibernateembedded;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "productCategory")
public class ProductCategory {

    @ManyToOne(fetch = FetchType.LAZY)
    private ProductCategory parent;

    @Id
    private Long id;

    private String name;

    @Embedded
    private Picture picture;

    @OneToMany(mappedBy = "parent")
    private List<ProductCategory> children;

    public ProductCategory getParent() {
        return parent;
    }

    public void setParent(ProductCategory parent) {
        this.parent = parent;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Picture getPicture() {
        return picture;
    }

    public void setPicture(Picture picture) {
        this.picture = picture;
    }

    public List<ProductCategory> getChildren() {
        return children;
    }

    public void setChildren(List<ProductCategory> children) {
        this.children = children;
    }
}
