package com.example.hibernateembedded;

import org.hibernate.Hibernate;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.model.naming.ImplicitNamingStrategyComponentPathImpl;
import org.hibernate.boot.model.naming.PhysicalNamingStrategyStandardImpl;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.jpa.SpecHints;

public class Main {

    public static Product fetch(SessionFactory sessionFactory, long id, String graph) {
        try (var session = sessionFactory.openSession()) {
            return session.createQuery("SELECT e FROM Product e WHERE e.id = :id", Product.class)
                    .setParameter("id", id)
                    .setHint(SpecHints.HINT_SPEC_FETCH_GRAPH, sessionFactory.createEntityManager().getEntityGraph(graph))
//                    .setHint(SpecHints.HINT_SPEC_LOAD_GRAPH, sessionFactory.createEntityManager().getEntityGraph(graph))
                    .getSingleResult();
        }
    }

    public static void main(String[] args) {
        var standardRegistry = new StandardServiceRegistryBuilder().build();
        var sources = new MetadataSources(standardRegistry);
        sources.addAnnotatedClass(Picture.class);
        sources.addAnnotatedClass(Product.class);
        sources.addAnnotatedClass(ProductCategory.class);

        var configuration = new Configuration(sources);
        configuration.setProperty("hibernate.connection.url", "jdbc:mariadb://localhost/proof_hibernate_embedding");
        configuration.setProperty("hibernate.connection.username", "root");
        configuration.setProperty("hibernate.connection.password", "MySQ7Admin");
        configuration.setProperty("hibernate.show_sql", "true");
        configuration.setProperty("hibernate.format_sql", "true");
        configuration.setPhysicalNamingStrategy(new PhysicalNamingStrategyStandardImpl());
        configuration.setImplicitNamingStrategy(new ImplicitNamingStrategyComponentPathImpl());

        try(var sessionFactory = configuration.buildSessionFactory()) {
            var result = fetch(sessionFactory, 122L, "Product.withAll");

            var pictureInit = Hibernate.isPropertyInitialized(result, "picture");
            if (pictureInit) {
                var picture = result.getPicture();
                pictureInit = Hibernate.isInitialized(picture);
                if (pictureInit) {
                    System.out.println("Picture initialized");
                }
            }
        }
    }
}
