package yc.hibprob;

import java.util.Collection;

public class Customer {

	private Long id;
	private Long linkId;
	private String name;
	private Collection<Address> addresses;

	public Customer() {
		linkId = Long.valueOf(-1);  // fix #1
	}

	public Collection<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(Collection<Address> addresses) {
		this.addresses = addresses;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getLinkId() {
		return linkId;
	}

	public void setLinkId(Long linkId) {
		this.linkId = linkId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
