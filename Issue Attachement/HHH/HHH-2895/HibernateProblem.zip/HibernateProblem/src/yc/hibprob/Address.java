package yc.hibprob;

public class Address {
	private Long id;
	private Long customerLinkId;
	private String name;
	private Customer customer;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getCustomerLinkId() {
		return customerLinkId;
	}

	public void setCustomerLinkId(Long customerLinkId) {
		this.customerLinkId = customerLinkId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
