package yc.hibprob;

import org.hibernate.Session;

import java.util.List;
import java.util.ArrayList;

public class RunMe {

	public static void main(String[] args) {

		// 1st tx
		System.out.println("first tx");
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();

		Customer customer = new Customer();
		customer.setName("john doe");
		List<Address> addresses = new ArrayList<Address>();
		customer.setAddresses(addresses);

		addCustomerAddress(customer, "addr #1");
		addCustomerAddress(customer, "addr #2");

		session.saveOrUpdate(customer);
		session.getTransaction().commit();

		// 2nd tx
		System.out.println("second tx");
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		customer.setName("foo boo");
		session.saveOrUpdate(customer);
		session.getTransaction().commit();
		// Exception in thread "main" org.hibernate.HibernateException: Don't change the reference to a collection with cascade="all-delete-orphan": yc.hibprob.Customer.addresses
	}


	static void addCustomerAddress(Customer customer, String name) {
		Address address = new Address();
		address.setName(name);
		address.setCustomer(customer);
		customer.getAddresses().add(address);

	}
}
