/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package db;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Root;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import static org.assertj.core.api.Assertions.assertThat;
import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.output.MigrateResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class QueryTest {

    private static final Logger LOGGER = LogManager.getLogger();

    private EntityManagerFactory emf;
    private EntityManager em;




    @Test
    public void executeQuery() {
        //given
        CriteriaBuilder cb = em.getCriteriaBuilder();
        var query = cb.createTupleQuery();
        Root<Primary> root = query.from(Primary.class);
        var secondaryJoin = root.join(Primary_.secondary);
        //when
        query.multiselect(
                cb.selectCase(secondaryJoin.get(Secondary_.code))
                        .when("a", root.get(Primary_.resultValue))
                        .otherwise(cb.nullLiteral(Integer.class)).alias("value")
        ).orderBy(
                cb.asc(root.get(Primary_.id))
        );
        var list = em.createQuery(query).getResultList();
        //then
        assertThat(list).hasSize(2);
        assertThat(list.get(0).get("value")).isEqualTo(100);
        assertThat(list.get(1).get("value")).isNull();
    }

    @BeforeClass
    private void beforeClass() {
        Flyway flyway = Flyway.configure().dataSource("jdbc:hsqldb:mem:jpa_test", "user", "password").load();
        MigrateResult migrateResult = flyway.migrate();
        LOGGER.info("Migrations: {}", migrateResult.migrationsExecuted);
        emf = Persistence.createEntityManagerFactory("jpa_test");
        em = emf.createEntityManager();
    }

    @AfterClass
    private void afterClass() {
        em.close();
        emf.close();
    }

    @BeforeMethod
    private void beforeMethod() {
        em.getTransaction().begin();
    }

    @AfterMethod
    private void afterMethod() {
        em.getTransaction().rollback();
    }
}
