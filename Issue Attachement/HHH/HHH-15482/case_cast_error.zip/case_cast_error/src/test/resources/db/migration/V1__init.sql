
create schema test;

create table test.t_secondary (
    code character varying(50) primary key
);

create table test.t_primary (
    id integer primary key,
    t_secondary_code character varying(50) not null ,
    result_value integer not null,
    constraint d_primary_t_secondary_code_fkey foreign key(t_secondary_code)
        references test.t_secondary(code) match simple
);

insert into test.t_secondary(code) values ('a'), ('b');

insert into test.t_primary(id, t_secondary_code, result_value)
    values (1, 'a', 100), (2, 'b', 200);
