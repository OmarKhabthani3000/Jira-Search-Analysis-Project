package org.hibernate.ejb.test.case254263;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
public class Customer {
    private long id;
    
	private Integer someProperty;
	

    private Set<Contact> contacts = new HashSet<Contact> ();
	
    @Id
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
    public Integer getSomeProperty() {
        return someProperty;
    }
    public void setSomeProperty(Integer someProperty) {
        this.someProperty = someProperty;
    }
    
    // works with @OneToMany(fetch=FetchType.LAZY, mappedBy="customer")
    @OneToMany(fetch=FetchType.EAGER, mappedBy="customer")
    // works if CascadeType.PERSIST is removed
    @Cascade({CascadeType.PERSIST})
    public Set<Contact> getContacts() {
        return contacts;
    }
    public void setContacts(Set<Contact> contacts) {
        this.contacts = contacts;
    }
}

