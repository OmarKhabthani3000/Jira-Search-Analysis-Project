//$Id: $
package org.hibernate.ejb.test.case254263;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.annotations.CascadeType;
import org.hibernate.ejb.test.TestCase;
import org.hibernate.ejb.test.association.Kitchen;
import org.hibernate.ejb.test.association.Oven;

/**
 * @author Anthony Patricio
 */
public class ReattachmentTest extends TestCase {
	public void testBug() throws Exception {
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Customer customer = new Customer();
		customer.setId(new Long(1));
		customer.setSomeProperty(1);

		Contact contact = new Contact();
		contact.setId(new Long(1));
		contact.setCustomer(customer);
		customer.getContacts().add(contact);
		contact.setSomeProperty(1);
		
		Session session = (Session)(em.getDelegate());
		session.persist(customer);
		session.persist(contact);
		em.getTransaction().commit();
		em.clear();
		
		em.getTransaction().begin();
		customer = (Customer) session.get(Customer.class, 1L);
		em.getTransaction().commit();
		em.clear();
		
		em.getTransaction().begin();
		em.clear();
		session = (Session)(em.getDelegate());
		session.clear();
		// Causes insert on contacts(!) table
		// customer.setContacts(null); //<-- Workaround to avoid it
		// really weird points:
		// works with 100% plain hibernate (mapping files + session APIs (via session Factory, see test based on hb core template)
		// fails with 50% plain hibernate (mapping files + EM APIs to obtain HB session)
		// works if collection is annotated with fetch=FetchType.LAZY
		// works if collection is annotated without CascadeType.PERSIST
		session.update(customer);
		em.getTransaction().commit();
		em.close();
	}

	public Class[] getAnnotatedClasses() {
		return new Class[]{
				Customer.class,
				Contact.class
		};
	}
}
