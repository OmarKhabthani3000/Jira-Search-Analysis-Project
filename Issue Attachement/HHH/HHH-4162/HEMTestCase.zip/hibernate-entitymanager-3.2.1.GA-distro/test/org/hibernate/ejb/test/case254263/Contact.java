package org.hibernate.ejb.test.case254263;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Contact {

    
    private long id;
	private Integer someProperty;
	
	
	private Customer customer;
	
	@Id
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public Integer getSomeProperty() {
		return someProperty;
	}
	public void setSomeProperty(Integer someProperty) {
		this.someProperty = someProperty;
	}

	@ManyToOne
	public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}