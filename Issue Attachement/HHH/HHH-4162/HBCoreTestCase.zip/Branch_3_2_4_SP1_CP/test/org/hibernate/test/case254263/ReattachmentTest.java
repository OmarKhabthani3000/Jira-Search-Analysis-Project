//$Id: CompositeIdTest.java 10977 2006-12-12 23:28:04Z steve.ebersole@jboss.com $
package org.hibernate.test.case254263;

import junit.framework.Test;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.junit.functional.FunctionalTestCase;
import org.hibernate.junit.functional.FunctionalTestClassTestSuite;

/**
 * @author Gavin King
 */
public class ReattachmentTest extends FunctionalTestCase {
	
	public ReattachmentTest(String str) {
		super(str);
	}

	public String[] getMappings() {
		return new String[] { "case254263/Mappings.hbm.xml" };
	}

	public static Test suite() {
		return new FunctionalTestClassTestSuite(ReattachmentTest.class);
	}
	

	
	public void testReattachment
	() {
		Session s = openSession();
		Transaction t = s.beginTransaction();

		Customer customer = new Customer();
		customer.setId(new Long(1));
		customer.setSomeProperty(1);

		Contact contact = new Contact();
		contact.setId(new Long(1));
		contact.setCustomer(customer);
		customer.getContacts().add(contact);
		contact.setSomeProperty(1);

		s.persist(customer);
		s.persist(contact);

		t.commit();
		s.close();
		
		s = openSession();
		s.clear();
		t = s.beginTransaction();
		customer = (Customer)s.get(Customer.class, 1L);
		t.commit();
		s.close();
		
		customer.setSomeProperty(customer.getSomeProperty() + 1);
		s = openSession();
		s.clear();
		t = s.beginTransaction();
		s.update(customer);
		t.commit();
		s.close();

		
		s = openSession();
		t = s.beginTransaction();
		s.createQuery("delete from Contact").executeUpdate();
		s.createQuery("delete from Customer").executeUpdate();
		t.commit();
		s.close();
	}

	


}

