package org.hibernate.test.case254263;

public class Contact {

    
    private long id;
	private Integer someProperty;
	
	
	private Customer customer;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public Integer getSomeProperty() {
		return someProperty;
	}
	public void setSomeProperty(Integer someProperty) {
		this.someProperty = someProperty;
	}

	public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}