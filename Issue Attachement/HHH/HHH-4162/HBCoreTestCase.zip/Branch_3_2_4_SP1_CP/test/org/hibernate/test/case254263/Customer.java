package org.hibernate.test.case254263;


import java.util.HashSet;
import java.util.Set;

public class Customer {
    private long id;
    
	private Integer someProperty;
	

    private Set<Contact> contacts = new HashSet<Contact> ();
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
    public Integer getSomeProperty() {
        return someProperty;
    }
    public void setSomeProperty(Integer someProperty) {
        this.someProperty = someProperty;
    }
    
    public Set<Contact> getContacts() {
        return contacts;
    }
    public void setContacts(Set<Contact> contacts) {
        this.contacts = contacts;
    }
}

