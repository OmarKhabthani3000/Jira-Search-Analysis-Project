/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package testcase1;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author rac
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
        Master m1 = new Master();
        em.persist(m1);
        em.getTransaction().commit();
        Long id = m1.getId();

        em.clear();

        m1 = em.find(Master.class, id);
        m1.getDetails().add(new Detail());

        em.refresh(m1);
    }

}
