package test;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Restrictions;

/**
 * Hello world!
 */
public class App {
    static Log log = LogFactory.getLog( App.class );

    @SuppressWarnings("unchecked")
    public static void main( String[] args )
        throws Exception {
        Session session = HibernateUtil.getSession();
        session.createSQLQuery( "insert into someentity (id,version,prop) values (1,11,'aa')" ).executeUpdate();
        session.createSQLQuery( "insert into someentity (id,version,prop) values (1,12,'bb')" ).executeUpdate();
        session.createSQLQuery( "insert into someentity (id,version,prop) values (10,21,'cc1')" ).executeUpdate();
        session.createSQLQuery( "insert into someentity (id,version,prop) values (10,22,'cc2')" ).executeUpdate();
        session.createSQLQuery( "insert into someentity (id,version,prop) values (10,23,'cc3')" ).executeUpdate();

        Query query = session.createQuery( "from SomeEntity" );
        List<SomeEntity> list = query.list();
        for ( SomeEntity entity : list ) {
            log.info( entity );
        }
        
        List ids = new ArrayList<SomeEntityId>(2);
        ids.add( new SomeEntityId(1,12) );
        ids.add( new SomeEntityId(10,23) );
        
        Criteria criteria = session.createCriteria( SomeEntity.class );
        Disjunction disjunction = Restrictions.disjunction();
        
        disjunction.add( Restrictions.in( "id", ids  ) );
        criteria.add( disjunction );
        
        list = criteria.list();
        for ( SomeEntity entity : list ) {
            log.info( entity );
        }
    }
}
