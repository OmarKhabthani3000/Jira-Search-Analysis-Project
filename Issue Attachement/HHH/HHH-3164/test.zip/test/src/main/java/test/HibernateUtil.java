/**
 * 
 */
package test;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class HibernateUtil {

    private static final SessionFactory sessionFactory;

    static {
        try {

            AnnotationConfiguration cfg = new AnnotationConfiguration().addAnnotatedClass( SomeEntity.class );
            cfg.setProperty( "hibernate.connection.driver_class", "org.h2.Driver" );
            cfg.setProperty( "hibernate.connection.url", "jdbc:h2:mem:~/test;TRACE_LEVEL_SYSTEM_OUT=2" );
            cfg.setProperty( "hibernate.connection.username", "sa" );
            cfg.setProperty( "hibernate.connection.password", "" );
            cfg.setProperty( "hibernate.connection.provider_class", "org.hibernate.connection.DriverManagerConnectionProvider" );
            cfg.setProperty( "hibernate.dialect", "org.hibernate.dialect.H2Dialect" );
            cfg.setProperty( "hibernate.show_sql", "true" );
            cfg.setProperty( "hibernate.format_sql", "false" );
            cfg.setProperty( "hibernate.hbm2ddl.auto", "create" );
            
            
            sessionFactory = cfg.buildSessionFactory();
        }
        catch ( Throwable ex ) {
            // Log exception!
            throw new ExceptionInInitializerError( ex );
        }
    }

    public static Session getSession()
        throws HibernateException {
        return sessionFactory.openSession();
    }
}
