package tests;

import java.util.Collection;
import java.util.List;
import junit.framework.TestCase;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import util.HibernateUtil;


/**
 * Some Criteria and SQL queries.
 *
 * @author Christian Bauer
 */
public class Queries extends TestCase {

    private org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(this.getClass());

    public void setUp() throws Exception {
        Transaction tx  = HibernateUtil.getSessionFactory().getCurrentSession().beginTransaction();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Collection all = session.createQuery("from TipoLogradouroDTO").list();
        for(Object o : all) {
            session.delete(o);
        }
        // if (autoFlush) {
        session.flush();

        for(int i=0;i<20;i++) {
            TipoLogradouroDTO dto = new TipoLogradouroDTO(new Long(i+1L));
            dto.setDesTipoLogrAbrev("D " + (i+1));
            dto.setDesTipoLogradouro("Desc " + (i+1));
            if (i<3) {
                dto.setIndTipoLogrAtivado("N");
            } else {
                dto.setIndTipoLogrAtivado("S");
            }
            session.save(dto);
        }
        tx.commit();
    }
    
    public void testOraclePaginationError() {        
        // Start a unit of work
        HibernateUtil.getSessionFactory().getCurrentSession().beginTransaction();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
	List result1,result2;
        String hql = "select p0 from TipoLogradouroDTO p0 order by p0.indTipoLogrAtivado asc";
	Query q = session.createQuery(hql);
        //First page
	q.setFirstResult(0);
	q.setMaxResults(10);
        q.setFetchSize(10);
	result1 = q.list();	
        //Second page
	q = session.createQuery(hql);
	q.setFirstResult(10);
	q.setMaxResults(10);
        q.setFetchSize(10);
	result2 = q.list();
        
        log.info("Result1:\n" + result1);
	log.info("Result2:\n" + result2);
	
        for(Object o : result2) {
            log.info("Testing: " + o);
            assertFalse(result1.contains(o));
        }
    }


}
