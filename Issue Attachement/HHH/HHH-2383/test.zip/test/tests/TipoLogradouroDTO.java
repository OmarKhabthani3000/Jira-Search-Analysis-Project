//Essa classe foi gerada pelo DBA JavaFramework
package tests;

import java.io.Serializable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public class TipoLogradouroDTO implements Serializable {
    private static Log log = LogFactory.getLog(TipoLogradouroDTO.class);

    private java.lang.String desTipoLogradouro;
    private java.lang.String desTipoLogrAbrev;
    private java.lang.Long ideTipoLogradouro;
    private java.lang.String indTipoLogrAtivado;

    public TipoLogradouroDTO(java.lang.Long ideTipoLogradouro) {
        this.setIdeTipoLogradouro(ideTipoLogradouro);
    }

    /** Construtor padrao */
    public TipoLogradouroDTO() {
    }


    /*
    public int hashCode() {
        // CUSTOMIZAR:
        // Deve ser customizado pelo desenvolvedor.
        if (ideTipoLogradouro != null) {
            return ideTipoLogradouro.hashCode();
        }
        return super.hashCode();
    }

    public boolean equals(Object other) {
        // CUSTOMIZAR:
        // Deve ser customizado pelo desenvolvedor.
        if ((other != null) && (other instanceof TipoLogradouroDTO)) {
            return this.hashCode() == other.hashCode();
        }
        return false;
    }
     */

    public java.lang.String getDesTipoLogradouro() {
        return desTipoLogradouro;
    }

    public void setDesTipoLogradouro(java.lang.String desTipoLogradouro) {
        this.desTipoLogradouro = desTipoLogradouro;
    }

    public java.lang.String getDesTipoLogrAbrev() {
        return desTipoLogrAbrev;
    }

    public void setDesTipoLogrAbrev(java.lang.String desTipoLogrAbrev) {
        this.desTipoLogrAbrev = desTipoLogrAbrev;
    }

    public java.lang.Long getIdeTipoLogradouro() {
        return ideTipoLogradouro;
    }

    public void setIdeTipoLogradouro(java.lang.Long ideTipoLogradouro) {
        this.ideTipoLogradouro = ideTipoLogradouro;
    }

    public java.lang.String getIndTipoLogrAtivado() {
        return indTipoLogrAtivado;
    }

    public void setIndTipoLogrAtivado(java.lang.String indTipoLogrAtivado) {
        this.indTipoLogrAtivado = indTipoLogrAtivado;
    }

    public String toString() {
        return "{"+ideTipoLogradouro+"}";
    }
}
