package test;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.cfg.AnnotationConfiguration;

public class SessionFactory {
	
	private static final org.hibernate.SessionFactory sessionFactory;

    static {
        try {
            sessionFactory = new AnnotationConfiguration().configure( "hibernate.cfg.xml" ).buildSessionFactory();
        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static Session getSession() throws HibernateException {
        return sessionFactory.getCurrentSession();
    }
}
