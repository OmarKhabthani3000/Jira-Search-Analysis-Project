package test;

import org.hibernate.Session;
import org.hibernate.Transaction;

import test.model.Article;
import test.model.Quantity;

public class HibernateTest {
	public static void main( String[] args ) {
		Session session = SessionFactory.getSession();
		Transaction transaction = session.getTransaction();
		transaction.begin();
		
		Article a = new Article();
		a.setName( "atricle" );
		
		Quantity q = new Quantity();
		q.setName( "quantity" );
		q.setArticle( a );
		
		a.getQuantities().add( q );
		
		session.persist( a );
		
		session.flush();
		
		session.flush();
		
		a.getQuantities().clear();
		
		session.flush();
		
		session.clear();
		
		Article a1 = new Article();
		a1.setId( a.getId() );
		a1.setName( a.getName() );
		a1.setVersion( a.getVersion() );
		
		Quantity q1 = new Quantity();
		q1.setArticle( a1 );
		q1.setName( q.getName() );
		q1.setVersion( q.getVersion() );
		q1.setId( q.getId() );
		
		a1.getQuantities().add( q1 );
		
		a1 = (Article)session.merge( a1 );
		
		session.flush();
		
		transaction.rollback();
		
	}
}
