package test.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Version;

@Entity
public class Article {
	private long id;

	private long version;

	private String name;

	private Set<Quantity> quantities = new HashSet<Quantity>();

	@Id
	@GeneratedValue( strategy = GenerationType.SEQUENCE )
	public long getId() {
		return id;
	}

	public void setId( long id ) {
		this.id = id;
	}

	@Version
	public long getVersion() {
		return version;
	}

	public void setVersion( long version ) {
		this.version = version;
	}

	@Basic
	public String getName() {
		return name;
	}

	public void setName( String name ) {
		this.name = name;
	}

	@OneToMany( mappedBy = "article", cascade = { CascadeType.MERGE, CascadeType.PERSIST }, fetch = FetchType.LAZY )
	public Set<Quantity> getQuantities() {
		return quantities;
	}

	public void setQuantities( Set<Quantity> quantities ) {
		this.quantities = quantities;
	}

}
