CREATE TABLE TestTable (
	[id] [int] NOT NULL ,
	[stamp] [datetime] NOT NULL
) ON [PRIMARY]

INSERT INTO TestTable values ('0', GETDATE() );
