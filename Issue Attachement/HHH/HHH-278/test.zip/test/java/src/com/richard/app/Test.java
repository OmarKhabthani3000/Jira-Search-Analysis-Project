package com.richard.app;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.HibernateException;
import org.hibernate.Hibernate;
import org.hibernate.Query;

import java.util.List;

import com.richard.util.HibernateUtil;
import com.richard.exceptions.InfrastructureException;


public class Test {

    public static void main(String[] args) throws Exception {

		List testList;
        String queryStr = "select new com.richard.beans.TestRow(myTest.id, myTest.stamp) from TestBean myTest";

        HibernateUtil.beginTransaction();
        Session session = HibernateUtil.getSession();
        try {
            testList = session.createQuery(queryStr).list();
        } catch (HibernateException ex) {
            ex.printStackTrace();
            throw new InfrastructureException(ex);
        } finally {
            HibernateUtil.closeSession();
        }
    }

}
