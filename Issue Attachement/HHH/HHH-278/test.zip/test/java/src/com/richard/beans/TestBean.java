package com.richard.beans;

import java.sql.Timestamp;
import java.io.Serializable;

public class TestBean implements Serializable {

    private Integer id;
    private Timestamp stamp;

    public TestBean() {
    }

    public TestBean(Integer id, Timestamp stamp) {
        this.id = id;
        this.stamp = stamp;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Timestamp getStamp() {
        return this.stamp;
    }

    public void setStamp(Timestamp stamp) {
        this.stamp = stamp;
    }
}
