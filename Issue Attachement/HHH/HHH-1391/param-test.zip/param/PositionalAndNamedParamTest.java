//$Id: $
package org.hibernate.test.param;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.TestCase;

/**
 * Tests using named parameters after positional parameters
 * (used to work).
 */
public class PositionalAndNamedParamTest extends TestCase {
	
	public PositionalAndNamedParamTest(String str) {
		super(str);
	}
	
	public void testMapping() {
		Session s = openSession();
		Transaction tx = s.beginTransaction();

                //list vs scalar doesn't seem to matter
		String hql = "SELECT DISTINCT p.name FROM Parent p " +
			" WHERE p.prop1 = ? and p.prop2 = ? and p.prop3 = ? " +
			//" and p.prop4 in (:param4)";
			" and p.prop4 = :param4 ";

		List params = new ArrayList(1);
		params.add("4");

		Query q = s.createQuery(hql);
		q.setParameter(0, "1");
		q.setParameter(1, "2");
		q.setParameter(2, "3");
		//q.setParameterList("param4", params);
		q.setParameter("param4", "4");

		//should not fail with invalid parameter index error
		List keys = q.list();

		tx.commit();
		s.close();
	}


	protected String[] getMappings() {
		return new String[] { "param/Parent.hbm.xml" };
	}

	public static Test suite() {
		return new TestSuite(PositionalAndNamedParamTest.class);
	}

}

