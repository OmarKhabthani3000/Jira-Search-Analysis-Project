package entity_test;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

@Entity
public class DerivedEntity extends BaseEntity {

    private RelatedEntity related;

    @OneToOne(cascade = CascadeType.ALL)
    @NotNull
    public RelatedEntity getRelated() {
        return related;
    }

    public void setRelated(final RelatedEntity related) {
        this.related = related;
    }
}
