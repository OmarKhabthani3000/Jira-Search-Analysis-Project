package entity_test;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

@Entity
public class OneToOneChain1 {

    private long id;
    private OneToOneChain2 linked;

    @Id
    public long getId() {
        return id;
    }

    public void setId(final long id) {
        this.id = id;
    }

    @OneToOne
    @NotNull
    public OneToOneChain2 getLinked() {
        return linked;
    }

    public void setLinked(final OneToOneChain2 link) {
        this.linked = link;
    }
}
