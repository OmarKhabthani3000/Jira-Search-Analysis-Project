package entity_test;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class RelatedEntity {

    private long id;

    @Id
    public long getId() {
        return id;
    }

    public void setId(final long id) {
        this.id = id;
    }
}
