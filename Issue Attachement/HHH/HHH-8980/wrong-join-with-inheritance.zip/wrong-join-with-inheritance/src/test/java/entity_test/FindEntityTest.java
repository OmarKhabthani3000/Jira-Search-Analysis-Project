package entity_test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import java.util.Map;
import java.util.TreeMap;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.dialect.HSQLDialect;
import org.hsqldb.jdbc.JDBCDriver;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.stereotype.Component;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

@Component
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(loader = AnnotationConfigContextLoader.class)
public class FindEntityTest {

    @Configuration
    @EnableTransactionManagement
    public static class TestConfiguration {

        @Bean
        public JpaTransactionManager txm() {
            return new JpaTransactionManager(emf().getObject());
        }

        @Bean
        public LocalContainerEntityManagerFactoryBean emf() {
            final LocalContainerEntityManagerFactoryBean emf =
                    new LocalContainerEntityManagerFactoryBean();
            // emf.setPersistenceProviderClass(org.hibernate.ejb.HibernatePersistence.class);
            emf.setPersistenceProviderClass(org.hibernate.jpa.HibernatePersistenceProvider.class);
            emf.setPackagesToScan(getClass().getPackage().getName());
            emf.setPersistenceUnitName("entity_test");
            emf.setJpaPropertyMap(persistenceProperties());
            return emf;
        }

        private Map<String, Object> persistenceProperties() {
            final Map<String, Object> properties = new TreeMap<String, Object>();
            properties.put("javax.persistence.jdbc.driver", JDBCDriver.class.getName());
            properties.put("javax.persistence.jdbc.url", "jdbc:hsqldb:mem:test");
            // properties.put("hibernate.connection.url", "jdbc:hsqldb:mem:test");
            properties.put("hibernate.dialect", HSQLDialect.class.getName());
            properties.put("hibernate.hbm2ddl.auto", "create");
            properties.put("hibernate.show_sql", true);
            properties.put("hibernate.format_sql", true);
            properties.put("hibernate.use_sql_comments", true);
            return properties;
        }
    }

    private static final long ID = 1;

    @PersistenceContext
    private EntityManager entityManager;

    @Test
    @Transactional
    public void testBaseEntity() {
        final BaseEntity base = new BaseEntity();
        base.setId(ID);
        entityManager.merge(base);
        entityManager.flush();

        entityManager.clear();
        final BaseEntity found = entityManager.find(BaseEntity.class, ID);
        assertThat(found, notNullValue());
    }

    @Test
    @Transactional
    public void testEntityChain() {
        final OneToOneChain1 entity1 = new OneToOneChain1();
        entity1.setId(ID);
        entity1.setLinked(new OneToOneChain2());
        entity1.getLinked().setId(ID);
        entity1.getLinked().setLinked(new OneToOneChain3());
        entity1.getLinked().getLinked().setId(ID);
        entityManager.merge(entity1);
        entityManager.flush();

        entityManager.clear();
        final OneToOneChain1 found = entityManager.find(OneToOneChain1.class, ID);
        assertThat(found, notNullValue());
    }
}
