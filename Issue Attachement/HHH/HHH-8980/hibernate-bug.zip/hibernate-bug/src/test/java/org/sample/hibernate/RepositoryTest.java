package org.sample.hibernate;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.sample.hibernate.model.Customer;
import org.sample.hibernate.model.Department;
import org.sample.hibernate.model.User;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * Unit test for simple App.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
public class RepositoryTest {

    @PersistenceContext
    private EntityManager em;

    @Test
    @Transactional
    public void find() {
        insert();

        /**
         * <pre>
         * Hibernate: 
         *     select
         *         user0_.id as id1_2_0_,
         *         user0_.name as name2_2_0_,
         *         user0_1_.belongTo_id as belongTo2_0_0_,
         *         case 
         *             when user0_1_.id is not null then 1 
         *             when user0_.id is not null then 0 
         *         end as clazz_0_,
         *         department1_.id as id1_1_1_,
         *         department1_.name as name2_1_1_ 
         *     from
         *         Users user0_ 
         *     left outer join
         *         Customer user0_1_ 
         *             on user0_.id=user0_1_.id 
         *     inner join
         *         Department department1_ 
         *             on user0_1_.belongTo_id=department1_.id 
         *     where
         *         user0_.id=?
         * </pre>
         */
        assertNull(em.find(User.class, 99L)); // ok

        /**
         * <pre>
         * Hibernate: 
         *     select
         *         customer0_.id as id1_2_0_,
         *         customer0_1_.name as name2_2_0_,
         *         customer0_.belongTo_id as belongTo2_0_0_,
         *         department1_.id as id1_1_1_,
         *         department1_.name as name2_1_1_ 
         *     from
         *         Customer customer0_ 
         *     inner join
         *         Users customer0_1_ 
         *             on customer0_.id=customer0_1_.id 
         *     inner join
         *         Department department1_ 
         *             on customer0_.belongTo_id=department1_.id 
         *     where
         *         customer0_.id=?
         * </pre>
         */
        assertNotNull(em.find(Customer.class, 2L)); // ok

        /**
         * <pre>
         * 
         * Hibernate: 
         *     select
         *         user0_.id as id1_2_0_,
         *         user0_.name as name2_2_0_,
         *         user0_1_.belongTo_id as belongTo2_0_0_,
         *         case 
         *             when user0_1_.id is not null then 1 
         *             when user0_.id is not null then 0 
         *         end as clazz_0_,
         *         department1_.id as id1_1_1_,
         *         department1_.name as name2_1_1_ 
         *     from
         *         Users user0_ 
         *     left outer join
         *         Customer user0_1_ 
         *             on user0_.id=user0_1_.id 
         *     inner join
         *         Department department1_ 
         *             on user0_1_.belongTo_id=department1_.id 
         *     where
         *         user0_.id=?
         * </pre>
         */
        assertNotNull(em.find(User.class, 1L)); // fail
    }

    public void insert() {
        em.persist(new User(1L, "Bart"));
        em.persist(new Department(100L, "D1"));
        em.flush();
        Department d = em.find(Department.class, 100L);
        em.persist(new Customer(2L, "Homer", d));
        em.flush();
        em.clear();
    }
}
