package org.sample.hibernate.model;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Customer extends User {

    public Customer() {
    }
    
    public Customer(Long id, String name, Department belongTo) {
        super(id, name);
        this.belongTo = belongTo;
    }

    @ManyToOne(optional = false)
    private Department belongTo;
}
