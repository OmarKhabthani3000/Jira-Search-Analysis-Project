package criteriabug.dao.impl;

import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.Parameter;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import criteriabug.dao.RegionDao;
import criteriabug.domain.Region;

@Repository
public class RegionDaoImpl implements RegionDao {

	@PersistenceContext
	private EntityManager entityManager;

	public int getParamCountInQuery() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Region> cq = cb.createQuery(Region.class);

        Root<Region> region = cq.from(Region.class);
        cq.where(cb.equal(region.get("regionId"), 1L));
        TypedQuery<Region> q = entityManager.createQuery(cq);
        
        Set<Parameter<?>> params = q.getParameters();
        q.getResultList();
        return params.size();
	}
}
