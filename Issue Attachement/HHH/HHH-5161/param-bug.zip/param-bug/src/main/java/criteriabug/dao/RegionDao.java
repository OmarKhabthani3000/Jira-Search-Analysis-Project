package criteriabug.dao;


public interface RegionDao {

	/**
	 * Constructs a Criteria query that selects a region by id and returns
	 * the number of parameters in the generated query. 
	 * 
	 * This is a simplistic example that is only used to demonstrate the
	 * bug.
	 * 
	 * @return the number of parameters in 
	 */
	int getParamCountInQuery();
}
