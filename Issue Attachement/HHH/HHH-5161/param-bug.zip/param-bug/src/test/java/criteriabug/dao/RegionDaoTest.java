package criteriabug.dao;

import org.junit.Test;
import org.junit.Assert;
import org.unitils.database.annotations.Transactional;
import org.unitils.spring.annotation.SpringBeanByType;

import criteriabug.BaseTestCase;

@Transactional
public class RegionDaoTest extends BaseTestCase {

	@SpringBeanByType
	RegionDao regionDao;

	@Test
	public void testPramCount() {
		Assert.assertTrue("Query contains no parameters", regionDao
				.getParamCountInQuery() > 0);
	}
}
