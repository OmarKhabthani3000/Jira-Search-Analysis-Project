/*
 * =============================================================
 * BaseTestCase.java, Project: Origin Case Management (OCM)
 * $URL: svn://wk005242/TCM/branches/OCM_Release1/OCM/web/src/test/java/ae/gov/dubaicustoms/ocm/BaseTestCase.java $
 *
 * Created: 12 Jan 2010 by amr.hassanin
 * Last Modified $Date:: 2010-02-08 13:49:25 #$
 * $LastChangedBy: tarekn $
 * $Revision: 32462 $
 * Copyright Dubai Customs (c) 2009-2010, All Rights Reserved
 * =============================================================
 */
package criteriabug;

import org.junit.runner.RunWith;
import org.unitils.UnitilsJUnit4TestClassRunner;
import org.unitils.spring.annotation.SpringApplicationContext;

@SpringApplicationContext(value = {"applicationContext.xml"})
@RunWith(UnitilsJUnit4TestClassRunner.class)
public abstract class BaseTestCase {}
