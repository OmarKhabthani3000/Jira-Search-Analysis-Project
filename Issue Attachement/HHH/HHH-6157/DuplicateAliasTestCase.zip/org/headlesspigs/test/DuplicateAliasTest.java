package org.headlesspigs.test;

import static org.junit.Assert.assertEquals;

import java.io.Serializable;

import org.headlesspigs.domainmodel2.SpecificInvoice;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

public class DuplicateAliasTest extends BaseCoreFunctionalTestCase {

  @Override
  public boolean createSchema() {
    return true;
  }

  @Override
  public String getBaseForMappings() {
    return "org/headlesspigs/domainmodel2/";
  }

  public String[] getMappings() {
    return new String[] {
      "Invoice.hbm.xml"
    };
  }

  @Test
  public void testDuplicateAlias() throws Exception {
    Transaction tx = null;
    Session s = null;
    Serializable id = null;
    SpecificInvoice inv = new SpecificInvoice("INV-1", "ABC", "XXX");
    try {
      s = this.openSession();
      tx = s.beginTransaction();
      id = s.save(inv);
      tx.commit();
    } catch (Exception e) {
      if (tx != null) {
        tx.rollback();
      }
      throw e;
    } finally {
      if (s != null && s.isOpen()) {
        s.close();
      }
    }

    try {
      s = this.openSession();
      tx = s.beginTransaction();
      inv = (SpecificInvoice) s.load(SpecificInvoice.class, id);
      assertEquals(inv.getSameNameAsInvoice(), inv.getName());
      assertEquals("INV-1", inv.getName());
      assertEquals("ABC", inv.getNumber());
      assertEquals("XXX", inv.getCode());
      tx.commit();
    } catch (Exception e) {
      if (tx != null) {
        tx.rollback();
      }
      throw e;
    } finally {
      if (s != null && s.isOpen()) {
        s.close();
      }
    }

  }

}
