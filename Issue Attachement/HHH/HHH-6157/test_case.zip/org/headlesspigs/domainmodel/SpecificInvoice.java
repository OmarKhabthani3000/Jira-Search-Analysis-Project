package org.headlesspigs.domainmodel;

public class SpecificInvoice extends Invoice {
	private String sameNameAsInvoice;
	private String number;
	private String code;

	public SpecificInvoice() {
		super();
	}

	public SpecificInvoice(String name, String number, String code) {
		super(name);
		this.number = number;
		this.code = code;
	}

	public String getSameNameAsInvoice() {
		return sameNameAsInvoice;
	}

	public void setSameNameAsInvoice(String sameNameAsInvoice) {
		this.sameNameAsInvoice = sameNameAsInvoice;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
