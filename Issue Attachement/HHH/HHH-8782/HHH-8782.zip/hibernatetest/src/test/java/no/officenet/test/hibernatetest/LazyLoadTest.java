package no.officenet.test.hibernatetest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.Arrays;

import javax.annotation.Resource;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import no.officenet.test.hibernatetest.model.Car;
import no.officenet.test.hibernatetest.model.Company;
import no.officenet.test.hibernatetest.model.Person;
import no.officenet.test.hibernatetest.model.Product;
import no.officenet.test.hibernatetest.model.Store2;
import no.officenet.test.hibernatetest.service.CarRepository;
import no.officenet.test.hibernatetest.service.CompanyRepository;
import no.officenet.test.hibernatetest.service.PersonRepository;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.ejb.HibernateEntityManagerFactory;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.mchange.v2.c3p0.ComboPooledDataSource;

@ContextConfiguration(locations = {"classpath*:spring/*-context.xml" })
public class LazyLoadTest extends AbstractTransactionalJUnit4SpringContextTests {

    @Resource
    protected EntityManagerFactory emf;

    @Resource
    PersonRepository personRepository;
    @Resource
    CarRepository carRepository;
    @Resource
    CompanyRepository companyRepository;
    @Resource
    DataSource dataSource;

    @Resource
    protected PlatformTransactionManager transactionManager;

    protected TransactionTemplate transactionTemplate;

    private SessionFactory sessionFactory;

    private static final String companyName = "OfficeNet AS";
    
    @Before
    public void before() throws Exception {
        transactionTemplate = new TransactionTemplate(transactionManager, new DefaultTransactionDefinition(TransactionDefinition.PROPAGATION_REQUIRED));
        sessionFactory = ((HibernateEntityManagerFactory) emf).getSessionFactory();
    }

    @Test
    public void testLazyLoadLeaksConnections() throws Exception {
        System.out.println("First deleting old data");
        deleteTestData();
        System.out.println("Generating test-data");
        generateTestData();
        ComboPooledDataSource c3poDataSource = (ComboPooledDataSource) dataSource;
        System.out.println("Looping to trigger connection-leak");
        for (int i = 0; i < 10; i++) {
            System.out.println("Iteration " + (i + 1));
            Company officeNet = companyRepository.findByCompanyName(companyName);
            for (Person person : officeNet.getEmployees()) {
                for (Car car : person.getCars()) {
                    System.out.println("Used connections in pool: " + c3poDataSource.getNumBusyConnections());
                    System.out.println("Employee " + person.getFirstName() + " has car: " + car.getModel());
                }
            }
        }
        // never gets here cause the loop triggers the connection-leak
    }

    private Session openSession() {
        return sessionFactory().openSession();
    }

    private SessionFactory sessionFactory() {
        return sessionFactory;
    }

    @Test
    public void testLazyUnidirectionalCollectionLoadingWithClearedSession() {
        Session s = openSession();
        s.beginTransaction();
        
        Store2 store = new Store2().setName("Acme Super Outlet");
        Store2 store2 = new Store2().setName("Acme Super Outlet2");
        
        Product product = new Product().setName("widget").setDescription("FooBar");
        s.persist(product);
        
        store.addInventoryProduct(product).setQuantity(10L).setStorePrice(new BigDecimal(500));
        store2.addInventoryProduct(product).setQuantity(20L).setStorePrice(new BigDecimal(520));
        s.persist(store);
        s.persist(store2);
        
        s.getTransaction().commit();
        s.close();
        
        sessionFactory().getStatistics().clear();

        s = openSession();
        s.beginTransaction();
        // first load the store, making sure collection is not initialized
        store = (Store2) s.get(Store2.class, store.getId());
        s.createCriteria(Store2.class).list();
        assertNotNull(store);
        assertFalse(Hibernate.isInitialized(store.getInventories()));

        assertEquals(1, sessionFactory().getStatistics().getSessionOpenCount());
        assertEquals(0, sessionFactory().getStatistics().getSessionCloseCount());

        // then clear session and try to initialize collection
        s.clear();
        store.getInventories().size();
        assertTrue(Hibernate.isInitialized(store.getInventories()));

        assertEquals(2, sessionFactory().getStatistics().getSessionOpenCount());
        assertEquals(0, sessionFactory().getStatistics().getSessionCloseCount());

        s.clear();
        store = (Store2) s.get(Store2.class, store.getId());
        assertNotNull(store);
        assertFalse(Hibernate.isInitialized(store.getInventories()));

        assertEquals(2, sessionFactory().getStatistics().getSessionOpenCount());
        assertEquals(0, sessionFactory().getStatistics().getSessionCloseCount());

        s.clear();
        store.getInventories().iterator();
        assertTrue(Hibernate.isInitialized(store.getInventories()));

        assertEquals(3, sessionFactory().getStatistics().getSessionOpenCount());
        assertEquals(0, sessionFactory().getStatistics().getSessionCloseCount());

        s.getTransaction().commit();
        s.close();
    }

    @Test
    public void testLazyUnidirectionalCollectionLoadingWithClosedSession() {
        Session s = openSession();
        s.beginTransaction();
        
        Store2 store = new Store2().setName("Acme Super Outlet");
        Store2 store2 = new Store2().setName("Acme Super Outlet2");
        
        Product product = new Product().setName("widget").setDescription("FooBar");
        s.persist(product);
        
        store.addInventoryProduct(product).setQuantity(10L).setStorePrice(new BigDecimal(500));
        store2.addInventoryProduct(product).setQuantity(20L).setStorePrice(new BigDecimal(520));
        s.persist(store);
        s.persist(store2);
        
        s.getTransaction().commit();
        s.close();
        sessionFactory().getStatistics().clear();

        s = openSession();
        s.beginTransaction();
        // first load the store, making sure collection is not initialized
        store = (Store2) s.get(Store2.class, store.getId());
        assertNotNull(store);
        assertFalse(Hibernate.isInitialized(store.getInventories()));

        assertEquals(1, sessionFactory().getStatistics().getSessionOpenCount());
        assertEquals(0, sessionFactory().getStatistics().getSessionCloseCount());

        // close the session and try to initialize collection
        s.getTransaction().commit();
        s.close();

        assertEquals(1, sessionFactory().getStatistics().getSessionOpenCount());
        assertEquals(1, sessionFactory().getStatistics().getSessionCloseCount());

        store.getInventories().size();
        assertTrue(Hibernate.isInitialized(store.getInventories()));

        assertEquals(2, sessionFactory().getStatistics().getSessionOpenCount());
        assertEquals(1, sessionFactory().getStatistics().getSessionCloseCount());
    }

    private void deleteTestData() {
        transactionTemplate.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {
                Company companyToDelete = companyRepository.findByCompanyName(companyName);
                if (companyToDelete != null) {
                    companyRepository.remove(companyToDelete);
                }
            }
        });
    }

    private void generateTestData() {
        final Company officeNet = new Company(companyName).addEmployee(new Person("andreak", "Andreas", "Krogh", Arrays.asList(new Car("Volvo")))).addEmployee(
                new Person("foo", "Foo", "Bar", Arrays.asList(new Car("Ferrari"))));
        transactionTemplate.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {
                companyRepository.save(officeNet);
            }
        });
    }

}
