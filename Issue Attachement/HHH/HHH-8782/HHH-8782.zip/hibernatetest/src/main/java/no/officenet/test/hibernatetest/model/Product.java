package no.officenet.test.hibernatetest.model;

import javax.persistence.Entity;

@Entity
public class Product extends AbstractEntity {

    /**
     * 
     */
    private static final long serialVersionUID = 2616912505549854846L;
    private String name;
    private String description;

    public String getName() {
        return name;
    }

    public Product setName(String name) {
        this.name = name;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public Product setDescription(String description) {
        this.description = description;
        return this;
    }

}
