package hibernate.bug;

import hibernate.bug.model.Student;
import hibernate.bug.model.Question;
import hibernate.bug.model.StudentAnswer;
import java.util.Arrays;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class LeftJoinWithMultipleFromClauseTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Question q1 = new Question();
        Question q2 = new Question();
        
        em.persist(q1);
        em.persist(q2);
        
        Student s1 = new Student();
        em.persist(s1);
        
        StudentAnswer sa1 = new StudentAnswer();
        sa1.setQuestion(q1);
        sa1.setStudent(s1);
        sa1.setAnswer("sa1");
        em.persist(sa1);
        s1.getStudentAnswers().add(sa1);
        
        StudentAnswer sa2 = new StudentAnswer();
        sa2.setQuestion(q2);
        sa2.setStudent(s1);
        sa2.setAnswer("sa2");
        em.persist(sa2);
        s1.getStudentAnswers().add(sa2);
        
        Student s2 = new Student();
        em.persist(s2);
        
        StudentAnswer sa3 = new StudentAnswer();
        sa3.setQuestion(q1);
        sa3.setStudent(s2);
        sa3.setAnswer("sa1");
        em.persist(sa3);
        s2.getStudentAnswers().add(sa3);
        
        StudentAnswer sa4 = new StudentAnswer();
        sa4.setQuestion(q2);
        sa4.setStudent(s2);
        sa4.setAnswer("sa2");
        em.persist(sa4);
        s2.getStudentAnswers().add(sa4);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testLeftJoinWith() {
        EntityManager em = emf.createEntityManager();
        
        List l = em.createQuery(
            "SELECT s.id, q.id, sa.answer "
                + "FROM Student s, Question q "
                + "LEFT JOIN s.studentAnswers sa WITH sa.question = q")
            .getResultList();
        Assert.assertEquals(4, l.size());
        
        em.close();
    }
    
    @Test
    public void testLeftJoinWhere() {
        EntityManager em = emf.createEntityManager();
        
        List l = em.createQuery(
            "SELECT DISTINCT s.id, q.id, sa.answer "
                + "FROM Student s, Question q "
                + "LEFT JOIN s.studentAnswers sa "
                + "WHERE sa.question = q")
            .getResultList();
        Assert.assertEquals(4, l.size());
        
        em.close();
    }
}
