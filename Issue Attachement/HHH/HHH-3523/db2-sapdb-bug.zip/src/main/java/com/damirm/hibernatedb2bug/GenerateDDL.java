package com.damirm.hibernatedb2bug;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.LocalSessionFactoryBean;

public class GenerateDDL
{
    private ApplicationContext ctx;

    public static void main(String[] args) throws IOException
    {
    	GenerateDDL app = new GenerateDDL("classpath:applicationContext.xml");
    	app.run();
    }
    
    public GenerateDDL(String appContext)
    {
    	this.ctx = new ClassPathXmlApplicationContext(appContext);
    }
    
    public void run() throws IOException 
    {
        generateSchema(org.hibernate.dialect.HSQLDialect.class, "hsqldb");
        generateSchema(org.hibernate.dialect.Oracle9iDialect.class, "oracle");
        generateSchema(org.hibernate.dialect.DerbyDialect.class, "derby");
        generateSchema(org.hibernate.dialect.MySQL5Dialect.class, "mysql5");
        generateSchema(org.hibernate.dialect.SQLServerDialect.class, "mssql");
        generateSchema(org.hibernate.dialect.PostgreSQLDialect.class, "pgsql");
        generateSchema(org.hibernate.dialect.SAPDBDialect.class, "sapdb");
        generateSchema(org.hibernate.dialect.DB2Dialect.class, "db2");
    }
    
    @SuppressWarnings("unchecked")
    public void generateSchema(Class dialect, String prefix) throws IOException
    {
        LocalSessionFactoryBean lsf = (LocalSessionFactoryBean) ctx.getBean("&sessionFactory");
        Configuration config = lsf.getConfiguration();
        config.setProperty("hibernate.dialect", dialect.getName());
        config.setProperty("hibernate.format.sql", "true");
        config.setProperty("hibernate.show_sql", "false");
        SchemaExport export = new SchemaExport(config);
        export.setOutputFile("target/" + prefix + "-ddl.sql");
        export.setFormat(true);
        export.setDelimiter(";");
        export.create(true, false);
        cleanFile("target/" + prefix + "-ddl.sql");
    }

    private void cleanFile(String fileName) throws IOException
    {
    	String lineEnd = System.getProperty("line.separator");
        File f = new File(fileName);
        FileInputStream fis = new FileInputStream(f);
        InputStreamReader isr = new InputStreamReader(fis);
        BufferedReader br = new BufferedReader(isr);
        String line = br.readLine();
        ArrayList<String> lines = new ArrayList<String>();
        while (line != null)
        {
            lines.add(line);
            line = br.readLine();
        }
        br.close();
        FileOutputStream fos = new FileOutputStream(f);
        OutputStreamWriter osw = new OutputStreamWriter(fos);
        for (String string: lines)
        {
            osw.write(string);
            osw.write(lineEnd);
        }
        osw.close();
    }
}
