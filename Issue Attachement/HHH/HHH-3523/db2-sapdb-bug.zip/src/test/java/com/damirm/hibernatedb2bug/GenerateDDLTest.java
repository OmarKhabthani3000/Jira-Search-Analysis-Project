package com.damirm.hibernatedb2bug;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;


/**
 * Unit test for {@link GenerateDDL}.
 */
public class GenerateDDLTest 
{
	private static GenerateDDL app;
	
	@BeforeClass
	public static void setUpClass() 
	{
		app = new GenerateDDL("classpath:applicationContext.xml");
        assertNotNull(app);
	}

	@Test
    public void testHSQL() throws Exception
    {
        app.generateSchema(org.hibernate.dialect.HSQLDialect.class, "hsqldb");
    }

	@Test
    public void testOracle9i() throws Exception
    {
        app.generateSchema(org.hibernate.dialect.Oracle9iDialect.class, "oracle");
    }

	@Test
    public void testDerby() throws Exception
    {
        app.generateSchema(org.hibernate.dialect.DerbyDialect.class, "derby");
    }

	@Test
    public void testMySQL5() throws Exception
    {
        app.generateSchema(org.hibernate.dialect.MySQL5Dialect.class, "mysql5");
    }

	@Test
    public void testSQLServer() throws Exception
    {
        app.generateSchema(org.hibernate.dialect.SQLServerDialect.class, "mssql");
    }

	@Test
    public void testPostgreSQL() throws Exception
    {
        app.generateSchema(org.hibernate.dialect.PostgreSQLDialect.class, "pgsql");
    }

	@Test
    public void testSAPDB() throws Exception
    {
        app.generateSchema(org.hibernate.dialect.SAPDBDialect.class, "sapdb");
    }

	@Test
    public void testDB2() throws Exception
    {
        app.generateSchema(org.hibernate.dialect.DB2Dialect.class, "db2");
    }
}
