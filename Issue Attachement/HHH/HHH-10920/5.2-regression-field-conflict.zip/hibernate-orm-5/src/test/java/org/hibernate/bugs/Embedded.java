package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Embedded {
	private String type;
	private double arg;

	@Column(name = "EMBEDDEDTYPE_", nullable = false, length = 10)
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Column(name = "ARG_")
	public double getArg() {
		return arg;
	}

	public void setArg(double arg) {
		this.arg = arg;
	}
}
