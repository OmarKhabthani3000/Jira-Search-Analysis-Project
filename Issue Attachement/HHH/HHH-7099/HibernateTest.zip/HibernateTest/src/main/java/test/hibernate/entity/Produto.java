/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test.hibernate.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 *
 * @author Wilson
 */
@Entity
@Table(name = "produto")
@NamedQueries({
    @NamedQuery(name = "Produto.findAll", query = "SELECT p FROM Produto p")})
public class Produto implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ProdutoPK produtoPK;

    public Produto() {
    }

    public Produto(ProdutoPK produtoPK) {
        this.produtoPK = produtoPK;
    }

    public Produto(String departamento, int classificacao, String nome, int quantidade, String marca, String modelo, int preco, String descricao) {
        this.produtoPK = new ProdutoPK(departamento, classificacao, nome, quantidade, marca, modelo, preco, descricao);
    }

    public ProdutoPK getProdutoPK() {
        return produtoPK;
    }

    public void setProdutoPK(ProdutoPK produtoPK) {
        this.produtoPK = produtoPK;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (produtoPK != null ? produtoPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Produto)) {
            return false;
        }
        Produto other = (Produto) object;
        if ((this.produtoPK == null && other.produtoPK != null) || (this.produtoPK != null && !this.produtoPK.equals(other.produtoPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "test.hibernate.entity.Produto[ produtoPK=" + produtoPK + " ]";
    }
    
}
