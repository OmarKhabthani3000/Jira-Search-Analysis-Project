/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test.hibernate.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Wilson
 */
@Embeddable
public class ProdutoPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "departamento")
    private String departamento;
    @Basic(optional = false)
    @NotNull
    @Column(name = "classificacao")
    private int classificacao;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "nome")
    private String nome;
    @Basic(optional = false)
    @NotNull
    @Column(name = "quantidade")
    private int quantidade;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "marca")
    private String marca;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "modelo")
    private String modelo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "preco")
    private int preco;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "descricao")
    private String descricao;

    public ProdutoPK() {
    }

    public ProdutoPK(String departamento, int classificacao, String nome, int quantidade, String marca, String modelo, int preco, String descricao) {
        this.departamento = departamento;
        this.classificacao = classificacao;
        this.nome = nome;
        this.quantidade = quantidade;
        this.marca = marca;
        this.modelo = modelo;
        this.preco = preco;
        this.descricao = descricao;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public int getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(int classificacao) {
        this.classificacao = classificacao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getPreco() {
        return preco;
    }

    public void setPreco(int preco) {
        this.preco = preco;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (departamento != null ? departamento.hashCode() : 0);
        hash += (int) classificacao;
        hash += (nome != null ? nome.hashCode() : 0);
        hash += (int) quantidade;
        hash += (marca != null ? marca.hashCode() : 0);
        hash += (modelo != null ? modelo.hashCode() : 0);
        hash += (int) preco;
        hash += (descricao != null ? descricao.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ProdutoPK)) {
            return false;
        }
        ProdutoPK other = (ProdutoPK) object;
        if ((this.departamento == null && other.departamento != null) || (this.departamento != null && !this.departamento.equals(other.departamento))) {
            return false;
        }
        if (this.classificacao != other.classificacao) {
            return false;
        }
        if ((this.nome == null && other.nome != null) || (this.nome != null && !this.nome.equals(other.nome))) {
            return false;
        }
        if (this.quantidade != other.quantidade) {
            return false;
        }
        if ((this.marca == null && other.marca != null) || (this.marca != null && !this.marca.equals(other.marca))) {
            return false;
        }
        if ((this.modelo == null && other.modelo != null) || (this.modelo != null && !this.modelo.equals(other.modelo))) {
            return false;
        }
        if (this.preco != other.preco) {
            return false;
        }
        if ((this.descricao == null && other.descricao != null) || (this.descricao != null && !this.descricao.equals(other.descricao))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "test.hibernate.entity.ProdutoPK[ departamento=" + departamento + ", classificacao=" + classificacao + ", nome=" + nome + ", quantidade=" + quantidade + ", marca=" + marca + ", modelo=" + modelo + ", preco=" + preco + ", descricao=" + descricao + " ]";
    }
    
}
