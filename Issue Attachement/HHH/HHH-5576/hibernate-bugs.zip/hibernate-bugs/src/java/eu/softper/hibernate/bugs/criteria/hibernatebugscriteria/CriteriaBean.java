/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package eu.softper.hibernate.bugs.criteria.hibernatebugscriteria;

import java.util.Date;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;

/**
 *
 * @author rsmogura
 */
@Stateless
public class CriteriaBean {

    @PersistenceContext(unitName="emq")
    private EntityManager em;

    public void queryComposite() {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery query =
            cb.createQuery(SomeEntity.class);
        Root<SomeEntity> root = query.from(SomeEntity.class);
        CriteriaBuilder.In<CompositeId> in = cb.in(root.<CompositeId>get("id"));
        query.where(in.value(new CompositeId()).value(new CompositeId()));

        em.createQuery(query).getResultList();
    }

    public void queryIntegerNotPrepared() {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery query =
            cb.createQuery(SomeEntity.class);
        Root<SomeEntity> root = query.from(SomeEntity.class);

        query.where(cb.equal(root.get("integerVal"), 1));

        em.createQuery(query).getResultList();
    }

    public void queryDateBytea() {
        CompositeId id = new CompositeId();
        id.setId1(new Date());
        id.setId2((int) (1000 * Math.random()));
        SomeEntity se = new SomeEntity();
        se.setDateVal(new Date());
        se.setId(id);
        em.persist(se);
        em.flush();
        em.refresh(se);

        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery query =
            cb.createQuery(SomeEntity.class);
        Root<SomeEntity> root = query.from(SomeEntity.class);
        query = query.select(cb.count(root));
        
        Path dateVal = root.<Date>get("dateVal");
        query.where(cb.equal(dateVal, se.getDateVal()));
        TypedQuery q = em.createQuery(query);
        q.getResultList();
    }
}
