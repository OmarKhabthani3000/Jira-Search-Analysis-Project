/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package eu.softper.hibernate.bugs.criteria.hibernatebugscriteria;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author rsmogura
 */
@Embeddable
public class CompositeId extends ComposieIdBase implements Serializable{
    private Date id1;

    @Column
    @Temporal(TemporalType.TIMESTAMP)
    public Date getId1() {
        return id1;
    }

    public void setId1(Date id1) {
        this.id1 = id1;
    }

    @Column
    @Override
    public int getId2() {
        return super.getId2();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final CompositeId other = (CompositeId) obj;
        if (this.id1 != other.id1 && (this.id1 == null || !this.id1.equals(other.id1))) {
            return false;
        }
        if (this.id2 != other.id2) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 31 * hash + (this.id1 != null ? this.id1.hashCode() : 0);
        hash = 31 * hash + this.id2;
        return hash;
    }

    

}
