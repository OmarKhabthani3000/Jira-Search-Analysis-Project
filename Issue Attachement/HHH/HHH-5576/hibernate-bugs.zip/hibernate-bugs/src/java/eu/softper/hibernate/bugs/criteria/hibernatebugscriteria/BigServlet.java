/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package eu.softper.hibernate.bugs.criteria.hibernatebugscriteria;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author rsmogura
 */
@WebServlet(urlPatterns={"/bugs/*"})
public class BigServlet extends HttpServlet{
    @EJB
    private CriteriaBean bean;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int testCase = Integer.valueOf(req.getPathInfo().substring(1));

        switch (testCase) {
            case 1:
                bean.queryComposite();
                break;
            case 2:
                bean.queryDateBytea();
                break;
            case 3:
                bean.queryIntegerNotPrepared();
        }
    }
}
