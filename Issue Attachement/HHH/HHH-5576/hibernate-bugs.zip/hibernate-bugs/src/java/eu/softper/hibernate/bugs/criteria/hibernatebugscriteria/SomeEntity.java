/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package eu.softper.hibernate.bugs.criteria.hibernatebugscriteria;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author rsmogura
 */
@Entity
public class SomeEntity implements Serializable {
    private CompositeId id;

    private int integerVal;

    private Date dateVal;

    @EmbeddedId
    public CompositeId getId() {
        return id;
    }

    public void setId(CompositeId id) {
        this.id = id;
    }

    @Temporal(TemporalType.DATE)
    public Date getDateVal() {
        return dateVal;
    }

    public void setDateVal(Date dateVal) {
        this.dateVal = dateVal;
    }

    public int getIntegerVal() {
        return integerVal;
    }

    public void setIntegerVal(int integerVal) {
        this.integerVal = integerVal;
    }


}
