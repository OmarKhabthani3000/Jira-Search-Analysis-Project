
package org.hibernate.bugs;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java
 * Persistence API.
 */
public class JPAUnitTestCase {

  private EntityManagerFactory entityManagerFactory;

  @Before
  public void init() {
    entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
  }

  @After
  public void destroy() {
    entityManagerFactory.close();
  }

  @Test
  public void test_that_will_fail_because_of_join_table() throws Exception {
    EntityManager entityManager = entityManagerFactory.createEntityManager();
    entityManager.getTransaction().begin();

    // we try to persist with a null b field in entityA.
    EntityA entityA = new EntityA();
    entityManager.persist(entityA);


    entityManager.getTransaction().commit();
    entityManager.close();
  }

  @Test
  public void test_that_will_pass_because_of_join_column() throws Exception {
    EntityManager entityManager = entityManagerFactory.createEntityManager();
    entityManager.getTransaction().begin();

    // we try to persist with a null b field in entityC which is the same conceptually as entityA but uses fk column in own table.
    EntityC entityC = new EntityC();
    entityManager.persist(entityC);


    entityManager.getTransaction().commit();
    entityManager.close();
  }
}
