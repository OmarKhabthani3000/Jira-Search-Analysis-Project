/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testifxjdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author N.Metzger
 */
public class TestIFXJdbc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Class.forName("com.informix.jdbc.IfxDriver");
            Connection conn = DriverManager.getConnection("jdbc:informix-sqli://ip:1525/orissa:INFORMIXSERVER=fr_on", "user", "pass");
            String query = "select case when testentity0_.id is not null then trim(BOTH"
                + " from (?||?)) else trim(BOTH from (?||?)) end as col_0_0_, trim(BOTH from (?||?)) as col_1_0_"
                + " from test testentity0_";
            final PreparedStatement preparedStatement = conn.prepareStatement(query);
        try {
            preparedStatement.setString(1, ".");
            preparedStatement.setString(2, "Test1   ");
            preparedStatement.setString(3, ".");
            preparedStatement.setString(4, "Test2   ");
            preparedStatement.setString(5, ".");
            preparedStatement.setString(6, "Test3   ");

            final ResultSet resultSet = preparedStatement.executeQuery();
            try {
                resultSet.next();
                System.out.println("Case value: '" +resultSet.getString(1)+"'");
                System.out.println("Case value length: " +resultSet.getString(1).length());
                System.out.println("Without case: '" +resultSet.getString(2)+"'");
                System.out.println("Without case value length: " +resultSet.getString(2).length());
            } finally {
                resultSet.close();
            }
        } finally {
            preparedStatement.close();
        }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
