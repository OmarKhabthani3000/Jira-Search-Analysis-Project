package org.hibernate.bugs;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM,
 * using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh123Test() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Object[]> c = cb.createQuery(Object[].class);
        Root<TestEntity> r = c.from(TestEntity.class);
        c.multiselect(cb.selectCase().when(cb.isNotNull(r.get("id")), cb.trim(cb.concat(".", cb.literal("Test   ")))).otherwise(r.get("name")), cb.trim(cb.concat(".", cb.literal("Test   "))));
        entityManager.createNativeQuery("insert into TEST_HHH_10848 values(1,'OLOLO')").executeUpdate();
        List<Object[]> result = entityManager.createQuery(c).getResultList();
        if (!result.isEmpty()) {
            for (Object[] o : result) {
                System.out.println("With case: '" + o[0] + "'; length: " + o[0].toString().length());
                System.out.println("Without case: '" + o[1] + "'; length: " + o[0].toString().length());
            }
        }
        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
