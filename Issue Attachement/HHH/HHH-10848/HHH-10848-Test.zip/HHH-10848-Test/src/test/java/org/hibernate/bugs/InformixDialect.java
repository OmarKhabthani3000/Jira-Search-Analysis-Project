package org.hibernate.bugs;

public class InformixDialect extends org.hibernate.dialect.InformixDialect {

    @Override
    public String getDropSequenceString(String sequenceName) {
        return "drop sequence " + sequenceName;
    }
}
