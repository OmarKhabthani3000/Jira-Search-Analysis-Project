Database
--------
- SQL Server 2005
- Restore database from backup

Configuration
-------------
-Update the context.xml file to match your environment

Source Code
-----------
- Copied from SpringSource Tool Suite workspace, includes project settings
- Uses Maven for dependencies

To Reproduce
------------
- c3p0 logging has been enabled
- Click the link "Click here to test"
- Click the "Cancel" button
- Repeat the process and you will see in the c3p0 logs that the number of connections continues to grow until
	it runs out of connections in the pool