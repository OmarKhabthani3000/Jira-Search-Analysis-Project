package com.test_case.controller.util;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ErrorController
{
	@RequestMapping("/dashboard/error")
	public void show(@RequestParam("errorId") int errorId, ModelMap model)
	{
		String errMsg = "";
		
		switch (errorId)
		{
		case 1:
			errMsg = "The session has timed out, please click <a href =\"login.jsp\"><u>here</u></a> to log back in";
			break;
		case 2:
			errMsg = "The request has bad syntax or was inherently impossible to be satisfied";
			break;
		case 3:
			errMsg = "You have reached an unauthorized page.";
			break;
		case 4:
			errMsg = "Payment is required.";
			break;
		case 5:
			errMsg = "This is a forbidden request.";
			break;
		case 6:
			errMsg = "The given URI was not found.";
			break;
		case 7:
			errMsg = "There has been an internal error in the system.";
			break;
		case 8:
			errMsg = "This operation is not implemented";
			break;
		case 9:
			errMsg = "The service is temporarily overloaded.  Please try again later.";
			break;
		case 10:
			errMsg = "The gateway has timed out.  Please try again.";
			break;
		case 11:
			errMsg = "There has been an error in the system.";
			break;
		}
		
		model.addAttribute("errMsg", errMsg);
	}
}