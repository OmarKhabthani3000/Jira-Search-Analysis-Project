package com.test_case.controller.dashboard;

import javax.servlet.ServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class RootController
{
	@RequestMapping(value = "/", method = RequestMethod.GET)
	protected View show()
	{
		return new RedirectView("j_spring_security_logout");
	}
	
	@RequestMapping("/dashboard/keepAlive")
	public void keepAlive(ServletResponse response) throws Exception
	{
		response.getWriter().write("OK");
		response.getWriter().close();
	}
	
	@RequestMapping("/dashboard/landing")
	public String landing(ServletResponse response) throws Exception
	{
		return "landingPage";
	}
}
