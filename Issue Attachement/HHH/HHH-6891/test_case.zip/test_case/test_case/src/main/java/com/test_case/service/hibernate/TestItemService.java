package com.test_case.service.hibernate;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Service;

import com.test_case.model.hibernate.TestItem;

@Service
public class TestItemService
{
	@PersistenceContext
	private EntityManager em;
	
	public TestItem get(int id)
	{
		return em.find(TestItem.class, id);
	}
}
