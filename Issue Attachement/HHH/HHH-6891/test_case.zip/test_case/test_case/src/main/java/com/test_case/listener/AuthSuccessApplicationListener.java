package com.test_case.listener;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Component;

@Component
public class AuthSuccessApplicationListener implements ApplicationListener<AuthenticationSuccessEvent>
{
	private static final String curClass = AuthSuccessApplicationListener.class.getSimpleName() + ".";
	private static final Logger LOGGER = Logger.getLogger(AuthSuccessApplicationListener.class);

	@Override
	public void onApplicationEvent(AuthenticationSuccessEvent appEvt)
	{
		String method = curClass + "onApplicationEvent(): ";

		// Get current user
		Authentication curAuth = appEvt.getAuthentication();
		Object source = appEvt.getSource();

		LOGGER.info(method + "sourceObj = [" + source + "]");

		User authUser = (User) curAuth.getPrincipal();
		String curUserName = authUser.getUsername();

		try
		{
			//this.userServ.updateUserLoginTime(curUserName);
		}
		catch (RuntimeException excpt)
		{
			LOGGER.error(method + "There was an error in updating a user's last login!");
			excpt.printStackTrace();
		}

		LOGGER.info(method + "*********===========================");
		LOGGER.info(method + "********* User, " + curUserName + " just logged in.");
		LOGGER.info(method + "*********===========================");
	}
}
