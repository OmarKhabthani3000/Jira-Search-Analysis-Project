package com.test_case.listener;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionListener;
import javax.servlet.http.HttpSessionEvent;

import org.apache.log4j.Logger;

public class SessionListener implements HttpSessionListener
{
	private static final String curClass = "SessionListener.";
	private static final Logger LOGGER = Logger.getLogger(SessionListener.class);

	@Override
	public void sessionCreated(HttpSessionEvent sessionEvt)
	{
		String method = curClass + "sessionCreated(): ";
		HttpSession session = sessionEvt.getSession();
		String sessionIDCreated = session.getId();
		
		LOGGER.info(method + "The created session's id is [" + sessionIDCreated + "]");
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent sessionEvt)
	{
		String method = curClass + "sessionDestroyed(): ";
		HttpSession session = sessionEvt.getSession();
		String sessionIDDestroyed = session.getId();
		
		LOGGER.info(method + "The destroyed session's id is [" + sessionIDDestroyed + "]");
	}
}