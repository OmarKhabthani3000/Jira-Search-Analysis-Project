package org.hibernate.bugs.many2many;

import java.util.List;

import org.hibernate.*;
import org.hibernate.cfg.*;
import org.hibernate.criterion.Restrictions;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.*;

public class Many2Many2ndLevelCacheTest extends BaseCoreFunctionalTestCase {

	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
				A.class,
				B.class
		};
	}

	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );

		configuration.setProperty( "hibernate.cache.use_query_cache", "true" );
		configuration.setProperty( "hibernate.cache.use_second_level_cache", "true" );
	}

	@Test
	public void many2ManyMultipleSessionsTest() throws Exception {

		Session s = openSession();
		Transaction tx = s.beginTransaction();
		A _a1 = new A();
		s.save(_a1);
		A _a2 = new A();
		s.save(_a2);
		B _b = new B();
		s.save(_b);
		_a1.addB(_b);
		tx.commit();
		s.close();

		s = openSession();
		tx = s.beginTransaction();
		Criteria crit = s.createCriteria(A.class);
		crit.createAlias("bs", "_b").add(Restrictions.eq("_b.id", _b.getId()));
		crit.setCacheable(true);
		List list = crit.list();
		Assert.assertEquals(1, list.size());
		tx.commit();
		s.close();

		s = openSession();
		tx = s.beginTransaction();
		A a2 = s.get(A.class, _a2.getId());
		B b	= s.get(B.class, _b.getId());
		a2.addB(b);
		tx.commit();
		s.close();

		s = openSession();
		tx = s.beginTransaction();
		crit = s.createCriteria(A.class);
		crit.createAlias("bs", "_b").add(Restrictions.eq("_b.id", _b.getId()));
		crit.setCacheable(true);
		list = crit.list();
		Assert.assertEquals(2, list.size());
		tx.commit();
		s.close();
	}



	@Test
	public void many2manyNoFlushTest() throws Exception {

		Session s = openSession();
		Transaction tx = s.beginTransaction();

		A a1 = new A();
		s.save(a1);
		A a2 = new A();
		s.save(a2);
		B b = new B();
		s.save(b);

		a1.addB(b);

		Criteria crit = s.createCriteria(A.class);
		crit.createAlias("bs", "_b").add(Restrictions.eq("_b.id", b.getId()));
		crit.setCacheable(true);
		List list = crit.list();

		Assert.assertEquals(1, list.size());

		a2.addB(b);

		// Test passes with any of these calls
		//a1.setName("dummy");
		//s.flush();

		crit = s.createCriteria(A.class);
		crit.createAlias("bs", "_b").add(Restrictions.eq("_b.id", b.getId()));
		crit.setCacheable(true);

		list = crit.list();

		Assert.assertEquals(2, list.size());

		tx.commit();
		s.close();
	}

}
