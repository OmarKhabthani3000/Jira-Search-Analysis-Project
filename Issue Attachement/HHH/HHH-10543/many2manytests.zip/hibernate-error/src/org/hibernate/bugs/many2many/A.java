package org.hibernate.bugs.many2many;

import java.util.*;

import javax.persistence.*;


@Entity
public class A
{
	@Id
	@GeneratedValue
	private long id;

	private String name;

	@ManyToMany(cascade = CascadeType.ALL)
	private Set<B> bs = new HashSet<B>();

	public long getId()
	{
		return id;
	}

	public void addB(B b)
	{
		bs.add(b);
	}

	public void removeB(B b)
	{
		bs.remove(b);
	}

	public Set<B> getBs() {
		return bs;
	}

	public void setName(String name)
	{
		this.name = name;

	}
}
