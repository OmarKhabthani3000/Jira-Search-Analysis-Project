package org.hibernate.bugs.many2many;

import java.util.*;

import javax.persistence.*;

@Entity
public class B
{
	@Id
	@GeneratedValue
	private long id;

	@ManyToMany
	private Set<A> as = new HashSet<A>();

	public long getId()
	{
		return id;
	}

	public void addB(A b)
	{
		as.add(b);
	}

	public void removeB(A b)
	{
		as.remove(b);
	}

	public Set<A> getAs() {
		return as;
	}
}
