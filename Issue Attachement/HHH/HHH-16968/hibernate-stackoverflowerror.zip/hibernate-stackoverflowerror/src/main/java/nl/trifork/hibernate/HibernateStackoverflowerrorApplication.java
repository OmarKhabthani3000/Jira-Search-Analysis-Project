package nl.trifork.hibernate;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Transactional;

@SpringBootApplication
public class HibernateStackoverflowerrorApplication implements CommandLineRunner {

    @PersistenceContext EntityManager entityManager;

    public static void main(String[] args) {
        SpringApplication.run(HibernateStackoverflowerrorApplication.class, args);
    }

    @Transactional
    @Override
    public void run(String... args) throws Exception {
        entityManager.unwrap(Session.class).byNaturalId(Parent.class).using("name", "someName").load();
    }
}
