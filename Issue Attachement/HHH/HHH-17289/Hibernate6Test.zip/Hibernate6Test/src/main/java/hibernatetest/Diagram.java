package hibernatetest;

import java.io.Serializable;
import java.util.Objects;
import java.util.SortedSet;
import java.util.TreeSet;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.SortNatural;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class Diagram implements Serializable {
    
    private static final long serialVersionUID = -5412503864464287451L;

    @Id
    @GeneratedValue
    long id;

    @Column
    String name;
    
    @OneToOne(optional = false)
    @JoinColumn(nullable = false)
    Contract contract;

    @OneToMany(mappedBy = "diagram", cascade = CascadeType.ALL, orphanRemoval = true)
    @SortNatural
    SortedSet<Entry> entries = new TreeSet<>();

    public Diagram() {}

    public Diagram(String name, Contract contract) {
        this.name = name;
        this.contract = contract;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof final Diagram other)) {
            return false;
        }
        return Objects.equals(this.name, other.name);
    }
}