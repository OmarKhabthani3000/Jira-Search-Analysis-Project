package hibernatetest;

import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.junit.jupiter.api.Test;

public class NonUniqueResultExceptionTest {

    @Test
    public void test() {
        final SessionFactory sessionFactory = newSessionFactory();

        final long contractId;

        try (final Session session = sessionFactory.openSession()) {
            final Transaction tx = session.beginTransaction();
            final Contract contract = new Contract("Contract");
            session.persist(contract);
            session.flush();
            tx.commit();
            contractId = contract.id;
        }

        final long diagramId;

        try (final Session session = sessionFactory.openSession()) {
            final Transaction tx = session.beginTransaction();
            final Contract contract = session.get(Contract.class, contractId);
            final Diagram diagram = new Diagram("Diagram", contract);
            contract.diagram = diagram;
            session.flush();
            tx.commit();
            diagramId = diagram.id;
        }

        try (final Session session = sessionFactory.openSession()) {
            final Transaction tx = session.beginTransaction();
            final Diagram diagram = session.get(Diagram.class, diagramId);
            final Entry entry1 = new Entry("Entry 1", diagram);
            final Entry entry2 = new Entry("Entry 2", diagram);
            diagram.entries.add(entry1);
            diagram.entries.add(entry2);
            session.flush();
            tx.commit();
        }

        sessionFactory.getCache().evictAllRegions();

        try (final Session session = sessionFactory.openSession()) {
            final Transaction tx = session.beginTransaction();
            session.get(Contract.class, contractId);
            tx.commit();
        }

        // sessionFactory.getCache().evictAllRegions(); // #1

        try (final Session session = sessionFactory.openSession()) {
            final Transaction tx = session.beginTransaction();
            // session.get(Diagram.class, diagramId); // #2
            final Query<Diagram> q = session.createQuery("select distinct d from Diagram d inner join fetch d.entries e where d.id = :id", Diagram.class);
            q.setParameter("id", diagramId);
            final Diagram diagram = q.uniqueResult();
            System.out.println(String.format("Loaded by query: %s (entry count: %s)", diagram.name, diagram.entries.size()));
            tx.commit();
        }

    }

    protected SessionFactory newSessionFactory() {
        final Properties properties = new Properties();
        properties.put("hibernate.hbm2ddl.auto", "create");
        properties.put("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        properties.put("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        properties.put("hibernate.connection.url", "jdbc:hsqldb:mem:tsg");
        properties.put("hibernate.connection.username", "sa");
        properties.put("hibernate.connection.password", "");
        properties.put("hibernate.cache.use_second_level_cache", "true");
        properties.put("hibernate.cache.use_query_cache", "true");
        properties.put("hibernate.cache.region.factory_class", "jcache");
        properties.put("hibernate.cache.use_structured_entries", "true");
        properties.put("hibernate.cache.auto_evict_collection_cache", "true");
        properties.put("hibernate.javax.cache.provider", "org.ehcache.jsr107.EhcacheCachingProvider");
        properties.put("hibernate.javax.cache.uri", "ehcache.xml");
        properties.put("hibernate.javax.cache.missing_cache_strategy", "fail");
        properties.put("hibernate.show_sql", "true");
        properties.put("hibernate.format_sql", "true");
        properties.put("hibernate.highlight_sql", "true");

        return new Configuration().addProperties(properties)
                                  .addAnnotatedClass(Contract.class)
                                  .addAnnotatedClass(Diagram.class)
                                  .addAnnotatedClass(Entry.class)
                                  .buildSessionFactory(new StandardServiceRegistryBuilder().applySettings(properties).build());
    }
}
