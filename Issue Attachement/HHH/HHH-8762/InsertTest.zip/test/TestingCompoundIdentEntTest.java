/*
 * Copyright (C) 2013 Payment Alliance International. All Rights Reserved.
 * 
 * This software is the proprietary information of Payment Alliance International.
 * Use is subject to license terms.
 * 
 * Name: TestingCompoundIdentEntTest.java 
 * Created: Dec 2, 2013 12:57:47 PM
 * Author: Chuck Lowery <chuck.lowery @ gopai.com>
 */

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.Test;
import org.junit.Before;

/**
 *
 * @author Chuck Lowery <chuck.lowery @ gopai.com>
 */
public class TestingCompoundIdentEntTest {
    
    public TestingCompoundIdentEntTest() {
    }
    
    EntityManagerFactory emf;

    @Before
    public void setup() {
        emf = Persistence.createEntityManagerFactory("PU");

    }

    @Test
    public void testInsert() {

        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        TestingCompoundIdentEnt ent = new TestingCompoundIdentEnt();

        ent.setPrimaryId(1);
        ent.setSecondaryId(1);
        em.merge(ent);
        em.getTransaction().commit();
    }
}
