CREATE TABLE TestingCompoundIdent (
	PrimaryID INT IDENTITY,
	SecondaryID INT,
	PRIMARY KEY (PrimaryID, SecondaryID)
)
