/*
 * Copyright (C) 2013 Payment Alliance International. All Rights Reserved.
 * 
 * This software is the proprietary information of Payment Alliance International.
 * Use is subject to license terms.
 * 
 * Name: TestingCompoundIdentEnt.java 
 * Created: Dec 2, 2013 12:57:15 PM
 * Author: Chuck Lowery <chuck.lowery @ gopai.com>
 */

/**
 *
 * @author Chuck Lowery <chuck.lowery @ gopai.com>
 */
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TestingCompoundIdent", schema = "dbo")
public class TestingCompoundIdentEnt implements java.io.Serializable {

    private Integer primaryId;
    private Integer secondaryId;

    public TestingCompoundIdentEnt() {
    }

    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "PrimaryID")
    public Integer getPrimaryId() {
        return primaryId;
    }

    public void setPrimaryId(Integer primaryId) {
        this.primaryId = primaryId;
    }

    @Id
    @Column(name = "SecondaryID")
    public Integer getSecondaryId() {
        return secondaryId;
    }

    public void setSecondaryId(Integer secondaryId) {
        this.secondaryId = secondaryId;
    }
}
