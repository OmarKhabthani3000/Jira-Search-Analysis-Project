 
package db;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Persistence;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import static org.assertj.core.api.Assertions.assertThat;
import org.flywaydb.core.Flyway;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class JoinOnTest {

    private static final int EXPECTED_ID = 2;

    @BeforeClass
    public void beforeClass() {
        var flyway = new Flyway();
        flyway.setLocations("/META-INF/db");
        flyway.setDataSource("jdbc:hsqldb:mem:jpa_test", "admin", "admin");
        flyway.migrate();
    }


    @Test
    public void joinOn() {
        var emf = Persistence.createEntityManagerFactory("hb_pu");
        //given
        EntityManager em = emf.createEntityManager();
        var cb = em.getCriteriaBuilder();
        //when
        em.getTransaction().begin();
        CriteriaQuery<Secondary> query = cb.createQuery(Secondary.class);
        Root<Primary> root = query.from(Primary.class);
        var secondaryJoin = root.<Primary, Secondary>join("secondary");
        secondaryJoin.on(cb.isTrue(secondaryJoin.get("active")));
        query.select(secondaryJoin);
        var secondary = em.createQuery(query).getSingleResult();
        //then
        assertThat(secondary.getId()).isEqualTo(EXPECTED_ID);
        em.getTransaction().rollback();
        em.close();
        emf.close();
    }


}