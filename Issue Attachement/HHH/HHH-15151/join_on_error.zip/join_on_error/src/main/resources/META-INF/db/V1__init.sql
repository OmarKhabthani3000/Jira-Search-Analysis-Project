
create schema test;

create table test.t_secondary (
    id integer primary key,
    active boolean not null
);

create table test.t_primary (
    id integer primary key,
    t_secondary_id integer not null,
    constraint t_primary_t_primary_id_fkey foreign key(t_secondary_id)
        references test.t_secondary(id) match simple
        on update no action on delete no action
);

insert into test.t_secondary(id, active) values (1, false), (2, true);
insert into test.t_primary(id, t_secondary_id) values (1, 1);
