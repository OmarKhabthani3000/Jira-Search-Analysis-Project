/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package db;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(schema = "test", name = "t_secondary")
public class Secondary implements Serializable {

    @Id
    private int id;
    boolean active;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Secondary secondary = (Secondary) o;
        return id == secondary.id;
    }

    @Override public int hashCode() {
        return Objects.hash(id);
    }
}
