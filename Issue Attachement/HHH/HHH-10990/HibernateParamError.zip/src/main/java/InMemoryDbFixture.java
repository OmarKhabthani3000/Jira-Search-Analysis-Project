package main.java;



import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class InMemoryDbFixture {

    private SessionFactory sessionFactory;

    @SuppressWarnings("deprecation")
    public void createSessionFactory() {
        Configuration cfg = new Configuration();
        sessionFactory = cfg.configure().buildSessionFactory();
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}
