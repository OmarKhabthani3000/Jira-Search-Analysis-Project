package main.java;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.xml.DOMConfigurator;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.BigIntegerType;

//Hibernate JPA With H2 Example

public class TestMain {

    SessionFactory sessionFac = null;
    
    public static void main(String[] args) {
        DOMConfigurator.configureAndWatch("log4j.xml");
        TestMain example = new TestMain();
        InMemoryDbFixture inMemdbFix = new InMemoryDbFixture();
        inMemdbFix.createSessionFactory();
        example.sessionFac = inMemdbFix.getSessionFactory();
        
        System.out.println("After System start ");
        example.listStudent();
        
        Student student1 = new Student();
        student1.setStudentId(new StudentId(1, "Anderson", "Matrix"));
        student1.setStudentName("Mr");
        student1.setObjektGruppen(1L);
        student1.setSemester(10);
        example.saveStudent(student1);
        
        Student student2 = new Student();
        student2.setStudentId(new StudentId(1, "Who", "Erde"));
        student2.setStudentName("Dr.");
        student2.setObjektGruppen(1L);
        student2.setSemester(12);
        example.saveStudent(student2);
        
        System.out.println("After Sucessfully insertion ");
        example.listStudent();
        
        System.out.println("With Query ");
        example.getFromSQLQuery(inMemdbFix, student1);
        example.getFromSQLQuery(inMemdbFix, student2);
    }

    public List<Student> getFromSQLQuery(InMemoryDbFixture inMemdbFix, Student student) {
        Session session = sessionFac.getCurrentSession();
        Transaction tx = session.beginTransaction();
        session.enableFilter("objektBerechtigungFilter").setParameter("gruppen", new BigIntegerType().fromString("1"));
        try {

            Criteria query = session.createCriteria(Student.class);
            query.add(Restrictions.eq("studentId", student.getStudentId()));
            
            DetachedCriteria inner = DetachedCriteria.forClass(Student.class);
            inner.setProjection(Projections.max("semester"));
            inner.add(Restrictions.eq("studentId", student.getStudentId()));
            
            query.add(Property.forName("semester").eq(inner));
            
            final List<Student> list = new ArrayList<Student>();
            @SuppressWarnings("unchecked")
            List<Object> objList = query.list();
            System.out.print("Student found by Criteria: ");
            for (Object o : objList) {
                list.add((Student) o);
                System.out.println(((Student) o).getStudentName());
            }
            System.out.println();

            tx.commit();
            return list;

        } catch (Exception e) {
            tx.rollback();
            e.printStackTrace();
        } finally {
            if (session.isOpen()) {
                session.close();
            }
        }
        return null;
    }

    public Student saveStudent(Student student) {
        Session session = sessionFac.getCurrentSession();
        Transaction tx = sessionFac.getCurrentSession().beginTransaction();
        try {
            session.save(student);
            tx.commit();
        } catch (Exception e) {
            tx.rollback();
        }
        return student;
    }

    public void listStudent() {
        Session session = sessionFac.getCurrentSession();
        Transaction tx = session.beginTransaction();
        try {
            @SuppressWarnings("unchecked")
            List<Student> Students = session.createQuery("from Student").list();
            for (Iterator<Student> iterator = Students.iterator(); iterator.hasNext();) {
                Student student = (Student) iterator.next();
                System.out.print(student.getStudentName() + ", ");
                System.out.print(student.getStudentId().getName() + ", ");
                System.out.print(student.getStudentId().getMatnr() + ", ");
                System.out.println(student.getStudentId().getAdresse());
            }
            tx.commit();
        } catch (Exception e) {
            tx.rollback();
        }
    }
}