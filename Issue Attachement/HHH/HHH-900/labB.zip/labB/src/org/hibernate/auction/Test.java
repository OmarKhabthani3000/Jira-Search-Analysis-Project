package org.hibernate.auction;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import org.hibernate.auction.model.*;

import java.math.BigDecimal;
import java.util.*;

public class Test {

    private static SessionFactory sessionFactory;

    static {
        sessionFactory = new Configuration().configure().buildSessionFactory();
    }

    public static void main(String[] args) throws Exception {
        final Test app = new Test();

        // Create test data
        Session session = null;
        Transaction tx = null;
        try {
            session = sessionFactory.openSession();
            tx = session.beginTransaction();

            app.createTestData(session);

            tx.commit();
        } catch (HibernateException e) {
            tx.rollback();
            e.printStackTrace();
        } finally {
            if (session != null)
                session.close();
        }

        // Close the SessionFactory
        sessionFactory.close();
    }

    private void createTestData(Session session) throws HibernateException {

        // Categories
        Category cars = new Category("Cars");
		Category carsLuxury = new Category("Luxury Cars");
		cars.addChildCategory(carsLuxury);
		Category carsSUV = new Category("SUVs");
		cars.addChildCategory(carsSUV);

		session.save(cars);

        // Users
        User gavin = new User("Gavin", "King", "gavin", "abc123", "gavin@hibernate.org");
        gavin.setAddress(new Address("Foo", "12345", "Bar"));

        User christian = new User("Christian", "Bauer", "christian", "abc123", "christian@hibernate.org");
        christian.setAddress(new Address("Foo", "12345", "Bar"));

        User max = new User("Max", "Anderson", "max", "abc123", "max@hibernate.org");
        max.setAddress(new Address("Foo", "12345", "Bar"));

        session.save(gavin);
        session.save(christian);
        session.save(max);

        // BillingDetails
        BillingDetails ccOne = new CreditCard("Christian  Bauer", christian, "1234567890",
                                                CreditCardType.MASTERCARD, "10", "2005");
        BillingDetails accOne = new BankAccount("Christian Bauer", christian, "234234234234",
                                                "FooBar Rich Bank", "foobar123foobaz");
        christian.addBillingDetails(ccOne);
        christian.addBillingDetails(accOne);

        // Items
        Calendar inThreeDays = GregorianCalendar.getInstance();
        inThreeDays.roll(Calendar.DAY_OF_YEAR, 3);
        Calendar inFiveDays = GregorianCalendar.getInstance();
        inFiveDays.roll(Calendar.DAY_OF_YEAR, 5);
        Calendar nextWeek = GregorianCalendar.getInstance();
        nextWeek.roll(Calendar.WEEK_OF_YEAR, true);

        Item auctionOne = new Item("Item One", "An item in the carsLuxury category.",
                christian,
                new MonetaryAmount(new BigDecimal("1.99"), Currency.getInstance(Locale.US)),
                new MonetaryAmount(new BigDecimal("50.33"), Currency.getInstance(Locale.US)),
                new Date(), inThreeDays.getTime());
        auctionOne.getImages().add("imagefiledupe1.jpg");
        auctionOne.getImages().add("imagefiledupe1.jpg");
        auctionOne.getImages().add("imagefile2.jpg");

        carsLuxury.addItem(auctionOne);
        auctionOne.addCategory(carsLuxury);

        Item auctionTwo = new Item("Item Two", "Another item in the carsLuxury category.",
                gavin,
                new MonetaryAmount(new BigDecimal("2.22"), Currency.getInstance(Locale.US)),
                new MonetaryAmount(new BigDecimal("100.88"), Currency.getInstance(Locale.US)),
                new Date(), inFiveDays.getTime());

        carsLuxury.addItem(auctionTwo);
        auctionTwo.addCategory(carsLuxury);

        Item auctionThree = new Item("Item Three", "Don't drive SUVs.",
                christian,
                new MonetaryAmount(new BigDecimal("3.11"), Currency.getInstance(Locale.US)),
                new MonetaryAmount(new BigDecimal("300.55"), Currency.getInstance(Locale.US)),
                new Date(), inThreeDays.getTime());
        carsSUV.addItem(auctionThree);
        auctionThree.addCategory(carsSUV);

        // Bids
        Bid bidOne1 = new Bid(new MonetaryAmount(new BigDecimal("12.12"), Currency.getInstance(Locale.US)),
                auctionOne, christian);
        org.hibernate.auction.model.Bid bidOne2 = new Bid(new MonetaryAmount(new BigDecimal("13.13"), Currency.getInstance(Locale.US)),
                auctionOne, gavin);
        Bid bidOne3 = new Bid(new MonetaryAmount(new BigDecimal("14.14"), Currency.getInstance(Locale.US)),
                auctionOne, max);

        auctionOne.addBid(bidOne1);
        auctionOne.addBid(bidOne2);
        auctionOne.addBid(bidOne3);

        // Successful Bid
        auctionOne.setSuccessfulBid(bidOne3);
    }

}