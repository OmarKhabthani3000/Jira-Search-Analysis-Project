package com.example.frozen;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.List;

@Entity
public class SomeEntity {

    @Id
    private Integer id;

    @OneToMany( mappedBy="parent" )
    private List<SomeEntityChild> children;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List<SomeEntityChild> getChildren() {
        return children;
    }

    public void setChildren(List<SomeEntityChild> children) {
        this.children = children;
    }

}
