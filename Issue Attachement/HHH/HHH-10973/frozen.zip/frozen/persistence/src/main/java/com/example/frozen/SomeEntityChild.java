package com.example.frozen;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class SomeEntityChild {

    @Id
    private Integer id;

    @ManyToOne
    private SomeEntity parent;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public SomeEntity getParent() {
        return parent;
    }

    public void setParent(SomeEntity parent) {
        this.parent = parent;
    }

}
