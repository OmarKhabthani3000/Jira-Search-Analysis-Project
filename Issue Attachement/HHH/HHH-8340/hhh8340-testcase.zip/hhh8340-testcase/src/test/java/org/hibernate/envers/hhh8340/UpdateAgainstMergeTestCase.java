package org.hibernate.envers.hhh8340;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.annotations.common.util.impl.Log;
import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.query.AuditEntity;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;


/**
 * 
 * Unit test about updating an entity
 * 
 * @author Davide Di Somma <davide.disomma@gmail.com>
 */
public class UpdateAgainstMergeTestCase {

	private static final Log log = LoggerFactory.make( UpdateAgainstMergeTestCase.class.getName() );

	private SessionFactory sessions;

	private Configuration cfg;

	private Address privetDriveAddress;

	private Address grimmauldPlaceAddress;

	@Before
	public void setUp() throws Exception {
		if ( cfg == null ) {
			buildConfiguration();
		}
		openSessionFactory();
	}

	@After
	public void tearDown() throws Exception {
		closeSessionFactory();
	}

	@Test
	public void testMergeVersion() throws Exception {

		createAddresses();

		verifyCreationObjects();

		Session session = openSession();
		Transaction tx = session.beginTransaction();

		log.debug( "Now I'll change privet drive address!!" );
		privetDriveAddress = (Address) session.merge( privetDriveAddress );
		// Changing the address's house number and flat number
		privetDriveAddress.setHouseNumber( 5 );
		privetDriveAddress.setFlatNumber( null );

		tx.commit();
		session.close();

		verifyModificationPrivetDriveAddress();

		deleteAddresses();
	}

	@Test
	public void testUpdateVersion() throws Exception {

		createAddresses();
		verifyCreationObjects();

		Session session = openSession();
		Transaction tx = session.beginTransaction();

		log.debug( "Now I'll change privet drive address!!" );
		// Changing the address's house number and flat number
		privetDriveAddress.setHouseNumber( 5 );
		privetDriveAddress.setFlatNumber( null );
		session.update( privetDriveAddress );

		tx.commit();
		session.close();

		verifyModificationPrivetDriveAddress();

		deleteAddresses();
	}


	private void deleteAddresses() {
		Session session;
		Transaction tx;
		// Now let's clean up everything
		session = openSession();
		tx = session.beginTransaction();
		session.delete( grimmauldPlaceAddress );
		session.delete( privetDriveAddress );
		tx.commit();
		session.close();
	}

	private void verifyModificationPrivetDriveAddress() {
		// // let's assert that audit tables got updated correctly
		Session session = openSession();
		Transaction tx = session.beginTransaction();
		AuditReader auditReader = AuditReaderFactory.get( session );

		@SuppressWarnings("unchecked")
		List<Address> houseNumberAndFlatNumberChangedAddressList = auditReader.createQuery()
				.forEntitiesAtRevision( Address.class, 2 ).add( AuditEntity.property( "houseNumber" ).hasChanged() )
				.add( AuditEntity.property( "flatNumber" ).hasChanged() )
				.add( AuditEntity.property( "streetName" ).hasNotChanged() ).getResultList();
		assertEquals( 1, houseNumberAndFlatNumberChangedAddressList.size() );
		Address houseNumberChangedAtRevision2 = houseNumberAndFlatNumberChangedAddressList.get( 0 );
		assertEquals( "Privet Drive", houseNumberChangedAtRevision2.getStreetName() );
		assertEquals( 5, houseNumberChangedAtRevision2.getHouseNumber().intValue() );
		assertNull( houseNumberChangedAtRevision2.getFlatNumber() );

		tx.commit();
		session.close();
	}

	private void verifyCreationObjects() {
		// assert that everything got saved correctly
		Session session = openSession();
		Transaction tx = session.beginTransaction();
		AuditReader auditReader = AuditReaderFactory.get( session );
		Long addressObjectsAtRevision1 = (Long) auditReader.createQuery().forEntitiesAtRevision( Address.class, 1 )
				.addProjection( AuditEntity.id().count() ).getSingleResult();
		assertEquals( 2L, addressObjectsAtRevision1.longValue() );

		tx.commit();
		session.close();
	}

	private void createAddresses() {
		privetDriveAddress = new Address( "Privet Drive", 121 );
		privetDriveAddress.setFlatNumber( 2 );
		grimmauldPlaceAddress = new Address( "Grimmauld Place", 12 );
		grimmauldPlaceAddress.setFlatNumber( 1 );

		// first operation -> save objects
		Session session = openSession();
		Transaction tx = session.beginTransaction();
		session.save( privetDriveAddress );
		session.save( grimmauldPlaceAddress );
		tx.commit();
		session.close();
	}

	
	public Session openSession() throws HibernateException {
		return sessions.openSession();
	}

	protected void configure(Configuration cfg) {
		cfg.addAnnotatedClass( Address.class )
				// .setProperty( "org.hibernate.envers.global_with_modified_flag", "true" )
				.setProperty( "hibernate.connection.driver_class", "org.h2.Driver" )
				.setProperty( "hibernate.connection.url", "jdbc:h2:mem:db1" )
				.setProperty( "hibernate.connection.username", "sa" ).setProperty( "hibernate.connection.password", "" )
				.setProperty( org.hibernate.cfg.Environment.HBM2DDL_AUTO, "create-drop" )
				.setProperty( "hibernate.dialect", "org.hibernate.dialect.H2Dialect" );
	}

	protected void buildConfiguration() {
		if ( cfg != null ) {
			throw new IllegalStateException( "Configuration was already built" );
		}
		try {
			cfg = new Configuration();
			configure( cfg );
		}
		catch ( HibernateException e ) {
			e.printStackTrace();
			throw e;
		}
		catch ( Exception e ) {
			e.printStackTrace();
			throw new RuntimeException( e );
		}
	}

	@SuppressWarnings("deprecation")
	protected void openSessionFactory() {
		if ( sessions == null ) {
			if ( cfg == null ) {
				throw new IllegalStateException( "configuration was not built" );
			}
			sessions = cfg.buildSessionFactory( /* new TestInterceptor() */);
		}
		else {
			throw new IllegalStateException( "there should be no SessionFactory initialized at this point" );
		}
	}

	protected void closeSessionFactory() {
		if ( sessions == null ) {
			throw new IllegalStateException( "there is no SessionFactory to close" );
		}
		else {
			sessions.close();
			sessions = null;
		}
	}

}
