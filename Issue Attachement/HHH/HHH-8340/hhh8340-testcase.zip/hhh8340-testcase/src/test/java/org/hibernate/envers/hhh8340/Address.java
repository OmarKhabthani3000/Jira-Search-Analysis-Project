package org.hibernate.envers.hhh8340;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.envers.Audited;

@Entity
//@DynamicUpdate(value=true)
//@SelectBeforeUpdate(value=true)
//@DynamicInsert
@Audited(withModifiedFlag=true)
public class Address {
	
	public Address() { }
	
	public Address(String streetName, Integer houseNumber) {
		super();
		this.streetName = streetName;
		this.houseNumber = houseNumber;
	}

	@Id @GeneratedValue 
    private int id;
    public int getId() { return id; }
	public void setId(int id) { this.id = id; }

    private String streetName;
    public String getStreetName() { return streetName; }
    public void setStreetName(String streetName) { this.streetName = streetName; }
    
    private Integer houseNumber;
    public Integer getHouseNumber() { return houseNumber; }
    public void setHouseNumber(Integer houseNumber) { this.houseNumber = houseNumber; }

    private Integer flatNumber;
    public Integer getFlatNumber() { return flatNumber; }
    public void setFlatNumber(Integer flatNumber) { this.flatNumber = flatNumber; }

}

