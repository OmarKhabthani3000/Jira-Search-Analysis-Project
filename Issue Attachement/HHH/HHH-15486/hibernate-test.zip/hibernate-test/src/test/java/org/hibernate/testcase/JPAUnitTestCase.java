package org.hibernate.testcase;

import java.util.function.Consumer;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.models.Association;
import org.hibernate.models.Owner;
import org.hibernate.models.OwnerId;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class JPAUnitTestCase {

	private static EntityManagerFactory entityManagerFactory;

	@BeforeAll
	public static void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
	}

	@AfterAll
	public static void destroy() {
		entityManagerFactory.close();
	}

	private void doInJPA(Consumer<EntityManager> task) {
		EntityManager em = entityManagerFactory.createEntityManager();
		EntityTransaction txn = em.getTransaction();
		txn.begin();
		try {
			task.accept(em);
			if (txn.getRollbackOnly()) {
				txn.rollback();
			} else {
				txn.commit();
			}
		} catch (Throwable t) {
			if (txn.isActive()) {
				txn.rollback();
			}
			throw t;
		} finally {
			em.close();
		}
	}

	@Test
	void hhh15486Test() throws Exception {

		// create Product
		doInJPA(em -> {

			Owner owner = new Owner();
			owner.setName("Owner");
			owner.setId("owner1");
			em.persist(owner);

		});

		doInJPA(em -> {
			OwnerId ownerId = new OwnerId();
			ownerId.setId("owner1");
			Owner owner = em.find(Owner.class, ownerId);
			
			Association asso = new Association();
			asso.setName("Association");
			asso.setId("asso1");
			owner.setAssociation(asso);
			
			em.merge(owner);
		});
	}
}