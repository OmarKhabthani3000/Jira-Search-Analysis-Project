package org.hibernate.models;

import java.io.Serializable;

import javax.persistence.Embeddable;

/**
 * 
 * @author hzerai
 *
 */
@Embeddable
public class OwnerId implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String id;

	public void setId(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}

}
