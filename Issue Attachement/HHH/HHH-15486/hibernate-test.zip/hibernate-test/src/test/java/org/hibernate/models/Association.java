package org.hibernate.models;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToOne;
import javax.persistence.Version;

@Entity
public class Association {

	@EmbeddedId
	private AssociationId codeObject = new AssociationId();

	@Version
	private Integer version;

	@Column(unique = true, nullable = false)
	private String name;

	@OneToOne(fetch = FetchType.LAZY)
	private Owner owner;

	public AssociationId getCodeObject() {
		return this.codeObject;
	}

	public String getId() {
		return this.codeObject.getId();
	}

	public void setId(String id) {
		this.codeObject.setId(id);
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Owner getOwner() {
		return owner;
	}

	public void setOwner(Owner owner) {
		this.owner = owner;
	}
}
