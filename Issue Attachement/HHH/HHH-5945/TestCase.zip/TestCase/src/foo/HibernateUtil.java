package foo;

import java.io.FileReader;
import java.util.Properties;

import javax.persistence.Persistence;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.ejb.HibernateEntityManagerFactory;

public class HibernateUtil {

	private static SessionFactory sessionFactory;
	
	
	static {
		try {
			boot();
		} catch (Throwable ex) {
			throw new ExceptionInInitializerError(ex);
		}
	}
	private static void boot() throws Exception {
		Properties prop = new Properties();
		prop.load(new FileReader("hibernate.properties"));//$NON-NLS-1$
		sessionFactory = ((HibernateEntityManagerFactory)Persistence.createEntityManagerFactory("PU", prop)).getSessionFactory(); //$NON-NLS-1$
	}

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public static void shutdown() {
		sessionFactory.close();
	}

	public static Session getCurrentSession() throws HibernateException {
		return sessionFactory.getCurrentSession();
	}
	
}
