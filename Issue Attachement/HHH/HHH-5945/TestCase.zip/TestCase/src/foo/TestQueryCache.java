package foo;

import java.util.ArrayList;
import java.util.List;

public class TestQueryCache {

	public static void main(String[] args) {
		
		// 1. create database "test" in your sql server instance
		// 2. update hibernate.properties with your sql server configuration settings (user/password, jdbc connection string)
		// 3. run this main().
		
		
		List<Thread> threads = new ArrayList<Thread>();
		for (int i=0; i<10; i++) {
			Thread t = new Thread() {
				@Override
				public void run() {
					try {
						HibernateUtil.getCurrentSession().beginTransaction();
						HibernateUtil.getCurrentSession()
							.createCriteria(ClasseAltezza.class)
							.setCacheable(true)
							.setCacheRegion(ClasseAltezza.class.toString())
							.list();
						HibernateUtil.getCurrentSession().getTransaction().commit();
					}
					catch (Exception ex) {
						ex.printStackTrace();
						HibernateUtil.getCurrentSession().getTransaction().rollback();
					}
				}
			};
			threads.add(t);
		}
		for (Thread t : threads)
			t.start();
		
		for (Thread t : threads) {
			try {
				t.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}


}
