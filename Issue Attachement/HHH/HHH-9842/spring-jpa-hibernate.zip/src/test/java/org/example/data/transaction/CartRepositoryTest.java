package org.example.data.transaction;

import org.example.domain.catalog.Product;
import org.example.domain.transaction.Cart;
import org.example.domain.transaction.CartItem;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.util.Optional;

@ContextConfiguration(locations = "classpath:springContext.xml")
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class CartRepositoryTest
{
  private static final BigDecimal CHARGE = new BigDecimal(10.00);

  @Autowired
  private CartRepository cartRepository;

  @PersistenceContext
  private EntityManager entityManager;

  @Test
  public void testCartItemsWithoutPackingOrShippingCharge()
  {
    final Cart cart = new Cart();
    cart.addItem(new CartItem(cart, new Product("Apple iPod"), 1, CHARGE, Optional.empty(), Optional.empty()));
    cart.addItem(new CartItem(cart, new Product("Apple iPhone"), 1, CHARGE, Optional.empty(), Optional.empty()));
    cart.addItem(new CartItem(cart, new Product("Apple iPad"), 1, CHARGE, Optional.empty(), Optional.empty()));
    cart.addItem(new CartItem(cart, new Product("Apple iWatch"), 1, CHARGE, Optional.empty(), Optional.empty()));

    cartRepository.saveAndFlush(cart);

    entityManager.clear();

    cartRepository.findAll().forEach(c -> {
      Assert.assertNotNull(c);
      Assert.assertTrue(c.getItems().size() > 0);
      c.getItems().forEach(i -> {
        Assert.assertNotNull(i.getProduct());
        Assert.assertEquals(1, i.getQuantity());
        Assert.assertEquals(CHARGE.intValueExact(), i.getPrice().intValueExact());
        Assert.assertEquals(CHARGE.intValueExact(), i.getAmount().intValueExact());
        Assert.assertFalse(i.getPackingCharge().isPresent());
        Assert.assertFalse(i.getShippingCharge().isPresent());
      });
    });
  }
}
