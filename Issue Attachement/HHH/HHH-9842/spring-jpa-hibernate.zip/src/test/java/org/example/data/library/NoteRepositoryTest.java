package org.example.data.library;

import org.example.domain.library.Note;
import org.example.domain.library.Topic;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@ContextConfiguration(locations = "classpath:springContext.xml")
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class NoteRepositoryTest
{
  private static final String NOTE_SUBJECT = "Note Subject";
  private static final String TOPIC_NAME   = "Topic Name";

  @Autowired
  private NoteRepository  noteRepository;
  @Autowired
  private TopicRepository topicRepository;

  @PersistenceContext
  private EntityManager entityManager;

  @Before
  public void before()
  {
    Note note = new Note(NOTE_SUBJECT);
    note.addTopic(new Topic(TOPIC_NAME));

    noteRepository.saveAndFlush(note);

    entityManager.refresh(note);
  }

  @Test
  public void testFindNoteBySubject()
  {
    Assert.assertNotNull(noteRepository.findBySubject(NOTE_SUBJECT));
  }

  @Test
  public void testGetNotesForTopic()
  {
    Assert.assertTrue(topicRepository
                          .findByName(TOPIC_NAME)
                          .getNotes()
                          .size() > 0);
  }
}
