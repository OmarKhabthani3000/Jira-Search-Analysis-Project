package org.example.domain.library;

import org.example.domain.RelationalEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "topic")
public class Topic extends RelationalEntity
{
  @Column(name = "name", unique = true)
  @NotNull
  private String name;

  @JoinTable(inverseJoinColumns = @JoinColumn(name = "note_id"), joinColumns = @JoinColumn(name = "topic_id"), name = "entity_note_topic")
  @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private List<Note> notes;

  Topic()
  {
    super();
  }

  public Topic(String name)
  {
    this();

    this.name = name;
  }

  public void addNote(Note note)
  {
    if (note != null)
    {
      if (notes == null)
      {
        notes = new ArrayList<>();
      }

      notes.add(note);
    }
  }

  public String getName()
  {
    return name;
  }

  public List<Note> getNotes()
  {
    return notes;
  }
}
