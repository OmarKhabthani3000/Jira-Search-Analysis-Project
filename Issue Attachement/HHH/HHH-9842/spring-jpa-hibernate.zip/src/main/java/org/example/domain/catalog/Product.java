package org.example.domain.catalog;

import org.example.domain.RelationalEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name = "product")
public class Product extends RelationalEntity
{
  @Column(name = "name")
  @Size(max = 1000)
  private String name;

  Product()
  {
    super();
  }

  public Product(final String name)
  {
    this();

    this.name = name;
  }

  public String getName()
  {
    return name;
  }
}
