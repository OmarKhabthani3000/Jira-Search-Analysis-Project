package org.example.data.transaction;

import org.example.data.RelationalEntityRepository;
import org.example.domain.transaction.Cart;

public interface CartRepository extends RelationalEntityRepository<Cart>
{
}
