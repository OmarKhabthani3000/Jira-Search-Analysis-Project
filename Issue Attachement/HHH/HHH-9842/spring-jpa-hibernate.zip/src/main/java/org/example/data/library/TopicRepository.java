package org.example.data.library;

import org.example.data.RelationalEntityRepository;
import org.example.domain.library.Topic;

import org.springframework.data.jpa.repository.Query;

public interface TopicRepository extends RelationalEntityRepository<Topic>
{
  @Query("SELECT t FROM Topic t WHERE UPPER(TRIM(t.name))=UPPER(TRIM(?1))")
  Topic findByName(String name);
}
