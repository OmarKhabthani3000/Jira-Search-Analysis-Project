package org.example.domain.transaction;

import org.example.domain.RelationalEntity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "cart")
public class Cart extends RelationalEntity
{
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "cart", orphanRemoval = true)
  private List<CartItem> items;

  public void addItem(final CartItem item)
  {
    if (items == null)
    {
      items = new ArrayList<>();
    }

    items.add(item);
  }

  public List<CartItem> getItems()
  {
    return items;
  }
}
