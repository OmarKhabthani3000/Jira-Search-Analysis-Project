package org.example.data.library;

import org.example.data.RelationalEntityRepository;
import org.example.domain.library.Note;

import org.springframework.data.jpa.repository.Query;

public interface NoteRepository extends RelationalEntityRepository<Note>
{
  @Query("SELECT n FROM Note n WHERE UPPER(TRIM(n.subject))=UPPER(TRIM(?1))")
  Note findBySubject(String subject);
}
