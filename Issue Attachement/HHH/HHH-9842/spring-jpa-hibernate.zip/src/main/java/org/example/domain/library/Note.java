package org.example.domain.library;

import org.example.domain.RelationalEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "note")
public class Note extends RelationalEntity
{
  @Column(name = "subject", unique = true)
  @NotNull
  private String subject;

  @JoinTable(inverseJoinColumns = @JoinColumn(name = "topic_id"), joinColumns = @JoinColumn(name = "note_id"), name = "entity_note_topic")
  @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private List<Topic> topics;

  Note()
  {
    super();
  }

  public Note(String subject)
  {
    this();

    this.subject = subject;
  }

  public void addTopic(Topic topic)
  {
    if (topic != null)
    {
      if (topics == null)
      {
        topics = new ArrayList<>();
      }

      topics.add(topic);
    }
  }

  public String getSubject()
  {
    return subject;
  }

  public List<Topic> getTopics()
  {
    return topics;
  }
}
