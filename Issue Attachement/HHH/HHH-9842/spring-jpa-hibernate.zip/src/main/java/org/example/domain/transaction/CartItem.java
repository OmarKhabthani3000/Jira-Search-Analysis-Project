package org.example.domain.transaction;

import org.example.domain.RelationalEntity;
import org.example.domain.catalog.Product;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Optional;

@Entity
@Table(name = "cart_item")
public class CartItem extends RelationalEntity
{
  @JoinColumn(name = "cart_id", updatable = false)
  @ManyToOne
  @NotNull
  private Cart cart;

  @Column(name = "packing_charge")
  private BigDecimal packingCharge;

  @Column(name = "price")
  private BigDecimal price;

  @JoinColumn(name = "product_id", updatable = false)
  @ManyToOne(cascade = CascadeType.ALL)
  @NotNull
  private Product product;

  @Column(name = "quantity")
  @NotNull
  private int quantity;

  @Column(name = "shipping_charge")
  private BigDecimal shippingCharge;

  CartItem()
  {
    super();
  }

  public CartItem(final Cart cart
      , final Product product
      , final int quantity
      , final BigDecimal price
      , final Optional<BigDecimal> packingCharge
      , final Optional<BigDecimal> shippingCharge)
  {
    this();

    this.cart = cart;
    this.packingCharge = packingCharge.orElse(null);
    this.price = price;
    this.product = product;
    this.quantity = quantity;
    this.shippingCharge = shippingCharge.orElse(null);
  }

  public BigDecimal getAmount()
  {
    return price.multiply(new BigDecimal(quantity));
  }

  public Cart getCart()
  {
    return cart;
  }

  public Optional<BigDecimal> getPackingCharge()
  {
    return Optional.ofNullable(packingCharge);
  }

  public BigDecimal getPrice()
  {
    return price;
  }

  public Product getProduct()
  {
    return product;
  }

  public int getQuantity()
  {
    return quantity;
  }

  public Optional<BigDecimal> getShippingCharge()
  {
    return Optional.ofNullable(shippingCharge);
  }
}
