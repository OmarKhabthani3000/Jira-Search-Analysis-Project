package test.onetooneproblem;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.junit.Before;
import org.junit.Test;

public class OneToOneProblemTest {

    private SessionFactory sessionFactory;

    @Before
    public void setup() {
        final Configuration configure = new Configuration().configure();
        sessionFactory = configure.buildSessionFactory(new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build());
    }

    @Test
    public void testOneToOne() {

        final Session session = sessionFactory.openSession();
        session.getTransaction().begin();

        Phone phone = new Phone("123-456-7890");
        PhoneDetails details = new PhoneDetails("Some Provider", "GSM");

        phone.addDetails(details);

        session.persist(phone);

        session.getTransaction().commit();
        session.close();
    }
}
