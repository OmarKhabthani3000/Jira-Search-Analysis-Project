package org.hibernate.bugs;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM,
 * using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        Assert.assertEquals("1", count(entityManager));
        entityManager.close();
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh123Test() throws Exception {
        final int connectionPoolSize = 5;
        for (int i = 0; i < connectionPoolSize + 1; ++i) {
            EntityManager entityManager = entityManagerFactory.createEntityManager();
            for (int j = 0; j < 2; ++j) {
                try {
                    // JPA query that will fail with org.hibernate.exception.SQLGrammarException
                    final CriteriaBuilder builder = entityManager.getCriteriaBuilder();
                    final CriteriaQuery<Dummy> criteriaQuery = builder.createQuery(Dummy.class);
                    criteriaQuery.from(Dummy.class);
                    entityManager.createQuery(criteriaQuery).getSingleResult();
                } catch (Exception e) {
                    Logger.getLogger(JPAUnitTestCase.class.getName()).log(Level.INFO, "Exception: ", e);
                }
            }
            entityManager.close();
        }
    }

    private String count(EntityManager entityManager) {
        return entityManager.createNativeQuery("SELECT COUNT(*) "
                + "FROM information_schema.sessions").getSingleResult().toString();
    }
}
