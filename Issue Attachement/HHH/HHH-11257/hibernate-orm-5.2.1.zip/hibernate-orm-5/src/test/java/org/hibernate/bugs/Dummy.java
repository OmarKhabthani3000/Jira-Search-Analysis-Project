package org.hibernate.bugs;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "dummy")
public class Dummy implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
}
