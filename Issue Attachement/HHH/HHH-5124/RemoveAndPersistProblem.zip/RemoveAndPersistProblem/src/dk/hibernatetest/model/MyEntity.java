package dk.hibernatetest.model;

import javax.persistence.Column;

/**
 * No Documentation
 */
@javax.persistence.Entity
public class MyEntity extends dk.hibernatetest.model.AbstractEntity {
  private static final long serialVersionUID = 864804063L;

  @Column(length = 255)
  private String data;

  public String getData() {
    return data;
  }

  public void setData(String data) {
    this.data = data;
  }
}
