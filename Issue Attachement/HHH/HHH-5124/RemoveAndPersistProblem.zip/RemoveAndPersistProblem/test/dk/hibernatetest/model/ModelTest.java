package dk.hibernatetest.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.Test;

public class ModelTest {
	@Test
	public void testRemoveAndThenPersist() {
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("testModel");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		try {
	    MyEntity originalEntity = new MyEntity();
	    originalEntity.setData("Hello");

			entityManager.persist(originalEntity); 
			entityManager.flush();
			entityManager.clear();
			
			MyEntity myEntityAgain = entityManager.find(MyEntity.class, originalEntity.getId());
      
			// Get rid of it!
			entityManager.remove(myEntityAgain);
			
			// Oops, I want it back (and the JPA spec says I can in 3.2.1)
			entityManager.persist(myEntityAgain);
			
		} finally {
			entityManager.getTransaction().rollback();
			entityManager.close();
			entityManagerFactory.close();
		}
	}

}
