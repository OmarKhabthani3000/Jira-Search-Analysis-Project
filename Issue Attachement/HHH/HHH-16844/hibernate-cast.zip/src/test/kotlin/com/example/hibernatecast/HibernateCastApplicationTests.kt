package com.example.hibernatecast

import jakarta.persistence.EntityManager
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest(properties = ["DB_USERNAME=informix", "DB_PASSWORD=in4mix", "DB_CONNECTION_STRING=jdbc:informix-sqli://localhost:9088/online_dev:INFORMIXSERVER=informix" ])
class HibernateCastApplicationTests {

    @Autowired
    lateinit var entityManager: EntityManager

    @Test
    fun testNativeQueryWorks() {
        val query = entityManager.createNativeQuery("select cast(id as varchar(20)) from demo")
        query.resultList
    }

    @Test
    fun testJPAQueryWorks() {
        val query = entityManager.createQuery("select cast(d.id as varchar) from Demo d")
        query.resultList
    }
}
