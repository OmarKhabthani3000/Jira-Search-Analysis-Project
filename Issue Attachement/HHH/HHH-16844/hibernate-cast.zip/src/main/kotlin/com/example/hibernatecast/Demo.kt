package com.example.hibernatecast

import jakarta.persistence.Entity
import jakarta.persistence.Id

@Entity
data class Demo(
    @Id val id: Int,
    val context: String,
)
