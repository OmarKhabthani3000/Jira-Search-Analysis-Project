package com.example.hibernatecast

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class HibernateCastApplication

fun main(args: Array<String>) {
    runApplication<HibernateCastApplication>(*args)
}
