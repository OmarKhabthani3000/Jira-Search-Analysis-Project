rootProject.name = "hibernate-cast"
