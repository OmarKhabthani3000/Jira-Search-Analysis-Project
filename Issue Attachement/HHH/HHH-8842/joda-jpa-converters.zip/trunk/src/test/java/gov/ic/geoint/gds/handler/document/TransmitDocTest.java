package gov.ic.geoint.gds.handler.document;

import gov.ic.geoint.gets.document.Document;
import gov.ic.geoint.gets.document.DocumentAttachment;

import gov.ic.geoint.gets.document.util.MockDocumentGenerator;
import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.AfterClass;
import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Test;



/**
 *
 * @author courtney.priester
 */
public class TransmitDocTest {

    private static Document md;
    private static EntityManagerFactory emf;
    protected static EntityManager em = null;
    ResultSet rs = null;
    Statement stmt = null;
    Connection connection = null;
    java.sql.Array array = null;
    int no;

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    @BeforeClass
    public static void beforeAll() throws Exception {
        md = MockDocumentGenerator.document();

        System.out.println("mock document:" + md);

        EntityManager em = null;

        try {
            EntityManagerFactory factory = Persistence
                    .createEntityManagerFactory("hibernateH3");
            em = factory.createEntityManager();
            em.getTransaction().begin();
            em.persist(md);
//            em.flush();
//            em.clear();
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (em != null) {
                em.close();
            }
            if (emf != null) {
                emf.close();
            }
            fail(e.getMessage());
           
        }
    }

    @AfterClass
    public static void afterAll() {
    }

    /**
     * Test that the Document properly persists and returns
     *
     *
     * @throws Exception
     */
    @Test
    public void testDocumentConversion() throws Exception {

        System.out.println("Testing Document");

        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM DOCUMENT");

            while (rs.next()) {

                String docId = rs.getString("DOCUMENT.docId");
                String docDocId = md.getDocId();
                assertEquals("Expected docId wasn't GETS", docDocId, docId);

                String system = rs.getString("DOCUMENT.System");
                String docSys = md.getSystem();
                assertEquals("Expected system wasn't GETS", docSys, system);

                Long version = rs.getLong("DOCUMENT.Version");
                Long docVersion = md.getVersion();
                assertEquals("Expected version wasn't GETS", docVersion, version);

                String classification = rs.getString("DOCUMENT.Classification");
                String docClass = md.getClassification();
                assertEquals("Expected classification wasn't GETS", docClass, classification);

                String title = rs.getString("DOCUMENT.Title");
                String docTitle = md.getTitle();
                assertEquals("Expected title wasn't GETS", docTitle, title);

                String summary = rs.getString("DOCUMENT.Summary");
                String docSum = md.getSummary().toString();
                Converter c = new Converter();
                c.convertToEntityAttribute(summary);
                System.out.println("Summary to Entity" + summary);
                assertEquals("Expected Summary wasn't GETS", summary, docSum);

//                String body = rs.getString("DOCUMENT.sections");
//               List<Section> bodys = md.getSections();
//                BodyConverter cc = new BodyConverter();
//                //List<Section> lsec = cc.convertToEntityAttribute(body); 
//                System.out.println("Database" + body); 
//                System.out.println("Document:" + bodys);

            }

        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            try {
                {
                    rs.close();
                    stmt.close();
                    em.close();
                }
            } catch (Exception e) {
            }
            System.out.println("");
        }
    }

    @Test
    public void testDocumentMeta() throws Exception {
        Array hc = null;
        System.out.println("Testing DocMeta");
        // HotCodes hotcode = new Hot(null, null, null);
        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM DOCUMENT, DOCUMENTMETA, DOCUMENT_DOCMETA");

            while (rs.next()) {
//                String docMetaId = rs.getString("DOCUMENT_DOCMETA.id");
//                String docDocMetaId = md.getDocMeta().getId();
//                assertEquals("Expected system wasn't GETS", docDocMetaId, docMetaId);
//                
//                String relevanceStart = rs.getString("DOCUMENTMETA.relevanceStart");
//                LocalDate docMetaRelevanceStart = md.getDocMeta().getRelevanceStart();
//                assertEquals("Expected system wasn't GETS", docMetaRelevanceStart, relevanceStart);
//                
//                 String relevanceEnd = rs.getString("DOCUMENT_DOCMETA.relevanceEnd");
//                LocalDate docRelevanceEnd = md.getDocMeta().getRelevanceEnd();
//                assertEquals("Expected system wasn't GETS", docRelevanceEnd, relevanceEnd);
//               
//            <basic name="relevanceEnd">
//                <column name="relevanceEnd"/> 
//            </basic>
            }

        } catch (Exception e) {
            e.printStackTrace();
            //   em.getTransaction().rollback();
        } finally {
            try {
                {

                    rs.close();
                    stmt.close();
                    em.close();

                }
            } catch (Exception e) {
            }

            System.out.println("");
        }
    }

    /**
     * Testing to ensure that the geospatial elements of the Document are
     * converted to a format that the spatial database can read (ie OGC WKB
     * format)
     */
    @Test
    public void testAttachment() {
        System.out.println("Testing Attachment");
        List<DocumentAttachment> lists = new ArrayList<>();
        DocumentAttachment documentAttachment = null;


        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM DOCUMENT, DOCUMENT_ATTACHMENTS");



            List<DocumentAttachment> lda = new ArrayList<>();
            lda = md.getAttachments();
            ListIterator<DocumentAttachment> lite = null;
            lite = lda.listIterator();

            while (lite.hasNext()) {

                System.out.println(lite.next());
            }


//            List<DocumentAttachment> lda = md.getAttachments();
//            int docAttachmentSize = lda.size();
//           
//            List<DocumentAttachment> attachview = lda.subList(docAttachmentSize - no, docAttachmentSize);
//            List<DocumentAttachment> ldoca = new ArrayList<>(attachview);
//            attachview.clear();
//            System.out.println(ldoca); 





            while (rs.next()) {
                documentAttachment = new DocumentAttachment(rs.getString("DOCUMENT_ATTACHMENTS.ID"), rs.getString("DOCUMENT_ATTACHMENTS.Classification"), rs.getString("DOCUMENT_ATTACHMENTS.OrigFileName"));
                //assertEquals("Expected Attachments was not GETS Attachments", lda, lite);
                documentAttachment.setDescription(rs.getString("DOCUMENT_ATTACHMENTS.Description"));
                documentAttachment.setExtension(rs.getString("DOCUMENT_ATTACHMENTS.Extension"));
                documentAttachment.setMimeType(rs.getString("DOCUMENT_ATTACHMENTS.MimeType"));
                documentAttachment.setSha1(rs.getString("DOCUMENT_ATTACHMENTS.Sha1"));
                documentAttachment.setSize(rs.getLong("DOCUMENT_ATTACHMENTS.Size"));
                documentAttachment.setUrl(rs.getString("DOCUMENT_ATTACHMENTS.Url"));
                lists.add(documentAttachment);

            }
//            String testDocDocAttachment = lda.toString();
//            String testDocAttachment = lists.toString();
//            assertEquals("DocumentAttachment was not GETS", testDocDocAttachment, testDocAttachment);


        } catch (Exception e) {
            e.printStackTrace();
            //   em.getTransaction().rollback();
        } finally {
            try {
                {
                    rs.close();
                    stmt.close();
                    em.close();
                }
            } catch (Exception e) {
            }

            System.out.println("");
        }
    }

    @Test
    public void testDocContributor() throws Exception {

        System.out.println("Testing Contributors");


        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM DOCUMENT");
            while (rs.next()) {
            }



        } catch (Exception e) {
            e.printStackTrace();
            //   em.getTransaction().rollback();
        } finally {
            try {
                {

                    rs.close();
                    stmt.close();
                    em.close();

                }
            } catch (Exception e) {
            }

            System.out.println("");
        }
    }

    @Test
    public void testDocumentCountries() throws Exception {

        System.out.println("Testing Document Countries");


        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM DOCUMENT");



            while (rs.next()) {
            }



        } catch (Exception e) {
            e.printStackTrace();
            //   em.getTransaction().rollback();
        } finally {
            try {
                {
                    rs.close();
                    stmt.close();
                    em.close();

                }
            } catch (Exception e) {
            }

            System.out.println("");
        }
    }

    @Test
    public void testGeobounds() throws Exception {
        System.out.println("Testing Geobounds");

        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM DOCUMENT_GEOITEM");
            while (rs.next()) {
                byte[] geometry = rs.getBytes("DOCUMENT_GEOITEM.Geometry");
                GeoConverter goco = new GeoConverter();
                com.vividsolutions.jts.geom.Geometry geom = goco.convertToVivid(geometry);
                System.out.println(geom);
                //  assertArrayEquals(geom, );
                // Geometry docgeo = md.getDocMeta().getGeoint().;
                //   assertEquals("Expected system wasn't GETS", docSys, system);
            }
        } catch (Exception e) {
            e.printStackTrace();
            //   em.getTransaction().rollback();
        } finally {
            try {
                {
                    rs.close();
                    stmt.close();
                    em.close();
                }
            } catch (Exception e) {
            }
            System.out.println("");
        }
    }

    @Test
    public void testDocumentHotcodes() throws Exception {

        System.out.println("Testing Hotcodes");


        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM DOCUMENT");



            while (rs.next()) {

                Long version = rs.getLong("DOCUMENT.Version");
                Long docVersion = md.getVersion();
                assertEquals("Expected version wasn't GETS", docVersion, version);


            }



        } catch (Exception e) {
            e.printStackTrace();
            //   em.getTransaction().rollback();
        } finally {
            try {
                {

                    rs.close();
                    stmt.close();
                    em.close();

                }
            } catch (Exception e) {
            }

            System.out.println("");
        }
    }

    @Test
    public void testDocumentKeywords() throws Exception {

        System.out.println("Testing KeyWords");


        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM DOCUMENT");



            while (rs.next()) {
            }



        } catch (Exception e) {
            e.printStackTrace();
            //   em.getTransaction().rollback();
        } finally {
            try {
                {

                    rs.close();
                    stmt.close();
                    em.close();

                }
            } catch (Exception e) {
            }

            System.out.println("");
        }
    }

    @Test
    public void testDocumentNeeds() throws Exception {

        System.out.println("Testing DocumentNeeds");


        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM DOCUMENT");



            while (rs.next()) {
            }



        } catch (Exception e) {
            e.printStackTrace();
            //   em.getTransaction().rollback();
        } finally {
            try {
                {

                    rs.close();
                    stmt.close();
                    em.close();

                }
            } catch (Exception e) {
            }

            System.out.println("");
        }
    }

    @Test
    public void testDocumentProductionMetrics() throws Exception {

        System.out.println("Testing Production Metrics");


        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM DOCUMENT");



            while (rs.next()) {
            }



        } catch (Exception e) {
            e.printStackTrace();
            //   em.getTransaction().rollback();
        } finally {
            try {
                {

                    rs.close();
                    stmt.close();
                    em.close();

                }
            } catch (Exception e) {
            }

            System.out.println("");
        }
    }

    @Test
    public void testDocumentProperties() throws Exception {

        System.out.println("Testing Document Properties");


        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM DOCUMENT");



            while (rs.next()) {
            }



        } catch (Exception e) {
            e.printStackTrace();
            //   em.getTransaction().rollback();
        } finally {
            try {
                {

                    rs.close();
                    stmt.close();
                    em.close();

                }
            } catch (Exception e) {
            }

            System.out.println("");
        }
    }

//    @Test
//    public void testHotcodes() {
//        
//    }
    public void testPubMeta() throws Exception {
        System.out.println("Testing PubMeta");


        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM PUB");



            while (rs.next()) {
                String pubMetaId = rs.getString("PUBLICATIONMETA.id");
                String docPubMetaId = md.getPubMeta().getId();
                assertEquals("Expected pubMetaId wasn't GETS", docPubMetaId, pubMetaId);

                String authorId = rs.getString("PUBLICATIONMETA.authorId");
                String docAuthorId = md.getPubMeta().getAuthorId();
                assertEquals("Expected pubMetaId wasn't GETS", docAuthorId, authorId);

                String orgId = rs.getString("PUBLICATIONMETA.orgId");
                String docOrgId = md.getPubMeta().getOrgId();
                assertEquals("Expected pubMetaId wasn't GETS", docOrgId, orgId);

//                Date pubdate = rs.getDate("PUBLICATIONMETA.publicationDate");
//                DateTime docPubDate = doc.getPubMeta().getPublicationDate();
//                assertEquals("Expected pubMetaId wasn't GETS", docPubDate, pubdate);
            }

        } catch (Exception e) {
            e.printStackTrace();
            //   em.getTransaction().rollback();
        } finally {
            try {
                {

                    rs.close();
                    stmt.close();
                    em.close();

                }
            } catch (Exception e) {
            }

            System.out.println("");
        }
    }

    @Test
    public void testDocumentTargets() throws Exception {

        System.out.println("Testing Document Targets");


        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM DOCUMENT");



            while (rs.next()) {
            }



        } catch (Exception e) {
            e.printStackTrace();
            //   em.getTransaction().rollback();
        } finally {
            try {
                {

                    rs.close();
                    stmt.close();
                    em.close();

                }
            } catch (Exception e) {
            }

            System.out.println("");
        }
    }

    @Test
    public void testDocumentTasks() throws Exception {

        System.out.println("Testing Document Tasks");


        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM DOCUMENT");

            while (rs.next()) {
            }



        } catch (Exception e) {
            e.printStackTrace();
            //   em.getTransaction().rollback();
        } finally {
            try {
                {

                    rs.close();
                    stmt.close();
                    em.close();

                }
            } catch (Exception e) {
            }

            System.out.println("");
        }
    }

    @Test
    public void testDocumentUnstructuredCallouts() throws Exception {

        System.out.println("Testing UnstructuredCallouts");


        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM DOCUMENT");



            while (rs.next()) {
            }



        } catch (Exception e) {
            e.printStackTrace();
            //   em.getTransaction().rollback();
        } finally {
            try {
                {

                    rs.close();
                    stmt.close();
                    em.close();

                }
            } catch (Exception e) {
            }

            System.out.println("");
        }
    }

    @Test
    public void testEntireDocument() throws Exception {

        System.out.println("Testing ");


        try {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:test", "sa", "");
            stmt = connection.createStatement();
            rs = stmt.executeQuery("SELECT * FROM DOCUMENT");



            while (rs.next()) {
            }



        } catch (Exception e) {
            e.printStackTrace();
            //   em.getTransaction().rollback();
        } finally {
            try {
                {

                    rs.close();
                    stmt.close();
                    em.close();

                }
            } catch (Exception e) {
            }

            System.out.println("");
        }
    }

    protected EntityManager createEm() {
        return emf.createEntityManager();
    }
}
