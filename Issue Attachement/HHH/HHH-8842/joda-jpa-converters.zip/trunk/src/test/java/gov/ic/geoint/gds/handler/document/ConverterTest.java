/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.ic.geoint.gds.handler.document;

import gov.ic.geoint.gets.document.component.Section;
import gov.ic.geoint.gets.document.component.Summary;
import gov.ic.geoint.gets.document.geoint.GeospatialItem;
import gov.ic.geoint.gets.document.util.MockDocumentGenerator;
import gov.ic.geoint.spatial.Geometry;
import java.util.Date;
import java.util.List;
import org.joda.time.DateTime;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author courtney.priester
 */
public class ConverterTest {

    public ConverterTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of convertToDatabaseColumn method, of class Converter.
     */
    @Test
    public void testConvertToDatabaseColumn() {
        
//        DateConverter dc = new DateConverter();
//        Date dt = MockDocumentGenerator.pubMeta().getPublicationDate();
//        //Date o = dc.convertToDatabaseColumn(dt);
//        System.out.println("Date" + " " + o);
//        System.out.println("Type" + " " + o.getClass().getName());
////        DateTime td = dc.convertToEntityAttribute(o);
//        System.out.println("DateTime" + td);
//        System.out.println("Type" + td.getClass().getName());
        
        
//        Summary s = MockDocumentGenerator.summary();
//        Converter c = new Converter();
//        String o = c.convertToDatabaseColumn(s);
//        System.out.println(o);
////        Summary ns = c.convertToEntityAttribute(o);
////        System.out.println("Entity" + ns);
//
//        Section ss = MockDocumentGenerator.section();
//        System.out.println(ss.toString());
//        List<Section> lss = null;
////       
//        Geometry geo = MockDocumentGenerator.geoint().getGeometry();
//        // GeospatialItem goit = null;
////        goit.getGeometry();
//
//        GeoConverter geoc = new GeoConverter();
//       // com.vividsolutions.jts.geom.Geometry viv = geoc.convertToDatabaseColumn(geo);
//       // System.out.println("viv: " + viv.getClass().getName());
//       // System.out.println(viv);
//
//        Geometry geom = null;
//        
//        DateConverter dc = new DateConverter();
//        DateTime dt = MockDocumentGenerator.pubMeta().getPublicationDate();
//        dc.convertToDatabaseColumn(dt);
//        System.out.println("Date" + dt);
//        System.out.println("Type" + dt.getClass().getName());
//        
//        
//        
//
////        BodyConverter bc = new BodyConverter();
////        String lll = bc.convertToDatabaseColumn(lss);
////        System.out.println(lll);
//
////       Converter c = new Converter();
////       String o = c.convertToDatabaseColumn(s);
////       System.out.println(o);

    }
}