package gov.ic.geoint.gds.handler.document;

///*
// * To change this template, choose Tools | Templates
// * and open the template in the editor.
// */
//package gov.ic.geoint.gds.handler.Document;
//
//import gov.ic.geoint.gets.document.Document;
//import java.sql.Statement;
//import javax.persistence.EntityManager;
//import javax.persistence.EntityManagerFactory;
//import javax.persistence.Persistence;
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
//import org.junit.After;
//import org.junit.AfterClass;
//import org.junit.Before;
//import org.junit.BeforeClass;
//
///**
// *
// * @author courtney.priester
// */
//public class GeoConverterTest {
//
//    private Document document;
//    private static Log log = LogFactory.getLog(TransmitDoc.class);
//    private static EntityManagerFactory emf;
//    protected EntityManager em = null;
//    private Statement stmt;
//
//    public Statement getStmt() {
//        return stmt;
//    }
//
//    public void setStmt(Statement stmt) {
//        this.stmt = stmt;
//    }
//    
//    
//    
//
//    @BeforeClass
//    public static void setUpClass() {
//        log.debug("creating entity manager factory");
//        emf = Persistence.createEntityManagerFactory("hibernateH4");
//    }
//
//    @Before
//    public void setUp() throws Exception {
//
//        log.debug("creating entity manager");
//        em = emf.createEntityManager();
//        cleanup();
//        em.getTransaction().begin();
//     
//    }
//
//   
//    @After
//    public void tearDown() throws Exception {
//
//        //Query q = em.createQuery("SELECT DOCUMENT_GEOITEM.GEOMETRY FROM DOCUMENT, DOCUMENT_GEOITEM, DOCUMENT_DOCMETA, DOCMETA, DOCUMENT_CONTRIBUTOR");
//       stmt.executeQuery("SELECT DOCUMENT_GEOITEM.GEOMETRY FROM DOCUMENT, DOCUMENT_GEOITEM, DOCUMENT_DOCMETA, DOCMETA, DOCUMENT_CONTRIBUTOR");
//        
//      // Query q = "SELECT * FROM DOCUMENT, DOCUMENT_GEOITEM, DOCUMENT_DOCMETA, DOCMETA, DOCUMENT_CONTRIBUTOR";
//       String geom = ("SELECT DOCUMENT_DOCID FROM DOCUMENT, DOCUMENT_GEOITEM, DOCUMENT_DOCMETA, DOCMETA, DOCUMENT_CONTRIBUTOR");
//       
//     // Geometry go = stmt.execute(geom);
//        System.out.println();
//
//    }
//
//    @AfterClass
//    public static void tearDownClass() {
//
////        log.debug("closing entity manager factory");
////        if (emf != null) {
////            emf.close();
////        }
//
//    }
//
//    public void cleanup() {
//        em.getTransaction().begin();
//        em.getTransaction().commit();
//    }
//
//    protected EntityManager createEm() {
//        return emf.createEntityManager();
//    }
//
//    public Document getDocument() {
//        return document;
//    }
//
//    public void setDocument(Document document) {
//        this.document = document;
//    }
//}
