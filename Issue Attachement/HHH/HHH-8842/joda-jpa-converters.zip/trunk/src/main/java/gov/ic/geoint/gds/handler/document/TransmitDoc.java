/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.ic.geoint.gds.handler.document;

/**
 *
 * @author courtney.priester
 */
public class TransmitDoc {
    
    
    
}
