/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.ic.geoint.gds.handler.document;
import gov.ic.geoint.gets.document.component.Summary;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.AttributeConverter;
import org.eclipse.emf.ecore.xml.type.internal.DataValue.Base64;

/**
 *
 * Encodes/Decodes Summary
 */
@javax.persistence.Converter
public class base64Encode implements AttributeConverter<gov.ic.geoint.gets.document.component.Summary, String> {

    private static final Logger log = Logger.getLogger(Converter.class.getName());

    @Override
    public String convertToDatabaseColumn(Summary x) {

        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(x);
            oos.close();
           
            
            return Base64.encode(baos.toByteArray());
        } catch (IOException e) {
            log.log(Level.SEVERE, "Unable to encode Summary", e);
            return "";
        }
    }

    @Override
    public Summary convertToEntityAttribute(String y) {
        Summary sum = null;
        try {
            byte[] data = Base64.decode(y);
            ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(data));
            Object o = ois.readObject();
            ois.close();
            

            return (Summary) o;
        } catch (Exception e) {
            log.log(Level.SEVERE, "Unable to decode Summary", e);
            return null;
        }

    }
}

