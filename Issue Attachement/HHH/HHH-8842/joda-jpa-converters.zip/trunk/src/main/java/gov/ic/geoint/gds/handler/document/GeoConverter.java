/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.ic.geoint.gds.handler.document;

import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.io.OutStream;
import com.vividsolutions.jts.io.OutputStreamOutStream;
import com.vividsolutions.jts.io.ParseException;
import com.vividsolutions.jts.io.WKBReader;
import com.vividsolutions.jts.io.WKBWriter;
import gov.ic.geoint.spatial.jts.JTSGeometries;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class GeoConverter implements AttributeConverter<gov.ic.geoint.spatial.Geometry, byte[]> {

    Collection<Geometry> geoms = new ArrayList<>();

//     @Override
//    public com.vividsolutions.jts.geom.Geometry convertToDatabaseColumn(gov.ic.geoint.spatial.Geometry x) {
//       
//
//
////     com.vividsolutions.jts.geom.GeometryFactory geofac = new com.vividsolutions.jts.geom.GeometryFactory();
////            Point getsPoint = null;
////            for (Polygon p : doc.getDocMeta().getGeoBounds()) {
////                //  com.vividsolutions.jts.geom.
////
////                com.vividsolutions.jts.geom.Polygon jtsPoly = JTSGeometries.valueOf(p);
////                com.vividsolutions.jts.geom.Point intPoint     public Geometry convertToDatabaseColumn(gov.ic.geoint.spatial.Geometry x) {
////= jtsPoly.getInteriorPoint();
////                Coordinate getsCoord = new Coordinate(intPoint.getY(), intPoint.getX(), 0);
////                getsPoint = new Point(getsCoord, 0, 0, 0);
////
////            }
////            value = getsPoint;
//
//
////         JTSGeometries.valueOf(coordinate);
////         JTSGeometries.valueOf(coord[]);
////         JTSGeometries.valueOf(geometry);
////         JTSGeometries.valueOf(line);
////         JTSGeometries.valueOf(point);
////         JTSGeometries.valueOf(polygon);
//
//
////     com.vividsolutions.jts.geom.GeometryFactory geofac = new com.vividsolutions.jts.geom.GeometryFactory();
////     
////     Coordinate coor = null;
////     Coordinate[] coorcoll = null;
////     Geometry geo = null;
////     Line line = null;
////     Point point = null;
////     Polygon poly = null;
//
//
////     
////                //  com.vividsolutions.jts.geom.
////
////                com.vividsolutions.jts.geom.Polygon jtsPoly = JTSGeometries.valueOf(p);
////                com.vividsolutions.jts.geom.Point intPoint = jtsPoly.getInteriorPoint();
////                Coordinate getsCoord = new Coordinate(intPoint.getY(), intPoint.getX(), 0);
//
//
//int i = 0;
//i++;
//        if (x instanceof gov.ic.geoint.spatial.Point) {
//            
//            System.out.println("X" + i + ": " + x.getClass().getName());
//            com.vividsolutions.jts.geom.Geometry geometry = JTSGeometries.valueOf(x);
//            
//            System.out.println("viv type: " + geometry.getClass().getName()+"; "+geometry);
//            return (com.vividsolutions.jts.geom.Geometry)geometry;
//        } else{
//            System.out.println("X" + i + ": " + x.getClass().getName());
//            System.out.println("this geometry is not a point");
//            return null;
//        }
//     
//    
//
//    
////            if (x instanceof gov.ic.geoint.spatial.Line){
////              
////             return JTSGeometries.valueOf(x);
////         }
////       else if (x instanceof gov.ic.geoint.spatial.Point){
////       
////             return JTSGeometries.valueOf(x);
////         }  
////        else if (x instanceof gov.ic.geoint.spatial.Polygon){
////           
////             return JTSGeometries.valueOf(x);
////         }  
//////         else if (x instanceof gov.ic.geoint.spatial.Coordinate){
//////             return JTSGeometries.valueOf(x);
//////         } 
////       else if (x instanceof gov.ic.geoint.spatial.CoordinateCollection){
////      
////             return JTSGeometries.valueOf(x);
////         }  
//     
//
//
//    }
//    @Override
//    public gov.ic.geoint.spatial.Geometry convertToEntityAttribute(com.vividsolutions.jts.geom.Geometry y) {
//        
//
////        
////         if(y instanceof com.vividsolutions.jts.geom.Geometry){
////             com.vividsolutions.jts.geom.Coordinate coor = JTSGeometries.asGets(coor);
//
////             com.vividsolutions.jts.geom.Coordinate;
////            return gov.ic.geoint.spatial.Coordinate;
////        
//
////           com.vividsolutions.jts.geom.Polygon vpoly = null;
////      gov.ic.geoint.spatial.Polygon poly = JTSGeometries.asGets(poly);
////        return poly;   }   
//
////         else if (y instanceof com.vividsolutions.jts.geom.Coordinate){
////           com.vividsolutions.jts.geom.Coordinate coor = null;
////            gov.ic.geoint.spatial.Coordinate coo = JTSGeometries.asGets(coor);
////        return coo;       
////        }
//
//        return null;
//
//    }
    @Override
    public byte[] convertToDatabaseColumn(gov.ic.geoint.spatial.Geometry x) {
        try {
            com.vividsolutions.jts.geom.Geometry geom = JTSGeometries.valueOf(x);
            if (geom != null) {
                WKBWriter writer = new WKBWriter();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                OutStream os = new OutputStreamOutStream(out);
                writer.write(geom, os);
                System.out.println("Geo" + out.toByteArray());
                return out.toByteArray();
            }
        } catch (IOException ex) {
            Logger.getLogger(GeoConverter.class.getName()).log(Level.SEVERE, "Unable to extract WKB bytes from geometry", ex);
        }
        return new byte[0];
    }
    
     @Override
    public gov.ic.geoint.spatial.Geometry convertToEntityAttribute(byte[] y) {
       try {
           
            if (y != null) {
                WKBReader reader = new WKBReader();
                ByteArrayInputStream in = new ByteArrayInputStream(y);
               // InputStream is = new InputStream(in);
                 com.vividsolutions.jts.geom.Geometry geo = reader.read(y);
          //     JTSGeometries.asGets(geo);
                System.out.println("Geo" + geo);
                return null;
            }
        
        } catch (ParseException ex) {
            Logger.getLogger(GeoConverter.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }
    

    
    public com.vividsolutions.jts.geom.Geometry convertToVivid(byte[] y) {
       try {
           
            if (y != null) {
                WKBReader reader = new WKBReader();
                ByteArrayInputStream in = new ByteArrayInputStream(y);
               // InputStream is = new InputStream(in);
                 com.vividsolutions.jts.geom.Geometry geo = reader.read(y);
                
          //     JTSGeometries.asGets(geo);
                
             
                System.out.println("Geo" + geo);
                return geo;
            }
        
        } catch (ParseException ex) {
            Logger.getLogger(GeoConverter.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }
    }
