package gov.ic.geoint.gds.handler.document;


import gov.ic.geoint.gets.document.DocumentAttachment;
import java.util.List;
import java.util.logging.Logger;
import javax.persistence.AttributeConverter;
import gov.ic.geoint.gets.document.component.Section;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.logging.Level;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author courtney.priester
 */
@javax.persistence.Converter(autoApply = true)
public class BodyConverter implements AttributeConverter<List<Section>, String> {

    private static final Logger log = Logger.getLogger(BodyConverter.class.getName());
    private List list;
    
    @Override
    public String convertToDatabaseColumn(List<Section> x) {
        
        List<Section> ls = new ArrayList<>();
        Section s = new Section();
        
        
      
          
            ListIterator<Section> lite = null;
            
            lite=x.listIterator();
            
            while(lite.hasNext()){
        
                lite.next().setComponents(list);
                lite.add(s);
                
               //ls.add(s);
              
                System.out.println(lite.next());
            }
//            Object[] al = x.toArray();
//            ListIterator<Section> lite = null;
//            lite=x.listIterator();
//            while(lite.hasNext()){
//             
//            
//                System.out.println(lite.next());
//            }
 String lo = lite.toString();

      
        
        return lo;
        
//     try{
//         
//         
//       x = new ArrayList<>();
//            
//            ListIterator<Section> lite = null;
//            lite = x.listIterator();
//
//            while (lite.hasNext()) {
//              String al = x.toArray().toString();
//              
//                
////                String o = lite.toString();
////                   lite.add(x);
//                
//
//           return al;
//            }}
//       catch (Exception e) {
//            log.log(Level.SEVERE, "Unable to decode Summary", e);}
//            return null;
        
      //  try {
//            byte[] data = Base64.decode(y);
//            ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(data));
//            Object o = ois.readObject();
//            ois.close();
//            
//
//            return (Summary) o;
//        } catch (Exception e) {
//            log.log(Level.SEVERE, "Unable to decode Summary", e);
       //     return null;
    }

    @Override
    public List<Section> convertToEntityAttribute(String y) {
        
//    
//       try {
//            byte[] data = Base64.decode(y);
//            ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(data));
//            Object o = ois.readObject();
//            ois.close();
//            
//
//            return (List<Section>) o;
//        } catch (Exception e) {
//            log.log(Level.SEVERE, "Unable to decode Summary", e);
            return null;
        }
}
