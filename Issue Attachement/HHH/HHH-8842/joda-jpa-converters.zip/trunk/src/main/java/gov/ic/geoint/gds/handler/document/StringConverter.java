//package gov.ic.geoint.gds.handler.document;
//
///*
// * To change this template, choose Tools | Templates
// * and open the template in the editor.
// */
//package
//
//import gov.ic.geoint.reference.country.Country;
//
// gov.ic.geoint.gds.handler.Document;
//
//import gov.ic.geoint.gets.document.component.Summary;
//import java.awt.image.BufferedImage;
//import java.io.ByteArrayInputStream;
//import java.io.ByteArrayOutputStream;
//import java.io.File;
//import java.io.IOException;
//import javax.imageio.ImageIO;
//import javax.persistence.AttributeConverter;
//import sun.misc.BASE64Decoder;
//import sun.misc.BASE64Encoder;
//
///**
// *
// * @author courtney.priester
// */
//public class StringConverter implements AttributeConverter<Country, String>{
//
//    @Override
//    public String convertToDatabaseColumn(Object x) {
//         
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//    @Override
//    public Object convertToEntityAttribute(String y) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//    
//     
//   
//
//    
//  
//}
