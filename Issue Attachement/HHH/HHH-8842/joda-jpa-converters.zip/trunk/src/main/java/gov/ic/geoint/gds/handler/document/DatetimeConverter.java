/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.ic.geoint.gds.handler.document;

import javax.persistence.AttributeConverter;
import java.util.Date;

import javax.persistence.Converter;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;

/**
 *
 * @author courtney.priester
 */
@Converter
public class DatetimeConverter implements AttributeConverter<DateTime, Date>{

    @Override
    public Date convertToDatabaseColumn(DateTime x) {
        
        
        
        LocalDate ld =  x.toLocalDate();
     
      DateTimeZone  dtz = x.getZone();
       
      DateTime dt = ld.toDateTimeAtStartOfDay(dtz);
     Date d = dt.toDate();
        System.out.println("date" + d);
        

        return d;
        
                


    }

    @Override
    public DateTime convertToEntityAttribute(Date y) {
        
     
//         
//          DateTime dateTimeNew = new DateTime(y.getTime(), timeZone);
          return null;
          
    }

  
    
}
