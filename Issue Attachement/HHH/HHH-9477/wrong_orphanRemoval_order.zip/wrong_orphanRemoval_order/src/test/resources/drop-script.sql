drop table if exists tranche;
drop table if exists tranchenmodell;
drop table if exists preisregelung;
