onetoone-cascade-test
=====================

Test case showing problems with removing pf entities connected by a bidirectional @OneToOne releation.
