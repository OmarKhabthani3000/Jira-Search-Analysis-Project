Dialect Registration Patch for Hibernate 3.3.1 GA (Revision 2)
Tomoto Shimizu Washio <tomoto@kh.rim.or.jp>
Sep 24, 2008

(1) dialect_resistration_rev2.pdfs
  Overview of the changes from the previous design and the implementation model.

(2) core-src.patch
  The patch to project/core/src.  See (1) for the overview.

(2) testing-src.patch
  The patch to project/testing/src.  It includes abstract implementations of
  dummy JDBC classes for unit testing.  We would need them for unit testing of
  resolvers which now required JDBC objects such as Connection and
  DatabaseMetaData as their parameters.

(3) testsuite-src.patch
  The patch to project/testsuite/src.
  - Test C1 of the modified code except deprecated paths and a few exceptional
    paths.
  - Test all database names that already exist in DialectFactory.

-- 
