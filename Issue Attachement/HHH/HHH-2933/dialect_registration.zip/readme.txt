Dialect Registration Patch for Hibernate 3.3.1 GA
Tomoto Shimizu Washio
Sep 22, 2008

(1) dialect_registration.pdf
  The explanation of the design.

(2) core-src.patch
  The patch to the project/core/src.
  - For general explanation, please see (1).
  - Although I marked mapper-related facilities deprecated in DialectFactory
    and removed initialization of the mappers, I left the mapper mechanism
    itself intact just in case we needed it again.  You may remove them.

(3) testsuite-src.patch
  The patch to the project/testsuite/src.
  - It adds unit test cases that pass C1 of the modified code except
    deprecated paths and a few exceptional paths.
  - Also these test cases try all the database names that already exist in
    DialectFactory.

-- 
