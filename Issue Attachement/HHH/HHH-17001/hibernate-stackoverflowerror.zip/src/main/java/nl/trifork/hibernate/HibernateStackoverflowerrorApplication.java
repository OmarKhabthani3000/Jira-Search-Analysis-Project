package nl.trifork.hibernate;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.SetJoin;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Transactional;

@SpringBootApplication
public class HibernateStackoverflowerrorApplication implements CommandLineRunner {

    @PersistenceContext EntityManager entityManager;

    public static void main(String[] args) {
        SpringApplication.run(HibernateStackoverflowerrorApplication.class, args);
    }

    @Transactional
    @Override
    public void run(String... args) throws Exception {
        final Child someChildToCompareTo = new Child();
        entityManager.persist(someChildToCompareTo);

        final CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        final CriteriaQuery<Parent> cq = cb.createQuery(Parent.class);
        final Root<Parent> root = cq.from(Parent.class);
        final SetJoin<Parent, Child> childrenJoin = root.join(Parent_.children);
        // This will cause a StackOverflowError:
        childrenJoin.on(cb.equal(childrenJoin, someChildToCompareTo));
        // This works:
        // cq.where(cb.equal(childrenJoin, someChildToCompareTo));
        entityManager.createQuery(cq).getResultList();
    }
}
