# Demo Project
## Introduction
This is the demo project which showcases that in hibernate 6.0.1.Final, query an entity with composite identifier (@IdClass) will throw an exception.

PS: hibernate 5.6.7.Final works fine.

## Project setting
* ProductEntity
    * A simple entity which contains:
        * productRef: Integer
        * productName: String
* ProductKey
    * A composite identifier which contains:
        * productRef: Integer

## Run the demo projects
1. Run mvn clean test at root (hibernate-issue-demo-2).
    <br>Results:
    * hibernate-demo-5.6.7.Final - Test passed
    * hibernate-demo-6.0.1.Final - Test failed
1. To run the single demo project, run the main class:
    * org.example.Hibernate567FinalDemoMain
    * org.example.Hibernate601FinalDemoMain
1. The error will be thrown when fetching data in hibernate 6.0.1.Final.

## Exception
```
Exception in thread "main" org.hibernate.TypeMismatchException: Provided id of the wrong type for class org.example.entity.ProductEntity. Expected: class org.example.entity.ProductKey, got class org.example.entity.ProductKey
    at org.hibernate.event.internal.DefaultLoadEventListener.checkIdClass(DefaultLoadEventListener.java:167)
    at org.hibernate.event.internal.DefaultLoadEventListener.onLoad(DefaultLoadEventListener.java:71)
    at org.hibernate.event.service.internal.EventListenerGroupImpl.fireEventOnEachListener(EventListenerGroupImpl.java:118)
    at org.hibernate.internal.SessionImpl.fireLoadNoChecks(SessionImpl.java:1239)
    at org.hibernate.internal.SessionImpl.fireLoad(SessionImpl.java:1227)
    at org.hibernate.loader.access.IdentifierLoadAccessImpl.doLoad(IdentifierLoadAccessImpl.java:192)
    at org.hibernate.loader.access.IdentifierLoadAccessImpl.lambda$load$1(IdentifierLoadAccessImpl.java:158)
    at org.hibernate.loader.access.IdentifierLoadAccessImpl.perform(IdentifierLoadAccessImpl.java:105)
    at org.hibernate.loader.access.IdentifierLoadAccessImpl.load(IdentifierLoadAccessImpl.java:158)
    at org.hibernate.internal.SessionImpl.get(SessionImpl.java:1019)
    at org.example.Hibernate601FinalDemoMain.loadProduct(Hibernate601FinalDemoMain.java:41)
    at org.example.Hibernate601FinalDemoMain.run(Hibernate601FinalDemoMain.java:19)
    at org.example.Hibernate601FinalDemoMain.main(Hibernate601FinalDemoMain.java:10)
```