package org.example.entity;

import java.io.Serializable;

public class ProductKey implements Serializable {
    private Integer productRef;

    public Integer getProductRef() {
        return productRef;
    }

    public void setProductRef(Integer productRef) {
        this.productRef = productRef;
    }
}
