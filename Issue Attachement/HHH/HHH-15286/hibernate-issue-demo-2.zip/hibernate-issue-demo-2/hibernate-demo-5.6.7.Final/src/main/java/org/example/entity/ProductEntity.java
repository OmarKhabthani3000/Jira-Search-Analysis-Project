package org.example.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@IdClass(ProductKey.class)
@Entity
@Table(name = "product", uniqueConstraints = { @UniqueConstraint(columnNames = "product_ref") })
public class ProductEntity {
    @Id
    @Column(name="product_ref", nullable=false)
    Integer productRef;

    @Column(name = "product_name", unique = true, nullable = false, length = 100)
    private String productName;

    public Integer getProductRef() {
        return productRef;
    }

    public void setProductRef(Integer productRef) {
        this.productRef = productRef;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    @Override
    public String toString() {
        return "ProductEntity{" + "productRef=" + productRef + ", productName='" + productName + '\'' + '}';
    }
}
