package org.example;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class Hibernate567FinalDemoTest {
    @Test
    public void test() {
        Assertions.assertDoesNotThrow(() -> Hibernate567FinalDemoMain.run());
    }
}
