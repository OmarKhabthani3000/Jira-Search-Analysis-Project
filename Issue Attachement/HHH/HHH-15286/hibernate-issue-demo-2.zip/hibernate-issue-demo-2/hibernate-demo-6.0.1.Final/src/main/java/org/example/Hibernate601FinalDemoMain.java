package org.example;

import org.example.entity.ProductEntity;
import org.example.entity.ProductKey;
import org.example.util.HibernateUtil;
import org.hibernate.Session;

public class Hibernate601FinalDemoMain {
    public static void main(final String[] args) {
        run();
    }

    public static void run() {
        System.out.println("Hibernate 6.0.0.Final");
        final Session session = HibernateUtil.getSessionFactory().openSession();

        final int newProductId = 1;
        saveProduct(session, newProductId, "Product A");
        loadProduct(session, newProductId);

        HibernateUtil.shutdown();
    }

    private static void saveProduct(final Session session, final int productId, final String productName) {
        session.beginTransaction();

        final ProductEntity storeProductEntity = new ProductEntity();
        storeProductEntity.setProductRef(productId);
        storeProductEntity.setProductName(productName);

        session.persist(storeProductEntity);

        session.getTransaction().commit();
    }

    private static void loadProduct(final Session session, final int productId) {
        session.beginTransaction();

        final ProductKey productKey = new ProductKey();
        productKey.setProductRef(productId);
        final ProductEntity storeProductEntity = session.get(ProductEntity.class, productKey);
        System.out.println(storeProductEntity.toString());

        session.getTransaction().commit();
    }
}
