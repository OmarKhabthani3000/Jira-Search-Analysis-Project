package org.example;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class Hibernate601FinalDemoTest {
    @Test
    public void test() {
        Assertions.assertDoesNotThrow(() -> Hibernate601FinalDemoMain.run());
    }
}
