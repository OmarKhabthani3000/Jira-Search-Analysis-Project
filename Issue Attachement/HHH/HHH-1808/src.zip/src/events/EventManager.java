package events;

import java.io.Serializable;
import org.hibernate.Criteria;
import org.hibernate.FlushMode;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import java.util.*;
import org.hibernate.criterion.Expression;
import org.hibernate.engine.EntityKey;
import org.hibernate.impl.SessionFactoryImpl;
import org.hibernate.impl.SessionImpl;
import util.HibernateUtil;

public class EventManager {
  
  public static void main(String[] args) throws Exception {
    EventManager mgr = new EventManager();
      
    if (args[0].equals("repro")) {
      Long personId = mgr.createAndStorePerson("Vor", "Nach");
      
      Session session = HibernateUtil.getSessionFactory().getCurrentSession();
      session.beginTransaction();
      
      Person person1 = (Person)session.load(Person.class, personId);
      person1.setAge(10);
      session.save(person1);
      session.flush();

      session.createQuery("update Person set age = 20").executeUpdate();

//      session.evict(person1);
      
//      for(Object o : session.getStatistics().getEntityKeys()) {
//        EntityKey key = (EntityKey) o;
//        if(key.getEntityName().equals("events.Person")) {
//          session.evict(session.load(key.getEntityName(), key.getIdentifier()));
//        }
//      }
     
      Person person2 = (Person)session.load(Person.class, personId);
      System.out.println(person2.getAge());
      session.getTransaction().commit();      

      session = HibernateUtil.getSessionFactory().getCurrentSession();
      session.beginTransaction();
      
      Person person3 = (Person)session.load(Person.class, personId);
      System.out.println(person3.getAge());
      
      session.getTransaction().commit();      
    }
  }
  
  
  private Long createAndStorePerson(String firstName, String lastName) {
    Long personId;
    
    Session session = HibernateUtil.getSessionFactory().getCurrentSession();
    session.beginTransaction();
    
    Person thePerson = new Person();
    thePerson.setFirstname(firstName);
    thePerson.setLastname(lastName);
    
    personId = (Long)session.save(thePerson);
    
    session.getTransaction().commit();
    
    return(personId);
  }
  
  
}