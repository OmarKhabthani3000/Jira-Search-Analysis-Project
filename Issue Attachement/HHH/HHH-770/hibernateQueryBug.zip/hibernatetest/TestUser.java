package au.com.dytech.find.core.hibernatetest;

import java.util.HashSet;
import java.util.Set;


/**
 * A User of the system.
 * 
 * @author Dytech Solutions Pty. Ltd.
 */
public class TestUser
{
	Set roles;
	Long id;
	
	public TestUser()
	{
		roles = new HashSet();
	}
	
	/**
	 * @return Returns the id.
	 */
	public Long getId()
	{
		return id;
	}
	
	/**
	 * @param id The id to set.
	 */
	public void setId(Long id)
	{
		this.id = id;
	}

	/**
	 * @param role The role to add.
	 */
	public void addRole(TestRole role)
	{
		roles.add(role);
		role.getUsers().add(this);
	}
	
	/**
	 * @return Returns the roles.
	 */
	public Set getRoles()
	{
		return roles;
	}
	
	/**
	 * @param roles The roles to set.
	 */
	public void setRoles(Set roles)
	{
		this.roles = roles;
	}
	
}
