package au.com.dytech.find.core.hibernatetest;

import java.util.HashSet;
import java.util.Set;


/**
 * A role assumed by Users.
 * 
 * @author Dytech Solutions Pty. Ltd.
 */
public class TestRole
{
	Set privileges;
	Set users;
	Long id;
	
	public TestRole()
	{
		privileges = new HashSet();
		users = new HashSet();
	}
	
	/**
	 * @return Returns the id.
	 */
	public Long getId()
	{
		return id;
	}
	
	/**
	 * @param id The id to set.
	 */
	public void setId(Long id)
	{
		this.id = id;
	}
	
	/**
	 * @param user The user to add.
	 */
	public void addUser(TestUser user)
	{
		user.addRole(this);
	}

	/**
	 * @return Returns the users.
	 */
	public Set getUsers()
	{
		return users;
	}
	
	/**
	 * @param users The users to set.
	 */
	public void setUsers(Set users)
	{
		this.users = users;
	}

	/**
	 * @param privilege The pivilege to add.
	 */
	public void addPrivilege(TestPrivilege privilege)
	{
		privileges.add(privilege);
		privilege.getRoles().add(this);
	}
	
	/**
	 * @return Returns the privileges.
	 */
	public Set getPrivileges()
	{
		return privileges;
	}
	
	/**
	 * @param privileges The privileges to set.
	 */
	public void setPrivileges(Set privileges)
	{
		this.privileges = privileges;
	}
	
}
