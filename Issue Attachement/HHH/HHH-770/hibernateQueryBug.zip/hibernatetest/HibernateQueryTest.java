package au.com.dytech.find.core.hibernatetest;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.naming.NamingException;

import junit.framework.TestCase;

import org.apache.commons.dbcp.BasicDataSource;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;
import org.springframework.orm.hibernate3.SessionFactoryUtils;

/**
 * This test exposes a bug in hibernate's query generation.
 * 
 * @author Dytech Solutions Pty. Ltd.
 */
public class HibernateQueryTest extends TestCase
{

	Session session;
	TestUser user1;
	TestPrivilege privilege1, privilege2, privilege3, privilege4;
	private Transaction transaction;

	/**
	 * @see junit.framework.TestCase#setUp()
	 */
	public void setUp() throws Exception
	{
		user1 = new TestUser();
		TestUser user2 = new TestUser();
		TestRole role1 = new TestRole();
		TestRole role2 = new TestRole();
		TestRole role3 = new TestRole();
		privilege1 = new TestPrivilege();
		privilege2 = new TestPrivilege();
		privilege3 = new TestPrivilege();
		privilege4 = new TestPrivilege();

		user1.addRole(role1);
		user1.addRole(role2);
		role1.addPrivilege(privilege1);
		role1.addPrivilege(privilege2);
		role2.addPrivilege(privilege1);
		role2.addPrivilege(privilege3);

		user2.addRole(role3);
		role3.addPrivilege(privilege1);
		role3.addPrivilege(privilege4);

		setupJndiContext();

		session = getSession();
		transaction = session.beginTransaction();

		List oldUsers = session.createCriteria(TestUser.class).list();
		for (Iterator iter = oldUsers.iterator(); iter.hasNext();)
		{
			TestUser oldUser = (TestUser) iter.next();
			session.delete(oldUser);
		}

		transaction.commit();
		transaction = session.beginTransaction();

		session.save(user1);
		session.save(user2);

		transaction.commit();
		transaction = session.beginTransaction();
	}

	/**
	 * @see junit.framework.TestCase#tearDown()
	 */
	public void tearDown()
	{
		transaction.commit();
	}

	/**
	 * Produces invalid SQL.
	 */
	public void test1()
	{
		Query query = session.createQuery("from TestPrivilege p where :user in p.roles.users");
		query.setEntity("user", user1);
		List results = query.list();

		assertEquals(3, results.size());
		assertTrue(results.contains(privilege1));
		assertTrue(results.contains(privilege2));
		assertTrue(results.contains(privilege3));
	}

	/**
	 * Produces valid SQL, but no results are found.
	 */
	public void test2()
	{
		Query query = session.createQuery("from TestPrivilege p where :user in elements(p.roles.users)");
		query.setEntity("user", user1);
		List results = query.list();

		assertEquals(3, results.size());
		assertTrue(results.contains(privilege1));
		assertTrue(results.contains(privilege2));
		assertTrue(results.contains(privilege3));
	}

	/**
	 * Successful Query!
	 */
	public void test3()
	{
		Query query = session.createQuery("select distinct u.roles.privileges from TestUser u where u = :user");
		query.setEntity("user", user1);
		List results = query.list();

		assertEquals(3, results.size());
		assertTrue(results.contains(privilege1));
		assertTrue(results.contains(privilege2));
		assertTrue(results.contains(privilege3));
	}

	/**
	 * 
	 */
	private Session getSession()
	{
		File configFile = new File(
				"src/code/au/com/dytech/find/core/hibernatetest/hibernate.cfg.xml").getAbsoluteFile();

		Configuration cfg = new Configuration();
		cfg.configure(configFile);
		cfg.buildMappings();
		cfg.setProperty("hibernate.connection.datasource", "jdbc/FindDb");

		SessionFactory sessionFactory = cfg.buildSessionFactory();

		Session session = SessionFactoryUtils.getNewSession(sessionFactory);
		return session;
	}

	/**
	 * Sets up testing JNDI resources
	 * 
	 */
	public void setupJndiContext() throws NamingException, IOException
	{
		if (SimpleNamingContextBuilder.getCurrentContextBuilder() == null)
		{
			SimpleNamingContextBuilder builder = SimpleNamingContextBuilder.emptyActivatedContextBuilder();

			BasicDataSource ds = new BasicDataSource();
			ds.setPassword("dbpassword");
			ds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
			ds.setUsername("dbusername");
			ds.setUrl("jdbc:oracle:thin:@dbserver:dbport:dbname");
			ds.setMaxActive(10);
			ds.setInitialSize(1);

			builder.bind("java:comp/env/" + "jdbc/FindDb", ds);
			builder.bind("jdbc/FindDb", ds);
		}
	}
}
