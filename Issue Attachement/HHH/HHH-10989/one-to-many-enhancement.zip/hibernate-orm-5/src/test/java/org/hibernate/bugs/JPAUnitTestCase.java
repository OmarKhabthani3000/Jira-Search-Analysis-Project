package org.hibernate.bugs;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import org.hibernate.bugs.entities.Garage;
import org.hibernate.bugs.entities.Car;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		// Create garage, add cars to garage
		EntityManager em1 = entityManagerFactory.createEntityManager();
		EntityTransaction tx1 = em1.getTransaction();
		tx1.begin();

        Garage garage = new Garage();
        Car car1 = new Car();
        Car car2 = new Car();
        garage.insert( car1 );
        garage.insert( car2 );
        
        em1.persist(garage);
        em1.persist(car1);
        em1.persist(car2);
        
        tx1.commit();
        em1.close();

        // Remove garage
        
		EntityManager em2 = entityManagerFactory.createEntityManager();
		EntityTransaction tx2 = em2.getTransaction();
		tx2.begin();
        
		Garage toRemoveGarage = em2.find(Garage.class, garage.getId());
		em2.remove(toRemoveGarage);
		
        tx2.commit();
        em2.close();
        
        // Check if there is no garage but cars are still present
        
		EntityManager em3 = entityManagerFactory.createEntityManager();
		EntityTransaction tx3 = em3.getTransaction();
		tx3.begin();
        
		Garage foundGarage = em3.find(Garage.class, garage.getId());
		assertThat( foundGarage, is (nullValue()));

        Car foundCar1 = em3.find(Car.class, car1.getId() );
        assertThat( foundCar1.getId(), equalTo( car1.getId() ) );

        Car foundCar2 = em3.find(Car.class, car2.getId() );
        assertThat( foundCar2.getId(), equalTo( car2.getId() ) );
        
        tx3.commit();
        em3.close();
	}
}
