package org.hibernate.bugs.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Car {

	@Id
	private String id;

	public Car() {
		this.id = java.util.UUID.randomUUID().toString();
	}

	public String getId() {
		return id;
	}

}
