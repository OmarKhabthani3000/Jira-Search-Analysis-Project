package org.hibernate.bugs.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Garage implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	/**
	 * Creates a new instance of an entity OneToManyUni.
	 *
	 */
	public Garage() {
		this.id = java.util.UUID.randomUUID().toString();
	}

	public String getId() {
		return id;
	}

	@OneToMany()
	@JoinColumn(name = "GARAGE_ID")
	private Set<Car> cars = new HashSet<Car>();

	public boolean insert(Car aCar) {
		return cars.add(aCar);
	}

}
