package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "A_CONTAINER")
public class EntityAContainer {
    
    @Id
    Integer id;

    @OneToMany(fetch = FetchType.LAZY, orphanRemoval = true, cascade = CascadeType.ALL, targetEntity = EntityA.class)
    @JoinColumn(name = "REFERENCE", foreignKey = @ForeignKey(name = "none"))
    @Fetch(FetchMode.SELECT)
    List<AbstractEntity> entities = new ArrayList<>();

}
