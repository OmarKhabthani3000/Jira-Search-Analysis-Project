package test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * 
 */
public class Tester
{
    /** */
    private EntityManagerFactory emf;

    /**
     * @throws Exception
     */
    @Before
    public void testData()
        throws Exception
    {
        emf = Persistence.createEntityManagerFactory("testPU");
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
        
        Employee employee = new Employee(1);
        
        Computer computer = new Computer(1);
        computer.setComputerName("Bob's computer");
        computer.setEmployee(employee);
        
        em.persist(employee);
        em.persist(computer);

        em.getTransaction().commit();

        em.close();
    }
    
    /**
     * 
     */
    @Test
    public void testOrderBy()
    {
        EntityManager em = emf.createEntityManager();
        
        Employee employee = em.find(Employee.class, 1);
        employee.getAssets();
        
        em.close();
    }

    /**
     * 
     */
    @After
    public void cleanup()
    {
        if (emf != null)
        {
            emf.close();
        }
    }
}
