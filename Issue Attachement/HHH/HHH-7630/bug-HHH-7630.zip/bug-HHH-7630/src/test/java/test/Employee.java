package test;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;

/**
 * 
 */
@Entity
public class Employee
{
    /** */
    @Id
    @Column(name = "id")
    private Integer id;
    
    /** */
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "employee", orphanRemoval = true)
    @OrderBy("id ASC") // <-- this causes the error
    private final List<Asset> assets = new ArrayList<Asset>();
    
    /**
     * @param id
     */
    public Employee(Integer id)
    {
        this.id = id;
    }

    /**
     * @return the id
     */
    public Integer getId()
    {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id)
    {
        this.id = id;
    }

    /**
     * @return the assets
     */
    public List<Asset> getAssets()
    {
        return assets;
    }
}
