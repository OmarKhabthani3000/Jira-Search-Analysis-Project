package test;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 * 
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Asset
{
    /** */
    @Id
    @Column(name = "id")
    private final Integer id;

    /** */
    @ManyToOne(cascade = {CascadeType.ALL})
    @JoinColumn(nullable = false)
    private Employee employee;
    
    /**
     * @param id
     */
    public Asset(Integer id)
    {
        this.id = id;
    }

    /**
     * @return the id
     */
    public Integer getId()
    {
        return id;
    }

    /**
     * @return the employee
     */
    public Employee getEmployee()
    {
        return employee;
    }

    /**
     * @param employee the employee to set
     */
    public void setEmployee(Employee employee)
    {
        this.employee = employee;
    }
}
