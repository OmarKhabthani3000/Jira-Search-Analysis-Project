package test;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;

/**
 * 
 */
@Entity
@PrimaryKeyJoinColumn(name = "id")
public class Computer
    extends Asset
{
    /** */
    private String computerName;
    
    /**
     * @param id
     */
    public Computer(Integer id)
    {
        super(id);
    }

    /**
     * @return the computerName
     */
    public String getComputerName()
    {
        return computerName;
    }

    /**
     * @param computerName the computerName to set
     */
    public void setComputerName(String computerName)
    {
        this.computerName = computerName;
    }
}
