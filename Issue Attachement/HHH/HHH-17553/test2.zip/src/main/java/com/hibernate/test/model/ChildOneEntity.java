package com.hibernate.test.model;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;

@Entity
@EqualsAndHashCode(callSuper = false, exclude = {"parentEntity"})
public class ChildOneEntity extends BaseEntity {

    @Id
    @Column(name = "parent_id", nullable = false)
    private String parentId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id", insertable = false, updatable = false, referencedColumnName = "parent_id")
    private ParentEntity parentEntity;
}
