package com.hibernate.test.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import lombok.EqualsAndHashCode;

@Entity
@EqualsAndHashCode(callSuper = true, onlyExplicitlyIncluded = true)
public class ChildThreeEntity extends ChildTwoEntity {

    @Column(name = "some_value")
    protected String someValue;
}
