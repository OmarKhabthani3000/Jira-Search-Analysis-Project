package com.hibernate.test.model;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;

@Entity
@EqualsAndHashCode(of = {"childTwoId"}, callSuper = false)
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "type", length = 25)
public class ChildTwoEntity extends BaseEntity {

    @Id
    @Column(name = "child_two_id", nullable = false)
    protected String childTwoId;

    @Column(name = "parent_id", nullable = false)
    protected String parentId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id", insertable = false, updatable = false, referencedColumnName = "parent_id")
    protected ParentEntity parentEntity;
}
