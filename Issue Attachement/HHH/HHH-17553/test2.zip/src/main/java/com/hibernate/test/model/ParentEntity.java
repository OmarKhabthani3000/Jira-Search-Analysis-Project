package com.hibernate.test.model;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;

import java.util.HashSet;
import java.util.Set;

@Entity
//@EqualsAndHashCode(of = "parentId", callSuper = false) // Use this and it will work
@EqualsAndHashCode(callSuper = false) // Use this and il will break
public class ParentEntity extends BaseEntity {

    @Id
    @Column(name = "parent_id", nullable = false)
    private String parentId;

    // Remove one of the associations and it will work
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "parentEntity")
    private ChildOneEntity childOneEntity;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "parentEntity")
    private Set<ChildTwoEntity> childTwoEntities = new HashSet<>();
}
