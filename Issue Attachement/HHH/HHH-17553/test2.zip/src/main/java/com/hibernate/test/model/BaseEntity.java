package com.hibernate.test.model;

import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.PostLoad;
import lombok.Getter;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@MappedSuperclass
@Getter
public abstract class BaseEntity implements Serializable {

    // Remove this method (or just the annotation) and it will work
    @PostLoad
    public void postLoad() {
        postLoad(this, new HashSet<>());
    }

    private void postLoad(Object entity, Set<Object> processed) {
        if (!processed.contains(entity)) {
            processed.add(entity);
            // Some processing for encryption
        }
    }
}
