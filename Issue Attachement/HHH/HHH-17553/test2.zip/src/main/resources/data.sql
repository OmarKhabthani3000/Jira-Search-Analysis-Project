insert into parent_entity(parent_id) values('bf511573-f812-4ac2-a1bf-440d68912e6b');
insert into child_one_entity (parent_id) values ('bf511573-f812-4ac2-a1bf-440d68912e6b');
insert into child_two_entity (child_two_id, parent_id, type) values ('ac31ba23-199f-4e71-8123-b6f99f4daa66', 'bf511573-f812-4ac2-a1bf-440d68912e6b', 'ChildThreeEntity');
insert into child_three_entity (child_two_id, some_value) values ('ac31ba23-199f-4e71-8123-b6f99f4daa66', 'some value');
