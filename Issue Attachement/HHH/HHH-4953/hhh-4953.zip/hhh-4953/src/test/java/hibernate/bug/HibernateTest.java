package hibernate.bug;

import hibernate.bug.model.AccountManager;
import hibernate.bug.model.TechnicalUser;
import java.util.Map;
import java.util.Properties;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import static org.junit.Assert.assertNull;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {

    private EntityManagerFactory emf;
    private int accountManagerId;
    private int technicalUserId;

    private Map createProperties() {
        Properties p = new Properties();
        p.put("hibernate.cache.use_second_level_cache", true);
        p.put("hibernate.cache.region.factory_class", "org.hibernate.cache.infinispan.InfinispanRegionFactory");
        return p;
    }

    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test", createProperties());

        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        AccountManager accountManager = new AccountManager();
        em.persist(accountManager);
        accountManagerId = accountManager.getId();
        
        TechnicalUser technicalUser = new TechnicalUser();
        em.persist(technicalUser);
        technicalUserId = technicalUser.getId();

        em.flush();
        tx.commit();
        em.close();
    }

    @Test
    public void testIssue() {
        EntityManager em = emf.createEntityManager();
        
        assertNull(em.find(AccountManager.class, technicalUserId));
        
        em.close();
    }
}
