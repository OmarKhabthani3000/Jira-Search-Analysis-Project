package hibernate.bug.model;

import javax.persistence.Cacheable;
import javax.persistence.Entity;

@Entity
@Cacheable
public class AccountManager extends AbstractUser {
    
}
