package foo;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = SimpleEntity.TABLENAME)
public class ComplexDuplicateEntity extends AbstractComplexEntity {

}
