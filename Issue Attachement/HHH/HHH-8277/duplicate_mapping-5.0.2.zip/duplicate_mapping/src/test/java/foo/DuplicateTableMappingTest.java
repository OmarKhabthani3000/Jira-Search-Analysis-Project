package foo;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.junit.Test;

public class DuplicateTableMappingTest {

	private static SessionFactory createSessionFactory(Class<?> ... classes) {
		Configuration configuration = new Configuration();
		if (classes != null) {
			for (Class<?> clazz : classes) {
				configuration.addAnnotatedClass(clazz);
			}
		}
        configuration.configure();
        ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
        SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
        return sessionFactory;
	}

	/**
	 * No problem with simple entities
	 */
	@Test
	public void testSimpleDuplicate() {
		createSessionFactory(SimpleEntity.class, SimpleDuplicateEntity.class);
	}

	/**
	 * No problem if ComplexDuplicateEntity is added first
	 */
	@Test
	public void testComplexBeforeSimple() {
		createSessionFactory(ComplexDuplicateEntity.class, SimpleEntity.class);
	}

	/**
	 * Pb if the simplest entity is added before the complex one.
	 */
	@Test // (expected = DuplicateMappingException.class)
	public void testDuplicateSimpleEntities() {
		createSessionFactory(SimpleEntity.class, ComplexDuplicateEntity.class);
	}
}
