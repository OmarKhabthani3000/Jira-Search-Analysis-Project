import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.Session;
import org.hibernate.Query;
import org.hibernate.test.TestCase;

/**
 * @author Mattias Jiderhamn
 */
public class TrueFalseTest extends TestCase {

	public void testTrueFalse() {
		Session s = openSession();
		s.getTransaction().begin();
		BooleanValue bv1 = new BooleanValue();
		bv1.setValue(true);
		s.persist( bv1 );
		BooleanValue bv2 = new BooleanValue();
		bv2.setValue(false);
		s.persist( bv2 );
		s.flush();
		s.clear();
		Query q = s.createQuery("from BooleanValue bv where bv.value = ?");
		// q.setString(0, "F"); // Works
		q.setBoolean(0, false); // Does not work
		BooleanValue falseValue = (BooleanValue) q.uniqueResult();
		assertNotNull(falseValue); // Fails
		s.getTransaction().commit();
		s.close();
	}

	public TrueFalseTest(String str) {
		super(str);
	}

	protected String[] getMappings() {
		return new String[] { "BooleanValue.hbm.xml" };
	}

	public static Test suite() {
		return new TestSuite(TrueFalseTest.class);
	}

}

