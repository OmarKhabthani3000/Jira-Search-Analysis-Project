
    create table COM_CLIENT_ADDRESS (
        addressSeq number(19,0) not null,
        addressTypeCd varchar2(255 char),
        houseName varchar2(255 char),
        line1 varchar2(255 char),
        preferredFl varchar2(255 char),
        zipCode varchar2(255 char),
        CLIENTCD varchar2(255 char) not null,
        primary key (addressSeq)
    );

    create table COM_CLIENT_ADDRESS_AUD (
        addressSeq number(19,0) not null,
        REV number(10,0) not null,
        REVTYPE number(3,0),
        addressTypeCd varchar2(255 char),
        houseName varchar2(255 char),
        line1 varchar2(255 char),
        preferredFl varchar2(255 char),
        zipCode varchar2(255 char),
        CLIENTCD varchar2(255 char),
        primary key (addressSeq, REV)
    );

    create table COM_CLIENT_M (
        clientCd varchar2(255 char) not null,
        bankCd varchar2(255 char),
        CLIENTYPECD varchar2(255 char),
        genderCd varchar2(255 char),
        firstName1 varchar2(255 char),
        lastName1 varchar2(255 char),
        middleName1 varchar2(255 char),
        primary key (clientCd)
    );

    create table COM_CLIENT_M_AUD (
        clientCd varchar2(255 char) not null,
        REV number(10,0) not null,
        REVTYPE number(3,0),
        bankCd varchar2(255 char),
        CLIENTYPECD varchar2(255 char),
        genderCd varchar2(255 char),
        firstName1 varchar2(255 char),
        lastName1 varchar2(255 char),
        middleName1 varchar2(255 char),
        primary key (clientCd, REV)
    );

    create table REVINFO (
        REV number(10,0) not null,
        REVTSTMP number(19,0),
        primary key (REV)
    );

    alter table COM_CLIENT_ADDRESS 
        add constraint FK4EEB95FEB02D5D23 
        foreign key (CLIENTCD) 
        references COM_CLIENT_M;

    alter table COM_CLIENT_ADDRESS_AUD 
        add constraint FK234094CFDF74E053 
        foreign key (REV) 
        references REVINFO;

    alter table COM_CLIENT_M_AUD 
        add constraint FKB5AB3048DF74E053 
        foreign key (REV) 
        references REVINFO;

    create sequence hibernate_sequence;
