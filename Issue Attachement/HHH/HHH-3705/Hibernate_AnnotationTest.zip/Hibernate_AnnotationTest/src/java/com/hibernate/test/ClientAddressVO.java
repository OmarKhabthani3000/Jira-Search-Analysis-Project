package com.hibernate.test;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import com.mastek.elixir.system.common.types.ValueObject;

@Audited
@Entity
@Table(name = "COM_CLIENT_ADDRESS")
@SequenceGenerator(name = "AddressSeq", sequenceName = "SEQ_COM_CLIENT_ADDRESS" ,  allocationSize=1)
public class ClientAddressVO implements Serializable
{
	private static final long	serialVersionUID	= 1L;

	protected long					addressSeq;
	protected String				preferredFl;

	protected String				addressTypeCd;
	protected String				line1;
	protected String				zipCode;

	// @AuditJoinTable(name = "COM_CLIENT_ADDRESSJOIN_AUD", inverseJoinColumns =
	// @JoinColumn(name = "CLIENTCD"))
	protected ClientVO			client;

	protected HouseDetails		houseDetails		= new HouseDetails();

	protected String				createdBy;
	protected String				createdAt;
	protected Date					createdDt;

	protected int					rowVersion;

	@Id
	@GeneratedValue(generator = "AddressSeq", strategy = GenerationType.SEQUENCE)
	public long getAddressSeq()
	{
		return addressSeq;
	}

	public void setAddressSeq(long addressSeq)
	{
		this.addressSeq = addressSeq;
	}

	public String getPreferredFl()
	{
		return preferredFl;
	}

	public void setPreferredFl(String preferredFl)
	{
		this.preferredFl = preferredFl;
	}

	public String getAddressTypeCd()
	{
		return addressTypeCd;
	}

	public void setAddressTypeCd(String addressTypeCd)
	{
		this.addressTypeCd = addressTypeCd;
	}

	public String getLine1()
	{
		return line1;
	}

	public void setLine1(String line1)
	{
		this.line1 = line1;
	}

	public String getZipCode()
	{
		return zipCode;
	}

	public void setZipCode(String zipCode)
	{
		this.zipCode = zipCode;
	}

	@ManyToOne(targetEntity = ClientVO.class)
	@JoinColumn(name = "CLIENTCD", nullable = false)
	public ClientVO getClient()
	{
		return client;
	}

	public void setClient(ClientVO client)
	{
		this.client = client;
	}

	@Column(name = "CREATEDBY")
	public String getCreatedBy()
	{
		return "default";
	}

	@SuppressWarnings("unused")
	private void setCreatedBy(String str)
	{
	}

	@Column(name = "CREATEDDT")
	public Date getCreatedDt()
	{
		return new Date(System.currentTimeMillis());
	}

	@SuppressWarnings("unused")
	private void setCreatedDt(Date dt)
	{
	}

	@Column(name = "CREATEDAT")
	public String getCreatedAt()
	{
		return "default";
	}

	@SuppressWarnings("unused")
	private void setCreatedAt(String str)
	{
	}

	@Embeddable
	public static class HouseDetails extends ValueObject
	{
		private String	houseName;

		public String getHouseName()
		{
			return houseName;
		}

		public void setHouseName(String bankCd)
		{
			this.houseName = bankCd;
		}
	}

	@Embedded
	public HouseDetails getHouseDetails()
	{
		return houseDetails;
	}

	public void setHouseDetails(HouseDetails houseDetails)
	{
		this.houseDetails = houseDetails;
	}

	public final int getRowVersion()
	{
		return this.rowVersion;
	}

	public final void setRowVersion(int rowVersion)
	{
		this.rowVersion = rowVersion;
	}

}
