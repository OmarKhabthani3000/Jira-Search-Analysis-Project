package com.hibernate.test;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class NameVO implements Serializable
{
	private static final long	serialVersionUID	= 1L;

	protected String				firstName1;

	protected String				middleName1;

	protected String				lastName1;

	public NameVO()
	{
	}

	public String getFirstName1()
	{
		return firstName1;
	}

	public void setFirstName1(String firstName1)
	{
		this.firstName1 = firstName1;
	}

	public String getMiddleName1()
	{
		return middleName1;
	}

	public void setMiddleName1(String middleName1)
	{
		this.middleName1 = middleName1;
	}

	public String getLastName1()
	{
		return lastName1;
	}

	public void setLastName1(String lastName1)
	{
		this.lastName1 = lastName1;
	}

}
