package com.hibernate.test;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.hibernate.Session;

import com.mastek.elixir.system.common.caching.Cache;
import com.mastek.elixir.system.common.environment.ApplicationScope;
import com.mastek.elixir.system.common.environment.Environment;
import com.mastek.elixir.system.common.util.PropertyResources;

public class HibernateAnnotationTest extends ApplicationScope
{
	public HibernateAnnotationTest(String name)
	{
		super(name);
	}

	public static void main(String[] args)
	{
		HibernateAnnotationTest test = new HibernateAnnotationTest("Test");
		Environment.initialize(test);

		test.runTest();
	}

	public void runTest()
	{
		// saveClient();

		// updateClient();

		//loadClient();

		 deleteClient();
	}

	private void loadClient()
	{
		EntityManager mgr = createEntityManager();

		Query query = mgr.createQuery("select client from ClientVO as client where client.nameVO.firstName1 like '%Kaiz%'");

		List<?> results = query.getResultList();
		Iterator itr = results.iterator();

		while (itr.hasNext())
		{
			ClientVO client = (ClientVO) itr.next();

			System.out.println(client.getNameVO().getFirstName1());

			System.out.println(client.getAddressList().get(0).getLine1());
		}

		//itr = mgr.createQuery("select client.nameVO.firstName1,client.nameVO.middleName1  from ClientVO as client").getResultList().iterator();

		itr = mgr.createQuery("select address.addressTypeCd, address.line1 from ClientVO as client join client.addressList as address").getResultList().iterator();
		
		while (itr.hasNext())
		{
			Object[] names = (Object[]) itr.next();

			for (Object name : names)
			{
				System.out.println("Name - " +name);
			}
		}

	}

	private void saveClient()
	{
		EntityManager mgr = createEntityManager();

		ClientVO client = createClient();

		mgr.persist(client);

		mgr.getTransaction().commit();

		mgr.close();
	}

	private void updateClient()
	{
		EntityManager mgr = createEntityManager();

		ClientVO clientVO =  mgr.find(ClientVO.class, "456");
		clientVO.getNameVO().setLastName1("Hawk");
		clientVO.getAddressList().get(0).setLine1("Piccadily Circus");

		mgr.persist(clientVO);

		mgr.getTransaction().commit();

		mgr.close();
	}

	private EntityManager createEntityManager()
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("ConsolePU");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();

		return em;
	}

	private ClientVO createClient()
	{

		ClientVO client = new ClientVO();
		client.setClientCd("456");
		client.setClientTypeCd("Person");
		client.setGenderCd("M");

		NameVO name = new NameVO();
		name.setFirstName1("Stephen");
		name.setLastName1("Hawking");

		client.setNameVO(name);

		client.getAddressList().add(createClientAddress(1, client));
		client.getAddressList().add(createClientAddress(2, client));

		return client;
	}

	private ClientAddressVO createClientAddress(int i, ClientVO client)
	{
		ClientAddressVO address = new ClientAddressVO();
		address.setClient(client);
		address.setAddressTypeCd("Office" + i);
		address.setZipCode("12345" + i);
		address.setPreferredFl("Y");
		address.setLine1("London");
		address.getHouseDetails().setHouseName("Palace");

		return address;
	}

	private void deleteClient()
	{
		/*EntityManager mgr = createEntityManager();

		ClientVO clientVO = mgr.find(ClientVO.class, "456");
		mgr.remove(clientVO);
		mgr.getTransaction().commit();*/
		
		
		Session session  = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		
		ClientVO clientVO = (ClientVO) session.load(ClientVO.class, "456");
		session.delete(clientVO);
		session.getTransaction().commit();
		
	}

	@Override
	protected Cache loadCache()
	{
		return null;
	}

	@Override
	protected PropertyResources loadResources()
	{
		return null;
	}

}
