package com.hibernate.test;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Audited
@Entity
@Table(name = "COM_CLIENT_M")
public class ClientVO  implements Serializable
{
	private static final long			serialVersionUID	= 1L;

	protected String						clientCd;

	protected String						clientTypeCd;
	protected String						genderCd;


	protected List<ClientAddressVO>	addressList			= new ArrayList<ClientAddressVO>();

	protected NameVO						nameVO;

	protected String						createdBy;
	protected String						createdAt;
	protected Date							createdDt;
	
	protected int						rowVersion;

	public ClientVO()
	{
	}

	@Id
	public String getClientCd()
	{
		return clientCd;
	}

	public void setClientCd(String clientCd)
	{
		this.clientCd = clientCd;
	}

	@Column(name = "CLIENTTYPECD" , nullable = false)
	public String getClientTypeCd()
	{
		return clientTypeCd;
	}

	public void setClientTypeCd(String clientTypeCd)
	{
		this.clientTypeCd = clientTypeCd;
	}

	public String getGenderCd()
	{
		return genderCd;
	}

	public void setGenderCd(String genderCd)
	{
		this.genderCd = genderCd;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "client", targetEntity = ClientAddressVO.class, fetch = FetchType.LAZY)
	public java.util.List<ClientAddressVO> getAddressList()
	{
		return addressList;
	}

	public void setAddressList(java.util.List<ClientAddressVO> list)
	{
		addressList = list;// _toArrayList(list);
	}

	@Embedded
	public NameVO getNameVO()
	{
		return nameVO;
	}

	public void setNameVO(NameVO nameVO)
	{
		this.nameVO = nameVO;
	}

	@Column(name = "CREATEDBY")
	public String getCreatedBy()
	{
		return "default";
	}

	@SuppressWarnings("unused")
	private void setCreatedBy(String str)
	{
	}

	@Column(name = "CREATEDDT")
	public Date getCreatedDt()
	{
		return new Date(System.currentTimeMillis());
	}

	@SuppressWarnings("unused")
	private void setCreatedDt(Date dt)
	{
	}

	@Column(name = "CREATEDAT")
	public String getCreatedAt()
	{
		return "default";
	}

	@SuppressWarnings("unused")
	private void setCreatedAt(String str)
	{
	}
	

	public final int getRowVersion()
	{
		return this.rowVersion;
	}

	public final void setRowVersion(int rowVersion)
	{
		this.rowVersion = rowVersion;
	}

}
