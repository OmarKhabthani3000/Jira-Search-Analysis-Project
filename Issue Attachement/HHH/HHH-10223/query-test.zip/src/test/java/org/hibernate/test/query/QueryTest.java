package org.hibernate.test.query;

import org.hibernate.cfg.Configuration;
import org.junit.Test;

public class QueryTest {

	@Test
	public void testQuery() {
		Configuration cfg = new Configuration();		
		cfg.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
		cfg.addResource("org/hibernate/test/query/Query.hbm.xml");
		cfg.buildSessionFactory();
	}

}
