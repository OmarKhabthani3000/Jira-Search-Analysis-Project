package br.com.simula.hibernatecountbug;

import java.io.Serializable;
import javax.persistence.Embeddable;

/**
 *
 * @author <a href="mailto:fabio@simula.com.br">Fabio Braga de Oliveira</a>
 */
@Embeddable
public class EntidadeId implements Serializable {

    private int chave1;
    private int chave2;

    public int getChave1() {
        return chave1;
    }

    public void setChave1(int chave1) {
        this.chave1 = chave1;
    }

    public int getChave2() {
        return chave2;
    }

    public void setChave2(int chave2) {
        this.chave2 = chave2;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final EntidadeId other = (EntidadeId) obj;
        if (this.chave1 != other.chave1) {
            return false;
        }
        if (this.chave2 != other.chave2) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 73 * hash + this.chave1;
        hash = 73 * hash + this.chave2;
        return hash;
    }

    
}
