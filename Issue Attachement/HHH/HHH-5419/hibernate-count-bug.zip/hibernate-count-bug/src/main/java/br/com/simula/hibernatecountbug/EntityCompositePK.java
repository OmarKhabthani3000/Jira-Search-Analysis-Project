package br.com.simula.hibernatecountbug;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

/**
 *
 * @author <a href="mailto:fabio@simula.com.br">Fabio Braga de Oliveira</a>
 */
@Entity
public class EntityCompositePK implements Serializable {

    @EmbeddedId
    private EntidadeId id;
    private String descricao;

    public EntidadeId getId() {
        return id;
    }

    public void setId(EntidadeId id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
