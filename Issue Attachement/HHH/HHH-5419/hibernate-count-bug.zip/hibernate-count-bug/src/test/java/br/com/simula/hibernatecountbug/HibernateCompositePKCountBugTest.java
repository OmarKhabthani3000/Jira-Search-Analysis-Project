package br.com.simula.hibernatecountbug;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Unit test for simple App.
 */
public class HibernateCompositePKCountBugTest
{
    private EntityManagerFactory factory;
    private static final String PERSISTENCE_UNIT_NAME = "hibernate-count-bug";

    

    @Before
    public void setUp() {
        factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);

        getEntityManager().getTransaction().begin();

    }

    @After
    public void tearDown() {
        getEntityManager().getTransaction().rollback();
    }

    private EntityManager getEntityManager() {
        return factory.createEntityManager();
    }

    @Test
    public void testCompositePKCountBug()
    {
       CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Object[]> cq = cb.createQuery(Object[].class);
        Root<EntityCompositePK> r = cq.from(EntityCompositePK.class);

        cq.multiselect(cb.count(r));
        assertEquals(0, ((Long) (getEntityManager().createQuery(cq).getSingleResult())[0]).intValue());
    }



}
