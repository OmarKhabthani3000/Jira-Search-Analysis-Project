package entity;

import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.DbTimestampType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DbTimestampTest
{
	private SessionFactory m_Factory;

	@Before
	public void setUp() throws Exception
	{
		// ServiceRegistryBuilder b = new ServiceRegistryBuilder();
		// ServiceRegistry r = b.configure().buildServiceRegistry();
		//
		// MetadataSources mds = new MetadataSources(r);
		// m_Factory = mds.buildMetadata().buildSessionFactory();

		// Deprecated, but working
		m_Factory = new Configuration().configure().buildSessionFactory();
	}

	@Test
	public void test() throws Exception
	{
		ScheduledExecutorService service = Executors.newScheduledThreadPool(1);
		service.scheduleAtFixedRate(new TimestampTask(), 0, 200,
				TimeUnit.MILLISECONDS);
		service.awaitTermination(15, TimeUnit.MINUTES);
	}

	@After
	public void tearDown() throws Exception
	{
		m_Factory.close();
	}

	class TimestampTask implements Runnable
	{
		@Override
		public void run()
		{
			try
			{
				DbTimestampType type = new DbTimestampType();
				Session session = m_Factory.getCurrentSession();

				Transaction t = session.beginTransaction();
				Date now = type.seed((SessionImplementor) session);
				t.commit();

				System.out.println("Timestamp: " + now.toString());
			} catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
