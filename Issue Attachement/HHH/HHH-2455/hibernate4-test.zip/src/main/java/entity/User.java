package entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User
{
	public Long m_Id;
	public String m_Firstname;
	public String m_Lastname;
	public Date m_Birthday;

	@Id
	Long getId()
	{
		return m_Id;
	}

	void setId(Long id)
	{
		m_Id = id;
	}

	@Column
	String getFirstname()
	{
		return m_Firstname;
	}

	void setFirstname(String firstname)
	{
		m_Firstname = firstname;
	}

	@Column
	String getLastname()
	{
		return m_Lastname;
	}

	void setLastname(String lastname)
	{
		m_Lastname = lastname;
	}

	@Column
	Date getBirthday()
	{
		return m_Birthday;
	}

	void setBirthday(Date birthday)
	{
		m_Birthday = birthday;
	}
}
