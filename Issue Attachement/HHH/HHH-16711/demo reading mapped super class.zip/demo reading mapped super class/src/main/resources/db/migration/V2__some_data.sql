INSERT INTO public.inheriting VALUES
    (1, 'name1'),
    (2, 'name2');