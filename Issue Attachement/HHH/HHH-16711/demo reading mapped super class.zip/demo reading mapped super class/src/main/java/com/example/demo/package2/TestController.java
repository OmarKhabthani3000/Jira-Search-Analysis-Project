package com.example.demo.package2;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequestMapping("/test")
@RestController
@CrossOrigin
@AllArgsConstructor
class TestController {
    private final InheritingRepository repository;

    @GetMapping
    public List<Inheriting> findEntities() {
        return repository.findAll();
    }
}
