package org.hibernate.bugs;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Item {
	@Id
	@GeneratedValue
	private Long id;

	public Item() {
	}

	public Long getId() {
		return id;
	}
}
