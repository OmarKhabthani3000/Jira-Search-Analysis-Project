package it.satanet.tpc;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
public class Diagram {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	Long id;

	String name;

	@OneToMany
    @Cascade(value = { CascadeType.ALL, CascadeType.DELETE_ORPHAN })
//    Commenting this one makes the test pass, but generates table for a 
//    many-to-many association, not a one to many
    @JoinColumn(name = "DIAGRAM_ID")
	Set<Shape> shapes;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Shape> getShapes() {
		if(shapes == null)
			shapes = new HashSet<Shape>();
		return shapes;
	}

	public void setShapes(Set<Shape> shapes) {
		this.shapes = shapes;
	}

	public Long getId() {
		return id;
	}

}
