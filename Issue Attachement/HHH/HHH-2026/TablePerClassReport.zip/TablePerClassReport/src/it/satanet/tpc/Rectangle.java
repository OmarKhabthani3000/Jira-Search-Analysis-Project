package it.satanet.tpc;

import javax.persistence.Entity;

@Entity
public class Rectangle extends Shape {
	int x, y, widht, height;
}
