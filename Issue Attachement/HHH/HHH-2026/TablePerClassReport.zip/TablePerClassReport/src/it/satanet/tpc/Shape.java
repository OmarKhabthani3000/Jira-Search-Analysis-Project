package it.satanet.tpc;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
// making this class abstract provides a better model, but the
// cascade save extra query is the same (and this time it tries
// to update a table that's not there since "shape" does not
// get generated)
public class Shape {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	Long id;

	String name;
	
//	Un-commenting this does not work either (haven't tried the bi-directional)
//	@ManyToOne
//	@JoinColumn(name="diagram_id", updatable=false, insertable=false)
//	Diagram diagram;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}
}
