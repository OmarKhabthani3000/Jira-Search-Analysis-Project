package it.satanet.tpc;

import javax.persistence.Entity;

@Entity
public class Circle extends Shape {
	double x,y;
	double radius;
}
