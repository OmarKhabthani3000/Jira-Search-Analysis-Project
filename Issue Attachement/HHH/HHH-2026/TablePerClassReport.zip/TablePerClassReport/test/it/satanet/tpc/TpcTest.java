package it.satanet.tpc;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.dialect.HSQLDialect;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TpcTest extends TestCase {
	private SessionFactory sf;
	private AnnotationConfiguration cfg;

	@Override
	protected void setUp() throws Exception {
		cfg = new AnnotationConfiguration();
		cfg.addAnnotatedClass(it.satanet.tpc.Shape.class);
		cfg.addAnnotatedClass(it.satanet.tpc.Circle.class);
		cfg.addAnnotatedClass(it.satanet.tpc.Rectangle.class);
		cfg.addAnnotatedClass(it.satanet.tpc.Diagram.class);

		SchemaExport exp = new SchemaExport(cfg);
		exp.execute(false, true, false, true);

		sf = cfg.buildSessionFactory();
	}
	
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
		sf.close();
	}
	
	public void testDumpSql() {
		String[] statements = cfg.generateSchemaCreationScript(new HSQLDialect());
		for (String sql : statements) {
			System.out.println(sql);
		}
	}

	public void testSaveSingle() {
		Session s = sf.openSession();

		Rectangle r = new Rectangle();
		s.save(r);
		s.flush();
		s.close();
	}
	
	public void testSaveCascade() {
		Session s = sf.openSession();

		Rectangle r = new Rectangle();
		Diagram d = new Diagram();
		d.getShapes().add(r);
		s.save(d);
		s.flush();
		s.close();
	}
}
