package org.hibernate.bugs;

import javax.persistence.*;
import javax.persistence.criteria.*;

import com.example.demo.Customer;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.criteria.internal.compile.CriteriaQueryTypeQueryAdapter;
import org.hibernate.service.ServiceRegistry;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Properties;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase extends Assert {

    private static final Logger log = LoggerFactory.getLogger(JPAUnitTestCase.class);

    private EntityManagerFactory entityManagerFactory;

    private SessionFactory sessionFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");

        StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder();
        Metadata metadata = new MetadataSources(srb.build())
                .addAnnotatedClass(Customer.class)
                .buildMetadata();
        sessionFactory = metadata.buildSessionFactory();

        initData();
    }

    private void initData() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        session.save(new Customer(1L, "Jack", "Bauer"));
        session.save(new Customer(2L, "Chloe", "O'Brian"));
        session.save(new Customer(3L, "Kim", "Bauer"));
        session.save(new Customer(4L, "Jack", "Palmer"));
        session.save(new Customer(5L, "Michelle", "Dessler"));

        transaction.commit();
        session.close();
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
        sessionFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh7613Test() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        CriteriaBuilder builder = entityManager.getCriteriaBuilder();

        CriteriaQuery<Tuple> criteria = builder.createTupleQuery();
        Root<Customer> customerRoot = criteria.from(Customer.class);

        Path<String> firstName = customerRoot.get("firstName");
        Expression<String> firstNameLetter = builder.substring(firstName, 1, 1);
        criteria.multiselect(firstName, firstNameLetter, builder.count(customerRoot));
        criteria.groupBy(firstName, firstNameLetter);

        TypedQuery<Tuple> query = entityManager.createQuery(criteria);
        List<Tuple> resultList = query.getResultList();

        String queryString = ((CriteriaQueryTypeQueryAdapter) query).getQueryString();
        String groupBySelectionString = "substring(generatedAlias0.firstName,1,1)";

        assertEquals("Group By expression isn't alias", 1, StringUtils.countMatches(queryString, groupBySelectionString));
        assertTrue("Empty result", resultList.size() > 0);

        resultList.forEach((Tuple tuple) -> {
            log.info(tuple.get(0) + " " + tuple.get(1) + " " + tuple.get(2));
        });

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
