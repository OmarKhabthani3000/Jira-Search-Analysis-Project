package hibernateunittest.timestampfault;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Iterator;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author jbaja
 */
public class HibernateTimestampTest
{
  public static EntityManagerFactory emf = Persistence.createEntityManagerFactory("HibernateUnitTestPU");

  @Before
  public void setUp()
  {
    addSenderAndEvents();
  }

  
  public static List<LastSenderEventTime> getLastSenderEvents()
  {
    EntityManager em = emf.createEntityManager();
    try
    {
      em.getTransaction().begin();

      Query q = em.createNamedQuery("getLatestEventTimes");
      List<LastSenderEventTime> entries = q.getResultList();

      em.getTransaction().commit();
      return entries;
    }
    finally
    {
      em.close();
    }
  }  
  
  public static void addSenderAndEvents()
  {
    EntityManager em = emf.createEntityManager();
    try
    {
      em.getTransaction().begin();
      
      Sender sender = new Sender();
      PendingEvent event1 = new PendingEvent();
      sender.addPendingEvent(new PendingEvent());
      sender.addPendingEvent(new PendingEvent());
      
      em.persist(sender);
      em.getTransaction().commit();
    }
    finally
    {
      em.close();
    }
  }
  
  
  @Test
  public void testTimestampInAggregate()
  {
    List<LastSenderEventTime> senderEvents = getLastSenderEvents();
    for (Iterator<LastSenderEventTime> it = senderEvents.iterator(); it.hasNext();)
    {
      LastSenderEventTime lastSenderEventTime = it.next();
      System.out.println(lastSenderEventTime.getSenderId() + " : " + lastSenderEventTime.getEventTime());
    }    
  }    
}