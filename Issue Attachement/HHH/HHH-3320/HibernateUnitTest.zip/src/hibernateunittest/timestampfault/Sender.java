/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hibernateunittest.timestampfault;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 *
 * @author jbaja
 */
@Entity
@Table(name="senders")
@NamedQuery(name = "getLatestEventTimes",
query = "SELECT NEW hibernateunittest.timestampfault.LastSenderEventTime(p.sender.id, MAX(p.eventTime)) " +
        "FROM PendingEvent p " +
        "GROUP BY p.sender.id ")
public class Sender implements Serializable
{
  @Id
  @SequenceGenerator(name="SenderSeq", sequenceName="sender_id_seq")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="SenderSeq")
  @Column(name="id", nullable=false, updatable=false, insertable=true)
  private Long id;    
  
  @OneToMany(fetch = FetchType.EAGER, targetEntity = PendingEvent.class, mappedBy = "sender", cascade=CascadeType.ALL)
  private Set<PendingEvent> pendingEvents = Collections.synchronizedSet(new HashSet<PendingEvent>());


  public Long getId()
  {
    return id;
  }

  public void setId(Long id)
  {
    this.id = id;
  }
  
   public void addPendingEvent(PendingEvent pendingEvent)
  {
    pendingEvents.add(pendingEvent);
    pendingEvent.setSender(this);
  }      
}
