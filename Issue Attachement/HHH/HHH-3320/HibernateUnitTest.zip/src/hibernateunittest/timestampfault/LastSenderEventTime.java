/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hibernateunittest.timestampfault;

import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author jbaja
 */
public class LastSenderEventTime 
{
  private Long senderId;
  
  //if the following is changed to Date it works
  private Timestamp eventTime;
//  private Date eventTime;
  
//  public LastSenderEventTime(Long senderId, Date eventTime)
    public LastSenderEventTime(Long senderId, Timestamp eventTime)
  {
    this.senderId = senderId;
    this.eventTime = eventTime;
  }

//  public Date getEventTime()
  public Timestamp getEventTime()
  {
    return eventTime;
  }

  public Long getSenderId()
  {
    return senderId;
  }      
}
