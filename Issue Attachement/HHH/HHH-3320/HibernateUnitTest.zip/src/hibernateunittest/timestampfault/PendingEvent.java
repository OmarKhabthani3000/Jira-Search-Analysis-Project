/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hibernateunittest.timestampfault;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

/**
 *
 * @author jbaja
 */
@Entity
@Table(name="pending_events")
public class PendingEvent implements Serializable
{
  @Id
  @SequenceGenerator(name="PendingEventSeq", sequenceName="pending_event_id_seq")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="PendingEventSeq")
  @Column(name="id", nullable=false, updatable=false, insertable=true)
  private Long id;
  
  @Column(name="event_time", updatable=false, nullable=false)
  private Timestamp eventTime = new Timestamp(System.currentTimeMillis());

  @ManyToOne(optional=false, fetch=FetchType.EAGER)
  @JoinColumn (name="sender_id", referencedColumnName="id", nullable=false)
  private Sender sender;        

  public Long getId()
  {
    return id;
  }

  public void setId(Long id)
  {
    this.id = id;
  }

  
  public Timestamp getEventTime()
  {
    return eventTime;
  }

  public void setEventTime(Timestamp eventTime)
  {
    this.eventTime = eventTime;
  }

  public Sender getSender()
  {
    return sender;
  }

  public void setSender(Sender sender)
  {
    this.sender = sender;
  }  
}
