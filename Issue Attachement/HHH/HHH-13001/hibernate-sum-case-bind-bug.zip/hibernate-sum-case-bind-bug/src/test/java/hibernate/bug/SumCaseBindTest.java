package hibernate.bug;

import hibernate.bug.model.Document;
import hibernate.bug.model.Person;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.*;
import javax.persistence.criteria.*;
import java.util.List;

public class SumCaseBindTest {

    private EntityManagerFactory emf;

    @Before
    public void init() {
        emf = Persistence.createEntityManagerFactory("Test");

        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        Person p1 = new Person();
        Person p2 = new Person();
        Document d = new Document();

        p1.getLocalized().put(1, "p1.1");
        p1.getLocalized().put(2, "p1.2");
        p2.getLocalized().put(1, "p2.1");
        p2.getLocalized().put(2, "p2.2");

        d.getContacts().put(1, p1);
        d.getContacts().put(2, p2);

        em.persist(p1);
        em.persist(p2);
        em.persist(d);

        em.flush();
        tx.commit();
        em.close();
    }

    @Test
    public void testSum() {
        EntityManager em = emf.createEntityManager();
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Tuple> query = cb.createTupleQuery();
        Root<Document> document = query.from(Document.class);
        Join contacts = document.join("contacts", JoinType.LEFT);
        Root<Person> person = query.from(Person.class);

        query
                .multiselect(
                        document.get("id"),
                        cb.sum(
                                cb.<Long>selectCase()
                                        .when(cb.equal(contacts.get("id"), person.get("id")), cb.literal(1L))
                                        .otherwise(cb.literal(0L))
                        ).as(Long.class)
                )
                .groupBy(document.get("id"));

        List l = em.createQuery(query).getResultList();
        Assert.assertEquals(1, l.size());
    }

}
