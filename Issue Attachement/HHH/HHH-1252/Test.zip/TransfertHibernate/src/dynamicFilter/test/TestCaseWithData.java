package dynamicFilter.test;


import org.hibernate.Session;
import org.hibernate.Transaction;

import test.TestCase;
import dynamicFilter.model.Article;
import dynamicFilter.model.Libelle;
import dynamicFilter.model.Provider;
/**
 * No actual test, but only test data initialization.
 *
 * @author Anthony Patricio
 */
public abstract class TestCaseWithData extends TestCase {

	protected void initData(){
		Libelle lib1 = new Libelle("accueil","fr","bonjour");
		Libelle lib2 = new Libelle("accueil","es","ola");
		
		Provider nike = new Provider("nike");
		Provider puma = new Provider("puma");
		
		Article artc = new Article();
		artc.getLibelles().add(lib1);
		artc.getLibelles().add(lib2);
		
		artc.getProviders().add(nike);
		artc.getProviders().add(puma);
		
		artc.setCodeLibelle("accueil");
		Session session = openSession();
		Transaction tx = session.beginTransaction();
		session.persist(lib1);
		session.persist(lib2);
		session.persist(artc);
		tx.commit();
		session.close();
	}

	public TestCaseWithData(String x) {
		super(x);
	}
	

}
