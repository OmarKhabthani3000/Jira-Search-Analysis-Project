package dynamicFilter.test;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import dynamicFilter.model.Article;

/**
 * @author Anthony
 *
 * Test entity lifecycle (merge, persist, lock...) and retrieve (get).
 */
public class ArticleTest extends TestCaseWithData{
	public void testGet() throws Exception  {
		initData();
		Session session = openSession();
		Transaction tx = null ;
		tx = session.beginTransaction();
		session.enableFilter("languageFilter").setParameter("codeLangue", "fr");
		
		
		String q = "from Article a " +
				"left join fetch a.providers p " +
				"left join fetch a.libelles l";
		
		Query query = session.createQuery(q);
		
		
		// comment / uncomment these lines to produce the strage behaviour
		Article article = (Article)query.list().get(0);
		//Article article = (Article)session.get(Article.class, new Long(1));
		
		assertEquals(article.getLibelle(),"bonjour");
		tx.commit();
		session.close();

	}
	public ArticleTest(String arg0) {
		super(arg0);
	}
	
	public String[] getMappings() {
		return new String[] {"" +
				"dynamicFilter/model/Article.hbm.xml",
				"dynamicFilter/model/Provider.hbm.xml",
				"dynamicFilter/model/Libelle.hbm.xml"
				};
	}

	public static Test suite() {
		return new TestSuite(ArticleTest.class);
	}
	
	public static void main(String[] args) throws Exception {
		TestRunner.run( suite() );
	}
}
