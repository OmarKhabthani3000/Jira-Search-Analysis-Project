package dynamicFilter.model;

import java.io.Serializable;

public class Libelle implements Serializable{

	private Long idLibelle;
	private String codeLibelle;
	private String codeLangue;
	private String libelle;
	
	public Libelle(String codeLibelle, String codeLangue, String libelle){
		super();
		this.codeLangue = codeLangue;
		this.libelle = libelle;
	}
	
	public Libelle(){
		super();
	}
	
	public String getCodeLangue() {
		return codeLangue;
	}
	public void setCodeLangue(String codeLangue) {
		this.codeLangue = codeLangue;
	}
	public String getLibelle() {
		return libelle;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public Long getIdLibelle() {
		return idLibelle;
	}

	public void setIdLibelle(Long id) {
		this.idLibelle = id;
	}

	public String getCodeLibelle() {
		return codeLibelle;
	}

	public void setCodeLibelle(String codeLibelle) {
		this.codeLibelle = codeLibelle;
	}

}
