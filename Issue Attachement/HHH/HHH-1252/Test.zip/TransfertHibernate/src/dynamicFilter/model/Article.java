package dynamicFilter.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Article implements Serializable{
	//private Long articleId;
	private List libelles = new ArrayList();
	private String codeLibelle;
	private List providers = new ArrayList();
	
	public List getLibelles() {
		return libelles;
	}
	public void setLibelles(List libelles) {
		this.libelles = libelles;
	}
	
	public String getLibelle(){
		if (getLibelles().size()!=1)
			throw new RuntimeException("you haven't set any language");
		return ((Libelle)getLibelles().iterator().next()).getLibelle();
	}
	public String getCodeLibelle() {
		return codeLibelle;
	}
	public void setCodeLibelle(String libelleId) {
		this.codeLibelle = libelleId;
	}
	public List getProviders() {
		return providers;
	}
	public void setProviders(List providers) {
		this.providers = providers;
	}

	

}
