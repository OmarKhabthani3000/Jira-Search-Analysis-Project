/**
 * BaseTestCase.java
 * User: jonaka
 * Date: 2006-10-11
 * Time: 11:33:23
 *
 * Copyright (c) 2006 Roche Poland Ltd.
 */
package test;

import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;

import java.util.Properties;
import java.io.IOException;
import java.io.FileInputStream;

import junit.framework.TestCase;
import test.sqlquery.Entity;

/**
 * BaseTestCase
 *
 * @author jonaka
 * @version $Id$
 */
public class BaseTestCase extends TestCase {
	protected SessionFactory sf;
	protected Session session;

	protected void readProperties(Properties props) throws IOException {
		FileInputStream fin = new FileInputStream("test/conf/test.properties");
		props.load(fin);
		fin.close();

		props.setProperty("hibernate.connection.driver_class",props.getProperty("database.jdbc.driver"));
		props.setProperty("hibernate.connection.url",props.getProperty("database.jdbc.url"));
		props.setProperty("hibernate.connection.username",props.getProperty("database.user"));
		props.setProperty("hibernate.connection.password",props.getProperty("database.pass"));
	}

	private void init() throws IOException {
		Properties props = new Properties();
		readProperties(props);
		Configuration cfg = new Configuration()
				.setProperties(props)
				.addClass(Entity.class)
				;
		sf = cfg.buildSessionFactory();
	}


	protected void setUp() throws Exception {
		super.setUp();
		init();
		session = sf.openSession();
	}


	protected void tearDown() throws Exception {
		super.tearDown();
		session.close();
	}
}
