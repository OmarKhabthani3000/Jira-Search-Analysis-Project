/**
 * Entity.java
 * User: jonaka
 * Date: 2006-10-11
 * Time: 11:36:36
 *
 * Copyright (c) 2006 Roche Poland Ltd.
 */
package test.sqlquery;

import java.io.Serializable;
import java.util.Set;

/**
 * Entity
 *
 * @author jonaka
 * @version $Id$
 */
public class Entity implements Serializable {
	private String documentId;
	private Set areas;

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public Set getAreas() {
		return areas;
	}

	public void setAreas(Set areas) {
		this.areas = areas;
	}

	public int hashCode() {
		return this.documentId.hashCode();
	}

	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		Entity entity = (Entity) o;

		if (!documentId.equals(entity.documentId)) return false;

		return true;
	}

	public String toString() {
		return "Entity{" +
				"documentId='" + documentId + '\'' +
				", areas=" + areas +
				'}';
	}
}
