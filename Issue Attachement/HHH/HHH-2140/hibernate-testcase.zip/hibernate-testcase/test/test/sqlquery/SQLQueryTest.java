/**
 * SQLQueryTest.java
 * User: jonaka
 * Date: 2006-10-11
 * Time: 11:45:13
 *
 * Copyright (c) 2006 Roche Poland Ltd.
 */
package test.sqlquery;

import test.BaseTestCase;

import java.util.List;
import java.util.ArrayList;
import java.util.LinkedHashSet;

/**
 * SQLQueryTest
 *
 * @author jonaka
 * @version $Id$
 */
public class SQLQueryTest extends BaseTestCase {

	public void testSQLQuery() throws Exception {
		List result = session.createSQLQuery(
			"select distinct {entity.*}, {areas.*} from TEntity entity join TArea areas on entity.DocumentId=areas.DocumentId " +
			"where areas.Name like 'BS - CF%'")
		.addEntity("entity", Entity.class)
		.addJoin("areas", "entity.Areas")
		.list();
		System.out.println("" + result);
	}
}
