package org.hibernate.bugs.hhh9754;

public interface EntityWithAuditSupportColumns
{
    public AuditSupportColumns getAuditSupportColumns();

    public void setAuditSupportColumns(AuditSupportColumns auditSupportColumns);
}
