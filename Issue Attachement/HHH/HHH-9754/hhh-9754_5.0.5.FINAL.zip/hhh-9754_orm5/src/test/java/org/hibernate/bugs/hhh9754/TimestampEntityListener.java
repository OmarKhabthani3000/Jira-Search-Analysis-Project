package org.hibernate.bugs.hhh9754;

import java.util.Date;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

public class TimestampEntityListener
{
    @PrePersist
    public void onCreate(Object entity)
    {
        if (entity instanceof EntityWithAuditSupportColumns)
        {
            EntityWithAuditSupportColumns eact = (EntityWithAuditSupportColumns) entity;
            if (eact.getAuditSupportColumns() == null)
                eact.setAuditSupportColumns(new AuditSupportColumns());

            eact.getAuditSupportColumns().setCreatedOn(new Date());
            eact.getAuditSupportColumns().setLastModifiedOn(eact.getAuditSupportColumns().getCreatedOn());
        }
    }

    @PreUpdate
    public void onUpdate(Object entity)
    {
        if (entity instanceof EntityWithAuditSupportColumns)
        {
            EntityWithAuditSupportColumns eact = (EntityWithAuditSupportColumns) entity;
            if (eact.getAuditSupportColumns() == null)
            {
                eact.setAuditSupportColumns(new AuditSupportColumns());
                eact.getAuditSupportColumns().setCreatedOn(new Date());
            }
            eact.getAuditSupportColumns().setLastModifiedOn(new Date());
        }
    }
}
