package org.hibernate.bugs.hhh9754;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@Entity(name = "JpaEntity")
@DynamicInsert(true)
@DynamicUpdate(true)
@Table(name = "entity")
@EntityListeners(TimestampEntityListener.class)
public class JpaEntity implements Serializable, EntityWithAuditSupportColumns
{
    private static final long serialVersionUID = -1373518821359802502L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, unique = true)
    private Long id;
    
    @Column(name = "name")
    public String name;
    
    @Embedded    
    private AuditSupportColumns auditSupportColumns = new AuditSupportColumns();

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }
    
    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    @Override
    public AuditSupportColumns getAuditSupportColumns()
    {
        return auditSupportColumns;
    }

    @Override
    public void setAuditSupportColumns(AuditSupportColumns auditSupportColumns)
    {
        this.auditSupportColumns = auditSupportColumns;
    }
    
    public Date getCreatedOn()
    {
        return auditSupportColumns.getCreatedOn();
    }
    
    public void setCreatedOn(Date createdOn)
    {
        auditSupportColumns.setCreatedOn(createdOn);
    }
    
    public Date getLastModifiedOn()
    {
        return auditSupportColumns.getLastModifiedOn();
    }
    
    public void setLastModifiedOn(Date lastModifiedOn)
    {
        auditSupportColumns.setLastModifiedOn(lastModifiedOn);
    }

    @Override
    public String toString() {
        return "JpaEntity{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", auditSupportColumns=" + auditSupportColumns +
                '}';
    }
}

