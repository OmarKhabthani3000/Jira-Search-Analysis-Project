/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import org.hibernate.bugs.hhh9754.JpaEntity;
import org.hibernate.bugs.hhh9754.TimestampEntityListener;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.jboss.logging.Logger;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import static org.junit.Assert.*;

public class hhh9754TestCase {
	@Test
	public void hhh9754() throws InterruptedException
	{
        EntityManager em = Persistence.createEntityManagerFactory("test").createEntityManager();

        String initialName = "Initial name";

        em.getTransaction().begin();
        JpaEntity entity = new JpaEntity();
        entity.setName(initialName);
        em.persist(entity);
        em.getTransaction().commit();

        em.getTransaction().begin();
        JpaEntity persistedEntity = (JpaEntity) em.find(JpaEntity.class, entity.getId());
        assertNotNull("persistedEntity - createdOn is not null", persistedEntity.getCreatedOn());
        assertNotNull("persistedEntity - lastModifiedOn is not null", persistedEntity.getLastModifiedOn());
        assertEquals("persistedEntity - createdOn == lastModifiedOn", persistedEntity.getCreatedOn().getTime(), persistedEntity.getLastModifiedOn().getTime());
        em.getTransaction().commit();

        em.getTransaction().begin();
        JpaEntity toMerge = new JpaEntity();
        toMerge.setId(persistedEntity.getId());
        toMerge.setName("Updated");
        toMerge.setCreatedOn(persistedEntity.getCreatedOn());
        toMerge.setLastModifiedOn(persistedEntity.getLastModifiedOn());
        JpaEntity updated = em.merge(toMerge);
        em.getTransaction().commit();
        em.clear();

        //Next assertion shows that the TimestampEntityListener @PreUpdate has fired and updated the entity lastModifiedOn timestamp.
        assertNotEquals("persistedEntity - createdOn != lastModifiedOn", updated.getCreatedOn().getTime(), updated.getLastModifiedOn().getTime());

        JpaEntity finalVersion = (JpaEntity) em.find(JpaEntity.class, entity.getId());

        //Next assertion shows that the updated name property was saved.
        assertNotEquals("Original name != finalVersion name", initialName, finalVersion.getName());

        //Next assertion shows that the lastModifiedOn property, which was updated by TimestampEntityListener.onUpdate, was saved.
        assertNotEquals("Final version createdOn != lastModifiedOn", finalVersion.getCreatedOn().getTime(), finalVersion.getLastModifiedOn().getTime());
	}
}
