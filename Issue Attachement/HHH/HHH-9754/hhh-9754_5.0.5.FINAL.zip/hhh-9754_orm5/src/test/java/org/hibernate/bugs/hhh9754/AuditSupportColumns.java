package org.hibernate.bugs.hhh9754;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class AuditSupportColumns
{
    @Column(name = "last_modified_date", insertable = true, updatable = true)
    private Date lastModifiedOn;

    @Column(name = "create_date", insertable = true, updatable = false)
    private Date createdOn;

    public Date getLastModifiedOn()
    {
        return lastModifiedOn;
    }

    public void setLastModifiedOn(Date lastModifiedOn)
    {
        this.lastModifiedOn = lastModifiedOn;
    }

    public Date getCreatedOn()
    {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn)
    {
        this.createdOn = createdOn;
    }

    @Override
    public String toString() {
        return "AuditSupportColumns{" +
                "lastModifiedOn=" + lastModifiedOn +
                ", createdOn=" + createdOn +
                '}';
    }
}
