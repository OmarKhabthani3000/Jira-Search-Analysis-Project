package org.hibernate.bugs;

import static org.junit.Assert.*;

import javax.persistence.EntityManager;

import org.junit.Before;
import org.junit.Test;

import domain.JpaEntity;

public class Hhh9754 {
	private EntityManager em;

	@Before
	public void setup() {
	    em = TestEntityManagerUtil.getEntityManagerFactory().createEntityManager();
	}
	
	@Test
	public void testEmbedded() throws InterruptedException
	{
	    em.getTransaction().begin();
	    JpaEntity entity = new JpaEntity();
	    entity.setName("Initial name");
	    em.persist(entity);
	    em.getTransaction().commit();
	    
	    em.getTransaction().begin();
	    JpaEntity persistedEntity = (JpaEntity) em.find(JpaEntity.class, entity.getId());
	    assertNotNull(persistedEntity.getCreatedOn());
	    assertNotNull(persistedEntity.getLastModifiedOn());
	    assertEquals(persistedEntity.getCreatedOn().getTime(), persistedEntity.getLastModifiedOn().getTime());
	    em.getTransaction().commit();
	    
	    em.getTransaction().begin();
	    JpaEntity toMerge = new JpaEntity();
	    toMerge.setId(persistedEntity.getId());
	    toMerge.setName("Updated");
	    toMerge.setCreatedOn(persistedEntity.getCreatedOn());
	    toMerge.setLastModifiedOn(persistedEntity.getLastModifiedOn());
	    JpaEntity updated = em.merge(toMerge);
        em.getTransaction().commit();
        em.clear();
        assertNotEquals(updated.getCreatedOn().getTime(), updated.getLastModifiedOn().getTime());
        
        JpaEntity finalVerion = (JpaEntity) em.find(JpaEntity.class, entity.getId());
        assertNotEquals(finalVerion.getCreatedOn().getTime(), finalVerion.getLastModifiedOn().getTime());
	}
}
