package org.hibernate.bugs;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestEntityManagerUtil
{
    public static EntityManagerFactory getEntityManagerFactory(){
        return Persistence.createEntityManagerFactory("test");
    }
}
