package domain;

public interface EntityWithAuditSupportColumns
{
    public AuditSupportColumns getAuditSupportColumns();

    public void setAuditSupportColumns(AuditSupportColumns auditSupportColumns);
}
