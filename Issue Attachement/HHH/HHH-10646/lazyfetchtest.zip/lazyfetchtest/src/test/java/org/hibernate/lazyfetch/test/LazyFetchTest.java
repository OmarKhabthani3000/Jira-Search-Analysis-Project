package org.hibernate.lazyfetch.test;

import static org.junit.Assert.fail;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.lazyfetch.entity.EnvioFirma;
import org.junit.Test;

public class LazyFetchTest
{
	@Test
	public void test()
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("lazyfetchtest");
		
		EntityManager em = emf.createEntityManager();
		
		EnvioFirma envio = new EnvioFirma();
		envio.setDatos("test data");
		em.getTransaction().begin();
		em.persist(envio);
		int id = envio.getId();
		em.getTransaction().commit();
		
		em.close();
		
		em = emf.createEntityManager();
		envio = em.find(EnvioFirma.class, id);
		String data = envio.getDatos();
		if (data == null)
			fail("lazy fetch property not retrieved");
	}
}
