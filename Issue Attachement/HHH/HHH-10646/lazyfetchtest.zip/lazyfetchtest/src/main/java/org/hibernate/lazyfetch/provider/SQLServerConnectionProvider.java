package org.hibernate.lazyfetch.provider;

import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.engine.jdbc.connections.internal.DatasourceConnectionProviderImpl;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;
import org.hibernate.jpa.AvailableSettings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class SQLServerConnectionProvider
	extends DatasourceConnectionProviderImpl
	implements ConnectionProvider
{
	private static final long		serialVersionUID	= 1L;

	private static final String	SERVER_NAME				= "veridata.connection.ServerName";
	private static final String	PORT_NUMBER				= "veridata.connection.PortNumber";
	private static final String	INSTANCE_NAME			= "veridata.connection.InstanceName";
	private static final String	DB_NAME						= "veridata.connection.DatabaseName";
	private static final String	SELECT_METHOD			= "veridata.connection.SelectMethod";
	private static final String	LOGIN_TIMEOUT			= "veridata.connection.LoginTimeout";
	private static final String	LOCK_TIMEOUT			= "veridata.connection.LockTimeout";

	private static final Logger	logger						= LoggerFactory.getLogger(SQLServerConnectionProvider.class);

	@Override
	public void configure(@SuppressWarnings("rawtypes")
	Map configValues)
		throws HibernateException
	{
		SQLServerDataSource sqlServerDataSource = new SQLServerDataSource();
		sqlServerDataSource.setServerName((String) configValues.get(SERVER_NAME));

		String portNumber = PORT_NUMBER;
		String value = (String) configValues.get(portNumber);
		if (value != null)
		{
			try
			{
				sqlServerDataSource.setPortNumber(Integer.valueOf(value));
			}
			catch (NumberFormatException e)
			{
				logger.error("Configuración - propiedad: " + portNumber, e);
			}
		}

		value = (String) configValues.get(INSTANCE_NAME);
		if (value != null)
			sqlServerDataSource.setInstanceName(value);

		sqlServerDataSource.setDatabaseName((String) configValues.get(DB_NAME));

		value = (String) configValues.get(SELECT_METHOD);
		if (value != null)
			sqlServerDataSource.setSelectMethod(value);

		String user = (String) configValues.get(AvailableSettings.JDBC_USER);
		sqlServerDataSource.setUser(user);

		String pwd = (String) configValues.get(AvailableSettings.JDBC_PASSWORD);
		sqlServerDataSource.setPassword(pwd);

		String loginTimeout = (String) configValues.get(LOGIN_TIMEOUT);
		if (loginTimeout != null)
		{
			try
			{
				int loginTO = Integer.parseInt(loginTimeout);
				sqlServerDataSource.setLoginTimeout(loginTO);
			}
			catch (NumberFormatException e)
			{
				logger.warn("Propiedad {} inválida : {}", LOGIN_TIMEOUT, loginTimeout);
			}
		}

		String lockTimeout = (String) configValues.get(LOCK_TIMEOUT);
		if (lockTimeout != null)
		{
			try
			{
				int lockTO = Integer.parseInt(lockTimeout);
				sqlServerDataSource.setLockTimeout(lockTO);
			}
			catch (NumberFormatException e)
			{
				logger.warn("Propiedad {} inválida : {}", LOCK_TIMEOUT, lockTimeout);
			}
		}

		setDataSource(sqlServerDataSource);

		super.configure(configValues);
	}
}
