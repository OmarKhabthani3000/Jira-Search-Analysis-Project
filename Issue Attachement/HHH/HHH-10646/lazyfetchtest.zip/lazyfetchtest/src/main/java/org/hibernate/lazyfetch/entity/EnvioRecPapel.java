package org.hibernate.lazyfetch.entity;

import java.io.Serializable;

import javax.persistence.Entity;

/**
 * Entity EnvioPapel
 * <p/>
 * 
 * @author Vicente
 */
@Entity
public class EnvioRecPapel
	extends Envio
	implements Serializable
{
	private static final long serialVersionUID = 1L;
}
