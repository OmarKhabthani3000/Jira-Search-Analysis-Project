package org.hibernate.lazyfetch.entity;

import static javax.persistence.FetchType.LAZY;
import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.MappedSuperclass;
import javax.validation.constraints.NotNull;

/**
 * 
 * @author Vicente
 *
 */
@MappedSuperclass
public abstract class Envio
	implements Serializable
{
	private static final long	serialVersionUID	= 1L;

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "ID", unique = true, nullable = false, updatable = false)
	private int								id;

	@NotNull
	@Lob
	@Basic(fetch = LAZY, optional = false)
	@Column(name = "Datos", nullable = false, updatable = false)
	private String						datos;

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public String getDatos()
	{
		return this.datos;
	}

	public void setDatos(String datos)
	{
		this.datos = datos;
	}
}
