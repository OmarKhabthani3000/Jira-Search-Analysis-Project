package org.hibernate.lazyfetch.provider;

import java.sql.Types;

import org.hibernate.dialect.SQLServer2008Dialect;

public class Dialect2008
	extends SQLServer2008Dialect
{
	/**
	 * Initializes a new instance of the {@link Dialect2008} class.
	 */
	public Dialect2008()
	{
		super();
		// Subclasses register a type name for the given type code.
		// $l in the type name with be replaced by the column length (if appropriate).
		// registerColumnType(Types.BIGINT, "bigint");
		// registerColumnType(Types.BIT, "bit");
		// registerColumnType(Types.BOOLEAN, "bit");
		// registerColumnType(Types.CHAR, "nchar(1)");
		// registerColumnType(Types.VARCHAR, 4000, "nvarchar($l)");
		// registerColumnType(Types.VARCHAR, "nvarchar(max)");
		// registerColumnType(Types.VARBINARY, 4000, "varbinary($1)");
		// registerColumnType(Types.VARBINARY, "varbinary(max)");
		// registerColumnType(Types.BLOB, "varbinary(max)");
		// registerColumnType(Types.CLOB, "nvarchar(max)");
		registerColumnType(Types.CLOB, "text");
		// registerColumnType(Types.DATE, "date");
		registerColumnType(Types.TIMESTAMP, "datetime");
		// registerColumnType(Types.TIMESTAMP, "datetime2(0)");
		// registerColumnType(Types.NUMERIC, "decimal");
		// registerColumnType(Types.DECIMAL, "decimal");
		// registerColumnType(Types.FLOAT, "decimal");
		// registerColumnType(Types.DOUBLE, "decimal");
	}
}