package org.hibernate.bugs.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Stuff {

    @Id
    private String id;
}
