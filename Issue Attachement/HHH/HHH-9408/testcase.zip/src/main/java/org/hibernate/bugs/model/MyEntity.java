package org.hibernate.bugs.model;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MyEntity {

    @Id
    private String id;

    @Embedded
    private Emb emb;
}
