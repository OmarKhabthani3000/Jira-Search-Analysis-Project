package org.hibernate.bugs;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.bugs.model.Emb_;
import org.hibernate.bugs.model.MyEntity;
import org.hibernate.bugs.model.MyEntity_;
import org.hibernate.bugs.model.Stuff_;
import org.hibernate.dialect.Oracle10gDialect;
import org.hibernate.jpa.internal.QueryImpl;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HHH_5792_Test {

    private Map<String, String> props;
    private EntityManagerFactory emFactory;
    private EntityManager em;

    @Before
    public void setup() {
        props = new HashMap<String, String>();
        props.put("hibernate.dialect", Oracle10gDialect.class.getName());

        emFactory = Persistence.createEntityManagerFactory("domain", props);
        em = emFactory.createEntityManager();
    }

    @After
    public void teardown() {
        em.close();
        emFactory.close();
    }

    @Test
    public void testHQL_EmbeddedWithJoin_Alone() {
        String hql = "FROM " + MyEntity.class.getSimpleName() + " e join e.emb e2";

        Assert.assertNotNull(em.createQuery(hql).unwrap(QueryImpl.class).getHibernateQuery().getQueryString());
    }

    @Test
    public void testHQL_EmbeddedWithJoin_WithWhereClause() {
        String hql = "FROM " + MyEntity.class.getSimpleName() + " e join e.emb e2 where e2 is not null";

        Assert.assertNotNull(em.createQuery(hql).unwrap(QueryImpl.class).getHibernateQuery().getQueryString());
    }

    @Test
    public void testHQL_EmbeddedWitDot() {
        String hql = "FROM " + MyEntity.class.getSimpleName() + " e join e.emb.stuffs s WHERE s.id = :id";

        Assert.assertNotNull(em.createQuery(hql).unwrap(QueryImpl.class).getHibernateQuery().getQueryString());
    }

    @Test
    public void testCriteriaQuery() {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<MyEntity> criteriaQuery = cb.createQuery(MyEntity.class);

        Root<MyEntity> root = criteriaQuery.from(MyEntity.class);
        criteriaQuery.select(root).where(cb.equal(root.join(MyEntity_.emb).join(Emb_.stuffs).get(Stuff_.id), "42"));

        Assert.assertNotNull(em.createQuery(criteriaQuery).unwrap(QueryImpl.class).getHibernateQuery().getQueryString());
    }
    
    @Test
    public void testCriteriaQueryWithStrings() {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<MyEntity> criteriaQuery = cb.createQuery(MyEntity.class);

        Root<MyEntity> root = criteriaQuery.from(MyEntity.class);
        criteriaQuery.select(root).where(cb.equal(root.join("emb").join("stuffs").get("id"), "42"));

        Assert.assertNotNull(em.createQuery(criteriaQuery).unwrap(QueryImpl.class).getHibernateQuery().getQueryString());
    }

}
