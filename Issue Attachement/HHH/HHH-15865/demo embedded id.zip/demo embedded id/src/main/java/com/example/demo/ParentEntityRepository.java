package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

interface ParentEntityRepository extends JpaRepository<ParentEntity, Integer> {
}
