package com.example.demo;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequestMapping("/test")
@RestController
@CrossOrigin
@AllArgsConstructor
class TestController {
    private final ParentEntityRepository repository;

    @PostMapping
    public void createParentEntity() {
        ParentEntityIdWrapper idWrapper = new ParentEntityIdWrapper(
                new ParentEntityId(1)
        );
        ParentEntity parentEntity = new ParentEntity(
                idWrapper,
                List.of(new ChildEntity())
        );
        repository.save(parentEntity);
    }
}
