package com.example.demo;

import jakarta.persistence.CascadeType;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Table(name = "parent_entity")
@NoArgsConstructor
@Getter
@AllArgsConstructor
class ParentEntity {
    @EmbeddedId
    private ParentEntityIdWrapper parentEntityIdWrapper;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "parent_entity_id", referencedColumnName = "id")
    List<ChildEntity> childEntities;
}
