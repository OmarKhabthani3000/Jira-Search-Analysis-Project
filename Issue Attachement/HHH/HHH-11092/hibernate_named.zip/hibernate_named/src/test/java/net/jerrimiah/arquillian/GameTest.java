package net.jerrimiah.arquillian;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.Archive;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(Arquillian.class)
public class GameTest {

    @Deployment
    public static Archive<?> init() {
        Archive war =
            ShrinkWrap.create(JavaArchive.class) //
            .addClass(Game.class) //
            .addAsResource("test-persistence.xml", "META-INF/persistence.xml") //
            .addAsManifestResource(EmptyAsset.INSTANCE, "beans.xml");
        System.out.println(war.toString(true));
        return war;
    }

    private static final String[] GAME_TITLES = { "Halo", "Grand Theft Auto", "NetHack" };

    @PersistenceContext
    private EntityManager entityManager;

    @Inject
    private UserTransaction utx;

    @Before
    public void setUp()
        throws Exception {
        clearData();
        insertData();
        startTransaction();
    }

    private void clearData()
        throws Exception {
        utx.begin();
        entityManager.joinTransaction();
        System.out.println("Deleting old recoreds..");
        entityManager.createQuery("delete from Game").executeUpdate();
        utx.commit();
    }

    private void insertData()
        throws Exception {
        utx.begin();
        entityManager.joinTransaction();
        System.out.println("Inserting records...");
        for (String title : GAME_TITLES) {
            Game game = new Game(title);
            entityManager.persist(game);
        }
        utx.commit();
        entityManager.clear();
    }

    private void startTransaction()
        throws Exception {
        utx.begin();
        entityManager.joinTransaction();
    }

    @After
    public void tearDown()
        throws Exception {
        utx.commit();
    }

    @Test
    public void testNamedQuery_ordinal_parameter() {
        Query query = entityManager.createNamedQuery("NamedQuery");
        query.setParameter(1, GAME_TITLES[0]);
        List list = query.getResultList();
        assertEquals(1, list.size());
    }
    
    @Test
    public void testNamedNativeQuery_ordinal_parameter() {
        Query query = entityManager.createNamedQuery("NamedNativeQuery");
        query.setParameter(1, GAME_TITLES[0]);
        List list = query.getResultList();
        assertEquals(1, list.size());
    }
}
