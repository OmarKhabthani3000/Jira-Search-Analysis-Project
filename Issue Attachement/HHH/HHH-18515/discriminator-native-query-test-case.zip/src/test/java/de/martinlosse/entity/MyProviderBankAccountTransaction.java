package de.martinlosse.entity;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue(Provider.MY_PROVIDER_VALUE)
public class MyProviderBankAccountTransaction extends BankAccountTransaction {

  private String myProviderValue;

  public String getMyProviderValue() {
    return myProviderValue;
  }

  public void setMyProviderValue(final String myProviderValue) {
    this.myProviderValue = myProviderValue;
  }
}
