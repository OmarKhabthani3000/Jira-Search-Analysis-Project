package de.martinlosse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.DiscriminatorType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "provider", discriminatorType = DiscriminatorType.STRING)
public abstract class BankAccountTransaction {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private LocalDate bookingDate;

  private BigDecimal amount;

  @Column(insertable = false, updatable = false)
  @Enumerated(EnumType.STRING)
  private Provider provider;

  public void setId(final Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public BigDecimal getAmount() {
    return amount;
  }

  public void setAmount(final BigDecimal amount) {
    this.amount = amount;
  }

  public LocalDate getBookingDate() {
    return bookingDate;
  }

  public void setBookingDate(final LocalDate bookingDate) {
    this.bookingDate = bookingDate;
  }

  public Provider getProvider() {
    return provider;
  }

  private void setProvider(final Provider provider) {
    this.provider = provider;
  }

}
