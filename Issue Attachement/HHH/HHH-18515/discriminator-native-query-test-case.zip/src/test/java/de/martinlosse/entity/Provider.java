package de.martinlosse.entity;

public enum Provider {

  MY_PROVIDER;

  public static final String MY_PROVIDER_VALUE = "MY_PROVIDER";

}
