/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import static org.assertj.core.api.Assertions.assertThat;

import de.martinlosse.entity.BankAccountTransaction;
import de.martinlosse.entity.MyProviderBankAccountTransaction;

import de.martinlosse.entity.Provider;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.util.function.Consumer;

class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@BeforeEach
	void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@AfterEach
	void destroy() {
		entityManagerFactory.close();
	}

	@Test
	void jpqlQueryShouldRetrieveEntityWithDiscriminatorColumn() {
		final var bankAccountTransaction = createBankAccountTransaction();

		withEntityManagerDo(entityManager -> entityManager.persist(bankAccountTransaction));
		withEntityManagerDo(entityManager -> {
			final var query = entityManager.createQuery(
					"FROM BankAccountTransaction bat WHERE bat.id = " + bankAccountTransaction.getId(),
					BankAccountTransaction.class);

			final var savedTransaction = query.getSingleResult();

			assertThat(savedTransaction).isInstanceOf(MyProviderBankAccountTransaction.class);
			assertThat(savedTransaction.getProvider()).isEqualTo(Provider.MY_PROVIDER);
		});
	}

	@Test
	void nativeQueryShouldRetrieveEntityWithDiscriminatorColumn() {
		final var bankAccountTransaction = createBankAccountTransaction();

		withEntityManagerDo(entityManager -> entityManager.persist(bankAccountTransaction));
		withEntityManagerDo(entityManager -> {
			final var query = entityManager.createNativeQuery(
					"SELECT * FROM bankaccounttransaction bat WHERE id = " + bankAccountTransaction.getId(),
					BankAccountTransaction.class);

			final var savedTransaction = (BankAccountTransaction) query.getSingleResult();

			assertThat(savedTransaction).isInstanceOf(MyProviderBankAccountTransaction.class);
			assertThat(savedTransaction.getProvider()).isEqualTo(Provider.MY_PROVIDER);
		});
	}

	private void withEntityManagerDo(Consumer<EntityManager> consumer) {
		final EntityManager entityManager = entityManagerFactory.createEntityManager();
		final EntityTransaction transaction = entityManager.getTransaction();

		try {
			transaction.begin();
			consumer.accept(entityManager);
			transaction.commit();
		} catch (RuntimeException e) {
			transaction.rollback();
			throw e;
		} finally {
			entityManager.close();
		}
	}

	private static MyProviderBankAccountTransaction createBankAccountTransaction() {
		final var bankAccountTransaction = new MyProviderBankAccountTransaction();
		bankAccountTransaction.setAmount(BigDecimal.ONE);
		bankAccountTransaction.setBookingDate(LocalDate.of(2024, Month.JANUARY, 1));
		bankAccountTransaction.setMyProviderValue("my value");

		return bankAccountTransaction;
	}
}
