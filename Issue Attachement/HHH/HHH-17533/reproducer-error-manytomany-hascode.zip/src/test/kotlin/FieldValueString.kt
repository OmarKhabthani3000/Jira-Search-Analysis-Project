import jakarta.persistence.DiscriminatorValue
import jakarta.persistence.Entity
import org.jetbrains.annotations.NotNull

@Entity
@DiscriminatorValue(value = "STRING")
class FieldValueString : SimpleFieldValue<String>() {

    @NotNull
    lateinit var valueString: String
    override fun getValue(): String {
        return valueString
    }

    override fun compareTo(other: AbstractFieldValue): Int {
        TODO("Not yet implemented")
    }
}
