abstract class SimpleFieldValue<T : Any> : AbstractFieldValue() {
    abstract fun getValue(): T
}
