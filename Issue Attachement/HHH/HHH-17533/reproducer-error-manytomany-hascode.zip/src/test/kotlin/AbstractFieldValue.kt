
import jakarta.persistence.CascadeType
import jakarta.persistence.Column
import jakarta.persistence.DiscriminatorColumn
import jakarta.persistence.Entity
import jakarta.persistence.EnumType
import jakarta.persistence.Enumerated
import jakarta.persistence.OneToMany
import jakarta.persistence.Table

@Entity
@Table(name = "field_value")
@DiscriminatorColumn(name = "type")
abstract class AbstractFieldValue : AbstractEntity(), Comparable<AbstractFieldValue> {
    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false, insertable = false, updatable = false)
    var type: Type? = null

    @OneToMany(mappedBy = "fieldValue", orphanRemoval = true, cascade = [CascadeType.ALL])
    var nodes: MutableSet<NodeFieldValue> = mutableSetOf()


    enum class  Type {
        STRING
    }

    override fun hashCode(): Int {
        return uuid.hashCode()
    }


}
