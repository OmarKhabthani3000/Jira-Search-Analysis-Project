
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.MappedSuperclass
import java.time.Instant
import org.hibernate.annotations.JdbcTypeCode
import org.hibernate.type.SqlTypes
import java.util.UUID

@MappedSuperclass
abstract class AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    var id: Long? = null


    @JdbcTypeCode(SqlTypes.CHAR)
    var uuid: UUID = UUID.randomUUID()

    var createdDate: Instant = Instant.now()
    var updatedDate: Instant? = null

    fun isNew(): Boolean {
        return id == null
    }
}