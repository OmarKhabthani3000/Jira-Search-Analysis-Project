import jakarta.persistence.CascadeType
import jakarta.persistence.Entity
import jakarta.persistence.OneToMany

@Entity
class Node : AbstractEntity() {


    @OneToMany(mappedBy = "node", orphanRemoval = true, cascade = [CascadeType.PERSIST,CascadeType.MERGE])
    var fieldValues: MutableSet<NodeFieldValue> = mutableSetOf()


    fun addFieldValue(fieldValue: AbstractFieldValue) {
        val nodeFieldValue = NodeFieldValue(fieldValue, this)
        fieldValues.add(nodeFieldValue)
        fieldValue.nodes.add(nodeFieldValue)
    }

    fun removeFieldValue(fieldValue: AbstractFieldValue) {
        val nodeFieldValue = NodeFieldValue(fieldValue, this)
        fieldValue.nodes.remove(nodeFieldValue)
        fieldValues.remove(nodeFieldValue)
        nodeFieldValue.fieldValue = null
        nodeFieldValue.node = null
    }


    override fun hashCode(): Int {
        return uuid.hashCode()
    }


}
