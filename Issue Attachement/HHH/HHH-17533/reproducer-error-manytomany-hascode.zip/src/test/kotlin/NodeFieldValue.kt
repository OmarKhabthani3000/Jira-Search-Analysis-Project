
import jakarta.persistence.CascadeType
import jakarta.persistence.Entity
import jakarta.persistence.Id
import jakarta.persistence.JoinColumn
import jakarta.persistence.ManyToOne
import jakarta.persistence.Table

@Table(name="node_field_value")
@Entity
class NodeFieldValue(

    @ManyToOne(cascade = [CascadeType.PERSIST, CascadeType.MERGE])
    @JoinColumn(name = "field_value_id")
    @Id
    var fieldValue: AbstractFieldValue? = null,

    @ManyToOne
    @JoinColumn(name = "node_id")
    @Id
    var node: Node? = null

)
