import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test

class JPAUnitTest {

    private var entityManagerFactory: EntityManagerFactory? = null

    @Before
    fun init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU")
    }

    @After
    fun destroy() {
        entityManagerFactory?.close()
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    @Throws(Exception::class)
    fun hhh123Test() {
        val entityManager: EntityManager = entityManagerFactory!!.createEntityManager()
        entityManager.getTransaction().begin()

        val fieldValueString =  FieldValueString()
        fieldValueString.valueString="test"
        val node = Node()
        node.addFieldValue(fieldValueString);
        entityManager.persist(node)

        entityManager.getTransaction().commit()
        entityManager.close()
    }
}