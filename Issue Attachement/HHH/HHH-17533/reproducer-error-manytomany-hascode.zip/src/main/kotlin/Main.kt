package org.example

fun main() {
    println("Hello World!")
}