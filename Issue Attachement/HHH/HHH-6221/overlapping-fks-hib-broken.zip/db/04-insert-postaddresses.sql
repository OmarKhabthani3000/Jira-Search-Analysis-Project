INSERT INTO PostAddresses (contact_id, ordinal_nbr, country_code, state_code, zip_code, city_name, street_name, street_nbr) VALUES
(1, 1, 'DE', 'HE', '64846', 'Groß-Zimmern', 'Otzbergring', '48'),
(1, 2, 'DE', 'SH', '22880', 'Wedel', 'Rosengarten', '6'),
(2, 1, 'DE', 'HE', '64846', 'Groß-Zimmern', 'Hirschbachweg', '34a'),
(2, 2, 'DE', 'SH', '22880', 'Wedel', 'Rosengarten', '6'),
(3, 1, 'DE', 'HE', '64807', 'Dieburg', 'Tralalastraße', '15b'),
(4, 1, 'DE', 'HE', '64839', 'Münster', 'Goethestraße', '2'),
(5, 1, 'DE', 'HE', '64859', 'Eppertshausen', 'Hauptstraße', '76');