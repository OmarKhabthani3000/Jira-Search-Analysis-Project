CREATE TABLE Zips
(
  country_code CHAR(2) NOT NULL,
  code VARCHAR(10) NOT NULL,
  PRIMARY KEY (country_code, code)
);

CREATE TABLE Cities
(
  country_code CHAR(2) NOT NULL,
  state_code VARCHAR(5) NOT NULL,
  name VARCHAR(100) NOT NULL,
  PRIMARY KEY (country_code, state_code, name)
);

CREATE TABLE PostAreas
(
  country_code CHAR(2) NOT NULL, -- used twice in FKs!
  state_code VARCHAR(5) NOT NULL,
  zip_code VARCHAR(10) NOT NULL,
  city_name VARCHAR(100) NOT NULL,
  PRIMARY KEY (country_code, zip_code, state_code, city_name),
  CONSTRAINT postareas_zips_fk
    FOREIGN KEY (country_code, zip_code)
    REFERENCES Zips (country_code, code)
    ON DELETE NO ACTION
    ON UPDATE CASCADE,
  CONSTRAINT postareas_cities_fk
    FOREIGN KEY (country_code, state_code, city_name)
    REFERENCES Cities (country_code, state_code, name)
    ON DELETE NO ACTION
    ON UPDATE CASCADE
);

CREATE TABLE PostAddresses
(
  contact_id INTEGER NOT NULL,
  ordinal_nbr INTEGER NOT NULL,
  country_code CHAR(2) NOT NULL,
  state_code VARCHAR(5) NOT NULL,
  zip_code VARCHAR(10) NOT NULL,
  city_name VARCHAR(100) NOT NULL,
  street_name VARCHAR(100) NULL,
  street_nbr VARCHAR(10) NULL,
  PRIMARY KEY (contact_id, ordinal_nbr),
  CONSTRAINT postaddresses_postareas_fk
    FOREIGN KEY (country_code, state_code, zip_code, city_name)
    REFERENCES PostAreas (country_code, state_code, zip_code, city_name)
    ON DELETE NO ACTION
    ON UPDATE CASCADE
);