
package tld.standalone;

import java.io.*;
import java.util.*;
import java.util.logging.*;
import java.sql.*;
import java.text.*;

import javax.sql.*;
import javax.persistence.*;

//import javax.jdo.*;

import tld.standalone.bbstats.model.*;
import tld.standalone.bbstats.view.*;

public class Main
{
		
	public static void main(String... sArgs) throws Exception
	{
		String sDbName = "standalone";

		/*JDOEnhancer enhancer = JDOHelper.getEnhancer();
		enhancer.setVerbose(true);
		enhancer.addPersistenceUnit(sDbName);
		enhancer.enhance();*/
		
		//createInMemoryDbViaJdbc(sDbName); // via JDBC statements
	
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(sDbName);
		EntityManager em = emf.createEntityManager();
		
		System.out.println();
		System.out.println("Entity manager created!");
		System.out.println();
		
		/*TeamMember tm1 = em.find(TeamMember.class, new TeamMemberId(1, 1));
		System.out.println("Loaded team member = " + tm1);
		
		TeamMember tm2 = em.find(TeamMember.class, new TeamMemberId(2, 1));
		System.out.println("Loaded team member = " + tm2);
		
		TeamMember tm3 = em.find(TeamMember.class, new TeamMemberId(3, 1));
		System.out.println("Loaded team member = " + tm3);
		
		PlayerStat ps = em.find(PlayerStat.class, new PlayerStatId(5, false, 2, 1));
		System.out.println("Loaded player stat = " + ps);
		
		Stat stat = em.find(Stat.class, new StatId(5, false, 2, 1, 1));
		System.out.println("Loaded stat = " + stat);//*/
		
		//String sJpqlStandings = readFile(new File("db" + File.separator + "jpql", "standings-el-sum-bug-jpql.sql"));
		String sJpqlStandings = readFile(new File("db" + File.separator + "jpql", "standings-jpql.sql"));
		
		System.out.println(sJpqlStandings);

		//List<StringLine> lsStringLines = em.createQuery(sJpqlStandings, StringLine.class)
		List<StringLine> lsStringLines = em.createQuery(sJpqlStandings)
			//.setParameter("", arg1)
			.getResultList();

		String[] sHeaders = getConstructorExpressions(sJpqlStandings);
		
		String[] sMaxValues = new String[sHeaders.length];
		
		// init to headers
		System.arraycopy(sHeaders, 0, sMaxValues, 0, sHeaders.length);
		
		for ( StringLine slRow : lsStringLines )
		{
			int col = 0;
			
			for ( Object o : slRow.getValues() )
			{
				String sObject = null;
				
				if ( o == null )
				{
					sObject = "null";
				}
				else
				{
					sObject = o.toString();
				}
				
				// only assign new object value if not set yet (null) or the new value is wider
				if ( /*sMaxValues[col] == null ||*/ sObject.length() > sMaxValues[col].length() )
				{
					sMaxValues[col] = sObject;
				}
				
				col++;
			}
		}
		
		String[] sAdjustedHeaders = new String[sMaxValues.length];
		
		int i = 0;
		
		// max expressions found, now adjust headers if values are wider
		for ( String sMaxValue : sMaxValues )
		{
			String sHeader = sHeaders[i];
			//System.out.println(sMaxValue + " - " + sHeader);
			
			if ( sMaxValue.length() > sHeader.length() )
			{
				String sAdjustedHeader = sHeader;
				
				// value wider than header, adjust by n spaces
				for ( int j = 0 ; j < sMaxValue.length() - sHeaders[i].length() ; j++ )
				{
					// center header!
					if ( j % 2 == 0 )
					{
						sAdjustedHeader = " " + sAdjustedHeader;
					}
					else
					{
						sAdjustedHeader += " ";
					}
				}
				
				sAdjustedHeaders[i] = sAdjustedHeader;
				
			}
			else
			{
				sAdjustedHeaders[i] = sHeader;
			}
			
			i++;
		}
		
		
		// lines to delimit the headers from the values
		List<String> lsTableLines = new ArrayList<String>();
		
		for ( String sAdjustedHeader : sAdjustedHeaders )
		{
			String sTableLine = "";
			
			for ( int j = 0 ; j < sAdjustedHeader.length() ; j++ )
			{
				sTableLine += "-";
			}
			
			lsTableLines.add(sTableLine);
		}
		
		//System.out.println(new StringLine(sExpressions));
		lsStringLines.add(0, new StringLine(sAdjustedHeaders));
		lsStringLines.add(1, new StringLine(lsTableLines.toArray(new String[lsTableLines.size()])));
		
		for ( StringLine sl : lsStringLines )
		{
			sl.setHeaders(sAdjustedHeaders);
			System.out.println(sl);
		}
		
		
		// close shizzle
		em.close();
		emf.close();
	}
	
	private static String[] getConstructorExpressions(String sJpql)
	{
		// hardcoded offsets!
		int firstIndex = sJpql.indexOf("(");
		int lastIndex = sJpql.indexOf("FROM");
		
		// get constructor parentheses string and trim whitespace
		String sConstructorParen = sJpql.substring(firstIndex, lastIndex).trim();
		//System.out.println("Constructor paren string = " + sConstructorParen + "\n");
		
		// delete parentheses and trim whitespace again
		String sCleanConstructorParen = sConstructorParen.substring(1, sConstructorParen.length() - 1).trim();
		//System.out.println("Clean constructor paren string = " + sCleanConstructorParen + "\n");
		
		List<String> lsExpressions = new ArrayList<String>();
		
		StringTokenizer sto = new StringTokenizer(sCleanConstructorParen, "\n");

		while ( sto.hasMoreTokens() )
		{
			String sLine = sto.nextToken();
			
			//System.out.println("JPQL line = " + sLine);
			
			// filter carriage returns, tabs, spaces, and commas
			String sExpression = sLine.replaceAll("\r", "").replaceAll("\t", "").replaceAll(" ", "").replaceAll(",", "");
			
			//System.out.println("Expression = " + sExpression);
			
			lsExpressions.add(sExpression);
		}	
		
		return lsExpressions.toArray(new String[lsExpressions.size()]);
	}
	
	private static void createInMemoryDbViaJdbc(String sDbName) throws Exception
	{
		String sBatchSqlScript = readFile(new File("db", sDbName + "-isoansi-ddl.sql"));
		
		//System.out.println(sBatchSqlScript);
		
		List<String> lsStatements = new ArrayList<String>();
		
		StringTokenizer sto = new StringTokenizer(sBatchSqlScript, ";");
	
		while ( sto.hasMoreTokens() )
		{
			String sStatement = sto.nextToken().trim();
			//System.out.println("---------------------------------------------------------------------------------------------------");
			//System.out.println(sStatement);
			
			if ( !sStatement.isEmpty() )
			{
				lsStatements.add(sStatement);
			}
		}
 
		// loads the JDBC driver (needed for HSQLDB pre 2.0.0)
		Class.forName("org.hsqldb.jdbcDriver");	
		
		PreparedStatement ps = null;
		Connection conn = null;
		
		String sCurrStatement = null;
		
		try
		{
			conn = DriverManager.getConnection("jdbc:hsqldb:mem:" + sDbName, "sa", "");
			
			for ( String sStatement : lsStatements )
			{
				sCurrStatement = sStatement;
				ps = conn.prepareStatement(sStatement);
				ps.executeUpdate();
			}
		}
		catch ( Exception e )
		{
			e.printStackTrace();
			System.out.println(sCurrStatement);
			System.exit(1);
		}
		finally
		{
			try
			{
				conn.close();
			}
			catch ( SQLException e )
			{
				e.printStackTrace();
			}
		}
		
		//System.out.println();
		//System.out.println("Database created!");
		//System.out.println();
    }
	
	private static String readFile(File flRead)
	{
		String sContent = null;
		FileInputStream fis = null;
		
		try
		{
			fis = new FileInputStream(flRead);
			byte[] readBuffer = new byte[(int)flRead.length()];
			
			fis.read(readBuffer);
			sContent = new String(readBuffer);
		}
		catch ( Exception e )
		{
			e.printStackTrace();
			return null;
		}
		finally
		{
			if ( fis != null )
			{
				try
				{
					fis.close();
				}
				catch ( Throwable t )
				{
					System.err.println("File input stream couldn't be closed!");
				}
			}
		}
	
		return sContent;
	}

}
