
package tld.postareas;

import java.io.*;
import java.util.*;
import java.util.logging.*;
import java.sql.*;
import java.text.*;

import javax.sql.*;
import javax.persistence.*;

import tld.postareas.model.*;

public class Main
{
	private static EntityManager em;
	
	private static final String sDbName = "postareas";
	
	public static void main(String... sArgs) throws Exception
	{
		/*JDOEnhancer enhancer = JDOHelper.getEnhancer();
		enhancer.setVerbose(true);
		enhancer.addPersistenceUnit(sDbName);
		enhancer.enhance();*/
		
		createDatabase();
		
		fillDatabase(
			"01-insert-zips.sql",
			"02-insert-cities.sql",
			"03-insert-postareas.sql",
			"04-insert-postaddresses.sql"
			);

		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("postareas");
		em = emf.createEntityManager();
		
		System.out.println();
		System.out.println("Entity manager created!");
		System.out.println();
		
		Zip zi = em.find(Zip.class, new ZipId("DE", "64846"));
		System.out.println("Loaded zip = " + zi);
		
		City ci = em.find(City.class, new CityId("DE", "HE", "Dieburg"));
		System.out.println("Loaded city = " + ci);
		
		PostArea pa = em.find(PostArea.class, new PostAreaId("DE", "HE", "64846", "Gro�-Zimmern"));
		System.out.println("Loaded post area = " + pa);
		
		//PostAddress pad = em.find(PostAddress.class, new PostAddressId(1, 1));
		//System.out.println("Loaded post address = " + pad);
		
		// close
		em.close();
		emf.close();
	}
	
	private static void createDatabase() throws Exception
	{
		executeSqlUpdateScripts(sDbName + ".sql");
		
		System.out.println();
		System.out.println("In-memory HSQL database created!");
		System.out.println();
    }
	
	private static void fillDatabase(String... sSqlFileNames) throws Exception
	{
		executeSqlUpdateScripts(sSqlFileNames);
		
		System.out.println();
		System.out.println("In-memory HSQL database filled with data!");
		System.out.println();
	}
	
	private static void executeSqlUpdateScripts(String... sSqlFileNames) throws Exception
	{
		List<String> lsStatements = new ArrayList<String>();
		List<String> lsFileNames = new ArrayList<String>();
		
		for ( String sSqlFileName : sSqlFileNames )
		{
			// prefix any file name with the db path
			File flSqlScript = new File("db", sSqlFileName);
			
			//System.out.println("Loaded SQL script " + flSqlScript);
			
			String sBatchSqlScript = readFile(flSqlScript);
				
			//System.out.println(sBatchSqlScript);
			
			StringTokenizer sto = new StringTokenizer(sBatchSqlScript, ";");
			
			while ( sto.hasMoreTokens() )
			{
				String sStatement = sto.nextToken().trim();
				//System.out.println("---------------------------------------------------------------------------------------------------");
				//System.out.println(sStatement);
				
				if ( !sStatement.isEmpty() )
				{
					// every statement is unique, if not, then there would be duplicates... SHOULDN'T HAPPEN!
					lsStatements.add(sStatement);
					lsFileNames.add(sSqlFileName);
				}
			}
		} 
		
		// loads the JDBC driver (needed for HSQLDB pre 2.0.0)
		Class.forName("org.hsqldb.jdbcDriver");	
		
		PreparedStatement ps = null;
		Connection conn = null;
		
		String sCurrStatement = null;
		String sCurrStatementFirstLine = null;
		int i = 0;
		
		try
		{
			conn = DriverManager.getConnection("jdbc:hsqldb:mem:" + sDbName, "sa", "");
			
			for ( String sStatement : lsStatements )
			{
				// for error message only
				sCurrStatement = sStatement;
				sCurrStatementFirstLine = sCurrStatement.substring(0, sCurrStatement.indexOf("\n"));
				
				ps = conn.prepareStatement(sStatement);
				ps.executeUpdate();
				
				System.out.println("Successfully executed " + sCurrStatementFirstLine);
				
				i++;
			}
		}
		catch ( Exception e )
		{
			e.printStackTrace();
			System.out.println("Exception due to error in file: " + lsFileNames.get(i));
			System.out.println(sCurrStatementFirstLine);
			System.exit(666);
		}
		finally
		{
			try
			{
				conn.close();
			}
			catch ( SQLException e )
			{
				e.printStackTrace();
			}
		}
		
	}
	
	private static String readFile(File flRead)
	{
		String sContent = null;
		FileInputStream fis = null;
		
		try
		{
			fis = new FileInputStream(flRead);
			byte[] readBuffer = new byte[(int)flRead.length()];
			
			fis.read(readBuffer);
			sContent = new String(readBuffer);
		}
		catch ( Exception e )
		{
			e.printStackTrace();
			return null;
		}
		finally
		{
			if ( fis != null )
			{
				try
				{
					fis.close();
				}
				catch ( Throwable t )
				{
					System.err.println("File input stream couldn't be closed!");
				}
			}
		}
	
		return sContent;
	}

}
