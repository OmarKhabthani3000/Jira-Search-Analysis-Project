package tld.postareas.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "Cities")
@IdClass(value = CityId.class)
public class City implements Serializable
{
	@Id
	@Column(name = "country_code")
	private String countryCode;

	@Id
	@Column(name = "state_code")
	private String stateCode;

	@Id
	@Column(name = "name")
	private String name;

	public City()
	{
	}

	public City(String countryCode, String stateCode, String name)
	{
		this.countryCode = countryCode;
		this.stateCode = stateCode;
		this.name = name;
	}

	public String getCountryCode()
	{
		return countryCode;
	}

	public void setCountryCode(String countryCode)
	{
		this.countryCode = countryCode;
	}

	public String getStateCode()
	{
		return stateCode;
	}

	public void setStateCode(String stateCode)
	{
		this.stateCode = stateCode;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		City rhs = (City)obj;

		return new EqualsBuilder().append(countryCode, rhs.getCountryCode()).append(stateCode, rhs.getStateCode()).append(name, rhs.getName()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(2055121233, 92821).append(countryCode).append(stateCode).append(name).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("countryCode", countryCode).append("stateCode", stateCode).append("name", name).toString();
	}

}
