package tld.postareas.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "Zips")
@IdClass(value = ZipId.class)
public class Zip implements Serializable
{
	@Id
	@Column(name = "country_code")
	private String countryCode;

	@Id
	@Column(name = "code")
	private String code;

	public Zip()
	{
	}

	public Zip(String countryCode, String code)
	{
		this.countryCode = countryCode;
		this.code = code;
	}

	public String getCountryCode()
	{
		return countryCode;
	}

	public void setCountryCode(String countryCode)
	{
		this.countryCode = countryCode;
	}

	public String getCode()
	{
		return code;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		Zip rhs = (Zip)obj;

		return new EqualsBuilder().append(countryCode, rhs.getCountryCode()).append(code, rhs.getCode()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(667811919, 92821).append(countryCode).append(code).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("countryCode", countryCode).append("code", code).toString();
	}

}
