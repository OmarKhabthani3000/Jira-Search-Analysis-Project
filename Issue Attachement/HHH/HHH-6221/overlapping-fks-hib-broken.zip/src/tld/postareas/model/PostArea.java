package tld.postareas.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "PostAreas")
@IdClass(value = PostAreaId.class)
public class PostArea implements Serializable
{
	@Id
	@Column(name = "country_code", insertable = false, updatable = false)
	private String countryCode;

	@Id
	@Column(name = "state_code", insertable = false, updatable = false)
	private String stateCode;

	@Id
	@Column(name = "zip_code", insertable = false, updatable = false)
	private String zipCode;

	@Id
	@Column(name = "city_name", insertable = false, updatable = false)
	private String cityName;

	@ManyToOne
	@JoinColumns(value = {@JoinColumn(name = "country_code", referencedColumnName = "country_code"), @JoinColumn(name = "zip_code", referencedColumnName = "code")})
	private Zip zip;

	@ManyToOne
	@JoinColumns(value = {@JoinColumn(name = "country_code", referencedColumnName = "country_code", insertable = false, updatable = false), @JoinColumn(name = "state_code", referencedColumnName = "state_code"), @JoinColumn(name = "city_name", referencedColumnName = "name")})
	private City city;

	public PostArea()
	{
	}

	public PostArea(String countryCode, String stateCode, String zipCode, String cityName)
	{
		this.countryCode = countryCode;
		this.stateCode = stateCode;
		this.zipCode = zipCode;
		this.cityName = cityName;

		if ( countryCode != null && zipCode != null )
		{
			this.zip = new Zip(countryCode, zipCode);
		}

		if ( countryCode != null && stateCode != null && cityName != null )
		{
			this.city = new City(countryCode, stateCode, cityName);
		}
	}

	public String getCountryCode()
	{
		return countryCode;
	}

	public String getStateCode()
	{
		return stateCode;
	}

	public String getZipCode()
	{
		return zipCode;
	}

	public String getCityName()
	{
		return cityName;
	}

	public Zip getZip()
	{
		return zip;
	}

	public void setZip(Zip zip)
	{
		this.zip = zip;
		this.countryCode = zip.getCountryCode();
		this.zipCode = zip.getCode();
	}

	public City getCity()
	{
		return city;
	}

	public void setCity(City city)
	{
		this.city = city;
		this.countryCode = city.getCountryCode();
		this.stateCode = city.getStateCode();
		this.cityName = city.getName();
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		PostArea rhs = (PostArea)obj;

		return new EqualsBuilder().append(countryCode, rhs.getCountryCode()).append(stateCode, rhs.getStateCode()).append(zipCode, rhs.getZipCode()).append(cityName, rhs.getCityName()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(532537445, 92821).append(countryCode).append(stateCode).append(zipCode).append(cityName).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("countryCode", countryCode).append("stateCode", stateCode).append("zipCode", zipCode).append("cityName", cityName).append("zip", zip).append("city", city).toString();
	}

}
