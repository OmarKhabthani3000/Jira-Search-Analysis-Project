package tld.postareas.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class PostAreaId implements Serializable
{
	private String countryCode;

	private String stateCode;

	private String zipCode;

	private String cityName;

	public PostAreaId()
	{
	}

	public PostAreaId(String countryCode, String stateCode, String zipCode, String cityName)
	{
		this.countryCode = countryCode;
		this.stateCode = stateCode;
		this.zipCode = zipCode;
		this.cityName = cityName;
	}

	public String getCountryCode()
	{
		return countryCode;
	}

	public void setCountryCode(String countryCode)
	{
		this.countryCode = countryCode;
	}

	public String getStateCode()
	{
		return stateCode;
	}

	public void setStateCode(String stateCode)
	{
		this.stateCode = stateCode;
	}

	public String getZipCode()
	{
		return zipCode;
	}

	public void setZipCode(String zipCode)
	{
		this.zipCode = zipCode;
	}

	public String getCityName()
	{
		return cityName;
	}

	public void setCityName(String cityName)
	{
		this.cityName = cityName;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		PostAreaId rhs = (PostAreaId)obj;

		return new EqualsBuilder().append(countryCode, rhs.getCountryCode()).append(stateCode, rhs.getStateCode()).append(zipCode, rhs.getZipCode()).append(cityName, rhs.getCityName()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(13754793, 92821).append(countryCode).append(stateCode).append(zipCode).append(cityName).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("countryCode", countryCode).append("stateCode", stateCode).append("zipCode", zipCode).append("cityName", cityName).toString();
	}

}
