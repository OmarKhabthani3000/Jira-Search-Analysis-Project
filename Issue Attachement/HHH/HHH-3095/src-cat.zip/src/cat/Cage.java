package cat;

import java.util.List;

public class Cage {
    protected Long id;
    protected List<DomesticCat> cats;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<DomesticCat> getCats() {
        return cats;
    }

    public void setCats(List<DomesticCat> cats) {
        this.cats = cats;
    }
}
