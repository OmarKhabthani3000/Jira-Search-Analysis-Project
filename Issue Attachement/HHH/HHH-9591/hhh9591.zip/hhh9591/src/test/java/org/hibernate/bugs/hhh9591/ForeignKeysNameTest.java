/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs.hhh9591;

import org.hibernate.jpa.AvailableSettings;
import org.jboss.logging.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.Persistence;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Tests some foreign key names generation in many cases especially within @AssociationOverride annotation.
 *
 * @author Alessandro.Specchia
 */
public class ForeignKeysNameTest {
    private static final Logger LOGGER = Logger.getLogger(ForeignKeysNameTest.class);

    private Path tempFile;

    @Before
    public void setup() throws IOException {
        this.tempFile = Files.createTempFile("hhh9591", ".sql");
        LOGGER.info("Created temp file " + tempFile.toString());
    }

    @After
    public void tearDown() {
        if (tempFile != null && Files.exists(tempFile)) {
            LOGGER.info("Deleting temp file " + tempFile.toString());
            tempFile.toFile().delete();
        }
    }

    // Add your tests, using standard JUnit.
    @Test
    public void hhh9591Test() throws Exception {
        /*
        The generated SQL for the foreign keys should be:
        alter table AT_ORDER_PRODUCT_EDIBLE add constraint FK_ATOPE_PRODUCT_ORDER foreign key (ORDER_ID) references ORDER
        alter table AT_ORDER_PRODUCT_EDIBLE add constraint FK_ATOPE_PRODUCT_EDIBLE foreign key (PRODUCT_ID) references PRODUCT_EDIBLE
        alter table AT_ORDER_PRODUCT_NON_EDIBLE add constraint FK_ATOPNE_ORDER foreign key (ORDER_ID) references ORDER
        alter table AT_ORDER_PRODUCT_NON_EDIBLE add constraint FK_ATOPNE_PRODUCT_NON_EDIBLE foreign key (PRODUCT_ID) references PRODUCT_NON_EDIBLE
        alter table ORDER add constraint FK_ORDER_CUSTOMER foreign key (CUSTOMER_ID) references CUSTOMER
        alter table PRODUCT_EDIBLE add constraint FK_PRODUCT_EDIBLE_SUPPLIER foreign key (SUPPLIER_ID) references SUPPLIER
        alter table PRODUCT_NON_EDIBLE add constraint FK_PRODUCT_NON_EDIBLE_SUPPLIER foreign key (SUPPLIER_ID) references SUPPLIER
        alter table SUPPLIER add constraint FK_SUPPLIER_SUPPLIER_CODE foreign key (SUPPLIER_CODE_ID) references SUPPLIER_CODE
        */
        Pattern fkRegex = Pattern.compile("alter table (\\w+) add constraint (\\w+) foreign key \\((\\w+)\\) references (\\w+)");
        final Set<FKLink> expectedFKs = new HashSet<>(10);
        expectedFKs.add(new FKLink("AT_ORDER_PRODUCT_EDIBLE", "ORDER", "FK_ATOPE_PRODUCT_ORDER"));
        expectedFKs.add(new FKLink("AT_ORDER_PRODUCT_EDIBLE", "PRODUCT_EDIBLE", "FK_ATOPE_PRODUCT_EDIBLE"));
        expectedFKs.add(new FKLink("AT_ORDER_PRODUCT_NON_EDIBLE", "ORDER", "FK_ATOPNE_ORDER"));
        expectedFKs.add(new FKLink("AT_ORDER_PRODUCT_NON_EDIBLE", "PRODUCT_NON_EDIBLE", "FK_ATOPNE_PRODUCT_NON_EDIBLE"));
        expectedFKs.add(new FKLink("ORDER", "CUSTOMER", "FK_ORDER_CUSTOMER"));
        expectedFKs.add(new FKLink("PRODUCT_EDIBLE", "SUPPLIER", "FK_PRODUCT_EDIBLE_SUPPLIER"));
        expectedFKs.add(new FKLink("PRODUCT_NON_EDIBLE", "SUPPLIER", "FK_PRODUCT_NON_EDIBLE_SUPPLIER"));
        expectedFKs.add(new FKLink("SUPPLIER", "SUPPLIER_CODE", "FK_SUPPLIER_SUPPLIER_CODE"));

        HashMap<String, String> map = new HashMap<>();
        //map.put(org.hibernate.cfg.AvailableSettings.HBM2DDL_AUTO, "");
        //map.put(AvailableSettings.SCHEMA_GEN_DATABASE_ACTION, "none");
        map.put(AvailableSettings.SCHEMA_GEN_CREATE_SCHEMAS, "true");
        map.put(AvailableSettings.SCHEMA_GEN_SCRIPTS_ACTION, "create");
        map.put(AvailableSettings.SCHEMA_GEN_CREATE_SOURCE, "metadata");
        map.put(AvailableSettings.SCHEMA_GEN_SCRIPTS_CREATE_TARGET, tempFile.toString());
        map.put(AvailableSettings.TRANSACTION_TYPE, "RESOURCE_LOCAL");
        map.put(AvailableSettings.VALIDATION_MODE, "NONE");

        LOGGER.info("Generating the SQL schema in " + tempFile.toString());
        Persistence.generateSchema("hhh9591", map);

        final List<String> sqlLines = Files.readAllLines(tempFile);
        final Set<FKLink> foundFKs = new HashSet<>();
        final Set<FKLink> mismatchedFKs = new HashSet<>();
        for (String line : sqlLines) {
            final Matcher matcher = fkRegex.matcher(line);
            if (matcher.matches()) {
                final String sourceTable = matcher.group(1);
                final String fkName = matcher.group(2);
                final String targetTable = matcher.group(4);
                final FKLink fkLink = new FKLink(sourceTable, targetTable, fkName);
                foundFKs.add(fkLink);
                if (expectedFKs.contains(fkLink)) {
                    LOGGER.info("Correct FK:    " + fkLink);
                } else {
                    LOGGER.warn("Mismatched FK: " + fkLink);
                    mismatchedFKs.add(fkLink);
                }
            }
        }

        Assert.assertTrue("Found some mismatched foreign keys: " + mismatchedFKs, mismatchedFKs.isEmpty());
        Assert.assertEquals("The number of expected and generate FKs differ", expectedFKs.size(), foundFKs.size());
        Assert.assertEquals(expectedFKs, foundFKs);
    }

    private static class FKLink {
        private String sourceTable;
        private String targetTable;
        private String foreignKey;

        FKLink(String sourceTable, String targetTable, String foreignKey) {
            this.sourceTable = sourceTable;
            this.targetTable = targetTable;
            this.foreignKey = foreignKey;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            FKLink fkLink = (FKLink) o;
            return Objects.equals(sourceTable, fkLink.sourceTable) &&
                    Objects.equals(targetTable, fkLink.targetTable) &&
                    Objects.equals(foreignKey, fkLink.foreignKey);
        }

        @Override
        public int hashCode() {
            return Objects.hash(sourceTable, targetTable, foreignKey);
        }

        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("FKLink{");
            sb.append("foreignKey='").append(foreignKey).append('\'');
            sb.append(", sourceTable='").append(sourceTable).append('\'');
            sb.append(", targetTable='").append(targetTable).append('\'');
            sb.append('}');
            return sb.toString();
        }
    }
}
