package org.hibernate.bugs.hhh9591.model;

import javax.persistence.*;

/**
 * @author Alessandro.Specchia.
 */
@Entity
@Table(name = "SUPPLIER")
public class Supplier {

    @Id
    @Column(name = "SUPPLIER_ID", nullable = false)
    private Long supplierId;

    @Column(name = "NAME", length = 75)
    private String name;

    @OneToOne(fetch = FetchType.EAGER, orphanRemoval = true)
    @JoinColumn(name = "SUPPLIER_CODE_ID", nullable = false, foreignKey = @ForeignKey(name = "FK_SUPPLIER_SUPPLIER_CODE"))
    private SupplierCode supplierCode;
}
