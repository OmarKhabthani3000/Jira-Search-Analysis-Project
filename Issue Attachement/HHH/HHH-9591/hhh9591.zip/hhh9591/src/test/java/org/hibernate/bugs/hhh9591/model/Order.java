package org.hibernate.bugs.hhh9591.model;

import javax.persistence.*;
import java.util.Date;

/**
 * @author Alessandro.Specchia.
 */
@Entity
@Table(name = "ORDER")
public class Order {

    @Id
    @Column(name = "ORDER_ID")
    private Long orderId;

    @Column(name = "ORDER_DATE")
    @Temporal(TemporalType.DATE)
    private Date orderDate;
}
