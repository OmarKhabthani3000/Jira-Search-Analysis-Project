package org.hibernate.bugs.hhh9591.model;

import javax.persistence.*;

/**
 * @author Alessandro.Specchia.
 */
@Entity
@Table(name = "PRODUCT_NON_EDIBLE")
@AssociationOverrides({
        @AssociationOverride(name = "orderList", joinTable = @JoinTable(name = "AT_ORDER_PRODUCT_NON_EDIBLE",
                joinColumns = @JoinColumn(name = "PRODUCT_ID", foreignKey = @ForeignKey(name = "FK_ATOPNE_PRODUCT_NON_EDIBLE")),
                inverseJoinColumns = @JoinColumn(name = "ORDER_ID", foreignKey = @ForeignKey(name = "FK_ATOPNE_ORDER")))),
        @AssociationOverride(name = "supplier", joinColumns = @JoinColumn(name = "SUPPLIER_ID", nullable = false), foreignKey = @ForeignKey(name = "FK_PRODUCT_NON_EDIBLE_SUPPLIER"))
})
public class ProductNonEdible extends Product {
}
