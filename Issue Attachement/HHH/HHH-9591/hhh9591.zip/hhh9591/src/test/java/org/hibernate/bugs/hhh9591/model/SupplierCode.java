package org.hibernate.bugs.hhh9591.model;

import javax.persistence.*;

/**
 * @author Alessandro.Specchia.
 */
@Entity
@Table(name = "SUPPLIER_CODE")
public class SupplierCode {

    @Id
    @Column(name = "SUPPLIER_CODE_ID")
    private Long supplierCodeId;

    @Column(name = "CODE", nullable = false)
    private String code;

    @Column(name = "YAC", nullable = true)
    private String yetAnotherCode;

    @OneToOne(mappedBy = "supplierCode", fetch = FetchType.LAZY)
    private Supplier supplier;
}
