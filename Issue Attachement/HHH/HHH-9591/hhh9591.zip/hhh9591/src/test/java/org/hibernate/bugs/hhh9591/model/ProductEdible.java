package org.hibernate.bugs.hhh9591.model;

import javax.persistence.*;
import java.util.Date;

/**
 * @author Alessandro.Specchia.
 */
@Entity
@Table(name = "PRODUCT_EDIBLE")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@AssociationOverrides({
        @AssociationOverride(name = "orderList", joinTable = @JoinTable(name = "AT_ORDER_PRODUCT_EDIBLE",
                joinColumns = @JoinColumn(name = "PRODUCT_ID", foreignKey = @ForeignKey(name = "FK_ATOPE_PRODUCT_EDIBLE")),
                inverseJoinColumns = @JoinColumn(name = "ORDER_ID", foreignKey = @ForeignKey(name = "FK_ATOPE_PRODUCT_ORDER")))),
        @AssociationOverride(name = "supplier", joinColumns = @JoinColumn(name = "SUPPLIER_ID", nullable = false), foreignKey = @ForeignKey(name = "FK_PRODUCT_EDIBLE_SUPPLIER"))
})
public class ProductEdible extends Product {

    private Date getExpirationDate;
}
