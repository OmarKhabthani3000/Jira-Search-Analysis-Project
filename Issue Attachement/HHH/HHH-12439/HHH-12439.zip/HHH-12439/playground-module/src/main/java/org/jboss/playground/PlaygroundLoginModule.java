/*
 * Copyright 2018 Red Hat, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jboss.playground;

import java.security.Principal;
import java.security.acl.Group;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.login.LoginException;

import org.jboss.security.SimpleGroup;
import org.jboss.security.auth.spi.AbstractServerLoginModule;

public class PlaygroundLoginModule extends AbstractServerLoginModule {

	private static final String USERNAME = "username";
	private static final String PASSWORD = "password";
	private static final String ROLES = "roles";
	
	private static final String[] VALID_OPTIONS = { USERNAME, PASSWORD, ROLES };

	private String username;
	private char[] password;

	private final Set<String> rolesStrings = new HashSet<>();

	@Override
	public void initialize(Subject subject, CallbackHandler callbackHandler, Map<String, ?> sharedState,
			Map<String, ?> options) {

		// add our valid options before calling the super class initialize...
		addValidOptions(VALID_OPTIONS);
		super.initialize(subject, callbackHandler, sharedState, options);

		String userName = (String) options.get(USERNAME);
		if (userName != null) {
			this.username = userName;
		}

		String password = (String) options.get(PASSWORD);
		if (password != null) {
			this.password = password.toCharArray();
		}
		
		String roles = (String) options.get(ROLES);
		if (roles != null) {
			this.rolesStrings.addAll(Arrays.asList(roles.split("\\s*,\\s*")));
		}

		try {
			NameCallback nameCallback = new NameCallback("User name: ", "guest");
			PasswordCallback passwordCallback = new PasswordCallback("Password: ", false);
			Callback[] callbacks = { nameCallback, passwordCallback };
			callbackHandler.handle(callbacks);
			this.username = nameCallback.getName();
			this.password = passwordCallback.getPassword();
		} catch (Exception e) {
			throw new IllegalStateException("Unable to get username and password", e);
		}
	}

	@Override
	public boolean login() throws LoginException {

		super.login();
		loginOk = false;
		return true;
	}

	@Override
	protected Principal getIdentity() {
		try {
			return super.createIdentity(username);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	@Override
	protected Group[] getRoleSets() throws LoginException {

		try {
			SimpleGroup userRoles = new SimpleGroup("Roles");

			for (String roleString : rolesStrings) {
				Principal role = super.createIdentity(roleString);
				userRoles.addMember(role);
			}

			Group[] roles = { userRoles };
			return roles;
			
		} catch (Exception e) {
			throw new LoginException("Unable to obtain roles, " + e.getMessage());
		}
	}

}
