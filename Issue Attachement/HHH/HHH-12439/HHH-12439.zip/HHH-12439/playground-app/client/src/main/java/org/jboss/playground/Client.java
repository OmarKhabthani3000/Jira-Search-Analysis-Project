/*
 * Copyright 2018 Red Hat, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jboss.playground;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.jboss.logmanager.Logger;
import org.jboss.playground.BeanRemote;

public class Client {

	private static Logger logger = Logger.getLogger(Client.class.getSimpleName()); 
	
    public static void main(String[] args) throws Exception {
        String name = "ejb:playground-app/playground-app-ejb/Bean!org.jboss.playground.BeanRemote";
        
        Properties props = new Properties();
        props.put(Context.PROVIDER_URL, "remote+http://localhost:8080");
        props.put(Context.INITIAL_CONTEXT_FACTORY, "org.wildfly.naming.client.WildFlyInitialContextFactory");
        InitialContext context = new InitialContext(props);
        BeanRemote b = (BeanRemote) context.lookup(name);

        Long id;
        
        id = b.worksInit();
        logger.info("worksInit returned id:"+id);
        b.worksTest(id, "worksTest");
        logger.info("post worksTest");

        id = b.errorInit();
        logger.info("errorInit returned id:"+id);
        b.errorTest(id, "errorTest");
        logger.info("post errorTest");
    }
}
