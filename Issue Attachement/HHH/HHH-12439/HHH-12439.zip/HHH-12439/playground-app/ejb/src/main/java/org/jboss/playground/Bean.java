/*
 * Copyright 2018 Red Hat, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jboss.playground;

import java.util.HashSet;
import java.util.Set;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless(name="Bean")
public class Bean implements BeanRemote {

	/*
     | Demonstrates: 
     | java.lang.IllegalStateException: MergeContext#attempt to create managed -> managed mapping with different entities: [org.jboss.playground.Frd#98304]; [org.jboss.playground.Frd#98304]
     |
     | If initializing of amd.vrg.ents and amd.vrg.atrg are swapped everything works just fine
     */
    
	@PersistenceContext
	EntityManager em;

	@Override
	public Long errorInit() {
		Amd amd = new Amd();
		amd.vrg = new Vrg();
		amd.vrg.ents = new Ents();
		amd.vrg.ents.frd.add(new Frd("errorInit"));

		em.persist(amd);

		return amd.getId();
	}

	@Override
	public void errorTest(Long id, String frdString) {
		Amd amd = em.find(Amd.class, id);

		amd.vrg.atrg = new Atrg();
		Set<Frd> frdsForAtrg = new HashSet<>();

		for (Frd frdFromEnts : amd.vrg.ents.frd) {
			Frd f = new Frd("errorTest-copyFromEnts");
			f.id = frdFromEnts.id;
			frdsForAtrg.add(f);
		}
		amd.vrg.atrg.frd.addAll(frdsForAtrg);

		em.merge(amd);
	}

	@Override
	public Long worksInit() {
		Amd amd = new Amd();
		amd.vrg = new Vrg();
		amd.vrg.atrg = new Atrg();
		amd.vrg.atrg.frd.add(new Frd("worksInit"));

		em.persist(amd);

		return amd.getId();
	}

	@Override
	public void worksTest(Long id, String frdString) {
		Amd amd = em.find(Amd.class, id);

		amd.vrg.ents = new Ents();
		Set<Frd> frdsForEnts = new HashSet<>();

		for (Frd frdFromAtrg : amd.vrg.atrg.frd) {
			Frd f = new Frd("worksTest-copyFromAtrg");
			f.id = frdFromAtrg.id;
			frdsForEnts.add(f);
		}
		amd.vrg.ents.frd.addAll(frdsForEnts);

		em.merge(amd);
	}
}
