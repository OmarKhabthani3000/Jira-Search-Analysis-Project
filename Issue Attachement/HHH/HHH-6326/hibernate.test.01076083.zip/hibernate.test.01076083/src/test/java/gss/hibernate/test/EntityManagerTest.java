package gss.hibernate.test;

import junit.framework.TestCase;

import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;


public class EntityManagerTest extends TestCase {
	
	private EntityManager em;
	
	@SuppressWarnings("deprecation")
	@Override
	protected void setUp() throws Exception {
		em = Persistence.createEntityManagerFactory("puHHH6326").createEntityManager();
	}
	
	@Override
	protected void tearDown() throws Exception {
		if (em != null) {
			em.close();
		}
	}
	
	public void testHHH6326() {
		EntityTransaction ets = em.getTransaction();
		
		ets.begin();
        String hql = "select e.lastName, e.department.deptName, e.title from Employee e  ";
        
        Query qry = em.createQuery(hql);
        qry.setMaxResults(10);
        qry.getResultList();
        System.out.println("===========>  HQL Works");
		ets.commit();
	}

}
