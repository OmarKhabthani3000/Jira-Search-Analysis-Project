package hibernate;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class Test {
    
    private Integer id;
    private String name;
    private Boolean data;
    
    public static void main(String[] args) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Test theTest = new Test();
        theTest.setId(1);
        theTest.setName("Hello");
        session.save(theTest);
        session.getTransaction().commit();
        session.flush();
        session.close();
        sessionFactory.close();
    }

    Integer getId() {
        return id;
    }

    void setId(Integer id) {
        this.id = id;
    }

    String getName() {
        return name;
    }

    void setName(String name) {
        this.name = name;
    }

    Boolean getData() {
        return data;
    }

    void setData(Boolean data) {
        this.data = data;
    }
}
