/*
 * A.java
 *
 * Created on 21. Dezember 2005, 11:10
 */

import java.net.*;
import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.*;
/**
 *
 * @author  Peter Fassev
 */
public class A {
	
	private int id;
	
	private String[] b;
	
	/** Creates a new instance of A */
	public A() {
	}
	
	/**
	 * Getter for property id.
	 * @return Value of property id.
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * Setter for property id.
	 * @param id New value of property id.
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * Getter for property b.
	 * @return Value of property b.
	 */
	public java.lang.String[] getB() {
		return this.b;
	}
	
	/**
	 * Setter for property b.
	 * @param b New value of property b.
	 */
	public void setB(java.lang.String[] b) {
		this.b = b;
	}
	
	public static void main(String args[]) {
		URL configFile = A.class.getResource("/a.hbm.xml");
		Configuration configuration = new Configuration();
		configuration.addURL(configFile);
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
        Transaction t = session.beginTransaction();
		
		A a = new A();
		String[] b = new String[] {"a", "b", "c"};
		a.setB(b);

        session.save(a);

        t.commit();
        
		t = session.beginTransaction();

		Query query = session.createQuery("select o from A as o inner join fetch o.b as e");
		List l = query.list();

        t.commit();
		
		session.close();
	}
	
}
