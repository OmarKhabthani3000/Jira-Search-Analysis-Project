package net.lucamasini.jboss.testcase;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import java.net.URI;
import java.util.Date;
import java.util.Map;

@Entity
public class OutputRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "OUTPUTREQUEST_PREVWQUERYPRM")
    @MapKeyJoinColumn(name = "param_id", referencedColumnName = "id")
    Map<ParameterRegistry, String> previewQueryParams;
}