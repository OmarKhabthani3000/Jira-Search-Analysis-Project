package net.lucamasini.jboss.testcase;

import javax.persistence.*;

/**
 * Anagrafica dei parametri
 */
@Entity
public class ParameterRegistry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column(nullable = false)
    String name;

}
