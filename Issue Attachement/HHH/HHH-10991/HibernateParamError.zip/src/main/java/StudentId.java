package main.java;

import java.io.Serializable;

public class StudentId implements Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = -6599138108996303771L;
    protected Integer matnr;
    protected String name;
    protected String adresse;
    
    public StudentId(){}
    
    public StudentId(Integer matnr, String name, String adresse){
        this.matnr = matnr;
        this.name = name;
        this.adresse = adresse;
    }
    
    @Override
    public boolean equals(final Object other){
        if(other instanceof StudentId){
            if(!this.matnr.equals(((StudentId)other).getMatnr())){
                return false;
            }
            if(!this.name.equals(((StudentId)other).getName())){
                return false;
            }
            if(!this.adresse.equals(((StudentId)other).getAdresse())){
                return false;
            }
            return true;
        }
        return false;
    }
    
    @Override
    public int hashCode(){
        return matnr;
    }

    public Integer getMatnr() {
        return matnr;
    }

    public void setMatnr(Integer matnr) {
        this.matnr = matnr;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }
}
