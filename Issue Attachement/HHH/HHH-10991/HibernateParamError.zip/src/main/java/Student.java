package main.java;

public class Student implements java.io.Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -7091099770730445378L;

    private StudentId studentId;
    private String studentName;
    private Integer semester;
    private Long objektGruppen;

    public void setStudentId(StudentId studentId) {
        this.studentId = studentId;
    }

    public StudentId getStudentId() {
        return studentId;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentName() {
        return studentName;
    }

    public Long getObjektGruppen() {
        return objektGruppen;
    }

    public void setObjektGruppen(Long objektGruppen) {
        this.objektGruppen = objektGruppen;
    }

    public Integer getSemester() {
        return semester;
    }

    public void setSemester(Integer semester) {
        this.semester = semester;
    }

}
