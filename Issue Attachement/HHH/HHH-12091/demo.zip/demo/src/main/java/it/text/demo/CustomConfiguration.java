package it.text.demo;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.envers.repository.support.EnversRevisionRepositoryFactoryBean;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
@EnableWebMvc
@EnableJpaAuditing
//To activate the Spring Data Envers repository factory
@EnableJpaRepositories(basePackages = "it.text.demo.repositories", repositoryFactoryBeanClass = EnversRevisionRepositoryFactoryBean.class)
public class CustomConfiguration {

}
