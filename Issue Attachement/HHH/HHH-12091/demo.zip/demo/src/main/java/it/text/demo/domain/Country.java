package it.text.demo.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.validation.constraints.Size;

import org.hibernate.envers.Audited;
import org.hibernate.validator.constraints.NotBlank;

@Entity
public class Country extends AbstractEntity {
	private static final long serialVersionUID = 4487829062553023011L;

	@Audited
	@NotBlank
	@Column(nullable = false)
	private String name;

	@Audited
	@NotBlank
	@Size(min = 2, max = 2)
	@Column(nullable = false, unique = true)
	private String alpha2Code;

	@Audited
	@NotBlank
	@Size(min = 3, max = 3)
	@Column(nullable = false, unique = true)
	private String alpha3Code;

	@Audited
	// e.g. Europe
	private String region;

	@Audited
	// e.g. Northern Europe
	private String subregion;

	public Country() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getSubregion() {
		return subregion;
	}

	public void setSubregion(String subregion) {
		this.subregion = subregion;
	}

	public String getAlpha2Code() {
		return alpha2Code;
	}

	public void setAlpha2Code(String alpha2Code) {
		this.alpha2Code = alpha2Code;
	}

	public String getAlpha3Code() {
		return alpha3Code;
	}

	public void setAlpha3Code(String alpha3Code) {
		this.alpha3Code = alpha3Code;
	}

	@Override
	public String toString() {
		return "Country [name=" + name + ", alpha2Code=" + alpha2Code + ", alpha3Code=" + alpha3Code + ", region=" + region + ", subregion="
				+ subregion + "]";
	}

}
