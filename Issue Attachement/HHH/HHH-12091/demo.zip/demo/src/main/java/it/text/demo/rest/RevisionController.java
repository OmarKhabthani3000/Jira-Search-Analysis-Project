package it.text.demo.rest;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.history.Revision;

import it.text.demo.domain.RestRevision;

public class RevisionController<T> {

	public List<RestRevision> getRestRevisions(List<Revision<Integer, T>> revisions) {
		List<RestRevision> list = new ArrayList<>();
		for (Revision<Integer, T> revision : revisions) {
			RestRevision rev = new RestRevision();
			rev.setRevisionNumber(revision.getRevisionNumber());
			rev.setRevisionDate(Instant.ofEpochMilli(revision.getRevisionDate().getMillis()));
			list.add(rev);
		}
		return list;
	}

}
