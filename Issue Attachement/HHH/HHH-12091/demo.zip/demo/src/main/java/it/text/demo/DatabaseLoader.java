package it.text.demo;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import it.text.demo.domain.Country;
import it.text.demo.domain.LicensePlate;
import it.text.demo.repositories.CountryRepository;
import it.text.demo.repositories.LicensePlateRepository;

@Component
public class DatabaseLoader {

	@Autowired
	private LicensePlateRepository licensePlateRepository;

	@Autowired
	private CountryRepository countryRepository;

	@PersistenceContext
	private EntityManager entityManager;

	@PostConstruct
	private void postConstruct() {
		Country country = new Country();
		country.setAlpha2Code("IT");
		country.setAlpha3Code("ITA");
		country.setName("Italy");
		countryRepository.save(country);

		LicensePlate lp = new LicensePlate();
		lp.setCountry(country);
		lp.setLicensePlate("AA123CC");
		licensePlateRepository.saveAndFlush(lp);

		lp.setLicensePlate("ZZ123XX");
		licensePlateRepository.saveAndFlush(lp);
	}
}
