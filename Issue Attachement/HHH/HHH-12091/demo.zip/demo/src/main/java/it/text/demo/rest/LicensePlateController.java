package it.text.demo.rest;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.Hibernate;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.query.AuditQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.history.Revision;
import org.springframework.data.rest.webmvc.RepositoryRestController;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.hateoas.PagedResources;
import org.springframework.hateoas.PagedResources.PageMetadata;
import org.springframework.hateoas.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.text.demo.domain.LicensePlate;
import it.text.demo.domain.RestRevision;
import it.text.demo.repositories.LicensePlateRepository;

@RepositoryRestController
@RequestMapping(path = "/")
@Transactional
public class LicensePlateController extends RevisionController<LicensePlate> {

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private LicensePlateRepository licensePlateRepository;

	@RequestMapping(value = "/licensePlates/{id}/revisions", method = RequestMethod.GET)
	public ResponseEntity<?> findRevisions(@PathVariable(value = "id") Long id, Pageable pageable) {
		if (id != null) {
			// Find all revisions of the current object
			Page<Revision<Integer, LicensePlate>> revisions = licensePlateRepository.findRevisions(id, pageable);
			List<RestRevision> revisionsList = getRestRevisions(revisions.getContent());

			// Repackage the paged response HATEOAS compliant
			PageMetadata pageMetadata = new PageMetadata(pageable.getPageSize(), pageable.getPageNumber(), revisionsList.size(),
					revisions.getTotalPages());
			PagedResources<RestRevision> pagedResources = new PagedResources<RestRevision>(revisionsList, pageMetadata);
			return new ResponseEntity<>(pagedResources, HttpStatus.OK);
		} else {
			throw new ResourceNotFoundException();
		}
	}

	@RequestMapping(value = "/licensePlates/{id}/revisions/{revid}", method = RequestMethod.GET)
	public ResponseEntity<?> findRevision(@PathVariable(value = "id") Long id, @PathVariable(value = "revid") Integer revId,
			Pageable pageable) {
		if (id != null) {
			AuditReader reader = AuditReaderFactory.get(entityManager);
			AuditQuery q = reader.createQuery().forEntitiesAtRevision(LicensePlate.class, revId);
			LicensePlate current = (LicensePlate) q.getSingleResult();
			Hibernate.initialize(current.getCountry());
			return new ResponseEntity<>(new Resource<>(current.getCountry()), HttpStatus.OK);
		} else {
			throw new ResourceNotFoundException();
		}
	}

}
