package it.text.demo.domain;

import java.time.Instant;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.Transient;
import javax.persistence.Version;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.domain.Persistable;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.data.rest.core.annotation.RestResource;

import com.fasterxml.jackson.annotation.JsonIgnore;

@EntityListeners({ AuditingEntityListener.class })
@MappedSuperclass
public abstract class AbstractEntity implements Persistable<Long> {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	private Long id;

	/* "UUID" and "UID" are Oracle reserved keywords -> "sid" */
	@Column(name = "sid", unique = true, nullable = false, updatable = false, length = 36)
	private String sid;
	
	@CreatedBy
	private String createdBy;

	//@Audited
	@CreatedDate
	@Column(updatable = false)
	private Instant createdDate;

	@LastModifiedDate
	private Instant lastModifiedDate;

	@LastModifiedBy
	private String lastModifiedBy;

	// Trick to start version counting from 1 instead of 0
	@Version
	private long version = 1;

	public AbstractEntity() {
	}

	@PrePersist
	public void initializeUUID() {
		if (sid == null) {
			sid = UUID.randomUUID().toString();
		}
	}

	@Override
	@JsonIgnore
	public Long getId() {
		return id;
	}

	public String getSid() {
		return sid;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public Instant getLastModifiedDate() {
		return lastModifiedDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public long getVersion() {
		return version;
	}

	@RestResource(exported = false)
	@JsonIgnore
	@Transient
	public boolean isNew() {
		return null == getId();
	}

	@Override
	public boolean equals(Object obj) {
		// if (null == obj) {
		// return false;
		// }
		//
		// if (this == obj) {
		// return true;
		// }
		//
		// if (!getClass().equals(ClassUtils.getUserClass(obj))) {
		// return false;
		// }
		//
		// AbstractEntity that = (AbstractEntity) obj;
		//
		// return null == this.getSid() ? false :
		// this.getSid().equals(that.getSid());

		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		AbstractEntity other = (AbstractEntity) obj;
		if (sid == null) {
			if (other.sid != null)
				return false;
		} else if (!sid.equals(other.sid)) {
			if (getId() == null) {
				if (other.getId() != null)
					return false;
			} else {
				if (!getId().equals(other.getId()))
					return false;
			}
		}

		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((sid == null) ? 0 : sid.hashCode());
		return result;
		// int hashCode = 17;
		// hashCode += null == getId() ? 0 : getId().hashCode() * 31;
		// return hashCode;
	}
}
