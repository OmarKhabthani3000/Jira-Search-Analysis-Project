package it.text.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.history.RevisionRepository;
import org.springframework.transaction.annotation.Transactional;

import it.text.demo.domain.LicensePlate;

@Transactional
public interface LicensePlateRepository extends JpaRepository<LicensePlate, Long>, RevisionRepository<LicensePlate, Long, Integer> {

	public LicensePlate findByLicensePlate(String licencePlate);


}
