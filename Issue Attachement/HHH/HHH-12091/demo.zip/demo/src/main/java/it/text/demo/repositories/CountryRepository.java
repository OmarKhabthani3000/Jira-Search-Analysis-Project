package it.text.demo.repositories;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.history.RevisionRepository;
import org.springframework.transaction.annotation.Transactional;

import it.text.demo.domain.Country;

@Transactional
public interface CountryRepository extends PagingAndSortingRepository<Country, Long>, RevisionRepository<Country, Long, Integer> {

}
