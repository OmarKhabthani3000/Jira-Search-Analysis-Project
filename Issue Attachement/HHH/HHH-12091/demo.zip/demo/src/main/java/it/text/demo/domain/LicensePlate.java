package it.text.demo.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;

@Entity
@Audited
public class LicensePlate extends AbstractEntity {
	private static final long serialVersionUID = -6871697166535810224L;
	
	@Column(nullable = false, unique = true)
	private String licensePlate;

	@NotNull
	// The country of the vehicle
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	private Country country;

	public LicensePlate() {
	}

	public String getLicensePlate() {
		return licensePlate;
	}

	public void setLicensePlate(String licensePlate) {
		this.licensePlate = licensePlate;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

}
