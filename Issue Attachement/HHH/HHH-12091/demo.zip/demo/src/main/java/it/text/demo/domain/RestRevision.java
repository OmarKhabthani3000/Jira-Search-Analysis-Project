package it.text.demo.domain;

import java.time.Instant;


public class RestRevision {
	
	private int revisionNumber;
	
	private Instant revisionDate;
	
	private String createdBy;
	
	private String remoteAddress;
	

	public int getRevisionNumber() {
		return revisionNumber;
	}

	public void setRevisionNumber(int revisionNumber) {
		this.revisionNumber = revisionNumber;
	}

	public Instant getRevisionDate() {
		return revisionDate;
	}

	public void setRevisionDate(Instant revisionDate) {
		this.revisionDate = revisionDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getRemoteAddress() {
		return remoteAddress;
	}

	public void setRemoteAddress(String remoteAddress) {
		this.remoteAddress = remoteAddress;
	}
}
