package it.text.demo;

import static org.junit.Assert.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.query.AuditQuery;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.history.Revisions;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import it.text.demo.domain.Country;
import it.text.demo.domain.LicensePlate;
import it.text.demo.repositories.CountryRepository;
import it.text.demo.repositories.LicensePlateRepository;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
// @Transactional
public class DemoApplicationTests {

	@Autowired
	private LicensePlateRepository licensePlateRepository;

	@Autowired
	private CountryRepository countryRepository;

	@PersistenceContext
	private EntityManager entityManager;

	LicensePlate lp;

	@Before
	public void setup() {
		Country country = new Country();
		country.setAlpha2Code("IT");
		country.setAlpha3Code("ITA");
		country.setName("Italy");
		countryRepository.save(country);

		lp = new LicensePlate();
		lp.setCountry(country);
		lp.setLicensePlate("AA123CC");
		licensePlateRepository.saveAndFlush(lp);

		lp.setLicensePlate("ZZ123XX");
		licensePlateRepository.saveAndFlush(lp);
	}

	@Test
	@Transactional
	public void contextLoads() {
		assertEquals("ZZ123XX", licensePlateRepository.findOne(lp.getId()).getLicensePlate());
		Revisions<Integer, LicensePlate> revisions = licensePlateRepository.findRevisions(lp.getId());
		assertEquals(2, revisions.getContent().size());

		AuditReader reader = AuditReaderFactory.get(entityManager);
		AuditQuery q = reader.createQuery().forEntitiesAtRevision(LicensePlate.class, 2);
		LicensePlate current = (LicensePlate) q.getSingleResult();

		// PREVIOUS

		q = reader.createQuery().forEntitiesAtRevision(LicensePlate.class, 1);
		LicensePlate previous = (LicensePlate) q.getSingleResult();

	}

}
