package com.nm.test;

import javax.persistence.Entity;

@Entity
public class B extends A
{
	private String b;
}
