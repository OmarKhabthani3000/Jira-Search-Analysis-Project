package com.nm.test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class HibernateTest
{
	public static void main(String[] args) throws Exception
	{
		EntityManagerFactory entityManagerFactory = Persistence
				.createEntityManagerFactory("neomind");

		EntityManager entityManager = entityManagerFactory.createEntityManager();

		// This works
		List result = entityManager.createQuery("SELECT a, a.b FROM A a").getResultList();
		System.out.println("result: " + result);

		// This generates an invalid SQL (select a0_1_.b as col_0_0_ from A a0_)
		result = entityManager.createQuery("SELECT a.b FROM A a").getResultList();
		System.out.println("result: " + result);
	}
}