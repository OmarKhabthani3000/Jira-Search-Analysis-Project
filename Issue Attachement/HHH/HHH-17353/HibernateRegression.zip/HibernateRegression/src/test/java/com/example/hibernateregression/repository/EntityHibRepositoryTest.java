package com.example.hibernateregression.repository;

import com.example.hibernateregression.HibernateRegressionApplication;
import com.example.hibernateregression.entities.EntityHib;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = HibernateRegressionApplication.class)
@Transactional
class EntityHibRepositoryTest {

    @Autowired
    EntityHibRepository repository;

    @Test
    void getByName() {
        String uuid = UUID.randomUUID().toString();
        String name = "name";

        repository.save(new EntityHib(uuid, name));

        Optional<EntityHib> optionalEntityHib = repository.getByName(name);

        assertTrue(optionalEntityHib.isPresent());

    }
}
