package com.example.hibernateregression;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateRegressionApplicationTests {

	@Test
	void contextLoads() {
	}

}
