package com.example.hibernateregression.repository;

import com.example.hibernateregression.entities.EntityHib;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EntityHibRepository extends JpaRepository<EntityHib, String> {
    Optional<EntityHib> getByName(String name);

}
