package com.example.hibernateregression.entities;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.ResultCheckStyle;
import org.hibernate.annotations.SQLInsert;

//Spring 2
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

//Spring 3
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.Id;

@Entity
@DynamicInsert
@SQLInsert(sql = "", check = ResultCheckStyle.NONE)
public class EntityHib {

    @Id
    @Column(nullable = false, unique = true)
    private String uuid;

    @Column(name = "name", nullable = false)
    private String name;

    public EntityHib() {
    }

    public EntityHib(String uuid, String name) {
        this.uuid = uuid;
        this.name = name;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "EntityHib{" +
                "uuid='" + uuid + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
