package dummy;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

/** @author Hibernate CodeGenerator */
public class GrandChild implements Serializable {
    /** nullable persistent field */
    private Parent grandParent;

    private Long id;

    /** nullable persistent field */
    private String name;

    /** nullable persistent field */
    private Integer orderNo;

    private Child parent;

    /** default constructor */
    public GrandChild() {
    }

    /** full constructor */
    public GrandChild(String name, Integer orderNo, Parent parent) {
        this.name = name;
        this.orderNo = orderNo;
        this.grandParent = parent;
    }

    public Parent getGrandParent() {
        return this.grandParent;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return this.name;
    }

    public Integer getOrderNo() {
        return this.orderNo;
    }

    public Child getParent() {
        return parent;
    }

    public void setGrandParent(Parent parent) {
        this.grandParent = parent;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }

    public void setParent(Child parent) {
        this.parent = parent;
    }

    public String toString() {
        return new ToStringBuilder(this).toString();
    }

}
