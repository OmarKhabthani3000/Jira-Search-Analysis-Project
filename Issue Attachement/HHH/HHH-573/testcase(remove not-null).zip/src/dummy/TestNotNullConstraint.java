package dummy;

public class TestNotNullConstraint extends TestBase {
    private static final int COUNT = 3;

    private void genChild(Parent parent) {
        {
            Child child = new Child();
            child.setName("child name");
            parent.addChild(child);

            // add 3 grand child
            for (int j = 0; j < COUNT; j++) {
                GrandChild grandChild = new GrandChild();
                grandChild.setName("grand child name");
                child.addGrandChild(grandChild);
            }
        }
    }

    private Parent genParent() {
        Parent parent = new Parent();
        parent.setName("parent name");

        // add 3 child
        for (int i = 0; i < COUNT; i++) {
            genChild(parent);
        }
        return parent;
    }

    public void testConstraint() throws Exception {
        execHql("delete from Child");
        execHql("delete from Parent");

        Long id;
        {
            Parent parent = genParent();
            id = (Long) save(parent);
        }
        session.clear();
        {
            Parent parent = new Parent();
            parent.setId(id);
            // add more 3 child
            for (int i = 0; i < 3; i++) {
                genChild(parent);
            }
            Parent parentEntity = (Parent) load(Parent.class, id);
            // cannot use update()
            merge(parent);
        }
    }
}
