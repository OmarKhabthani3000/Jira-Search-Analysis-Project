package dummy;

import java.io.Serializable;

import junit.framework.TestCase;

import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

/**
 * @author giangnh
 */
public class TestBase extends TestCase {

    private Transaction transaction;

    protected org.hibernate.Session session;

    private void openSession(boolean createSchema) {
        Configuration configuration = new Configuration();
        if (createSchema) {
            configuration.setProperty(Environment.HBM2DDL_AUTO, "create-drop");
        }
        session = configuration.configure().buildSessionFactory().openSession();
    }

    protected void beginTrans() {
        transaction = session.beginTransaction();
    }

    protected void commit() {
        transaction.commit();
    }

    protected int count(Class class1) {
        return session.createCriteria(class1).list().size();
    }

    protected void execHql(String hql) {
        beginTrans();
        session.createQuery(hql).executeUpdate();
        commit();
    }

    protected Object load(Class aClass, Long aId) {
        return session.get(aClass, aId);
    }

    protected void merge(Object object) {
        beginTrans();
        session.merge(object);
        commit();
    }

    protected void restartSession() {
        session.close();
        openSession(false);
    }

    protected Serializable save(Parent aParent) {
        beginTrans();
        Serializable save = session.save(aParent);
        commit();
        return save;
    }

    protected void setUp() throws Exception {
        super.setUp();
        openSession(true);
    }

    protected void update(Object object) {
        beginTrans();
        session.update(object);
        commit();
    }
}