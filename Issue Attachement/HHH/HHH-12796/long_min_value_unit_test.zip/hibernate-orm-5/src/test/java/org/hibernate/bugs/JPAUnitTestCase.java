package org.hibernate.bugs;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

  private EntityManagerFactory entityManagerFactory;

  @Before
  public void init() {
    entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
  }

  @After
  public void destroy() {
    entityManagerFactory.close();
  }

  // Entities are auto-discovered, so just add them anywhere on class-path
  // Add your tests, using standard JUnit.
  @Test
  public void criteriaBuilder_not_suuport_min_value() throws Exception {
    EntityManager entityManager = entityManagerFactory.createEntityManager();
    entityManager.getTransaction().begin();

    CriteriaBuilder cb = entityManager.getCriteriaBuilder();

    CriteriaQuery<EntityA> q = cb.createQuery(EntityA.class);
    Root<EntityA> c = q.from(EntityA.class);
    q.select(c);

    q.where(cb.greaterThan(c.get("id"), Long.MIN_VALUE));
    TypedQuery<EntityA> query = entityManager.createQuery(q);

    // Will fail here
    query.getResultList();

    // Do stuff...
    entityManager.getTransaction().commit();
    entityManager.close();
  }
}
