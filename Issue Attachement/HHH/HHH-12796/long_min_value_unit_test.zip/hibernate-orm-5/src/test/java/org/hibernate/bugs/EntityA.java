package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class EntityA {

  @Id
  private Long id;

}
