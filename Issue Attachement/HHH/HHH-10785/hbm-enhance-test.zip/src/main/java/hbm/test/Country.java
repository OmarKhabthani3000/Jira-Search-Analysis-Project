package hbm.test;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "DB", name = "COUNTRY")
public class Country implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "DIRECTOR_ID")
	private Integer id;

	@Column(name = "DIRECTOR_NR")
	private Integer number;
	
	@Column(name = "NAME")
	private String name;

	
	public Country() {
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((this.number == null) ? 0 : this.number.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Country other = (Country) obj;
		if (this.number == null) {
			if (other.number != null)
				return false;
		} else if (!this.number.equals(other.number))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Country [number=" + this.number + "]";
	}
	
}
