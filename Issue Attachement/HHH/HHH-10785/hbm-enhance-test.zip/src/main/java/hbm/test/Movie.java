package hbm.test;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(schema = "DB", name = "MOVIE")
public class Movie implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @Column(name = "MOVIE_ID", nullable = false)
	private Integer id;
	
    @Column(name = "MOVIE_NR", nullable = false)
	private Integer number;
	
	@Column(name = "TITLE", length = 35)
	private String title;

	@ManyToOne(optional = false)
    @JoinColumn(name = "DIRECTOR_ID")
	private Director director;
	
	@ManyToOne(optional = true)
    @JoinColumn(name = "PREMIERE_THEATER_ID")
	private Theatre premiereTheater;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "RELEASE_DATE")
	private Date releaseDate;
	
	
	public Movie() {
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Director getDirector() {
		return director;
	}

	public void setDirector(Director director) {
		this.director = director;
	}

	public Theatre getPremiereTheater() {
		return premiereTheater;
	}

	public void setPremiereTheater(Theatre premiereTheater) {
		this.premiereTheater = premiereTheater;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		if (this.number == null) {
			if (other.number != null)
				return false;
		} else if (!this.number.equals(other.number))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Movie [number=" + this.number + "]";
	}
	
}
