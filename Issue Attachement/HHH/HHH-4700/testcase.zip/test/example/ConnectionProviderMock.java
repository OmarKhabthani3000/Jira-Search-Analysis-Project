package test.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import org.hibernate.HibernateException;
import org.hibernate.connection.ConnectionProvider;

public class ConnectionProviderMock implements ConnectionProvider {

	private static boolean initialized = false;

	private static ConnectionMock lastConnectionUsed;

	public static void setInitialized(boolean initialized) {
		ConnectionProviderMock.initialized = initialized;
	}

	public static ConnectionMock getLastConnectionUsed() {
		return lastConnectionUsed;
	}

	public void close() throws HibernateException {
		// TODO Auto-generated method stub

	}

	public void closeConnection(Connection conn) throws SQLException {
		// TODO Auto-generated method stub

	}

	public void configure(Properties props) throws HibernateException {
		// TODO Auto-generated method stub

	}

	public Connection getConnection() throws SQLException {
		if (initialized) {
			lastConnectionUsed = new ConnectionMock();
			return lastConnectionUsed;
		} else {
			initialized = true;
			throw new UnsupportedOperationException("");
		}
	}

	public boolean supportsAggressiveRelease() {
		// TODO Auto-generated method stub
		return false;
	}

}
