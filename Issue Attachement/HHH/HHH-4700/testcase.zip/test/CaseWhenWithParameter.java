package test;

import java.util.HashMap;

import org.hibernate.cfg.Configuration;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.hql.QueryTranslator;
import org.hibernate.hql.ast.QueryTranslatorImpl;
import org.junit.BeforeClass;
import org.junit.Test;

import test.example.AffectedObject;
import test.example.ConnectionProviderMock;


public class CaseWhenWithParameter {

	private static SessionFactoryImplementor factory;

	@BeforeClass
	public static void setUp() {
		Configuration cfg = new Configuration();
		cfg.addClass(AffectedObject.class);
		cfg.setProperty("hibernate.dialect",
				"org.hibernate.dialect.SQLServerDialect");
		/*	cfg.setProperty("hibernate.show_sql", "true");*/
		cfg.setProperty("hibernate.connection.provider_class",
				ConnectionProviderMock.class.getName());

		factory = (SessionFactoryImplementor) cfg.buildSessionFactory();
	}

	@Test
	public void doesntWork() {
		runQuery("UPDATE AffectedObject SET value = CASE WHEN name like 'L%' THEN :new_value END");
	}

	@Test
	public void works() {
		runQuery("UPDATE AffectedObject SET value = :new_value");
		runQuery("UPDATE AffectedObject SET value = CASE WHEN name like 'L%' THEN 'ok' END");
		runQuery("UPDATE AffectedObject SET value = CASE WHEN name not like 'L%' THEN 'ok' ELSE :new_value END");
	}

	private void runQuery(String hql) {
		QueryTranslator translators = new QueryTranslatorImpl(hql, hql, new HashMap(), factory);
		translators.compile(new HashMap(), false);
	}
}
