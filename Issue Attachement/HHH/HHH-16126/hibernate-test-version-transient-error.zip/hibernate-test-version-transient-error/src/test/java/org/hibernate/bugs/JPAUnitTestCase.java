package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import org.hibernate.Session;
import org.hibernate.bugs.entities.Domain;
import org.hibernate.bugs.entities.Privilege;
import org.hibernate.bugs.entities.Server;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
        createEntities();
    }

    private void createEntities() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        Domain domain = new Domain();

        Privilege privilege = new Privilege();

        Server server = new Server();

        domain.setPrivilege(privilege);

        privilege.setDomain(domain);
        privilege.setServer(server);

        server.setDomain(domain);
        server.setPrivilege(privilege);

        entityManager.persist(domain);
        entityManager.persist(privilege);
        entityManager.persist(server);

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh123Test() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        // Load all domains
        List<Domain> domains =
                entityManager.createNamedQuery("Domain.selectAll", Domain.class)
                        .getResultList();

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
