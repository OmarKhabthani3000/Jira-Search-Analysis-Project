package org.hibernate.bugs.entities;

import jakarta.persistence.*;

import java.util.Set;

@NamedQueries({
        @NamedQuery(
                name = "Domain.selectAll",
                query = "SELECT DISTINCT d" +
                        "  FROM Domain d" +
                        "  LEFT JOIN FETCH d.servers s")
})
@Entity
public class Domain {
    @Id
    @GeneratedValue
    private Long id;

    @ManyToOne
    private Privilege privilege;

    @Version
    private Integer rowVersion;

    @OneToMany(mappedBy = "domain")
    private Set<Server> servers;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Privilege getPrivilege() {
        return privilege;
    }

    public void setPrivilege(Privilege privilege) {
        this.privilege = privilege;
    }

    public Integer getRowVersion() {
        return rowVersion;
    }

    public void setRowVersion(Integer rowVersion) {
        this.rowVersion = rowVersion;
    }

    public Set<Server> getServers() {
        return servers;
    }

    public void setServers(Set<Server> servers) {
        this.servers = servers;
    }
}
