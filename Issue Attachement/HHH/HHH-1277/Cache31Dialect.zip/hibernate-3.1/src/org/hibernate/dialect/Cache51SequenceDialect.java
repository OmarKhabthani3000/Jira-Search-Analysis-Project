//$Id: Cache51Dialect.java,v 1.14 2005/08/25 13:36:00 oneovthafew Exp $
package org.hibernate.dialect;
import org.hibernate.dialect.CacheDialect;

import java.sql.Types;
import org.hibernate.MappingException;

/**
 * Cach� 5.1 dialect. This class is required in order to use Hibernate with Intersystems Cach� SQL.<br>
 * <br>
 * Compatible with Cach� 5.1.
 * Cache JDBC driver version ?.?.
 */
public class Cache51SequenceDialect extends Cache51Dialect {

	/**
	 * Creates new <code>Cach�51Dialect</code> instance. Sets up the JDBC /
	 * Cach� type mappings.
	 */
	public Cache51SequenceDialect() {
        super();
	}

    public String getSequenceNextValString(String sequenceName) {
        return "select InterSystems.Sequences_GetNext('"+sequenceName+"') from InterSystems.Sequences where ucase(name)=ucase('" + sequenceName + "'))";
    }
    public String getCreateSequenceString(String sequenceName) {
        return "insert into InterSystems.Sequences(Name) values (ucase('" + sequenceName + "'))";
    }
    public String getDropSequenceString(String sequenceName) {
        return "delete from InterSystems.Sequences where ucase(name)=ucase('" + sequenceName + "'))";

    }

    public boolean supportsSequences() {
        return true;
    }

}
