//$Id: CacheDialect.java,v 1.14 2005/08/25 13:36:00 oneovthafew Exp $
package org.hibernate.dialect;
import java.sql.Types;
import java.sql.SQLException;

import org.hibernate.Hibernate;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.function.NoArgSQLFunction;
import org.hibernate.dialect.function.StandardSQLFunction;
import org.hibernate.dialect.function.ConditionalParenthesisFunction;
import org.hibernate.dialect.function.InFixFunction;
import org.hibernate.dialect.function.SQLFunctionTemplate;
import org.hibernate.dialect.function.StandardODBCFunction;
import org.hibernate.exception.SQLExceptionConverter;
import org.hibernate.util.StringHelper;
import org.hibernate.sql.JoinFragment;
import org.hibernate.sql.CacheJoinFragment;
import org.hibernate.exception.TemplatedViolatedConstraintNameExtracter;
import org.hibernate.exception.ViolatedConstraintNameExtracter;
import org.hibernate.exception.JDBCExceptionHelper;
import org.hibernate.exception.CacheSQLStateConverter;
import java.sql.ResultSet;
import java.sql.CallableStatement;

/**
 * Cach� dialect. This class is required in order to use Hibernate with Intersystems Cach� SQL.<br>
 * <br>
 * <head>
 * <title>Cach&eacute; and Hibernate</title>
 * </head>
 * <body>
 * <h1>Cach&eacute; and Hibernate</h1>
 * <h2>PREREQUISITES</h2>
 * These setup instructions assume that both Cach&eacute; and Hibernate are installed and operational.
 * <br>
 * <h2>HIBERNATE DIRECTORIES AND FILES</h2>
 * InterSystems support for Hibernate 2.1.8 and Hibernate 3.0.5 requires different dialect files from those distributed with Hibernate 3.1.
 * Also Hibernate 2.1.8 has a different directory and Java package structure which is reflected in the InterSystems sources.
 * JBoss distributes the InterSystems Cache' dialect for Hibernate 3.1.
 * For earlier versions of Hibernate please contact
 * <a href="http://www.intersystems.com/support/cache-support.html">InterSystems Worldwide Response Center</A> (WRC)
 * for the appropriate source files.
 * <br>
 * <h2>CACH&Eacute; DOCUMENTATION</h2>
 * Documentation for Cach&eacute; is available online when Cach&eacute; is running.
 * It can also be obtained from the
 * <a href="http://www.intersystems.com/cache/downloads/documentation.html">InterSystems</A> website.
 * The book, "Object-oriented Application Development Using the Cach&eacute; Post-relational Database:
 * is also available from Springer-Verlag.
 * <br>
 * <h2>HIBERNATE DOCUMENTATION</h2>
 * Hibernate comes with extensive electronic documentation.
 * In addition, several books on Hibernate are available from
 * <a href="http://www.manning.com">Manning Publications Co</a>.
 * Two available titles are "Hibernate Quickly" and "Hibernate in Action".
 * <br>
 * <h2>TO SET UP HIBERNATE FOR USE WITH CACH&Eacute;</h2>
 * The following steps assume that the directory where Cach&eacute; was installed is C:\CacheSys.
 * This is the default installation directory for  Cach&eacute;.
 * The default installation directory for Hibernate is assumed to be C:\Hibernate.
 * <p>
 * If either product is installed in a different location, the pathnames that follow should be modified appropriately.
 * <p>
 * Cach&eacute; version 5.1 is recommended for use with Hibernate.
 * Some additional configuration actions are necessary if you wish to use Hibernate with Cach&eacute; version 5.0.x.
 * <ol>
 * <li>Copy C:\CacheSys\dev\java\lib\CacheDB.jar to C:\Hibernate\lib\CacheDB.jar.</li>
 * <p>
 * <li>Insert the following files into your Java classpath:
 * <p>
 * <ul>
 * <li>All jar files in the directory C:\Hibernate\lib</li>
 * <li>The directory (or directories) where hibernate.properties and/or hibernate.cfg.xml are kept.</li>
 * </ul>
 * </li>
 * <p>
 * <li>In the file, hibernate.properties (or hibernate.cfg.xml),
 * specify the Cach&eacute; dialect and the Cach&eacute; version URL settings.</li>
 * </ol>
 * <p>
 * For example, in Hibernate 3.1, typical entries in hibernate.properties would have the following
 * "name=value" pairs:
 * <p>
 * <table cols=3 border cellpadding=5 cellspacing=0>
 * <tr>
 * <th>Property Name</th>
 * <th>Property Value 3.1</th>
 * <th>Property Value 2.1.8</th>
 * </tr>
 * <tr>
 * <td>hibernate.dialect</td>
 * <td>hibernate.dialect org.hibernate.dialect.Cache51Dialect</td>
 * <td>net.sf.hibernate.dialect.Cache50Dialect</td>
 * </tr>
 * <tr>
 * <td>hibernate.connection.driver_class</td>
 * <td>com.intersys.jdbc.CacheDriver</td>
 * <td>com.intersys.jdbc.CacheDriver</td>
 * </tr>
 * <tr>
 * <td>hibernate.connection.username</td>
 * <td>(see note 1)</td>
 * <td>(see note 1)</td>
 * </tr>
 * <tr>
 * <td>hibernate.connection.password</td>
 * <td>(see note 1)</td>
 * <td>(see note 1)</td>
 * </tr>
 * <tr>
 * <td>hibernate.connection.url</td>
 * <td>jdbc:Cache://127.0.0.1:1972/USER</td>
 * <td>jdbc:Cache://127.0.0.1:1972/USER</td>
 * </tr>
 * </table>
 * <p>
 * <dl>
 * <dt><b>Note 1</b></dt>
 * <dd>Please contact your administrator for the userid and password you should use when attempting access via JDBC.
 * By default, these are chosen to be "_SYSTEM" and "SYS" respectively as noted in the SQL standard.</dd>
 * </dl>
 * <br>
 * <h2>CACH&Eacute; VERSION URL</h2>
 * This is the standard URL for the JDBC driver.
 * For a JDBC driver on the machine hosting Cach&eacute;, use the IP "loopback" address, 127.0.0.1.
 * For 1972, the default port, specify the super server port of your Cach&eacute; instance.
 * For USER, substitute the NAMESPACE which contains your Cach&eacute; database data.
 * <br>
 * <h2>CACH&Eacute; DIALECTS</h2>
 * Choices for Dialect are:
 * <br>
 * <p>
 * <ul>
 * <li>net.sf.hibernate.dialect.Cache50SequenceDialect</li>
 * <p>
 * <li>net.sf.hibernate.dialect.Cache50Dialect</li>
 * <p>
 * <li>net.sf.hibernate.dialect.Cache51Dialect</li>
 * <p>
 * <li>net.sf.hibernate.dialect.Cache51SequenceDialect</li>
 * </ul>
 * <p>
 * Setting up for Cach&eacute; 5.0 is similar except that the hibernate
 * dialect package is "org.hibernate.dialect.Cache50Dialect"
 * (or "org.hibernate.dialect.Cache50SequenceDialect" if you wish to use sequences support).
 * <br>
 * <h2>SETTING UP CACH&Eacute; DIALECT FROM INTERSYSTEMS SOURCES</h2>
 * <p>
 * InterSystems provides source code for the Hibernate Dialect classes.
 * Therefore, you must first place the source code in the proper locations
 * and compile it into Java class files.
 * Doing this will eliminate possible version mismatches in the compiled Java code.
 * <p>
 * To begin, unzip the InterSystems source into the PARENT directory of the location where you installed Hibernate.
 * The InterSystems zip file that contains InterSystems Hibernate support for
 * Hibernate 2.1.8 and Hibernate 3.0.5 already contains hibernate-2.1
 * and hibernate-3.0 in its directory structure.  This is why you must
 * unzip to the directory CONTAINING your Hibernate install directory.
 * <p>
 * If you are using Hibernate 3.1, JBoss has already built the right JAR file for you.
 * If you are NOT using Hibernate 3.1, then you must do the following:
 * <p>
 * <ol>
 * <li>In your Hibernate install directory, after the unzip we described above,
 * type the following:
 * <br>
 * <pre>
 *     build
 * </pre></li>
 * <li>Copy the JAR file to the proper place.
 * <p>
 * For Hibernate 3.0.5 and Hibernate 3.1, copy
 * <pre>
 * ..\hibernate\hibernate3.jar
 * </pre>
 * to the Hibernate install directory.
 * <p>
 * For Hibernate 2.1.8, copy
 * <pre>
 *     ..\hibernate\hibernate.2jar
 * </pre>
 * to the Hibernate install directory.</li>
 * <p>
 * <li>Test your installation by configuring etc\hibernate.properties for your Cach&eacute; database,
 * and then running the following:
 * <pre>
 *     build eg
 * </pre>
 * The build process reports its success or failure.  If you see,
 * <pre>
 *     BUILD FAILED
 * </pre>
 * please contact the
 * <a href="http://www.intersystems.com/support/cache-support.html">InterSystems Worldwide Response Center</A>
 * for assistance.
 * </li>
 * </ol>
 * <br>
 * <h2>SEQUENCE DIALECTS SUPPORT SEQUENCES</h2>
 * You do not have to use the sequence dialects with Cach&eacute;.
 * But if you choose to use them, set them up as follows:
 * <p>
 * To use Hibernate sequence support with Cach&eacute; in a namespace, you must FIRST load the following file into that namespace:
 * <pre>
 *     hibernate-3.1\src\org\hibernate\dialect\CacheSequences.xml
 * </pre>
 * In your Hibernate mapping you can specify sequence use.
 * When you are using a Cache' sequence dialect, the type "native" maps to sequence.
 * <p>
 * For example, the following shows the use of a sequence generator in a Hibernate mapping:
 * <pre>
 *     &lt;id name="id" column="uid" type="long" unsaved-value="null"&gt;
 *         &lt;generator class="seqhilo"&gt;
 *             &lt;param name="sequence"&gt;EVENTS_SEQ&lt;/param&gt;
 *             &lt;param name="max_lo"&gt;0&lt;/param&gt;
 *         &lt;/generator&gt;
 *     &lt;/id&gt;
 * </pre>
 * <br>
 * <h2>SUPPORT FOR IDENTITY COLUMNS</h2>
 * Cach&eacute; 5.1 or later supports identity columns. To cause Hibernate to use identity columns, specify "native" as the generator.
 * <br>
 * <h2>BIGINT SUPPORT</h2>
 * Cach&eacute; 5.1 supports BIGINT.
 * <p>
 * Cach&eacute; 5.0.x does not have direct BIGINT support.
 * To imitate BIGINT support in Cache 5.0.x, in the SQL configuration,
 * remap %INTEGER as follows, to be used by Cach&eacute; 5.0.x  dialects:
 * <p>
 * <pre>
 *     %Library.Integer(MAXVAL=99999999999999999999,MINVAL=-999999999999999999)
 * </pre>
 * <p>
 * To change SQL settings:
 * <p>
 * <ul>
 * <li>In Cach&eacute; 5.1, use the System Management Portal.</li>
 * <p>
 * <li>In Cach&eacute; 5.0, use the Configuration Manager.</li>
 * </ul>
 * <p>
 * Set Cach&eacute; SQL to allow:
 * <p>
 * <ul>
 * <li>delimited identifiers</li>
 * <li>drop of non-existent tables</li>
 * <li>drop of non-existent constraints</li>
 * </ul>
 * <p>
 * <h2>HIBERNATE 2.1.8</h2>
 * Hibernate 2.1.8 requires different source files from InterSystems reflecting
 * the different directory and Java package structure of Hibernate 2.1.8.
 * Please contact
 * <a href="http://www.intersystems.com/support/cache-support.html">InterSystems Worldwide Response Center</A> (WRC)
 * for these source files if you need to use Hibernate 2.1.8.
 * <p>
 * To run a Cach� application with Hibernate 2.1.8, set the following flag when starting your JVM:
 * <pre>
 *      -Dhibernate.jdbc.use_streams_for_binary=false
 * </pre>
 * <p>
 * In Hibernate 3.0.5, this flag is not necessary;
 * it is taken care of by the Cach&eacute; dialect itself.
 * <br>
 * <h2>TO SIMULATE LONGVARBINARY OR LONGVARCHAR IN A WHERE CLAUSE</h2>
 * Cach&eacute; does not support using LONGVARBINARY or LONGVARCHAR in a WHERE clause.
 * So for Hibernate type="object", you will need to map the id and class to a VARBINARY.  For example,
 * <p>
 * <pre>
 *     &lt;property name="any" type="object"&gt;
 *         &lt;column name="`any_id of object`"/&gt;
 *         &lt;column name="`any_class of object`" sql-type="varbinary(32767)"/&gt;
 *     <&lt;/property&gt;
 * </pre>
 * <h2>HIBERNATE FILES ASSOCIATED WITH CACH&Eacute; DIALECT</h2>
 * The following files are associated with Cach&eacute; dialect:
 * <p>
 * <ul>
 * <li>hibernate-3.1\src\org\hibernate\dialect\CacheDialect.java</li>
 * <li>hibernate-3.1\src\org\hibernate\exception\CacheSQLStateConverter.java</li>
 * <li>hibernate-3.1\src\org\hibernate\dialect\Cache50Dialect.java</li>
 * <li>hibernate-3.1\src\org\hibernate\dialect\Cache50SequenceDialect.java</li>
 * <li>hibernate-3.1\src\org\hibernate\dialect\Cache51Dialect.java</li>
 * <li>hibernate-3.1\src\org\hibernate\dialect\Cache51SequenceDialect.java</li>
 * <li>hibernate-3.1\src\org\hibernate\dialect\CacheDialect.java</li>
 * <li>hibernate-3.1\src\org\hibernate\dialect\function\ConditionalParenthesisFunction.java</li>
 * <li>hibernate-3.1\src\org\hibernate\dialect\function\InFixFunction.java</li>
 * <li>hibernate-3.1\src\org\hibernate\dialect\function\StandardODBCFunction.java</li>
 * <li>hibernate-3.1\src\org\hibernate\sql\CacheJoinFragment.java</li>
 * <li>hibernate-3.1\src\org\hibernate\dialect\CacheSequences.xml</li>
 * 	</ul>
 * 	<h2>Limitations</h2>
 * The following is a list of the currently known limitations of using Cache' with Hibernate. Please check with InterSystems on the latest status as these are server side issues.
 * <p>
 * - Support for identity columns is incomplete.
 * <p>
 * - Delete of self-referential foreign keys.
 * Deletion of a table row when the table has a foreign key that references itself and the foreign key in the table row references that table row. (self-referential foreign keys)
 * <p>
 * - Support for "SELECT FOR UPDATE."
 * <p>
 * Concurrency modes that require "SELECT FOR UPDATE" support cannot be used.
 * <p>
 * - Limitations in support for outer joins (see Cache' documentation). 
 * <p>
 * Cache' does support "NOT NULL" clauses in the ON conditions.
 * <p>
 * - Cache' does not support using longvarbinary or longvarchar in a where clause.  For Hibernate type="object", you will need to map the id and class to a varbinary.  For example,
 * <p>
 * <pre>
 *         &lt;property name="any" type="object"&gt;
 *         	&lt;column name="`any_id of object`"/&gt;
 *         	&lt;column name="`any_class of object`" sql-type="varbinary(32767)"/&gt;
 *         &lt;/property&gt;
 * </pre>
 * <p>
 * In Hibernate regression tests, Baz.hbm.xml, FooBar.hbm.xml, Glarch.hbm.xml and XY.hbm.xml have to be edited to replace "!" by BANG and "^" by CARET.  Our own identifier translation is not enough since Hibernate uses names containing these in its own mapping files and Hibernate (on the client-side) does not know about our server-side mapping.
 * <p>
 * Cache' fails two tests in org.hibernate.testcollection because of the following:
 * <p>
 * SQL ERROR -37: Aggregate function COUNT not supported for Stream fields
 * <p>
 * We fail on org.hibernate.test.component.ComponentTest since it uses the mapping:
 * <p>
 * <pre>
 * 			&lt;property name="yob" formula="year(dob)"/&gt;
 * </pre>
 * and the error is:
 * <p>
 * ERROR #359: User defined SQL Function 'SQLUSER.YEAR' does not exist
 * <p>
 * If the mapping is changed to
 * <p>
 * <pre>
 * 			&lt;property name="yob" formula="{fn year(dob)}"/&gt;
 * </pre>
 * then org.hibernate.test.component.ComponentTest mostly succeeds.
 * <p>
 * In org.hibernate.test.connections.SuppliedConnectionTest, testManualDisconnectWithOpenResources fails with java.lang.NullPointerException at java.util.StringTokenizer.<init>(StringTokenizer.java:146) at org.hibernate.pretty.Formatter.  This may be a problem with Hibernate not Cache'.
 * <p>
 * In org.hibernate.test.connections.ThreadLocalCurrentSessionTest in testManualDisconnectChain, Cache' fails with reconnect is not valid without active transaction.  This may be a problem with Hibernate not Cache'.
 * <p>
 * Cache' does not support "row value expressions" where clauses at this time, for example:
 * <p>
 * <pre>
 * result = s.createQuery("from Transaction txn where txn.value = (1.5, 'AUD')").list();
 * </pre>
 * will not generate valid Cache' SQL because of the parenthesis around (1.5, 'AUD')
 * <p>
 * org.hibernate.test.filter.DynamicFilterTest - 4 errors caused by "Unsupported Usage of Outter Join"
 * <p>
 * org.hibernate.test.hql.AdHocOnTest - we don't support temp tables.
 * Also true for org.hibernate.test.hql.BulkManipulationTest that it fails because we don't support temp tables
 * <p>
 * Cache' does not support ANSI extract and thus HQL like the following:
 * <p>
 * session.createQuery("select extract(second from current_timestamp()), extract(minute from current_timestamp()), extract(hour from current_timestamp()) from Mammal m").list();
 * <p>
 * will not work.
 * <p>
 * This causes failure in org.hibernate.test.hql.ASTParserLoadingTest
 * <p>
 * org.hibernate.test.hql.BulkManipulationTest testInsertManyToOne - there is a failure which is Prodlogged as 47355.  There is a syntax error in a join saying that 'MOTHER' is ambiguous.
 * <p>
 * org.hibernate.test.hql.ScrollableCollectionFetchingTest has failures because we do not support temp tables.
 * <p>
 * org.hibernate.test.joinedsubclass.JoinedSubclassTest fails because we do not support comparing parenthesized expressions, i.e., row value expressions.
 * <p>
 * In org.hibernate.test.legacy.ABCProxyTest, testDiscriminatorFiltering, we fail because of unsupported outter join.
 * <p>
 * org.hibernate.test.legacy.CustomSQLTest, testInsert because an attempt is made to insert into an identity column, which no database supports.  This is a "bug" in the Hibernate test.  It only works with databases whose native generator is not the identity generator.
 * <p>
 * org.hibernate.test.hql, AdHocOnTest fails since we do not support temp tables
 * <p>
 * org.hibernate.test.legacy.FooBarTest, testQuery fails.  We return two rows and we should only return 1.  This is Prodlog 47399.
 * <p>
 * org.hibernate.test.legacy.FooBarTest, testNamedParams fails because we do not support in () (empty parenthesis)
 * <p>
 * org.hibernate.test.legacy.FooBarTest, testCollectionsInSelect fails because we do not guarantee the case of a column returned using a group by clause.
 * <p>
 * The test has:
 * <p>
 * <pre>
 * list = s.find("select new Result( baz.name, max(foo.long), count(foo) ) from Baz baz join baz.fooArray foo group by baz.name");
 * </pre>
 * and we return baz.name in lower case.
 * <p>
 * org.hibernate.test.legacy.FooBarTest, testObjectType fails because we have a problem with returned batch counts in this case.
 * <p>
 * org.hibernate.test.legacy.MasterDetailTest, testSerialization fails because an attempt is made to insert into an identity column.  This is a problem with the test not Cache'.  Same is true for testUpdateLazyCollections.
 * <p>
 * In org.hibernate.test.legacy.MultiTableTest, with Cache51Dialect, testQueries, testConstraints, testMultiTable, and testMultiTableCollections, testMultiTableManyToOne fail because of attempt to insert into identity column.  This is problem with test not Cache'.
 * <p>
 * In org.hibernate.test.legacy.NewerPerformanceTest, testSimultaneous,
 * testHibernateOnly, testJdbcOnly, we fail with [SQLCODE: &lt;-110&gt;:&lt;Locking conflict in filing&gt;].
 * <p>
 * Same problem for org.hibernate.test.legacy.NewPerformanceTest, Prodlog 47370.
 * <p>
 * org.hibernate.test.querycache.QueryCacheTest, testQueryCacheInvaliddation, the wrong number of rows is returned.  Cache' returns 1 and should return 0.  This is Prodlog 47389.
 * <p>
 * org.hibernate.test.sqlinterceptor.SQLInterceptorTest; Cache' has one failure; the same failure as Oracle has, so it must be a problem with Hibernate test.
 * <p>
 * org.hibernate.test.unionsubclass2.UnionSubclassTest, testUnionSubclass test fails because we don't support "row value expressions."
 * </body>
 * @author InterSystems
 */
public class CacheDialect extends Dialect {

	/**
	 * Creates new <code>Cach�Dialect</code> instance. Sets up the JDBC /
	 * Cach� type mappings.
	 */
	public CacheDialect() {
		super();
		// Note: For object <-> SQL datatype mappings see:
		//	 Configuration Manager | Advanced | SQL | System DDL Datatype Mappings
		//
		//	TBD	registerColumnType(Types.BINARY,        "binary($1)");		
		// changed 08-11-2005, jsl
        registerColumnType(Types.BINARY,        "varbinary($1)");
        registerColumnType(Types.BIT,           "bit");
		registerColumnType(Types.CHAR,          "char(1)");		
		registerColumnType(Types.DATE,          "date");			
		registerColumnType(Types.DECIMAL,       "decimal");			
		registerColumnType(Types.DOUBLE,        "double");
		registerColumnType(Types.FLOAT,         "float");
		registerColumnType(Types.INTEGER,       "integer");
		registerColumnType(Types.LONGVARBINARY, "longvarbinary");	// binary %Stream
		registerColumnType(Types.LONGVARCHAR,   "longvarchar");		// character %Stream
		registerColumnType(Types.NUMERIC,       "numeric(19,3)");	
		registerColumnType(Types.REAL,          "real");
		registerColumnType(Types.SMALLINT,      "smallint");
		registerColumnType(Types.TIMESTAMP,     "timestamp");
		registerColumnType(Types.TIME,          "time");
		registerColumnType(Types.TINYINT,       "tinyint");
		// TBD should this be varbinary($1)?
		//		registerColumnType(Types.VARBINARY,     "binary($1)");
		registerColumnType(Types.VARBINARY,     "longvarbinary");
		registerColumnType(Types.VARCHAR,       "varchar($l)");
		registerColumnType(Types.BLOB,          "longvarbinary");
		registerColumnType(Types.CLOB,          "longvarchar");

		getDefaultProperties().setProperty(Environment.USE_STREAMS_FOR_BINARY, "false");
		getDefaultProperties().setProperty(Environment.STATEMENT_BATCH_SIZE, DEFAULT_BATCH_SIZE);
		getDefaultProperties().setProperty(Environment.USE_SQL_COMMENTS, "false");

		registerFunction( "abs", new StandardSQLFunction("abs") );
        registerFunction( "character_length", new StandardSQLFunction("character_length",Hibernate.INTEGER) );
        registerFunction( "char_length", new StandardSQLFunction("char_length",Hibernate.INTEGER) );
		registerFunction( "coalesce", new StandardSQLFunction("coalesce") );
		registerFunction( "dateadd", new StandardSQLFunction("dateadd",Hibernate.TIMESTAMP) );
		registerFunction( "datediff", new StandardSQLFunction("datediff",Hibernate.INTEGER) );
		registerFunction( "datename", new StandardSQLFunction("datename",Hibernate.STRING) );
        registerFunction( "datepart", new StandardSQLFunction("datepart",Hibernate.INTEGER) );
        registerFunction( "concat", new InFixFunction( "||", Hibernate.STRING ) );        
		registerFunction( "%external", new StandardSQLFunction("%external",Hibernate.STRING) );
		registerFunction( "$extract", new StandardSQLFunction("$extract",Hibernate.STRING) );
		registerFunction( "$find", new StandardSQLFunction("$find",Hibernate.INTEGER) );
		registerFunction( "length", new StandardSQLFunction("length",Hibernate.INTEGER) );
		registerFunction( "$length", new StandardSQLFunction("$length",Hibernate.INTEGER) );
		registerFunction( "list", new StandardSQLFunction("list",Hibernate.STRING) );
		registerFunction( "$list", new StandardSQLFunction("$list",Hibernate.STRING) );
		registerFunction( "$listdata", new StandardSQLFunction("$listdata",Hibernate.INTEGER) );
		registerFunction( "$listfind", new StandardSQLFunction("$listfind",Hibernate.INTEGER) );
		registerFunction( "$listget", new StandardSQLFunction("$listget",Hibernate.STRING) );
		registerFunction( "$listlength", new StandardSQLFunction("$listlength",Hibernate.INTEGER) );
		registerFunction( "lower", new StandardSQLFunction("lower") );
		registerFunction( "ltrim", new StandardSQLFunction("ltrim") );
		registerFunction( "nvl", new StandardSQLFunction("nvl") );
		registerFunction( "$piece", new StandardSQLFunction("$piece",Hibernate.STRING) );
		registerFunction( "position", new StandardSQLFunction("position",Hibernate.INTEGER) );
		registerFunction( "repeat", new StandardSQLFunction("repeat",Hibernate.STRING) );
		registerFunction( "round", new StandardSQLFunction("round") );
		registerFunction( "rtrim", new StandardSQLFunction("rtrim") );
		registerFunction( "sign", new StandardSQLFunction("sign",Hibernate.INTEGER) );
		registerFunction( "space", new StandardSQLFunction("space",Hibernate.STRING) );
		registerFunction( "%sqlupper", new StandardSQLFunction("%sqlupper") );
		registerFunction( "%sqlstring", new StandardSQLFunction("%sqlstring",Hibernate.STRING) );
		registerFunction( "%sqlupper", new StandardSQLFunction("%sqlupper",Hibernate.STRING) );
		registerFunction( "substr", new StandardSQLFunction("substr",Hibernate.STRING) );
        registerFunction( "substring", new StandardSQLFunction("substring",Hibernate.STRING) );
        registerFunction( "locate", new StandardSQLFunction( "$FIND", Hibernate.INTEGER ) );        
		registerFunction( "tochar", new StandardSQLFunction("tochar",Hibernate.STRING) );
		registerFunction( "todate", new StandardSQLFunction("todate",Hibernate.STRING) );
		registerFunction( "to_char", new StandardSQLFunction("to_char",Hibernate.STRING) );
		registerFunction( "to_date", new StandardSQLFunction("to_date",Hibernate.STRING) );
		//registerFunction( "trim", new StandardSQLFunction("trim",Hibernate.STRING) );
        registerFunction( "upper", new StandardSQLFunction("upper") );

        registerFunction("year", new StandardODBCFunction("YEAR", Hibernate.INTEGER) );
        registerFunction("mod", new StandardODBCFunction("MOD", Hibernate.DOUBLE) );                
        registerFunction("sqrt", new StandardODBCFunction("SQRT", Hibernate.DOUBLE) );
        registerFunction( "bit_length", new SQLFunctionTemplate( Hibernate.INTEGER, "($length(?1)*8)" ) );
        registerFunction("current_timestamp", new ConditionalParenthesisFunction( "CURRENT_TIMESTAMP", Hibernate.TIMESTAMP));
        registerFunction("current_time", new NoArgSQLFunction("CURRENT_TIME", Hibernate.TIME, false) );
        registerFunction("current_date", new NoArgSQLFunction("CURRENT_DATE", Hibernate.DATE, false) );        
        registerFunction("hour", new StandardODBCFunction("hour", Hibernate.INTEGER) );
        registerFunction("minute", new StandardODBCFunction("minute", Hibernate.INTEGER) );
        registerFunction("second", new StandardODBCFunction("minute", Hibernate.INTEGER) );         
        registerFunction("year", new StandardODBCFunction("hour", Hibernate.INTEGER) );
        registerFunction("month", new StandardODBCFunction("minute", Hibernate.INTEGER) );
        registerFunction("day", new StandardODBCFunction("minute", Hibernate.INTEGER) );         
        

	}

        public boolean hasAlterTable() {
		// Does this dialect support the ALTER TABLE syntax? 
                return true;
        }

	public boolean qualifyIndexName() {
	        // Do we need to qualify index names with the schema name?
	        return false;
	}
	
	public boolean supportsForUpdate() {
		// Does this dialect support the FOR UPDATE syntax? 
		return false;
	}
	
	public boolean supportsForUpdateOf() {
		// Does this dialect support FOR UPDATE OF, allowing particular rows to be locked? 
		return false;
	}
	
        public boolean supportsForUpdateNowait() {
		// Does this dialect support the Oracle-style FOR UPDATE NOWAIT syntax? 
		return false;
	}
	
	public boolean supportsUnique() {
		// Does this dialect support the UNIQUE column syntax? 
		return true;
	}

	/**
	 * The syntax used to add a foreign key constraint to a table.
	 * @return String
	 */
	public String getAddForeignKeyConstraintString(String constraintName, String[] foreignKey, String referencedTable, String[] primaryKey) {
		// The syntax used to add a foreign key constraint to a table. 
		return new StringBuffer(300)
		.append(" ADD CONSTRAINT ")
		.append(constraintName)		
		.append(" FOREIGN KEY ")
		.append(constraintName)
		.append(" ("	)
		.append( StringHelper.join(", ", foreignKey) )	// identifier-commalist
		.append(") REFERENCES ")
		.append(referencedTable)
		.append(" (")
		.append( StringHelper.join(", ", primaryKey) ) // identifier-commalist
		.append(") ")
		.toString();
	}

	// ----------------------------------------------------------------------------
	// TOP n (LIMIT TO n ROWS)
	public boolean supportsLimit() {
		// Does this Dialect have some kind of LIMIT syntax?
		return true;
	}
	public boolean supportsLimitOffset() {
		// Does this dialect support an offset to the LIMIT? 
		return false;
	}	
	public boolean supportsVariableLimit() {
		return true;
	}
	public boolean bindLimitParametersFirst() {
		// Does the LIMIT clause come at the start of the SELECT statement, rather than at the end? 
		return true;
	}
	public boolean useMaxForLimit() {
		// Does the LIMIT clause take a "maximum" row number instead of a total number of returned rows? 
		return true;
	}

	public String getLimitString(String querySelect, boolean hasOffset, int limit) {
	        // TBD: Should this use limit parameter (like SQL server) or
                // '?' (like Informix)?  SQL server doesn't support variable
                // limit, Informix does.
		if (hasOffset) throw new UnsupportedOperationException("An offset may not be specified to <TOP n> in Cache SQL");
		/*
                String topString = new StringBuffer(32)
		    .append(" TOP ").append(limit).append(" ").toString();
		return new StringBuffer( querySelect.length()+32 )
			.append(querySelect)
			.insert( getAfterSelectInsertPoint(querySelect), topString )
			.toString();
		*/
		return new StringBuffer( querySelect.length()+8 )
			.append(querySelect)
			.insert( getAfterSelectInsertPoint(querySelect), " TOP ? " )
			.toString();

	}
	
	// This does not support the Cache SQL 'DISTINCT BY (comma-list)' extensions,
	// but this extension is not supported through Hibernate anyway.
	//
	private static int getAfterSelectInsertPoint(String sql) {
	        // TBD: Is this properly case insensitive?
		return sql.startsWith("select distinct") ? 15 : 6;
	}
		
	public boolean supportsCheck() {
		// Does this dialect support check constraints? 
		return false;
	}

        public String getLowercaseFunction() {
	        // The name of the SQL function that transforms a string to lowercase 
	        return "lower";
	}

	public String getAddColumnString() {
	        // The syntax used to add a column to a table
	        return " add column";
	}    

	public String getCascadeConstraintsString() {
                // Completely optional cascading drop clause.
	        return " cascade"; 
    }

	public boolean dropConstraints() {
	        // Do we need to drop constraints before dropping tables in this dialect?
	        return true;
	}

    public boolean supportsCascadeDelete() {
        return true;
    }

	public String getNullColumnString() {
                // The keyword used to specify a nullable column.
	        return " null";
	}

	public JoinFragment createOuterJoinFragment() {
                // Create an OuterJoinGenerator for this dialect.
	        return new CacheJoinFragment();
	}

	public String getNoColumnsInsertString() {
	        // The keyword used to insert a row without specifying
                // any column values
	        return " default values";
	}

    public String getLimitString(String sql, boolean hasOffset) {
            // JSL added from JMM's getLimitString 8/25/2005 and
            // now build eg passes, before it failed
            if (hasOffset) throw new UnsupportedOperationException("An offset may not be specified to <TOP n> in Cache SQL");
            return new StringBuffer( sql.length()+8 )
                .append(sql)
                .insert( getAfterSelectInsertPoint(sql), " TOP ? " )
                .toString();
    }

    public boolean hasSelfReferentialForeignKeyBug() {
        return true;
    }

    public SQLExceptionConverter buildSQLExceptionConverter() {
        // The default SQLExceptionConverter for all dialects is based on SQLState
        // since SQLErrorCode is extremely vendor-specific.  Specific Dialects
        // may override to return whatever is most appropriate for that vendor.
        return new CacheSQLStateConverter( getViolatedConstraintNameExtracter() );
    }
    
    public ViolatedConstraintNameExtracter getViolatedConstraintNameExtracter() {
        return EXTRACTER;

    }

    private static ViolatedConstraintNameExtracter EXTRACTER = new TemplatedViolatedConstraintNameExtracter() {

            /**
             * Extract the name of the violated constraint from the given SQLException.
             *
             * @param sqle The exception that was the result of the constraint violation.
             * @return The extracted constraint name.
             */
        public String extractConstraintName(SQLException sqle) {
                return extractUsingTemplate( "constraint (", ") violated", sqle.getMessage() );
        }
    };

    public int registerResultSetOutParameter(CallableStatement statement, int col) throws SQLException {
        return col; 
    }

    public ResultSet getResultSet(CallableStatement ps) throws SQLException {
        ps.execute();
        ResultSet rs = (ResultSet) ps.getObject(1);			
        return rs;		
    }

}



