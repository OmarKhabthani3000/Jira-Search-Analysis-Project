//$Id: Cache51Dialect.java,v 1.14 2005/08/25 13:36:00 oneovthafew Exp $
package org.hibernate.dialect;
import org.hibernate.dialect.CacheDialect;

import java.sql.Types;
import org.hibernate.MappingException;

/**
 * Cach� 5.1 dialect. This class is required in order to use Hibernate with Intersystems Cach� SQL.<br>
 * <br>
 * Compatible with Cach� 5.1.
 * Cache JDBC driver version ?.?.
 */
public class Cache50Dialect extends CacheDialect {

	/**
	 * Creates new <code>Cach�51Dialect</code> instance. Sets up the JDBC /
	 * Cach� type mappings.
	 */
	public Cache50Dialect() {
        super();
        registerColumnType(Types.BIGINT,"Integer");        
	}

}
