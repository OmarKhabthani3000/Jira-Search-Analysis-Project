//$Id: CacheJoinFragment.java,v 1.0 2005/08/25 13:52:00 oneovthafew Exp $
package org.hibernate.sql;

import org.hibernate.AssertionFailure;
import org.hibernate.sql.JoinFragment;

/**
 * A Cach� dialect join.  Differs from ANSI only in that full outer join is not supported.
 * @author Jeff Miller
 * Modifed 8-26-05 by Jonathan Levinson to support Hibernate 3.0
 */
public class CacheJoinFragment extends JoinFragment {
	
	private StringBuffer buffer = new StringBuffer();
	private StringBuffer conditions = new StringBuffer();
    
	public void addJoin(String tableName, String alias, String[] fkColumns, String[] pkColumns, int joinType) {
		addJoin(tableName, alias, fkColumns, pkColumns, joinType, null);
	}

    public void addJoin(String tableName, String alias, String[] fkColumns, String[] pkColumns, int joinType, String on) {
        String joinString;
        switch (joinType) {
            case INNER_JOIN:
                joinString = " inner join ";
                break;
            case LEFT_OUTER_JOIN:
                joinString = " left outer join ";
                break;
            case RIGHT_OUTER_JOIN:
                joinString = " right outer join ";
                break;
            case FULL_JOIN:
                throw new AssertionFailure("Cache does not support full outer joins");
            default:
                throw new AssertionFailure("undefined join type");
        }

        buffer.append(joinString)
                .append(tableName)
                .append(' ')
                .append(alias)
                .append(" on ");


        for ( int j=0; j<fkColumns.length; j++) {
            //if (fkColumns[j].indexOf('.')<1) throw new AssertionFailure("missing alias");
            buffer.append( fkColumns[j] )
                    .append('=')
                    .append(alias)
                    .append('.')
                    .append( pkColumns[j] );
            if ( j<fkColumns.length-1 ) buffer.append(" and ");
        }
        addCondition(buffer, on);
    }

	public String toFromFragmentString() {
		return buffer.toString();
	}

	public String toWhereFragmentString() {
		return conditions.toString();
	}

	public void addJoins(String fromFragment, String whereFragment) {
		buffer.append(fromFragment);
		//where fragment must be empty!
	}

	public JoinFragment copy() {
		CacheJoinFragment copy = new CacheJoinFragment();
		copy.buffer = new StringBuffer( buffer.toString() );
		return copy;
	}

	public void addCondition(String alias, String[] columns, String condition) {
		for ( int i=0; i<columns.length; i++ ) {
			conditions.append(" and ")
				.append(alias)
				.append('.')
				.append( columns[i] )
				.append(condition);
		}
	}

	public void addCrossJoin(String tableName, String alias) {
		buffer.append(", ")
			.append(tableName)
			.append(' ')
			.append(alias);		
	}

	public void addCondition(String alias, String[] fkColumns, String[] pkColumns) {
		throw new UnsupportedOperationException();
			
	}

    public boolean addCondition(String condition) {
        //return false;
        return addCondition(conditions, condition);  // jsl august 25, 2005, not sure this is correct, but like SybaseJoinFragment
	}
	
	public void addFromFragmentString(String fromFragmentString) {
		buffer.append(fromFragmentString);
	}

}
