//$Id: Cache51Dialect.java,v 1.14 2005/08/25 13:36:00 oneovthafew Exp $
package org.hibernate.dialect;
import org.hibernate.dialect.CacheDialect;

import java.sql.Types;
import org.hibernate.MappingException;

/**
 * Cach� 5.1 dialect. This class is required in order to use Hibernate with Intersystems Cach� SQL.<br>
 * <br>
 * Compatible with Cach� 5.1.
 * Cache JDBC driver version ?.?.
 */
public class Cache51Dialect extends CacheDialect {

	/**
	 * Creates new <code>Cach�51Dialect</code> instance. Sets up the JDBC /
	 * Cach� type mappings.
	 */
	public Cache51Dialect() {
        super();
        registerColumnType(Types.BIGINT,"BigInt");			
        
	}

	public boolean supportsIdentityColumns() {
		return true;
	}
    	 
	public String getIdentitySelectString() {
	    return null;
	}

	public boolean hasDataTypeInIdentityColumn() {
		// Whether this dialect has an Identity clause added to the data type or a completely seperate identity 
		// data type 
		return true;
	}
	
	public String getIdentityColumnString() throws MappingException {
		// The keyword used to specify an identity column, if identity column key generation is supported. 
	    return "identity";
	}
}
