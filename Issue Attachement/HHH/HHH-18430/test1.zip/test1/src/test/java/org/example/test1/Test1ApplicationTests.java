package org.example.test1;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test1ApplicationTests {

    @Autowired
    Entity1Repo repo1;
    @Autowired
    Handler handler;

    @BeforeEach
    void setUp() {
        repo1.deleteAll();
    }

    @Test
    void returnVersion1() {
        handler.runIn(() ->{
            System.out.println("METHOD 1");
            method1();
            System.out.println("METHOD 2");
            method2();
        });
        System.out.println("AFTER TRANSACTION");
        var tmp = repo1.findById(1L).get();
        System.out.println(tmp);
    }

    @Test
    void returnVersion2() {
        handler.runIn(() ->{
            System.out.println("METHOD 1");
            method1();
            System.out.println("FIND ALL");
            repo1.findByDocId(3);
            System.out.println("METHOD 2");
            method2();
        });
        System.out.println("AFTER TRANSACTION");
        var tmp = repo1.findById(1L).get();
        System.out.println(tmp);
    }

    private void method1(){
        var tmp = new Entity1();
        tmp.setId(1L);
        tmp.setDocId(1);
        repo1.save(tmp);

        System.out.println("AFTER SAVE 1");
        tmp = repo1.findById(1L).get();
        tmp.setDocId(2);
        repo1.save(tmp);

        System.out.println("AFTER SAVE 2");
        tmp = repo1.findById(1L).get();
        tmp.setDocId(3);
        repo1.save(tmp);
        System.out.println("AFTER SAVE 3");
    }

    private void method2(){
        var tmp = repo1.findById(1L).get();
        tmp.setDocId(4);
        repo1.save(tmp);
        System.out.println("AFTER SAVE 4");

        tmp = repo1.findById(1L).get();
        tmp.setDocId(5);
        repo1.save(tmp);
        System.out.println("AFTER SAVE 5");

        tmp = repo1.findById(1L).get();
        tmp.setDocId(6);
        repo1.save(tmp);
        System.out.println("AFTER SAVE 6");
    }

}
