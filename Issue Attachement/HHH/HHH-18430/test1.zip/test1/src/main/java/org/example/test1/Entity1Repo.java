package org.example.test1;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Entity1Repo extends JpaRepository<Entity1, Long> {

    Entity1 findByDocId(int id);
}
