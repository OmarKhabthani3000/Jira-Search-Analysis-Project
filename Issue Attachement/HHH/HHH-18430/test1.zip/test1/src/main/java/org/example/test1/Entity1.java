package org.example.test1;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import lombok.Data;

@Table(name = "Entity1")
@Entity
@Data
public class Entity1 {

    @Id
    private long id;

    private int docId;

    @Version
    private int version;
}
