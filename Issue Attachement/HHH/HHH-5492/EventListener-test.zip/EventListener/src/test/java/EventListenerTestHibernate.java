import org.hibernate.*;
import org.hibernate.cfg.AnnotationConfiguration;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static junit.framework.Assert.*;


/**
 * When using an Oracle database, the following test is failing. Using hsqldb or mysql it passes 
 *
 * @author Barry.Pitman
 * @since 19 Aug 2010 4:22:33 PM
 */

public class EventListenerTestHibernate {

    private SessionFactory sessionFactory;

    @Before
    public void setup() {
        AnnotationConfiguration annotationConfiguration = new AnnotationConfiguration();
        annotationConfiguration.setListener("post-insert", new EventListener());
        annotationConfiguration.setListener("post-delete", new EventListener());
        annotationConfiguration.setListener("post-update", new EventListener());
        sessionFactory = annotationConfiguration.configure().buildSessionFactory();

        //remove any existing data
        Transaction transaction = sessionFactory.getCurrentSession().beginTransaction();
        sessionFactory.getCurrentSession().createQuery("delete from SomeEntity").executeUpdate();
        sessionFactory.getCurrentSession().createQuery("delete from AuditRecord").executeUpdate();
        transaction.commit();
    }

    @Test
    public void testInsertListener() {
        Transaction transaction = sessionFactory.getCurrentSession().beginTransaction();

        //there are no exist records
        assertEquals(0, findAllEntityRecords().size());
        assertEquals(0, findAllAuditRecords().size());

        //insert a new record, an audit record should be saved
        SomeEntity record = new SomeEntity();
        sessionFactory.getCurrentSession().save(record);
        assertEquals(1, findAllEntityRecords().size());
        assertEquals(1, findAllAuditRecords().size());

        //update, new audit record should be written
        record.setProperty("force update to happen");
        sessionFactory.getCurrentSession().update(record);
        assertEquals(1, findAllEntityRecords().size());
        assertEquals(2, findAllAuditRecords().size());

        //delete the inserted record, new audit record is written
        sessionFactory.getCurrentSession().delete(record);
        assertEquals(0, findAllEntityRecords().size());
        assertEquals(3, findAllAuditRecords().size());
        transaction.commit();

    }

    private List<SomeEntity> findAllEntityRecords() {
        return (List<SomeEntity>) sessionFactory.getCurrentSession().createQuery("from SomeEntity").list();
    }

    private List<AuditRecord> findAllAuditRecords() {
        return (List<AuditRecord>) sessionFactory.getCurrentSession().createQuery("from AuditRecord").list();
    }

}
