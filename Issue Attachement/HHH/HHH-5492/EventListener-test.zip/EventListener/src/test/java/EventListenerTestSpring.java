import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.test.annotation.NotTransactional;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import static junit.framework.Assert.*;


/**
 * todo: short description here.
 *
 * @author Barry.Pitman
 * @since 19 Aug 2010 4:22:33 PM
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
public class EventListenerTestSpring {

    @Autowired private Dao dao;
    @Autowired private HibernateTransactionManager hibernateTransactionManager;

    @Test
    public void testInsertListener() {
        SomeEntity record = new SomeEntity();
        assertEquals(0, dao.findAll(SomeEntity.class).size());
        assertEquals(0, dao.findAll(AuditRecord.class).size());
        dao.save(record);
        assertEquals(1, dao.findAll(SomeEntity.class).size());
        assertEquals(1, dao.findAll(AuditRecord.class).size());
        record.setProperty("force update to happen");
        dao.update(record);
        assertEquals(1, dao.findAll(SomeEntity.class).size());
        assertEquals(2, dao.findAll(AuditRecord.class).size());
        dao.delete(record);
        assertEquals(0, dao.findAll(SomeEntity.class).size());
        assertEquals(3, dao.findAll(AuditRecord.class).size());
    }

}
