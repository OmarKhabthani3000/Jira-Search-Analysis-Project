import javax.persistence.*;

/**
 * @author Barry.Pitman
 * @since 19 Aug 2010 5:09:23 PM
 */
@Entity
@Table
public class SomeEntity {

    private Long id;
    private String property;

    public SomeEntity() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProperty() {
        return property;
    }

    public void setProperty(String property) {
        this.property = property;
    }
}
