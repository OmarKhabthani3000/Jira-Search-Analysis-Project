import java.io.Serializable;
import java.util.List;

/**
 * todo: short description here.
 *
 * @author Barry.Pitman
 * @since 19 Aug 2010 11:59:17 PM
 */
public interface Dao {

    void save(SomeEntity someEntity);
    void update(SomeEntity someEntity);
    void delete(SomeEntity someEntity);
    <T> List<T> findAll(Class<T> clazz);
}
