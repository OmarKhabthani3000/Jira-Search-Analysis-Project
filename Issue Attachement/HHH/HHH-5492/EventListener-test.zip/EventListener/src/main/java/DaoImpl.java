import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateOperations;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.util.List;

/**
 * todo: short description here.
 *
 * @author Barry.Pitman
 * @since 20 Aug 2010 12:01:20 AM
 */
public class DaoImpl implements Dao {

    private HibernateOperations hibernateOperations;

    public void setHibernateOperations(HibernateOperations hibernateOperations) {
        this.hibernateOperations = hibernateOperations;
    }

    public void save(SomeEntity someEntity) {
        hibernateOperations.save(someEntity);
    }

    public void update(SomeEntity someEntity) {
        hibernateOperations.update(someEntity);
    }

    public void delete(SomeEntity someEntity) {
        hibernateOperations.delete(someEntity);
    }

    public <T> List<T> findAll(Class<T> clazz) {
        return hibernateOperations.loadAll(clazz);
    }
}
