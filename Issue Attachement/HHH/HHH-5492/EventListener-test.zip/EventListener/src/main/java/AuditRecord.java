import javax.persistence.*;

/**
 *
 * @author Barry.Pitman
 * @since 19 Aug 2010 4:19:01 PM
 */
@Entity
@Table
public class AuditRecord {

    private Long id;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
