import org.hibernate.Session;
import org.hibernate.event.*;

import java.util.Random;
import java.util.UUID;

/**
 * Inserts an audit record every time a SomeEntity is called.
 *
 * @author Barry.Pitman
 * @since 19 Aug 2010 4:16:59 PM
 */
public class EventListener implements PostInsertEventListener, PostDeleteEventListener, PostUpdateEventListener {

    public void onPostInsert(PostInsertEvent event) {
        if (isAuditable(event.getEntity())) {
            saveAuditRecord(event.getSession());
        }
    }

    /*public boolean onPreInsert(PreInsertEvent event) {
        if (isAuditable(event.getEntity())) {
            saveAuditRecord(event.getSession());
        }
        return false;
    }*/

    public void onPostDelete(PostDeleteEvent event) {
        if (isAuditable(event.getEntity())) {
            saveAuditRecord(event.getSession());
        }
    }

    public void onPostUpdate(PostUpdateEvent event) {
        if (isAuditable(event.getEntity())) {
            saveAuditRecord(event.getSession());
        }
    }

    private boolean isAuditable(Object entity) {
        return entity instanceof SomeEntity;
    }

    private void saveAuditRecord(Session session) {
        AuditRecord record = new AuditRecord();
        record.setId(Double.doubleToLongBits(Math.random()));
        session.save(record);
    }
}
