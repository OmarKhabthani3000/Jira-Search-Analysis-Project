package nl.relate4u.innovation.model.definition;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import nl.relate4u.innovation.model.base.FieldDefinitionContainer;
import nl.relate4u.innovation.model.base.KeyedObjectInterface;
import nl.relate4u.innovation.model.base.LabeledObjectInterface;
import nl.relate4u.innovation.model.content.Asset;
import nl.relate4u.innovation.model.email.MailTemplate;
import nl.relate4u.innovation.model.enumerations.FeedbackPosition;
import nl.relate4u.innovation.model.enumerations.FieldDefinitionType;
import nl.relate4u.innovation.model.lang.Label;
import nl.relate4u.innovation.model.lang.LargeLabel;
import nl.relate4u.innovation.model.user.Role;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.IndexColumn;

@Entity
public class FeedbackType extends FieldDefinitionContainer implements Serializable, LabeledObjectInterface, KeyedObjectInterface {

    private static final long serialVersionUID = 7586893922898464892L;

    @Column(unique = true, name = "feedback_type_key")
    private String key;
    
    @JoinColumn(name = "label_plural_id")
    @ManyToOne(cascade = CascadeType.ALL)
    private Label labelPlural = new Label();

    @JoinColumn(name = "label_button_id")
    @ManyToOne(cascade = CascadeType.ALL)
    private Label labelButton = new Label();

    @JoinColumn(name = "trigger_text_id")
    @ManyToOne(cascade = CascadeType.ALL)
    private LargeLabel triggerText = new LargeLabel();

    @JoinColumn(name = "intro_text_id")
    @ManyToOne(cascade = CascadeType.ALL)
    private LargeLabel introText = new LargeLabel();

    @JoinColumn(name = "outcome_text_id")
    @ManyToOne(cascade = CascadeType.ALL)
    private LargeLabel outcomeText = new LargeLabel();

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private FeedbackPosition buttonPosition = FeedbackPosition.RIGHT_COLUMN;

    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    private Asset icon;

    @Column(columnDefinition = "TINYINT")
    private boolean sendToOwner;

    @Column(columnDefinition = "TINYINT")
    private boolean sendToModerators;

    @Column(columnDefinition = "TINYINT")
    private boolean showFeedback;

    @Column(columnDefinition = "TINYINT")
    private boolean showFeedbackOnHomePage;

    @ManyToOne
    private MailTemplate emailTemplate;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @IndexColumn(name = "definiton_index")
    private List<FeedbackFieldDefinition> fieldDefinitions = new ArrayList<FeedbackFieldDefinition>();

    @ManyToMany(cascade = CascadeType.PERSIST)
    @Cascade(value = org.hibernate.annotations.CascadeType.SAVE_UPDATE)
    private Set<Role> requiredRoles = new HashSet<Role>();
    
    @Override
    public String getKey() {
        return key;
    }
    
    @Override
    public void setKey(String key) {
        this.key = key;
    }
    
    public String getLabelPlural() {
        return labelPlural.get();
    }
    
    public void setLabelPlural(String labelPlural) {
        this.labelPlural.add(labelPlural);
    }
    
    public String getLabelButton() {
        return labelButton.get();
    }
    
    public void setLabelButton(String labelButton) {
        this.labelButton.add(labelButton);
    }
    
    public String getTriggerText() {
        return triggerText.get();
    }

    public void setTriggerText(String triggerText) {
        this.triggerText.add(triggerText);
    }
    
    public String getIntroText() {
        return introText.get();
    }

    public void setIntroText(String introText) {
        this.introText.add(introText);
    }
    
    public void setOutcomeText(String outcomeText) {
        this.outcomeText.add(outcomeText);
    }

    public String getOutcomeText() {
        return outcomeText.get();
    }
    
    public FeedbackPosition getButtonPosition() {
        return buttonPosition;
    }

    public void setButtonPosition(FeedbackPosition buttonPosition) {
        this.buttonPosition = buttonPosition;
    }

    public Asset getIcon() {
        return icon;
    }

    public void setIcon(Asset icon) {
        this.icon = icon;
    }

    public MailTemplate getEmailTemplate() {
        return emailTemplate;
    }

    public void setEmailTemplate(MailTemplate emailTemplate) {
        this.emailTemplate = emailTemplate;
    }

    public boolean isSendToOwner() {
        return sendToOwner;
    }

    public void setSendToOwner(boolean sendToOwner) {
        this.sendToOwner = sendToOwner;
    }

    public boolean isSendToModerators() {
        return sendToModerators;
    }

    public void setSendToModerators(boolean sendToModerators) {
        this.sendToModerators = sendToModerators;
    }
    
    public boolean isShowFeedback() {
        return showFeedback;
    }
    
    public void setShowFeedback(boolean showFeedback) {
        this.showFeedback = showFeedback;
    }
    
    public boolean isShowFeedbackOnHomePage() {
        return showFeedbackOnHomePage;
    }
    
    public void setShowFeedbackOnHomePage(boolean showFeedbackOnHomePage) {
        this.showFeedbackOnHomePage = showFeedbackOnHomePage;
    }

    public Set<Role> getRequiredRoles() {
        return requiredRoles;
    }

    public void setRequiredRoles(Set<Role> requiredRoles) {
        this.requiredRoles = requiredRoles;
    }

    public List<FeedbackFieldDefinition> getFieldDefinitions() {
        return fieldDefinitions;
    }

    public void setFieldDefinitions(List<FeedbackFieldDefinition> fieldDefinitions) {
        this.fieldDefinitions = fieldDefinitions;
    }

    @Transient
    public boolean isButtonPositionRightColumn(){
        return FeedbackPosition.RIGHT_COLUMN.equals(buttonPosition);
    }

    @Transient
    public FeedbackFieldDefinition getFieldDefinitionById(Long fieldId) {
        return super.getFieldDefinitionById(fieldDefinitions, fieldId);
    }

    @Transient
    public List<FeedbackFieldDefinition> getFieldDefinitionsByTypes(FieldDefinitionType... types) {
        return super.getFieldDefinitionsByTypes(fieldDefinitions, types);
    }

    @Override
    public String toString() {
        return "FeedbackType: id=" + getId() + ", key=" + getKey();
    }
}
