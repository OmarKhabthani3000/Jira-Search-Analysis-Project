package nl.relate4u.innovation.model.content;

import java.awt.Rectangle;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.Transient;

import nl.relate4u.innovation.Constants;
import nl.relate4u.innovation.model.base.FieldContainer;
import nl.relate4u.innovation.model.definition.AssetType;
import nl.relate4u.innovation.model.enumerations.AssetUsage;
import nl.relate4u.innovation.util.LocalizationUtil;
import nl.relate4u.innovation.util.enumeration.AssetMimeTypeGroup;
import nl.relate4u.innovation.util.enumeration.FallbackLocale;
import nl.relate4u.innovation.util.exception.Relate4uRuntimeException;
import nl.relate4u.innovation.web.registry.StaticBeanRegistry;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

@Entity
public class Asset extends FieldContainer implements Serializable, Comparable<Asset> {

    private static final long serialVersionUID = 2121452209650093877L;

    @LazyCollection(LazyCollectionOption.EXTRA)
    @MapKey(name = "localeCode")
    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Map<String, AssetFile> assetFiles = new HashMap<String, AssetFile>();

    @ManyToOne
    private AssetType assetType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AssetUsage assetUsage;

    private String mimeType;

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public AssetType getAssetType() {
        return assetType;
    }

    public void setAssetType(AssetType assetType) {
        this.assetType = assetType;
    }

    public AssetUsage getAssetUsage() {
        return assetUsage;
    }

    public void setAssetUsage(AssetUsage usage) {
        this.assetUsage = usage;
    }

    public Map<String, AssetFile> getAssetFiles() {
        return assetFiles;
    }

    public AssetFile getAssetFile(String localeCode) {
        return getAssetFile(localeCode, true);
    }

    public AssetFile getAssetFile(String localeCode, boolean fallback) {
        AssetFile file = assetFiles.get(localeCode);
        if (fallback && file == null) {
            // Try alternatives
            List<String> alternatives = FallbackLocale.getAlternativeChain(localeCode);
            // Add the default locale as an alternative
            alternatives.add(Constants.DEFAULT_LOCALE_CODE);
            // There are cases that use only a single language or a selection of
            // non-user/non-English languages,
            // in that case return the first language
            if (!assetFiles.isEmpty()) {
                alternatives.add(assetFiles.keySet().iterator().next());
            }
            Iterator<String> it = alternatives.iterator();
            while (it.hasNext() && file == null) {
                file = assetFiles.get(it.next());
            }
            if (file == null) {
                // explicitly return null here, it is expected to get null (instead of "") when
                // value is not present
                return null;
            }
        }
        return file;
    }

    public AssetFile getAssetFile() {
        String localeCode = StaticBeanRegistry.getInstance().getUserSettings().getLanguageCode();
        return getAssetFile(localeCode);
    }

    public void addAssetFile(String localeCode, AssetFile assetFile) {
        if (assetFiles.get(localeCode) != null) {
            throw new Relate4uRuntimeException("asset file already exists for locale " + localeCode);
        }
        if (assetFile.getLocaleCode() == null) {
            assetFile.setLocaleCode(localeCode);
        }
        this.assetFiles.put(localeCode, assetFile);
    }

    public void removeAssetFile(String localeCode) {
        if (localeCode == null) {
            return;
        }
        assetFiles.remove(localeCode);
    }

    public void removeAssetFile(AssetFile assetFile) {
        if (assetFile == null) {
            return;
        }
        if (assetFile.getLocaleCode() == null) {
            throw new Relate4uRuntimeException("cannot remove asset file without locale: " + assetFile);
        }
        removeAssetFile(assetFile.getLocaleCode());
    }

    public boolean hasAssetFile(String localeCode) {
        return localeCode != null && assetFiles.containsKey(localeCode);
    }

    public boolean hasAssetFile() {
        return assetFiles.size() > 0;
    }

    public boolean hasTranslations() {
        return assetFiles.size() > 1;
    }

    public Set<String> getAssetFileLocaleCodes() {
        return assetFiles.keySet();
    }

    @Transient
    public String getFileName() {
        AssetFile file = getAssetFile();
        return file != null ? file.getFileName() : null;
    }

    @Transient
    public Long getFileSize() {
        AssetFile file = getAssetFile();
        return file != null ? file.getFileSize() : null;
    }

    @Transient
    public int getImageWidth() {
        AssetFile file = getAssetFile();
        return file != null ? file.getImageWidth() : null;
    }

    @Transient
    public int getImageHeight() {
        AssetFile file = getAssetFile();
        return file != null ? file.getImageHeight() : null;
    }

    @Transient
    public boolean isImageTransparent() {
        AssetFile file = getAssetFile();
        return file != null ? file.isImageTransparent() : null;
    }

    @Transient
    public String getColorSpace() {
        AssetFile file = getAssetFile();
        return file != null ? file.getColorSpace() : null;
    }

    @Transient
    public Rectangle getImageDimension() {
        AssetFile file = getAssetFile();
        return file != null ? file.getImageDimension() : null;
    }

    @Transient
    public String getImageDimensionString() {
        AssetFile file = getAssetFile();
        return file != null ? file.getImageDimensionString() : null;
    }

    @Transient
    public String getExtension() {
        AssetFile file = getAssetFile();
        return file != null ? file.getExtension() : null;
    }

    @Transient
    public String getImageResolution() {
        AssetFile file = getAssetFile();
        return file != null ? file.getImageResolution() : null;
    }

    @Transient
    public String getFileSizeLabel() {
        AssetFile file = getAssetFile();
        return file != null ? file.getFileSizeLabel() : null;
    }

    @Transient
    public boolean isCmyk() {
        AssetFile file = getAssetFile();
        return file != null && file.isCmyk();
    }

    public boolean isImage() {
        return AssetMimeTypeGroup.IMAGE.equals(getMimeTypeGroup());
    }
    
    public boolean isVideo() {
        return AssetMimeTypeGroup.VIDEO.equals(getMimeTypeGroup());
    }

    public String getImageDescription() {
        AssetFile file = getAssetFile();
        return file != null ? file.getImageDescription() : null;
    }

    public boolean isSimilarMimeType(String mimeType) {
        AssetMimeTypeGroup type = getMimeTypeGroup();
        return type != null && type.hasMimeType(mimeType);
    }

    public String getIcon() {
        AssetMimeTypeGroup type = getMimeTypeGroup();
        return type != null ? type.getIcon() : "page_white.png";
    }

    public String getFileTypeLabel() {
        AssetMimeTypeGroup type = getMimeTypeGroup();
        return type != null ? type.getLabel() : LocalizationUtil.localize("asset.file-unknown.label", getClass());
    }

    private AssetMimeTypeGroup getMimeTypeGroup() {
        return AssetMimeTypeGroup.getMimeTypeGroup(mimeType);
    }

    @Override
    public String toString() {
        return "Asset: id=" + getId() + ", mimeType=" + mimeType + ", usage=" + assetUsage + ", type=[" + assetType + "]";
    }

    @Override
    public int compareTo(Asset o) {
        if (o == null) return -1;
        if (o.getCreatedDate() == null) return -1;
        if (getCreatedDate() == null) return 1;
        return getCreatedDate().compareTo(o.getCreatedDate());
    }

}
