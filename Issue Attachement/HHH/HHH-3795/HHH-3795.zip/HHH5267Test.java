package nl.relate4u.innovation.dao.hibernate;

import java.io.Serializable;

import nl.relate4u.innovation.base.InnovationSpringTestsBase;
import nl.relate4u.innovation.model.content.Asset;
import nl.relate4u.innovation.model.definition.FeedbackType;
import nl.relate4u.innovation.model.enumerations.AssetUsage;

public class HHH5267Test extends InnovationSpringTestsBase {

    public void testHHH5267() {
        FeedbackType type = new FeedbackType();
        type.assignDates();
        type.assignUuid();
        
        sessionFactory.getCurrentSession().save(type);
        sessionFactory.getCurrentSession().flush();
        sessionFactory.getCurrentSession().evict(type);
        sessionFactory.getCurrentSession().saveOrUpdate(type);
        
        type = (FeedbackType) sessionFactory.getCurrentSession().createQuery("from FeedbackType").list().get(0);
        sessionFactory.getCurrentSession().flush();
        sessionFactory.getCurrentSession().evict(type);
        sessionFactory.getCurrentSession().saveOrUpdate(type);
    }
    
    public void testHHH3795() {
        Asset icon = new Asset();
        icon.assignDates();
        icon.assignUuid();
        icon.setAssetUsage(AssetUsage.FEEDBACK_IMAGE);

        Serializable assetId = sessionFactory.getCurrentSession().save(icon);
        icon = (Asset) sessionFactory.getCurrentSession().load(Asset.class, assetId);
        
        FeedbackType type = new FeedbackType();
        type.assignDates();
        type.assignUuid();
        type.setIcon(icon);
        
        Serializable fbId = sessionFactory.getCurrentSession().save(type);
        
        /* 1) Within a single session (i.e. a transient object):

            Load parent
            Delete child
            saveOrUpdate()
            Result: Child is deleted from DB, a DELETE statement was issued
        */
        type = (FeedbackType) 
                sessionFactory.getCurrentSession().createQuery("from FeedbackType where id = " + fbId).uniqueResult();
        assertNotNull(type.getIcon());
        type.setIcon(null);
        sessionFactory.getCurrentSession().saveOrUpdate(type);
        sessionFactory.getCurrentSession().flush();
        type = (FeedbackType) 
                sessionFactory.getCurrentSession().createQuery("from FeedbackType where id = " + fbId).uniqueResult();
        assertNull(type.getIcon());
        icon = (Asset) 
                sessionFactory.getCurrentSession().createQuery("from Asset where id = " + assetId).uniqueResult();
        assertNull(icon);

        // Add data again
        icon = new Asset();
        icon.assignDates();
        icon.assignUuid();
        icon.setAssetUsage(AssetUsage.FEEDBACK_IMAGE);

        assetId = sessionFactory.getCurrentSession().save(icon);
        icon = (Asset) sessionFactory.getCurrentSession().load(Asset.class, assetId);

        type.setIcon(icon);
        
        sessionFactory.getCurrentSession().saveOrUpdate(type);
        sessionFactory.getCurrentSession().flush();
        
        /* 2) Across multiple session (i.e. a detached object):

            Have parent with valid ID, but empty list/set of children
            saveOrUpdate()
            Result: Child is not deleted from DB, an UPDATE statement is issued which sets FK of child to 'null'
        */
        type = (FeedbackType) 
                sessionFactory.getCurrentSession().createQuery("from FeedbackType where id = " + fbId).uniqueResult();
        sessionFactory.getCurrentSession().evict(type);
        assertNotNull(type.getIcon());
        type.setIcon(null);
        sessionFactory.getCurrentSession().saveOrUpdate(type);
        sessionFactory.getCurrentSession().flush();
        type = (FeedbackType) 
                sessionFactory.getCurrentSession().createQuery("from FeedbackType where id = " + fbId).uniqueResult();
        assertNull(type.getIcon());
        icon = (Asset) 
                sessionFactory.getCurrentSession().createQuery("from Asset where id = " + assetId).uniqueResult();
        // With our fix, this should also work
        assertNull(icon);
    }
}
