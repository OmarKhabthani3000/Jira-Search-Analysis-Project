package com.medq.test;

import javax.transaction.UserTransaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.jboss.cache.transaction.DummyTransactionManager;
import org.jboss.cache.transaction.DummyUserTransaction;

public class TestHibernate {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		SessionFactory factory = new AnnotationConfiguration().configure().buildSessionFactory();
		try{
			Session session = factory.openSession();
			try{
				// Use dummy transaction stuff provided by JBoss Cache for this test code
				UserTransaction tx= new DummyUserTransaction(DummyTransactionManager.getInstance());
				
				tx.begin();
				A a = new A();
				a.id = 1;
				
				session.persist(a);
				session.flush(); 
				session.clear();
				tx.commit();
				
				tx.begin();
				
				session.get(A.class, 1);
				session.createSQLQuery("update A set s = 'blah'").executeUpdate();
				
				tx.commit();
				
			} catch (Exception e){
				System.err.println("Test failed!");
				e.printStackTrace();
			}
			finally{
				session.close();
			}
			
		} finally{
			factory.close();
		}
	}

}
