package com.medq.test;

import java.util.Properties;

import javax.transaction.TransactionManager;

import org.hibernate.HibernateException;
import org.hibernate.transaction.TransactionManagerLookup;
import org.jboss.cache.transaction.DummyTransactionManager;

public class DummyTransactionManagerLookup implements TransactionManagerLookup {

	public TransactionManager getTransactionManager(Properties arg0)
			throws HibernateException {
		
		return DummyTransactionManager.getInstance();
		
	}

	public String getUserTransactionName() {
		return "UserTransaction";
	}

}
