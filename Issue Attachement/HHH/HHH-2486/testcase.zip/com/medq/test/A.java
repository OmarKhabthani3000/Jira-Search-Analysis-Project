package com.medq.test;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Cache(usage=CacheConcurrencyStrategy.TRANSACTIONAL)
public class A {
	
	@Id
	Integer id;
	
	String s;
	
	@OneToMany(fetch=FetchType.EAGER, mappedBy="a", cascade=CascadeType.ALL)
	@Cache(usage=CacheConcurrencyStrategy.TRANSACTIONAL)
	List<B> bs = new LinkedList<B>();

}
