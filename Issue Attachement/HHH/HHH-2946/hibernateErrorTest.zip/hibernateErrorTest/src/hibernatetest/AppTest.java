package hibernatetest;

import java.util.HashMap;
import java.util.Map;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;


/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    private static ApplicationContext ctx;

	/**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
    	ctx = new FileSystemXmlApplicationContext("conf/applicationContext.xml");

		return new TestSuite( AppTest.class );
    }

    /**
     * Rigorous Test :-)
     */
    public void testApp()
    {
    	TestEntityDAO dao = (TestEntityDAO) ctx.getBean("testEntityDAO");
    	Map<String,String> map = new HashMap<String, String>();
    	map.put("Hello", "World");
    	TestEntity entity = new TestEntity("HelloWorld",map);
    	dao.save(entity);   
    }
}
