package hibernatetest;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class TestEntityDAO extends HibernateDaoSupport{

	public void save(TestEntity entity) {
		getHibernateTemplate().save(entity);
	}

}
