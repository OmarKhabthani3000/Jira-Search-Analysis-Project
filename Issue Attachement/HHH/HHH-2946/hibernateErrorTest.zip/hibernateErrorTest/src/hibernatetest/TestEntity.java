package hibernatetest;

import java.util.Map;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.CollectionOfElements;

@Entity
public class TestEntity {
	private Long id;
	private String testProperty;
	private Map<String, String> settings;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO) 
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public TestEntity(String testProperty, Map<String, String> settings) {
		super();
		this.testProperty = testProperty;
		this.settings = settings;
	}
	public String getTestProperty() {
		return testProperty;
	}
	public void setTestProperty(String testProperty) {
		this.testProperty = testProperty;
	}
	
	@CollectionOfElements
	@AttributeOverride(name="element.value", column=@Column(columnDefinition="TEXT")) 
	public Map<String, String> getSettings() {
		return settings;
	}
	public void setSettings(Map<String, String> settings) {
		this.settings = settings;
	}
	
}
