CREATE TABLE public.table_test (
                                   id serial4 NOT NULL,
                                   "type" varchar NOT NULL,
                                   property jsonb NULL,
                                   CONSTRAINT pk PRIMARY KEY (id)
);

INSERT INTO public.table_test
(id, discriminator, property)
VALUES(
          '1',
          'A',
          '{
              "propertyA": "valueA"
          }'::jsonb);

INSERT INTO public.table_test
(id, discriminator, property)
VALUES(
          '2',
          'B',
          '{
              "propertyB": "valueB"
          }'::jsonb);
;