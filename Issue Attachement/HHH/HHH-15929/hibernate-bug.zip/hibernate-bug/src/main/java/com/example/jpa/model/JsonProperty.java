package com.example.jpa.model;

import java.io.Serializable;

//@JsonTypeInfo(
//        use = JsonTypeInfo.Id.NAME,
//        include = JsonTypeInfo.As.PROPERTY,
//        property = "type"
//)
//@JsonSubTypes({
//        @JsonSubTypes.Type(
//                name = "A",
//                value = EntityA.PropertyTypeA.class
//        ),
//        @JsonSubTypes.Type(
//                name = "B",
//                value = EntityB.PropertyTypeB.class
//        ),
//})
public abstract class JsonProperty implements Serializable{
//    @JsonTypeInfo(use = JsonTypeInfo.Id.NAME)
//    @JsonIgnore
//    public abstract String getType();
}
