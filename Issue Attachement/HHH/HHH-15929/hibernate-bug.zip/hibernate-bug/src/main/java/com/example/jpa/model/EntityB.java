package com.example.jpa.model;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@DiscriminatorValue("B")
public class EntityB extends CommonEntity {
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "property", columnDefinition = "jsonb")
    private PropertyTypeB property;

    record PropertyTypeB(String propertyB){}
}
