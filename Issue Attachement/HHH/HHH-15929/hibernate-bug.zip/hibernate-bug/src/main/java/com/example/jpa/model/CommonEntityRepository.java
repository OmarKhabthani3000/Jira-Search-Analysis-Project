package com.example.jpa.model;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CommonEntityRepository extends JpaRepository<CommonEntity, Long> {
}
