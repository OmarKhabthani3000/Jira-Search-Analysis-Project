package com.example.jpa;

import com.example.jpa.model.CommonEntity;
import com.example.jpa.model.CommonEntityRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@EnableTransactionManagement(proxyTargetClass = true)
class JpaApplicationTests {

    @Autowired
    CommonEntityRepository repository;

    @Test
    void findEntity() {
        assertNotNull(repository.findById(1L).map(CommonEntity::getProperty));
        assertNotNull(repository.findById(2L).map(CommonEntity::getProperty));
    }
}



