package test.bug;

import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;

@Embeddable
public class TestEmbedded {
	@ManyToOne
	private TestEntity2 ref;

	public TestEntity2 getRef() {
		return ref;
	}

	public void setRef(TestEntity2 ref) {
		this.ref = ref;
	}

}
