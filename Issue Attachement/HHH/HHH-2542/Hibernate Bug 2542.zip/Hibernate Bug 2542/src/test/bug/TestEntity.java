package test.bug;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
public class TestEntity {
	@Id
	@Column(length = 36)
	private String id;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@Fetch(FetchMode.SUBSELECT)
	private Set<TestCascaded> cascaded;

	public String getId() {
		return id;
	}

	public TestEntity() {
		id = java.util.UUID.randomUUID().toString();
	}

	public Set<TestCascaded> getCascaded() {
		if (cascaded == null)
			cascaded = new HashSet<TestCascaded>();
		return cascaded;
	}

	public void setCascaded(Set<TestCascaded> cascaded) {
		this.cascaded = cascaded;
	}

}
