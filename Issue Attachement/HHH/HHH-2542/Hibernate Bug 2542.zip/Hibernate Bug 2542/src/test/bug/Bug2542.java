package test.bug;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

public class Bug2542 {
	@SuppressWarnings("unused")
	private void reproduceBug() {
		try {
			EntityManagerFactory emf = javax.persistence.Persistence
					.createEntityManagerFactory("BUG2542");
			EntityManager em = emf.createEntityManager();

			if (em != null) {
				TestEntity l_tst = new TestEntity();
				TestCascaded l_csd = new TestCascaded();

				EntityTransaction et = em.getTransaction();

				et.begin();
				em.persist(l_tst);
				et.commit();
				em.close();

				l_tst.getCascaded().add(l_csd);

				em = emf.createEntityManager();
				et = em.getTransaction();
				et.begin();
				em.merge(l_tst);
				et.commit();
				em.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		Bug2542 test = new Bug2542();

		test.reproduceBug();
	}
}
