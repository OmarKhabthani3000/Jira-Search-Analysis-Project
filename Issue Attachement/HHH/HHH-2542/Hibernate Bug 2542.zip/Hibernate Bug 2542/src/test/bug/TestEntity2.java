package test.bug;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class TestEntity2 {
	@Id
	@Column(length = 36)
	private String id;

	public String getId() {
		return id;
	}

	public TestEntity2() {
		id = java.util.UUID.randomUUID().toString();
	}

}
