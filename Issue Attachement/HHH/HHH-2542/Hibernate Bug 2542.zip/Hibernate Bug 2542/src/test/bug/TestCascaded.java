package test.bug;

import javax.persistence.AssociationOverride;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

@Entity
public class TestCascaded {
	@Id
	@Column(length = 36)
	private String id;

	@Embedded
	@AssociationOverride(name = "ref", joinColumns = @JoinColumn(name = "REF_ID", referencedColumnName = "ID", nullable = true))
	private TestEmbedded embedded;

	public String getId() {
		return id;
	}

	public TestCascaded() {
		id = java.util.UUID.randomUUID().toString();
	}

	public TestEmbedded getEmbedded() {
		return embedded;
	}

	public void setEmbedded(TestEmbedded embedded) {
		this.embedded = embedded;
	}

}
