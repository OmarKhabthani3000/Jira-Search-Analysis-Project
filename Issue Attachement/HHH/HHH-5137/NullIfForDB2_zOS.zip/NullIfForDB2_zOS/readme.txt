Configure DB2 with DECIMAL POINT IS = ','
see section: DECIMAL POINT IS field (DECIMAL DECP value) at
http://publib.boulder.ibm.com/infocenter/dzichelp/v2r2/index.jsp?topic=/com.ibm.db29.doc.inst/db2z_dsntipf.htm

#db2 driver available in DB2 install (db2jcc.jar and db2jcc_license_cu.jar)

#jar to put in classpath
hibernate-annotations-3.4.0.jar
hibernate-commons-annotations-3.1.0.jar
hibernate-core-3.3.2.GA.jar
hibernate-entitymanager-3.4.0.jar
hibernate-validator-3.1.0.GA.jar
dom4j-1.6.1.jar
antlr-2.7.6.jar
jpa-1.0.jar
slf4j-api-1.5.8.jar
slf4j-log4j12-1.5.8.jar
log4j-1.2.14.jar
javassist-3.9.0.GA.jar
commons-collections-3.1.jar
jta-1.1.jar

#Use case to reproduce bug: execute Main class
