package com.entities;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToOne;

@Entity
public class SubFoo1 extends Foo
{
   @OneToOne(fetch = FetchType.LAZY)
   private Bar myBar;
}
