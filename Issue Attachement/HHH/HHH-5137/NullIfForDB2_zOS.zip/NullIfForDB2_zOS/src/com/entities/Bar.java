package com.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Bar
{
   @Id
   private int id;
}
