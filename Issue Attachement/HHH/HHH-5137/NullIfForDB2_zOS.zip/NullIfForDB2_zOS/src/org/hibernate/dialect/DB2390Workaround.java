package org.hibernate.dialect;

import java.sql.Types;

public class DB2390Workaround extends DB2390Dialect
{
   public String getSelectClauseNullString(int sqlType)
   {
      String literal;
      switch (sqlType)
      {
         case Types.VARCHAR:
         case Types.CHAR:
            literal = "'x'";
            break;
         case Types.DATE:
            literal = "'2000-1-1'";
            break;
         case Types.TIMESTAMP:
            literal = "'2000-1-1 00:00:00'";
            break;
         case Types.TIME:
            literal = "'00:00:00'";
            break;
         default:
            literal = "0";
      }
      // prevents DB2 interpretation of arguments separated by ',' as a decimal
      // number (because DECIMAL POINT IS is set ',')
      return "nullif(" + literal + ", " + literal + ')';
   }
}
