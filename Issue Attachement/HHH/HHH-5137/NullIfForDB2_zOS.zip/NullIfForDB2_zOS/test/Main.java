import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.entities.Foo;

public class Main
{
   public static void main(String[] args)
   {
      EntityManagerFactory EMF = Persistence.createEntityManagerFactory("jpa");

      EntityManager em = EMF.createEntityManager();

      em.find(Foo.class, 1);

      em.close();
      EMF.close();
   }
}
