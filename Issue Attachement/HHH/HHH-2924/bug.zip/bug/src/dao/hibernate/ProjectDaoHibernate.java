package dao.hibernate;

import dao.ProjectDao;

import model.Project;

public class ProjectDaoHibernate extends ReadWriteDaoHibernate implements ProjectDao {

	public ProjectDaoHibernate() {
		super(Project.class);
	}

	public Long create(Project _project) {
		return((Long)super.create(_project));
	}

	public Project retrieve(Long _id) {
		return((Project)super.retrieve(_id));
	}

	public void update(Project _project) {
		super.update(_project);
	}

	public void delete(Long _id) {
		super.delete(_id);
	}

};
