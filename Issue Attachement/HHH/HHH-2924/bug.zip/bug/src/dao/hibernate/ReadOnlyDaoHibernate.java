package dao.hibernate;

import dao.ReadOnlyDao;

import model.BaseObject;


import java.io.Serializable;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.orm.ObjectRetrievalFailureException;

abstract class ReadOnlyDaoHibernate extends HibernateDaoSupport implements ReadOnlyDao {

	private final static Log log=LogFactory.getLog(ReadOnlyDaoHibernate.class);

	private Class type;

	ReadOnlyDaoHibernate(Class _type) {
		type=_type;
	}

	protected BaseObject retrieve(Serializable _id) {
		BaseObject baseObject=(BaseObject)getHibernateTemplate().get(type,_id);
		if (baseObject==null) {
			throw(new ObjectRetrievalFailureException(type,_id));
		}
		return(baseObject);
	}

	public List retrieveAll() {
		DetachedCriteria dc=DetachedCriteria.forClass(type);
		dc.addOrder(Order.asc("id"));
		return(getHibernateTemplate().findByCriteria(dc));
	}

	public List retrieveAll(int _startIndex,int _count) {
		DetachedCriteria dc=DetachedCriteria.forClass(type);
		dc.addOrder(Order.asc("id"));
		return(getHibernateTemplate().findByCriteria(dc,_startIndex,_count));
	}

	public int getCount() {
		DetachedCriteria dc=DetachedCriteria.forClass(type);
		dc.setProjection(Projections.rowCount());
		List results=getHibernateTemplate().findByCriteria(dc);
		return(((Integer)results.get(0)).intValue());
	}

};
