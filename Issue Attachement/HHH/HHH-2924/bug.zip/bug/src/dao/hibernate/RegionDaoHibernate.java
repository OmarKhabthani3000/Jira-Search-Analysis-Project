package dao.hibernate;

import dao.RegionDao;

import model.Region;

public class RegionDaoHibernate extends ReadWriteDaoHibernate implements RegionDao {

	public RegionDaoHibernate() {
		super(Region.class);
	}

	public Long create(Region _region) {
		return((Long)super.create(_region));
	}

	public Region retrieve(Long _id) {
		return((Region)super.retrieve(_id));
	}

	public void update(Region _region) {
		super.update(_region);
	}

	public void delete(Long _id) {
		super.delete(_id);
	}

};
