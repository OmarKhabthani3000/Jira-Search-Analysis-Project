package dao.hibernate;

import model.BaseObject;

import java.io.Serializable;

import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.hibernate.Session;
import org.hibernate.HibernateException;

import org.springframework.orm.hibernate3.HibernateCallback;

abstract class ReadWriteDaoHibernate extends ReadOnlyDaoHibernate {

	private final static Log log=LogFactory.getLog(ReadWriteDaoHibernate.class);

	ReadWriteDaoHibernate(Class _type) {
		super(_type);
	}

	protected Serializable create(BaseObject _object) {
		return(getHibernateTemplate().save(_object));
	}

	protected void create(final BaseObject _object,final Serializable _id) {
		//getHibernateTemplate().save(_object,_id);
		getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(Session _session) throws HibernateException,SQLException {
				org.hibernate.classic.Session session=(org.hibernate.classic.Session)_session;
				session.save(_object,_id);
				return(_object);
			}
		},true);
	}

	protected void update(BaseObject _object) {
		getHibernateTemplate().update(_object);
		getHibernateTemplate().flush();
	}

	protected void delete(BaseObject _object) {
		getHibernateTemplate().delete(_object);
	}

	protected void delete(Serializable _id) {
		delete(retrieve(_id));
	}

};
