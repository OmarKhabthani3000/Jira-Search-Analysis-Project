package dao.hibernate;

import dao.ClientDao;

import model.Client;

public class ClientDaoHibernate extends ReadWriteDaoHibernate implements ClientDao {

	public ClientDaoHibernate() {
		super(Client.class);
	}

	public Long create(Client _client) {
		return((Long)super.create(_client));
	}

	public Client retrieve(Long _id) {
		return((Client)super.retrieve(_id));
	}

	public void update(Client _client) {
		super.update(_client);
	}

	public void delete(Long _id) {
		super.delete(_id);
	}

};
