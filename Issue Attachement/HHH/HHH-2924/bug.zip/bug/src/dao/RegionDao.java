package dao;

import model.Region;

public interface RegionDao extends ReadOnlyDao {

	// basic CRUD operations
	public Long create(Region _region);

	public Region retrieve(Long _id);

	public void update(Region _region);

	public void delete(Long _id);

};
