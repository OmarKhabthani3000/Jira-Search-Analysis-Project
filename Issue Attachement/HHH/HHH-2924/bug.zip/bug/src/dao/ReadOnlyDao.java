package dao;

import java.util.List;

public interface ReadOnlyDao {

	List retrieveAll();

	List retrieveAll(int _startIndex,int _count);

	int getCount();

};
