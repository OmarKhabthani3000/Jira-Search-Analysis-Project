package dao;

import model.Project;

public interface ProjectDao extends ReadOnlyDao {

	// basic CRUD operations
	public Long create(Project _project);

	public Project retrieve(Long _id);

	public void update(Project _project);

	public void delete(Long _id);

};
