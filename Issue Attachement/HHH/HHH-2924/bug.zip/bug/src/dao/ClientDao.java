package dao;

import model.Client;

public interface ClientDao extends ReadOnlyDao {

	// basic CRUD operations
	public Long create(Client _client);

	public Client retrieve(Long _id);

	public void update(Client _client);

	public void delete(Long _id);

};
