package model;

/**
 * @hibernate.class
 *   table="bug_project"
 */
public class Project extends BaseObject {

	protected Long id;

	protected String name;

	protected transient Client client;

	protected transient Region region;

	public Project() {
		// empty constructor
	}

	public Project(String _name,Client _client,Region _region) {
		name=_name;
		client=_client;
		region=_region;
	}

	/**
	 * @hibernate.id
	 *   generator-class="sequence"
	 * @hibernate.generator-param
	 *   name="sequence"
	 *   value="bug_project_sequence"
	 */
	public Long getId() {
		return(id);
	}

	public void setId(Long _id) {
		id=_id;
	}

	/**
	 * @hibernate.property
	 *   column="name"
	 *   not-null="true"
	 */
	public String getName() {
		return(name);
	}

	public void setName(String _name) {
		name=_name;
	}

	/**
	 * @hibernate.many-to-one
	 *   column="client_id"
	 *   not-null="true"
	 *   outer-join="true"
	 */
	public Client getClient() {
		return(client);
	}

	public void setClient(Client _client) {
		client=_client;
	}

	/**
	 * @hibernate.many-to-one
	 *   column="region_id"
	 *   not-null="true"
	 */
	public Region getRegion() {
		return(region);
	}

	public void setRegion(Region _region) {
		region=_region;
	}

};
