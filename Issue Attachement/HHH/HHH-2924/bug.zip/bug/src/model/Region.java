package model;

import java.util.HashSet;
import java.util.Set;

/**
 * @hibernate.class
 *   table="bug_region"
 */
public class Region extends BaseObject {

	protected Long id;

	protected String name;

	protected transient Set projects=new HashSet();

	public Region() {
		// empty constructor
	}

	public Region(String _name) {
		name=_name;
	}

	/**
	 * @hibernate.id
	 *   generator-class="sequence"
	 * @hibernate.generator-param
	 *   name="sequence"
	 *   value="bug_region_sequence"
	 */
	public Long getId() {
		return(id);
	}

	public void setId(Long _id) {
		id=_id;
	}

	/**
	 * @hibernate.property
	 *   column="name"
	 *   not-null="true"
	 */
	public String getName() {
		return(name);
	}

	public void setName(String _name) {
		name=_name;
	}

	/**
	 * @hibernate.set
	 *   lazy="true"
	 *   where="client.active=TRUE"
	 * @hibernate.collection-key
	 *   column="region_id"
	 * @hibernate.collection-one-to-many
	 *   class="model.Project"
	 */
	public Set getProjects() {
		return(projects);
	}

	public void setProjects(Set _projects) {
		projects=_projects;
	}

};
