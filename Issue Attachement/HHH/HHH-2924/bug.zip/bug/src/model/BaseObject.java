package model;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public abstract class BaseObject implements Serializable {

	private final static Log log=LogFactory.getLog(BaseObject.class);

	abstract public Long getId();

	abstract public void setId(Long _id);

	/**
	 * Creates a String using reflection that contains all non-transient
	 * member variables
	 */
	public String toString() {
		return(ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE));
	}

	/**
	 * Compares two objects by checking that their non-transient member variables
	 * are the same
	 */
	public boolean equals(Object _object) {
		return(EqualsBuilder.reflectionEquals(this,_object));
	}

	/**
	 * Generates a hash code for this object using only the non-transient member
	 * variables
	 */
	public int hashCode() {
		return(HashCodeBuilder.reflectionHashCode(this));
	}

};
