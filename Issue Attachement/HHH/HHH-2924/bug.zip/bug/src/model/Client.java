package model;

import java.util.HashSet;
import java.util.Set;

/**
 * @hibernate.class
 *   table="bug_client"
 */
public class Client extends BaseObject {

	protected Long id;

	protected String name;

	protected Boolean active;

	protected transient Set projects=new HashSet();

	public Client() {
		active=Boolean.TRUE;
	}

	public Client(String _name) {
		this();
		name=_name;
	}

	/**
	 * @hibernate.id
	 *   generator-class="sequence"
	 * @hibernate.generator-param
	 *   name="sequence"
	 *   value="bug_client_sequence"
	 */
	public Long getId() {
		return(id);
	}

	public void setId(Long _id) {
		id=_id;
	}

	/**
	 * @hibernate.property
	 *   column="name"
	 *   not-null="true"
	 */
	public String getName() {
		return(name);
	}

	public void setName(String _name) {
		name=_name;
	}

	/**
	 * @hibernate.property
	 *   column="active"
	 *   not-null="true"
	 */
	public Boolean getActive() {
		return(active);
	}

	public void setActive(Boolean _active) {
		active=_active;
	}

	/**
	 * @hibernate.set
	 *   lazy="true"
	 * @hibernate.collection-key
	 *   column="client_id"
	 * @hibernate.collection-one-to-many
	 *   class="model.Project"
	 */
	public Set getProjects() {
		return(projects);
	}

	public void setProjects(Set _projects) {
		projects=_projects;
	}

};
