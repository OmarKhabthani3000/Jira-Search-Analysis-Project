package ref;

import dao.ClientDao;
import dao.ProjectDao;
import dao.RegionDao;

import model.Client;
import model.Project;
import model.Region;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.orm.hibernate3.SessionHolder;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
//import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.transaction.support.TransactionTemplate;

public class Initialize {

	public static void main(String[] _args) {

		// load up the configuration files
		String[] path={
			"/applicationContext-resources.xml",
			"/applicationContext-domain.xml"
		};
		final ApplicationContext ctx=new ClassPathXmlApplicationContext(path);

		// create a transaction template
		SessionFactory sessionFactory=(SessionFactory)ctx.getBean("sessionFactory");
		PlatformTransactionManager ptm=new HibernateTransactionManager(sessionFactory);
		TransactionTemplate tt=new TransactionTemplate(ptm);

		final ClientDao clientDao=(ClientDao)ctx.getBean("clientDao");
		final ProjectDao projectDao=(ProjectDao)ctx.getBean("projectDao");
		final RegionDao regionDao=(RegionDao)ctx.getBean("regionDao");

		// create some data
		tt.execute(new TransactionCallbackWithoutResult() {
			protected void doInTransactionWithoutResult(TransactionStatus _status) {
				Client abcClient=new Client("ABC");
				clientDao.create(abcClient);

				Client xyzClient=new Client("XYZ");
				clientDao.create(xyzClient);

				Region northRegion=new Region("North");
				regionDao.create(northRegion);

				Project roadProject=new Project("road",abcClient,northRegion);
				projectDao.create(roadProject);

				Project bridgeProject=new Project("bridge",xyzClient,northRegion);
				projectDao.create(bridgeProject);
			}
		});

		tt.execute(new TransactionCallbackWithoutResult() {
			protected void doInTransactionWithoutResult(TransactionStatus _status) {
				Region northRegion=regionDao.retrieve(new Long(1));

				/* This generates the following incorrect SQL statement:
				 *
				 * select projects0_.region_id as region4_2_, projects0_.id as id2_, projects0_.id as id0_1_, projects0_.name as name0_1_, projects0_.client_id as client3_0_1_, projects0_.region_id as region4_0_1_, client1_.id as id1_0_, client1_.name as name1_0_, client1_.active as active1_0_, client1_.user_id as user4_1_0_ from bug_project projects0_ inner join bug_client client1_ on projects0_.client_id=client1_.id where  (client.active=projects0_.TRUE)  and projects0_.region_id=?
				 *
				 * Which demonstrates two bugs:
				 *
				 *  1) "projects0_.TRUE" should simply be "TRUE"
				 *
				 *  2) "client.active" should be "client1_.active"
				 */
				System.out.println("region projects.size="+northRegion.getProjects().size());
			}
		});
	}

};
