//$Id$
package org.hibernate.test.naturalid;

/**
 * @author Alex Burgel
 */
public class Child {
	
	private Long id;
    private Parent parent;
	private String name;
	
	Child() {}

	public Child(String name, Parent parent) {
		this.name = name;
        this.parent = parent;
	}
	
}
