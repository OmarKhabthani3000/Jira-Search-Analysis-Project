//$Id$
package org.hibernate.test.naturalid;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Alex Burgel
 */
public class Parent {
	
	private Long id;
	private String name;
	private List children = new ArrayList();

	Parent() {}

	public Parent(String name) {
		this.name = name;
	}

    public void setName(String name) {
        this.name = name;
    }

    public List getChildren() {
        return children;
    }

    public void setChildren(List children) {
        this.children = children;
    }

    
}
