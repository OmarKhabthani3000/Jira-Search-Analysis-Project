import org.codehaus.jackson.map.ObjectMapper;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class TestSet {
    private Configuration config;

    private SessionFactory sessionFactory;
    private ObjectMapper mapper = new ObjectMapper();

    @Before
    public void setup() {
        config = new Configuration();

        // add your entities here e.g.:
        config.addAnnotatedClass(Department.class);
        config.addAnnotatedClass(Employee.class);

        config.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        config.setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:myunittests");
        config.setProperty("hibernate.connection.username", "sa");
        config.setProperty("hibernate.connection.password", "");
        config.setProperty("hibernate.connection.pool_size", "1");
        //config.setProperty("hibernate.current_session_context_class", "thread");
        config.setProperty("hibernate.hbm2ddl.auto", "update");
        config.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        config.setProperty("hibernate.show_sql", "true");

        sessionFactory = config.buildSessionFactory();
    }

    // perform your tests using standard junit test cases
    @Test
    public void testCreateAndUpdate() throws Exception {

        // POST from client
        String jsonFromClient = "{\"employees\":[{}]}";
        Department department = mapper.readValue(jsonFromClient, Department.class);

        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.persist(department);
        tx.commit();

        String jsonToClient = mapper.writeValueAsString(department);
        System.out.println(jsonToClient);   // {"id":1,"version":0,"employees":[{"id":1,"version":0}]}

        // PUT from client, but nothing has actually changed
        jsonFromClient = jsonToClient;
        Department department2 = mapper.readValue(jsonFromClient, Department.class);

        // new session emulates the client updating the Department
        session = sessionFactory.openSession();
        tx = session.beginTransaction();
        department2 = (Department) session.merge(department2);
        tx.commit();

        jsonToClient = mapper.writeValueAsString(department2);
        System.out.println(jsonToClient);  // {"id":1,"version":1,"employees":[{"id":1,"version":0}]}

        Assert.assertEquals("versions should be the same?", department.getVersion(), department2.getVersion());

    }

}