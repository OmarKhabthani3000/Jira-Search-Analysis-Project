package testPZ;

import java.io.Serializable;

public class Holder implements Serializable{
   private static final long serialVersionUID = 1L;
   String oid;
   Container1 con1;
   
   public Holder(){
      
   }
   
   public Holder(String _oid){
      oid = _oid;
   }

   public Container1 getCon1() {
      return con1;
   }

   public void setCon1(Container1 con1) {
      this.con1 = con1;
   }

   public String getOid() {
      return oid;
   }

   public void setOid(String oid) {
      this.oid = oid;
   }

public boolean equals(Object obj) {
	return obj instanceof Holder && oid == ((Holder)obj).getOid();
}

public int hashCode() {
	return oid.hashCode();
}
   
   
}