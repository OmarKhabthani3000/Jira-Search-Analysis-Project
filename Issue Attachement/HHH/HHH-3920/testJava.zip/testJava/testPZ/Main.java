package testPZ;

import java.util.List;

import org.hibernate.*;
import org.hibernate.cfg.*;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class Main {

	public static void main(String[] args) {
		Configuration cfg;
		SessionFactory sf;
		Session s = null;
		
		try {
			cfg = new Configuration();
			cfg.configure();
			cfg.addFile("testJava/testPZ/mapping.xml");
			
			// Create schema
			SchemaExport se = new SchemaExport(cfg);
			se.create(false, true);
			
			// Create objects
			Holder h = new Holder("1");
			h.con1 = new Container1();
			Container2 con2 = new Container2("2");
			h.con1.listCon2.add(con2);
			
			// Store objects
			sf = cfg.buildSessionFactory();
			s = sf.openSession();
			Transaction t = s.beginTransaction();
			s.saveOrUpdate(con2);
			s.saveOrUpdate(h);
			t.commit();
			
			// Retrieve objects
			Query q = s.createQuery("select h.con1 from testPZ.Holder h");
			List listCon1 = q.list();
			Container1 con1 = (Container1)listCon1.iterator().next();
			List listCon2 = con1.getListCon2();
			
			System.out.println(listCon2);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (s != null)
				s.close();
		}
	}

}
