package testPZ;

import java.io.Serializable;
import java.util.*;

public class Container1 implements Serializable{
   private static final long serialVersionUID = 1L;
   List listCon2 = new ArrayList();
   
   public Container1(){
      
   }
   
   public List getListCon2() {
      return listCon2;
   }

   public void setListCon2(List listCon2) {
      this.listCon2 = listCon2;
   }
   
   public boolean equals(Object obj) {
	   if (!(obj instanceof Container1))
		   return false;
	   Container1 con1 = (Container1) obj;
	   if (listCon2 == null && con1.listCon2 == null)
		   return true;
	   if ((listCon2 == null && con1.listCon2 != null) || (listCon2 != null && con1.listCon2 != null) || (listCon2.size() != con1.listCon2.size()))
		   return false;
	   Iterator i = listCon2.iterator(), j = con1.listCon2.iterator();
	   
	   for(; i.hasNext() && j.hasNext();){
		   Container2 con2a = (Container2)i.next(), con2b = (Container2)j.next();
		   if (!con2a.equals(con2b))
			   return false;
	   }
	   
	   return true;
	}

}