package testPZ;

import java.io.Serializable;

public class Container2 implements Serializable{
   private static final long serialVersionUID = 1L;
   String oid;
   
   public Container2(){
      
   }
   
   public Container2(String _oid){
      oid = _oid;
   }

   public String getOid() {
      return oid;
   }

   public void setOid(String oid) {
      this.oid = oid;
   }
   
   public boolean equals(Object obj) {
	   return obj instanceof Container2 && oid == ((Container2)obj).getOid();
	}

	public int hashCode() {
		return oid.hashCode();
	}
}