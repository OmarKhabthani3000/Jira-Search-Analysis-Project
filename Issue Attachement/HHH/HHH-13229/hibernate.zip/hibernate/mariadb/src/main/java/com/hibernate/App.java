package com.hibernate;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class App {

    public static void main (String...args){

        Session session = HibernateUtil.getSession();
        Transaction tx = session.beginTransaction();

        Book book = new Book();
        book.setTitle("My Book");
       
        session.save(book);
        tx.commit();

        session.close();
        HibernateUtil.shutdown();
    }
}
