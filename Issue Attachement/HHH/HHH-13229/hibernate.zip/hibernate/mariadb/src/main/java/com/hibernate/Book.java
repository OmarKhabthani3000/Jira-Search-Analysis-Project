package com.hibernate;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "TBL_BOOK")
public class Book implements Serializable {

	private static final long serialVersionUID = -6764974509809614953L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(
            name = "hibernate_sequence",
            allocationSize = 10
        )
    @Column(name = "ID")
    private Integer id;
    @Column(name = "TITLE")
    private String title;
    

    public Book() {
    }

    public Book(String title) {
        this.title = title;
        
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", title='" + title + '\'' +
                '}';
    }
}
