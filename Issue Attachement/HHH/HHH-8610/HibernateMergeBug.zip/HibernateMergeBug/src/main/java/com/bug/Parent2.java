package com.bug;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Parent2 implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	private Integer id;

	private String attr;

	@OneToMany(cascade = { CascadeType.MERGE, CascadeType.PERSIST }, mappedBy = "parent", orphanRemoval = true)
	private Set<Child2> children;
	
	public Parent2(Integer id, String attr) {
		this.id = id;
		this.attr = attr;
	}
	
	public Parent2() {
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Parent2 other = (Parent2) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAttr() {
		return attr;
	}

	public void setAttr(String attr) {
		this.attr = attr;
	}

	public Set<Child2> getChildren() {
		return children;
	}

	public void setChildren(Set<Child2> children) {
		this.children = children;
	}

}
