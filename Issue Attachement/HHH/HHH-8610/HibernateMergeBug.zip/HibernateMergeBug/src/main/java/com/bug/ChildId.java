package com.bug;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

@Embeddable
public class ChildId implements Serializable{
	private static final long serialVersionUID = 1L;

	private Integer id;

	@ManyToOne(fetch=FetchType.LAZY)
	private Parent1 parent;

	public ChildId() {
		super();
	}

	public ChildId(Integer id, Parent1 parent) {
		this.id = id;
		this.parent = parent;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Parent1 getParent() {
		return parent;
	}

	public void setParent(Parent1 parent) {
		this.parent = parent;
	}


	
}
