package com.bug;

import java.util.HashSet;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class Service {

	@Autowired
    private SessionFactory sessionFactory;
	
	public void saveEntity(Object parent) {
		Session session = sessionFactory.getCurrentSession();
		parent = session.merge(parent);
		session.saveOrUpdate(parent);
		session.flush();
	}

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring-ctx.xml");
		Service service = context.getBean(Service.class);
		
		saveParent1(service);
		
		saveParent2(service);
		
		context.close();
	}

	private static void saveParent2(Service service) {
		Parent2 parent = new Parent2(1,"parent");
		service.saveEntity(parent);
		
		parent = new Parent2(1,"parent");
		HashSet<Child2> children = new HashSet<>();
		children.add(new Child2(1,parent,"child"));
		parent.setChildren(children);
		service.saveEntity(parent);
	}

	private static void saveParent1(Service service) {
		Parent1 parent1 = new Parent1(1,"parent");
		service.saveEntity(parent1);
		
		parent1 = new Parent1(1,"parent");
		HashSet<Child1> children1 = new HashSet<>();
		children1.add(new Child1(1,parent1,"child"));
		parent1.setChildren(children1);
		service.saveEntity(parent1);
		
		parent1 = new Parent1(1,"parent");
		children1 = new HashSet<>();
		children1.add(new Child1(2,parent1,"child"));
		parent1.setChildren(children1);
		service.saveEntity(parent1);
	}
}