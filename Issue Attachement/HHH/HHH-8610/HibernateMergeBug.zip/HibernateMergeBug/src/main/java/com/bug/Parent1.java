package com.bug;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Parent1 implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	private Integer id;

	private String attr;

	@OneToMany(cascade = { CascadeType.MERGE, CascadeType.PERSIST }, mappedBy = "id.parent", orphanRemoval = true)
	private Set<Child1> children;
	
	public Parent1(Integer id, String attr) {
		this.id = id;
		this.attr = attr;
	}
	
	public Parent1() {
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAttr() {
		return attr;
	}

	public void setAttr(String attr) {
		this.attr = attr;
	}

	public Set<Child1> getChildren() {
		return children;
	}

	public void setChildren(Set<Child1> children) {
		this.children = children;
	}

}
