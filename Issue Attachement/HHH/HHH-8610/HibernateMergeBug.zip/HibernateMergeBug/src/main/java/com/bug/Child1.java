package com.bug;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class Child1 implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ChildId id;
	
	private String attr;

	public Child1(Integer id, Parent1 parent, String attr) {
		this.id = new ChildId(id,parent);
		this.attr = attr;
	}

	public Child1() {
	}


	public ChildId getId() {
		return id;
	}

	public void setId(ChildId id) {
		this.id = id;
	}

	public String getAttr() {
		return attr;
	}

	public void setAttr(String attr) {
		this.attr = attr;
	}

}