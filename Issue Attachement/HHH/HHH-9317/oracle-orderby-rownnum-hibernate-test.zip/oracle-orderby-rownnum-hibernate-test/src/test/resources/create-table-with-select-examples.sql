create table t as select mod(level,5) id, trunc(dbms_random.value(1,100)) data from dual connect by level <= 10000;
select * from (select a.*, rownum rnum from (select id, data from t order by id) a where rownum <= 150) where rnum >= 148;
select * from (select a.*, rownum rnum from (select id, data from t order by id) a where rownum <= 151) where rnum >= 148;
select * from (select a.*, rownum rnum from (select id, data from t order by id, rowid) a where rownum <= 150) where rnum >= 148;
select * from (select a.*, rownum rnum from (select id, data from t order by id, rowid) a where rownum <= 151) where rnum >= 148;