1. Run the create-table-with-select-examples.sql on an oracle database. (Tested with 11.2)
2. Setup env.properties with jdbc url and username/password
3. Run Junits