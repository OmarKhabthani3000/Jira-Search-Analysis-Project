package org.test;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:applicationContext.xml")
public class TDaoTest {

	@Resource
	protected TDao tdao;

	@Test(expected=AssertionError.class)
	public void testGet() {
		List<T> firstQueryResults = tdao.get(148, 3);
		List<T> secondQueryResults = tdao.get(148, 4);

		Assert.assertEquals(firstQueryResults.get(0), secondQueryResults.get(0));
		Assert.assertEquals(firstQueryResults.get(1), secondQueryResults.get(1));
		Assert.assertEquals(firstQueryResults.get(2), secondQueryResults.get(2));
	}
	
	@Test
	public void testGetWithRowId() {
		List<T> firstQueryResults = tdao.getWithRowId(148, 3);
		List<T> secondQueryResults = tdao.getWithRowId(148, 4);

		Assert.assertEquals(firstQueryResults.get(0), secondQueryResults.get(0));
		Assert.assertEquals(firstQueryResults.get(1), secondQueryResults.get(1));
		Assert.assertEquals(firstQueryResults.get(2), secondQueryResults.get(2));
	}
}