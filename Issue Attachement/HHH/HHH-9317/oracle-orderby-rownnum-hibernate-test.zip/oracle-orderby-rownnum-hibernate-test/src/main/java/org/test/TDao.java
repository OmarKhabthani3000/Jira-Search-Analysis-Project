package org.test;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Class to test Example Oracle Pagination described at
 * http://www.oracle.com/technetwork
 * /issue-archive/2006/06-sep/o56asktom-086197.html
 *
 */
@Transactional
@Component
public class TDao {

	@Resource
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public List<T> get(int firstResult, int maxResults) {
		DetachedCriteria detachedCriteria = DetachedCriteria.forClass(T.class);
		detachedCriteria.addOrder(Order.asc("id"));
		Criteria criteria = detachedCriteria.getExecutableCriteria(sessionFactory.getCurrentSession());
		return criteria.setFirstResult(firstResult).setMaxResults(maxResults).list();
	}

	@SuppressWarnings("unchecked")
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public List<T> getWithRowId(int firstResult, int maxResults) {
		int lastResult = maxResults + firstResult;
		// This is the same query as with the get method just with adding order
		// by rownum. See
		// http://www.oracle.com/technetwork/issue-archive/2006/06-sep/o56asktom-086197.html
		String withRowIdString = "select * from ( select row_.*, rownum rownum_ from ( select this_.id as id1_39_0_, this_.data as data2_39_0_ from t this_ order by this_.id, rowid asc ) row_ where rownum <= "
				+ lastResult + ") where rownum_ > " + firstResult;
		List<Object[]> results = sessionFactory.getCurrentSession().createSQLQuery(withRowIdString).list();
		List<T> translate = new ArrayList<T>(results.size());
		for (Object[] c : results) {
			T result = new T();
			result.setId(((BigDecimal) c[0]).intValueExact());
			result.setData(((BigDecimal) c[1]).toPlainString());
			translate.add(result);
		}
		return translate;
	}
}
