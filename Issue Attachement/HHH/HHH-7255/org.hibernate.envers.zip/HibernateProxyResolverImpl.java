package ru.csbi.registry.services.reflection.model;

import org.hibernate.envers.HibernateProxyResolver;
import org.hibernate.envers.tools.Pair;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import ru.csbi.registry.services.envers.HibernateDomainIdService;
import ru.csbi.registry.services.envers.ModelInformationService;
import ru.csbi.registry.utils.PersistenceManagerHibernate;
/**
 * Suggested proxy resolver.
 */
@Service("hibernateProxyResolver")
public class HibernateProxyResolverImpl implements HibernateProxyResolver, ApplicationContextAware {

	private static ApplicationContext applicationContext;
	
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		HibernateProxyResolverImpl.applicationContext = applicationContext;
	}
	
	@Override
	public Pair<Object, String> resolve(Object proxy, String entityName) {
		String nonAuditableEntityClassName = getNonAuditableEntityClassName(entityName);
		Class clazz = getMethodInformationService().getEntityClassByEntityName(nonAuditableEntityClassName);		
		Object objectWithRealClass = getMethodInformationService().initializeAndUnproxy(proxy);
		String entityName2 = getMethodInformationService().createClassWrapper(objectWithRealClass.getClass()).getEntityNameByEntityClass();
		if (isAuditedEntityName(entityName)) {
			return new Pair<Object, String>(objectWithRealClass, createAuditedEntityName(entityName2));
		}
		return new Pair<Object, String>(objectWithRealClass, entityName2); 
	}

	private HibernateDomainIdService getHhibernateDomainIdService() {
		return applicationContext.getBean(HibernateDomainIdService.class);
	}

	private ModelInformationService getMethodInformationService() {
		return applicationContext.getBean(ModelInformationService.class);
	}

	private PersistenceManagerHibernate getPersistenceManagerHibernate() {
		return applicationContext.getBean(PersistenceManagerHibernate.class);
	}

	private boolean isAuditedEntityName(String entityName) {
		return entityName.endsWith("_AUD");
	}

	private String createAuditedEntityName(String notAuditedEntityName) {
		return notAuditedEntityName + "_AUD";
	}

	private String getNonAuditableEntityClassName(String entityName) {
		if (isAuditedEntityName(entityName)) {
			return entityName.substring(0, entityName.indexOf("_AUD"));
		}
		return entityName;
	}
}
