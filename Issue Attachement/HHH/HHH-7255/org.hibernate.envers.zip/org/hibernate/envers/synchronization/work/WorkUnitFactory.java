/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2010, Red Hat Inc. or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Inc.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.envers.synchronization.work;

import java.io.Serializable;

import org.hibernate.collection.PersistentCollection;
import org.hibernate.engine.CollectionEntry;
import org.hibernate.envers.configuration.AuditConfiguration;
import org.hibernate.event.AbstractCollectionEvent;
import org.hibernate.event.EventSource;

public interface WorkUnitFactory {

	AuditWorkUnit createCollectionChangeWorkUnit(Object entity, String entityName, Serializable entityId);

	AuditWorkUnit createCascadedModWorkUnit(Object object, String entityName, Serializable entityId);

	AuditWorkUnit createPersistentCollectionChangeWorkUnit(
			AbstractCollectionEvent event, EventSource session,
			String entityName, AuditConfiguration verCfg,
			PersistentCollection newColl, CollectionEntry collectionEntry,
			Serializable oldColl, Serializable affectedOwnerIdOrNull,
			String referencingPropertyName);
}