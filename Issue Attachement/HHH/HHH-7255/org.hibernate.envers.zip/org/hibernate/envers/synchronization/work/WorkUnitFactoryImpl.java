/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2010, Red Hat Inc. or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Inc.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.envers.synchronization.work;

import java.io.Serializable;

import org.hibernate.EntityMode;
import org.hibernate.collection.PersistentCollection;
import org.hibernate.engine.CollectionEntry;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.envers.EntityWithCachedNameAndId;
import org.hibernate.envers.HibernateProxyResolver;
import org.hibernate.envers.configuration.AuditConfiguration;
import org.hibernate.envers.synchronization.work.unit.CascadedModWorkUnit;
import org.hibernate.envers.synchronization.work.unit.CollectionChangeWorkUnit;
import org.hibernate.envers.synchronization.work.unit.PersistentCollectionChangeWorkUnit;
import org.hibernate.envers.tools.Pair;
import org.hibernate.event.AbstractCollectionEvent;
import org.hibernate.event.EventSource;
import org.hibernate.persister.entity.EntityPersister;

public class WorkUnitFactoryImpl implements WorkUnitFactory {

	private SessionImplementor sessionImplementor;
	
	private AuditConfiguration auditConfiguration;
	
	private HibernateProxyResolver hibernateProxyResolver;
	
	public WorkUnitFactoryImpl(SessionImplementor sessionImplementor, AuditConfiguration auditConfiguration, HibernateProxyResolver hibernateProxyResolver) {
		if (sessionImplementor == null) {
			throw new IllegalStateException(" (sessionImplementor == null) ");
		}
		if (auditConfiguration == null) {
			throw new IllegalStateException(" (auditConfiguration == null) ");
		}
		if (hibernateProxyResolver == null) {
			throw new IllegalStateException(" (hibernateProxyResolver == null) ");
		}
		this.sessionImplementor = sessionImplementor;
		this.auditConfiguration = auditConfiguration;
		this.hibernateProxyResolver = hibernateProxyResolver;
	}

	@Override
	public AuditWorkUnit createCascadedModWorkUnit(Object object, String entityName, Serializable entityId) {
		EntityPersister entityPersister = sessionImplementor.getEntityPersister(entityName, object);
		if (entityPersister == null) {
			throw new IllegalStateException(" (entityPersister == null), object: " + object.toString());
		}
//		EntityEntry entityEntry = (EntityEntry) sessionImplementor.getPersistenceContext().getEntityEntries().get(object);
//		if (entityEntry == null) {
//			throw new IllegalStateException(" (entityEntry == null), object: " + object.toString());
//		}
		Object[] propertyValues = entityPersister.getPropertyValues(object, EntityMode.POJO);
		if (propertyValues == null || propertyValues.length == 0) {
			throw new IllegalStateException(" (propertyValues == null || propertyValues.length == 0), object: " + object.toString());
		}
		CascadedModWorkUnit cascadedModWorkUnit = new CascadedModWorkUnit(sessionImplementor, 
				entityName, 
				auditConfiguration, 
				entityId, 
				entityPersister, 
				propertyValues);
		return cascadedModWorkUnit;
	}

	@Override
	public AuditWorkUnit createCollectionChangeWorkUnit(Object entity, String entityName, Serializable entityId) {
		EntityWithCachedNameAndId entityWithCachedNameAndId = new EntityWithCachedNameAndId(entity, entityId, entityName);
		entityWithCachedNameAndId = resolveNonAbstractEntityName(entityWithCachedNameAndId); 
		CollectionChangeWorkUnit workUnit = new CollectionChangeWorkUnit(sessionImplementor, 
				entityWithCachedNameAndId.getEntityName(), 
				auditConfiguration, 
				entityWithCachedNameAndId.getEntityId(),  
				entityWithCachedNameAndId.getEntity());
		return workUnit;
	}	

	private EntityWithCachedNameAndId resolveNonAbstractEntityName(EntityWithCachedNameAndId entityWithCachedNameAndId) {
		Pair<Object,String> entityAndEntityName = hibernateProxyResolver.resolve(entityWithCachedNameAndId.getEntity(), entityWithCachedNameAndId.getEntityName());
		return new EntityWithCachedNameAndId(entityAndEntityName.getFirst(), entityWithCachedNameAndId.getEntityId(), entityAndEntityName.getSecond());
	}

	@Override
	public AuditWorkUnit createPersistentCollectionChangeWorkUnit(
			AbstractCollectionEvent event, EventSource session,
			String entityName, AuditConfiguration verCfg,
			PersistentCollection newColl, CollectionEntry collectionEntry,
			Serializable oldColl, Serializable affectedOwnerIdOrNull,
			String referencingPropertyName) {
		return  new PersistentCollectionChangeWorkUnit(event, event.getSession(), entityName, verCfg, newColl, collectionEntry, oldColl, event.getAffectedOwnerIdOrNull(), referencingPropertyName);
	}
}
