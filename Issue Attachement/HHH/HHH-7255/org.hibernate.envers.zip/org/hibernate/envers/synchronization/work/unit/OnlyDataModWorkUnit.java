/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2010, Red Hat Inc. or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Inc.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.envers.synchronization.work.unit;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.hibernate.envers.RevisionType;
import org.hibernate.envers.configuration.AuditConfiguration;
import org.hibernate.envers.synchronization.work.AuditWorkUnit;
import org.hibernate.envers.synchronization.work.WorkUnitMergeVisitor;

import org.hibernate.engine.SessionImplementor;
import org.hibernate.event.PostUpdateEvent;
import org.hibernate.persister.entity.EntityPersister;

/**
 * @author Vyacheslav Sakhno
 */
public class OnlyDataModWorkUnit extends AbstractAuditWorkUnit implements AuditWorkUnit {
    private final Map<String, Object> data = new HashMap<String, Object>();
    private final boolean changes;        
    private Object before;
    private Object after;
    private EntityPersister entityPersister;
    private Object[] newState;
    private Object[] oldState;
    
    public OnlyDataModWorkUnit(SessionImplementor sessionImplementor, String entityName, AuditConfiguration verCfg, Serializable id, EntityPersister entityPersister, Object[] newState, Object[] oldState) {
        super(sessionImplementor, entityName, verCfg, id, RevisionType.ONLY_DATA_PROPERTY_MOD);
        changes = verCfg.getEntCfg().get(getEntityName()).getPropertyMapper().map(sessionImplementor, data, entityPersister.getPropertyNames(), newState, oldState);
        this.newState = newState;
        this.oldState = oldState;
        this.entityPersister = entityPersister;
    }

    public EntityPersister getEntityPersister() {
		return entityPersister;
	}

	public Object[] getNewState() {
		return newState;
	}

	public Object[] getOldState() {
		return oldState;
	}

	public OnlyDataModWorkUnit(PostUpdateEvent event, AuditConfiguration verCfg) {
    	this(event.getSession(), event.getPersister().getEntityName(), verCfg, event.getId(), event.getPersister(), event.getState(), event.getOldState());
    	this.before = event.getEntity();
    	this.after = event.getEntity();
	}

	public Object getBefore() {
		return before;
	}

	public void setBefore(Object before) {
		this.before = before;
	}
	
	public Object getObject() {
		return after;
	}

	public void setAfter(Object after) {
		this.after = after;
	}

	public boolean containsWork() {
        return changes;
    }

    public Map<String, Object> generateData(Object revisionData) {
        fillDataWithId(data, revisionData);

        return data;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public AuditWorkUnit merge(AddWorkUnit second) {
        return this;
    }

    public AuditWorkUnit merge(OnlyDataModWorkUnit second) {
        return second;
    }

	@Override
	public AuditWorkUnit merge(BothCollectionAndDataModWorkUnit second) { 
		return second;
	}

    public AuditWorkUnit merge(DelWorkUnit second) {
        return second;
    }

    public AuditWorkUnit merge(CollectionChangeWorkUnit second) {
        return new BothCollectionAndDataModWorkUnit(sessionImplementor, entityName, verCfg, id, entityPersister, newState, oldState);
    }

    public AuditWorkUnit merge(FakeBidirectionalRelationWorkUnit second) {
        return FakeBidirectionalRelationWorkUnit.merge(second, this, second.getNestedWorkUnit());
    }

    public AuditWorkUnit dispatch(WorkUnitMergeVisitor first) {
        return first.merge(this);
    }

	@Override
	public AuditWorkUnit merge(CascadedModWorkUnit second) {
		throw new UnsupportedOperationException(" cascaded unit merge ");
	}
}