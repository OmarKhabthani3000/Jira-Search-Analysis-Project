/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2010, Red Hat Inc. or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Inc.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.envers.synchronization.work.unit;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.envers.RevisionType;
import org.hibernate.envers.configuration.AuditConfiguration;
import org.hibernate.envers.synchronization.work.AuditWorkUnit;
import org.hibernate.envers.synchronization.work.WorkUnitMergeVisitor;
import org.hibernate.persister.entity.EntityPersister;

/**
 * @author Vyacheslav Sakhno
 */
public class CascadedModWorkUnit extends AbstractAuditWorkUnit implements AuditWorkUnit {
    private final Map<String, Object> data;

    public CascadedModWorkUnit(SessionImplementor sessionImplementor, String entityName, AuditConfiguration verCfg, Serializable id, EntityPersister entityPersister, Object[] newState) {
    	super(sessionImplementor, entityName, verCfg, id, RevisionType.CASCADED);
    	data = new HashMap<String, Object>();
    	verCfg.getEntCfg().get(getEntityName()).getPropertyMapper().map(sessionImplementor, data, entityPersister.getPropertyNames(), newState, null);
    }

	public boolean containsWork() {
        return true;
    }

    public Map<String, Object> generateData(Object revisionData) {
        fillDataWithId(data, revisionData);
        return data;
    }
    
    public AuditWorkUnit merge(AddWorkUnit second) {
        throw new UnsupportedOperationException(" cascaded unit merge ");
    }

    public AuditWorkUnit merge(OnlyDataModWorkUnit second) {
    	throw new UnsupportedOperationException(" cascaded unit merge ");
    }

    public AuditWorkUnit merge(DelWorkUnit second) {
    	throw new UnsupportedOperationException(" cascaded unit merge ");
    }

    public AuditWorkUnit merge(CollectionChangeWorkUnit second) {
    	throw new UnsupportedOperationException(" cascaded unit merge ");
    }

    public AuditWorkUnit merge(FakeBidirectionalRelationWorkUnit second) {
    	throw new UnsupportedOperationException(" cascaded unit merge ");
    }
    
    public void undo(Session session) {
    	throw new UnsupportedOperationException(" cascaded unit merge "); 
    }

	@Override
	public AuditWorkUnit merge(CascadedModWorkUnit second) {
		throw new UnsupportedOperationException(" cascaded unit merge ");//cascaded changes do not modify data fields, so there is no need to replace cascaded work unit
	}

	public AuditWorkUnit dispatch(WorkUnitMergeVisitor first) {
    	throw new UnsupportedOperationException(" cascaded unit merge ");
    }

	@Override
	public AuditWorkUnit merge(BothCollectionAndDataModWorkUnit second) {
		throw new UnsupportedOperationException(" cascaded unit merge ");
	}
}