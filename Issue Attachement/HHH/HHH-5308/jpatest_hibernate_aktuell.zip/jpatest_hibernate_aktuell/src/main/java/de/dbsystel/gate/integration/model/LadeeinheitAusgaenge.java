package de.dbsystel.gate.integration.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("AUSGANG")
@SuppressWarnings("serial")
public class LadeeinheitAusgaenge extends AbstractEinAusgang {

	public LadeeinheitAusgaenge() {
	}

}
