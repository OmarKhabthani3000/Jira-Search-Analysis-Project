package de.dbsystel.gate.integration.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("EINGANG")
@SuppressWarnings("serial")
public class LadeeinheitEingaenge extends AbstractEinAusgang {

	public LadeeinheitEingaenge() {
	}

}
