/**
 * Copyright 2010, DB Systel GmbH
 */
package de.dbsystel.gate.integration.dao.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.orm.jpa.support.JpaDaoSupport;

/**
 * @author AndreasAWuest
 * 
 */
public class LadeeinheitDaoImpl extends JpaDaoSupport {

    public void findby() {

        final String q = "SELECT x FROM AbstractEinAusgang x";

        final List findByNamedQuery = getJpaTemplate().findByNamedParams(q,
                new HashMap());

        final String q1 = "SELECT x FROM AbstractEinAusgang x where x.id.laeiLaeiLfdNr = :lfdNr "
                + " AND x.id.laeiAuftAuftNr = :auftNr AND x.id.laeiAuftMandMandNr = :mandNr ";

        final HashMap<String, Object> params = new HashMap<String, Object>();
        params.put("lfdNr", Long.valueOf(1));
        params.put("auftNr", Long.valueOf(4855769));
        params.put("mandNr", Long.valueOf(1124));

        final List findByNamedQuery2 = getJpaTemplate().findByNamedParams(q1,
                params);
    }

}
