package hibernate.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import hibernate.dao.DirectoryDao;
import hibernate.entity.Directory;

/**
 * @author Copyright 2000-${year} Flux Corporation. All rights reserved.
 */
@Service("directoryService")
@Transactional(readOnly = false)
public class DirectoryService {

  @Autowired
  private DirectoryDao directoryDao;

  public void deleteDirectory(long id) {
    directoryDao.deleteDirectory(id);
  }

  public void addDirectory(Directory directory) {
    directoryDao.addDirectory(directory);
  }

  @Transactional(readOnly = true)
  public Directory getDirectory(long id) {
    return directoryDao.getDirectory(id);
  }
}
