package hibernate;

import hibernate.entity.Blacklisted;
import hibernate.entity.Directory;
import hibernate.entity.Person;
import hibernate.service.DirectoryService;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.HashSet;
import java.util.Set;

/**
 * @author Copyright 2000-${year} Flux Corporation. All rights reserved.
 */
public class HibernateCascadeBug {
  private ClassPathXmlApplicationContext context;

  public HibernateCascadeBug() {
    this.context = new ClassPathXmlApplicationContext("applicationContextExample.xml");
  }

  public void addDirectory(Directory directory) {
    getDirectoryService().addDirectory(directory);
  }

  public Directory getDirectory(long id) {
    return getDirectoryService().getDirectory(id);
  }

  private DirectoryService getDirectoryService() {
    return (DirectoryService) context.getBean("directoryService");
  }

  public void deleteDirectory(long id) {
    getDirectoryService().deleteDirectory(id);
  }

  public static void main(String[] args) {
    HibernateCascadeBug bug = new HibernateCascadeBug();
    Directory directory = new Directory();
    Set<Person> people = new HashSet<Person>();
    Person adam = new Person();
    adam.setName("Adam");
    adam.setDirectory(directory);
    people.add(adam);
    Person james = new Person();
    james.setName("James");
    james.setDirectory(directory);
    people.add(james);
    directory.setPeople(people);

    Set<Blacklisted> blacklisted = new HashSet<Blacklisted>();
    Blacklisted blocked = new Blacklisted();
    blocked.setPerson(adam);
    blocked.setDirectory(directory);
    blacklisted.add(blocked);
    directory.setSuspended(blacklisted);
    bug.addDirectory(directory);
    System.out.println("Created!");

    bug.deleteDirectory(directory.getId());
    System.out.println("Deleted!");
  }
}
