package hibernate.entity;

import org.hibernate.validator.NotNull;

import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.Column;
import javax.persistence.OneToMany;
import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Entity;

/**
 * @author Copyright 2000-${year} Flux Corporation. All rights reserved.
 */
@Entity(name = Blacklisted.TABLE)
public class Blacklisted {
  public static final String TABLE = "BLACKLISTED";

  @Id
  @GeneratedValue
  @Column(name = "PK")
  private Long id;

  @NotNull
  @ManyToOne(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE,
    CascadeType.PERSIST})
  @JoinColumn(name = "DIRECTORY", unique = false, nullable = false, insertable = true, updatable = false)
  private Directory directory;

  @OneToOne(fetch = FetchType.EAGER, cascade = {CascadeType.PERSIST,
    CascadeType.MERGE})
  @JoinColumn(name = "PERSON", unique = false, nullable = false)
  private Person person;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Directory getDirectory() {
    return directory;
  }

  public void setDirectory(Directory directory) {
    this.directory = directory;
  }

  public Person getPerson() {
    return person;
  }

  public void setPerson(Person person) {
    this.person = person;
  }
}
