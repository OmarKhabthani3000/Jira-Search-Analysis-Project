package hibernate.entity;

import org.hibernate.validator.NotNull;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.Column;
import javax.persistence.OneToMany;
import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import java.util.Set;
import java.util.HashSet;

/**
 * @author Copyright 2000-${year} Flux Corporation. All rights reserved.
 */
@Entity(name = Directory.TABLE)
public class Directory {
  public static final String TABLE = "DIRECTORY";

  @Id
  @GeneratedValue
  @Column(name = "PK")
  private Long id;

  @NotNull
  @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  @JoinColumn(name = "DIRECTORY", nullable = false)
  private Set<Person> people;

  @OneToMany(mappedBy = "directory", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  @JoinColumn(name = "DIRECTORY", nullable = false)
  private Set<Blacklisted> suspended;

  public Long getId() {
    return id;
  }

  public Directory() {
    people = new HashSet<Person>();
    suspended = new HashSet<Blacklisted>();
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Set<Person> getPeople() {
    return people;
  }

  public void setPeople(Set<Person> people) {
    this.people = people;
  }

  public Set<Blacklisted> getSuspended() {
    return suspended;
  }

  public void setSuspended(Set<Blacklisted> suspended) {
    this.suspended = suspended;
  }   
}
