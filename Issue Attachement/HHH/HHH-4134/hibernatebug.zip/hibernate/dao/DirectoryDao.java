package hibernate.dao;

import hibernate.entity.Directory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;

/**
 * @author Copyright 2000-${year} Flux Corporation. All rights reserved.
 */
@Repository("directoryDao")
public class DirectoryDao {
  @PersistenceContext
  private EntityManager entityManager;

  @PersistenceUnit
  private EntityManagerFactory entityManagerFactory;

  protected EntityManagerFactory getEntityManagerFactory() {
    return entityManagerFactory;
  }

  private EntityManager getEntityManager() {
    if (entityManager == null || !entityManager.isOpen()) {
      entityManager = getEntityManagerFactory().createEntityManager();
    }
    return entityManager;
  }

  public void deleteDirectory(long id) {
    getEntityManager().remove(getDirectory(id));
  }

  public void addDirectory(Directory directory) {
    getEntityManager().persist(directory);
  }

  public Directory getDirectory(long id) {
    return getEntityManager().find(Directory.class, id);
  }
}
