package org.hibernate.test;

import java.io.Serializable;

/**
 * @author Marcin Moscicki
 */
public class Child implements Serializable {
	private Integer id;
	private Parent parent;


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}
}
