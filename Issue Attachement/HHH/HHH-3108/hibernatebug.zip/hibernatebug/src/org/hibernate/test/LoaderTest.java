package org.hibernate.test;

import junit.framework.TestCase;
import org.hibernate.Transaction;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;

/**
 * @author Marcin Moscicki
 */
public class LoaderTest extends TestCase {

	public void testNamedEntityLoadCollection() {
		testLoadCollection("mapping-entity.hbm.xml", "parent");
	}
	public void testEntityLoadCollection() {
		testLoadCollection("mapping-class.hbm.xml", "Parent");
	}
	public void testDefaultLoaderCollection() {
		testLoadCollection("mapping-default.hbm.xml", "Parent");
	}


	private void testLoadCollection(String mapping, String entity) {
		Configuration cfg = new Configuration().addResource(mapping);
		SessionFactory sf = cfg.buildSessionFactory();
		org.hibernate.classic.Session session = sf.openSession();

		String hql = "from " + entity;
		Query query = session.createQuery(hql);
		List parents = query.list();
		assertEquals(2, parents.size());
		for (int i = 0; i < parents.size(); i++) {
			Parent parent = (Parent) parents.get(i);
			assertEquals(2, parent.getChildren().size());
		}
	}
}
