package org.hibernate.test;

import java.io.Serializable;
import java.util.Set;

/**
 * @author Marcin Moscicki
 */
public class Parent implements Serializable {
	private Integer id;
	private Set children;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}


	public Set getChildren() {
		return children;
	}

	public void setChildren(Set children) {
		this.children = children;
	}
}
