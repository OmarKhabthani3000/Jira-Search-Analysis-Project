drop table parents cascade constraints;
drop table children cascade constraints;

create table parents (
	id	number(10) primary key
);

create table children (
	id	number(10)	primary key,
	parent_id	number(10) references parents (id)
);

insert into parents values ( 1 );
insert into children values ( 11, 1 );
insert into children values ( 12, 1 );

insert into parents values ( 2 );
insert into children values ( 21, 2 );
insert into children values ( 22, 2 );