# Hibernate Test Case Templates: Hibernate Search 7 in Hibernate ORM with Lucene

This directory contains a test case template for
Hibernate Search 7 in Hibernate ORM backed by an embedded Lucene instance.

You can run the integration tests:
* either using the command line with: `mvn verify`;
* or directly from your IDE. 
