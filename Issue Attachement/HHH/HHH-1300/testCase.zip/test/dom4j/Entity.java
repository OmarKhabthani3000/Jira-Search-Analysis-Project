package test.dom4j;
// Generated 2005/12/20 10:09:56 by Hibernate Tools 3.1.0 beta1JBIDERC2

import java.util.HashSet;
import java.util.Set;

/**
 * entity class<br>
 * 
 * @author Giangnh <br>
 */
public class Entity implements java.io.Serializable {

	// Fields

	/**
	 * field id<br>
	 */
	private Long id;
	/**
	 * field name<br>
	 */
	private String name;
	/**
	 * field details<br>
	 */
	private Set details = new HashSet();

	// Constructors

	/**
	 * Contructor Entity<br>
	 */
	public Entity() {
	}

	/**
	 * Contructor Entity<br>
	 * 
	 * @param name
	 * @param details
	 */
	public Entity(String name, Set details) {
		this.name = name;
		this.details = details;
	}

	// Property accessors

	/**
	 * get id<br>
	 * 
	 * @return Long
	 */
	public Long getId() {
		return this.id;
	}

	/**
	 * set id<br>
	 * 
	 * @param id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * get name<br>
	 * 
	 * @return String
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * set name<br>
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * get details<br>
	 * 
	 * @return Set
	 */
	public Set getDetails() {
		return this.details;
	}

	/**
	 * set details<br>
	 * 
	 * @param details
	 */
	public void setDetails(Set details) {
		this.details = details;
	}

	/**
	 * add detail entity<br>
	 * 
	 * @param detailEntity
	 */
	public void addDetailEntity(DetailEntity detailEntity) {
		if (details == null) {
			details = new HashSet();
		}
		detailEntity.setEntity(this);
		details.add(detailEntity);
	}

	/**
	 * get detail<br>
	 * @param i
	 * @return DetailEntity
	 */
	public DetailEntity getDetail(int i) {
		return (DetailEntity) details.toArray()[i];
	}

}
