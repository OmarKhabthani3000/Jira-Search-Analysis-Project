package test.dom4j;
// Generated 2005/12/20 10:09:56 by Hibernate Tools 3.1.0 beta1JBIDERC2



/**
 *  detail entity class<br>
 * @author Giangnh
 * <br>
 */
public class DetailEntity  implements java.io.Serializable {


    // Fields    

     /**
	 * field id<br>
	 */
    private Long id;
     /**
	 * field name<br>
	 */
    private String name;
     /**
	 * field component<br>
	 */
    private Component component;
     /**
	 * field entity<br>
	 */
    private Entity entity;


    // Constructors

    /**
	 * Contructor DetailEntity<br>
	 */
    public DetailEntity() {
    }

    
    /**
	 * Contructor DetailEntity<br>
	 * @param name
	 * @param component
	 * @param entity
	 */
    public DetailEntity(String name, Component component, Entity entity) {
        this.name = name;
        this.component = component;
        this.entity = entity;
    }
    

   
    // Property accessors

    /**
	 * get id<br>
	 * @return Long
	 */
    public Long getId() {
        return this.id;
    }
    
    /**
	 * set id<br>
	 * @param id
	 */
    public void setId(Long id) {
        this.id = id;
    }

    /**
	 * get name<br>
	 * @return String
	 */
    public String getName() {
        return this.name;
    }
    
    /**
	 * set name<br>
	 * @param name
	 */
    public void setName(String name) {
        this.name = name;
    }

    /**
	 * get component<br>
	 * @return Component
	 */
    public Component getComponent() {
        return this.component;
    }
    
    /**
	 * set component<br>
	 * @param component
	 */
    public void setComponent(Component component) {
        this.component = component;
    }

    /**
	 * get entity<br>
	 * @return Entity
	 */
    public Entity getEntity() {
        return this.entity;
    }
    
    /**
	 * set entity<br>
	 * @param entity
	 */
    public void setEntity(Entity entity) {
        this.entity = entity;
    }
   








}
