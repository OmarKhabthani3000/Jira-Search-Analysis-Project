package test.dom4j;
// Generated 2005/12/20 10:09:56 by Hibernate Tools 3.1.0 beta1JBIDERC2



/**
 *  component class<br>
 * @author Giangnh
 * <br>
 */
public class Component  implements java.io.Serializable {


    // Fields    

     /**
	 * field nested property<br>
	 */
    private String nestedProperty;
     /**
	 * field nested entity<br>
	 */
    private NestedEntity nestedEntity;


    // Constructors

    /**
	 * Contructor Component<br>
	 */
    public Component() {
    }

    
    /**
	 * Contructor Component<br>
	 * @param nestedProperty
	 * @param nestedEntity
	 */
    public Component(String nestedProperty, NestedEntity nestedEntity) {
        this.nestedProperty = nestedProperty;
        this.nestedEntity = nestedEntity;
    }
    

   
    // Property accessors

    /**
	 * get nested property<br>
	 * @return String
	 */
    public String getNestedProperty() {
        return this.nestedProperty;
    }
    
    /**
	 * set nested property<br>
	 * @param nestedProperty
	 */
    public void setNestedProperty(String nestedProperty) {
        this.nestedProperty = nestedProperty;
    }

    /**
	 * get nested entity<br>
	 * @return NestedEntity
	 */
    public NestedEntity getNestedEntity() {
        return this.nestedEntity;
    }
    
    /**
	 * set nested entity<br>
	 * @param nestedEntity
	 */
    public void setNestedEntity(NestedEntity nestedEntity) {
        this.nestedEntity = nestedEntity;
    }
   








}
