package test.dom4j;
// Generated 2005/12/20 10:09:56 by Hibernate Tools 3.1.0 beta1JBIDERC2



/**
 *  nested entity class<br>
 * @author Giangnh
 * <br>
 */
public class NestedEntity  implements java.io.Serializable {


    // Fields    

     /**
	 * field id<br>
	 */
    private Long id;
     /**
	 * field name<br>
	 */
    private String name;


    // Constructors

    /**
	 * Contructor NestedEntity<br>
	 */
    public NestedEntity() {
    }

    
    /**
	 * Contructor NestedEntity<br>
	 * @param name
	 */
    public NestedEntity(String name) {
        this.name = name;
    }
    

   
    // Property accessors

    /**
	 * get id<br>
	 * @return Long
	 */
    public Long getId() {
        return this.id;
    }
    
    /**
	 * set id<br>
	 * @param id
	 */
    public void setId(Long id) {
        this.id = id;
    }

    /**
	 * get name<br>
	 * @return String
	 */
    public String getName() {
        return this.name;
    }
    
    /**
	 * set name<br>
	 * @param name
	 */
    public void setName(String name) {
        this.name = name;
    }
   








}
