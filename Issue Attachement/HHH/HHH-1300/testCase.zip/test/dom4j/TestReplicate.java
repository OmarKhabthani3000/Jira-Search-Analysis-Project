package test.dom4j;

import java.io.Serializable;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.hibernate.EntityMode;
import org.hibernate.ReplicationMode;
import org.hibernate.Session;

import test.base.TestBase;

/**
 * test replicate class<br>
 * 
 * @author Giangnh <br>
 */
public class TestReplicate extends TestBase {
	/**
	 * test replicate<br>
	 * 
	 * @exception Exception
	 */
	public void testReplicate() throws Exception {
		Entity entity = genEntity();
		Serializable id = save(entity);

		session.clear();

		Session session2 = session.getSession(EntityMode.DOM4J);
		String asXML = ((Element) session2.get(Entity.class, id)).asXML();

		Element element = DocumentHelper.parseText(asXML).getRootElement();
		beginTrans();
		session2.replicate(Entity.class.getName(), element,
				ReplicationMode.OVERWRITE);
		commit();

		Entity entity2 = (Entity) get(Entity.class, id);
		assertNotNull(entity2.getDetail(0).getComponent().getNestedEntity());
	}

	/**
	 * gen entity<br>
	 * 
	 * @return Entity
	 */
	private Entity genEntity() {
		Entity entity = new Entity();
		entity.setName("entity name");
		entity.addDetailEntity(genDetail());
		return entity;
	}

	/**
	 * gen detail<br>
	 * 
	 * @return DetailEntity
	 */
	private DetailEntity genDetail() {
		DetailEntity detailEntity = new DetailEntity();
		detailEntity.setName("detail Entity");
		detailEntity.setComponent(genNestedComponent());
		return detailEntity;
	}

	/**
	 * gen nested component<br>
	 * 
	 * @return Component
	 */
	private Component genNestedComponent() {
		NestedEntity nestedEntity = new NestedEntity();
		nestedEntity.setName("nested name");
		save(nestedEntity);
		Component component = new Component();
		component.setNestedEntity(nestedEntity);
		component.setNestedProperty("nested property");
		return component;
	}
}
