package test.base;

import java.io.Serializable;

import junit.framework.TestCase;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.classic.Session;

import test.multicasecade.RootEntity;

/**
 * test base class<br>
 * <br>
 */
public class TestBase extends TestCase {

	/**
	 * field session<br>
	 */
	public static Session session;

	/**
	 * field transaction<br>
	 */
	private Transaction transaction;

	/**
	 * begin trans<br>
	 */
	protected void beginTrans() {
		transaction = session.beginTransaction();
	}

	/**
	 * commit<br>
	 */
	protected void commit() {
		transaction.commit();
	}

	/**
	 * get<br>
	 * 
	 * @param class1
	 * @param id
	 * @return Object
	 */
	protected Object get(Class class1, Serializable id) {
		return session.get(class1, id);
	}

	/**
	 * open session<br>
	 * 
	 * @param flg
	 */
	private void openSession(boolean flg) {
		Configuration configuration = new Configuration();
		if (flg) {
			configuration.setProperty(Environment.HBM2DDL_AUTO, "create-drop");
		}
		SessionFactory sessionFactory = configuration.configure()
				.buildSessionFactory();
		session = sessionFactory.openSession();
	}

	/**
	 * restart session<br>
	 */
	protected void restartSession() {
		session.close();
		openSession(false);
	}

	/**
	 * save<br>
	 * 
	 * @param object
	 * @return Serializable
	 */
	protected Serializable save(Object object) {
		beginTrans();
		Serializable id = session.save(object);
		commit();
		return id;
	}

	/**
	 * set up<br>
	 * 
	 * @exception Exception
	 */
	protected void setUp() throws Exception {
		super.setUp();
		openSession(true);
	}

	/**
	 * delete<br>
	 * 
	 * @param rootEntity
	 */
	protected void delete(RootEntity rootEntity) {
		beginTrans();
		session.delete(rootEntity);
		commit();
	}

}
