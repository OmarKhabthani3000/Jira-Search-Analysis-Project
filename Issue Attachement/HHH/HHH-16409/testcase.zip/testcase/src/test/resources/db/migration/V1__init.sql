
create schema test;

create table test.t_secondary (
    id integer primary key,
    name character varying (50)
);

create table test.t_primary (
    id integer primary key,
    t_secondary_id integer not null ,
    value numeric (12, 2) not null,
    constraint d_primary_t_secondary_id_fkey foreign key(t_secondary_id)
        references test.t_secondary(id) match simple
);

insert into test.t_secondary(id, name) values (1, 'a'), (2, 'b'), (3, 'c');

insert into test.t_primary(id, t_secondary_id, value)
    values (1, 1, 10), (2, 1, 20), (3, 1, 30),
           (4, 2, 100), (5, 2, 200), (6, 2, 300),
           (7, 3, 1000), (8, 3, 2000), (9, 3, 3000);
