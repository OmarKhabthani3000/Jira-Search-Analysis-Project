/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package testcase;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Root;
import java.math.BigDecimal;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import static org.assertj.core.api.Assertions.assertThat;
import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.output.MigrateResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testcase.db.Primary;
import testcase.db.Primary_;
import testcase.db.Secondary_;

public class QueryTest {

    private static final Logger LOGGER = LogManager.getLogger();

    private EntityManagerFactory emf;
    private EntityManager em;


    @Test
    public void executeQuery() {
        //given
        CriteriaBuilder cb = em.getCriteriaBuilder();
        var query = cb.createTupleQuery();
        Root<Primary> root = query.from(Primary.class);
        var secondaryJoin = root.join(Primary_.secondary);
        //when
        query.multiselect(
                secondaryJoin.get(Secondary_.name).alias("secondary"),
                cb.sum(root.get(Primary_.value)).alias("sum")
        ).groupBy(
                secondaryJoin
        ).orderBy(
                cb.desc(secondaryJoin.get(Secondary_.name))
        );
        var list = em.createQuery(query).getResultList();
        //then
        assertThat(list).hasSize(3);
        var tupleIt = list.iterator();
        var tuple = tupleIt.next();
        assertThat(tuple.get("secondary", String.class)).isEqualTo("c");
        assertThat(tuple.get("sum", BigDecimal.class)).isEqualByComparingTo(new BigDecimal("6000"));
        tuple = tupleIt.next();
        assertThat(tuple.get("secondary", String.class)).isEqualTo("b");
        assertThat(tuple.get("sum", BigDecimal.class)).isEqualByComparingTo(new BigDecimal("600"));
        tuple = tupleIt.next();
        assertThat(tuple.get("secondary", String.class)).isEqualTo("a");
        assertThat(tuple.get("sum", BigDecimal.class)).isEqualByComparingTo(new BigDecimal("60"));
    }

    @BeforeClass
    private void beforeClass() {
        Flyway flyway = Flyway.configure().dataSource("jdbc:hsqldb:mem:jpa_test", "user", "password").load();
        MigrateResult migrateResult = flyway.migrate();
        LOGGER.info("Migrations: {}", migrateResult.migrationsExecuted);
        emf = Persistence.createEntityManagerFactory("jpa_test");
        em = emf.createEntityManager();
    }

    @AfterClass
    private void afterClass() {
        em.close();
        emf.close();
    }

    @BeforeMethod
    private void beforeMethod() {
        em.getTransaction().begin();
    }

    @AfterMethod
    private void afterMethod() {
        em.getTransaction().rollback();
    }
}
