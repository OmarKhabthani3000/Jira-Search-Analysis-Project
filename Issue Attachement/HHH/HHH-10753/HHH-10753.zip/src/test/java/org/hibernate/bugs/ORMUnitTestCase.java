/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.stat.SecondLevelCacheStatistics;

import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.Assert.assertEquals;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 * <p>
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

	protected final Logger LOGGER = LoggerFactory.getLogger( getClass());

	// Add your entities here.
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
				Post.class,
				PostComment.class,
		};
	}

	// If you use *.hbm.xml mappings, instead of annotations, add the mappings here.
	@Override
	protected String[] getMappings() {
		return new String[] {
//				"Foo.hbm.xml",
//				"Bar.hbm.xml"
		};
	}

	// If those mappings reside somewhere other than resources/org/hibernate/test, change this.
	@Override
	protected String getBaseForMappings() {
		return "org/hibernate/test/";
	}

	// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );

		configuration.setProperty( AvailableSettings.SHOW_SQL, "true" );
		configuration.setProperty("hibernate.cache.region_prefix", "");
		configuration.setProperty("hibernate.generate_statistics", Boolean.TRUE.toString());
		configuration.setProperty("hibernate.cache.use_second_level_cache", Boolean.TRUE.toString());
		configuration.setProperty("hibernate.cache.region.factory_class", "org.hibernate.cache.ehcache.EhCacheRegionFactory");
	}

	// Add your tests, using standard JUnit.
	@Test
	public void HHH10753Test() throws Exception {
		// BaseCoreFunctionalTestCase automatically creates the SessionFactory and provides the Session.
		Session session = openSession();
		Transaction transaction = session.beginTransaction();

		try {
			Post post = new Post();
			post.setId( 1L );
			post.setTitle( "Post" );

			PostComment comment1 = new PostComment();
			comment1.setId(1L);
			comment1.setReview("JDBC part review");
			post.addComment(comment1);

			PostComment comment2 = new PostComment();
			comment2.setId(2L);
			comment2.setReview("Hibernate part review");
			post.addComment(comment2);

			session.persist( post );

			transaction.commit();
		}
		catch (HibernateException expected) {
			transaction.rollback();
		}
		finally {
			session.close();
		}

		session = openSession();
		transaction = session.beginTransaction();

		try {
			Post post = session.get(Post.class, 1L);
			assertEquals(2, post.getComments().size());
		}
		catch (HibernateException expected) {
			transaction.rollback();
		}
		finally {
			session.close();
		}

		printCacheRegionStatistics(Post.class.getName());
		printCacheRegionStatistics(Post.class.getName() + ".comments");
		printCacheRegionStatistics(PostComment.class.getName());

		session = openSession();
		transaction = session.beginTransaction();

		try {
			Post post = session.get(Post.class, 1L);
			session.delete(post);
			transaction.commit();
		}
		catch (HibernateException expected) {
			transaction.rollback();
		}
		finally {
			session.close();
		}

		printCacheRegionStatistics(Post.class.getName());
		printCacheRegionStatistics(Post.class.getName() + ".comments");
		printCacheRegionStatistics(PostComment.class.getName());
	}

	protected void printCacheRegionStatistics(String region) {
		SecondLevelCacheStatistics statistics = sessionFactory().getStatistics().getSecondLevelCacheStatistics( region);
		LOGGER.info("\nRegion: {},\nStatistics: {},\nEntries: {}", region, statistics, statistics.getEntries());
	}

	@Entity(name = "Post")
	@Table(name = "post")
	@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
	public static class Post {

		@Id
		private Long id;

		private String title;

		@Version
		private int version;

		@OneToMany(cascade = CascadeType.ALL, mappedBy = "post", orphanRemoval = true)
		@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
		private List<PostComment> comments = new ArrayList<>();

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public List<PostComment> getComments() {
			return comments;
		}

		public void addComment(PostComment comment) {
			comments.add(comment);
			comment.setPost(this);
		}
	}

	@Entity(name = "PostComment")
	@Table(name = "post_comment")
	@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
	public static class PostComment {

		@Id
		private Long id;

		@ManyToOne(fetch = FetchType.LAZY)
		private Post post;

		private String review;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public Post getPost() {
			return post;
		}

		public void setPost(Post post) {
			this.post = post;
		}

		public String getReview() {
			return review;
		}

		public void setReview(String review) {
			this.review = review;
		}
	}
}
