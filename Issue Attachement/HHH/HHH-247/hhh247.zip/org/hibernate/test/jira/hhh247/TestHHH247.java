package org.hibernate.test.jira.hhh247;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.test.TestCase;

import junit.framework.Test;
import junit.framework.TestSuite;

public class TestHHH247 extends TestCase {

	public TestHHH247(String name) {
		super(name);
	}

	/**
	 * Issue logged in JIRA:
	 * <a href="http://opensource.atlassian.com/projects/hibernate/browse/HHH-247">HHH-247</a>
	 * <p>
	 * Fails against Microsoft SQL Server 2000 SP3.
	 * Succeeds against HSQL.
	 * </p>
	 */
	public void testHHH247() {
		Person p = new Person();
		p.setName(new Name("John", null));

		Session s = openSession();
		Transaction t = s.beginTransaction();

		s.persist(p);
		t.commit();

		t = s.beginTransaction();
		p.getName().setLast("Doe");
		t.commit();

		s.close();
	}

	protected String[] getMappings() {
		return new String[] {"jira/hhh247/person.hbm.xml"};
	}

	protected void configure(Configuration cfg) {
		cfg.setProperty(Environment.USE_QUERY_CACHE, "false");
		cfg.setProperty(Environment.USE_SECOND_LEVEL_CACHE, "false");
	}

	public static Test suite() {
		return new TestSuite(TestHHH247.class);
	}
}

