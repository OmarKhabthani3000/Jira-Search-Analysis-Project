package org.hibernate.test.jira.hhh247;

public class Person {

	private Integer _identity;
	private Name _name;

	public Person() {
	}

	public Integer getIdentity() {
		return _identity;
	}

	public void setIdentity(Integer id) {
		_identity = id;
	}

	public Name getName() {
		return _name;
	}

	public void setName(Name n) {
		_name = n;
	}
}

