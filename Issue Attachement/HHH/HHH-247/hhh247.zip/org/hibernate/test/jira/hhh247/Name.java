package org.hibernate.test.jira.hhh247;

public class Name {

	private String _first;
	private String _last;

	public Name() {
	}

	public Name(String first, String last) {
		setFirst(first);
		setLast(last);
	}

	public String getFirst() {
		return _first;
	}

	public void setFirst(String firstName) {
		_first = firstName;
	}

	public String getLast() {
		return _last;
	}

	public void setLast(String lastName) {
		_last = lastName;
	}

	public boolean equals(Object other) {
		return (other instanceof Name) && equals((Name) other);
	}

	public boolean equals(Name other) {
		return equals(getFirst(), other.getFirst()) && equals(getLast(), other.getLast());
	}

	protected boolean equals(String a, String b) {
		if (a == b) return true;
		return (a != null) && (b != null) && a.equals(b);
	}

	public int hashCode() {
		return hashCode(getFirst()) ^ hashCode(getLast());
	}

	protected int hashCode(String s) {
		return (s == null) ? 0 : s.hashCode();
	}
}

