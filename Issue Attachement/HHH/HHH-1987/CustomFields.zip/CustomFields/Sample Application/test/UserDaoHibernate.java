package test;

import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.opencraft.util.hibernate.customfields.CustomField;
import com.opencraft.util.hibernate.customfields.CustomFieldsConfiguration;

/**
 * @author Ali El Gamal
 * 
 */
public class UserDaoHibernate extends HibernateDaoSupport implements UserDao {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.oc.test.UserDao#getUser(long)
	 */
	public User getUser(Long uid) {
		User s = (User) getHibernateTemplate().load(test.User.class, uid);
		// System.err.println("User Age=" + s.getAge());
		return s;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.oc.test.UserDao#addUser(com.oc.test.User)
	 */
	public void addUser(User user) {
		getHibernateTemplate().save(user);
	}

	public int getUsersCount() {
		return getHibernateTemplate().loadAll(test.User.class).size();
	}
}
