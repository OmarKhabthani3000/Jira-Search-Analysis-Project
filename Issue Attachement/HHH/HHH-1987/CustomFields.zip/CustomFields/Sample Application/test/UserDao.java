package test;

import com.opencraft.util.hibernate.customfields.CustomField;

public interface UserDao {

	public User getUser(Long uid);

	public void addUser(User user);
	
	public int getUsersCount();
}