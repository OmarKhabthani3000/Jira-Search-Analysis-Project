package test;

import java.io.FileInputStream;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.InputStreamResource;
import org.springframework.orm.hibernate3.LocalSessionFactoryBean;

import com.opencraft.util.hibernate.customfields.CustomField;
import com.opencraft.util.hibernate.customfields.CustomFieldsConfiguration;
import com.opencraft.util.hibernate.customfields.DefaultExtensibleEntity;
import com.opencraft.util.hibernate.customfields.spring.SpringCustomFieldsSupporter;

public class User extends DefaultExtensibleEntity {

	private Long id;

	private String firstName;

	private String lastName;

	private String company;

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public Long getId() {
		return id;
	}

	private void setId(Long id) {
		this.id = id;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public static void main(String[] args) throws Exception {
		BeanFactory bf = new XmlBeanFactory(new InputStreamResource(
				new FileInputStream("ApplicationContext.xml")));
		SpringCustomFieldsSupporter scfs = (SpringCustomFieldsSupporter) bf
				.getBean("customFieldsSupporter");

		CustomField emailField = new CustomField("email", "string", "email",
				User.class);
		boolean emailFieldFound = scfs.getCustomFields(User.class).contains(
				emailField);
		if (!emailFieldFound) {
			System.out.println("Email field wasn't found");
			System.out.println("Creating Email Custom Field");
			scfs.addCustomField(emailField);
		}else {
			System.out.println("Email field found!");
		}

		UserDao ud = (UserDao) bf.getBean("usersDao");
		User u = new User();
		u.setFirstName("Ali");
		u.setLastName("El Gamal");
		u.setCompany("OpenCraft");
		if (!emailFieldFound)
			u.setCustomFieldValue("email", "aelgamal@open-craft.com");
		ud.addUser(u);
		System.out.println("User Added to the DB");
		System.out.println("check the database to see the effect of this application");
	}
}
