package com.opencraft.util.hibernate.customfields;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.mapping.PersistentClass;

/**
 * <p>
 * This class enables adding custom fields support to applications that are
 * using Hibernate.
 * </p>
 * 
 * @author Ali El Gamal
 * @version 0.1
 */
public class CustomFieldsConfiguration extends Configuration {

	private static final long serialVersionUID = 8542742161880737895L;

	private Document configurationDocument;

	private LinkedList<CustomField> newCustomFields = new LinkedList<CustomField>();

	private HashMap<Class, HashSet<CustomField>> customFields = new HashMap<Class, HashSet<CustomField>>();

	private String autoSaveFileName;

	/**
	 * Creates a new instance of <code>CustomFieldsConfiguration</code> that
	 * does has no custom fields configuration. Instances of this configuration
	 * will behave the same as <code>org.hibernate.cfg.Configuration</code>
	 * unless {@link #setConfigurationDocument(Document)} and/or
	 * {@link #addCustomField} was called with a valid configuration document
	 * 
	 */
	public CustomFieldsConfiguration() {
		// preparing a document for usage by setting the root element
		setConfigurationDocument(DocumentHelper.createDocument());
		Element rootElement = DocumentHelper.createElement("cf-conf");
		getConfigurationDocument().setRootElement(rootElement);
	}

	/**
	 * Creates a new instance of <code>CustomFieldsConfiguration</code> that
	 * has the custom fields configuration in the specified XML file.
	 * 
	 * @param filename
	 *            the name of the XML file
	 * @throws DocumentException
	 *             if an error occured during parsing
	 * @throws FileNotFoundException
	 *             if the file was not found
	 * @throws ClassNotFoundException
	 *             If a class that is referenced in the configuratation document
	 *             cannot be found
	 */
	public CustomFieldsConfiguration(String filename) throws DocumentException,
			FileNotFoundException, ClassNotFoundException {
		this(new File(filename));
	}

	/**
	 * Creates a new instance of <code>CustomFieldsConfiguration</code> that
	 * has the custom fields configuration in the specified XML file.
	 * 
	 * @param configurationFile
	 *            the XML file that contains the custom fields configuration.
	 * @throws DocumentException
	 *             if an error occured during parsing the document
	 * @throws FileNotFoundException
	 *             if the file was not found
	 * @throws ClassNotFoundException
	 *             If a class that is referenced in the configuratation document
	 *             cannot be found
	 */
	public CustomFieldsConfiguration(File configurationFile)
			throws DocumentException, FileNotFoundException,
			ClassNotFoundException {

		this(new FileReader(configurationFile));

	}

	/**
	 * Creates a new instance of <code>CustomFieldsConfiguration</code> that
	 * has the custom fields configuration specified by the xml document at the
	 * specified <code>java.net.URL</code>
	 * 
	 * @param configurationDocumentURL
	 *            the URL of the XML document that contains the configuration of
	 *            the custom fields
	 * @throws DocumentException
	 *             if an error occured during parsing the document
	 * @throws ClassNotFoundException
	 *             If a class that is referenced in the configuratation document
	 *             cannot be found
	 */
	public CustomFieldsConfiguration(URL configurationDocumentURL)
			throws DocumentException, ClassNotFoundException {
		this(new SAXReader().read(configurationDocumentURL));
	}

	/**
	 * Creates a new instance of <code>CustomFieldsConfiguration</code> that
	 * has the custom fields configuration specified by the xml document that is
	 * currently open by the specified <code>Reader</code>
	 * 
	 * @param reader
	 *            the reader that has the XML file open
	 * @throws DocumentException
	 *             if an error occured while parsing the document
	 * @throws ClassNotFoundException
	 *             If a class that is referenced in the configuratation document
	 *             cannot be found
	 */
	public CustomFieldsConfiguration(Reader reader) throws DocumentException,
			ClassNotFoundException {
		this(new SAXReader().read(reader));
	}

	/**
	 * Creates a new instance of <code>CustomFieldsConfiguration</code> that
	 * has the custom fields configuration specified by the specified XML
	 * document
	 * 
	 * @param configurationDocument
	 *            the XML document that contains the custom fields configuration
	 * @throws DocumentException
	 *             If an error occured during parsing the document
	 * @throws ClassNotFoundException
	 *             If a class that is referenced in the configuratation document
	 *             cannot be found
	 * @throws IllegalArgumentException
	 *             If the configuration file contains a class that doesn't
	 *             implement interface {@link ExtensibleEntity}
	 */
	public CustomFieldsConfiguration(Document configurationDocument)
			throws DocumentException, ClassNotFoundException,
			IllegalArgumentException {
		setConfigurationDocument(configurationDocument);

		for (Iterator itr = configurationDocument.getRootElement()
				.elementIterator("class"); itr.hasNext();) {

			Element eClass = (Element) itr.next();
			Class classClass = Class.forName(eClass.attributeValue("name"));

			// Finding custom properties of the class
			for (Iterator itr2 = eClass.elementIterator("property"); itr2
					.hasNext();) {
				Element eProperty = (Element) itr2.next();
				CustomField cf = new CustomField(eProperty, classClass);
				if (newCustomFields.contains(cf))
					throw new RuntimeException(
							"The file contains duplicate customField with name "
									+ cf.getFieldName() + " for the class "
									+ cf.getContainingType());
				newCustomFields.add(cf);
			}
		}

	}

	/**
	 * Returns the XML configuration document that contains the custom fields
	 * configuration.
	 * 
	 * @return the custom fields configuration document
	 */
	public Document getConfigurationDocument() {
		return configurationDocument;
	}

	/**
	 * Sets the XML document that contains the custome fields configuration.<br>
	 * <b>Note:</b> This configuration will be applied to next calls of
	 * buildSessionFactory. Already built sessionFactories will not be affected.
	 * 
	 * @param configurationDocument
	 *            the custom fields configuration document.
	 * @throws NullPointerException
	 *             if the specified configuration document is null
	 */
	public void setConfigurationDocument(Document configurationDocument)
			throws NullPointerException {
		if (configurationDocument == null)
			throw new NullPointerException(
					"Configuration Document cannot be null");
		this.configurationDocument = configurationDocument;

	}

	/**
	 * Builds a session factory that can be used for openning sessions.<br>
	 * <b>Note:</b> Before calling this method, you must have created
	 * ClassMapping for the entities containing the custom fields.<br>
	 * <b>Note:</b> If auto save configuration document is enabled and an error
	 * happens during auto saving, the exception will be printed to the standard
	 * err.<br>
	 */
	@Override
	public SessionFactory buildSessionFactory() throws HibernateException,
			IllegalArgumentException {
		if (!newCustomFields.isEmpty()) {
			// We have some custom fields that needs to be added
			for (CustomField cf : newCustomFields) {
				PersistentClass pc = getClassMapping(cf.getContainingType()
						.getName());

				try {
					pc.getProperty(cf.getFieldName());
					throw new IllegalStateException("The class "
							+ cf.getContainingType()
							+ " contains more than one field with name "
							+ cf.getFieldName());
				} catch (MappingException me) {
					// The Property is not duplicated
				}
				pc.addProperty(cf.getProperty(pc));
				// Adding the custom fields to the list of custom fields.
				HashSet<CustomField> classCustomFields = customFields.get(cf
						.getContainingType());
				if (classCustomFields == null) {
					classCustomFields = new HashSet<CustomField>();
					customFields.put(cf.getContainingType(), classCustomFields);
				}
				// Adding the custom fields to the class
				classCustomFields.add(cf);
			}
		}
		// If auto save configuration file is enabled, save the configuration
		// document
		if (!newCustomFields.isEmpty() && autoSaveFileName != null) {
			try {
				saveDocument(autoSaveFileName);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		newCustomFields.clear();
		return super.buildSessionFactory();
	}

	/**
	 * Adds a new custom field. <br>
	 * <b>Note:</b>The specified custom field won't affect already build
	 * session factories.
	 * 
	 * @param cf
	 *            The custom field to be added.
	 * @throws IllegalArgumentException
	 *             If a custom field with the same name for the same class was
	 *             added before.
	 */
	public void addCustomField(CustomField cf) throws IllegalArgumentException {
		if (newCustomFields.contains(cf))
			throw new IllegalArgumentException("Custom Field already added");

		// Adding this custom field to the list of custom fields in order to
		// get it when the the user request a new session factory
		newCustomFields.add(cf);

		// Adding the custom field to the document
		Element typeElement = null;
		// Searching for an existing element for the class that contain this
		// class element
		for (Iterator itr = configurationDocument.getRootElement()
				.elementIterator("class"); itr.hasNext();) {
			Element e = (Element) itr.next();
			if (e.attributeValue("name").equals(
					cf.getContainingType().getName())) {
				typeElement = e;
				break;
			}
		}

		if (typeElement == null) {
			// No Existing one found, creating a new element under the root
			// element
			typeElement = configurationDocument.getRootElement().addElement(
					"class");
			typeElement.addAttribute("name", cf.getContainingType().getName());
		}
		Element propertyElement = typeElement.addElement("property");
		propertyElement.addAttribute("name", cf.getFieldName());
		propertyElement.addAttribute("type", cf.getValue().getType().getName());
	}

	/**
	 * Returns the custom fields available for this class.<br>
	 * <b>Note:</b> The custom fields returned are those custom field available
	 * in the last session factory retrieved by calling
	 * {@link #buildSessionFactory()}
	 * 
	 * @param c
	 *            the class to get all it customFields
	 * @return the custom fields for the specified class
	 */
	public Set<CustomField> getCustomFields(Class c) {
		if(customFields.get(c) == null)
			customFields.put(c, new HashSet<CustomField>());
		return Collections.unmodifiableSet(customFields.get(c));
	}

	/**
	 * Save the XML configuration document to a file
	 * 
	 * @param fileName
	 *            the name of the file to save the XML configuration document to
	 * @throws IOException
	 *             if an IO error occured while writing the document
	 */
	public void saveDocument(String fileName) throws IOException {
		saveDocument(new File(fileName));
	}

	/**
	 * Save the XML configuration document to a file
	 * 
	 * @param file
	 *            the file to save the XML configuration document to
	 * @throws IOException
	 *             if an IO error occured while writing the document
	 */
	public void saveDocument(File file) throws IOException {
		FileWriter writer = new FileWriter(file);
		saveDocument(writer);
		writer.close();
	}

	/**
	 * Saves the XML configuration document using a <code>Writer</code><br/>
	 * <b>Note:</b> The caller of this method is responsible for closing the
	 * stream.
	 * 
	 * @param writer
	 *            the writer to be used to save the XML configuration document.
	 * @throws IOException
	 *             if an IO error occured while writing the document
	 */
	public void saveDocument(Writer writer) throws IOException {
		XMLWriter xmlWriter = new XMLWriter(writer, OutputFormat
				.createPrettyPrint());
		xmlWriter.write(getConfigurationDocument());
	}

	/**
	 * Sets the name of the file to auto save the configuration document to. If
	 * you set the file name to <code>null</code> then you specify that you
	 * don't want to use the auto save feature.
	 * 
	 * @param fileName
	 *            the name of the file to auto save the configuration document
	 *            to or <code>null</code> if you want to disable the autosave
	 *            feature
	 */
	public void setAutoSaveFileName(String fileName) {
		this.autoSaveFileName = fileName;
	}

	/**
	 * The name of the file that auto saving feature is saving to.
	 * 
	 * @return the name of the file that this instance is saving the
	 *         configuration document to or <code>null</code> if the instance
	 *         is not auto saving the configuration document
	 */
	public String getAutoSaveFileName() {
		return autoSaveFileName;
	}

}
