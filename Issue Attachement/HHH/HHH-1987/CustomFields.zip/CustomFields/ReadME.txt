Directory Structure:
====================
Implementation		--> "Custom Fields Support for Hibernate & Spring"
Sample Application	--> An Eclipse Project that contains source code for a sample Spring/Hibernate Application with "Custom Fields" support

How to Run "Custom Fields" Sample Application?
=============================================
1- Change hibernate properties in Application Context to suite your Database configurations
2- Run test.User

About "Custom Fields":
======================
What is it?
=======
Custom Fields Support means the ability to add custom fields to existing hibernate entities in runtime without modifying .hbm files or even recompilling the classes.

Problem Example:
=============
Assume an enterprise application that contains information about a company's customers. When the enterprise application was developed, the communication between the company and its customers was through phone calls. As the company become larger and is now making business overseas, they now have customers outside their country and some business is now  done through emails. Unfortunately, the old enterprise application that the company was using doesn't support "Custom Fields" so, they had to call back the software company which has developed this application in order to request these new updates in their data model.

Scenario if "Custom Fields" was supported:
=============================
When any enterprise that is using an application that support "Custom Fields" needs to add attributes for their existing entities, they will just need to open the "Settings" page of their application and add these new fields to existing entity then they restart the application. The new fields are now ready to use!

How to Design an Application with "Custom Fields" support?
========================================
1- All Hibernate Entities that will need to have "Custom Fields" supported will need to implement an interface called "ExtensibleEntity" or they can inherit from "DefaultExtensibleEntity"
2- In hibernate configuration, you need to set the property "hibernate.hbm2ddl.auto" to "update"
3- For Hibernate Applications, use "CustomFieldsConfiguration" to build session factories.
For Spring Applications, use "SpringCustomFieldsFactoryBean" to build LocalSessionFactoryBean.
4- The UI should have pages for adding custom fields which will call the methods provided in "CustomFieldsConfiguration" or "SpringCustomFieldsFactoryBean".

Current Implementation:
=================
The current implementation enables "Custom Fields" support to hibernate or spring applications that are using hibernate for persistent.

Current Limitations:
==============
The current implementation only supports adding new custom fields of premitive types.