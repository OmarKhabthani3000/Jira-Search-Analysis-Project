package com.opencraft.util.hibernate.customfields.property;

import java.util.HashMap;

import org.hibernate.PropertyNotFoundException;
import org.hibernate.property.Getter;
import org.hibernate.property.PropertyAccessor;
import org.hibernate.property.Setter;

/**
 * This class is an accessor for custom fields.
 * 
 * @author Ali El Gamal
 * @version 0.1
 */
public final class CustomPropertyAccessor implements PropertyAccessor {

	HashMap<Class, HashMap<String, Getter>> getters = new HashMap<Class, HashMap<String, Getter>>();

	HashMap<Class, HashMap<String, Setter>> setters = new HashMap<Class, HashMap<String, Setter>>();

	public Getter getGetter(Class clazz, String property)
			throws PropertyNotFoundException {
		HashMap<String, Getter> classGetters = getters.get(clazz);
		if (classGetters == null) {
			classGetters = new HashMap<String, Getter>();
			getters.put(clazz, classGetters);
		}
		Getter propertyGetter = classGetters.get(property);
		if (propertyGetter == null) {
			propertyGetter = new CustomPropertyGetter(property);
			classGetters.put(property, propertyGetter);
		}
		return propertyGetter;
	}

	public Setter getSetter(Class clazz, String property)
			throws PropertyNotFoundException {
		HashMap<String, Setter> classSetters = setters.get(clazz);
		if (classSetters == null) {
			classSetters = new HashMap<String, Setter>();
			setters.put(clazz, classSetters);
		}
		Setter propertySetter = classSetters.get(property);
		if (propertySetter == null) {
			propertySetter = new CustomPropertySetter(property);
			classSetters.put(property, propertySetter);
		}
		return propertySetter;
	}

}
