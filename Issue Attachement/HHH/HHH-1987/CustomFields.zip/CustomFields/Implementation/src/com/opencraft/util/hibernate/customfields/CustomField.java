package com.opencraft.util.hibernate.customfields;

import java.util.Iterator;

import org.dom4j.Element;
import org.hibernate.mapping.Column;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;
import org.hibernate.mapping.SimpleValue;
import org.hibernate.mapping.Table;
import org.hibernate.mapping.Value;

import com.opencraft.util.hibernate.customfields.property.CustomPropertyAccessor;

/**
 * This class represent a custom field
 * 
 * @author Ali El Gamal
 * @version 0.1
 * 
 */
public class CustomField {

	private final String fieldName;

	private final Value fieldValue;

	private final Class containingType;

	/**
	 * Creates a new custom field with the specified name & type
	 * 
	 * @param fieldName
	 *            the name of the field
	 * @param fieldValue
	 *            contains information about the values thid field can contain
	 * @param containingType
	 *            The class that has this custom field
	 * @throws IllegalArgumentException
	 *             If the specified <code>containingType</code> doesn't
	 *             implement {@link ExtensibleEntity}
	 */
	public CustomField(String fieldName, Value fieldValue, Class containingType)
			throws IllegalArgumentException {
		this.fieldName = fieldName;
		this.fieldValue = fieldValue;
		this.containingType = containingType;
		if (!ExtensibleEntity.class.isAssignableFrom(containingType))
			// The class specified in the document is not extensible
			throw new IllegalArgumentException("Class "
					+ containingType.getName()
					+ " does not implement interface Extensible");
	}

	/**
	 * Creates a new instance of <code>CustomField</code> that has a simple
	 * value.
	 * 
	 * @param fieldName
	 *            the name of the custom field
	 * @param fieldType
	 *            the name of the field's type
	 * @param columnName
	 *            the name of the field's column
	 * @param containingType
	 *            the class that contains this custom field
	 */
	public CustomField(String fieldName, String fieldType, String columnName,
			Class containingType) {
		this.fieldName = fieldName;
		SimpleValue sv = new SimpleValue();
		sv.addColumn(new Column(columnName));
		sv.setTypeName(fieldType);
		this.fieldValue = sv;
		this.containingType = containingType;
		if (!ExtensibleEntity.class.isAssignableFrom(containingType))
			// The class specified in the document is not extensible
			throw new IllegalArgumentException("Class "
					+ containingType.getName()
					+ " does not implement interface Extensible");
	}

	/**
	 * Constructs a <code>CustomField</Code> from an XML DOM4J element.
	 * @param propertyElement The property element of the field
	 * @param containingType The class containing the new <code>CustomField</code>
	 */
	CustomField(Element propertyElement, Class containingType) {
		this.fieldName = propertyElement.attributeValue("name");
		this.containingType = containingType;
		SimpleValue sv = new SimpleValue();
		this.fieldValue = sv;
		sv.setTypeName(propertyElement.attributeValue("type"));
		Column col = new Column(this.fieldName);
		sv.addColumn(col);
		if (!ExtensibleEntity.class.isAssignableFrom(containingType))
			// The class specified in the document is not extensible
			throw new IllegalArgumentException("Class "
					+ containingType.getName()
					+ " does not implement interface extensible");
	}

	/**
	 * Determines the name of the field
	 * 
	 * @return the field name
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * Determines the class that has this custom field
	 * 
	 * @return The class containing this custom field
	 */
	public Class getContainingType() {
		return containingType;
	}

	/**
	 * Determines the information about this custom field values
	 * 
	 * @return an object implementing <code>org.hibernate.mapping.Value</code>
	 *         containing information about this values of this custom field.
	 */
	public Value getValue() {
		return fieldValue;
	}

	/**
	 * Return an equivelant <code>org.hibernate.mapping.Property</code> object
	 * to this <code>CustomField</code><br>
	 * If the value of this property is of type
	 * <code>org.hibernate.mapping.SimpleValue</code> this method will also
	 * set its table property and add the columns of this value to the table.
	 * 
	 * @param oc
	 *            The persistent class that this instace is for
	 * @return A <code>Property</code> Object equiveant to this
	 *         <code>CustomField</code>
	 */
	Property getProperty(PersistentClass pc) throws IllegalArgumentException {
		if (!pc.getClassName().equals(getContainingType().getName()))
			throw new IllegalArgumentException(
					"The Persistent Class must be for the class "
							+ getContainingType());
		// Building the Property
		Property p = new Property();
		p.setName(getFieldName());
		p.setNodeName(getFieldName());
		Value value = getValue();
		p.setValue(value);
		String propertyAccessorName = CustomPropertyAccessor.class.getName();
		p.setPropertyAccessorName(propertyAccessorName);
		// If the property is simple Property we need to add its columns to the
		// persistent class table
		if (value instanceof SimpleValue) {
			Table table = pc.getTable();
			((SimpleValue) value).setTable(table);
			for (Iterator itr = value.getColumnIterator(); itr.hasNext();) {
				Column col = (Column) itr.next();
				table.addColumn(col);
			}
		}
		// TODO find what you need to do in order to support Collection Values
		return p;
	}

	@Override
	/**
	 * Overriden in order to compare the field name & the containing type.
	 * 
	 * @param o
	 *            the object to be compared
	 * @return <code>true</code> if the passed object is an instance of
	 *         <code>CustomField</code> and the field name of the passed
	 *         object is the same as this one. Also, the two custom fields are
	 *         for the same class. <code>false</code> otherwise.
	 */
	public boolean equals(Object o) {
		if (o instanceof CustomField) {
			CustomField cf = (CustomField) o;
			return cf.getFieldName().equals(getFieldName())
					&& cf.getContainingType().equals(getContainingType());
		}
		return false;
	}

	@Override
	/**
	 * calculates the hash code for this <code>CustomField</code><br>
	 * The hash code is calculated as the summation of the hash code of the
	 * field name and the containing type.
	 * 
	 * @return the hash code of this <code>CustomField</code>
	 */
	public int hashCode() {
		return getFieldName().hashCode() + getContainingType().hashCode();
	}
}
