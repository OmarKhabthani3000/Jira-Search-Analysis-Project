package com.opencraft.util.hibernate.customfields;

/**
 * This interface should be implemented by all classes that represent hibernate
 * entities in order to have custom fields support.
 * 
 * @author Ali El Gamal
 * @version 0.1
 */
public interface ExtensibleEntity {

	/**
	 * Returns the value of the custom field.<br>
	 * <b>Note:</b> This method will return <code>null</code> if the custom
	 * field doesn't exist in this entity or if it exists and it has no value.
	 * 
	 * @param customField
	 *            the custom fields to get its value
	 * @return the value of the custom field
	 */
	public Object getCustomFieldValue(String customField);

	/**
	 * Sets the value of a custom field.<br>
	 * <b>Note:</b> if the custom field is not specified for the session
	 * factory from which you have retrieved this entity. The custom field value
	 * will be saved in memory by not in the DB.
	 * 
	 * @param customField
	 *            The custom field to set its value
	 * @param value
	 *            the value to be set to the custom field
	 */
	public void setCustomFieldValue(String customField, Object value);

}
