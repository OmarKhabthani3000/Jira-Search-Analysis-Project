package com.opencraft.util.hibernate.customfields.spring;

import java.util.Set;

import org.springframework.orm.hibernate3.LocalSessionFactoryBean;

import com.opencraft.util.hibernate.customfields.CustomField;
import com.opencraft.util.hibernate.customfields.CustomFieldsConfiguration;

/**
 * This class provides Custom Fields support for Spring/Hibenate applications.<br>
 * To add CustomFields Support to Spring/Hibernate applications follow the next
 * steps:<br>
 * <ol>
 * <li> Declare a bean of this class in the application context. This can be
 * done by adding the following to the application context configuration:<br>
 * <code>
 &lt;bean 	id="customFieldsSupporter"
 &nbsp;&nbsp;&nbsp;&nbsp;class="com.opencraft.util.hibernate.customfields.spring.SpringCustomFieldsSupporter"&gt;
 <br>
 &nbsp;&nbsp;&nbsp;&nbsp;&lt;property name="configurationFileName"&gt;
 <br>
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;value&gt;customfields.cfg.xml&lt;/value&gt;
 <br>
 &nbsp;&nbsp;&nbsp;&nbsp;&lt;/property&gt;
 <br>
 &nbsp;&nbsp;&nbsp;&nbsp;&lt;property name="autoSaveFileName"&gt;
 <br>
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;value&gt;customfields.cfg.xml&lt;/value&gt;
 <br>
 &nbsp;&nbsp;&nbsp;&nbsp;&lt;/property&gt;
 <br>
 &lt;/bean&gt;
 <br>
 </code> </li>
 * <li> Configure your LocalSessionBeanFactory to be instantiated from
 * customFieldSupporter. This can be done by adding the attribute
 * <code>factory-bean</code> equals to the name of the
 * <code>CustomFieldsSupporterBean</code> and the attribute
 * <code>factory-method</code> equals to
 * <code>getLocalSessionFactoryBean</code> </li>
 * <li> To Add or Query on custom fields, you need to use
 * {@link #addCustomField(CustomField)} & {@link #getCustomFields(Class)} from
 * the <code>SpringCustomFieldsSupporter</code> object. </li>
 * <li> When you add a custom field, It will not be actually be added until the
 * next restart of the spring application. </li>
 * </ol>
 * 
 * @author Ali El Gamal
 * @version 0.1
 */
public class SpringCustomFieldsSupporter {

	private CustomFieldsLocalSessionFactoryBean factoryBean = new CustomFieldsLocalSessionFactoryBean();

	/**
	 * Returns an instance of
	 * <code>org.springframework.orm.hibernate3.LocalSessionFactoryBean</code>
	 * 
	 * @return The hibernate <code>LocalSessionFactoryBean</code> that should
	 *         be used by the spring application to have custom fields support
	 */
	public LocalSessionFactoryBean getLocalSessionFactoryBean() {
		return factoryBean;
	}

	/**
	 * It actually calls
	 * {@link CustomFieldsConfiguration#addCustomField(CustomField)}
	 * 
	 * @param cf
	 *            the CustomField that will be passed to
	 *            {@link CustomFieldsConfiguration#addCustomField(CustomField)}
	 */
	public void addCustomField(CustomField cf) {
		((CustomFieldsConfiguration) factoryBean.getConfiguration())
				.addCustomField(cf);
	}

	/**
	 * It actually calls
	 * {@link CustomFieldsConfiguration#getCustomFields(Class)}
	 * 
	 * @param c
	 *            the calls that will be passed to
	 *            {@link CustomFieldsConfiguration#getCustomFields(Class)}
	 * @return the result of
	 *         {@link CustomFieldsConfiguration#getCustomFields(Class)}
	 */
	public Set<CustomField> getCustomFields(Class c) {
		return ((CustomFieldsConfiguration) factoryBean.getConfiguration())
				.getCustomFields(c);
	}

	/**
	 * Sets the name of the xml that contains the Custom Fields configuration
	 * document.
	 * 
	 * @param configurationFileName
	 *            the configuration file name
	 */
	public void setConfigurationFileName(String configurationFileName) {
		factoryBean.setConfigurationFileName(configurationFileName);
	}

	/**
	 * Determines the name of the configuration file that will be used by any
	 * new <code>Configuration</code> objects retrieved from
	 * <code>org.springframework.orm.hibernate3.LocalSessionFactoryBean.newConfiguration</code>
	 * 
	 * @return the name of the configuration file or <code>null</code> if it
	 *         will not use any configuration file
	 */
	public String getConfigurationFileName() {
		return factoryBean.getConfigurationFileName();
	}

	/**
	 * Sets the name of the file that all <code>Configuration</code> objects
	 * retrieved from subsequent calls to
	 * <code>org.springframework.orm.hibernate3.LocalSessionFactoryBean.newConfiguration</code>
	 * will auto save their configuration document to.<br>
	 * If you passed <code>null</code> instead of the file name, you then
	 * specify that you don't want to use the auto save feature
	 * 
	 * @see CustomFieldsConfiguration#setAutoSaveFileName(String)
	 * 
	 * @param fileName
	 *            the name of the to auto save the configuration files to
	 */
	public void setAutoSaveFileName(String fileName) {
		factoryBean.setAutoSaveFileName(fileName);
	}

	/**
	 * Determines the name of the file that will be used for the autosave
	 * feature of subsequesnt <code>Configuration</code> objects from
	 * 
	 * @see CustomFieldsConfiguration#getAutoSaveFileName()
	 * @return the name of the file that the auto save feature of subsequent
	 *         <code>Configuration</code> objects retrieved from
	 *         <code>org.springframework.orm.hibernate3.LocalSessionFactoryBean.newConfiguration</code>
	 *         will save to or <code>null</code> if the autosave feature will
	 *         be disabled
	 */
	public String getAutoSaveFileName() {
		return factoryBean.getAutoSaveFileName();
	}
}
