package com.opencraft.util.hibernate.customfields;

import java.util.HashMap;

/**
 * This class provides a default and simple way for entities to implement
 * {@link ExtensibleEntity}
 * 
 * @author Ali El Gamal
 * @version 0.1
 */
public class DefaultExtensibleEntity implements ExtensibleEntity {

	/**
	 * Stores values of customFieldValues
	 */
	protected HashMap<String, Object> customFieldValues = new HashMap<String, Object>();

	public Object getCustomFieldValue(String customField) {
		return customFieldValues.get(customField);
	}

	public void setCustomFieldValue(String customField, Object value) {
		customFieldValues.put(customField, value);
	}

}
