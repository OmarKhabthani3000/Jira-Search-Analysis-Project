package com.opencraft.util.hibernate.customfields.property;

import java.lang.reflect.Method;

import org.hibernate.HibernateException;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.property.Setter;

import com.opencraft.util.hibernate.customfields.ExtensibleEntity;

/**
 * This class is a setter for custom fields
 * 
 * @author Ali El Gamal
 * @version 0.1
 */
public class CustomPropertySetter implements Setter {

	private static final long serialVersionUID = -3949383087833610604L;

	/**
	 * The name of the property that this <code>CustomPropertySetter</code>
	 * can set.
	 */
	public final String propertyName;

	/**
	 * Creates a new <code>CustomPropertySetter</code> that sets the specified
	 * property name.
	 * 
	 * @param propertyName
	 *            The name of the property that this setter should set.
	 */
	public CustomPropertySetter(String propertyName) {
		this.propertyName = propertyName;
	}

	public Method getMethod() {
		// Optional Method as specified by the interface
		// org.hibernate.property.Setter
		return null;
	}

	public String getMethodName() {
		// Optional Method as specified by the interface
		// org.hibernate.property.Setter
		return null;
	}

	public void set(Object obj, Object value,
			SessionFactoryImplementor sessionFactory) throws HibernateException {
		((ExtensibleEntity) obj).setCustomFieldValue(propertyName, value);
	}

}
