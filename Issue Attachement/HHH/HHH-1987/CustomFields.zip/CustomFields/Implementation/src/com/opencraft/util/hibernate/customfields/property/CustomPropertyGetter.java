package com.opencraft.util.hibernate.customfields.property;

import java.lang.reflect.Method;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.property.Getter;

import com.opencraft.util.hibernate.customfields.ExtensibleEntity;

/**
 * This class is a getter for custom Fields
 * 
 * @author Ali El Gamal
 * @version 0.1
 */
class CustomPropertyGetter implements Getter {

	private static final long serialVersionUID = 5844709710121600333L;

	/**
	 * The property that this getter is used to retrieve
	 */
	public final String propertyName;

	/**
	 * Creates a new <code>CustomPropertyGetter</code> that retrieves the
	 * specified property name.
	 * 
	 * @param propertyName
	 *            the name of the property that this getter should retrieve
	 */
	CustomPropertyGetter(String propertyName) {
		this.propertyName = propertyName;
	}

	public Object get(Object obj) throws HibernateException {
		return ((ExtensibleEntity) obj).getCustomFieldValue(propertyName);
	}

	public Object getForInsert(Object obj, Map arg1, SessionImplementor arg2)
			throws HibernateException {
		return get(obj);
	}

	public Method getMethod() {
		// Optional Method as specified by the interface
		// org.hibernate.property.Getter
		return null;
	}

	public String getMethodName() {
		// Optional Method as specified by the interface
		// org.hibernate.property.Getter
		return null;
	}

	public Class getReturnType() {
		// Optional Method as specified by the interface
		// org.hibernate.property.Getter
		return null;
	}

}
