package com.opencraft.util.hibernate.customfields.spring;

import org.hibernate.HibernateException;
import org.hibernate.cfg.Configuration;
import org.springframework.orm.hibernate3.LocalSessionFactoryBean;

import com.opencraft.util.hibernate.customfields.CustomFieldsConfiguration;

/**
 * This class provides Custom Fields for Spring/Hibernate Applications. Use
 * instances of this class instead of
 * <code>org.springframework.orm.hibernate3.LocalSessionFactoryBean</code>
 * 
 * @author Ali El Gamal
 * @version 0.1
 */
class CustomFieldsLocalSessionFactoryBean extends LocalSessionFactoryBean {

	private String configurationFileName;

	private String autoSaveFileName;

	private CustomFieldsConfiguration cfc;

	@Override
	/**
	 * Creates a new <code>Configuration</code> cbject that support Custom
	 * Fields
	 * 
	 * @see CustomFieldsLocalSessionFactoryBean#setConfigurationFileName(String)
	 * @see CustomFieldsLocalSessionFactoryBean#setAutoSaveFileName(String)
	 */
	protected Configuration newConfiguration() throws HibernateException {
		// If we already have a configuration object, just return it
		if (cfc != null)
			return cfc;

		if (configurationFileName == null)
			cfc = new CustomFieldsConfiguration();
		else {
			try {
				cfc = new CustomFieldsConfiguration(configurationFileName);
			} catch (Exception e) {
				throw new HibernateException(e);
			}
		}

		cfc.setAutoSaveFileName(getAutoSaveFileName());
		return cfc;
	}

	@Override
	public Configuration getConfiguration() {
		if (cfc == null)
			newConfiguration();
		return cfc;
	}

	/**
	 * Sets the name of the xml that contains the Custom Fields configuration
	 * document.
	 * 
	 * @param configurationFileName
	 *            the configuration file name
	 */
	public void setConfigurationFileName(String configurationFileName) {
		this.configurationFileName = configurationFileName;
	}

	/**
	 * Determines the name of the configuration file that will be used by any
	 * new <code>Configuration</code> objects retrieved from
	 * {@link #newConfiguration()}
	 * 
	 * @return the name of the configuration file or <code>null</code> if it
	 *         will not use any configuration file
	 */
	public String getConfigurationFileName() {
		return this.configurationFileName;
	}

	/**
	 * Sets the name of the file that all <code>Configuration</code> objects
	 * retrieved from subsequent calls to {@link #newConfiguration()} will auto
	 * save their configuration document to.<br>
	 * If you passed <code>null</code> instead of the file name, you then
	 * specify that you don't want to use the auto save feature
	 * 
	 * @see CustomFieldsConfiguration#setAutoSaveFileName(String)
	 * 
	 * @param fileName
	 *            the name of the to auto save the configuration files to
	 */
	public void setAutoSaveFileName(String fileName) {
		this.autoSaveFileName = fileName;
	}

	/**
	 * Determines the name of the file that will be used for the autosave
	 * feature of subsequesnt <code>Configuration</code> objects from
	 * 
	 * @see CustomFieldsConfiguration#getAutoSaveFileName()
	 * @return the name of the file that the auto save feature of subsequent
	 *         <code>Configuration</code> objects retrieved from
	 *         {@link #newConfiguration()} will save to or <code>null</code>
	 *         if the autosave feature will be disabled
	 */
	public String getAutoSaveFileName() {
		return autoSaveFileName;
	}
}
