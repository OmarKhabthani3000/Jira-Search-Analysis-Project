package com.xyz.junit.jpa;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicInsert
@DynamicUpdate
@Table( name = "`Article`" )
public class Article
{
  @Id
  @GeneratedValue( strategy = GenerationType.SEQUENCE )
  @SequenceGenerator( name = "SEQ_Article", sequenceName = "`SEQ_Article`", allocationSize = 50 )
  @Column( name = "`ID`" )
  private Long                       id                   = null;

  @Column( name = "`Identifier`" )
  private String                     identifier           = null;

  @OneToMany( mappedBy = "article", cascade = CascadeType.ALL, fetch = FetchType.LAZY )
  private Set< ArticleAttribute >    articleAttributes    = new HashSet< ArticleAttribute >();

  @OneToMany( mappedBy = "article", cascade = CascadeType.ALL, fetch = FetchType.LAZY )
  private Set< ArticleStructureMap > articleStructureMaps = new HashSet< ArticleStructureMap >();

  public Long getId()
  {
    return this.id;
  }

  public void setId( Long newId )
  {
    this.id = newId;
  }

  public String getIdentifier()
  {
    return this.identifier;
  }

  public void setIdentifier( String newIdentifier )
  {
    this.identifier = newIdentifier;
  }

  public Set< ArticleAttribute > getArticleAttributes()
  {
    return this.articleAttributes;
  }

  public void setArticleAttributes( Set< ArticleAttribute > articleAttributes )
  {
    this.articleAttributes = articleAttributes;
  }

  public Set< ArticleStructureMap > getArticleStructureMaps()
  {
    return this.articleStructureMaps;
  }

  public void setArticleStructureMaps( Set< ArticleStructureMap > articleStructureMaps )
  {
    this.articleStructureMaps = articleStructureMaps;
  }
}
