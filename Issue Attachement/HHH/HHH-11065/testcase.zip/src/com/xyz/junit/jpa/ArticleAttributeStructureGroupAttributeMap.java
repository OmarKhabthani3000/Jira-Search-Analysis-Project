package com.xyz.junit.jpa;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicInsert
@DynamicUpdate
@Table( name = "`ArtAttrStructGrpAttrMap`" )
public class ArticleAttributeStructureGroupAttributeMap
{
  @Id
  @GeneratedValue( strategy = GenerationType.SEQUENCE )
  @SequenceGenerator( name = "SEQ_ArtAttrStructGrpAttrMap", sequenceName = "`SEQ_ArtAttrStructGrpAttrMap`", allocationSize = 50 )
  @Column( name = "`ID`" )
  private Long                id                  = null;

  @ManyToOne( fetch = FetchType.LAZY, optional = false )
  @JoinColumn( name = "`ArticleAttributeID`", nullable = false )
  private ArticleAttribute    articleAttribute    = null;

  @ManyToOne( fetch = FetchType.LAZY, optional = false )
  @JoinColumn( name = "`ArticleStructureMapID`", nullable = false )
  private ArticleStructureMap articleStructureMap = null;

  @Column( name = "`StructureGroupID`" )
  private Long                structureGroupId    = null;

  public Long getId()
  {
    return this.id;
  }

  public void setId( Long newId )
  {
    this.id = newId;
  }

  public ArticleAttribute getArticleAttribute()
  {
    return this.articleAttribute;
  }

  public void setArticleAttribute( ArticleAttribute newArticleAttribute )
  {
    this.articleAttribute = newArticleAttribute;
  }

  public Long getStructureGroupId()
  {
    return this.structureGroupId;
  }

  public void setStructureGroupId( Long newStructureGroupId )
  {
    this.structureGroupId = newStructureGroupId;
  }

  public void setArticleStructureMap( ArticleStructureMap articleStructureMap )
  {
    this.articleStructureMap = articleStructureMap;
  }

  public ArticleStructureMap getArticleStructureMap()
  {
    return this.articleStructureMap;
  }
}
