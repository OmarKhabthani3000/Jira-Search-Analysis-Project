package com.xyz.junit;

import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.Session;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.xyz.junit.jpa.Article;
import com.xyz.junit.jpa.ArticleAttribute;
import com.xyz.junit.jpa.ArticleAttributeStructureGroupAttributeMap;
import com.xyz.junit.jpa.ArticleStructureMap;

@SuppressWarnings( "nls" )
public class JPAUnitTestCase
{
  private EntityManagerFactory entityManagerFactory;

  @Before
  public void init()
  {
    this.entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
  }

  @After
  public void destroy()
  {
    this.entityManagerFactory.close();
  }

  @Test
  @SuppressWarnings( "resource" )
  public void hhh11065Test() throws Exception
  {
    EntityManager entityManager = this.entityManagerFactory.createEntityManager();
    Session session = entityManager.unwrap( Session.class );
    EntityTransaction tx = entityManager.getTransaction();
    tx.begin();

    //create parents
    Article a = new Article();
    a.setIdentifier( "TestArticle" );

    ArticleAttribute aa = new ArticleAttribute();
    aa.setIdentifier( "TestAttribute" );
    aa.setArticle( a );
    a.getArticleAttributes()
     .add( aa );

    session.merge( a );
    entityManager.flush();
    tx.commit();

    tx.begin();

    a = entityManager.createQuery( " from Article a", Article.class )
                     .getSingleResult();
    Set< ArticleAttribute > persistedAas = a.getArticleAttributes();
    Assert.assertEquals( persistedAas.size(), 1 );

    aa = persistedAas.iterator()
                     .next();

    //create children
    ArticleStructureMap asm = new ArticleStructureMap();
    asm.setStructureGroupId( 1L );
    asm.setArticle( a );
    a.getArticleStructureMaps()
     .add( asm );

    ArticleAttributeStructureGroupAttributeMap aasgam = new ArticleAttributeStructureGroupAttributeMap();
    aasgam.setStructureGroupId( 1L );
    aasgam.setArticleAttribute( aa );
    aasgam.setArticleStructureMap( asm );

    asm.getArticleAttributeStructureGroupAttributeMaps()
       .add( aasgam );
    aa.getArticleAttributeStructureGroupAttributeMaps()
      .add( aasgam );

    session.merge( a );
    entityManager.flush();

    tx.commit();

    //check parent - child relation
    tx.begin();
    a = entityManager.createQuery( " from Article a", Article.class )
                     .getSingleResult();
    persistedAas = a.getArticleAttributes();
    aa = persistedAas.iterator()
                     .next();
    Set< ArticleAttributeStructureGroupAttributeMap > persistedAasgams = aa.getArticleAttributeStructureGroupAttributeMaps();
    Assert.assertEquals( persistedAasgams.size(), 1 );
    aasgam = persistedAasgams.iterator()
                             .next();
    Assert.assertEquals( aasgam.getArticleAttribute()
                               .getId(), aa.getId() );

    Set< ArticleStructureMap > persistedAsms = a.getArticleStructureMaps();
    Assert.assertEquals( persistedAsms.size(), 1 );
    asm = persistedAsms.iterator()
                       .next();
    Assert.assertEquals( aasgam.getArticleStructureMap()
                               .getId(), asm.getId() );
    tx.commit();

    entityManager.close();
  }
}
