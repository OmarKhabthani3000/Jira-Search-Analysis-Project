package com.xyz.junit.jpa;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@DynamicInsert
@DynamicUpdate
@Table( name = "`ArticleAttribute`" )
public class ArticleAttribute
{
  @Id
  @GeneratedValue( strategy = GenerationType.SEQUENCE )
  @SequenceGenerator( name = "SEQ_ArticleAttribute", sequenceName = "`SEQ_ArticleAttribute`", allocationSize = 50 )
  @Column( name = "`ID`" )
  private Long                                              id                                          = null;

  @ManyToOne( fetch = FetchType.LAZY )
  @JoinColumn( name = "`ArticleID`", nullable = false )
  private Article                                           article                                     = null;

  @Column( name = "`Identifier`" )
  private String                                            identifier                                  = null;

  @OneToMany( mappedBy = "articleAttribute", cascade = CascadeType.ALL, fetch = FetchType.LAZY )
  @Fetch( FetchMode.SUBSELECT )
  private Set< ArticleAttributeStructureGroupAttributeMap > articleAttributeStructureGroupAttributeMaps = new HashSet< ArticleAttributeStructureGroupAttributeMap >();

  public Long getId()
  {
    return this.id;
  }

  public void setId( Long newId )
  {
    this.id = newId;
  }

  public String getIdentifier()
  {
    return this.identifier;
  }

  public void setIdentifier( String newIdentifier )
  {
    this.identifier = newIdentifier;
  }

  public Article getArticle()
  {
    return this.article;
  }

  public void setArticle( Article newArticle )
  {
    this.article = newArticle;
  }

  public Set< ArticleAttributeStructureGroupAttributeMap > getArticleAttributeStructureGroupAttributeMaps()
  {
    return this.articleAttributeStructureGroupAttributeMaps;
  }

  public void setArticleAttributeStructureGroupAttributeMaps( Set< ArticleAttributeStructureGroupAttributeMap > newArticleAttributeStructureGroupAttributeMaps )
  {
    this.articleAttributeStructureGroupAttributeMaps = newArticleAttributeStructureGroupAttributeMaps;
  }
}
