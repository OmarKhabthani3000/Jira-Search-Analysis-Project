package com.xyz.junit.jpa;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicInsert
@DynamicUpdate
@Table( name = "`ArticleStructureMap`" )
public class ArticleStructureMap
{
  @Id
  @GeneratedValue( strategy = GenerationType.SEQUENCE )
  @SequenceGenerator( name = "SEQ_ArticleStructureMap", sequenceName = "`SEQ_ArticleStructureMap`", allocationSize = 50 )
  @Column( name = "`ID`" )
  private Long                                              id                                          = null;

  @ManyToOne( fetch = FetchType.LAZY )
  @JoinColumn( name = "`ArticleID`", nullable = false )
  private Article                                           article                                     = null;

  @Column( name = "`StructureGroupID`" )
  private Long                                              structureGroupId                            = null;

  @OneToMany( mappedBy = "articleStructureMap", cascade = CascadeType.ALL, fetch = FetchType.LAZY )
  private Set< ArticleAttributeStructureGroupAttributeMap > articleAttributeStructureGroupAttributeMaps = new HashSet< ArticleAttributeStructureGroupAttributeMap >();

  public Long getId()
  {
    return this.id;
  }

  public void setId( Long newId )
  {
    this.id = newId;
  }

  public Article getArticle()
  {
    return this.article;
  }

  public void setArticle( Article newArticle )
  {
    this.article = newArticle;
  }

  public Long getStructureGroupId()
  {
    return this.structureGroupId;
  }

  public void setStructureGroupId( Long newStructureGroupId )
  {
    this.structureGroupId = newStructureGroupId;
  }

  public Set< ArticleAttributeStructureGroupAttributeMap > getArticleAttributeStructureGroupAttributeMaps()
  {
    return this.articleAttributeStructureGroupAttributeMaps;
  }

  public void setArticleAttributeStructureGroupAttributeMaps( Set< ArticleAttributeStructureGroupAttributeMap > newArticleAttributeStructureGroupAttributeMaps )
  {
    this.articleAttributeStructureGroupAttributeMaps = newArticleAttributeStructureGroupAttributeMaps;
  }
}
