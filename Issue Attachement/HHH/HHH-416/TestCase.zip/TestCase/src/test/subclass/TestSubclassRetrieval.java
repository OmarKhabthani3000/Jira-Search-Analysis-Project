package test.subclass;

import junit.framework.TestCase;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class TestSubclassRetrieval extends TestCase {
	
	Logger logger = Logger.getLogger(TestSubclassRetrieval.class);
	/** The single instance of hibernate SessionFactory */
	
	private static SessionFactory sessionFactory;
	private static Session session;
	

	
	public void testSubclassUsingGet() throws Exception {
		Object partner = (Partner) getSession().get(Partner.class,new Long(1));
		assertNull(partner);
		logger.info(partner + " = null");	
	}
	public void testSubclassUsingLoad() throws Exception {
		Object partner =  getSession().load(Partner.class,new Long(1));
		assertNull(partner);
		logger.info(partner + " = null");	
	}
	public void testSubclassUsingCriteria() throws Exception {
		Object partner = getSession().createCriteria(Partner.class)
		                                            .add(Restrictions.eq("personId",new Long(1)))
		                                            .uniqueResult();
		assertNull(partner);
		logger.info(partner + " = null");		
	}	
	
	protected void setUp() throws Exception {
		super.setUp();
		sessionFactory = null;
		Session session = getSession();
		Client client = new Client();
		client.setPersonName("Test Case - " + System.currentTimeMillis());
		session.save(client);
		logger.info("Client created: " + client.getPersonId() + " - " + client.getPersonName());
		session.flush();
		session.close();
	}
	
	protected void tearDown() throws Exception {
		super.tearDown();
		getSession().close();
	}

	
	private Session getSession() {

		if (session == null || !session.isOpen() ) {
			if (sessionFactory == null) {
				Configuration cfg = new Configuration()
						.addClass(Person.class)
						.setProperty("hibernate.connection.driver_class","org.hsqldb.jdbcDriver")
						.setProperty("hibernate.connection.url","jdbc:hsqldb:C:\\hsql\\test")
						.setProperty("hibernate.connection.username", "sa").setProperty("hibernate.connection.password", "")
						.setProperty("hibernate.dialect","org.hibernate.dialect.HSQLDialect")
						.setProperty("hibernate.connection.autocommit", "false")
						.setProperty("show_sql", "true").setProperty("hibernate.hbm2ddl.auto", "create-drop");
				sessionFactory = cfg.buildSessionFactory();
			}
			session = sessionFactory.openSession();
		}
		return session;
	}
}
