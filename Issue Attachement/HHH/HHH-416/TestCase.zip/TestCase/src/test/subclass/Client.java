package test.subclass;

/**
 * @author psheldon
 */
public class Client extends Person {


}
