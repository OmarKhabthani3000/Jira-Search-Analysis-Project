package test.subclass;

/**
 * @author psheldon
 */
public class Partner extends Person {

	public Partner() {
	}

}
