package com.fdv.template.web;

import java.util.Enumeration;
import java.util.logging.LogManager;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class FDVContextListener implements ServletContextListener {
	
	 public static SessionFactory sessionFactory;

	public void contextInitialized(ServletContextEvent sce) {
		initHibernate();
		
	}
	
	private void initHibernate() {
		 try {
		      // Create the SessionFactory from hibernate.cfg.xml
		      Configuration config = buildHibernateConfig();
		      //sessionFactory = config.buildSessionFactory();
		    } catch (Throwable ex) {
		      // Make sure you log the exception, as it might be swallowed
		      System.err.println("Initial SessionFactory creation failed." + ex);
		      throw new ExceptionInInitializerError(ex);
		    }
		
	}

	protected Configuration buildHibernateConfig() {
		Configuration config = new Configuration();
		if (!true){
			config.setProperty("hibernate.connection.driver_class", "oracle.jdbc.driver.OracleDriver");
			config.setProperty("hibernate.connection.url", "jdbc:oracle:thin:@localhost:1521:XE");
			config.setProperty("hibernate.connection.password", "ems-cl");
			config.setProperty("hibernate.connection.username", "ems-cl");
			config.setProperty("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect");
			System.err.println("Session programatica");
			return config;
		} else {
			System.err.println("Session por XML");
			return config.configure();
		}
	}
	

	public void contextDestroyed(ServletContextEvent sce) {
		if (sessionFactory != null){
			sessionFactory.close();
			sessionFactory=null;
		}
		unregisterDrivers();
		LogManager.getLogManager().reset();
		
	}
	
	private static void unregisterDrivers() {
//		logger.info("Desregistrando drivers JDBC");
	       // Descargar drivers JDBC de este classLoader
		String classloaderHash = Integer.toHexString(Thread.currentThread().getContextClassLoader().hashCode());
//		logger.info("Unloading drivers for classLoader: [" + classloaderHash + "]");
        try {
            for (@SuppressWarnings("rawtypes")
			Enumeration e = java.sql.DriverManager.getDrivers(); e.hasMoreElements();)
            {
                java.sql.Driver driver = (java.sql.Driver) e.nextElement();
                if (driver.getClass().getClassLoader() == Thread.currentThread().getContextClassLoader())
                {
                    try {
                        java.sql.DriverManager.deregisterDriver(driver);
//                        logger.info(driver.getClass().getName() + " unloaded.");
                    } catch (Throwable tx) {
//                    	logger.error("ERROR unloading driver " + driver + ": " + tx.getClass().getName() + " generated: " + tx.getMessage());
                    }
                }
                else {
//                	logger.warn(driver.getClass().getName() + " not unloaded (was not loaded by classloader: " + classloaderHash );
                }
            }
        } catch (Throwable e) {
//        	logger.error("Failed to cleanup ClassLoader for webapp: " + e.getMessage(),e);
        }
        
//        logger.info("Fin de desregistración drivers JDBC");	
	}	

}
