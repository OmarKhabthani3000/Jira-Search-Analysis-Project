    public static void main(String[] args) {

        Transaction tx = null;
        try {
	        Session sess = getNewTestSession();
	        tx = sess.beginTransaction();
	        List tstRecords = sess.createQuery(
	                "from TestTabel tst where " +
	                "tst.key=1580").list();
	        Iterator recordIt = tstRecords.iterator();
	        TestTabel tst = 
	        	(TestTabel)recordIt.next();
	        System.out.println("XML: "+tst.getXmlData());
	        
	        
          tst.setXmlData("Granpr� Moli�re�; 0123456789");
          sess.flush();
          tx.commit();
        } catch (Exception e) {
        	e.printStackTrace();
        }        
    }
