package com.getronics.slg.civmk.common.model;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.Date;

import nl.pinkroccade.civility.civision.stuf.StUFBericht;
import nl.pinkroccade.civility.civision.stuf.StUFStuurgegevens;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.getronics.slg.civmk.common.control.ControllerHelper;
import com.getronics.slg.civmk.common.util.Util;
import com.getronics.slg.civmk.stuf.*;
import com.getronics.slg.civmk.stuf.xml.objectgenerator.StUFBerichtGeneratorImpl;
import com.getronics.slg.civmk.stuf.xml.xmlgenerator.*;

import java.io.IOException;
import com.getronics.slg.civmk.common.util.BronBerichtNummerGenerator;

public class TestTabel
    implements Serializable {

  /** identifier field */
  private Long key;

  /** persistent field */
  private String xmlData;

  /** default constructor */
  public TestTabel() {
  }

  /**
   *            @hibernate.id
   *             generator-class="sequence"
   *             type="java.lang.Long"
   *             column="TSTKEY"
   *            @hibernate.generator-param
   *              name="sequence"
   *              value="TSTQ00"
   *
   */
  public Long getKey() {
    return this.key;
  }

  public void setKey(Long key) {
    this.key = key;
  }

  public String getXmlData() {
		return xmlData;
	  }

  public void setXmlData(String xmlData) {
    this.xmlData = xmlData;
  }

  public String toString() {
    return new ToStringBuilder(this)
        .append("key", getKey())
        .toString();
  }

  public boolean equals(Object other) {
    if (! (other instanceof TestTabel)) {
      return false;
    }
    TestTabel castOther = (TestTabel) other;
    return new EqualsBuilder()
        .append(this.getKey(), castOther.getKey())
        .isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder()
        .append(getKey())
        .toHashCode();
  }

}
