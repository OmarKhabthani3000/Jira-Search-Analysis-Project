create table tstm00 (tstkey numeric(18) not null, tstdata clob ccsid 1208);

ALTER TABLE tstM00
  add constraint tstML0 primary key  (TSTKEY);

CREATE SEQUENCE TSTQ00
as numeric(18)
minvalue 1
maxvalue 999999999999999999
start with 1
increment by 1
nocache;

insert into tstm00 values (1580, 'abc');
commit;

