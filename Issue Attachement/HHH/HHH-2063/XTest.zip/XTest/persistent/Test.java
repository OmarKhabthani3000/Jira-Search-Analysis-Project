package persistent;

// GEN-BEGIN:CLASS
public class Test
// GEN-END:CLASS
{
	
	private Long pk;

	public Long getPK() {
		return pk;
	}
	
	public void setPK(Long pk) {
		this.pk = pk;
	}
	
    // GEN-BEGIN:ATTRIBS
    // attributes
    private Integer fieldpokus;
    public static final String pokus="pokus";
    private Long fieldpokusLong;
    public static final String pokusLong="pokusLong";

    // attributes
    public Integer getPokus() {
        return this.fieldpokus;
    }

    public void setPokus(Integer pokus) {
        this.fieldpokus = pokus;
    }

    public Long getPokusLong() {
        return this.fieldpokusLong;
    }

    public void setPokusLong(Long pokusLong) {
        this.fieldpokusLong = pokusLong;
    }

    // GEN-END:ATTRIBS


// GEN-BEGIN:END_OF_CLASS Test
}
// GEN-END:END_OF_CLASS Test
