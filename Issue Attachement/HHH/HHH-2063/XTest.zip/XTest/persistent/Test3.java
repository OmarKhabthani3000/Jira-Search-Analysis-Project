// **************************************************************************
/**
 * \file  \brief
 *
 * \author Ale� PROCH�ZKA \author (C) 2006, EXADEV, Pie��any
 *
 * \date 24.8.2006 Description, history :
 *
 * \version 1 vytvorenie
 *
 */
// ****************************************************************************
package persistent;

import java.util.ArrayList;
import java.util.List;

// GEN-BEGIN:CLASS
public class Test3 extends Test
// GEN-END:CLASS
{
    // GEN-BEGIN:ATTRIBS

    // RK associations
    private List<Test2> fieldtests2 = new ArrayList<Test2>();
    public static final String tests2="tests2";

    // LNK associations
    private List<Test2> fieldtestLnk2 = new ArrayList<Test2>();
    public static final String testLnk2="testLnk2";

    // RK associations
    public List<Test2>  getTests2() {
        return this.fieldtests2;
    }

    public void setTests2(List<Test2> tests2) {
        this.fieldtests2 = tests2;
    }

    public void addToTests2(Test2 obj) {
        obj.setFkTest3(this);
    }

    public void removeFromTests2(Test2 obj) {
        if (this.fieldtests2.contains(obj))
            obj.setFkTest3(null);
    }


    // LNK associations
    public List<Test2> getTestLnk2() {
        return this.fieldtestLnk2;
    }

    public void setTestLnk2(List<Test2> testLnk2) {
        this.fieldtestLnk2 = testLnk2;
    }

    public void addToTestLnk2(Test2 obj) {
        if (!this.fieldtestLnk2.contains(obj)) {
            this.fieldtestLnk2.add(obj);
        if (!obj.getTestLnk3().contains(this))
            obj.getTestLnk3().add(this);
        }
    }

    public void removeFromTestLnk2(Test2 obj) {
        if (this.fieldtestLnk2.contains(obj)) {
            this.fieldtestLnk2.remove(obj);
            obj.getTestLnk3().remove(this);
        }
    }


    // GEN-END:ATTRIBS

// GEN-BEGIN:END_OF_CLASS Test3
}
// GEN-END:END_OF_CLASS Test3
