// **************************************************************************
/**
 * \file  \brief
 *
 * \author Ale� PROCH�ZKA \author (C) 2006, EXADEV, Pie��any
 *
 * \date 23.8.2006 Description, history :
 *
 * \version 1 vytvorenie
 *
 */
// ****************************************************************************
package persistent;


// GEN-BEGIN:CLASS
public class Test4 extends Test2
// GEN-END:CLASS
{
    // GEN-BEGIN:ATTRIBS

    // GEN-END:ATTRIBS

// GEN-BEGIN:END_OF_CLASS Test4
}
// GEN-END:END_OF_CLASS Test4
