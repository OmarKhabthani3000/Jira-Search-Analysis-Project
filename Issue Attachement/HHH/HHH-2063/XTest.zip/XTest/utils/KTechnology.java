package utils;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

public class KTechnology {
	
	private static Configuration cfg;
	
	private static SessionFactory factory = null;
	
	private static ThreadLocal<Session> threadSession = new ThreadLocal<Session>();
	
	public static void initialize(Configuration cfg) {
		if (cfg == null) 
			throw new NullPointerException();

		KTechnology.cfg = cfg;
		
		cfg.setProperty(Environment.CURRENT_SESSION_CONTEXT_CLASS, "managed");
	}
	
	public static Session getSession() {
		if (cfg == null) 
			throw new NullPointerException();
		if (factory == null)
			factory = cfg.buildSessionFactory();
		
		Session session = threadSession.get();
		if (session == null) {
			session = factory.openSession();
			threadSession.set(session);
		}
		return session;				
	}
	
	public static void closeSession() {
		Session session = threadSession.get();
		if (session != null) {
			session.flush();
			session.close();
			threadSession.remove();
		}
	}

	public static Configuration getConfiguration() {
		return cfg;
	}

}
