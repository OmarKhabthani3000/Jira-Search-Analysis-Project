package test;


import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

import persistent.Test;
import persistent.Test2;
import persistent.Test3;
import persistent.Test4;
import persistent.Test5;
import utils.KTechnology;

public class MainTest {
	
	public static void main(String[] args) {
		
		Configuration cfg = new Configuration()
		.setProperty(Environment.DIALECT, "org.hibernate.dialect.Oracle9Dialect")
		.setProperty(Environment.DRIVER, "oracle.jdbc.driver.OracleDriver")
		.setProperty(Environment.URL, "jdbc:oracle:oci8:@APOLOCAL")
		.setProperty(Environment.USER, "TEST_DC2")
		.setProperty(Environment.PASS, "TEST_DC2")
		.setProperty(Environment.CACHE_PROVIDER, "org.hibernate.cache.EhCacheProvider")
		.setProperty(Environment.USE_QUERY_CACHE, "true");
		
		KTechnology.initialize(cfg);
		
		cfg.addClass(Test.class);
		cfg.addClass(Test2.class);
		cfg.addClass(Test3.class);
		cfg.addClass(Test4.class);
		cfg.addClass(Test5.class);
		
		cfg.setProperty(Environment.HBM2DDL_AUTO, "create");
		
		cfg.setProperty(Environment.SHOW_SQL, "true");

		test();
		
		
	}

	private static void test() {
		
		Session sess = KTechnology.getSession();
		Transaction trans = sess.beginTransaction();
		Test5 t = new Test5();

		try {
			sess.saveOrUpdate(t);
			
			trans.commit();
		} catch (HibernateException e) {
			trans.rollback();
			e.printStackTrace();
		}

		t.setPokus(Integer.valueOf(100));
		
		trans = sess.beginTransaction();
		try {
			sess.saveOrUpdate(t);
			
			trans.commit();
		} catch (HibernateException e) {
			trans.rollback();
			e.printStackTrace();
		}

		KTechnology.closeSession();
		
	}

}
