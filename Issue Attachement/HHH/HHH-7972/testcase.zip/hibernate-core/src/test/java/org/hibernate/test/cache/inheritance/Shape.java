package org.hibernate.test.cache.inheritance;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


@Entity( name = "shape" )
@Inheritance( strategy = InheritanceType.JOINED )
@Cache( usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "shapes" )
public abstract class Shape
{
  private Long id;
  private String color;
  
  @Id
  public Long getId()
  {
    return id;
  }
  
  public void setId( Long id )
  {
    this.id = id;
  }

  public String getColor()
  {
    return color;
  }

  public void setColor( String color )
  {
    this.color = color;
  }
}
