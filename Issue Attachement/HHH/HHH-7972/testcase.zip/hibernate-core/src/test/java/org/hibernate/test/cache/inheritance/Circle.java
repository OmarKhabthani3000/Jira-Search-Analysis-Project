package org.hibernate.test.cache.inheritance;


import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;


@Entity( name = "circle" )
@PrimaryKeyJoinColumn
public class Circle extends Shape
{
  private double diameter;
  
  public double getDiameter()
  {
    return diameter;
  }

  public void setDiameter( double diameter )
  {
    this.diameter = diameter;
  }
}
