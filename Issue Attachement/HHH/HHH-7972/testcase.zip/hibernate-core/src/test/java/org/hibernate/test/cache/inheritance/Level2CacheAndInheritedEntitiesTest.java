package org.hibernate.test.cache.inheritance;


import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;


public class Level2CacheAndInheritedEntitiesTest extends BaseCoreFunctionalTestCase
{
  @Override
  protected Class<?>[] getAnnotatedClasses()
  {
    return new Class<?>[] { Shape.class, Circle.class, Rectangle.class };
  }
  
  @Override
  protected void configure( Configuration cfg )
  {
    super.configure( cfg );
    cfg.setProperty( Environment.CACHE_REGION_PREFIX, "" );
    cfg.setProperty( Environment.GENERATE_STATISTICS, "true" );
  }
  
  @Test
  public void testLevel2CacheDoesNotContainTheWrongEntity()
  {
    prepareObjects();
    
    Session s = openSession();
    s.beginTransaction();
    
    // make sure there is nor circle neither rectangle entity with id=1 in level2 cache
    assertFalse( sessionFactory().getCache().containsEntity( Circle.class, 1L ) );
    assertFalse( sessionFactory().getCache().containsEntity( Rectangle.class, 1L ) );
    
    // load rectangle with id=1, expect null
    assertNull( s.get( Rectangle.class, 1L ) );

    // check level2 cache again - should be empty
    assertFalse( sessionFactory().getCache().containsEntity( Circle.class, 1L ) );
    assertFalse( sessionFactory().getCache().containsEntity( Rectangle.class, 1L ) );

    // load circle with id=1, expect !null
    assertNotNull( s.get( Circle.class, 1L ) );

    // check level2 cache again - should hold circle entity
    assertTrue( sessionFactory().getCache().containsEntity( Circle.class, 1L ) );
    assertFalse( sessionFactory().getCache().containsEntity( Rectangle.class, 1L ) ); // FAILURE!!

    // close current session
    s.getTransaction().rollback();
    s.close();
  }
  
  @Test
  public void testLoadingTheWrongEntityFromLevel2Cache()
  {
    prepareObjects();
    
    Session s = openSession();
    s.beginTransaction();
    
    // make sure there is nor circle neither rectangle entity with id=1 in level2 cache
    assertFalse( sessionFactory().getCache().containsEntity( Circle.class, 1L ) );
    assertFalse( sessionFactory().getCache().containsEntity( Rectangle.class, 1L ) );
    
    // load circle with id=1, expect !null
    assertNotNull( s.get( Circle.class, 1L ) );

    // close current session
    s.getTransaction().rollback();
    s.close();
    
    // ... and open a new session
    s = openSession();
    s.beginTransaction();

    // we expect that there are no entities connected with session cache, so let's try to load rectangle
    // from the level2 cache

    // load rectangle with id=1, expect null, however it is not null -> failure
    assertNull( s.get( Rectangle.class, 1L ) ); // FAILURE!!
    
    s.getTransaction().rollback();
    s.close();
  }
  
  private void prepareObjects()
  {
    sessionFactory().getCache().evictEntityRegions();
    sessionFactory().getStatistics().clear();
    
    Session s = openSession();
    s.beginTransaction();
    
    // one circle with id=1 and no rectangles
    Circle c = new Circle();
    c.setId( 1L );
    c.setColor( "red" );
    c.setDiameter( Math.PI );
    
    s.save( c );
    
    s.getTransaction().commit();
    s.close();
  }
}
