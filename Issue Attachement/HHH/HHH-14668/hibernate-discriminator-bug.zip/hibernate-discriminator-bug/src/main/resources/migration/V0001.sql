CREATE TABLE holder (
  id UUID PRIMARY KEY
);

CREATE TABLE component (
  id UUID PRIMARY KEY,
  holder_id UUID REFERENCES holder(id),
  parent_component_id UUID REFERENCES component(id),
  component_type varchar(255),
  field_a varchar(255),
  field_b varchar(255),
  title varchar(255)
);

INSERT INTO holder (id) values('9b1fad66-35c3-44c5-b7d3-ed2c6ddf743d');

INSERT INTO component (id, holder_id, component_type, title) values
('fdeafe81-af2a-4fa7-bef6-9fb0e6e2d21c', '9b1fad66-35c3-44c5-b7d3-ed2c6ddf743d', 'CONTAINER', 'Container with 2 components');

INSERT INTO component (id, parent_component_id, component_type, field_a) values
('d1d41cd6-bbf2-4317-b9c1-7d1c48ad404a', 'fdeafe81-af2a-4fa7-bef6-9fb0e6e2d21c', 'A', 'Component A');

INSERT INTO component (id, parent_component_id, component_type, field_b) values
('a0d32282-c4b1-4e1f-a5ab-550425c85c2e', 'fdeafe81-af2a-4fa7-bef6-9fb0e6e2d21c', 'B', 'Component B');