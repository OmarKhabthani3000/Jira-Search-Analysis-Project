package org.example.configs;

import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.configuration.FluentConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@EnableJpaRepositories(basePackages = "org.example.repositories")
@EnableTransactionManagement
public class JpaConfiguration {

    @Bean
    public Flyway flyway(DataSource dataSource) {
        FluentConfiguration cfg = new FluentConfiguration();
        cfg.locations("migration/");
        cfg.dataSource(dataSource);
        cfg.outOfOrder(true);
        return new Flyway(cfg);
    }

}
