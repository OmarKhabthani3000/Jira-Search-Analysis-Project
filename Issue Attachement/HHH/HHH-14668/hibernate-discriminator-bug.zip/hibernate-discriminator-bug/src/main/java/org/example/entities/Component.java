package org.example.entities;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.UUID;

@Entity
@Data
@Table(name = "component")
@DiscriminatorColumn(name = "component_type")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Component {

    @Id
    @EqualsAndHashCode.Exclude
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    UUID id;

}
