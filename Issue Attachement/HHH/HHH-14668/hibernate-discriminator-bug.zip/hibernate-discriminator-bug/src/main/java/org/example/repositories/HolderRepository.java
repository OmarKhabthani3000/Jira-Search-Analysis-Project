package org.example.repositories;

import org.example.entities.Holder;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface HolderRepository extends JpaRepository<Holder, UUID> {
}
