package org.example;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.example.entities.Holder;
import org.example.repositories.HolderRepository;
import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.UUID;

@SpringBootApplication
@Slf4j
public class Main implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);
    }

    @Autowired
    Flyway flyway;

    @Autowired
    HolderRepository holderRepository;

    @Autowired
    Gson gson;

    @Override
    public void run(String... args) throws Exception {
        flyway.migrate();

        Holder holder = holderRepository.findById(UUID.fromString("9b1fad66-35c3-44c5-b7d3-ed2c6ddf743d")).get();
        if (holder.getComponents().size() == 2) {
            if (holder.getComponents().get(0) == holder.getComponents().get(1)) {
                log.info(gson.toJson(holder));
                log.error("One component container expected, but got 2 and same instance!");
            }
        }

    }
}
