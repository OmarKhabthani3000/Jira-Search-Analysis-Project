package de.idon.test.hibernate;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import de.idon.test.hibernate.beans.Child;
import de.idon.test.hibernate.beans.Node;
import de.idon.test.hibernate.beans.Parent;

/**
 * @author Burkhard Graves
 */
public class NonRecursiveTest extends BaseCoreFunctionalTestCase {

	@Override
	protected Class<?>[] getAnnotatedClasses() {
		return new Class[] { Parent.class, Child.class };
	}

	// load by id
	private Parent loadParent(Session s, int id) {
		return (Parent) s.load(Parent.class, Integer.valueOf(id));
	}
	
	// load by id
	private Child loadChild(Session s, int id) {
		return (Child) s.load(Child.class, Integer.valueOf(id));
	}
	
	// check index of child
	private void checkIndex(Child child, int index) {
		Assert.assertEquals(index, child.getIndex());
	}
	
	@Before
	public void before() {

		Session s = openSession();
		s.getTransaction().begin();
		
		// create parent
		Parent parent = new Parent(1);
		
		// holding three children
		parent.add(new Child(2)).add(new Child(3)).add(new Child(4));

		s.save(parent);
		
		s.getTransaction().commit();
		s.close();
	}
	
	@After
	public void after() {

		Session s = openSession();
		s.getTransaction().begin();
		
		// delete parent and its children by cascade
		Parent parent = loadParent(s, 1);
		s.delete(parent);

		s.getTransaction().commit();
		s.close();
		
		// empty second level cache
		//
		// makes test_2() fail with CacheConcurrencyStrategy.READ_WRITE
		// (assuming that test_1_withInitialize() runs before test_2())
		sessionFactory().getCache().evictEntityRegions();
	}

	/**
	 * Test succeeds.
	 */
	@Test
	public void test_1_withInitialize() {
		
		Session s = openSession();
		s.getTransaction().begin();
		
		Parent parent = loadParent(s, 1);
		
		// this way the test succeeds
		Hibernate.initialize(parent.getChildren());
		
		checkIndex(loadChild(s, 2), 0);
		checkIndex(loadChild(s, 3), 1);
		checkIndex(loadChild(s, 4), 2);

		s.getTransaction().commit();
		s.close();
	}

	/**
	 * @see Node
	 * 
	 * Succeeds with CacheConcurrencyStrategy.NONE and(!) CacheConcurrencyStrategy.NONSTRICT_READ_WRITE,
	 * fails otherwise.
	 * 
	 * If second level cache is not(!) cleared in after(),
	 * the test succeeds with CacheConcurrencyStrategy.READ_WRITE too
	 */
	@Test
	public void test_2() {
		
		Session s = openSession();
		s.getTransaction().begin();
		
		checkIndex(loadChild(s, 2), 0);
		checkIndex(loadChild(s, 3), 1);
		checkIndex(loadChild(s, 4), 2);
		
		s.getTransaction().commit();
		s.close();
	}

	private void reorderElements() {

		Session s = openSession();
		s.getTransaction().begin();
		
		Parent parent = loadParent(s, 1);
		
		// succeeds as in test_1_withInitialize()
		Hibernate.initialize(parent.getChildren());
		checkIndex(loadChild(s, 2), 0);
		checkIndex(loadChild(s, 3), 1);
		checkIndex(loadChild(s, 4), 2);

		Child child = parent.getChildren().remove(0);
		parent.getChildren().add(child);
		
		s.update(parent);
		
		s.getTransaction().commit();
		s.close();
	}

	/**
	 * Test succeeds.
	 */
	@Test
	public void test_3_withInitialize() {
		
		reorderElements();
		
		Session s = openSession();
		s.getTransaction().begin();
		
		Parent parent = loadParent(s, 1);
		
		// this way the test succeeds
		Hibernate.initialize(parent.getChildren());
		
		checkIndex(loadChild(s, 3), 0);
		checkIndex(loadChild(s, 4), 1);
		checkIndex(loadChild(s, 2), 2);

		s.getTransaction().commit();
		s.close();
	}

	/**
	 * Succeeds with CacheConcurrencyStrategy.NONE, fails otherwise.
	 */
	@Test
	public void test_4() {
		
		reorderElements();
		
		// close session and open another one
		
		Session s = openSession();
		s.getTransaction().begin();
		
		checkIndex(loadChild(s, 3), 0);
		checkIndex(loadChild(s, 4), 1); // index == 0 !?
		checkIndex(loadChild(s, 2), 2);
		
		s.getTransaction().commit();
		s.close();
	}
}
