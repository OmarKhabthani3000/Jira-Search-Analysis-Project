package de.idon.test.hibernate.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;

@Entity
public class Parent implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer id;
	
	private List<Child> children = new ArrayList<Child>();

	public Parent() {
		// empty constructor
	}
	
	public Parent(int id) {
		this.id = Integer.valueOf(id);
	}

	@Id
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@OneToMany(mappedBy = "parent", cascade = CascadeType.ALL)
	@OrderColumn(name = "idx")
	public List<Child> getChildren() {
		return children;
	}

	public void setChildren(List<Child> children) {
		this.children = children;
	}

	public Parent add(Child child) {
		child.setParent(this);
		getChildren().add(child);
		return this;
	}

	@Override
    public boolean equals(final Object obj) {
        // may be expressed this way since id is never null
        return this == obj
        		|| (obj instanceof Parent && id.equals(((Parent) obj).getId()));
    }

    @Override
    public int hashCode() {
    	// may be expressed this way since id is never null
        return id.hashCode();
    }
}
