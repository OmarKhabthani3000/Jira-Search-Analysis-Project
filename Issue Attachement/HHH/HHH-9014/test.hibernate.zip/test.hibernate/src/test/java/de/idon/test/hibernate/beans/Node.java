package de.idon.test.hibernate.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
//@Cache(usage = CacheConcurrencyStrategy.NONE)
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
//@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
//@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Cache(usage = CacheConcurrencyStrategy.TRANSACTIONAL)
public class Node implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer id;
	
	private Node parent;
	private List<Node> children = new ArrayList<Node>();
	private int index;
	
	public Node() {
		// empty constructor
	}
	
	public Node(int id) {
		this.id = Integer.valueOf(id);
	}

	@Id
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@ManyToOne
	@JoinColumn(name = "parent_id")
	public Node getParent() {
		return parent;
	}

	public void setParent(Node parent) {
		this.parent = parent;
	}

	@OneToMany(mappedBy = "parent", cascade = CascadeType.ALL)
	@OrderColumn(name = "idx")
	public List<Node> getChildren() {
		return children;
	}

	public void setChildren(List<Node> children) {
		this.children = children;
	}

	@Column(name="idx", nullable = false)
	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public Node add(Node child) {
		child.setParent(this);
		getChildren().add(child);
		return this;
	}

	@Override
    public boolean equals(final Object obj) {
        // may be expressed this way since id is never null
        return this == obj
        		|| (obj instanceof Node && id.equals(((Node) obj).getId()));
    }

    @Override
    public int hashCode() {
    	// may be expressed this way since id is never null
        return id.hashCode();
    }
}
