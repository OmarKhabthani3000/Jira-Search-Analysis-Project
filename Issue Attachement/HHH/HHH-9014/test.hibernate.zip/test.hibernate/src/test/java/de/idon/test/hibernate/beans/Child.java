package de.idon.test.hibernate.beans;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
//@Cache(usage = CacheConcurrencyStrategy.NONE)
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
//@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
//@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Cache(usage = CacheConcurrencyStrategy.TRANSACTIONAL)
public class Child implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer id;
	
	private Parent parent;
	private int index;
	
	public Child() {
		// empty constructor
	}
	
	public Child(int id) {
		this.id = Integer.valueOf(id);
	}

	@Id
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@ManyToOne
	@JoinColumn(name = "parent_id")
	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	@Column(name="idx", nullable = false)
	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	@Override
    public boolean equals(final Object obj) {
        // may be expressed this way since id is never null
        return this == obj
        		|| (obj instanceof Child && id.equals(((Child) obj).getId()));
    }

    @Override
    public int hashCode() {
    	// may be expressed this way since id is never null
        return id.hashCode();
    }
}
