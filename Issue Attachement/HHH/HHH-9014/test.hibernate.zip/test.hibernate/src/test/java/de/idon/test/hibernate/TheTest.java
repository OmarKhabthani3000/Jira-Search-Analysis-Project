package de.idon.test.hibernate;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import de.idon.test.hibernate.beans.Node;

/**
 * @author Burkhard Graves
 */
public class TheTest extends BaseCoreFunctionalTestCase {

	@Override
	protected Class<?>[] getAnnotatedClasses() {
		return new Class[] { Node.class };
	}

	// load node by id
	private Node load(Session s, int id) {
		return (Node) s.load(Node.class, Integer.valueOf(id));
	}
	
	// check index of node
	private void checkIndex(Node node, int index) {
		Assert.assertEquals(index, node.getIndex());
	}
	
	@Before
	public void before() {

		Session s = openSession();
		s.getTransaction().begin();
		
		// create a parent node
		Node parentNode = new Node(1);
		
		// holding three child nodes
		parentNode.add(new Node(2)).add(new Node(3)).add(new Node(4));

		s.save(parentNode);
		
		s.getTransaction().commit();
		s.close();
	}
	
	@After
	public void after() {

		Session s = openSession();
		s.getTransaction().begin();
		
		// delete parent node and its child nodes by cascade
		Node parentNode = load(s, 1);
		s.delete(parentNode);

		s.getTransaction().commit();
		s.close();
		
		// empty second level cache
		//
		// makes test_2() fail with CacheConcurrencyStrategy.READ_WRITE
		// (assuming that test_1_withInitialize() runs before test_2())
		sessionFactory().getCache().evictEntityRegions();
	}

	/**
	 * Test succeeds.
	 */
	@Test
	public void test_1_withInitialize() {
		
		Session s = openSession();
		s.getTransaction().begin();
		
		Node parentNode = load(s, 1);
		
		// this way the test succeeds
		Hibernate.initialize(parentNode.getChildren());
		
		checkIndex(load(s, 2), 0);
		checkIndex(load(s, 3), 1);
		checkIndex(load(s, 4), 2);

		s.getTransaction().commit();
		s.close();
	}

	/**
	 * @see Node
	 * 
	 * Succeeds with CacheConcurrencyStrategy.NONE and(!) CacheConcurrencyStrategy.NONSTRICT_READ_WRITE,
	 * fails otherwise.
	 * 
	 * If second level cache is not(!) cleared in after(),
	 * the test succeeds with CacheConcurrencyStrategy.READ_WRITE too
	 */
	@Test
	public void test_2() {
		
		Session s = openSession();
		s.getTransaction().begin();
		
		checkIndex(load(s, 2), 0);
		checkIndex(load(s, 3), 1);
		checkIndex(load(s, 4), 2);
		
		s.getTransaction().commit();
		s.close();
	}

	private void reorderElements() {

		Session s = openSession();
		s.getTransaction().begin();
		
		Node parentNode = load(s, 1);
		
		// succeeds as in test_1_withInitialize()
		Hibernate.initialize(parentNode.getChildren());
		checkIndex(load(s, 2), 0);
		checkIndex(load(s, 3), 1);
		checkIndex(load(s, 4), 2);

		Node node = parentNode.getChildren().remove(0);
		parentNode.getChildren().add(node);
		
		s.update(parentNode);
		
		s.getTransaction().commit();
		s.close();
	}

	/**
	 * Test succeeds.
	 */
	@Test
	public void test_3_withInitialize() {
		
		reorderElements();
		
		Session s = openSession();
		s.getTransaction().begin();
		
		Node parentNode = load(s, 1);
		
		// this way the test succeeds
		Hibernate.initialize(parentNode.getChildren());
		
		checkIndex(load(s, 3), 0);
		checkIndex(load(s, 4), 1);
		checkIndex(load(s, 2), 2);

		s.getTransaction().commit();
		s.close();
	}

	/**
	 * Succeeds with CacheConcurrencyStrategy.NONE, fails otherwise.
	 */
	@Test
	public void test_4() {
		
		reorderElements();
		
		// close session and open another one
		
		Session s = openSession();
		s.getTransaction().begin();
		
		checkIndex(load(s, 3), 0);
		checkIndex(load(s, 4), 1); // index == 0 !?
		checkIndex(load(s, 2), 2);
		
		s.getTransaction().commit();
		s.close();
	}
}
