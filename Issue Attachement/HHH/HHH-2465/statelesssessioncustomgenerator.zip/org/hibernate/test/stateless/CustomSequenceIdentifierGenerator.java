package org.hibernate.test.stateless;

import java.io.Serializable;
import java.util.Properties;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.dialect.Dialect;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.id.Configurable;
import org.hibernate.id.IdentifierGenerator;
import org.hibernate.id.IdentifierGeneratorFactory;
import org.hibernate.id.PersistentIdentifierGenerator;
import org.hibernate.type.LongType;
import org.hibernate.type.Type;

/**
 *
 * @author ldallolio
 *
 */
public class CustomSequenceIdentifierGenerator implements IdentifierGenerator,
		Configurable, PersistentIdentifierGenerator {
	private static IdentifierGenerator hibernateGeneratorDelegate = null;

	/**
	 * @see net.sf.hibernate.id.IdentifierGenerator#generate(SessionImplementor
	 *      session, Object object)
	 */
	public Serializable generate(SessionImplementor session, Object object)
			throws HibernateException {
		return hibernateGeneratorDelegate.generate(session,
				object);
	}

	/**
	 * @see net.sf.hibernate.id.Configurable#configure(Type type, Properties
	 *      props, Dialect dialect)
	 */
	public void configure(Type type, Properties props, Dialect dialect)
			throws MappingException {
		hibernateGeneratorDelegate = IdentifierGeneratorFactory.create(
				"sequence", type, props, dialect);
		if (hibernateGeneratorDelegate instanceof Configurable) {
			((Configurable) hibernateGeneratorDelegate).configure(type, props,
					dialect);
		}
	}

	/**
	 * @see net.sf.hibernate.id.PersistentIdentifierGenerator#generatorKey()
	 */
	public Object generatorKey() {
		if (hibernateGeneratorDelegate instanceof PersistentIdentifierGenerator)
			return ((PersistentIdentifierGenerator) hibernateGeneratorDelegate)
					.generatorKey();
		else
			return this; // not sure it is a good solution, but we won't fall
							// in this case with the two generators defined
							// below ;-)
	}

	/**
	 * @see net.sf.hibernate.id.PersistentIdentifierGenerator#sqlCreateStrings(net.sf.hibernate.dialect.Dialect)
	 */
	public String[] sqlCreateStrings(Dialect dialect) throws HibernateException {
		if (hibernateGeneratorDelegate instanceof PersistentIdentifierGenerator)
			return ((PersistentIdentifierGenerator) hibernateGeneratorDelegate)
					.sqlCreateStrings(dialect);
		else
			return new String[] {}; // safe, supported by caller
	}

	/**
	 * @see net.sf.hibernate.id.PersistentIdentifierGenerator#sqlDropString(net.sf.hibernate.dialect.Dialect)
	 */
	public String[] sqlDropStrings(Dialect dialect) throws HibernateException {
		if (hibernateGeneratorDelegate instanceof PersistentIdentifierGenerator)
			return ((PersistentIdentifierGenerator) hibernateGeneratorDelegate)
					.sqlDropStrings(dialect);
		else
			return new String[] {}; // safe, supported by caller
	}

}
