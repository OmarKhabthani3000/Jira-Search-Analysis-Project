package org.foo.test.jpa2.hibernate;

import java.util.List;
import java.util.UUID;

import javax.persistence.CacheRetrieveMode;
import javax.persistence.CacheStoreMode;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.foo.test.jpa2.hibernate.customer.Customer;
import org.foo.test.jpa2.hibernate.customer.CustomerId;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CacheTest {

	private static final String CUSTOMER_NAME = "foo tester";	
	private static EntityManagerFactory emf;
	private Customer customer;
		
	@Test
	@SuppressWarnings("unchecked")
	public void testCacheContains() {		
		EntityManager em = emf.createEntityManager();		
		List<Customer> customers = em.createQuery("select c from Customer c where c.name = :name")
			.setParameter("name", CUSTOMER_NAME)
			.setHint("org.hibernate.cacheable", Boolean.TRUE)
			.setHint("javax.persistence.cache.retrieveMode", CacheRetrieveMode.USE)
			.setHint("javax.persistence.cache.storeMode", CacheStoreMode.USE)
			.getResultList();
		
		Assert.assertTrue(customers.contains(customer));
		Assert.assertTrue(emf.getCache().contains(Customer.class, customer.getPrimaryKey()));		
		em.close();
	}
	
	@Before
	public void before() {
		EntityManager em = emf.createEntityManager();
				
		CustomerId id = new CustomerId(UUID.randomUUID().toString());
		
		customer = new Customer(id);	
		customer.setName(CUSTOMER_NAME);
		
		em.getTransaction().begin();
		em.persist(customer);
		em.getTransaction().commit();
		
		em.close();
	}
	
	@After
	public void after() {
		if (customer != null) {
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			em.remove(em.find(Customer.class, customer.getPrimaryKey()));
			em.getTransaction().commit();
			em.close();
		}
	}
	
	@BeforeClass
	public static void beforeClass() {
		emf = Persistence.createEntityManagerFactory("jpa2Pu");
	}
	
	@AfterClass
	public static void afterClass() {
		if (emf != null) {
			emf.close();
		}
	}
}
