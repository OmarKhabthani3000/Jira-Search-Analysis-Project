package org.foo.test.jpa2.hibernate.common;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(AbstractIdentity.class)
public abstract class AbstractIdentity_ {

	public static volatile SingularAttribute<AbstractIdentity, String> id;

}

