package org.foo.test.jpa2.hibernate.customer;

import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(CustomerId.class)
public abstract class CustomerId_ extends org.foo.test.jpa2.hibernate.common.AbstractIdentity_ {


}

