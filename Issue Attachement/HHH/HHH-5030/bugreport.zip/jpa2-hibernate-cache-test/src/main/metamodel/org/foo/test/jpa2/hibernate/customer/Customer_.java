package org.foo.test.jpa2.hibernate.customer;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(Customer.class)
public abstract class Customer_ extends org.foo.test.jpa2.hibernate.common.AbstractEntity_ {

	public static volatile SingularAttribute<Customer, CustomerId> customerId;
	public static volatile SingularAttribute<Customer, String> email;
	public static volatile SingularAttribute<Customer, String> name;

}

