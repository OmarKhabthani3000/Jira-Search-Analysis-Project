package org.foo.test.jpa2.hibernate.common;

/**
 * <code>Entity</code> is a unit which is identified by its unique identity 
 * (whereas a {@link DDDValueObject} is identified by its attributes).
 * 
 * @see DDDValueObject
 * 
 * @author had
 * @author http://dddsample.sourceforge.net/
 * 
 * @param <T> The type of the entity.
 * @param <I> The type of the identity.
 */
public interface DDDEntity<T, I> {
    
    /**
     * Returns the identity of the entity.
     * @return The identity, never null.
     */
    I getId();
    
    /**
     * Entities compare by identity, not by attributes.
     * @param other The other entity.
     * @return <code>true</code> if the identities are the same, regardless of
     *         other attributes.
     */
    boolean sameIdentityAs(T other);

}
