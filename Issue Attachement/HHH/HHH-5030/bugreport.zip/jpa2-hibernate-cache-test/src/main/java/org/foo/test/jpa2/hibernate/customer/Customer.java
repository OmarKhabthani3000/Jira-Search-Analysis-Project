/**
 * 
 */
package org.foo.test.jpa2.hibernate.customer;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.apache.commons.lang.Validate;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.foo.test.jpa2.hibernate.common.AbstractEntity;
import org.foo.test.jpa2.hibernate.common.DDDEntity;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.validator.constraints.Email;


/**
 * <code>Customer</code> represents a single customer identified by its 
 * customer id.
 *
 * @author  had
 */
@Entity
@Table(name = "t_customers",
    uniqueConstraints=@UniqueConstraint(columnNames={"id"}))
@Cacheable
@Cache(usage=CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Customer extends AbstractEntity<Customer, CustomerId> implements DDDEntity<Customer, CustomerId> {
    
	private CustomerId customerId;
    private String name;
    @Email
    private String email;

    /**
     * Constructs <code>Customer</code> using the specified customer id.
     * @param customerId The customer id, must not be null.
     * @throws IllegalArgumentException If <code>customerId</code> is null.
     */
    public Customer(final CustomerId customerId) {
    	Validate.notNull(customerId, "Customer id must not be null");
    	this.customerId = customerId;
    }
    
    
    /**
     * <strong>Note:</strong> This constructor only exists to fulfill the JPA 
     * specification. Use {@link #Customer(CustomerId)}
     * constructor in order to manually create an entity instance.
     */
    protected Customer() {
        // needed by JPA
    }    
    
    @Override
	public CustomerId getId() {
		return customerId;
	}


	/**
     * Returns the name.
     * @return The name.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name.
     * @param name The name to set.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the email.
     * @return The email.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email.
     * @param email The email to set.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Customer)) {
            return false;
        }
        
        Customer other = (Customer)obj;
        return sameIdentityAs(other);
    }
    
    /**
     * @see AbstractEntity#toString()
     */
    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
            .appendSuper(super.toString())
            .append("name", name)
            .append("email", email)
            .toString();
    }    
}
