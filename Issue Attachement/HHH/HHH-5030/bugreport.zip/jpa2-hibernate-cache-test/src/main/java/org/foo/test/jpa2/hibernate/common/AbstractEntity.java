package org.foo.test.jpa2.hibernate.common;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * <code>AbstractEntity</code> provides an abstract base implementation for
 * all entities.
 * <p/>
 * An entity has a business identity: {@link #id} and a technical
 * primary key: {@link #primaryKey}.
 * 
 * @author had
 * @param <T> The type of the entity.
 * @param <I> The type of the identity.
 */
@MappedSuperclass
public abstract class AbstractEntity<T extends DDDEntity<T,I>, I extends Identity<I>> implements DDDEntity<T, I> {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name="pk")
    private Long primaryKey;
    
    /**
     * <strong>Note:</strong> This constructor only exists to fulfill the JPA 
     * specification. Use {@link #AbstractEntity(Identity)} constructor in order to
     * manually create an entity instance.
     */
    protected AbstractEntity() {
        // needed for JPA
    }
    
    /**
     * Returns the primary key.
     * @return The primary key, may be null if entity is not yet persisted.
     */
    public Long getPrimaryKey() {
        return primaryKey;
    }
    
    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {        
        return getId().hashCode();
    }
        
	/**
     * @see DDDEntity#sameIdentityAs(Object)
     */
    @Override
    public boolean sameIdentityAs(T other) {        
        return (other != null && getId().sameValueAs(other.getId()));               
    }

    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
            .append("pk", primaryKey)
            .append("id", getId())
            .toString();
    }
}
