package org.hibernate.bugs;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.RevisionEntity;
import org.hibernate.envers.query.AuditQuery;
import org.hibernate.envers.query.criteria.AuditCriterion;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class Hhh9105 {
	private Configuration config;

	private SessionFactory sessionFactory;

	@SuppressWarnings("deprecation")
	@Before
	public void setup() {
		config = new Configuration();

		// add your entities here e.g.:
		//  config.addAnnotatedClass(Customer.class);
		config.addAnnotatedClass(Header.class);
		config.addAnnotatedClass(Item.class);

		config.setProperty("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
		config.setProperty("hibernate.connection.url", "jdbc:hsqldb:mem:myunittests");
		config.setProperty("hibernate.connection.username", "sa");
		config.setProperty("hibernate.connection.password", "");
		config.setProperty("hibernate.connection.pool_size", "1");
		config.setProperty("hibernate.current_session_context_class", "thread");
		config.setProperty("hibernate.hbm2ddl.auto", "update");
		config.setProperty("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
		config.setProperty("hibernate.show_sql", "true");

		sessionFactory = config.buildSessionFactory();
	}

	// perform your tests using standard junit test cases
	@Test
	public void testEmbeddableWithCollection() {
		Header h1 = new Header();
		h1.setName("h1");
		
		EmbeddableWithCollection ewc = new EmbeddableWithCollection();
		List<Item> items = new ArrayList<Item>();
		Item i1 = new Item();
		i1.setHeader(h1);
		i1.setName("h1-item1");
		i1.setPosition(0);
		Item i2 = new Item();
		i2.setHeader(h1);
		i2.setName("h1-item2");
		i2.setPosition(1);
		items.add(i1);
		items.add(i2);
		ewc.setItems(items);
		
		h1.setEmbeddableWithCollection(ewc);
		sessionFactory.getCurrentSession().beginTransaction();
		Long headerId = (Long) sessionFactory.getCurrentSession().save(h1);
				
		sessionFactory.getCurrentSession().getTransaction().commit();
		Header persistedHeader = (Header) sessionFactory.getCurrentSession()
				.createCriteria(Header.class)
				.add(Restrictions.idEq(headerId))
				.uniqueResult();
		Assert.assertEquals(2, persistedHeader.getEmbeddableWithCollection().getItems().size());
		
		sessionFactory.getCurrentSession().beginTransaction();
		AuditReader reader = AuditReaderFactory.get(sessionFactory.getCurrentSession());
		Header auditedHeader = reader.find(Header.class, headerId, Integer.MAX_VALUE);
		List<Item> auditedHeader1Items = auditedHeader.getEmbeddableWithCollection().getItems(); 
		Assert.assertEquals(2, auditedHeader1Items.size());
		Assert.assertEquals("h1-item1", auditedHeader1Items.get(0).getName());
		Assert.assertEquals(Long.valueOf(0), auditedHeader1Items.get(0).getPosition());
		Assert.assertEquals(headerId, auditedHeader1Items.get(0).getHeader().getId());
		Assert.assertEquals("h1-item2", auditedHeader1Items.get(1).getName());
		Assert.assertEquals(Long.valueOf(1), auditedHeader1Items.get(1).getPosition());
		Assert.assertEquals(headerId, auditedHeader1Items.get(1).getHeader().getId());
		sessionFactory.getCurrentSession().getTransaction().commit();
		sessionFactory.getCurrentSession().close();
	}
}
