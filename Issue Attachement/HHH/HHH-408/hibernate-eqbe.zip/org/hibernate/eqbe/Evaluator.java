package org.hibernate.eqbe;

import org.hibernate.criterion.*;
import java.lang.reflect.*;
import java.util.*;
import org.apache.commons.logging.*;

/**
 * Provides "Evaluator" mechanisms to be applied to Java Bean properties during query execution. 
 * Evaluators are applied to corresponding properties through use of the Evaluation class.
 * <p>
 * Example:
 * <p>
 * Evalaution evaluation = new Evaluation();<br/>
 * evalation.addEvaluation("property name", Evaluator.LIKE);<br/>
 * <p>
 * @author Marc Piparo
 * @see Evaluation
 */
public class Evaluator {
  
  private static Log log = LogFactory.getLog(Evaluator.class);
  
  private String criterionMethod;
  private Class[] methodParameterTypes;  
  private Object[] optionalParameters;
  
  /**
   * Apply "Equal" constraint to the property. (Based on interpretation of database "=" interpretation. 
   * Case-Insensitive for ANSI-SQL Compliant Databases)
   */
  public static final Evaluator EQUAL;
  /**
   * Apply "Greater Than" constraint to the property.
   */
  public static final Evaluator GREATER;
  /**
   * Apply "Greater Than or Equal" constraint to the property.
   */
  public static final Evaluator GREATER_EQUAL;
  /**
   * Apply "Less Than" constraint to the property.
   */
  public static final Evaluator LESSTHAN;
  /**
   * Apply "Greater Than or Equal" constraint to the property.
   */
  public static final Evaluator LESSTHAN_EQUAL;
  /**
   * Apply "Between" constraint to the property.  
   * <p>
   * Based on property's value syntax of "lower..higher".
   * <p>
   * Example: 
   * <p>
   * property value="5..10" will constraint results to values between 5 and 10.
   */
  public static final Evaluator BETWEEN;
  
  /**
   * Apply a "like" constraint to the property. (Based on interpretation of database "like" interpretation. 
   * Case-Insensitive for ANSI-SQL Compliant Databases)
   * <p>
   * Filters on wildcard characters: '%' and '_' set in property value.
   * <p>
   * Example:
   * <p>
   * <table>
   * <tr><td>property value="italy%"</td><td>-- match where property value begins with 'italy'</td></tr>
   * <tr><td>property value="%italy"</td><td>-- match where property value ends with 'italy'</td></tr>
   * <tr><td>property value="%italy%"</td><td>-- match where 'italy' occurs anywhere in property value</td></tr>
   * <tr><td>property value="i_aly"</td><td>-- match where '_' can be any character</td></tr>
   * </table>
   */
  public static final Evaluator LIKE;
  
  /**
   * Apply a "like anywhere" constraint to the property. (Based on interpretation of database "like" interpretation. 
   * Case-Insensitive for ANSI-SQL Compliant Databases)
   * <p>
   * Similar to standard LIKE and applying wildcard pattern: '%data%'
   * <p>
   */
  public static final Evaluator LIKE_ANYWHERE;
  
  /**
   * Apply a "like exact" constraint to the property. (Based on interpretation of database "like" interpretation. 
   * Case-Insensitive for ANSI-SQL Compliant Databases)
   * <p>
   * Similar to standard LIKE with NO wildcard pattern.
   * <p>
   */
  public static final Evaluator LIKE_EXACT;
  
  /**
   * Apply a "like starts-with" constraint to the property. (Based on interpretation of database "like" interpretation. 
   * Case-Insensitive for ANSI-SQL Compliant Databases)
   * <p>
   * Similar to standard LIKE and applying wildcard pattern: 'data%'
   * <p>
   */
  public static final Evaluator LIKE_START;
  
  /**
   * Apply a "like ends-with" constraint to the property. (Based on interpretation of database "like" interpretation. 
   * Case-Insensitive for ANSI-SQL Compliant Databases)
   * <p>
   * Similar to standard LIKE and applying wildcard pattern: '%data'
   * <p>
   */
  public static final Evaluator LIKE_END;
  
  
  /**
   * Apply an "ilike" (case-insensitive like) constraint to the property on supported databases. 
   * (Based on interpretation of database "ilike" interpretation (i.e. Postgres), if any.  Will default to standard "like" if 
   * not supported by database))
   * <p>
   * Filters on wildcard characters: '%' and '_' set in property value.
   * <p>
   * Example:
   * <p>
   * <table>
   * <tr><td>property value="italy%"</td><td>-- match where property value begins with 'italy'</td></tr>
   * <tr><td>property value="%italy"</td><td>-- match where property value ends with 'italy'</td></tr>
   * <tr><td>property value="%italy%"</td><td>-- match where 'italy' occurs anywhere in property value</td></tr>
   * <tr><td>property value="i_aly"</td><td>-- match where '_' can be any character</td></tr>
   * </table>
   */
  public static final Evaluator ILIKE;
 
  /**
   * Apply an "ilike anywhere" (case-insensitive) constraint to the property. (Based on interpretation of database "ilike" interpretation (i.e. Postgres), if any.  Will default to standard "like" if 
   * not supported by database))
   * <p>
   * Similar to standard ILIKE and applying wildcard pattern: '%data%'
   * <p>
   */
  public static final Evaluator ILIKE_ANYWHERE;
  
  /**
   * Apply an "ilike exact" (case-insensitive) constraint to the property. (Based on interpretation of database "ilike" interpretation (i.e. Postgres), if any.  Will default to standard "like" if 
   * not supported by database))
   * <p>
   * Similar to standard ILIKE with NO wildcard pattern.
   * <p>
   */
  public static final Evaluator ILIKE_EXACT;
  
  /**
   * Apply an "ilike starts-with" (case-insensitive) constraint to the property. (Based on interpretation of database "ilike" interpretation (i.e. Postgres), if any.  Will default to standard "like" if 
   * not supported by database))
   * <p>
   * Similar to standard ILIKE and applying wildcard pattern: 'data%'
   * <p>
   */
  public static final Evaluator ILIKE_START;
  
  /**
   * Apply an "ilike ends-with" (case-insensitive) constraint to the property. (Based on interpretation of database "ilike" interpretation (i.e. Postgres), if any.  Will default to standard "like" if 
   * not supported by database))
   * <p>
   * Similar to standard ILIKE and applying wildcard pattern: '%data'
   * <p>
   */
  public static final Evaluator ILIKE_END;
  
  
  /**
   * Apply "Is Null" constraint check on the property.
   */
  public static final Evaluator IS_NULL;
  /**
   * Apply "Is Null" constraint check on the property.
   */
  public static final Evaluator IS_NOT_NULL;
  
  
  static {
    
    // mappings to hibernate expression methods
    
    EQUAL          = new Evaluator("eq", new Class[] {String.class, Object.class}); 
    
    GREATER        = new Evaluator("gt", new Class[] {String.class, Object.class}); 
    GREATER_EQUAL  = new Evaluator("ge", new Class[] {String.class, Object.class}); 
    
    LESSTHAN       = new Evaluator("lt", new Class[] {String.class, Object.class}); 
    LESSTHAN_EQUAL = new Evaluator("le", new Class[] {String.class, Object.class}); 
    
    BETWEEN        = new Evaluator("between", new Class[] {String.class, Object.class, Object.class});  
     
    LIKE           = new Evaluator("like", new Class[] {String.class, Object.class}); 
    LIKE_ANYWHERE  = new Evaluator("like", new Class[] {String.class, String.class, MatchMode.class}, new Object[] {MatchMode.ANYWHERE}); 
    LIKE_EXACT     = new Evaluator("like", new Class[] {String.class, String.class, MatchMode.class}, new Object[] {MatchMode.EXACT}); 
    LIKE_START     = new Evaluator("like", new Class[] {String.class, String.class, MatchMode.class}, new Object[] {MatchMode.START}); 
    LIKE_END       = new Evaluator("like", new Class[] {String.class, String.class, MatchMode.class}, new Object[] {MatchMode.END}); 
    
    ILIKE          = new Evaluator("ilike", new Class[] {String.class, Object.class}); 
    ILIKE_ANYWHERE = new Evaluator("ilike", new Class[] {String.class, String.class, MatchMode.class}, new Object[] {MatchMode.ANYWHERE}); 
    ILIKE_EXACT    = new Evaluator("ilike", new Class[] {String.class, String.class, MatchMode.class}, new Object[] {MatchMode.EXACT}); 
    ILIKE_START    = new Evaluator("ilike", new Class[] {String.class, String.class, MatchMode.class}, new Object[] {MatchMode.START}); 
    ILIKE_END      = new Evaluator("ilike", new Class[] {String.class, String.class, MatchMode.class}, new Object[] {MatchMode.END}); 
      
    IS_NULL        = new Evaluator("isNull", new Class[] {String.class}); 
    IS_NOT_NULL    = new Evaluator("isNotNull", new Class[] {String.class});
    
  }
  
  /** Creates a new instance of Evaluator */
  private Evaluator(String method, Class[] parameters) {
    this.criterionMethod = method;
    this.methodParameterTypes = parameters;
  }
  
  /** Creates a new instance of Evaluator with optional parameters  */
  private Evaluator(String method, Class[] methodParameters, Object[] optionalParameters) {
    this.criterionMethod = method;
    this.methodParameterTypes = methodParameters;
    this.optionalParameters = optionalParameters;
  }
    
  // derive expression method
  private Method getCriteriaExpressionMethod() throws Exception {
    return Restrictions.class.getMethod(criterionMethod, methodParameterTypes); 
  }
  
  // process parameters for method
  private Object[] processParameters(String property, Object value) throws Exception {
    Collection parameters = new ArrayList();
    
    // add property as 1st parameter
    parameters.add(property);            
    
    if (value != null) {
      log.debug("building parameters for method call.  value="+value);
      if (this.equals(BETWEEN)) {
        // parse between syntax (lower..higher)
        String[] result = value.toString().split("..");
        if (result.length == 2) {
          // add low and high values as 2nd and 3rd parameters
          parameters.add(result[0]);
          parameters.add(result[1]);
        } else {
          throw new Exception("Incorrect Format for Between Evaluation Value.  Use 'low..high' format!");
        }               
      } else if (!this.equals(IS_NULL) && (!this.equals(IS_NOT_NULL))) {
        // add value as second parameter
        parameters.add(value.toString());
      }   
    }
    
    // add optional parameters for this evaluator (if any)
    if (optionalParameters != null) {
      for (int p=0; p<optionalParameters.length; p++) {
        parameters.add(optionalParameters[p]);        
      }
    }
    
    return parameters.toArray();
  }
  
  // build criterion from derived expression method
  protected Criterion buildCriterion(String property, Object value) throws Exception {
    Criterion criterion = null;
    // get defined expression method
    log.debug("building criterion for expressionMethod: "+this.criterionMethod);
    Method expressionMethod = getCriteriaExpressionMethod();    
    
    // process logical operators (AND/OR, syntax &&/||)
    if ((value != null) && (value.toString().indexOf("||") > -1)) {
      // process ORs
      Disjunction disjunction = Expression.disjunction();
      String[] result = value.toString().split("\\|\\|");
      log.debug("number of arguments: "+result.length);
      for (int x=0; x<result.length; x++) {
         Object[] parameters = processParameters(property, result[x]);
         disjunction.add((Criterion)expressionMethod.invoke(null, parameters));
         System.out.println(result[x]);
      }
      criterion = (Criterion)disjunction;  
    } else {
      // single value
      Object[] parameters = processParameters(property, value);
      criterion = (Criterion)expressionMethod.invoke(null, parameters); 
    }
  
    // call method and return Criterion
    return criterion;
    
  }
  
}
