package org.hibernate.eqbe;

import java.util.*;
import org.hibernate.criterion.*;
import org.apache.commons.logging.*;

/**
 * Provides a container for a collection of query {@link Evaluator} objects that can be 
 * applied to properties of a Java Bean object during Search query execution.
 * p>
 * Evaluator objects are added to instances of this class through the addEvaluator method along with
 * the coresponding bean property name expressed in dot notation.
 * <p>
 * Example:
 * <p>
 * Given the following Class assocation structure, where "Person" is the root target search class.
 * <p>
 * <table>
 * <tr><td>Person</td><td>Address</td></tr>
 * <tr><td>------------------</td><td>------------</td></tr>
 * <tr><td>String  name</td><td>String city</td></tr>
 * <tr><td>Address homeAddress&nbsp;&nbsp;</td><td>String state</td></tr>
 * </table>
 * <p>
 * Evaluation evaluation = new Evaluation();<br/>
 * evaluation.addEvaluator("name", Evaluator.LIKE);<br/>
 * evaluation.addEvaluator("homeAddress.city", Evaluator.EQUAL);<br/>
 * <p>
 * @author Marc Piparo
 * @version 1.0
 * @see Evaluator
 * @see Search
 */
public class Evaluation {
  
  private static Log log = LogFactory.getLog(Evaluation.class);
  
  private Map evaluators = new HashMap();  
  
  /**
   * Adds "property-Evaluator" pair to Evaluation object.
   * <p>
   * Example Usage:
   * <p>
   * Evaluation evaluation = new Evaluation();
   * evaluation.addEvaluator("name", Evaluator.EQUAL);
   * <p>
   * "property" parameter is expressed in object dot notation, with root query object
   * as root.  See example in Class description.
   * <p>
   * @param property Java Bean property name expressed in dot notation with primary search object as root.
   * @param evaluator Evalautor object to apply to this property
   */
  public void addEvaluator(String property, Evaluator evaluator) {
    evaluators.put(property, evaluator);
  }   
  
  protected Criterion createCriterion(String property, Object value, boolean isPrimitive) throws Exception {
    Criterion criterion = null;
    // look for propery in evaluation map
    if (evaluators.containsKey(property)) {
      // evaluator exists for property, build criterion from evaluator
      log.debug("Evaluator for property "+property+" exists.");
      Evaluator evaluator = (Evaluator)evaluators.get(property);
      criterion = evaluator.buildCriterion(property, value);     
    } else if (!isPrimitive && value != null) {
      // no evaluator for this property defined, default to equals (unless property is primitive type)  
      log.debug("evaluation exists..but not evaluator for this object, using default equals comparison.");
      criterion = Expression.eq(property, value.toString());      
    }        
    
    return criterion;
    
  }
  
}
