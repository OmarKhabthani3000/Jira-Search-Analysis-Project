package org.hibernate.eqbe;

import org.apache.commons.logging.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.*;
import org.hibernate.criterion.*;
import java.util.*;
import org.apache.commons.beanutils.*;


/**
 * Primary API Class for query interactions with the Common Persistence Manager.
 * <p>
 * This class provides utility methods for executing searches to the persistence layer. For query examples
 * please refer to the How To section in the Common Persistence overview.
 * <p>
 * @author Marc Piparo
 * @version 1.0
 * @see Evaluation
 * @see Evaluator
 */
public class EQBECriteria {
  
  private static Log log = LogFactory.getLog(EQBECriteria.class);
    
  // ------------------
  // Public API Methods
  // ------------------
   
   /**
   * Performs E-QBE (Enhanced Query-By-Example) searching on searchObj and returns
   * results list of matched objects applying Evaluators contained in Evaluation parameter on searchObj 
   * properties.
   * @param searchObj Root Search Java Bean object
   * @param evaluation Evaluation object containing collection of Evaluators to be applied to search object properties
   * @throws java.lang.Exception Exception
   * @return Result List
   */    
  public static Criteria createEQBECriteriaImpl(Object searchObj, Evaluation evaluation, Session session) throws HibernateException {      
    
    // initialize criteria with search object        
    Criteria criteria = session.createCriteria(searchObj.getClass()); 
    
    // build criteria
    buildCriteria(searchObj, criteria, null, null, evaluation); 
        						
    return criteria;               
  }          
   
  // -----------------------
  // Private Support Methods
  // -----------------------  
  
  // --------------------------------------------------------------------------
  // Build Criteria:
  // Iterate through object properties and build Criterion and nested Criteria 
  // using bean object reflection and nested recurssion
  private static void buildCriteria(Object obj, Criteria criteria, String path, Collection objectHistory, Evaluation evaluation) throws HibernateException {              

    // store this object in history collection to avoid member object circular
    // references. (i.e. child objects parent relation)
    if (objectHistory == null) {
      objectHistory = new HashSet();
    }
    objectHistory.add(obj);        
    try {
      Map beanProps = PropertyUtils.describe(obj);
      Iterator props = beanProps.entrySet().iterator();
      log.debug("\n\n***mapping bean properties for: "+obj.getClass().getName());

      while (props.hasNext()) {
        Map.Entry entry = (Map.Entry) props.next();
        log.debug("*****************************************************");
        log.debug("* key: "+entry.getKey()+"  value: "+entry.getValue());    

        if (entry.getKey() != null) {
          // determine path to this property
          String pathName = "";
          if (path != null) {
            pathName = path+".";
          }
          pathName += entry.getKey().toString();               
          log.debug("* pathName: "+pathName);         
          log.debug("*****************************************************");

          // get property type   
          Class propertyClass = PropertyUtils.getPropertyType(obj, entry.getKey().toString());

          // check for self class reference property or if this property is null 
          // or has already been processed
          if ((!entry.getKey().toString().equals("class")) && 
              (entry.getValue() == null || (!objectHistory.contains(entry.getValue())))) {

            //  build criteria for this property         
            log.debug("propertyType: "+propertyClass);

            // check if property type is a primitive or supported hibernate type class
            if (!propertyClass.isPrimitive() && !isHibernateClass(propertyClass) && entry.getValue() != null) {                          
              log.debug("- property is a class (non primitive)");
              Object nestedObj = null;
              // check if property type is a collection
              if (Class.forName("java.util.Collection").isInstance(entry.getValue())) {          
                log.debug("- property is a Collection");
                // check if anything in this collection
                Collection collection = (Collection) entry.getValue();
                if (!collection.isEmpty()) {
                  // look only at first object in collection
                  nestedObj = collection.toArray()[0];
                }                                    
              }
              else {            
                nestedObj = entry.getValue();
              }

              if (nestedObj != null) {

                // join nested object
                Criteria subCriteria = criteria.createCriteria(entry.getKey().toString());              

                // recursive call to build this nestedObj criteria
                buildCriteria(nestedObj, subCriteria, pathName, objectHistory, evaluation);
              }
            }
            else {
              // property is of hibernate/SQL supported primitive type
              log.debug("- property is a Primitive Type or Class, or a null object");

              // create criterion expression for this property
              Criterion criterion = createCriterion(entry.getKey().toString(), entry.getValue(), 
                                                    pathName, evaluation, propertyClass.isPrimitive()); 
              if (criterion != null) {
                criteria.add(criterion);
              }
            }                        
          } else {
            log.debug("- already been processed...");
          } // if this class object or already checked      
        } // null key
      } // end loop
    } catch (Exception ex) {
      throw new HibernateException("E-QBE Exception: "+ex);
    }
  }
  
  private static Criterion createCriterion(String property, Object value, String path, Evaluation evaluation, boolean isPrimitive) throws HibernateException {
    // parse value for wildcards and expression syntax
        
    Criterion criterion = null;
    if (evaluation == null) {
      // no evaluation object, default non-null values to equals comparison
      if (value != null) {      
        // do NOT default evaluate java primitive types      
        // ALL java primitive types REQUIRE an evaluator
        if (!isPrimitive) {
          log.debug("value="+value);
          log.debug("\nBuild Default Criterion for path: "+path+"  property="+property+"  value="+value.toString());   
          criterion = Expression.eq(property, value.toString());
        }
      }
      log.debug("\nValue is Null - no Criteria built.");  
    }
    else {
      // evaluation object exists
      // build criterion based on evaluation evaluators
      try {
        log.debug("\nBuild Evaluator Criterion for path: "+path+"  property="+property+"  value="+value.toString()+"  isPrimitive="+isPrimitive);  
        criterion = evaluation.createCriterion(property, value, isPrimitive);   
      } catch (Exception ex) {
        throw new HibernateException("E-QBE Criterion build error: "+ex);
      }
    }
    
    return criterion;            
  }
  
  private static boolean isHibernateClass(Class propertyClass) throws Exception {
    boolean result = false;
    if (Constants.HIBERNATE_CLASSES.contains(propertyClass)) { 
      result = true;
    }   
    return result;  
  }
  
}
