package org.hibernate.bugs.model.entity;

import org.hibernate.bugs.model.type.MonetaryAmount;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(
  name = "INT_TRANSACTIONS"
)
public class IntTransactions {

  @EmbeddedId
  @AttributeOverrides(
    {
      @AttributeOverride(
        name = "institutionNumber",
        column = @Column(
          name = "INSTITUTION_NUMBER",
          nullable = false,
          length = 8
        )
      ),
      @AttributeOverride(
        name = "transactionSlip",
        column = @Column(
          name = "TRANSACTION_SLIP",
          nullable = false,
          length = 11
        )
      )}
  )
  private TransactionId id;

  @Column(
    name = "MERCHANT_NAME",
    length = 30
  )
  private String merchantName;

  @Embedded
  @AttributeOverrides(
    {
      @AttributeOverride(
        name = "currency",
        column = @Column(
          name = "TRAN_CURRENCY",
          insertable = false,
          updatable = false
        )
      ),
      @AttributeOverride(
        name = "amount",
        column =

        @Column(
          name = "TRAN_AMOUNT",
          length = 18
        )
      )
    }
  )
  private MonetaryAmount tranAmount;

}