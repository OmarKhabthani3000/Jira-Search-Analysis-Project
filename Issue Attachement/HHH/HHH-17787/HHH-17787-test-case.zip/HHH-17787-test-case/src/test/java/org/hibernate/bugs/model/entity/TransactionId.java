package org.hibernate.bugs.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class TransactionId {

  @Column(
    name = "INSTITUTION_NUMBER",
    nullable = false,
    length = 8
  )
  private Integer institutionNumber;

  @Column(
    name = "TRANSACTION_SLIP",
    nullable = false,
    length = 11
  )
  private Long transactionSlip;
  
}
