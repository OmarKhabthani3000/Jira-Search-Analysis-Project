package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import org.hibernate.bugs.model.entity.*;
import org.hibernate.bugs.model.type.*;
import org.hibernate.query.sqm.internal.QuerySqmImpl;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private static final Logger LOG = Logger.getLogger(JPAUnitTestCase.class.getName());

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");

        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        String insertTransaction = 
        """
        INSERT INTO INT_TRANSACTIONS (INSTITUTION_NUMBER, TRANSACTION_SLIP, MERCHANT_NAME, TRAN_CURRENCY, TRAN_AMOUNT)
        VALUES ('00000200','00000000001','Test Merch', '840', '100.00')
        """;
        
        em.createNativeQuery(insertTransaction).executeUpdate();

        em.getTransaction().commit();
        em.close();
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void test1_selectFromSubquery_simpleType_succeeds() throws Exception {
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        String selectTransaction = 
        """
        select sub.innerSlip
        from (select id.transactionSlip as innerSlip
              from IntTransactions) sub
        """;

        List resultList = em.createQuery(selectTransaction).getResultList();
        int resultCount = resultList.size();
        Long result = (Long) resultList.get(0);

        em.getTransaction().commit();
        em.close();
        assertEquals(1L, result);
        assertEquals(1, resultCount);
    }


    @Test
    public void test2_selectFromSubquery_embeddableType_singleField_succeeds() throws Exception {
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        String selectTransaction = 
        """
        select sub.currencyInner as currencyOuter
        from (select tranAmount.currency as currencyInner
              from IntTransactions) sub
        """;

        List resultList = em.createQuery(selectTransaction).getResultList();
        int resultCount = resultList.size();
        String result = (String) resultList.get(0);


        em.getTransaction().commit();
        em.close();
        assertEquals("840", result);
        assertEquals(1, resultCount);
    }

    
        
    @Test
    public void test3_selectFromSubquery_embeddableType_wholeEmbeddable_fails() throws Exception {
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        String selectTransaction = 
        """
        select sub.tranAmountInner as tranAmountOuter
        from (select tranAmount as tranAmountInner
              from IntTransactions) sub
        """;

        MonetaryAmount expectedResult = new MonetaryAmount("840",BigDecimal.valueOf(100L));

        List resultList = em.createQuery(selectTransaction).getResultList();
        int resultCount = resultList.size();
        MonetaryAmount result = (MonetaryAmount) resultList.get(0);


        em.getTransaction().commit();
        em.close();
        assertEquals(expectedResult, result);
        assertEquals(1, resultCount);
    }


    @Test
    public void test4_selectFromSubquery_SameColumnDifferentAliasInSubquery_fails() throws Exception {
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        String selectTransaction = 
        """
        select sub.tranSlip1 as tranSlip1, sub.tranSlip2 as tranSlip2
        from (select id.transactionSlip as tranSlip1, id.transactionSlip as tranSlip2
              from IntTransactions) sub
        """;

        List resultList = em.createQuery(selectTransaction).getResultList();
        int resultCount = resultList.size();

        em.getTransaction().commit();
        em.close();
        assertEquals(1, resultCount);
    }

}
