drop table t_parent;
drop table t_child;
create table t_parent(
  parent_id integer not null,
  primary key(parent_id)
);
create table t_child(
  child_id integer not null,
  parent_id integer not null,
  primary key(child_id)
);