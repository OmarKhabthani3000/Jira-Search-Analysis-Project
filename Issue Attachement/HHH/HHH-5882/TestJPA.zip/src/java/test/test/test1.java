package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.property.Getter;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


import orm.*;

public class test1 {
	static Configuration Config;
	static SessionFactory sessionFactory;

	@Before
	public void setUp() throws Exception {
		Config = new Configuration();
		Config.configure()
			  .addPackage("orm")
			  .addAnnotatedClass(Parent.class)
			  .addAnnotatedClass(Child.class)
			  .addAnnotatedClass(Parent_LazyLoad.class)
			  .addAnnotatedClass(Child_LazyLoad.class)
			  ;
		sessionFactory = Config.buildSessionFactory();
		Session vSession = sessionFactory.openSession();
		Transaction vTran = vSession.beginTransaction();
		try{
			vSession.createQuery("delete from Parent").executeUpdate();
			vSession.createQuery("delete from Child").executeUpdate();
			
			Parent vParent = new Parent();
			vParent.setParent_id(1);
			vSession.save(vParent);
			
			Child vChild = new Child();
			vChild.setChild_id(10);
			vChild.setParentObj(vParent);
			vSession.save(vChild);
			Child vChild2 = new Child();
			vChild2.setChild_id(11);
			vChild2.setParentObj(vParent);
			vSession.save(vChild2);

			vTran.commit();
		}finally{
			vSession.close();
		}
	
	}

	
	@Test
	//Test case for eager load in many to one situation.
	public void TestEagerLoadManyToOne(){
		PersistentClass vChildClass = Config.getClassMapping(Child.class.getName());
		PersistentClass vParentClass = Config.getClassMapping(Parent.class.getName());
		Getter vHeaderGetter = vChildClass.getProperty("parentObj").getGetter(Child.class);
		Getter vHeaderIDGetter = vParentClass.getProperty("parent_id").getGetter(Parent.class);
//		Getter vHeaderIDGetter = vParentClass.getIdentifierProperty().getGetter(Parent.class);
		
		Session vSession = sessionFactory.openSession();
		
		try{
			Child vChild = (Child) vSession.get(Child.class, 10);
			Assert.assertNotNull(vChild);
			Assert.assertNotNull(vChild.getChild_id());
			
			//Test case to get header_id use getter ,but get header data form Method.
			Parent vParent = vChild.getParentObj();
			Assert.assertNotNull(vParent);
			Object vParent_ID = vParent.getParent_id();
			Assert.assertNotNull(vParent_ID);
			vParent_ID = vHeaderIDGetter.get(vParent);
			Assert.assertNotNull(vParent_ID);
			
			//Test case to get everything use eager getter
			vParent = (Parent) vHeaderGetter.get(vChild); // should work like: Parent vParent = vChild.getParentObj();
			Assert.assertNotNull(vParent);
			vParent_ID = vHeaderIDGetter.get(vParent); // should work like: Object vParent_ID = vParent.getParent_id();
			Assert.assertNotNull(vParent_ID);

		}finally{
			vSession.close();
		}
	}	
	
	@Test
	//Test case for lazy load in many to one situation.
	public void TestLazyLoadManyToOne(){
		PersistentClass vChildClass = Config.getClassMapping(Child_LazyLoad.class.getName());
		PersistentClass vParentClass = Config.getClassMapping(Parent_LazyLoad.class.getName());
		Getter vHeaderGetter = vChildClass.getProperty("parentObj").getGetter(Child_LazyLoad.class);
		Getter vHeaderIDGetter = vParentClass.getProperty("parent_id").getGetter(Parent_LazyLoad.class);
//		Getter vHeaderIDGetter = vParentClass.getIdentifierProperty().getGetter(Parent.class);
		
		Session vSession = sessionFactory.openSession();
		
		try{
			Child_LazyLoad vChild = (Child_LazyLoad) vSession.get(Child_LazyLoad.class, 10);
			Assert.assertNotNull(vChild);
			Assert.assertNotNull(vChild.getChild_id());
			
			//Test case to get header_id use getter ,but get header data form Method.
			Parent_LazyLoad vParent= vChild.getParentObj();
			Assert.assertNotNull(vParent);
			Object vParent_ID = vParent.getParent_id();
			Assert.assertNotNull(vParent_ID);
			vParent_ID = vHeaderIDGetter.get(vParent);
			Assert.assertNotNull(vParent_ID);
			
			//Test case to get everything use eager getter
			vParent = (Parent_LazyLoad) vHeaderGetter.get(vChild); // should work like: Parent vParent = vChild.getParentObj();
			Assert.assertNotNull(vParent);
			vParent_ID = vHeaderIDGetter.get(vParent); // should work like: Object vParent_ID = vParent.getParent_id();
			Assert.assertNotNull(vParent_ID);

		}finally{
			vSession.close();
		}
	}	
	
}
