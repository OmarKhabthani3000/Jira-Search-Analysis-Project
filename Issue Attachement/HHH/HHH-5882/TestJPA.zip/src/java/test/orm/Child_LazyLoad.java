package orm;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



@Entity
@org.hibernate.annotations.Entity(dynamicUpdate=true,dynamicInsert=true)
@Table(name="T_Child")
public class Child_LazyLoad {
	@Id
	private Integer child_id;
	
	@ManyToOne(optional=false,cascade={CascadeType.ALL},fetch=FetchType.LAZY)
	@JoinColumn(name="parent_id")
	private Parent_LazyLoad parentObj;	
	
	public Integer getChild_id() {
		return child_id;
	}
	public void setChild_id(Integer childId) {
		child_id = childId;
	}
	public Parent_LazyLoad getParentObj() {
		return parentObj;
	}
	public void setParentObj(Parent_LazyLoad parent) {
		this.parentObj = parent;
	}

}
