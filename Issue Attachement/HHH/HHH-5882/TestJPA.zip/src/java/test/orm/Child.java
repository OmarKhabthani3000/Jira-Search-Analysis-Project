package orm;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@org.hibernate.annotations.Entity(dynamicUpdate=true,dynamicInsert=true)
@Table(name="T_Child")
public class Child {
	@Id
	private Integer child_id;
	
	@ManyToOne(optional=false,cascade={CascadeType.ALL})
	@JoinColumn(name="parent_id")
	private Parent parentObj;	
	
	public Integer getChild_id() {
		return child_id;
	}
	public void setChild_id(Integer childId) {
		child_id = childId;
	}
	public Parent getParentObj() {
		return parentObj;
	}
	public void setParentObj(Parent parent) {
		this.parentObj = parent;
	}

}
