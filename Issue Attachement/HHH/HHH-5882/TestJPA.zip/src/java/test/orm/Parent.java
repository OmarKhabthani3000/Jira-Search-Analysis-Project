package orm;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;

@Entity
@org.hibernate.annotations.Entity(dynamicUpdate=true,dynamicInsert=true)
@Table(name="T_Parent")
public class Parent {
	@Id
	private Integer parent_id;
	@OneToMany(mappedBy="parentObj",cascade={CascadeType.ALL}, targetEntity=Child.class,fetch=FetchType.LAZY)
	@BatchSize(size=1000)
	private Set<Child> children;
	
	public Integer getParent_id() {
		return parent_id;
	}
	public void setParent_id(Integer parentId) {
		parent_id = parentId;
	}
	public Set<Child> getChildren() {
		return children;
	}
	public void setChildren(Set<Child> children) {
		this.children = children;
	}
}
