package org.hibernate.bugs.HHH11237;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicInteger;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

public class OnFlushDirtyInterceptor extends EmptyInterceptor {

	private static final long serialVersionUID = 1L;
	
	private AtomicInteger callCount = new AtomicInteger();

	@Override
	public boolean onFlushDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState, String[] propertyNames, Type[] types) {
		callCount.incrementAndGet();
		return false;
	}
	
	public int getCallCount() {
		return callCount.get();
	}
	
	public void resetCallCount() {
		callCount.set(0);
	}
}
