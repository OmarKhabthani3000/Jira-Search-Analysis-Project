package org.hibernate.bugs.HHH11237;

import java.io.Serializable;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Version;

import org.hibernate.annotations.SelectBeforeUpdate;

@Entity
@SelectBeforeUpdate
public class Person implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private Long personId;
	
	private String personName;
	
	@Embedded
	private Address address;
	
	@Version
	private Long version;

	public Person() {
	}

	public Person(Long personId, String personName, Address address) {
		this.personId = personId;
		this.personName = personName;
		this.address = address;
	}

	public Long getPersonId() {
		return personId;
	}

	public void setPersonId(Long personId) {
		this.personId = personId;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Long getVersion() {
		return version;
	}

	public void setVersion(Long version) {
		this.version = version;
	}
}
