package org.hibernate.bugs.HHH11237;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class Address implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String postalCode;
	private String state;
	private String address;
	
	public Address() {
	}
	
	public Address(String postalCode, String state, String address) {
		this.postalCode = postalCode;
		this.state = state;
		this.address = address;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	@Override
	public boolean equals(Object o) {
		if (o != null) {
			if (o instanceof Address) {
				Address a = (Address)o;
				return eq(this.postalCode, a.postalCode) && eq(this.state, a.state) && eq(this.address, a.address);
			}
		}
		return false;
	}
	
	private static boolean eq(String s1, String s2) {
		if (s1 == null && s2 == null) return true;
		if (s1 == null || s2 == null) return false;
		return s1.equals(s2);
	}

}
