/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs.HHH11237;

import static org.junit.Assert.assertEquals;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {
	
	private static final boolean USE_EMPTY_COMPONENT = true; // test with both true/false

	// Add your entities here.
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	protected Class[] getAnnotatedClasses() {
		return new Class[] {
			Person.class
		};
	}

	// Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
	@Override
	protected void configure(Configuration configuration) {
		super.configure( configuration );
		configuration.setProperty(AvailableSettings.CREATE_EMPTY_COMPOSITES_ENABLED, Boolean.toString(USE_EMPTY_COMPONENT));
	}

	// Add your tests, using standard JUnit.
	@Test
	public void hhh11237Test() throws Exception {
		Session s;
		Transaction t;
        OnFlushDirtyInterceptor i = new OnFlushDirtyInterceptor();
		
		// ----------------------------------------------------------------------------------------------
		// insert
		{
			s = openSession(i);
			t = s.beginTransaction();
			
			Person john = new Person(1L, "John", new Address());
			s.save(john);

			Person mary = new Person(2L, "Mary", null);
			s.save(mary);
			
			t.commit();
			s.close();
		}

		// ----------------------------------------------------------------------------------------------
		// get & update within a session.
		// null and empty component should be treated the same and no update should occur.
		{
			s = openSession(i);
			t = s.beginTransaction();
			
			Person john = s.get(Person.class, 1L);
			Person mary = s.get(Person.class, 2L);
			
	        i.resetCallCount();
			john.setAddress(null);
			s.flush();
	        assertEquals(0L, i.getCallCount());

	        i.resetCallCount();
			mary.setAddress(new Address());
			s.flush();
	        assertEquals(0L, i.getCallCount());

			t.commit();
			s.close();
		}

		// ----------------------------------------------------------------------------------------------
		// get in a session & update in another.
		// null and empty component should be treated the same and no update should occur.
		{
			s = openSession(i);
			t = s.beginTransaction();

			Person john = s.get(Person.class, 1L);
			Person mary = s.get(Person.class, 2L);

			t.commit();
			s.close();

			//
			
			s = openSession(i);
			t = s.beginTransaction();

	        i.resetCallCount();
			john.setAddress(null);
			s.update(john);
			s.flush();
	        assertEquals(0L, i.getCallCount());

	        i.resetCallCount();
			mary.setAddress(new Address());
			s.update(mary);
			s.flush();
	        assertEquals(0L, i.getCallCount());
	        // this fails in both cases (USE_EMPTY_COMPONENT=true/false)

			t.commit();
			s.close();
		}
	}
}
