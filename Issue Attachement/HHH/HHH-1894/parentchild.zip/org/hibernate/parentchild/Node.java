package org.hibernate.parentchild;

import java.util.HashSet;
import java.util.Set;

public class Node
{
    private long id;
    private Node parent = null;
    private String name = null;
    private Set children = new HashSet(0);
    
    public Node ()
    {
	// Nop
    }

    public Node(String name)
    {
	this.name = name;
    }

    public long getId()
    {
        return id;
    }

    public void setId(long id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public Node getParent()
    {
        return parent;
    }

    public void setParent(Node parent)
    {
	if (this.parent != null)
	    this.parent.getChildren().remove(this);
	
        this.parent = parent;
        
	if (this.parent != null)
	    this.parent.getChildren().add(this);
    }

    public Set getChildren()
    {
        return children;
    }

    public void setChildren(Set children)
    {
        this.children = children;
    }
    
    
}
