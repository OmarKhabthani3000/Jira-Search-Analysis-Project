package org.hibernate.parentchild;

import java.sql.Connection;
import java.sql.Statement;

import junit.framework.TestCase;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

public class ParentTest extends TestCase
{
    private Configuration cfg = new Configuration();
    private SessionFactory sessionFactory;
    private Session session;    

    public void testReparent () throws Exception
    {
	Node root1 = new Node ("root1");
	Node child = new Node ("child");
	child.setParent(root1);
	session.save(root1);
	Node root2 = new Node ("root2");
	session.save(root2);
	session.flush();
	
	root1 = loadNode (root1.getId());
	root2 = loadNode (root2.getId());
	child = loadNode (child.getId());
	Node n = (Node)root1.getChildren().iterator().next();
	assertEquals ("Loading root1.children[0] and child are different objects", child.getId(), n.getId());
	
	// Test reparent
	if (1 == 1)
	{
	    // This doesn't work: Throws ObjectDeletedException for child
	    child.setParent(root2);
	    session.flush();
	}
	else if (0 == 1)
	{
	    // This doesn't work either: I get the error
	    // Found two representations of same collection: org.hibernate.parentchild.Node.children
	    // in the second flush
	    child.setParent(null);
	    session.flush();

	    child.setId (-1);
	    child.setParent(root2);
	    session.flush();
	}
	else
	{
	    // This works but is no solution for complex objects: I have to clone the child
	    child.setParent(null);
	    // Note: Without this explicit delete, I get the same ObjectDeletedException as above :-/
	    session.delete(child);
	    session.flush();

	    // Must create clone
	    Node newChild = new Node (child.getName());
	    newChild.setParent(root2);
	    session.flush();
	}
    }
    
    private Node loadNode(long id)
    {
	return (Node) session.createQuery("from Node where id = ?").setLong(0, id).uniqueResult();
    }

    protected void setUp() throws Exception
    {
	super.setUp();
	setupHibernate ();
	setupDB ();
    }


    protected void tearDown() throws Exception
    {
	if (session != null)
	    session.close();
	super.tearDown();
    }


    private void setupHibernate()
    {
	cfg.configure("/org/hibernate/parentchild/parenttest.cfg.xml");
	sessionFactory = cfg.buildSessionFactory();
	session = sessionFactory.openSession();
    }

    private void setupDB() throws Exception
    {
	Connection conn = null;
	Statement st = null;
	try{
	    conn = session.connection();
	    st = conn.createStatement();
	    st.executeUpdate(
	    	"DROP TABLE parent_test IF EXISTS;\n" +
	    	"CREATE TABLE parent_test (\n" +
	    	"  id BIGINT PRIMARY KEY,\n" +
	    	"  parent_id BIGINT,\n" +
	    	"  name VARCHAR_IGNORECASE(256) NOT NULL,\n" +
	    	"  UNIQUE(id)\n" +
	    	");"
	    );
	} finally {
	    st.close ();
	    conn.close ();
	}
    }
}
