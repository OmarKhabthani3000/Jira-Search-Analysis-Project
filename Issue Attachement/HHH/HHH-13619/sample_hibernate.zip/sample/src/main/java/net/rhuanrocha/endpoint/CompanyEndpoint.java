package net.rhuanrocha.endpoint;

import net.rhuanrocha.business.CompanyBusiness;
import net.rhuanrocha.entity.Company;
import net.rhuanrocha.entity.Customer;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URI;
import java.util.ArrayList;
import java.util.Objects;

@Path("/companies")
public class CompanyEndpoint {

    @Inject
    private CompanyBusiness companyBusiness;

    @POST
    public Response insertCompany(){

        Company company = new Company();
        company.setName("Company 2");
        company.setCustomers(new ArrayList<>());

        for(int i = 1; i <= 2; i++){
            Customer customer = new Customer();
            customer.setName("Customer "+i);
            company.getCustomers().add(customer);
        }

        companyBusiness.insert(company);

        return Response
                .created(null)
                .build();

    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response findAll(){

        return Response
                .ok(companyBusiness.findAll())
                .build();
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/test")
    public Response test(@QueryParam("name") String name){


        return Response.ok(companyBusiness.findByName(Objects.nonNull(name)? name : "Company 1")).build();
    }



}
