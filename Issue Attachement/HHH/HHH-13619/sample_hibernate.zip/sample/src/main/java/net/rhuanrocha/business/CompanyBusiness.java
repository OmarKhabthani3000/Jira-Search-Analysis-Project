package net.rhuanrocha.business;

import net.rhuanrocha.dto.CompanyDto;
import net.rhuanrocha.entity.Company;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.swing.text.html.parser.Entity;
import java.util.List;
import java.util.Objects;

@Stateless
public class CompanyBusiness {

    @PersistenceContext
    private EntityManager entityManager;

    public Company insert(Company company){

        if(Objects.nonNull(company.getId())){
            throw new IllegalArgumentException("Company.id should be null");
        }

        entityManager.persist( company );

        return company;

    }

    public List<Company> findAll(){
        return entityManager
                .createQuery("select c from Company c ")
                .getResultList();
    }

    public List<CompanyDto> findByName(String name){

        String hql = "select distinct new net.rhuanrocha.dto.CompanyDto(c.id,c.name,size(c.customers)) "
                +    " from Company c left join c.customers cu"
                +    " where c.name =:name "
                +    " group by c.id, c.name ";

        Query query = entityManager.createQuery(hql);
        query.setParameter("name", name);

        return query.getResultList();

    }
}
