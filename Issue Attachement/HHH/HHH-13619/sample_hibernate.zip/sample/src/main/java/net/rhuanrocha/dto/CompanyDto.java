package net.rhuanrocha.dto;

import java.util.Objects;

public class CompanyDto {

    public Long id;

    public String name;

    public int sizeCustomer;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSizeCustomer() {
        return sizeCustomer;
    }

    public void setSizeCustomer(int sizeCustomer) {
        this.sizeCustomer = sizeCustomer;
    }

    public CompanyDto(){}

    public CompanyDto(Long id, String name, int sizeCustomer){
        this.id = id;
        this.name = name;
        this.sizeCustomer = sizeCustomer;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CompanyDto that = (CompanyDto) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
