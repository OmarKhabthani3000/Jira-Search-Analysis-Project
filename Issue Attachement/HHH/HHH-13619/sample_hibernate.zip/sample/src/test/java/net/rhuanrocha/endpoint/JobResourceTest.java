package net.rhuanrocha.endpoint;


public class JobResourceTest {



}
