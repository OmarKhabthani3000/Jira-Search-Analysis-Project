package readonlyhibernatetest;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "PATIENT_EVENT_LIST")
public class Patient {

    private static final long serialVersionUID = -601288023188427399L;
    private Integer id;
    private String name;
   
    private List<EventAction> eventActions;



    @Id
    @Column(name = "ID")
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Column(name = "NAME")
    public String getName() {
        return name;
    }

   
    public void setName(String name) {
        this.name = name;
    }

    
    @OneToMany(fetch = FetchType.EAGER, cascade=CascadeType.ALL)
    @JoinTable(name = "PATIENT_EVENTS", joinColumns = @JoinColumn(name = "PATIENT_EVENT_LIST_FK", referencedColumnName = "ID"), inverseJoinColumns = @JoinColumn(name = "EVENTS_ACTION_FK", referencedColumnName = "ID"))
    public List<EventAction> getEventActions() {
        return eventActions;
    }

    public void setEventActions(
            List<EventAction> eventActions) {
        this.eventActions = eventActions;
    }

   

}

