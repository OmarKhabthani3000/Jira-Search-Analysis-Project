/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package readonlyhibernatetest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

/**
 *
 * @author daniela
 */
public class HibernateUtil {
private static final SessionFactory sessionFactory;
public static String url = "jdbc:oracle:thin:@localhost:1521:xe";
public static String dbdriver = "oracle.jdbc.driver.OracleDriver";
public static String username = "test";
public static String password = "test";

    static {
        try {

            sessionFactory = new AnnotationConfiguration().
                    addPackage("readonlyhibernatetest") //the fully qualified package name
                    .addAnnotatedClass(EventAction.class)
                    .addAnnotatedClass(EventType.class)
                    .addAnnotatedClass(Patient.class).
                    configure().buildSessionFactory();
        } catch (Throwable ex) {
            // Log exception!
            throw new ExceptionInInitializerError(ex);
        }
    }


    public static final ThreadLocal session = new ThreadLocal();

    public static Session currentSession() throws HibernateException {
        Session s = (Session) session.get();
        // Open a new Session, if this thread has none yet
        if (s == null) {
            s = sessionFactory.openSession();
            // Store it in the ThreadLocal variable
            session.set(s);
        }
        
        return s;
    }

    public static void closeSession() throws HibernateException {
        Session s = (Session) session.get();
        if (s != null)
            s.close();
        session.set(null);
    }

    static Connection conn;
    static Statement st;

    public static void setup(String sql) {
        try {
            createStatement();
            st.executeUpdate(sql);
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            e.printStackTrace();
            System.exit(0);
        }
    }

    public static void createStatement() {
        try {
            Class.forName(dbdriver);
            conn = DriverManager.getConnection(url, username, password);
            st = conn.createStatement();
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            e.printStackTrace();
            System.exit(0);
        }
    }

}
