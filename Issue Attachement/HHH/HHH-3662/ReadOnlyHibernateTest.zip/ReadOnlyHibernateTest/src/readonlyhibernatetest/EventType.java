package readonlyhibernatetest;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Immutable;



@Entity
@Table(name = "EVENT_TYPE")
@Immutable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class EventType implements Serializable {

    private static final long serialVersionUID = -5429999423598552267L;

    private Integer id;

    private String descriptor;



   
    @Id
    @Column(name = "ID")
    public Integer getId() {
        return id;
    }

  
    public void setId(Integer id) {
        this.id = id;
    }

   
    @Column(name = "DESCRIPTOR")
    public String getDescriptor() {
        return descriptor;
    }

  
    public void setDescriptor(String descriptor) {
        this.descriptor = descriptor;
    }

}

