package readonlyhibernatetest;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Immutable;


@Entity
@Table(name = "EVENTS_ACTION")
@Immutable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class EventAction implements Serializable {

	private static final long serialVersionUID = 3671281676205215835L;

	private Integer id;

	private EventType eventType;

	private String screenLabel;

	private String permissionName;


	@Id
	@Column(name = "ID")
	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EVENT_TYPE_FK")
	public EventType getEventType() {
		return eventType;
	}


	public void setEventType(EventType eventType) {
		this.eventType = eventType;
	}


	@Column(name = "SCREEN_LABEL")
	public String getScreenLabel() {
		return screenLabel;
	}


	public void setScreenLabel(String label) {
		this.screenLabel = label;
	}


	@Column(name = "PERMISSION_NAME")
	public String getPermissionName() {
		return permissionName;
	}


	public void setPermissionName(String permissionName) {
		this.permissionName = permissionName;
	}

}

