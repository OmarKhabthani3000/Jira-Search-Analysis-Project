/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package readonlyhibernatetest;

import java.util.ArrayList;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author daniela
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        HibernateUtil.createStatement();

        Session session = HibernateUtil.currentSession();

        // Perform life-cycle operations under a transaction
        Transaction tx = null;
        try {
            tx = session.beginTransaction();

            Query query=session.createQuery("from Patient where id=1");

            Patient patient=(Patient) query.uniqueResult();

            System.out.println(patient.getName());

            patient.setEventActions(new ArrayList<EventAction>());

            EventAction event=new EventAction();

            event.setId(1);

            patient.getEventActions().add(event);

            session.merge(patient);

            
            tx.commit();
            tx = null;
        } catch ( HibernateException e ) {
            if ( tx != null ) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }


    }

}
