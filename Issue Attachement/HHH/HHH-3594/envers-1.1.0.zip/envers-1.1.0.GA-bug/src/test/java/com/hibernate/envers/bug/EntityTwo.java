package com.hibernate.envers.bug;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.jboss.envers.Versioned;

@Entity
@Versioned
public class EntityTwo {
	
	@Id @GeneratedValue
    @Versioned
    private int id;
	
    @Versioned
    private String name;
    
    @ManyToOne
    private EntityOne entityOne;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public EntityOne getEntityOne() {
		return entityOne;
	}

	public void setEntityOne(EntityOne entityOne) {
		this.entityOne = entityOne;
	}
}
