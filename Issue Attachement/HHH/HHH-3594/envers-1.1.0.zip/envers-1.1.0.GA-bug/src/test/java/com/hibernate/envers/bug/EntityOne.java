package com.hibernate.envers.bug;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.jboss.envers.Versioned;

@Entity
public class EntityOne {

	@Id @GeneratedValue
    @Versioned
    private int id;
	
    @Versioned
    private String name;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "entityOne")
    @Versioned
    private Set<EntityTwo> entityTwos;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<EntityTwo> getEntityTwos() {
		return entityTwos;
	}

	public void setEntityTwos(Set<EntityTwo> entityTwos) {
		this.entityTwos = entityTwos;
	}
	
	public void setEntityTwo(EntityTwo two) {
		if (entityTwos == null) {
			entityTwos = new HashSet<EntityTwo>();
		}
		entityTwos.add(two);
	}

}
