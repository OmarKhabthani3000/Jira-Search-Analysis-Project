package com.hibernate.envers.bug;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest extends TestCase {

	private EntityManagerFactory emFactory;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		try {
			System.out.println("Building JPA EntityManager for unit tests");
			emFactory = Persistence.createEntityManagerFactory("test");
		} catch (Exception ex) {
			ex.printStackTrace();
			fail("Exception during JPA EntityManager instanciation.");
		}
	}

	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
		System.out.println("Shuting down Hibernate JPA layer.");
		if (emFactory != null) {
			emFactory.close();
		}
		System.out.println("Stopping in-memory HSQL database.");
	}

	public void testPersistence() {
		try {
			EntityManager em = emFactory.createEntityManager();
			em.getTransaction().begin();
			EntityOne one = new EntityOne();
			one.setName("number one");
			System.out.println("working here louie liu");
			em.persist(one);
			em.getTransaction().commit();
			em.close();
			
			EntityManager em2 = emFactory.createEntityManager();
			em2.getTransaction().begin();
			EntityOne one2 = em2.find(EntityOne.class, Integer.valueOf(1));
			System.out.println("entity one name=" + one2.getName());
			EntityTwo two = new EntityTwo();
			two.setName("entity two");
			one2.setEntityTwo(two);
			em2.merge(one2);
			em2.getTransaction().commit();
			em2.close();
			
		} catch (Exception ex) {
			ex.printStackTrace();
			fail("Exception during testPersistence");			
		} 
	}


	/**
	 * Create the test case
	 * 
	 * @param testName
	 *            name of the test case
	 */
	public AppTest(String testName) {
		super(testName);
	}

	/**
	 * @return the suite of tests being tested
	 */
	public static Test suite() {
		return new TestSuite(AppTest.class);
	}

	/**
	 * Rigourous Test :-)
	 */
	public void testApp() {
		assertTrue(true);
	}
}
