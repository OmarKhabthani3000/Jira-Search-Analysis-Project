
package enversbug;


import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;


/**
 * 
 * TODO: [MODEL] Im UML-Modell kommentieren.
 */
@Entity
@org.hibernate.envers.Audited
@DiscriminatorValue("CLASSD")
public class D extends DBase
{
}