
package enversbug;


import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;


/**
 * 
 * WARNING: Please don't edit this .java file.
 * This .java file is generated.
 * 
 * TODO: [MODEL] Im UML-Modell kommentieren.
 */
@MappedSuperclass
public abstract class BBase /*implements DomainBase*/
{
	/**
	 * Object-Id
	 */
	@Id
	@org.hibernate.annotations.GenericGenerator(name = "generator::enversbug.B", strategy = "seqhilo",
	                                            parameters = { @org.hibernate.annotations.Parameter(name="sequence", value = "SEQ_BBB"),
	                                                           @org.hibernate.annotations.Parameter(name="max_lo", value = "100"),
	                                                           @org.hibernate.annotations.Parameter(name="parameters", value = "minvalue 1 start with 1 increment by 1 nocache") })
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator::enversbug.B")
	@Column(name = "BBB_ID", columnDefinition = "NUMBER(38, 0)")
	private Long id;

	/**
	 * Versioning for optimistic locking
	 */
	@Version
	@Column(name = "BBB_VERSION", nullable = false)
	private Integer version;

	/**
	 * Rolle: a.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 *   "b": B [navigable = true] [MANY] (THIS END)
	 *   "a": A [navigable = true] [ONE] (OPPOSITE END)
	 */
	@ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH}, fetch = FetchType.LAZY)
	@org.hibernate.annotations.ForeignKey(name = "A_ID_FK")
	@org.hibernate.annotations.Index(name = "IX_A_ID")
	@JoinColumn(name = "A_ID")
	@org.hibernate.validator.NotNull
	private A a;

	/**
	 * Getter der Object-Id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Versioning for optimistic locking
	 */
	public Integer getVersion() {
		return version;
	}
	
	/**
	 * Ueberschreibe diese Methode um die grundlegende Initialisierung der Instanz zu erreichen.
	 */
	public void initialize() {
	}

	@Override
	public boolean equals(Object other) {
		if (this == other)
			return true;
		else {
			if (other instanceof B) {
				if (getId() == null)
					return businessKeyEquals((B)other);
				else
					return getId().equals(((B)other).getId());
			} else
				return false;
		}
	}

	/**
	 * 
	 * Override this method for business key equality by using for example
	 * EqualsBuilder().append(..., other....).append(..., other....).isEquals();
	 * 
	 * @return  true if this object is the same as the obj argument; false otherwise.
	 */
	protected boolean businessKeyEquals(B other) {
		return false;
	}

	/**
	 * Getter des Attributs: a:A.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 *
	 * @return
	 */
	public A getA() {
		return a;
	}
		
	/**
	 * Setter des Attributs: a:A.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 *
	 */
	public void setA(A a) {
		if (null == a) {
			if (null != getA()) {
				getA()._removeFromB((B)this);
				_setA(null);
			}	
		} else {
			_setA(a);
			a._addToB((B)this);
		}		
	}

	public void _setA(A a) {
		this.a = a;	
	}		

	@Override
	public String toString() {
		StringBuffer stringBuffer = new StringBuffer(super.toString()); stringBuffer.append("\n");
		stringBuffer.append("\toid: " + getId() + "\n");
		return stringBuffer.toString();
	}
}