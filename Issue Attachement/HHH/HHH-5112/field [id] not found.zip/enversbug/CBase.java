
package enversbug;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;


/**
 * 
 * WARNING: Please don't edit this .java file.
 * This .java file is generated.
 * 
 * TODO: [MODEL] Im UML-Modell kommentieren.
 */
@MappedSuperclass
public abstract class CBase /*implements DomainBase*/
{
	/**
	 * Object-Id
	 */
	@Id
	@org.hibernate.annotations.GenericGenerator(name = "generator::enversbug.C", strategy = "seqhilo",
	                                            parameters = { @org.hibernate.annotations.Parameter(name="sequence", value = "SEQ_CCC"),
	                                                           @org.hibernate.annotations.Parameter(name="max_lo", value = "100"),
	                                                           @org.hibernate.annotations.Parameter(name="parameters", value = "minvalue 1 start with 1 increment by 1 nocache") })
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator::enversbug.C")
	@Column(name = "CCC_ID", columnDefinition = "NUMBER(38, 0)")
	private Long id;

	/**
	 * Versioning for optimistic locking
	 */
	@Version
	@Column(name = "CCC_VERSION", nullable = false)
	private Integer version;

	/**
	 * Getter der Object-Id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Versioning for optimistic locking
	 */
	public Integer getVersion() {
		return version;
	}
	
	/**
	 * Ueberschreibe diese Methode um die grundlegende Initialisierung der Instanz zu erreichen.
	 */
	public void initialize() {
	}

	@Override
	public boolean equals(Object other) {
		if (this == other)
			return true;
		else {
			if (other instanceof C) {
				if (getId() == null)
					return businessKeyEquals((C)other);
				else
					return getId().equals(((C)other).getId());
			} else
				return false;
		}
	}

	/**
	 * 
	 * Override this method for business key equality by using for example
	 * EqualsBuilder().append(..., other....).append(..., other....).isEquals();
	 * 
	 * @return  true if this object is the same as the obj argument; false otherwise.
	 */
	protected boolean businessKeyEquals(C other) {
		return false;
	}

	@Override
	public String toString() {
		StringBuffer stringBuffer = new StringBuffer(super.toString()); stringBuffer.append("\n");
		stringBuffer.append("\toid: " + getId() + "\n");
		return stringBuffer.toString();
	}
}