
package enversbug;


import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * 
 * TODO: [MODEL] Im UML-Modell kommentieren.
 */
@Entity
@org.hibernate.envers.Audited
@Table(name = "BBB")
public class B extends BBase
{
}