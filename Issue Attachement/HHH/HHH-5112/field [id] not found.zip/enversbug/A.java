
package enversbug;


import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * 
 * TODO: [MODEL] Im UML-Modell kommentieren.
 */
@Entity
@org.hibernate.envers.Audited
@Table(name = "AAA")
public class A extends ABase
{
}