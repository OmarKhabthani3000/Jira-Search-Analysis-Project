
package enversbug;


import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;


/**
 * 
 * WARNING: Please don't edit this .java file.
 * This .java file is generated.
 * 
 * TODO: [MODEL] Im UML-Modell kommentieren.
 */
@MappedSuperclass
public abstract class ABase /*implements DomainBase*/
{
	/**
	 * Object-Id
	 */
	@Id
	@org.hibernate.annotations.GenericGenerator(name = "generator::enversbug.A", strategy = "seqhilo",
	                                            parameters = { @org.hibernate.annotations.Parameter(name="sequence", value = "SEQ_AAA"),
	                                                           @org.hibernate.annotations.Parameter(name="max_lo", value = "100"),
	                                                           @org.hibernate.annotations.Parameter(name="parameters", value = "minvalue 1 start with 1 increment by 1 nocache") })
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator::enversbug.A")
	@Column(name = "AAA_ID", columnDefinition = "NUMBER(38, 0)")
	private Long id;

	/**
	 * Versioning for optimistic locking
	 */
	@Version
	@Column(name = "AAA_VERSION", nullable = false)
	private Integer version;

	/**
	 * Rolle: b.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 *   "a": A [navigable = true] [ONE] (THIS END)
	 *   "b": B [navigable = true] [MANY] (OPPOSITE END)
	 */
	@OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH}, mappedBy = "a")
	private final Set<B> b = new HashSet<B>();

	/**
	 * Rolle: c.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 *   "": A [navigable = false] [ONE] (THIS END)
	 *   "c": C [navigable = true] [ONE] (OPPOSITE END)
	 */
	@OneToOne(optional = true, cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH}, fetch = FetchType.LAZY)
	@org.hibernate.annotations.ForeignKey(name = "C_ID_FK")
	@JoinColumn(name = "C_ID", unique = true)
	@org.hibernate.annotations.LazyToOne(value = org.hibernate.annotations.LazyToOneOption.NO_PROXY)
	private C c;

	/**
	 * Getter der Object-Id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Versioning for optimistic locking
	 */
	public Integer getVersion() {
		return version;
	}
	
	/**
	 * Ueberschreibe diese Methode um die grundlegende Initialisierung der Instanz zu erreichen.
	 */
	public void initialize() {
	}

	@Override
	public boolean equals(Object other) {
		if (this == other)
			return true;
		else {
			if (other instanceof A) {
				if (getId() == null)
					return businessKeyEquals((A)other);
				else
					return getId().equals(((A)other).getId());
			} else
				return false;
		}
	}

	/**
	 * 
	 * Override this method for business key equality by using for example
	 * EqualsBuilder().append(..., other....).append(..., other....).isEquals();
	 * 
	 * @return  true if this object is the same as the obj argument; false otherwise.
	 */
	protected boolean businessKeyEquals(A other) {
		return false;
	}

	/**
	 * Getter des Collection-Attributs: b:Set<B>.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 *
	 * @return
	 */
	public Set<B> getB() {
		return b;
	}
	
	/**
	 * Fuegt eine Instanz der Collection: b:Set<B> hinzu.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 *
	 * @return
	 */
	public void addToB(B b) {
		if (null == b) {
			throw new IllegalArgumentException("b must not be [null]");
		}
		
		_addToB(b);
		b._setA((A)this);
	}
	
	/**
	 * Entfernt eine Instanz aus der Collection: b:Set<B> sofern vorhanden.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 *
	 * @return
	 */
	public void removeFromB(B b) {
		if (null == b) {
			throw new IllegalArgumentException("b must not be [null]");
		}
	
		_removeFromB(b);
		b._setA(null);
	}
	
	public void _addToB(B b) {		
		this.b.add(b);
	}
	
	public void _removeFromB(B b) {
		this.b.remove(b);
	}
		


	/**
	 * Getter des Attributs: c:C.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 *
	 * @return
	 */
	public C getC() {
		return c;
	}

	/**
	 * Setter des Attributs: c:C.
	 *
	 * TODO: [MODEL] Im UML-Modell kommentieren.
	 *
	 * @param c
	 */
	public void setC(C c) {
		this.c = c;
	}

	@Override
	public String toString() {
		StringBuffer stringBuffer = new StringBuffer(super.toString()); stringBuffer.append("\n");
		stringBuffer.append("\toid: " + getId() + "\n");
		return stringBuffer.toString();
	}
}