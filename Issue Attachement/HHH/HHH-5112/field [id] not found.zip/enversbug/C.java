
package enversbug;


import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;


/**
 * 
 * TODO: [MODEL] Im UML-Modell kommentieren.
 */
@Entity
@org.hibernate.envers.Audited
@Table(name = "CCC")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "CCC_DISCRIMINATOR", discriminatorType = DiscriminatorType.STRING)
@DiscriminatorValue("CLASSC")
public class C extends CBase
{
}