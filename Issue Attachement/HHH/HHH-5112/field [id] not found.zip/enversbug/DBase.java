
package enversbug;


import javax.persistence.MappedSuperclass;


/**
 * 
 * WARNING: Please don't edit this .java file.
 * This .java file is generated.
 * 
 * TODO: [MODEL] Im UML-Modell kommentieren.
 */
@MappedSuperclass
public abstract class DBase extends C
{

	@Override
	public String toString() {
		StringBuffer stringBuffer = new StringBuffer(super.toString()); stringBuffer.append("\n");
		stringBuffer.append("\toid: " + getId() + "\n");
		return stringBuffer.toString();
	}
}