package org.hibernate.bugs;

import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "CONTAINER")
public class Container {
	@Id
	@Column(name = "ID")
	private long id;

	@OneToMany(fetch = FetchType.EAGER)
	@Fetch(FetchMode.SUBSELECT)
	@JoinColumn(name = "PARENT_ID", referencedColumnName = "ID")
	@MapKey(name = "type")
	private Map<Integer, Child> childrenByType;

	@Transient
	private Child type1;

	@Transient
	private Child type2;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@PostLoad
	private void postLoad() {
		type1 = childrenByType.get(1);
		type2 = childrenByType.get(2);
	}
}
