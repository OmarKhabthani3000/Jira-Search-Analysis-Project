package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		insertContainer(1, entityManager);
		insertContainer(2, entityManager);
		insertContainer(3, entityManager);

		insertChild(1, 1, entityManager);
		insertChild(1, 2, entityManager);
		insertChild(1, 3, entityManager);
		insertChild(1, 4, entityManager);

		insertChild(2, 1, entityManager);
		insertChild(2, 2, entityManager);
		insertChild(2, 3, entityManager);
		insertChild(2, 4, entityManager);

		insertChild(3, 1, entityManager);
		insertChild(3, 2, entityManager);
		insertChild(3, 3, entityManager);
		insertChild(3, 4, entityManager);

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh123Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		entityManager.createQuery("select c from " + Container.class.getName() + " c").getResultList();

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	private void insertContainer(int id, EntityManager em) {
		Container c = new Container();
		c.setId(id);
		em.persist(c);
	}

	private void insertChild(int containerId, int type, EntityManager em) {
		Child child = new Child();
		child.setId(containerId * 10 + type);
		child.setContainerId(containerId);
		child.setType(type);
		em.persist(child);
	}
}
