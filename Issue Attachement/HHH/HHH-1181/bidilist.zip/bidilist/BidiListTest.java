//$Id: BidiListTest.java,v 1.6 2005/07/16 22:28:30 oneovthafew Exp $
package org.hibernate.test.bidilist;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.TestCase;

/**
 * @author Gavin King
 */
public class BidiListTest extends TestCase {
	
	public BidiListTest(String str) {
		super(str);
	}
	
	public void testPersistCascasde() {
		Session s = openSession();
		Transaction t = s.beginTransaction();

		Parent p = new Parent("Marc");
		Parent p2 = new Parent("Nathalie");

        // FAILS
        s.persist(p);
        s.persist(p2);

		Child c = new Child("Elvira");
		Child c2 = new Child("Blase");
		p.getChildren().add(c);
        c.setParent(p);
		p.getChildren().add(c2);
        c2.setParent(p);

        // WORKS
        //s.persist(p);
        //s.persist(p2);

		t.commit();
		s.close();

	}
	
	protected String[] getMappings() {
		return new String[] { "bidilist/ParentChild.hbm.xml" };
	}

	public static Test suite() {
		return new TestSuite(BidiListTest.class);
	}

	public String getCacheConcurrencyStrategy() {
		return null;
	}

}

