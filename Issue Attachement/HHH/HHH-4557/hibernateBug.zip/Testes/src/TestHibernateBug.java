import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.hibernate.Query;
import org.hibernate.ScrollableResults;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.classic.Session;
import org.hibernate.dialect.H2Dialect;
import org.junit.Test;

public class TestHibernateBug {

    /**
     * The unique result returns the connection to the connection provider while another ScrollableResults is using it.<br>
     * <br>
     * The configuration:
     * <ul>
     * <li>Hibernate: 3.2.6.ga (<a
     * href=http://sourceforge.net/projects/hibernate/files/hibernate3/3.2.6.ga/hibernate-3.2.6.ga.zip/download>click
     * here to download</a>)</li>
     * <li>Database: H2 (<a href=http://hsql.sourceforge.net/m2-repo/com/h2database/h2/1.2.125/h2-1.2.125.jar>click here
     * to download</a>)</li>
     * <li>Connection Provider: C3P0ConnectionProvider</li>
     * </ul>
     * Hibernate
     */
    @Test
    public void testBug() throws Exception {
        Configuration cfg = new Configuration();

        // Hibernate H2 configuration
        cfg.setProperty(Environment.DIALECT, H2Dialect.class.getName());
        cfg.setProperty(Environment.DRIVER, org.h2.Driver.class.getName());
        cfg.setProperty(Environment.URL, "jdbc:h2:mem:hibernate666");
        cfg.setProperty(Environment.USER, "sa");
        cfg.setProperty(Environment.PASS, "");
        cfg.setProperty(Environment.HBM2DDL_AUTO, "create");
        cfg.setProperty(Environment.SHOW_SQL, "true");
        cfg.setProperty(Environment.AUTOCOMMIT, "true");
        cfg.setProperty(Environment.C3P0_MIN_SIZE, "5");
        cfg.setProperty(Environment.C3P0_MAX_SIZE, "10");

        // Entities
        cfg.addClass(MyEntity.class);

        SessionFactory sf = cfg.buildSessionFactory();
        Session s = sf.openSession();
        try {
            // make data
            MyEntity entity = new MyEntity(1, "Entity 1");
            s.save(entity);
            entity = new MyEntity(2, "Entity 2");
            s.save(entity);
            s.flush();

            // scrollable results 
            Query qsr = s.createQuery("from MyEntity");
            ScrollableResults sr = qsr.scroll();
            try {
                assertTrue(sr.next());

                // another query to get another object by UNIQUERESULT
                Query qo = s.createQuery("from MyEntity where code = 1");
                assertNotNull(qo.uniqueResult());

                // continue iterating socrollable results..
                assertTrue(sr.next()); // this next will got an exception: connection closed!!!!
            } finally {
                sr.close();
            }
        } finally {
            s.close();
            sf.close();
        }
    }
}
