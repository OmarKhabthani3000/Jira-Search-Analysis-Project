import java.io.Serializable;

public class MyEntity implements Serializable {

    private int code;
    private String name;

    public MyEntity() {
        // 
    }

    public MyEntity(int code) {
        this.code = code;
    }

    public MyEntity(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        StringBuilder ret = new StringBuilder();
        ret.append(MyEntity.class.getName()).append(" {\n");
        ret.append("\tPERID = ").append(getCode()).append("\n");
        ret.append("}");
        return ret.toString();
    }

}
