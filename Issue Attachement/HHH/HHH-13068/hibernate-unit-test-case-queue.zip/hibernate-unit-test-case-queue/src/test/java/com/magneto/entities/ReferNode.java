package com.magneto.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicUpdate
@DynamicInsert
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class ReferNode extends EntityTreeNode {

    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    private NodeLink    nodeLink;

	public NodeLink getNodeLink() {
		return nodeLink;
	}

	public void setNodeLink(NodeLink nodeLink) {
		this.nodeLink = nodeLink;
	}

	public ReferNode(EntityTreeNode leftNode, EntityTreeNode rightNode, NodeLink nodeLink) {
		super(leftNode, rightNode);
		this.nodeLink = nodeLink;
	}
    
	public ReferNode(){
		super();
	}
    

}
