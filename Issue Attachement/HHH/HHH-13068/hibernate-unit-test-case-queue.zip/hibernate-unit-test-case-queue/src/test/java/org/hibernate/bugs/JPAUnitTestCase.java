package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.magneto.entities.*;
/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	//Reported case
	@Test
	public void InsertSortingTest1() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		NodeLongValue longVal = new NodeLongValue();
		longVal.setLongValue(666L);
		NodeStringValue stringVal = new NodeStringValue();
		stringVal.setStringValue("mr. sandman");
		
		EntityTreeNode etn = new EntityTreeNode(null, null);
		ContentNode cn1 = new ContentNode(stringVal, null, null);
		ContentNode cn2 = new ContentNode(longVal, cn1, null);
		
		NodeLink nl = new NodeLink(cn2);
		
		ReferNode rn1 = new ReferNode(etn, null, nl);
	
		entityManager.persist(rn1);
		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
	//This test passes
	@Test
	public void InsertSortingTest2() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		NodeLongValue aparam = new NodeLongValue();
		aparam.setLongValue(666L);
//		NodeStringValue dparam = new NodeStringValue();
//		dparam.setStringValue("mr. sandman");
		
		ContentNode xa = new ContentNode(aparam,null, null);
		ContentNode xb = new ContentNode(aparam, null, null);
		ContentNode xc = new ContentNode(aparam, xb, null);
		
		NodeLink nl = new NodeLink(xc);
		
		ReferNode ya = new ReferNode(xa, null, nl);
	
		entityManager.persist(ya);
		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
	//Test fails
	@Test
	public void InsertSortingTest3() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		NodeLongValue longVal = new NodeLongValue();
		longVal.setLongValue(666L);
		NodeStringValue stringVal = new NodeStringValue();
		stringVal.setStringValue("mr. sandman");
		
		EntityTreeNode etn = new EntityTreeNode(null, null);
		ContentNode cn1 = new ContentNode(stringVal, null, null);
		ContentNode cn2 = new ContentNode(longVal, cn1, null);
		
		ReferNode rn1 = new ReferNode(etn, cn2, null);
	
		entityManager.persist(rn1);
		entityManager.getTransaction().commit();
		entityManager.close();
	}

	//Test passes as multiple entitytypes from same table [EntityTreeNode] arent used
	@Test
	public void InsertSortingTest4() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		NodeLongValue longVal = new NodeLongValue();
		longVal.setLongValue(666L);
		NodeStringValue stringVal = new NodeStringValue();
		stringVal.setStringValue("mr. sandman");
		
		ContentNode cn1 = new ContentNode(stringVal, null, null);
		ContentNode cn2 = new ContentNode(longVal, cn1, null);
		
		ContentNode cn3 = new ContentNode(null, cn1, cn2);
	
		entityManager.persist(cn3);
		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
	//Test passes as multiple entitytypes from same table [EntityTreeNode] arent used, except for root case
	@Test
	public void InsertSortingTest5() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		NodeLongValue longVal = new NodeLongValue();
		longVal.setLongValue(666L);
		NodeStringValue stringVal = new NodeStringValue();
		stringVal.setStringValue("mr. sandman");
		
		EntityTreeNode etn = new EntityTreeNode(null, null);
		ContentNode cn1 = new ContentNode(stringVal, null, null);
		ContentNode cn2 = new ContentNode(longVal, cn1, null);
		
		ContentNode cn3 = new ContentNode(null, etn, cn2);
	
		entityManager.persist(cn3);
		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
	@Test
	public void InsertSortingTest6() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		NodeLongValue longVal = new NodeLongValue();
		longVal.setLongValue(666L);
		NodeStringValue stringVal = new NodeStringValue();
		stringVal.setStringValue("mr. sandman");
		
		EntityTreeNode etn = new EntityTreeNode(null, null);
		ContentNode cn1 = new ContentNode(stringVal, null, null);
		ReferNode rn1 = new ReferNode(null, cn1, null);
		
		ContentNode cn3 = new ContentNode(longVal, etn, rn1);
	
		entityManager.persist(cn3);
		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
	//Passes
	@Test
	public void InsertSortingTest7() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		NodeStringValue stringVal = new NodeStringValue();
		stringVal.setStringValue("mr. sandman");
		
		EntityTreeNode etn = new EntityTreeNode(null, null);
		ContentNode cn1 = new ContentNode(null, etn, null);
		ReferNode rn1 = new ReferNode(null, cn1, null);
		
		entityManager.persist(rn1);
		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
	//Passes
	@Test
	public void InsertSortingTest8() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		NodeStringValue stringVal = new NodeStringValue();
		stringVal.setStringValue("mr. sandman");
		
		EntityTreeNode etn = new EntityTreeNode(null, null);
		ReferNode rn1 = new ReferNode(null, etn, null);
		ContentNode cn3 = new ContentNode(null, rn1, null);
	
		entityManager.persist(cn3);
		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
	@Test
	public void InsertSortingTest9() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		NodeStringValue stringVal = new NodeStringValue();
		stringVal.setStringValue("mr. sandman");
		
		EntityTreeNode etn = new EntityTreeNode(null, null);
		ContentNode cn1 = new ContentNode(null, etn, null);
		ReferNode rn1 = new ReferNode(null, cn1, null);
		
		ContentNode cn3 = new ContentNode(null, rn1, null);
	
		entityManager.persist(cn3);
		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
