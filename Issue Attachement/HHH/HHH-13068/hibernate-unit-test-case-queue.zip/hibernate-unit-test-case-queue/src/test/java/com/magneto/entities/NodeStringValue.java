package com.magneto.entities;

import javax.persistence.Entity;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicUpdate
@DynamicInsert
public class NodeStringValue extends TreeNodeValue {
	
	String stringValue;

	public String getStringValue() {
		return stringValue;
	}

	public void setStringValue(String stringValue) {
		this.stringValue = stringValue;
	}

	public NodeStringValue(String dataType, String stringValue) {
		super(dataType);
		this.stringValue = stringValue;
	}

	public NodeStringValue()
	{
		super();
	}
	

}
