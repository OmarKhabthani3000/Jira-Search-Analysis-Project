package com.magneto.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicUpdate
@DynamicInsert
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class ContentNode extends EntityTreeNode {
	
    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    private TreeNodeValue	nodeValue;

	public TreeNodeValue getNodeValue() {
		return nodeValue;
	}

	public void setNodeValue(TreeNodeValue nodeValue) {
		this.nodeValue = nodeValue;
	}

	public ContentNode(TreeNodeValue nodeValue,EntityTreeNode leftNode, EntityTreeNode rightNode) {
		super(leftNode, rightNode);
		this.nodeValue = nodeValue;
	}
    
	public ContentNode(){
		super();
	}

}
