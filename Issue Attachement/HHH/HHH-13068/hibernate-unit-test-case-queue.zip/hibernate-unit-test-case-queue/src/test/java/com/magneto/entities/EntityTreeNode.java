package com.magneto.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.id.enhanced.SequenceStyleGenerator;

@Entity
@DynamicUpdate
@DynamicInsert
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class EntityTreeNode {
	@GenericGenerator(name = "sequencePerEntityGenerator", strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator", parameters = {
			@Parameter(name = "prefer_sequence_per_entity", value = "true"),
			@Parameter(name = "sequence_per_entity_suffix", value = "_seq"),
			@Parameter(name = "initial_value", value = "5000000"),
			@Parameter(name = SequenceStyleGenerator.INCREMENT_PARAM, value = "1") })
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "sequencePerEntityGenerator")
	@Id
	Long id;
	
    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private EntityTreeNode leftNode;

    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private EntityTreeNode rightNode;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public EntityTreeNode getLeftNode() {
		return leftNode;
	}

	public void setLeftNode(EntityTreeNode leftNode) {
		this.leftNode = leftNode;
	}

	public EntityTreeNode getRightNode() {
		return rightNode;
	}

	public void setRightNode(EntityTreeNode rightNode) {
		this.rightNode = rightNode;
	}

	public EntityTreeNode(EntityTreeNode leftNode, EntityTreeNode rightNode) {
		super();
		this.leftNode = leftNode;
		this.rightNode = rightNode;
	}
    
	public EntityTreeNode(){
		super();
	}

}
