package com.magneto.entities;

import javax.persistence.Entity;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicUpdate
@DynamicInsert
public class NodeLongValue extends TreeNodeValue {
	
	Long longValue;

	public Long getLongValue() {
		return longValue;
	}

	public void setLongValue(Long longValue) {
		this.longValue = longValue;
	}

	public NodeLongValue(String dataType, Long longValue) {
		super(dataType);
		this.longValue = longValue;
	}

	public NodeLongValue() {
		super();
	}


}
