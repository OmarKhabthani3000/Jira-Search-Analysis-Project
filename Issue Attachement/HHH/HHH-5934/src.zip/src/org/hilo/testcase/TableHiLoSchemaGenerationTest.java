package org.hilo.testcase;

import java.io.File;
import java.util.Date;

import junit.framework.TestCase;

import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.Dialect;
import org.hibernate.dialect.Oracle10gDialect;
import org.hibernate.dialect.SQLServer2008Dialect;

public class TableHiLoSchemaGenerationTest extends TestCase
{
    private long id;

    private Date modifydate;

    private String value;

    public long getId()
    {
        return id;
    }

    public void setId(long id)
    {
        this.id = id;
    }

    public Date getModifydate()
    {
        return modifydate;
    }

    public void setModifydate(Date modifydate)
    {
        this.modifydate = modifydate;
    }

    public String getValue()
    {
        return value;
    }

    public void setValue(String value)
    {
        this.value = value;
    }

    private void prepare(Dialect dialect, String type)
    {
        Configuration cfg = new Configuration();
        cfg.addDirectory(new File("./src"));
        cfg.setProperty(Environment.DIALECT, dialect.getClass()
            .getCanonicalName());
        String[] res = cfg.generateSchemaCreationScript(dialect);
        for (String s : res)
        {
            if (s.startsWith("create table hibernate_unique_key"))
            {
                assertEquals(
                    "create table hibernate_unique_key ( next_hi " + type + " )", s);
            }
        }
    }

    public void testOracle()
    {
        prepare(new Oracle10gDialect(), "number(19,0)");
    }

    public void testMssql()
    {
        prepare(new SQLServer2008Dialect(),"numeric(19,0)");
    }
}
