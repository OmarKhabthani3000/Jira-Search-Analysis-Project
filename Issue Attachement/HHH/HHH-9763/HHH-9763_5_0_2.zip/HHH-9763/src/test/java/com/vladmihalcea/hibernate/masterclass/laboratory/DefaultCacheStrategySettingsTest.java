package com.vladmihalcea.hibernate.masterclass.laboratory;

import com.vladmihalcea.hibernate.masterclass.laboratory.util.AbstractTest;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.junit.Test;

import javax.persistence.*;
import java.util.Properties;


/**
 * DefaultCacheStrategySettingsTest - Test to replicate HHH-9763
 *
 * @author Vlad Mihalcea
 */
public class DefaultCacheStrategySettingsTest extends AbstractTest {

    @Override
    protected Class<?>[] entities() {
        return new Class<?>[] {
                Repository.class,
                RepositoryWithExplicitCacheStrategy.class
        };
    }

    @Override
    protected Properties getProperties() {
        Properties properties = super.getProperties();
        properties.put("hibernate.cache.use_second_level_cache", Boolean.TRUE.toString());
        properties.put("hibernate.cache.region.factory_class", "org.hibernate.cache.ehcache.EhCacheRegionFactory");
        properties.put("hibernate.cache.default_cache_concurrency_strategy", "read-write");
        return properties;
    }

    @Test
    public void test() {
        doInTransaction(session -> {
            Repository repository = new Repository("Hibernate-Master-Class");
            session.persist(repository);
            RepositoryWithExplicitCacheStrategy repositoryWithExplicitCacheStrategy = new RepositoryWithExplicitCacheStrategy("RepositoryWithExplicitCacheStrategy");
            session.persist(repositoryWithExplicitCacheStrategy);
        });
        doInTransaction(session -> {
            LOGGER.info("First try");
            Repository repository = (Repository) session.get(Repository.class, 1L);
            RepositoryWithExplicitCacheStrategy repositoryWithExplicitCacheStrategy = (RepositoryWithExplicitCacheStrategy) session.get(RepositoryWithExplicitCacheStrategy.class, 1L);
        });
        doInTransaction(session -> {
            LOGGER.info("Second try");
            Repository repository = (Repository) session.get(Repository.class, 1L);
            RepositoryWithExplicitCacheStrategy repositoryWithExplicitCacheStrategy = (RepositoryWithExplicitCacheStrategy) session.get(RepositoryWithExplicitCacheStrategy.class, 1L);
        });
    }

    /**
     * Repository - Repository
     *
     * @author Vlad Mihalcea
     */
    @Entity(name = "Repository")
    @Cacheable
    public static class Repository {

        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        private Long id;

        private String name;

        public Repository() {
        }

        public Repository(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }
    }

    /**
     * Repository - Repository
     *
     * @author Vlad Mihalcea
     */
    @Entity(name = "RepositoryWithExplicitCacheStrategy")
    @org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    public static class RepositoryWithExplicitCacheStrategy {

        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        private Long id;

        private String name;

        public RepositoryWithExplicitCacheStrategy() {
        }

        public RepositoryWithExplicitCacheStrategy(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }
    }
}
