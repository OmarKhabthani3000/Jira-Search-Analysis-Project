package com.bstirbat.entity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import java.util.List;

import static org.junit.Assert.assertTrue;

@RunWith(JUnit4.class)
public class ProductTest {

    private EntityManagerFactory emf;
    private EntityManager em;

    @Before
    public void setUp() {
        emf = Persistence.createEntityManagerFactory("iventory");
        em = emf.createEntityManager();
    }

    @Test
    public void testOk() {
        Product product = new Product();
        product.setName("test");
        product.setDescription("test");

        em.getTransaction().begin();
        em.persist(product);
        em.getTransaction().commit();

        List<Product> products = em.createQuery("select p from Product p", Product.class)
                .getResultList();

        assertTrue(products.size() == 1);
    }

    @After
    public void tearDown() {
        em.clear();
        em.close();
        emf.close();
    }
}
