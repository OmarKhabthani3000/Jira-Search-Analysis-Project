package net.upf.hibtest.data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class ChildData {
	@Id @GeneratedValue
	long id;

	String childId;

	public ChildData() {
	}

	public ChildData( String id ) {
		childId = id;
	}

	@Override
	public String toString() {
		return childId;
	}
}
