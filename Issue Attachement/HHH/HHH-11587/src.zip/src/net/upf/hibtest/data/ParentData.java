package net.upf.hibtest.data;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;

@Entity
public class ParentData {
	@Id 
	@GeneratedValue
	long id;

	@OneToMany(orphanRemoval=true, cascade={CascadeType.ALL})
	@OrderColumn(name = "INDEX")
	List<ChildData> children = new ArrayList<ChildData>();
	
	public List<ChildData> getChildren() {
		return children;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		for( ChildData child: children ) {
			sb.append( child.toString() );
			sb.append( " / " );
		}
		return sb.toString();
	}
}

//https://forum.hibernate.org/viewtopic.php?f=1&t=1012610&p=2448639&hilit=ordercolumn#p2448639