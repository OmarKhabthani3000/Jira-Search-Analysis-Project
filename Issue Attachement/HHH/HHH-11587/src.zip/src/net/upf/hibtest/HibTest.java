package net.upf.hibtest;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import net.upf.hibtest.data.ChildData;
import net.upf.hibtest.data.ParentData;

public class HibTest {

	public static void main(String[] args) {
		SessionFactory sessionFactory;
		Session session = null;

		System.out.println( System.getProperty("java.version"));
		
		System.out.println(" SETUP HIBERNATE ");
		try {
			Configuration config = new Configuration().configure("/resources/hibernate.cfg.xml");
			sessionFactory = config.buildSessionFactory();
			session = sessionFactory.openSession();
		} catch (Throwable t) {
			System.err.println("Initial SessionFactory creation failed." + t);
			throw new ExceptionInInitializerError(t);
		}

		System.out.println(" CREATE TEST DATA ");
		session.beginTransaction();
		ParentData parent = new ParentData();
		session.save(parent);

		String[] childrenStr = new String[] { "One", "Two", "Three", "Four", "Five" };
		for (String str : childrenStr) {
			ChildData child = new ChildData(str);
			session.save(child);
			parent.getChildren().add(child);
		}
		session.getTransaction().commit();
		
		System.out.println(" MOVE CHILD DATA");
		List<ChildData> children = parent.getChildren();		
		try {
			System.out.println(parent.toString());
			session.beginTransaction();
			ChildData child = children.get(0);
			children.remove(0);
			session.flush();
			children.add(child);
			session.getTransaction().commit();
			System.out.println(parent.toString());
			System.out.println(" !! WORK DONE !!");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(" !! ERROR !!");
			if( session.getTransaction().isActive() )
				if( session.getTransaction().getRollbackOnly() )
					session.getTransaction().rollback();
				else
					session.getTransaction().commit();
		}
		sessionFactory.close();
	}
}
