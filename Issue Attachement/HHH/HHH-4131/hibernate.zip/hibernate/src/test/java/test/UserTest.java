package test;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.BeforeClass;
import org.junit.Test;

public class UserTest {

    private static EntityManagerFactory factory;

    @BeforeClass
    public static void initOnce() {
        factory = Persistence.createEntityManagerFactory("test");
    }

    @Test(expected = EntityExistsException.class)
    public void testPersistDuplicate() {
        EntityManager em = factory.createEntityManager();
        saveUser(em, new User("login123"));
        saveUser(em, new User("login123"));
        em.close();
    }

    private void saveUser(EntityManager em, User user) {
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        em.persist(user);
        tx.commit();
    }

}
