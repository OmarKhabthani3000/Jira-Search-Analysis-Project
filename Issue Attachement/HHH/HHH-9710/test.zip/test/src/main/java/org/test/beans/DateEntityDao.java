package org.test.beans;
import java.util.Date;
import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TemporalType;

@Singleton
@Startup
public class DateEntityDao {
    @PersistenceContext
    EntityManager em;

    @PostConstruct
    public void testQuery() {
        em.createQuery("update DateEntity d set d.createTime = :value").setParameter("value", (Date)null, TemporalType.TIMESTAMP).executeUpdate();
    }
}