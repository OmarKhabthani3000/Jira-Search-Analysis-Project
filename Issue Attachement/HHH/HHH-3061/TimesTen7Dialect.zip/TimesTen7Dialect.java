package org.hibernate.dialect;

import java.sql.Types;

import org.hibernate.Hibernate;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.function.NoArgSQLFunction;
import org.hibernate.dialect.function.NvlFunction;
import org.hibernate.dialect.function.SQLFunctionTemplate;
import org.hibernate.dialect.function.StandardSQLFunction;
import org.hibernate.dialect.function.VarArgsSQLFunction;
import org.hibernate.sql.JoinFragment;
import org.hibernate.sql.OracleJoinFragment;

/**
 * A SQL dialect for TimesTen version 7.x.
 * 
 * Known limitations:
 * 
 * 1. This dialect is designed for use with TimesTen 7.x data stores
 *    configured for Oracle type mode (TypeMode=0).
 * 2. No CLOB/BLOB support (VARCHAR & VARBINARY are used as substitutes).
 * 3. No support for updating primary keys.
 *
 * @author Jason Feldhaus (jason.feldhaus@oracle.com)
 */
 
 
public class TimesTen7Dialect
  extends Dialect
{

  public TimesTen7Dialect()
  {
    super();
    
    // type mappings
    registerColumnType(Types.BIT, "TT_TINYINT");
    registerColumnType(Types.SMALLINT, "TT_SMALLINT");
    registerColumnType(Types.TINYINT, "TT_TINYINT");
    registerColumnType(Types.INTEGER, "TT_INTEGER");
    registerColumnType(Types.BIGINT, "TT_BIGINT");
    
    registerColumnType(Types.CHAR, "CHAR(1)");
    registerColumnType(Types.VARCHAR, 4194304, "VARCHAR2($l)");
    registerColumnType(Types.VARBINARY, 4194304, "VARBINARY($l)");
    
    registerColumnType(Types.NUMERIC, "NUMBER($p,$s)"); 
    registerColumnType(Types.DECIMAL, "NUMBER($p,$s)" );   
    registerColumnType(Types.FLOAT, "BINARY_FLOAT");
    registerColumnType(Types.DOUBLE, "BINARY_DOUBLE");
    
    registerColumnType(Types.DATE, "TT_DATE");
    registerColumnType(Types.TIME, "TT_TIME");
    registerColumnType(Types.TIMESTAMP, "TIMESTAMP");

    // TimesTen has no BLOB/CLOB support, but these types may be suitable
    // for some applications. The length is limited to 4MB.
    registerColumnType(Types.BLOB, "VARBINARY(4194304)");
    registerColumnType(Types.CLOB, "VARCHAR2(4194304)");

    // properties
    getDefaultProperties().setProperty(
      Environment.USE_STREAMS_FOR_BINARY, "true");
                                       
    getDefaultProperties().setProperty(
      Environment.STATEMENT_BATCH_SIZE, DEFAULT_BATCH_SIZE);
      
    // string functions                                 
    registerFunction("lower", new StandardSQLFunction("lower"));
    registerFunction("upper", new StandardSQLFunction("upper"));
    registerFunction("rtrim", new StandardSQLFunction("rtrim"));
    registerFunction("ltrim", new StandardSQLFunction("ltrim") );
    registerFunction("length", 
      new StandardSQLFunction("length", Hibernate.LONG) );
    registerFunction( "concat", 
      new VarArgsSQLFunction( Hibernate.STRING, "(", "||", ")" ) );
    registerFunction("to_char", 
      new StandardSQLFunction("to_char", Hibernate.STRING));
    registerFunction("chr", 
      new StandardSQLFunction("chr", Hibernate.CHARACTER));
    registerFunction("instr", 
      new StandardSQLFunction("instr", Hibernate.INTEGER) );
    registerFunction("instrb", 
      new StandardSQLFunction("instrb", Hibernate.INTEGER) );
    registerFunction("lpad", 
      new StandardSQLFunction("lpad", Hibernate.STRING) );
    registerFunction( "rpad", 
      new StandardSQLFunction("rpad", Hibernate.STRING) );
    registerFunction("substr", 
      new StandardSQLFunction("substr", Hibernate.STRING) );
    registerFunction("substrb", 
      new StandardSQLFunction("substrb", Hibernate.STRING) );
    registerFunction("substring", 
      new StandardSQLFunction( "substr", Hibernate.STRING ) );
    registerFunction("locate", 
      new SQLFunctionTemplate( Hibernate.INTEGER, "instr(?2,?1)" ) );
    registerFunction( "str", 
      new StandardSQLFunction("to_char", Hibernate.STRING) );
      

    // date/time functions  
    registerFunction("to_date", 
      new StandardSQLFunction("to_date", Hibernate.TIMESTAMP));
    registerFunction("sysdate", 
      new NoArgSQLFunction("sysdate", Hibernate.TIMESTAMP, false));
    registerFunction("getdate", 
      new NoArgSQLFunction("getdate", Hibernate.TIMESTAMP, false));

    registerFunction("current_date", 
      new NoArgSQLFunction("sysdate", Hibernate.DATE, false));
    registerFunction("current_time", 
      new NoArgSQLFunction("sysdate", Hibernate.TIME, false));
    registerFunction("current_timestamp", 
      new NoArgSQLFunction("sysdate", Hibernate.TIMESTAMP, false));


    // math functions
    registerFunction("abs", new StandardSQLFunction("abs") );
    registerFunction("sign", 
      new StandardSQLFunction("sign", Hibernate.INTEGER));
    registerFunction("mod", new StandardSQLFunction("mod"));
    registerFunction("round", new StandardSQLFunction("round"));
    registerFunction("trunc", new StandardSQLFunction("trunc"));
    registerFunction("ceil", new StandardSQLFunction("ceil"));
    registerFunction("floor", new StandardSQLFunction("floor"));
    registerFunction("power", 
      new StandardSQLFunction("power", Hibernate.FLOAT));
    
    // misc. functions
    registerFunction("nvl", new StandardSQLFunction("nvl"));
    registerFunction("coalesce", new NvlFunction());
    
    registerFunction( "user", 
      new NoArgSQLFunction("user", Hibernate.STRING, false) );
    
    registerFunction( "rowid", 
      new NoArgSQLFunction("rowid", Hibernate.LONG, false) );
    registerFunction( "rownum", 
      new NoArgSQLFunction("rownum", Hibernate.LONG, false) );
    
      
  }

  public boolean dropConstraints()
  {
    return true;
  }

  public boolean qualifyIndexName()
  {
    return false;
  }

  public boolean supportsUnique()
  {
    return true;
  }

  public boolean supportsUniqueConstraintInCreateAlterTable()
  {
    return false;
  }

  public String getAddColumnString()
  {
    return "add";
  }

  public boolean supportsSequences()
  {
    return true;
  }

  public String getSelectSequenceNextValString(String sequenceName)
  {
    return sequenceName + ".nextval";
  }

  public String getSequenceNextValString(String sequenceName)
  {
    return "select " + sequenceName + ".nextval from sys.dual";
  }

  public String getCreateSequenceString(String sequenceName)
  {
    return "create sequence " + sequenceName;
  }

  public String getDropSequenceString(String sequenceName)
  {
    return "drop sequence " + sequenceName;
  }

  public String getQuerySequencesString()
  {
    return "select name from sys.sequences";
  }

  public JoinFragment createOuterJoinFragment()
  {
    return new OracleJoinFragment();
  }



  public String getForUpdateString()
  {
    return " for update";
  }

  public boolean supportsForUpdateNowait()
  {
    return true;
  }

  public String getForUpdateNowaitString()
  {
    return " for update nowait";
  }


  public boolean supportsColumnCheck()
  {
    return false;
  }

  public boolean supportsTableCheck()
  {
    return false;
  }

  public boolean supportsLimitOffset()
  {
    return true;
  }

  public boolean supportsVariableLimit()
  {
    return true;
  }

  public boolean supportsLimit()
  {
    return true;
  }

  public boolean useMaxForLimit()
  {
    return true;
  }

  public boolean bindLimitParametersFirst() 
  {
    return true;
  }


  public String getLimitString(String query, boolean hasOffset)
  {
    if (hasOffset)
    {
      // use the 'ROWS M to N' syntax
      return new StringBuffer(query.length() + 13).
        append(query).insert(6," rows ? to ? ").toString();
    }

    // use the 'FIRST N' syntax
    return new StringBuffer(query.length() + 9).
      append(query).insert(6, " first ? ").toString();
  }


  public boolean supportsCurrentTimestampSelection()
  {
    return true;
  }

  public String getCurrentTimestampSelectString()
  {
    return "select sysdate from sys.dual";
  }

  public boolean isCurrentTimestampSelectStringCallable()
  {
    return false;
  }

  public boolean supportsTemporaryTables()
  {
    return true;
  }

  public String generateTemporaryTableName(String baseTableName)
  {
    String name = super.generateTemporaryTableName(baseTableName);
    return name.length() > 30? name.substring(1, 30): name;
  }

  public String getCreateTemporaryTableString()
  {
    return "create global temporary table";
  }

  public String getCreateTemporaryTablePostfix()
  {
    return "on commit delete rows";
  }

 
  public boolean supportsUnionAll() 
  {
    return true;
  }


  public boolean supportsEmptyInList()
  {
    return true;
  }

  public boolean supportsCircularCascadeDeleteConstraints()
  {
    return false;
  }

  
  
}
