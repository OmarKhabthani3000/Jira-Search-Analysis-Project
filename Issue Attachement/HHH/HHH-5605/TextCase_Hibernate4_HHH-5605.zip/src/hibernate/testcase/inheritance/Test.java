package hibernate.testcase.inheritance;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import junit.framework.TestCase;

public class Test extends TestCase{
	SessionFactory mSessionFactory;
	
	public void setUp() {
		Configuration lConfig = new Configuration().configure("hibernate/testcase/inheritance/SessionFactory.cfg.xml");
        ServiceRegistry lServiceRegistry = new ServiceRegistryBuilder().applySettings(
        		lConfig.getProperties()).buildServiceRegistry();
		mSessionFactory = lConfig.buildSessionFactory(lServiceRegistry);
		// Create data
		Session lCurrentSession = mSessionFactory.getCurrentSession();
		Transaction lTx = lCurrentSession.beginTransaction();
		BEntity b = new BEntity();
		b.Oid=1;
		b.A=12l;
		b.B=13233334l;
		lCurrentSession.persist(b);
		CEntity c = new CEntity();
		c.Oid=2;
		c.B = "Hi";
		c.C = "out there!";
		lCurrentSession.persist(c);
		lTx.commit();
	}

	@Override
	protected void tearDown() throws Exception {
		mSessionFactory.close();
	}
	
	public void testHQL() {
		Session currentSession = mSessionFactory.getCurrentSession();
		Transaction lTx = currentSession.beginTransaction();
		Query lQuery = currentSession.createQuery("from hibernate.testcase.inheritance.AEntity");
		lQuery.list();
		lTx.commit();
	}
}
