package hibernate.testcase.inheritance;

public class CEntity extends AEntity {
	
	public String B;
	public String C;
	public String getB() {
		return B;
	}
	public void setB(String b) {
		B = b;
	}
	public String getC() {
		return C;
	}
	public void setC(String c) {
		C = c;
	}
	
	

}
