package hibernate.testcase.inheritance;

public abstract class AEntity {
	
	public long Oid;

	public long getOid() {
		return Oid;
	}

	public void setOid(long oid) {
		Oid = oid;
	}
	
	

}
