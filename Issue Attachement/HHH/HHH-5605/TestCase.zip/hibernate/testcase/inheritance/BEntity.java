package hibernate.testcase.inheritance;

public class BEntity extends AEntity {
	
	public Long A;
	public Long B;
	public Long getA() {
		return A;
	}
	public void setA(Long a) {
		A = a;
	}
	public Long getB() {
		return B;
	}
	public void setB(Long b) {
		B = b;
	}
	
	

}
