package hibernate.testcase.inheritance;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

import junit.framework.TestCase;

public class Test extends TestCase{
	SessionFactory mSessionFactory;
	
	public void setUp() {
		Configuration lConfig = new Configuration().configure("hibernate/testcase/inheritance/SessionFactory.hbm.cfg");
		mSessionFactory = lConfig.buildSessionFactory();
	}

	@Override
	protected void tearDown() throws Exception {
		mSessionFactory.close();
	}
	
	public void testHQL() {
		Session currentSession = mSessionFactory.getCurrentSession();
		Transaction lTx = currentSession.beginTransaction();
		Query lQuery = currentSession.createQuery("from hibernate.testcase.inheritance.AEntity");
		lQuery.list();
		lTx.commit();
	}
}
