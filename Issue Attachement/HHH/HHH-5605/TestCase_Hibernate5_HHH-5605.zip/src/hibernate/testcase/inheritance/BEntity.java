package hibernate.testcase.inheritance;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;

@Entity
@Table(name="B")
@BatchSize(size=20)
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public class BEntity extends AEntity {
	
	public Long A;
	public Long B;
	public Long getA() {
		return A;
	}
	public void setA(Long a) {
		A = a;
	}
	public Long getB() {
		return B;
	}
	public void setB(Long b) {
		B = b;
	}
	
	

}
