package hibernate.testcase.inheritance;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CheckInheritanceFault {
	SessionFactory mSessionFactory;
	
	@Before
	public void setUp() {
		Configuration lConfig = new Configuration().configure("hibernate/testcase/inheritance/SessionFactory.cfg.xml");
        ServiceRegistry lServiceRegistry = new StandardServiceRegistryBuilder().applySettings(
        		lConfig.getProperties()).build();
        // Had to put this here - other options (e.g. in config file) did not work
        lConfig.addAnnotatedClass(AEntity.class);
        lConfig.addAnnotatedClass(BEntity.class);
        lConfig.addAnnotatedClass(CEntity.class);
		mSessionFactory = lConfig.buildSessionFactory(lServiceRegistry);
		
		

		// Create data
		Session lCurrentSession = mSessionFactory.getCurrentSession();
		Transaction lTx = lCurrentSession.beginTransaction();
		BEntity b = new BEntity();
		b.Oid=1;
		b.A=12l;
		b.B=13233334l;
		lCurrentSession.persist(b);
		CEntity c = new CEntity();
		c.Oid=2;
		c.B = "Hi";
		c.C = "out there!";
		lCurrentSession.persist(c);
		lTx.commit();
	}

	@After
	public void tearDown() throws Exception {
		mSessionFactory.close();
	}
	
	@Test
	public void testHQL() {
		Session currentSession = mSessionFactory.getCurrentSession();
		Transaction lTx = currentSession.beginTransaction();
		Query lQuery = currentSession.createQuery("from hibernate.testcase.inheritance.AEntity");
		lQuery.list();
		lTx.commit();
	}
}
