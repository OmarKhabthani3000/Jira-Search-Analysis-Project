package hibernate.testcase.inheritance;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
//@Table(name="A")
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public abstract class AEntity {
	
	@Id
	public long Oid;

	public long getOid() {
		return Oid;
	}

	public void setOid(long oid) {
		Oid = oid;
	}
	
	

}
