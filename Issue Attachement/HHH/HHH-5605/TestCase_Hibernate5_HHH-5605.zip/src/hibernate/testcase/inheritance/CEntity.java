package hibernate.testcase.inheritance;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;

@Entity
@Table(name="C")
@BatchSize(size=20)
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public class CEntity extends AEntity {
	
	public String B;
	public String C;
	public String getB() {
		return B;
	}
	public void setB(String b) {
		B = b;
	}
	public String getC() {
		return C;
	}
	public void setC(String c) {
		C = c;
	}
	
	

}
