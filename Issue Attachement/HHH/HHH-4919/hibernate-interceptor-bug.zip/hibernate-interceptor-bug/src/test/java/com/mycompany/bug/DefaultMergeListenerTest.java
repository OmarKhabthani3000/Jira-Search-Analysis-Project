package com.mycompany.bug;

import com.mycompany.bug.FooEntity;
import com.mycompany.bug.MyInterceptor;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Unit test for simple App.
 */
public class DefaultMergeListenerTest extends TestCase {

    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public DefaultMergeListenerTest(String testName) {
        super(testName);
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite() {
        return new TestSuite(DefaultMergeListenerTest.class);
    }
    
    SessionFactory sessionFactory;
    Session session;
    Transaction tx;

    protected void setUp() throws Exception {
        sessionFactory = new Configuration().configure("hibernate.xml").setInterceptor(new MyInterceptor()).buildSessionFactory();
        session = sessionFactory.openSession();
        tx = session.beginTransaction();
    }

    protected void tearDown() throws Exception {
        tx.rollback();
        session.close();
    }

    public void testMerge() {


        FooEntity foo = new FooEntity();
        foo.setName("my foo");

        final String expectedInjectedString = "MyInterceptor was here";

        FooEntity merged = (FooEntity) session.merge(foo);
        // Interceptor IS NOT called for instantiating the persistent instance associated to the session when using merge
        assertEquals(expectedInjectedString, merged.getInjectedString());
    }

    public void testLoad() {


        FooEntity foo = new FooEntity();
        foo.setName("my foo");

        final String expectedInjectedString = "MyInterceptor was here";

        FooEntity merged = (FooEntity) session.merge(foo);
        FooEntity loaded = (FooEntity) session.load(FooEntity.class, merged.getId());
        // the session-bound instance was not instantiated by the interceptor, load simply returns it
        assertEquals(expectedInjectedString, loaded.getInjectedString());
    }

    public void testForceReload() {
        FooEntity foo = new FooEntity();
        foo.setName("my foo");

        final String expectedInjectedString = "MyInterceptor was here";

        FooEntity merged = (FooEntity) session.merge(foo);

        // flush the session and evict the merged instance from session to force an actual load
        session.flush();
        session.evict(merged);

        FooEntity reloaded = (FooEntity) session.load(FooEntity.class, merged.getId());
        assertEquals(expectedInjectedString, reloaded.getInjectedString());
    }

}
