/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mycompany.bug;

/**
 *
 * @author fdegrassi
 */
public class FooEntity {
    private Integer id;
    private String name;
    private String injectedString;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getInjectedString() {
        return injectedString;
    }

    public void setInjectedString(String injectedString) {
        this.injectedString = injectedString;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
