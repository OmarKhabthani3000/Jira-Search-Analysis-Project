package com.mycompany.bug;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        SessionFactory sessionFactory = new Configuration().configure("hibernate.xml").setInterceptor(new MyInterceptor()).buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

        FooEntity foo = new FooEntity();
        foo.setName("my foo");
        
        FooEntity merged = (FooEntity) session.merge(foo);
        // Interceptor IS NOT called for instantiating the persistent instance associated to the session when using merge
        System.out.println("merged.injectedString : " + merged.getInjectedString());

        FooEntity loaded = (FooEntity) session.load(FooEntity.class, merged.getId());
        // the session-bound instance was not instantiated by the interceptor, load simply returns it
        System.out.println("loaded.injectedString : " + loaded.getInjectedString());

        // flush the session and evict the merged instance from session to force an actual load
        session.flush();
        session.evict(merged);
        
         FooEntity reloaded = (FooEntity) session.load(FooEntity.class, merged.getId());
        // Interceptor IS called for instantiating the persistent instance associated to the session when using load
        System.out.println("reloaded.injectedString : " + reloaded.getInjectedString());

        tx.commit();
        session.close();

               

    }
}
