/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mycompany.bug;

import java.io.Serializable;
import java.util.Iterator;
import org.hibernate.CallbackException;
import org.hibernate.EntityMode;
import org.hibernate.Interceptor;
import org.hibernate.Transaction;
import org.hibernate.type.Type;

/**
 *
 * @author fdegrassi
 */
public class MyInterceptor implements Interceptor {

    public void afterTransactionBegin(Transaction tx) {
        // Do nothing
    }

    public void afterTransactionCompletion(Transaction tx) {
        // Do nothing
    }

    public void beforeTransactionCompletion(Transaction tx) {
        // Do nothing
    }

    public int[] findDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState, String[] propertyNames, Type[] types) {
        return null;
    }

    public Object getEntity(String entityName, Serializable id) throws CallbackException {
        return null;
    }

    public String getEntityName(Object object) throws CallbackException {
        return null;
    }

    // ONLY REALLY USEFUL METHOD
    public Object instantiate(String entityName, EntityMode entityMode, Serializable id) throws CallbackException {
        if (!"com.mycompany.bug.FooEntity".equals(entityName))
            return null;
        // Simply inject a sample string into new instances
        FooEntity instance = new FooEntity();
        instance.setId((Integer)id);
        instance.setInjectedString("MyInterceptor was here");
        return instance;
    }

    public Boolean isTransient(Object entity) {
        return null;
    }

    public void onCollectionRecreate(Object collection, Serializable key) throws CallbackException {
        // Do nothing
    }

    public void onCollectionRemove(Object collection, Serializable key) throws CallbackException {
        // Do nothing
    }

    public void onCollectionUpdate(Object collection, Serializable key) throws CallbackException {
        // Do nothing
    }

    public void onDelete(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) throws CallbackException {
        // Do nothing
    }

    public boolean onFlushDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState, String[] propertyNames, Type[] types) throws CallbackException {
        return false;
    }

    public boolean onLoad(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) throws CallbackException {
        return false;
    }

    public String onPrepareStatement(String sql) {
        return sql;
    }

    public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) throws CallbackException {
        return false;
    }

    public void postFlush(Iterator entities) throws CallbackException {
        // Do nothing
    }

    public void preFlush(Iterator entities) throws CallbackException {
        // Do nothing
    }

}
