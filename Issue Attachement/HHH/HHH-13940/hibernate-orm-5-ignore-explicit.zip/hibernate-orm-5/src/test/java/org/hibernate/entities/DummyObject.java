package org.hibernate.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Inheritance(
        strategy = InheritanceType.JOINED
)
@Table(
        name = "SUPERCLASS_TABLE"
)
@DiscriminatorColumn(
        name = "SUBCLASS_TYPE",
        discriminatorType = DiscriminatorType.STRING,
        length = 20
)
public class DummyObject implements Serializable {

    @Id
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "SEQ_DUMMYOBJECT"
    )
    @GenericGenerator(
            name = "SEQ_DUMMYOBJECT",
            strategy = "sequence-identity",
            parameters = {@Parameter(
                    name = "sequence",
                    value = "SEQ_DUMMYOBJECT"
            )}
    )
    @Column(
            name = "ID",
            nullable = false,
            precision = 18
    )
    private Long id;
    @Column(
            name = "NAME",
            nullable = false,
            length = 256
    )
    private String name;

    public DummyObject() {
    }

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }
}
