package org.hibernate.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(
        name = "WORKSPACE_RESOURCE_FOLDER"
)
@PrimaryKeyJoinColumn(
        name = "ID_WORKSPACE_RESOURCE_FOLDER"
)
@DiscriminatorValue("SUB")
public class DummyObjectWithDescription extends DummyObject implements Serializable {

    @Column(
            name = "description",
            nullable = false,
            length = 256
    )
    private String description;

    public DummyObjectWithDescription() {
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }
}
