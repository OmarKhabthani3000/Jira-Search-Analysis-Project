package org.hibernate.test;

public class OrderEntry {

}
