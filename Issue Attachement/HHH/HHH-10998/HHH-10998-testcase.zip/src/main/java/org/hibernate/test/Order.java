package org.hibernate.test;

public class Order {

	private Long orderId;
	private OrderEntry firstOrder;

	public OrderEntry getFirstOrder() {
		return firstOrder;
	}

	public void setFirstOrder(OrderEntry firstOrder) {
		this.firstOrder = firstOrder;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
}
