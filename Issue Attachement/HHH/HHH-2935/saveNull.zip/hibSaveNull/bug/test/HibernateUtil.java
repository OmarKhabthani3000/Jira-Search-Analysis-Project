package bug.test;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

public class HibernateUtil {
	private static SessionFactory sessionFactory;

	public static Session session;

	static {
		try {
			String sDBUser = "root";
			String sDBPassword = "password";
			String url = "jdbc:mysql://localhost:3306/testdb";

			Configuration ac = new AnnotationConfiguration().addAnnotatedClass(
					Child.class).addAnnotatedClass(Parent.class).setProperty(
					"hibernate.connection.password", sDBPassword).setProperty(
					"hibernate.connection.username", sDBUser).setProperty(
					"hibernate.connection.url", url).setProperty(
					"hibernate.connection.driver_class",
					"com.mysql.jdbc.Driver").setProperty(
					"hibernate.hbm2ddl.auto", "create-drop").setProperty("hibernate.dialect",
					"org.hibernate.dialect.MySQLInnoDBDialect");
			sessionFactory = ac.buildSessionFactory();
		} catch (Throwable ex) {
			throw new ExceptionInInitializerError(ex);
		}
	}

	public static Session getSession() throws HibernateException {
		if (session == null || !session.isOpen()) {
			session = getSessionFactory().openSession();
			session.beginTransaction();
		}
		return session;
	}

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}
}
