package bug.test;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;


public class Test {

	public static void main(String[] args) throws IOException, SQLException {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		Parent parent = new Parent();
		int times = 2;
		List<Child> children = new ArrayList<Child>(times);
		for (int i = 0; i < times; i++) {
			Child child = new Child();
			children.add(child);
			child.setParent(parent);
		}
		parent.setChildren(children);
		session.save(parent);
		session.getTransaction().commit();
	}
}
