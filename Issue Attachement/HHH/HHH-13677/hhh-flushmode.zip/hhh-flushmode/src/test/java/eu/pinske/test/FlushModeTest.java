package eu.pinske.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;

import org.junit.Assert;
import org.junit.Test;

public class FlushModeTest {

    @Test
    public void testFail() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");

        EntityManager em = emf.createEntityManager();
        Assert.assertEquals(FlushModeType.COMMIT, em.getFlushMode());
        em.close();

        emf.close();
    }

}
