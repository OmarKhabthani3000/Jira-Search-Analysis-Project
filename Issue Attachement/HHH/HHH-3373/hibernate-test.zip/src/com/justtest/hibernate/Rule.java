package com.justtest.hibernate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * User: Grisha Klimov
 * Date: May 29, 2008
 * Time: 7:00:07 PM
 */


@Entity
@Table(name = "rules")
public class Rule implements Serializable {

    private static final long serialVersionUID = 1719238850511767679L;

    @Id
    @GeneratedValue
    private Long id;

    @Column(name = "name")
    private String name;

    @OneToMany
    @JoinColumn(name = "rule_id")
    private List<Criterion> criteria;

    @ManyToMany
    @JoinTable(name = "executors_rules",
            joinColumns = {@JoinColumn(name = "rule_id")},
            inverseJoinColumns = {@JoinColumn(name = "executor_id")})
    private List<Service> availableExecutors;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Criterion> getCriteria() {
        return criteria;
    }

    public void setCriteria(List<Criterion> criteria) {
        this.criteria = criteria;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Rule rule = (Rule) o;

        if (id != null ? !id.equals(rule.id) : rule.id != null) return false;
        if (name != null ? !name.equals(rule.name) : rule.name != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result;
        result = (id != null ? id.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        return result;
    }
}
