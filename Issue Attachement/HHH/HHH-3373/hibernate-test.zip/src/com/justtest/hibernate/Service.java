package com.justtest.hibernate;

import org.hibernate.annotations.CollectionOfElements;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * User: Grisha Klimov
 * Date: May 29, 2008
 * Time: 7:40:34 PM
 */

@Entity
@Table(name = "services")
public class Service implements Serializable {

    private static final long serialVersionUID = 7106619829921752104L;

    @Id
    @GeneratedValue
    private Long id;

    @Column(name = "name")
    private String name;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "services_rules",
            joinColumns = {@JoinColumn(name = "service_id")},
            inverseJoinColumns = {@JoinColumn(name = "rule_id")})
    private List<Rule> availableRules;

    @CollectionOfElements
    @JoinTable(name = "services_rules", joinColumns = @JoinColumn(name = "service_id"))
    @Column(name = "rule_id")
    private List<Long> ruleIds;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Rule> getAvailableRules() {
        return availableRules;
    }

    public void setAvailableRules(List<Rule> availableRules) {
        this.availableRules = availableRules;
    }

    public List<Long> getRuleIds() {
        return ruleIds;
    }

    public void setRuleIds(List<Long> ruleIds) {
        this.ruleIds = ruleIds;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Service executor = (Service) o;

        if (id != null ? !id.equals(executor.id) : executor.id != null) return false;
        if (name != null ? !name.equals(executor.name) : executor.name != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result;
        result = (id != null ? id.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        return result;
    }
}
