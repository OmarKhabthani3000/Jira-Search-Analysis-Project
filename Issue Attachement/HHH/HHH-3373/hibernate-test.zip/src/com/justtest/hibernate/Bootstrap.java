package com.justtest.hibernate;

import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.*;

/**
 * User: Grisha Klimov
 * Date: May 29, 2008
 * Time: 7:20:55 PM
 */

public class Bootstrap {

    public static void main(String[] args) {
        AnnotationConfiguration configuration = new AnnotationConfiguration();
        configuration.configure();

        SessionFactory sessionFactory = configuration.buildSessionFactory();
        StatelessSession session = sessionFactory.openStatelessSession();
        //session.setFlushMode(FlushMode.MANUAL);

        /*Transaction transaction = session.beginTransaction();

        Rule rule = new Rule();
        rule.setId(1L);
        rule.setName("Test equality");

        session.saveOrUpdate(rule);

        transaction.commit();
        session.flush();*/

        Service service = (Service) session.get(Service.class, 1L);
        System.out.println(service);

        User user = (User) session.get(User.class, 1L);
        System.out.println(user);
    }
}
