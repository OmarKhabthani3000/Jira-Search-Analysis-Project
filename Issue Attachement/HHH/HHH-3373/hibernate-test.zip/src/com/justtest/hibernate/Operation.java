package com.justtest.hibernate;

/**
 * User: Grisha Klimov
 * Date: May 29, 2008
 * Time: 7:15:05 PM
 */

public enum Operation {

    EQUALS,
    NOT_EQUALS,
    GREATER,
    GREATER_OR_EQUALS,
    LESSER,
    LESSER_OR_EQUALS

}
