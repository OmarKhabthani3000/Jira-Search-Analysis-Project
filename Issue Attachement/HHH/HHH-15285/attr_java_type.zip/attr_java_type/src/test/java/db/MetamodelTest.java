/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package db;

import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;
import org.testng.annotations.Test;

public class MetamodelTest extends BaseTest {


    @Test
    public void select() {
        //given
        //when
        //then
        assertThat(Primary_.entities.getJavaType()).isEqualTo(List.class);
        assertThat(Primary_.cmps.getJavaType()).isEqualTo(List.class);
        assertThat(Primary_.basics.getJavaType()).isEqualTo(List.class);
    }
}
