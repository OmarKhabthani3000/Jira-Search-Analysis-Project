/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package db;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;

@Entity
@Table(schema = "test", name = "t_primary")
public class Primary implements Serializable {

    @Id
    private int id;
    @OneToMany(mappedBy = "primary")
    private List<Secondary> entities;
    @ElementCollection
    private List<Cmp> cmps;
    @ElementCollection
    private List<String> basics;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Secondary> getEntities() {
        return entities;
    }

    public void setEntities(List<Secondary> entities) {
        this.entities = entities;
    }

    public List<Cmp> getCmps() {
        return cmps;
    }

    public void setCmps(List<Cmp> cmps) {
        this.cmps = cmps;
    }

    public List<String> getBasics() {
        return basics;
    }

    public void setBasics(List<String> basics) {
        this.basics = basics;
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Primary primary = (Primary) o;
        return id == primary.id;
    }

    @Override public int hashCode() {
        return Objects.hash(id);
    }
}
