/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package db;

import jakarta.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class Cmp implements Serializable {

    private String name;
    private int value;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
