package com.example.demo.model;

import static jakarta.persistence.GenerationType.AUTO;
import static jakarta.persistence.InheritanceType.SINGLE_TABLE;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;

@Entity
@Inheritance(strategy = SINGLE_TABLE)
@DiscriminatorColumn(name = "code")
public abstract class MarketValue {

	@Id
	@GeneratedValue(strategy = AUTO)
	private final Long id;

	@Column(nullable = false, insertable = false, updatable = false)
	private final MarketId code;

	protected MarketValue() {
		this.id = null;
		this.code = null;
	}

	protected MarketValue(String code) {
		this.id = null;
		this.code = new MarketId(code);
	}

	public Long getId() {
		return id;
	}

	public MarketId getCode() {
		return code;
	}

	@Override
	public int hashCode() {
		return Objects.hash(code, id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MarketValue other = (MarketValue) obj;
		return Objects.equals(code, other.code) && Objects.equals(id, other.id);
	}
}
