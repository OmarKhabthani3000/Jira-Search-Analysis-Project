package com.example.demo.model;

import java.util.Objects;

public class MarketId {
	private final String code;

	protected MarketId() {
		this.code = null;
	}

	public MarketId(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	@Override
	public int hashCode() {
		return Objects.hash(code);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MarketId other = (MarketId) obj;
		return Objects.equals(code, other.code);
	}
}
