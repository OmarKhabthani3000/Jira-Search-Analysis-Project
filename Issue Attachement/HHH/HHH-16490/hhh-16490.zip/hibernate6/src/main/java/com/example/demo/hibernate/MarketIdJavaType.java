package com.example.demo.hibernate;

import org.hibernate.type.descriptor.WrapperOptions;
import org.hibernate.type.descriptor.java.AbstractClassJavaType;
import org.hibernate.type.descriptor.jdbc.JdbcType;
import org.hibernate.type.descriptor.jdbc.JdbcTypeIndicators;
import org.hibernate.type.descriptor.jdbc.VarcharJdbcType;

import com.example.demo.model.MarketId;

import jakarta.persistence.AttributeConverter;

public class MarketIdJavaType extends AbstractClassJavaType<MarketId> implements AttributeConverter<MarketId, String> {

	private static final long serialVersionUID = 1L;

	public MarketIdJavaType() {
		super(MarketId.class);
	}

	@Override
	public JdbcType getRecommendedJdbcType(JdbcTypeIndicators indicators) {
		return VarcharJdbcType.INSTANCE;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <X> X unwrap(MarketId value, Class<X> type, WrapperOptions options) {
		if (value == null) {
			return null;
		}
		if (type.isAssignableFrom(String.class)) {
			return (X) value.getCode();
		}
		if (type.isAssignableFrom(MarketId.class)) {
			return (X) value;
		}

		throw unknownUnwrap(type);
	}

	@Override
	public <X> MarketId wrap(X value, WrapperOptions options) {
		if (value == null) {
			return null;
		}
		if (value instanceof String code) {
			return new MarketId(code);
		}
		if (value instanceof MarketId id) {
			return id;
		}

		throw unknownWrap(value.getClass());
	}

	@Override
	public String convertToDatabaseColumn(MarketId attribute) {
		return unwrap(attribute, String.class, null);
	}

	@Override
	public MarketId convertToEntityAttribute(String dbData) {
		return wrap(dbData, null);
	}

}
