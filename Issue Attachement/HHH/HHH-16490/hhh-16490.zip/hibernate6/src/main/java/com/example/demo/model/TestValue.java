package com.example.demo.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("TEST")
public class TestValue extends MarketValue {

	public TestValue() {
		super("TEST");
	}

}
