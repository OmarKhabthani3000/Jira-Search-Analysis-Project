package com.example.demo.config;

import static org.hibernate.jpa.boot.internal.EntityManagerFactoryBuilderImpl.TYPE_CONTRIBUTORS;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.boot.model.TypeContributor;
import org.hibernate.jpa.boot.spi.TypeContributorList;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

import com.example.demo.hibernate.MarketIdJavaType;

import jakarta.persistence.spi.PersistenceUnitInfo;

@Configuration
public class Config {

	public Config() {
		super();
	}

	@Bean
	public JpaVendorAdapter jpaVendorAdapter() {
		var adapter = new CustomisableHibernateJpaVendorAdapter();
		adapter.addTypeContributors(List.of(contributor()));
		return adapter;
	}

	@Bean
	public TypeContributor contributor() {
		return (typeContributions, serviceRegistry) -> {
			typeContributions.contributeJavaType(new MarketIdJavaType());
		};
	}

	
	public final class CustomisableHibernateJpaVendorAdapter extends HibernateJpaVendorAdapter {

		  private final Set<TypeContributor> typeContributors = new HashSet<>();

		  public void addTypeContributors(Collection<TypeContributor> typeContributors) {
		    this.typeContributors.addAll(typeContributors);
		  }

		  @Override
		  public Map<String, Object> getJpaPropertyMap() {
		    return customise(super.getJpaPropertyMap());
		  }

		  @Override
		  public Map<String, Object> getJpaPropertyMap(PersistenceUnitInfo pui) {
		    return customise(super.getJpaPropertyMap(pui));
		  }

		  private Map<String, Object> customise(Map<String, Object> properties) {
		    if (!typeContributors.isEmpty()) {
		      var typeContributorList = (TypeContributorList) properties.get(TYPE_CONTRIBUTORS);
		      if (typeContributorList == null) {
		        properties.put(TYPE_CONTRIBUTORS, (TypeContributorList) () -> new ArrayList<>(typeContributors));
		      } else {
		        typeContributorList.getTypeContributors().addAll(typeContributors);
		      }
		    }

		    return properties;
		  }
		}
}

