package cz.tconsult.problem;

import java.math.BigDecimal;

public class MyNumber extends Number {

  private final BigDecimal value;

  public MyNumber(final BigDecimal value) {
    this.value = value;
  }

  @Override
  public String toString() {
    return value.toString();
  }

  public BigDecimal getValue() {
    return value;
  }

  @Override
  public int intValue() {
    return value.intValue();
  }

  @Override
  public long longValue() {
    return value.longValue();
  }

  @Override
  public float floatValue() {
    return value.floatValue();
  }

  @Override
  public double doubleValue() {
    return value.doubleValue();
  }
}
