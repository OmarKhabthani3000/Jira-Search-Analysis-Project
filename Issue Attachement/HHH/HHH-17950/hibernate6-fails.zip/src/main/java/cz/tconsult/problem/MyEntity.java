package cz.tconsult.problem;

import jakarta.persistence.*;


@Entity
public class MyEntity {

  @Id
  private long id;

  private MyNumber myNumber;


}
