package cz.tconsult.problem;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import java.math.BigDecimal;


@Converter(autoApply=true)
public class MyNumberAttributeConverter implements AttributeConverter<MyNumber, BigDecimal> {


  @Override
  public BigDecimal convertToDatabaseColumn(MyNumber attribute) {
    return attribute.getValue();
  }

  @Override
  public MyNumber convertToEntityAttribute(BigDecimal dbData) {
    return new MyNumber(dbData);
  }
}
