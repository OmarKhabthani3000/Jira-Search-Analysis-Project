CREATE TABLE my_entity (
    id BIGINT,
    my_number numeric(10)
);


INSERT INTO my_entity (id, my_number) VALUES (11, 123);
INSERT INTO my_entity (id, my_number) VALUES (22, 456);
