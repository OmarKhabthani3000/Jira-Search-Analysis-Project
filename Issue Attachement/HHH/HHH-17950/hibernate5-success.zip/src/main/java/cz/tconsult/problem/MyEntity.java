package cz.tconsult.problem;

import javax.persistence.*;


@Entity
public class MyEntity {

  @Id
  private long id;

  private MyNumber myNumber;


}
