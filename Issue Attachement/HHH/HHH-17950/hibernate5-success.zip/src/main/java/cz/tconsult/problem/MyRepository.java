package cz.tconsult.problem;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;


@Repository
public interface MyRepository extends CrudRepository<MyEntity, Long> {

  @Query("SELECT e.myNumber FROM MyEntity e WHERE id = 11")
  MyNumber findMyNumber();

  @Query("SELECT sum(e.myNumber) FROM MyEntity e")
  MyNumber sumMyNumbersFail();

  @Query("SELECT sum(e.myNumber) FROM MyEntity e")
  BigDecimal sumMyNumbersOk();


}
