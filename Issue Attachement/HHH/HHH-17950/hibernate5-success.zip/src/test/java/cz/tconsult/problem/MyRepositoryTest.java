package cz.tconsult.problem;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DataJpaTest
public class MyRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private MyRepository myRepository;

    @Test
    public void testFindMyNumber() {
        MyNumber foundNumber = myRepository.findMyNumber();
        assertEquals(123L, foundNumber.getValue().longValue());
    }

    @Test
    public void testSumMyNumbersOk() {
        BigDecimal sum = myRepository.sumMyNumbersOk();
        assertEquals(579L, sum.longValue());
    }

    @Test
    public void testSumMyNumbersFail() {
        MyNumber sum = myRepository.sumMyNumbersFail();
        assertEquals(579L, sum.longValue());
    }

}
