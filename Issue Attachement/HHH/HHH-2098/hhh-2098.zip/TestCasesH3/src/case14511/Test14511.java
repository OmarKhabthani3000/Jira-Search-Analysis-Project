package case14511;


import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import test.TestCase;

/**
 * @author Anthony
 *
 */
public class Test14511 extends TestCase{

	public void test() {
		try{
			Session session = openSession();
			Transaction tx = null ;
			tx = session.beginTransaction();
			
			ScanCodeId scid = new ScanCodeId();
			scid.setOperatingCntxGuid("OperatingCntxGuid");
			scid.setScanCdGuid("ScanCdGuid");
			
			PatientScanCode psc = new PatientScanCode();
			psc.setExtendedDescription("psc");
			psc.setDescription("desc");
			psc.setId(scid);
			
			
			Patient p = new Patient();
			p.setDescription("patient");
			psc.setPatient(p);
			
			session.save(p);
			session.save(psc);
			tx.commit();
			session.close();
			
			session = openSession();
			tx = session.beginTransaction();

			
			
			
			String queryStr = "delete from PatientScanCode as scancode " +
			"where scancode.patient.id = ? ";
			Query query = session.createQuery(queryStr);
			query.setParameter(0, p.getId());
			query.executeUpdate();
			tx.commit();
			session.close();
			

			
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}
	
	public Test14511(String arg0) {
		super(arg0);
	}
	
	public String[] getMappings() {
		return new String[] {"case14511/Mappings.hbm.xml"};
	}

	public static Test suite() {
		return new TestSuite(Test14511.class);
	}
	
	public static void main(String[] args) throws Exception {
		TestRunner.run( suite() );
	}
}
