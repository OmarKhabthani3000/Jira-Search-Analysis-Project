package case14511;

public class Patient {
	private Long id;
	private String description;
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long simpleId) {
		this.id = simpleId;
	}

}
