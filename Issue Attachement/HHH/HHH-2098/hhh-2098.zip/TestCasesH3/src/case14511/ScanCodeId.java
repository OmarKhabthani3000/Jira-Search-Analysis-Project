package case14511;

import java.io.Serializable;

public class ScanCodeId implements Serializable{
	private String scanCdGuid;
	private String operatingCntxGuid;
	
	public String getOperatingCntxGuid() {
		return operatingCntxGuid;
	}
	public void setOperatingCntxGuid(String operatingCntxGuid) {
		this.operatingCntxGuid = operatingCntxGuid;
	}
	public String getScanCdGuid() {
		return scanCdGuid;
	}
	public void setScanCdGuid(String scanCdGuid) {
		this.scanCdGuid = scanCdGuid;
	}
}
