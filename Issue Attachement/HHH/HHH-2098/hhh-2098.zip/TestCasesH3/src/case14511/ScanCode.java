package case14511;

public class ScanCode {
	private ScanCodeId id;
	
	private String description;

	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public ScanCodeId getId() {
		return id;
	}
	public void setId(ScanCodeId id) {
		this.id = id;
	}

}
