package boundry.org.hibernate.mapping;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

/**
 * @author <a href="mailto:pashazadeh@gmail.com">Amir Pashazadeh</a>
 * @version 1.0
 * @date 11/20/11
 */
@Entity
@Table(name = "sample_bean")
@Inheritance
@DiscriminatorColumn(name = "discriminator")
@DiscriminatorValue("parent")
public class SampleBean implements Serializable {
    private Long id;
    private String discriminator;
    private String name;

    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "entityGenerator")
    @GenericGenerator(name = "entityGenerator", strategy = "enhanced-table",
            parameters = {
                    @org.hibernate.annotations.Parameter(name = org.hibernate.id.enhanced.TableGenerator.TABLE_PARAM, value = "tbi_hibernate_sequences"),
                    @org.hibernate.annotations.Parameter(name = org.hibernate.id.enhanced.TableGenerator.SEGMENT_COLUMN_PARAM, value = "sequence_name"),
                    @org.hibernate.annotations.Parameter(name = org.hibernate.id.enhanced.TableGenerator.VALUE_COLUMN_PARAM, value = "next_val"),
                    @org.hibernate.annotations.Parameter(name = org.hibernate.id.enhanced.TableGenerator.CONFIG_PREFER_SEGMENT_PER_ENTITY, value = "true"),
                    @org.hibernate.annotations.Parameter(name = org.hibernate.id.enhanced.TableGenerator.INCREMENT_PARAM, value = "32")
            })
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Column(name = "DISCRIMINATOR", insertable = false, updatable = false)
    public String getDiscriminator() {
        return discriminator;
    }

    public void setDiscriminator(String discriminator) {
        this.discriminator = discriminator;
    }

    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
