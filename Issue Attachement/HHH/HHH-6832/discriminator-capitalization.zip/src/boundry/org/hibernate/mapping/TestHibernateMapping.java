/*
 * Copyright (c) 2010. Payeshgaran MT, all rights reserved.
 */

package boundry.org.hibernate.mapping;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import java.sql.SQLException;
import java.util.List;

/**
 * @author <a href="mailto:pashazadeh@gmail.com">Amir Pashazadeh</a>
 * @version 1.0
 * @date 11/20/11
 */
@ContextConfiguration("/boundry/org/hibernate/mapping/boundry-hibernate-mapping.xml")
@Transactional
public class TestHibernateMapping extends AbstractTransactionalTestNGSpringContextTests {

    @Autowired
    private HibernateTemplate hibernateTemplate;

    @Test(groups = "hibernate")
    public void doSomeTest() {
        hibernateTemplate.executeFind(new HibernateCallback<List<?>>() {
            public List<?> doInHibernate(Session session) throws HibernateException, SQLException {
                return session.createQuery("from boundry.org.hibernate.mapping.SampleBean x")
                        .setFirstResult(10)
                        .setMaxResults(20)
                        .list();
            }
        });
    }

}
