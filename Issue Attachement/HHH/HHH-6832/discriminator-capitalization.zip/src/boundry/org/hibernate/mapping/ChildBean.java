/*
 * Copyright (c) 2010. Payeshgaran MT, all rights reserved.
 */

package boundry.org.hibernate.mapping;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * @author <a href="mailto:pashazadeh@gmail.com">Amir Pashazadeh</a>
 * @version 1.0
 * @date 11/20/11
 */
@Entity
@DiscriminatorValue("child")
public class ChildBean extends SampleBean{
}
