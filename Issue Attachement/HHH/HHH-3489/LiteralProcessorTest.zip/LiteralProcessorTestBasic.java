package com.expd.app.edms.persistence;

import junit.framework.TestCase;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/*
 * (c)2008 Expeditors International of Washington, Inc. Business confidential
 * and proprietary.  This information may not be reproduced in any form without
 * advance written consent of an authorized officer of the copyright holder.
 */

/**
 * 
 */
public class LiteralProcessorTestBasic extends TestCase
{
	private Configuration config;
	private SessionFactory factory;
	private Session session;


	@Override
	public void setUp()
	{
		this.config = new Configuration().configure();
		this.factory = this.config.buildSessionFactory();
		this.session = this.factory.openSession();
	}


	public void testHql()
	{
		String hqlStmt = "select type from LocationData l" + " where l.oid in (9999999999999999999)";
		Query hqlQuery = this.session.createQuery(hqlStmt);
		hqlQuery.list();
	}


	public void shutDown()
	{
		this.session.close();
	}
}
