package app.hibernate.model;

import java.io.Serializable;

/**
 * @author Ivan Bondarenko
 */
public class IdWithSubId implements Serializable {
    private static final long serialVersionUID = -2304656293054567177L;
    
    private Long id;
    private Long subId;
    
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    
    public Long getSubId() {
        return subId;
    }
    public void setSubId(Long subId) {
        this.subId = subId;
    }
    
}