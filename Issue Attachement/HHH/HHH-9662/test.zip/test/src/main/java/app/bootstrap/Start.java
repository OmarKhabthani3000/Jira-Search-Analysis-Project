package app.bootstrap;

import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import app.hibernate.model.Animal;

/**
 * @author Ivan Bondarenko
 */
public class Start {
	
	public static void main(String[] args) {
	    Properties props = new Properties();
	    props.setProperty("javax.persistence.jdbc.user", "root");
	    props.setProperty("javax.persistence.jdbc.password", "12345");
	    props.setProperty("javax.persistence.jdbc.url", "jdbc:mysql://localhost:3306/test?autoReconnect=true&useSSL=false");
	    
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("pups", props);
		
		EntityManager entityManager = factory.createEntityManager();
		Animal animal = new Animal();
		
		entityManager.persist(animal);
	}
}
