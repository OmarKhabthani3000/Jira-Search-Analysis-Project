package app.hibernate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * @author Ivan Bondarenko
 */
@Entity
@Table(name = "animal")
@IdClass(IdWithSubId.class)
public class Animal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Id
    @Column(name = "sub_id")
    private Long subId;
    
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    
    public Long getSubId() {
        return subId;
    }
    public void setSubId(Long subId) {
        this.subId = subId;
    }
}
