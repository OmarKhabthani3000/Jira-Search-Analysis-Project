package su.axada.hibernate.sandbox.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class BaseDocumentLine extends AbstractEntity
{
	private String text;

	@Column(nullable=false)
	public String getText()
	{
		return text;
	}

	public void setText(String text)
	{
		this.text = text;
	}
}
