package su.axada.hibernate.sandbox.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class DocumentLineA extends BaseDocumentLine
{
	private DocumentA document;

	@ManyToOne(fetch = FetchType.LAZY, optional=false)
	@JoinColumn(updatable=false, insertable=true, nullable=false)
	public DocumentA getDocument()
	{
		return document;
	}

	public void setDocument(DocumentA document)
	{
		this.document = document;
	}
}
