//$Id: $
package org.hibernate.test.leadingunderscore;


/**
 * @author Marco Reimann<marco.reimann@hypoport.de>
 */
public class RacingDriver{
	
	private Long _id;
	private RacingTeam _team;
	
	public  RacingTeam getTeam() {
		return _team;
	}
	
	
	public void setTeam(RacingTeam p_team)
	{
		if(_team == null && p_team != null || !_team.equals(p_team))
		{
			if(_team != null)
			{
				_team.removeDriver(this);
			}
			
			_team = p_team;
			
			if(_team != null)
			{
				_team.addDriver(this);
			}
		}
		
	}
	
	
}
