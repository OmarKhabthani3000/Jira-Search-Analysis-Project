//$Id: $
package org.hibernate.test.leadingunderscore;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.dialect.Dialect;
import org.hibernate.dialect.Oracle9Dialect;
import org.hibernate.dialect.OracleDialect;
import org.hibernate.test.DatabaseSpecificTestCase;

import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * 
 * 
 * This test reproduces the Hibernate Bug HHH-1573 
 * (one-to-many fails on oracle if field starts with underscore).
 * 
 * This test executes queries on a onetomany mapping with a leading underscore.
 *  
 * @author Marco Reimann<marco.reimann@hypoport.de>
 */
public class LeadingUnderScoreTest extends DatabaseSpecificTestCase {
	
	public boolean appliesTo(Dialect dialect) {
		return dialect instanceof Oracle9Dialect ||
               dialect instanceof OracleDialect;
	}

	public LeadingUnderScoreTest(String str) {
		super(str);
	}
	
	public void testSequentialSelects() {
		Session s = openSession();
		Transaction t = s.beginTransaction();
		
		RacingDriver driver = new RacingDriver();
		
		RacingTeam team = new RacingTeam();
		
		driver.setTeam(team);
		
		s.save(team);
		s.save(driver);
				
		
		t.commit();
		s.close();
		
		s = openSession();
		t = s.beginTransaction();
		
        // Simply execute the queries.
        // When they complete without an exception, everything is fine
        
		s.createQuery("select team._drivers from RacingTeam team where team._id = 1").list();
		
		s.createQuery("from RacingTeam team join team._drivers driver where driver._id = 1").list();
		
		s.createQuery("from RacingTeam team join fetch team._drivers").list();
		
        
		t.commit();
		s.close();
		
	}

	
	protected String[] getMappings() {
		return new String[] { "leadingunderscore/RacingDriver.hbm.xml" , "leadingunderscore/RacingTeam.hbm.xml"};
	}

	public static Test suite() {
		return new TestSuite(LeadingUnderScoreTest.class);
	}

}

