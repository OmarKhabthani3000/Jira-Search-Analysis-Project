//$Id: $
package org.hibernate.test.leadingunderscore;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;


/**
 * @author Marco Reimann<marco.reimann@hypoport.de>
 */
public class RacingTeam {
	private Long _id;
	private Set _drivers = new HashSet();
	
	public Set getDrivers()
	{
		return Collections.unmodifiableSet(_drivers);
	}
	
	public void addDriver(RacingDriver p_racingDriver)
	{
		if(!_drivers.contains(p_racingDriver))
		{
			_drivers.add(p_racingDriver);
			p_racingDriver.setTeam(this);
		}
			
	}

	public void removeDriver(RacingDriver p_racingDriver) {

		if(_drivers.contains(p_racingDriver))
		{
			_drivers.remove(p_racingDriver);
			p_racingDriver.setTeam(null);
		}
		
	}
	
	
	
}
