package test.hibernate;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.Session;
import org.hibernate.context.spi.CurrentSessionContext;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Hodac Jan
 */
@RunWith(SpringJUnit4ClassRunner.class)
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@ContextConfiguration(locations = { "classpath:test-context-core.xml", "TestPrepravkaOsobaSAdresou-context.xml" })
@Transactional(value = "transactionManager")
public class TestPrepravkaOsobaSAdresou {
  
  @Entity(name = "Ppv")
  @Table(name = "PPV")
  public static class Ppv {

    @Id
    Long ppvId;
    
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "ppv", orphanRemoval = true)
    Set<Uvazek> uvazeks = new HashSet<Uvazek>(0);
    
  }
  
  @Entity(name = "Uvazek")
  @Table(name = "UVAZEK")
  public static class Uvazek {
    
    @Id
    Long uvazekId;
    
    @ManyToOne
    @JoinColumn(name = "PPV_FXID")
    Ppv ppv;

  }
    
  @Autowired
  private CurrentSessionContext sessionContext;
  @Autowired
  private JdbcTemplate jdbcTemplate;
  
  @Before
  public void init() {
    jdbcTemplate.execute("delete from PPV");
    jdbcTemplate.execute("insert into PPV values(1)");
    
    jdbcTemplate.execute("delete from UVAZEK");
    jdbcTemplate.execute("insert into UVAZEK values(2, 1)");
    jdbcTemplate.execute("insert into UVAZEK values(3, 1)");
  }

  @Test
  public void testSessionGet() {
    Ppv ppv = (Ppv) getSession().get(Ppv.class, 1l);

    getSession().clear();
    
    ppv.uvazeks.remove(ppv.uvazeks.iterator().next());
    getSession().merge(ppv);
    getSession().flush();
    
    getSession().clear();
    
    ppv.uvazeks.remove(ppv.uvazeks.iterator().next());
    getSession().merge(ppv);
    getSession().flush();
  }
  
  private Session getSession() {
    return sessionContext.currentSession();
  }

}