package com.pojector.server.data.entities.TestBug;

public class Locale {

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
