package com.pojector.server.data.entities.TestBug;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;

@Entity
public class Key {
	protected long Id;
	protected String name;


	@javax.persistence.Id
	@GeneratedValue
	@Column(nullable = false, unique = true)
	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	@Override
	public boolean equals(Object obj) {
		Key c  = (Key) obj;
		if (this.getName().compareTo(c.getName())==0) {
			return true;
		}
		return false;
	}

	@Override
	public int hashCode() {
		return this.getName().hashCode();
		//return super.hashCode();
	}
}
