package com.pojector.server.driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Environment;

import com.pojector.server.data.entities.TestBug.Child;
import com.pojector.server.data.entities.TestBug.Key;
import com.pojector.server.data.entities.TestBug.Parent;

public class TestBug {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		AnnotationConfiguration ac = new AnnotationConfiguration()
		.setProperty(Environment.SHOW_SQL,"false")
		.setProperty(Environment.FORMAT_SQL,"true")
		.setProperty("hibernate.connection.driver_class", "org.postgresql.Driver")
		.setProperty(Environment.C3P0_MAX_SIZE,"20")
		.setProperty(Environment.C3P0_MIN_SIZE,"5")
		.setProperty(Environment.C3P0_TIMEOUT,"300")
		.setProperty(Environment.C3P0_MAX_STATEMENTS,"50")
		.setProperty(Environment.C3P0_IDLE_TEST_PERIOD,"3000")
		.setProperty(Environment.C3P0_MAX_SIZE,"50")
		.setProperty(Environment.C3P0_ACQUIRE_INCREMENT,"1")
		.setProperty("hibernate.connection.url" ,"jdbc:postgresql:test")
		.setProperty("hibernate.connection.username" ,"test" )
		.setProperty("hibernate.connection.password" ,"test")
		.setProperty("hibernate.dialect" ,"org.hibernate.dialect.PostgreSQLDialect" )
		//.setProperty("hibernate.hbm2ddl.auto" ,"create")
		//.setProperty("hibernate.hbm2ddl.auto" ,"validate")
		.setProperty("hibernate.hbm2ddl.auto" ,"update")
		.setProperty("hibernate.current_session_context_class","thread")
		.addAnnotatedClass(Parent.class)
		.addAnnotatedClass(Child.class)
		.addAnnotatedClass(Key.class);
		SessionFactory sf =  ac.buildSessionFactory();
		
		
		Session s = sf.getCurrentSession();
		Key k1 = new Key();
		k1.setName("key 1");
		Key k2 = new Key();
		k2.setName("key 2");
		
		Child c1 = new Child();
		c1.setName("child 1");
		c1.setKey(k1);
		
		Child c2 = new Child();
		c2.setName("child 2");
		c2.setKey(k2);
		
		Parent p = new Parent();
		p.setName("parent 1");
		
		p.getChildren().put(c1.getKey(), c1);
		p.getChildren().put(c2.getKey(), c2);
		
		s.getTransaction().begin();
		
		s.save(p);
		s.getTransaction().commit();
		
		
		Session ss= sf.getCurrentSession();
		ss.getTransaction().begin();
		//the id below is hard coded , should be adjusted per run
		Parent pres =  (Parent)   ss.get(Parent.class, (long)6);
		System.out.println("parent has " + pres.getChildren().size() +  "children" );
		ss.getTransaction().commit();
		

	}
}
