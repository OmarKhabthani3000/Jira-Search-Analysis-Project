package com.pojector.server.data.entities.TestBug;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;

@Entity
public class Parent {
	protected long Id;
	protected Map<Key, Child> children =  new HashMap<Key, Child>();
	protected String name;
	

	@javax.persistence.Id
	@GeneratedValue
	@Column(nullable = false, unique = true)
	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	@OneToMany(cascade = CascadeType.ALL)
	@MapKey(name="key")
	public Map<Key, Child> getChildren() {
		return children;
	}

	public void setChildren(Map<Key, Child> children) {
		this.children = children;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
