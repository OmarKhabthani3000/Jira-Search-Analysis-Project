package com.pojector.server.data.entities.TestBug;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.ManyToOne;

@Entity
public class Child {
	protected long Id;
	protected String name;
	protected Key key;

	@javax.persistence.Id
	@GeneratedValue
	@Column(nullable = false, unique = true)
	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@ManyToOne(cascade = CascadeType.ALL)
	public Key getKey() {
		return key;
	}

	public void setKey(Key key) {
		this.key = key;
	}
}
