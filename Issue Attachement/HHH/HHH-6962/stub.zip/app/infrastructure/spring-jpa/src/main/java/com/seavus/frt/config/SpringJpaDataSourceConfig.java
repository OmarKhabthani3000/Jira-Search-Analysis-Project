package com.seavus.frt.config;

import java.beans.PropertyVetoException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.mchange.v2.c3p0.ComboPooledDataSource;

@Configuration
public class SpringJpaDataSourceConfig {

    private static final String PROPERTY_NAME_DATABASE_DRIVER = "db.driver";
    private static final String PROPERTY_NAME_DATABASE_PASSWORD = "db.password";
    private static final String PROPERTY_NAME_DATABASE_URL = "db.url";
    private static final String PROPERTY_NAME_DATABASE_USERNAME = "db.username";
    private static final String PROPERTY_NAME_DATABASE_INITIAL_POOL_SIZE = "db.pool.initial_size";
    private static final String PROPERTY_NAME_DATABASE_MAX_POOL_SIZE = "db.pool.max_size";
    private static final String DB_POOL_TEST_CONNECTION_QUERY = "db.pool.test_connection_query";
    private static final String DB_POOL_TEST_CONNECTION_ON_CHECKOUT = "db.pool.test_connection_on_checkout";

    @Resource
    private Environment environment;

    @Bean
    public DataSource dataSource() throws PropertyVetoException {

        final String initialPoolSize = environment.getProperty(PROPERTY_NAME_DATABASE_INITIAL_POOL_SIZE);
        final String maxPoolSize = environment.getProperty(PROPERTY_NAME_DATABASE_MAX_POOL_SIZE);

        final ComboPooledDataSource dataSource = new ComboPooledDataSource();
        dataSource.setDriverClass(environment.getRequiredProperty(PROPERTY_NAME_DATABASE_DRIVER));
        dataSource.setJdbcUrl(environment.getRequiredProperty(PROPERTY_NAME_DATABASE_URL));
        dataSource.setUser(environment.getRequiredProperty(PROPERTY_NAME_DATABASE_USERNAME));
        dataSource.setPassword(environment.getRequiredProperty(PROPERTY_NAME_DATABASE_PASSWORD));
        dataSource.setPreferredTestQuery(environment.getRequiredProperty(DB_POOL_TEST_CONNECTION_QUERY));
        dataSource.setTestConnectionOnCheckout(
                Boolean.parseBoolean(environment.getRequiredProperty(DB_POOL_TEST_CONNECTION_ON_CHECKOUT)));
        if (initialPoolSize != null && initialPoolSize.trim().length() > 0) {
            dataSource.setInitialPoolSize(Integer.valueOf(initialPoolSize));
        }
        if (maxPoolSize != null && maxPoolSize.trim().length() > 0) {
            dataSource.setMaxPoolSize(Integer.valueOf(maxPoolSize));
        }

        return dataSource;
    }

}
