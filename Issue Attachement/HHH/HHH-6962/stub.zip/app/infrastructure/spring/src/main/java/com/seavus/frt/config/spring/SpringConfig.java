package com.seavus.frt.config.spring;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("con.seavus.frt.config")
public class SpringConfig {

}
