package com.seavus.frt.config.spring;

public class DefaultSystemAdapter implements SystemAdapter {

    @Override
    public String getenv(final String name) {
        return System.getenv(name);
    }

}
