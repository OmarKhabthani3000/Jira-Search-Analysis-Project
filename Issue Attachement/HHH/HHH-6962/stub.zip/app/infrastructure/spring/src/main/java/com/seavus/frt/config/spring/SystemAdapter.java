package com.seavus.frt.config.spring;

/**
 * An adapter to JDK's {@link System} class to enforce clean boundaries with third-party APIs.
 */
public interface SystemAdapter {

    String getenv(String name);
}
