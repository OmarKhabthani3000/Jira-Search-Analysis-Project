package com.seavus.frt.testing.spring;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringITConfig {


}
