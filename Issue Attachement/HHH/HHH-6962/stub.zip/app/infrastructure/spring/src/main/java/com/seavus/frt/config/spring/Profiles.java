package com.seavus.frt.config.spring;

public enum Profiles {
    MAIN, TEST, LDAP_SECURITY, MOCKED_SECURITY;
}
