package com.seavus.frt.config.spring;

public interface StringProfiles {
    String MAIN_STR = "MAIN";
    String TEST_STR = "TEST";
    String LDAP_SECURITY_STR = "LDAP_SECURITY";
    String MOCKED_SECURITY_STR = "MOCKED_SECURITY";
}
