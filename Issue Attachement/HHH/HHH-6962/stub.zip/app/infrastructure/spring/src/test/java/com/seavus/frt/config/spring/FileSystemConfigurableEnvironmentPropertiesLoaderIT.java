package com.seavus.frt.config.spring;

import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.core.env.ConfigurableEnvironment;
import org.unitils.UnitilsJUnit4TestClassRunner;
import org.unitils.inject.annotation.InjectIntoByType;
import org.unitils.inject.annotation.TestedObject;
import org.unitils.spring.annotation.SpringBeanByType;

import com.seavus.frt.testing.spring.BaseIT;

@RunWith(UnitilsJUnit4TestClassRunner.class)
public class FileSystemConfigurableEnvironmentPropertiesLoaderIT extends BaseIT {

    private static final String PROPERTIES_FILE = "local.properties";

    @TestedObject
    private FileSystemConfigurableEnvironmentPropertiesLoader propertiesLoader;

    @InjectIntoByType
    @Mock
    private SystemAdapter system;

    @SpringBeanByType
    private ConfigurableEnvironment environment;

    @Before
    public void setUp() {
        propertiesLoader = new FileSystemConfigurableEnvironmentPropertiesLoader();
    }

    /**
     * Loading a non-existing properties file should be silently ignored.
     */
    @Test
    public void testLoadingPropertiesFromNonExistingPropertiesFile() throws Exception {

        propertiesLoader.loadProperties(environment, "non-existing.properties");
    }

    @Test
    public void testLoadingPropertiesFromCustomEtcDir() throws Exception {
        setCustomEtcDir();

        // when
        propertiesLoader.loadProperties(environment, PROPERTIES_FILE);

        // then
        assertEquals("one", environment.getProperty("property.one"));
        assertEquals("two", environment.getProperty("property.two"));
    }

    @Test
    public void testThatLoadedPropertiesOverwriteExistingOnes() throws Exception {
        // given
        System.setProperty("property.one", "default");
        setCustomEtcDir();

        // when
        propertiesLoader.loadProperties(environment, PROPERTIES_FILE);

        // then
        assertEquals("one", environment.getProperty("property.one"));
    }

    /**
     * Configure the system adapter mock to return the test resources location as a custom etc dir.
     */
    private void setCustomEtcDir() {
        final String etcDir = getClass().getResource("").getPath();
        given(system.getenv(FileSystemConfigurableEnvironmentPropertiesLoader.CUSTOM_ETC_DIR_VAR)).willReturn(etcDir);
    }
}
