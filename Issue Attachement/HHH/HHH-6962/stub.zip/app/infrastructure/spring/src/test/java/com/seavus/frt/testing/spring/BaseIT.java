package com.seavus.frt.testing.spring;

import java.util.List;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.unitils.UnitilsJUnit4TestClassRunner;
import org.unitils.spring.annotation.SpringApplicationContext;

/**
 * A stripped-down version of the {@link gymondo.testing.BaseIT} class to support integration tests
 * within the <code>gymondo-infrastructure-spring</code> module.
 * <p>
 * The reason why this class should be used is because the
 * <code>gymondo-infrastructure-testing</code> module where the {@link gymondo.testing.BaseIT}
 * resides has dependency on this module and both modules can't have each other as dependencies.
 */
@RunWith(UnitilsJUnit4TestClassRunner.class)
public abstract class BaseIT {

    @SpringApplicationContext
    public ConfigurableApplicationContext createApplicationContext(List<String> locations) {
        final AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
        context.register(SpringITConfig.class);
        context.refresh();

        return context;
    }

    @Before
    public void setUpMockito() {
        MockitoAnnotations.initMocks(this);
    }
}
