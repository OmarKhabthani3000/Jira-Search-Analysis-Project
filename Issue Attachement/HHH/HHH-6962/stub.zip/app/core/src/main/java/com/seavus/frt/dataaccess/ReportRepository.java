package com.seavus.frt.dataaccess;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.seavus.frt.model.Report;

public interface ReportRepository extends PagingAndSortingRepository<Report, Long> {

}
