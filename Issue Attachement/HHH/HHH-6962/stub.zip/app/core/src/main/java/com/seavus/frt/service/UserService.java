package com.seavus.frt.service;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService, AuthenticationManager {
}
