package com.seavus.frt.service;

public enum UserRole {
    DM, // Division manager
    RCR // reporting and controlling responsible
}
