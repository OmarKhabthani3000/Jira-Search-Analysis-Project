package com.seavus.frt.service;

public interface ReportService {

}
