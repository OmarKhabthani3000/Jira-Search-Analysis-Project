package com.seavus.frt.service.impl;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.seavus.frt.config.spring.StringProfiles;
import com.seavus.frt.service.RoleService;
import com.seavus.frt.service.UserRole;
import com.seavus.frt.service.UserService;

@Profile(StringProfiles.MOCKED_SECURITY_STR)
@Service("userService")
public class MockedUserService implements UserService {
    @Autowired
    private Environment environment;
    @Autowired
    private RoleService roleService;

    @Override
    public Authentication authenticate(Authentication auth) throws AuthenticationException {
        User user = (User) loadUserByUsername(auth.getName());

        boolean passed = false;
        if (auth.getCredentials() instanceof String) {
            passed = StringUtils.equals((String) auth.getCredentials(), user.getPassword());
        }
        if (passed) {
            return new UsernamePasswordAuthenticationToken(user, auth.getCredentials(), user.getAuthorities());
        }

        throw new BadCredentialsException("Bad Credentials");
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        String loadedUsername = environment.getProperty("mock.security." + username + ".username");
        String loadedPassword = environment.getProperty("mock.security." + username + ".password");
        String loadedRole = environment.getProperty("mock.security." + username + ".role");

        if (StringUtils.isNotBlank(loadedUsername) && StringUtils.isNotBlank(loadedPassword)) {
            Collection<? extends GrantedAuthority> authorities = loadUserAuthorities(loadedRole);
            return new User(loadedUsername, loadedPassword, authorities);
        }

        throw new UsernameNotFoundException("Username `" + username + "` not found");
    }

    private Collection<? extends GrantedAuthority> loadUserAuthorities(String role) {
        UserRole userRole = UserRole.valueOf(role);
        List<String> authoritiesForRole = roleService.getAuthoritiesForRole(userRole);
        return authoritiesForRole.stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList());
    }

}
