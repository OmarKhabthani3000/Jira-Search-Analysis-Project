package com.seavus.frt.service;

import java.util.List;

public interface RoleService {
    List<String> getAuthoritiesForRole(UserRole userRole);
}