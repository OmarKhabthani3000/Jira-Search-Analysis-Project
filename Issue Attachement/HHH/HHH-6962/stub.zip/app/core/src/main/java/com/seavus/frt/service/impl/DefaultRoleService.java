package com.seavus.frt.service.impl;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.seavus.frt.service.RoleContainer;
import com.seavus.frt.service.RoleService;
import com.seavus.frt.service.UserRole;

@Component
public class DefaultRoleService implements RoleService {
    private RoleContainer roles;

    @Autowired
    public void setEnvironment(Environment env) {
        roles = createRolesFromProperties(env);
    }

    private RoleContainer createRolesFromProperties(Environment env) {
        RoleContainer roles = new RoleContainer();
        for (String roleName : commaSeparate(env.getProperty("security.availableRoles"))) {
            List<String> authorities = commaSeparate(env.getProperty("security.role." + roleName));
            roles.addRole(roleName, authorities);
        }
        return roles;
    }

    private List<String> commaSeparate(String string) {
        return Arrays.asList(StringUtils.tokenizeToStringArray(string, ","));
    }

    @Override
    public List<String> getAuthoritiesForRole(UserRole userRole) {
        if (userRole == null) {
            return Collections.emptyList();
        }
        return roles.toAuthorities(userRole.name());
    }

}
