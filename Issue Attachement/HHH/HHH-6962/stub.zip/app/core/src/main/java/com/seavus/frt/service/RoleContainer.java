package com.seavus.frt.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class RoleContainer {

    private Map<String, List<String>> roleMap = new HashMap<>();

    public void addRole(String roleName, List<String> authorities) {
        roleMap.put(roleName, authorities);
    }

    public List<String> toAuthorities(String roleName) {
        List<String> authorities = new LinkedList<>();
        List<String> roleAuthorities = roleMap.get(roleName);
        if (roleAuthorities != null) {
            authorities.addAll(roleAuthorities);
        }
        return authorities;
    }

/*
    public void checkGrantAllowed(List<String> heldRoles, List<String> grantingRoles) {
        List<String> allowedRoles = Lists.newLinkedList(filter(grantingRoles, isGrantAllowed(heldRoles)));
        if (!allowedRoles.containsAll(grantingRoles)) {
            List<String> preventedRoles = Lists.newLinkedList(grantingRoles);
            preventedRoles.removeAll(allowedRoles);
            throw new IllegalArgumentException("Cannot grant the following roles: " + preventedRoles);
        }
    }

    private Predicate<String> isGrantAllowed(final List<String> heldRoles) {
        return new Predicate<String>() {

            @Override
            public boolean apply(String roleName) {
                List<String> authorities = toAuthorities(roleName);
                for (String heldRoleName : heldRoles) {
                    if (toAuthorities(heldRoleName).containsAll(authorities)) {
                        return true;
                    }
                }
                return false;
            }
        };
    }
*/

    public Collection<String> getAvailableRoles() {
        return roleMap.keySet();
    }

}
