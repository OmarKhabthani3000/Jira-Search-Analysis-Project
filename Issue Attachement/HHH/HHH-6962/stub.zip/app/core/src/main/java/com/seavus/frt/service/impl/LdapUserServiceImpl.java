package com.seavus.frt.service.impl;

import org.springframework.context.annotation.Profile;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.seavus.frt.config.spring.StringProfiles;
import com.seavus.frt.service.UserService;

@Profile(StringProfiles.LDAP_SECURITY_STR)
@Service("userService")
public class LdapUserServiceImpl implements UserService {
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        return null;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return null;
    }
}
