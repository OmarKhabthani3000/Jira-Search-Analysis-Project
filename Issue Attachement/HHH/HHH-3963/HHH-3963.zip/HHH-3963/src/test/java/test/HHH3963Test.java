/**
 * 
 */
package test;

import java.util.List;

import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import entities.Child;
import entities.Parent;

/**
 * @author mtorres
 *
 */
public class HHH3963Test {
	private SessionFactory sessionFactory;
	@BeforeClass
	public void init(){
		AnnotationConfiguration configuration = new AnnotationConfiguration();
		configuration.configure();
		sessionFactory = configuration.buildSessionFactory();
	}
	
	
	@Test
	public void testFlush(){
		Long id=null;
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.setFlushMode(FlushMode.MANUAL);
		Parent parent = new Parent();
		parent.setName("test");
		session.saveOrUpdate(parent);
		id = parent.getId();
		session.flush();
		tx.commit();
		session.close();
		
		
		session = sessionFactory.openSession();
		tx = session.beginTransaction();
		session.setFlushMode(FlushMode.MANUAL);
		parent = (Parent)session.get(Parent.class, id);
		Child child = new Child();
		child.setName("testChild");
		parent.getChildrenForEdit().add(child);
		tx.commit();
		session.close();
		
		
		session = sessionFactory.openSession();
		session.setFlushMode(FlushMode.MANUAL);
		@SuppressWarnings("unchecked")
		List<Child> children = session.createCriteria(Child.class).list();
		//no children should have been created
		Assert.assertTrue(children.isEmpty());
		session.close();
		
		
		session = sessionFactory.openSession();
		tx = session.beginTransaction();
		session.setFlushMode(FlushMode.MANUAL);
		parent = (Parent)session.get(Parent.class, id);
		child = new Child();
		child.setName("testChild");
		parent.getChildrenForEdit().add(child);
		System.out.println(session.isDirty());
		tx.commit();
		session.close();
		
		session = sessionFactory.openSession();
		session.setFlushMode(FlushMode.MANUAL);
		children = session.createCriteria(Child.class).list();
		//no children should have been created
		Assert.assertTrue(children.isEmpty());
		session.close();
	}
	
	@AfterClass
	public void close(){
		sessionFactory.close();
	}
}
