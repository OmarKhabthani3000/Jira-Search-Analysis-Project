
import org.hibernate.*;
import org.hibernate.cfg.*;

public class Test1 {
	public static void main(String [] args) {
		try {
			SessionFactory sessionFactory = 
				new Configuration().configure().buildSessionFactory();
	      	Session session = sessionFactory.openSession();

	        Transaction t = session.beginTransaction();
	        
	        Department dept = new Department();
	        dept.setLocation("bangalore");
	        
	        session.save(dept);

	        t.commit();
	        session.close();
        } catch (Exception ex) {
          System.out.println("ex: " + ex);          
	    }	    		
	}
}
