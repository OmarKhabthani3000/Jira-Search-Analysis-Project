


Test1 & Test2 are only for creating the tables and data.


To see the issue:
1> Run Test1
2> Run Test2
3> Run Test3 ( this will throw the LazyInitializationException)
