package org.hibernate.bugs;

import java.util.Date;
import java.util.Objects;

/**
 * <code>Company</code>.
 */
public class Company {

    private String id;

    private Date version;

    private String name;

    private LegalForm legalForm;

    private Taxnumber taxnumber;

    public Taxnumber getTaxnumber() {
        return taxnumber == null ? Taxnumber.KEINE : taxnumber;
    }

    public void setTaxnumber(Taxnumber taxnumber) {
        this.taxnumber = Taxnumber.KEINE.equals(taxnumber) ? null : taxnumber;
    }

    public LegalForm getLegalForm() {
        return legalForm == null ? LegalForm.UNKNOWN : legalForm;
    }

    public void setLegalForm(LegalForm kind) {
        this.legalForm = LegalForm.UNKNOWN.equals(kind) ? null : kind;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public final String getId() {
        return id;
    }

    public final void setId(String newId) {
        id = newId;
    }

    public final boolean hasVersion() {
        return version != null;
    }

    public final Date getVersion() {
        return (version == null) ? null : (Date) version.clone();
    }

    public final void setVersion(Date newVersion) {
        version = (newVersion == null) ? null : (Date) newVersion.clone();
    }

    @Override
    public boolean equals(Object obj) {
        final boolean result;
        if (this == obj) {
            result = true;
        } else if ((obj != null) && getClass().equals(obj.getClass())) {
            final Company other = (Company) obj;
            if ((getId() == null) || (other.getId() == null)) {
                result = super.equals(obj);
            } else {
                result = getId().equals(other.getId())
                        && Objects.equals(getVersion(), other.getVersion());
            }
        } else {
            result = false;
        }
        return result;
    }

    @Override
    public int hashCode() {
        return (getId() == null) ? super.hashCode() : getId().hashCode();
    }

}
