package org.hibernate.bugs;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Objects;
import java.util.Properties;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.usertype.ParameterizedType;
import org.hibernate.usertype.UserType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public final class EnumType<T extends Enum<T>> implements UserType, ParameterizedType {

    private static final Logger LOG = LoggerFactory.getLogger(EnumType.class);

    private Class<T> enumClass;

    private String defaultName;

    public static <E extends Enum<E>> Properties parametersFor(Class<E> enumClass) {
        final Properties result = new Properties();
        result.setProperty("enum", enumClass.getCanonicalName());
        return result;
    }

    @Override
    public final Object deepCopy(Object value) throws HibernateException {
        return value;
    }

    @Override
    public final boolean isMutable() {
        return false;
    }

    @Override
    public final Object assemble(Serializable cached, Object owner) throws HibernateException {
        return cached;
    }

    @Override
    public final Serializable disassemble(Object value) throws HibernateException {
        return (Serializable) value;
    }

    @Override
    public final Object replace(Object original, Object target, Object owner)
            throws HibernateException {
        return original;
    }

    @Override
    public int[] sqlTypes() {
        return new int[] {Types.VARCHAR};
    }

    @Override
    public Class returnedClass() {
        return enumClass;
    }

    @Override
    public boolean equals(Object x, Object y) throws HibernateException {
        return Objects.equals(x, y);
    }

    @Override
    public int hashCode(Object x) throws HibernateException {
        return x.hashCode();
    }

    @Override
    public Object nullSafeGet(ResultSet rs, String[] names, SharedSessionContractImplementor /* SessionImplementor */ session, Object owner)
            throws HibernateException, SQLException {
        String name = rs.getString(names[0]);
        if ((name == null || name.isEmpty()) && (defaultName != null && !defaultName.isEmpty())) {
            name = defaultName;
        }
        Object result = null;
        if (name != null) {
            result = Enum.valueOf(enumClass, name);
        }
        return result;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void nullSafeSet(PreparedStatement st, Object value, int index,
            SharedSessionContractImplementor /* SessionImplementor */ session)
            throws HibernateException, SQLException {
        if (value==null) {
            st.setNull(index, Types.VARCHAR);
        } else {
            st.setString(index, ((Enum<T>) value).name());
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public void setParameterValues(Properties parameters) {
        final String enumClassName = parameters.getProperty("enum");
        if (enumClassName == null) {
            throw new MappingException("enum nicht spezifiziert");
        }
        try {
            enumClass = (Class<T>) loadClassAsSubclass(enumClassName, Enum.class);
        } catch (final IllegalStateException e) {
            throw new MappingException("Enumklasse nicht gefunden", e);
        }

        defaultName = parameters.getProperty("default");
        if (defaultName != null) {
            try {
                Enum.valueOf(enumClass, defaultName);
            } catch (final IllegalArgumentException e) {
                LOG.error("Default '{}' ist ung�ltig.", defaultName);
            }
        }
    }

    private static <T> Class<? extends T> loadClassAsSubclass(String className, Class<T> subclass) {
        try {
            return Class.forName(className).asSubclass(subclass);
        } catch (final ClassNotFoundException e) {
            throw new IllegalStateException("Klasse nicht gefunden: " + className, e);
        }
    }

}
