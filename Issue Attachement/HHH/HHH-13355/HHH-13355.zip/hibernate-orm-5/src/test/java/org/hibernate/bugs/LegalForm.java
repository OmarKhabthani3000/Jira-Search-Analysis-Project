package org.hibernate.bugs;

public enum LegalForm {

    AG, GMBH, UNKNOWN;
}
