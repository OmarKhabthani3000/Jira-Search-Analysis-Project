package org.hibernate.bugs;

import java.io.Serializable;

public final class Taxnumber implements Comparable<Taxnumber>, Serializable {

    public static final int UNKNOWN = -1;

    public static final Taxnumber KEINE = new Taxnumber(UNKNOWN, "");

    private static final long serialVersionUID = 0L;

    private String nummer = "";

    private int bufa = UNKNOWN;

    private Taxnumber() {
    }

    private Taxnumber(int aBufa, String aNummer) {
        setNummer2(aNummer);
        setBufa2(aBufa);
    }

    public String getNummer() {
        return nummer;
    }

    private String getNummer2() {
        return isEmpty(nummer) ? null : nummer;
    }

    private boolean isEmpty(String str) {
        return ((str == null) || (str.length() == 0));
    }

    private void setNummer2(String newNummer) {
        nummer = (newNummer == null) ? "" : newNummer;
    }

    public int getBufa() {
        return bufa;
    }

    private int getBufa2() {
        return bufa;
    }

    private void setBufa2(int newBufa) {
        bufa = newBufa;
    }

    @Override
    public int compareTo(Taxnumber other) {
        return nummer.compareTo(other.getNummer());
    }


    @Override
    public boolean equals(Object obj) {
        final boolean result;
        if (this == obj) {
            result = true;
        } else if (obj instanceof Taxnumber) {
            final Taxnumber other = (Taxnumber) obj;
            result = (bufa == other.bufa) && nummer.equals(other.getNummer());
        } else {
            result = false;
        }
        return result;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + bufa;
        result = prime * result + nummer.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return getNummer();
    }
}