package org.hibernate.bugs.hhh3223;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Bug
{
  public static void main(String... args)
    throws Throwable
  {
    EntityManagerFactory entityManagerFactory =
      Persistence.createEntityManagerFactory("bugs");
    EntityManager entityManager = entityManagerFactory.createEntityManager();

    entityManager.getTransaction().begin();

    Parent parent = new Parent("parent");
    entityManager.persist(parent);

    Child c1 = new Child("c1", parent);
    entityManager.persist(c1);

    Child c2 = new Child("c2", parent);
    entityManager.persist(c2);

    Child c3 = new Child("c3", parent);
    entityManager.persist(c3);

    entityManager.getTransaction().commit();
    entityManager.close();

    entityManager = entityManagerFactory.createEntityManager();

    List<Parent> parents =
      entityManager.createQuery("select p from Parent p").getResultList();
    for (Parent p : parents)
    {
      System.out.printf("%s:\n", p.getName());

      for (Child c : p.getChildren().values())
      {
        System.out.printf("  - %s\n", c.getName());
      }

      entityManager.getTransaction().begin();
      p.getChildren().remove("c1");
      entityManager.getTransaction().commit();
    }

    for (Parent p : parents)
    {
      System.out.printf("%s:\n", p.getName());

      for (Child c : p.getChildren().values())
      {
        System.out.printf("  - %s\n", c.getName());
      }
    }

    entityManager.close();

    entityManager = entityManagerFactory.createEntityManager();

    parents =
      entityManager.createQuery("select p from Parent p").getResultList();
    for (Parent p : parents)
    {
      System.out.printf("%s:\n", p.getName());

      for (Child c : p.getChildren().values())
      {
        System.out.printf("  - %s\n", c.getName());
      }

      entityManager.getTransaction().begin();
      p.getChildren().remove("c1");
      entityManager.getTransaction().commit();
    }

    for (Parent p : parents)
    {
      System.out.printf("%s:\n", p.getName());

      for (Child c : p.getChildren().values())
      {
        System.out.printf("  - %s\n", c.getName());
      }
    }
  }
}
