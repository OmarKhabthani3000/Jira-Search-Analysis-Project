package org.hibernate.bugs.hhh3223;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Child
{
  @Id
  @GeneratedValue
  protected int id;

  @Basic
  protected String name;

  @ManyToOne
  protected Parent parent;

  public Child(String name, Parent parent)
  {
    this.name = name;
    this.parent = parent;

    parent.getChildren().put(name, this);
  }

  protected Child()
  {
  }

  public int getId()
  {
    return id;
  }

  public String getName()
  {
    return name;
  }
}
