package org.hibernate.bugs.hhh3223;

import java.util.SortedMap;
import java.util.TreeMap;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Sort;
import org.hibernate.annotations.SortType;

@Entity
public class Parent
{
  @Id
  @GeneratedValue
  protected int id;

  @Basic
  protected String name;

  @OneToMany(mappedBy = "parent")
  @MapKey(name = "name")
  @Sort(type = SortType.NATURAL)
  protected SortedMap<String, Child> children;

  public Parent(String name)
  {
    this.name = name;
  }

  protected Parent()
  {
  }

  public int getId()
  {
    return id;
  }

  public String getName()
  {
    return name;
  }

  public SortedMap<String, Child> getChildren()
  {
    return children != null ? children :
      (children = new TreeMap<String, Child>());
  }
}
