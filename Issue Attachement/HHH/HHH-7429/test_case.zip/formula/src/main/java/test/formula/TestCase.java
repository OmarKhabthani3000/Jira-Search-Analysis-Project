package test.formula;

import java.util.List;

import test.formula.dao.SimpleDAO;
import test.formula.entity.Primary;

public class TestCase {
	
	public static void main(String[] args) {

		SimpleDAO simpleDAO = new SimpleDAO();
		List<Primary> l = simpleDAO.getList();
		for (Primary p : l) {
			System.out.println(p.get__uid__()+"\t"+p.getPtName()+"\t"+p.getPtSurname()+"\t"+p.getCorrectFormula()+"\t"+p.getWrongFormula());
		}
		
	}
}
