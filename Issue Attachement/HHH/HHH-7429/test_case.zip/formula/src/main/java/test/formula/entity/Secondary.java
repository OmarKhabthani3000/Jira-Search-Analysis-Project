package test.formula.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "secondary_table")
public class Secondary {

	@Id
	private long __uid__;
	@Column(name = "user_account")
	private long account;
	@Column(name = "user_note")
	private String note;

	public long get__uid__() {
		return __uid__;
	}

	public void set__uid__(long __uid__) {
		this.__uid__ = __uid__;
	}

	public long getAccount() {
		return account;
	}

	public void setAccount(long account) {
		this.account = account;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

}
