package test.formula.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import test.formula.entity.Primary;

public class SimpleDAO {

	

	public List<Primary> getList() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("manager1");
		EntityManager em = emf.createEntityManager(); 
		return (List<Primary>) em.createNamedQuery("pt.selectAll",
				Primary.class).getResultList();

	}

}
