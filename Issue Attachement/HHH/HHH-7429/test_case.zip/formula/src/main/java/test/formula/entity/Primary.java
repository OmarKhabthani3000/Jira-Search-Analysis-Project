package test.formula.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.Formula;
import org.hibernate.annotations.NamedQuery;

@Entity(name = "primary_table")
@NamedQuery(name = "pt.selectAll", query = "select pt from primary_table pt")
public class Primary {

	@Id
	private long __uid__;
	@Column(name = "name")
	private String ptName;
	@Column(name = "surname")
	private String ptSurname;

	@Formula("__uid__ * 10")
	private int correctFormula;

	@Formula("(select count(st.__uid__) from secondary_table st where st.user_account=__uid__)")
	private int wrongFormula;

	public String getPtName() {
		return ptName;
	}

	public void setPtName(String ptName) {
		this.ptName = ptName;
	}

	public String getPtSurname() {
		return ptSurname;
	}

	public void setPtSurname(String ptSurname) {
		this.ptSurname = ptSurname;
	}


	public long get__uid__() {
		return __uid__;
	}

	public void set__uid__(long __uid__) {
		this.__uid__ = __uid__;
	}

	public int getCorrectFormula() {
		return correctFormula;
	}

	public int getWrongFormula() {
		return wrongFormula;
	}

}
