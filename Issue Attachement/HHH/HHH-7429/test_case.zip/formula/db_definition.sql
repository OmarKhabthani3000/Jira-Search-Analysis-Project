DROP TABLE secondary_table;

DROP TABLE primary_table;

CREATE TABLE primary_table
(
  __uid__ bigint NOT NULL,
  name character(15),
  surname character varying(15) NOT NULL,  
  CONSTRAINT pt___uid___key UNIQUE (__uid__)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE primary_table
  OWNER TO postgres;

  CREATE TABLE secondary_table
(
  __uid__ bigint NOT NULL,
  user_account bigint NOT NULL,
  user_note character(15),
    CONSTRAINT st_user_account FOREIGN KEY (user_account)
      REFERENCES primary_table (__uid__) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT st___uid___key UNIQUE (__uid__)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE secondary_table
  OWNER TO postgres;
  
INSERT INTO primary_table(
            __uid__, name, surname)
VALUES (1, 'John', 'Doe');

INSERT INTO primary_table(
        __uid__, name, surname)
VALUES (2, 'Jane', 'Doe');

INSERT INTO secondary_table(
            __uid__, user_account, user_note)
    VALUES (100, 1, 'Note A');

    INSERT INTO secondary_table(
            __uid__, user_account, user_note)
    VALUES (101, 1, 'Note B');

    INSERT INTO secondary_table(
            __uid__, user_account, user_note)
    VALUES (102, 1, 'Note C');

    INSERT INTO secondary_table(
            __uid__, user_account, user_note)
    VALUES (103, 1, 'Note D');

    INSERT INTO secondary_table(
            __uid__, user_account, user_note)
    VALUES (104, 2, 'Note Z');
