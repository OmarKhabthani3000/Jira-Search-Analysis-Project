package org.hibernate.test;

public final class WorkflowItem {
    private static final long serialVersionUID = 1L;
    private Long id;
    private String name;
    private WorkflowItem next;
    public WorkflowItem() {
    }
    boolean hasNext() {
        return next != null;
    }
    public void setNext(WorkflowItem newNext) {
        next = newNext;
    }
    public WorkflowItem getNext() {
        return next;
    }
    public String getName() {
        return name;
    }
    public void setName(String newName) {
        name = newName;
    }
}
