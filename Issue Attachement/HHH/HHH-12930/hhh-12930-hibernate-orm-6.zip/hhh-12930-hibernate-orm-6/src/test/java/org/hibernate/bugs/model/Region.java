package org.hibernate.bugs.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.NaturalId;

@Getter
@Setter
@Entity
@Table(name = "region")
public class Region {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    private int id;

    private String name;

// non-embedded composite naturalId works:
/*
    @NaturalId
    @Column(name = "country_code", nullable = false)
    private String countryCode;

    @NaturalId
    @Column(name = "zip_code", nullable = false)
    private int zipCode;
*/

    // embedded composite naturalId fails when mapped using ManyToOne and JoinColumns
    @NaturalId
    @Embedded
    private PostalCode postalCode;

}