package org.hibernate.bugs.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class PostalCode {

    @Column(name = "country_code", nullable = false)
    protected String countryCode;

    @Column(name = "zip_code", nullable = false)
    protected int zipCode;
}