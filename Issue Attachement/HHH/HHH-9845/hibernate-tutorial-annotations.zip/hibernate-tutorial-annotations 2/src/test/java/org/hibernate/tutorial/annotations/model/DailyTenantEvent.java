package org.hibernate.tutorial.annotations.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

@Entity
@Table( name = "DailyTenantEvent" )
public class DailyTenantEvent extends Event {

	private static final long serialVersionUID = 1L;

	private String type;
	
    protected SuperUser superUser;


	public DailyTenantEvent() {
		// this form used by Hibernate
	}

	public DailyTenantEvent(String type){
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
/*    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    @LazyCollection(LazyCollectionOption.EXTRA)
	public SuperUser getSuperUser() {
		return superUser;
	}

	public void setSuperUser(SuperUser superUser) {
		this.superUser = superUser;
	}
*/

}
