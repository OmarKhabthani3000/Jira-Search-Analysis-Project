/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2010, Red Hat Inc. or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Inc.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.tutorial.annotations;

import java.util.Date;
import java.util.List;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.tutorial.annotations.model.DailyTenantEvent;
import org.hibernate.tutorial.annotations.model.Event;
import org.hibernate.tutorial.annotations.model.SuperUser;
import org.hibernate.tutorial.annotations.model.User;

/**
 * Illustrates the use of Hibernate native APIs.  The code here is unchanged from the {@code basic} example, the
 * only difference being the use of annotations to supply the metadata instead of Hibernate mapping files.
 *
 * @author Steve Ebersole
 */
public class HQLQueryJoinFetchTest extends TestCase {
	private SessionFactory sessionFactory;

	@Override
	protected void setUp() throws Exception {
		// A SessionFactory is set up once for an application
        sessionFactory = new Configuration()
                .configure() // configures settings from hibernate.cfg.xml
                .buildSessionFactory();
	}

	@Override
	protected void tearDown() throws Exception {
		if ( sessionFactory != null ) {
			sessionFactory.close();
		}
	}

	@SuppressWarnings({ "unchecked" })
	public void testBasicUsage() {
		// create test data
		createTestData();

		// now lets pull events from the database and list them
		Session session = sessionFactory.openSession();
        session.beginTransaction();

        runQueryWithDailyTenantUserJoin(session, 3);
        runQueryWithSuperUser(session, 3);
        
        //Returns uninitialized proxy for the Join Fetch below
        runQueryWithDailyTenantUserJoinFetch(session, 3);




        session.getTransaction().commit();
        session.close();
	}
	
	private void createTestData(){
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		User user = new User("User1", new Date());
		session.save(user);
		
		User user2 = new User("User2", new Date());
		session.save(user2);
		
		session.save( new Event( "Our very first event!", new Date(), user ) );
		session.save( new Event( "A follow up event", new Date(), user ) );
		session.save( new Event( "A follow up event 1", new Date(), user ) );
		session.save( new Event( "A follow up event 2", new Date(), user ) );

		session.save( new Event( "A follow up event for user 2", new Date(), user2 ) );
		
		SuperUser superUser = new SuperUser("Super User");
		superUser.setDate(new Date());
		superUser.setName("Super User 3");
		session.save(superUser);
		
		DailyTenantEvent te = new DailyTenantEvent();
		te.setUser(superUser);
		te.setDate(new Date());
		te.setTitle("Daily Tenant Event");
		te.setType("Daily Tenant Event for Super User 3");
		session.save(te);
	
		te = new DailyTenantEvent();
		te.setUser(superUser);
		te.setDate(new Date());
		te.setTitle("Daily Tenant Event 1");
		te.setType("Daily Tenant Event for Super User 3");
		session.save(te);
		
		session.save( new Event( "A follow up event for user 3", new Date(), superUser ) );

		
		session.getTransaction().commit();
		session.close();
		
	}
	
	public void runQueryWithDailyTenantUserJoin(Session session, int userId){
        List result = session.createQuery( "select event from DailyTenantEvent event INNER JOIN event.user user where user.id=" + userId).list();
        
		for ( DailyTenantEvent event : (List<DailyTenantEvent>) result ) {
			System.out.println( "DailyTenantEvent (" + event.getDate() + ") : " + event.getTitle() );
		}

	}
	
	public void runQueryWithDailyTenantUserJoinFetch(Session session, int userId){
        List result = session.createQuery( "select event from DailyTenantEvent event INNER JOIN FETCH event.user user where user.id=" + userId).list();
        
		for ( DailyTenantEvent event : (List<DailyTenantEvent>) result ) {
			System.out.println( "DailyTenantEvent (" + event.getDate() + ") : " + event.getTitle() );
		}

	}
	
	
	public void runQueryWithSuperUser(Session session, int userId){
        List result = session.createQuery( "select user from SuperUser user where user.id=" + userId).list();
        
		for ( SuperUser user : (List<SuperUser>) result ) {
			System.out.println( "SuperUser (" + user.getDate() + ") : " + user.getName() );
		}

	}
	
	

	

	

}
