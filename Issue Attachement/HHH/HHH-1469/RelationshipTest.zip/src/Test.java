import objects.Ball;
import objects.Box;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.io.IOException;
import java.util.Properties;

public class Test {

	public static void main(String[] args) throws IOException {
		Test tst = new Test();
		tst.run();
	}

	public void run() throws IOException {
		Properties props = new Properties();
		Configuration config = new Configuration();
		SessionFactory factory;
		Session sess;

		//Initialization
		props.load(this.getClass().getResourceAsStream("test-hibernate.properties"));
		config.addProperties(props);
		config.addInputStream(this.getClass().getResourceAsStream("mappings/Ball.hbm.xml"));
		config.addInputStream(this.getClass().getResourceAsStream("mappings/Box.hbm.xml"));

		factory = config.buildSessionFactory();
		sess = factory.openSession();

		//The faulty query - works correctly (or incorrectly works) in Hibernate 3.0.4
		SQLQuery query = sess.createSQLQuery("select {box.*}, {ball.*}, "
		 + "{joinTable.*} from Box box left join Ball_For_Box joinTable on "
		 + "joinTable.box_id = box.box_id left join Ball ball on "
		 + "joinTable.ball_id = ball.ball_id");

		query.addEntity("box", Box.class);
		query.addEntity("ball", Ball.class);
		query.addJoin("joinTable", "box.balls");

		query.list();
	}

}
