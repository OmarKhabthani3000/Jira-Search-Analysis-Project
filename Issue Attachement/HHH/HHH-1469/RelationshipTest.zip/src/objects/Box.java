package objects;

import java.io.Serializable;
import java.util.Set;

/** @author Hibernate CodeGenerator */
public class Box implements Serializable {

    /** identifier field */
    private Integer boxId;

    /** persistent field */
    private int size;

    /** persistent field */
    private Set balls;

    /** full constructor */
    public Box(int size, Set balls) {
        this.size = size;
        this.balls = balls;
    }

    /** default constructor */
    public Box() {
    }

    public Integer getBoxId() {
        return this.boxId;
    }

    public void setBoxId(Integer boxId) {
        this.boxId = boxId;
    }

    public int getSize() {
        return this.size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public Set getBalls() {
        return this.balls;
    }

    public void setBalls(Set balls) {
        this.balls = balls;
    }

}
