package objects;

import java.io.Serializable;
import java.util.Set;

/** @author Hibernate CodeGenerator */
public class Ball implements Serializable {

    /** identifier field */
    private Integer ballId;

    /** persistent field */
    private int colorNum;

    /** persistent field */
    private Set boxes;

    /** full constructor */
    public Ball(int colorNum, Set boxes) {
        this.colorNum = colorNum;
        this.boxes = boxes;
    }

    /** default constructor */
    public Ball() {
    }

    public Integer getBallId() {
        return this.ballId;
    }

    public void setBallId(Integer ballId) {
        this.ballId = ballId;
    }

    public int getColorNum() {
        return this.colorNum;
    }

    public void setColorNum(int colorNum) {
        this.colorNum = colorNum;
    }

    public Set getBoxes() {
        return this.boxes;
    }

    public void setBoxes(Set boxes) {
        this.boxes = boxes;
    }

}
