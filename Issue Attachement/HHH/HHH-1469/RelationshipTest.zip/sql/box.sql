CREATE TABLE `box` (
  `box_id` int(11) NOT NULL auto_increment,
  `size` int(11) NOT NULL default '0',
  PRIMARY KEY  (`box_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1