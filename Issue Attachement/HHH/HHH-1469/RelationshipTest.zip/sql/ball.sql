CREATE TABLE `ball` (
  `ball_id` int(11) NOT NULL auto_increment,
  `color_num` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ball_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1