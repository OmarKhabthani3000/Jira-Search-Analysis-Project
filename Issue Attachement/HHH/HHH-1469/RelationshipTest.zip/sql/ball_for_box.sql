CREATE TABLE `ball_for_box` (
  `ball_for_box_id` int(11) NOT NULL auto_increment,
  `box_id` int(11) NOT NULL default '0',
  `ball_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ball_for_box_id`),
  KEY `fk1` (`box_id`),
  KEY `fk2` (`ball_id`),
  CONSTRAINT `fk1` FOREIGN KEY (`box_id`) REFERENCES `box` (`box_id`),
  CONSTRAINT `fk2` FOREIGN KEY (`ball_id`) REFERENCES `ball` (`ball_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='InnoDB free: 596992 kB'