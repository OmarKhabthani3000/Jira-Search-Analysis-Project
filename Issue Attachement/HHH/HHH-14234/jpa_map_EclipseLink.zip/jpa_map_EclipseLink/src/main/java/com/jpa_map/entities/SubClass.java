
package com.jpa_map.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table( name = "test_subTable",
        uniqueConstraints = {
            @UniqueConstraint(  name = "UK_sub",
                                columnNames = {"colOne", "colTwo", "colThree"})
        }
)
public class SubClass extends SuperClass {

	@Column(name = "colThree")
	protected Long colThree;

	//<editor-fold defaultstate="collapsed" desc="get/set">
	public Long getColThree() {
		return colThree;
	}
	
	public void setColThree(Long colThree) {
		this.colThree = colThree;
	}
	//</editor-fold>
}
