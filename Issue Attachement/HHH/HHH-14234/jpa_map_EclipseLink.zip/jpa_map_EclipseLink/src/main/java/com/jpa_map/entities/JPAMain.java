
package com.jpa_map.entities;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/** EclipseLink test.		*/
public class JPAMain {

	private static EntityManagerFactory factory;
	
	// name from persistence.xml
	private static final String PERSISTENCE_UNIT_NAME = "jpa_map_PU";


	public static void main(String[] args) {

		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();

		// read the existing entries and write to console
		Query q = em.createQuery("SELECT sc FROM SubClass sc");
		List<SubClass> todoList = q.getResultList();

		for(SubClass subClass: todoList) {
			System.out.println(subClass);
		}

		System.out.println("Size: " + todoList.size());

		// create new todo
		em.getTransaction().begin();

		SubClass subClass = new SubClass();
			subClass.setColOne(123L);
			subClass.setColThree(999L);

		em.persist(subClass);
		em.getTransaction().commit();

		em.close();
	}
}
