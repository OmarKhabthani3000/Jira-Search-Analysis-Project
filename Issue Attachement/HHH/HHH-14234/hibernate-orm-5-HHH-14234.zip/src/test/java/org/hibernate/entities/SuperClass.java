
package org.hibernate.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@Table( name = "test_supTable",
        uniqueConstraints = {
            @UniqueConstraint(  name = "UK_sup",
                                columnNames = {"colOne", "colTwo"})
        }
)
public class SuperClass implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	@Column(name = "id", unique = true, nullable = false)
	protected Long id;

	@Column(name = "colOne")
	protected Long colOne;

	@Column(name = "colTwo")
	protected Long colTwo;

	//<editor-fold defaultstate="collapsed" desc="get/set">
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getColOne() {
		return colOne;
	}
	
	public void setColOne(Long colOne) {
		this.colOne = colOne;
	}
	
	public Long getColTwo() {
		return colTwo;
	}
	
	public void setColTwo(Long colTwo) {
		this.colTwo = colTwo;
	}
	//</editor-fold>
}
