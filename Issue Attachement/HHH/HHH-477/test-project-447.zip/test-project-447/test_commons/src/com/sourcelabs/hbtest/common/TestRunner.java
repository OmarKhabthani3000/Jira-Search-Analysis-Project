package com.sourcelabs.hbtest.common;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: konstantinignatyev
 * Date: Jul 25, 2005
 * Time: 1:08:25 PM
 */
public abstract class TestRunner {

  static Logger log = Logger.getLogger(TestRunner.class);

  private static final SessionFactory sessionFactory;
  private static ThreadLocal transaction = new ThreadLocal();
  public static final ThreadLocal session = new ThreadLocal();

  static {
    try {
      sessionFactory = new Configuration()
          .configure().buildSessionFactory();
    } catch (HibernateException ex) {
      throw new RuntimeException("Exception building SessionFactory: " + ex.getMessage(), ex);
    }
  }


  public static Session currentSession() throws HibernateException {
    Session s = (Session) session.get();
    // Open a new Session, if this Thread has none yet
    if (s == null) {
      s = sessionFactory.openSession();
      Transaction tx = s.beginTransaction();
      transaction.set( tx );
      session.set(s);
      //            if(debug)
      {
        log.debug("Creating new Hibernate Session: " + Thread.currentThread().getName());
      }
    }
    else
    {
      log.debug("Returning existing session: "+s.toString());
    }
    return s;
  }
  public static void closeSession()
      throws HibernateException
  {
    Session s = (Session) session.get();
    Transaction tx = (Transaction) transaction.get();
    tx.commit();
    session.set(null);
    transaction.set( null);
    if (s != null){
      s.close();
      log.debug("Closing Hibernate Session: "+ (s != null ? s.toString() : "null" ));
    }
  }


  public void executeTests(String[] args) {
    try{
      Session s = currentSession();
      test( s );
      closeSession();
    } catch( Exception e ){
      e.printStackTrace();
    }
  }

  public abstract void test(Session s) throws Exception ;


  protected void print(List l) {
    for (Iterator j = l.iterator(); j.hasNext();) {
      Object o = j.next();

      printProperties( o );
    }
  }

  private void printProperties(Object o) {
    try{
    System.out.println( o );
    Map m = BeanUtils.describe( o );
     List keys = new ArrayList( m.keySet() );
      Collections.sort( keys );
      for (Iterator k = keys.iterator(); k.hasNext();) {
        String key = (String) k.next();
        System.out.println(key +" = " + m.get( key ));
      }
    }catch( Exception e ){
      e.printStackTrace();
    }
  }
}
