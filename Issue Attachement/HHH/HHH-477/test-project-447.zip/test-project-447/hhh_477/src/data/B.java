package data;

/**
 * Created by IntelliJ IDEA.
 * User: konstantinignatyev
 * Date: Jul 25, 2005
 * Time: 12:44:20 PM
 */
public class B extends A{

  public B() {
    super();
  }


  public B(String id, String name) {
    super(id, name);
  }
}
