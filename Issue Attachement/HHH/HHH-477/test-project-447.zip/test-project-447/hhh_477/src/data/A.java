package data;

/**
 * Created by IntelliJ IDEA.
 * User: konstantinignatyev
 * Date: Jul 25, 2005
 * Time: 12:44:08 PM
 */
public class A {
  String id;
  String name;

  public A() {
  }

  public A(String id, String name) {
    this.id = id;
    this.name = name;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
}
