import com.sourcelabs.hbtest.common.TestRunner;
import data.B;
import data.A;
import org.hibernate.Session;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: konstantinignatyev
 * Date: Jul 25, 2005
 * Time: 12:43:52 PM
 */
public class RunTests extends TestRunner
{

  public static void main(String[] args) {
    RunTests r = new RunTests();
    r.executeTests( args );
  }

  public void test(Session s) throws Exception {
    List l = s.createQuery( "from B" ).list();
    print( l );
    String  id = "" + System.currentTimeMillis();
    B o = new B( id, "BB" + id);
    s.save( o );

    Thread.sleep(2);
    id = "" + System.currentTimeMillis();
    A a = new A( id, "AA" + id);
    s.save( a );
  }

}
