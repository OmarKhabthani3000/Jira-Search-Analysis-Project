drop table a;

create table a(
  id varchar(50),
  name varchar(50),
  registered boolean
);

insert into a values( 'oA', 'Object A', false );
insert into a values( 'oB', 'Object B', true );