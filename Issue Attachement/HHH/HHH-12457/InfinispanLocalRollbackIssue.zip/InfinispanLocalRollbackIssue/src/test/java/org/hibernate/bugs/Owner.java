package org.hibernate.bugs;

import javax.persistence.*;

import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name = "OWNER")
@org.hibernate.annotations.Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
public class Owner {
    @Id
    @GeneratedValue
    private Long owner_id;

    @Version
    private Long version;

    private String name;

    public Owner() {
    }

    public long getId() {
        return owner_id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }
}