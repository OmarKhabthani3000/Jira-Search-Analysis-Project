package org.hibernate.bugs;

import java.util.function.Function;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    @Test
    public void transactionRollbackAffectsCache() throws Exception {
        final Long ownerId = transactional((em) -> {
            Owner o = new Owner();
            o.setName("1");
            em.persist(o);
            return o.getId();
        });

        try {
            transactional((em) -> {
                final Owner o = em.find(Owner.class, ownerId);
                o.setName("2");
                em.flush();
                throw new RuntimeException("boom");
            });
        } catch (Exception e) {
            //ok
        }

        transactional((em) -> {
            final Owner o = em.find(Owner.class, ownerId);
            Assert.assertEquals("1", o.getName());
            return null;
        });
    }

    @Test
    public void transactionSuccessAffectsCache() throws Exception {
        final Long ownerId = transactional((em) -> {
            Owner o = new Owner();
            o.setName("1");
            em.persist(o);
            return o.getId();
        });

        transactional((em) -> {
            final Owner o = em.find(Owner.class, ownerId);
            o.setName("2");
            em.flush();
            return null;
        });

        transactional((em) -> {
            final Owner o = em.find(Owner.class, ownerId);
            Assert.assertEquals("2", o.getName());
            return null;
        });
    }

    private <T> T transactional(Function<EntityManager, T> task) {
        EntityManager em = entityManagerFactory.createEntityManager();
        try {
            try {
                em.getTransaction().begin();
                T result = task.apply(em);
                em.getTransaction().commit();
                return result;
            } catch (Exception e) {
                em.getTransaction().rollback();
                throw e;
            }
        } finally {
            em.close();
        }
    }
}
