package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.hibernate.bugs.test.LegacyEntity;
import org.hibernate.bugs.test.ModernEntity;
import org.hibernate.bugs.test.NestedLegacyEntity;

import java.io.Serializable;

/**
 * This template demonstrates how to develop a org.hibernate.bugs.test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	/**
	 * Get an identifier for an entity with a nested IdClass which already exists in the db.
	 * @throws Exception
	 */
	@Test
	public void getIdentifierTest() throws Exception {

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		// This gives a NullPointerException right now. Look at HHH-10623 when this issue is fixed
		Serializable nestedLegacyEntityId = (Serializable) entityManager.getEntityManagerFactory()
				.getPersistenceUnitUtil().getIdentifier(createExisitingNestedLegacyEntity());

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	private NestedLegacyEntity createExisitingNestedLegacyEntity() {

		ModernEntity modernEntity = new ModernEntity();
		modernEntity.setFoo(2);

		LegacyEntity legacyEntity = new LegacyEntity();
		legacyEntity.setPrimitivePk1(1);
		legacyEntity.setPrimitivePk2(2);
		legacyEntity.setFoo("Foo");

		NestedLegacyEntity nestedLegacyEntity = new NestedLegacyEntity();
		nestedLegacyEntity.setModernEntity(modernEntity);
		nestedLegacyEntity.setLegacyEntity(legacyEntity);

		return nestedLegacyEntity;
	}
}
