package enterprise.web_jpa_war.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Thing implements Serializable {

	@ManyToOne(optional = false)
	private Person person;
	private static final long serialVersionUID = 1L;
	@Id @GeneratedValue
	private Long id;

	// <editor-fold defaultstate="collapsed" desc="BOILERPLATE GETTERS/SETTERS">
	public Thing() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}
	// </editor-fold>
}
