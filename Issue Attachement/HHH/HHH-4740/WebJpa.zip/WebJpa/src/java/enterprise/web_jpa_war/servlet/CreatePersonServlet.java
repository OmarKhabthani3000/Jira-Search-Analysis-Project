package enterprise.web_jpa_war.servlet;

import enterprise.web_jpa_war.entity.Person;
import enterprise.web_jpa_war.entity.Thing;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import javax.persistence.PersistenceUnit;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityManager;
import javax.annotation.Resource;
import javax.transaction.UserTransaction;

@WebServlet(name = "CreatePersonServlet", urlPatterns = {"/CreatePerson"})
public class CreatePersonServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	@PersistenceUnit
	//The emf corresponding to
	private EntityManagerFactory emf;
	@Resource
	private UserTransaction utx;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		EntityManager em = null;
		try {
			String id = request.getParameter("id");
			String firstName = request.getParameter("firstName");
			String lastName = request.getParameter("lastName");

			Person person = new Person();
			person.setId(id);
			person.setFirstName(firstName);
			person.setLastName(lastName);
			for (int i = 0 ; i < 5 ; i++) {
				Thing thing = new Thing();
				thing.setPerson(person);
				person.getThings().add(thing);
			}

			utx.begin();
			em = emf.createEntityManager();
			em.persist(person);
			utx.commit();

			request.getRequestDispatcher("ListPerson").forward(request, response);
		} catch (Exception ex) {
			throw new ServletException(ex);
		} finally {
			if (em != null) {
				em.close();
			}
		}
	}
}
