package enterprise.web_jpa_war.servlet;

import enterprise.web_jpa_war.entity.Person;
import java.io.*;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.Query;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import javax.persistence.PersistenceUnit;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityManager;
import javax.transaction.UserTransaction;

@WebServlet(name = "ListPersonServlet", urlPatterns = {"/ListPerson"})
public class ListPersonServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	@PersistenceUnit
	private EntityManagerFactory emf;
	@Resource
	private UserTransaction utx;

	@Override
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		EntityManager em = null;
		try {
			em = emf.createEntityManager();

			Query query = em.createQuery("select p from Person p");
			List<Person> persons = query.getResultList();
			request.setAttribute("personList", persons);

			// REMOVE ALL THE THINGS, TO CHECK REMOVEORPHANS
			utx.begin();
			for (Person person : persons)  {
				em = emf.createEntityManager();
				person = em.merge(person);
				person.getThings().clear(); // SHOULD BE NO NEED TO REMOVE ID FROM ELEMENTS
			}
			utx.commit();

			query = em.createQuery("select p from Person p");
			persons = query.getResultList();
			for (Person person : persons)  {
				if (!person.getThings().isEmpty())
					throw new RuntimeException("removeOrphans failed");
			}

			request.getRequestDispatcher("ListPerson.jsp").forward(request, response);
		} catch (Exception ex) {
			throw new ServletException(ex);
		} finally {
			if (em != null) {
				em.close();
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
