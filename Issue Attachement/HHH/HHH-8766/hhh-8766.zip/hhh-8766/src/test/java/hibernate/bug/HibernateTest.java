package hibernate.bug;

import hibernate.bug.model.Document;
import hibernate.bug.model.Person;
import hibernate.bug.model.Bro;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Person p = new Person("person");
        Bro b = new Bro("bro");
        Document d = new Document(b);
        
        em.persist(p);
        em.persist(b);
        em.persist(d);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void test() {
        EntityManager em = emf.createEntityManager();
        
        List<Document> l = em.createQuery(
                "FROM Document d "
                + "WHERE TYPE(d.owner) = :t1", Document.class)
                .setParameter("t1", Bro.class)
                .getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
    
    @Test
    public void test2() {
        EntityManager em = emf.createEntityManager();
        
        List<Document> l = em.createQuery(
                "FROM Document d "
                + "JOIN FETCH d.owner o "
                + "WHERE TYPE(o) = :t1", Document.class)
                .setParameter("t1", Bro.class)
                .getResultList();
        Assert.assertEquals(1, l.size());
        
        em.close();
    }
}
