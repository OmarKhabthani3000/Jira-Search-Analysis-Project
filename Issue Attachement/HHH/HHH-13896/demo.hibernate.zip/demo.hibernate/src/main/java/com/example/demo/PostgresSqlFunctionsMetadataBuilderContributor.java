package com.example.demo;

import org.hibernate.boot.MetadataBuilder;
import org.hibernate.boot.spi.MetadataBuilderContributor;
import org.hibernate.dialect.function.StandardSQLFunction;
import org.hibernate.type.StandardBasicTypes;

public class PostgresSqlFunctionsMetadataBuilderContributor implements MetadataBuilderContributor {

	@Override
	public void contribute(MetadataBuilder metadataBuilder) {
		 metadataBuilder.applySqlFunction(
		            "DATE_PART",
		            new StandardSQLFunction(
		                "DATE_PART",
		                StandardBasicTypes.INTEGER
		            )
		        );
		 metadataBuilder.applySqlFunction(
		            "jsonb_extract_path_text",
		            new StandardSQLFunction(
		                "jsonb_extract_path_text",
		                StandardBasicTypes.STRING
		            )
		        );
		 metadataBuilder.applySqlFunction(
		            "jsonb_array_length",
		            new StandardSQLFunction(
		                "jsonb_array_length",
		                StandardBasicTypes.LONG
		            )
		        );
		 
		 metadataBuilder.applySqlFunction(
		            "to_number",
		            new StandardSQLFunction(
		                "to_number",
		                StandardBasicTypes.DOUBLE
		            )
		        );
		 metadataBuilder.applySqlFunction(
		            "count",
		            new StandardSQLFunction(
		                "count",
		                StandardBasicTypes.LONG
		            )
		        );
	}

}
