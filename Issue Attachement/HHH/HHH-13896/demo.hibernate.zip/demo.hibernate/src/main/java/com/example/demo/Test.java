package com.example.demo;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;

import org.springframework.stereotype.Service;

@Service
public class Test {
	
	
	@PersistenceContext
	private EntityManager em;
	
	@PostConstruct
	public void init() {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery cq = cb.createQuery();
		From from = cq.from(Domain.class);
		cq.select(cb.count(cb.function("jsonb_extract_path_text", String.class, from.get("extra"), cb.literal("test1"))));
		TypedQuery query = em.createQuery(cq);
		List list = query.getResultList();
		list.size();
	}
}
