/*
 * $Id$
 * Created on Mar 18, 2005
 */
package test;

import java.io.File;
import java.io.Serializable;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

/**
 * @author rando
 * @version $Id$
 */
public class Test {

	public static void main(String[] args) throws Exception {
		Configuration cfg = new Configuration()
		.addJar(new File("hbtest.jar"));
		
		SessionFactory factory = cfg.buildSessionFactory();
		Session s = factory.openSession();

		// create test row
		Transaction tx = s.beginTransaction(); 
		Entity e = new Entity();
		e.getComp().setSimple("simple");
		e.getComp().setDerived("derived");
		s.save(e);
		tx.commit();
		
		try {
			testHQuery(s);
		} catch (Exception ex)	{
			ex.printStackTrace();
		}
		
		try {
			testCritQuery(s);
		} catch (Exception ex)	{
			ex.printStackTrace();
		}

		// cleanup
		tx = s.beginTransaction();
		s.delete(e);
		tx.commit();
		
		s.close();
	}
	
	static void testHQuery(Session s) throws Exception	{
		Query q1 = s.createQuery("from Entity e where e.comp.simple=?");
		q1.setString(0, "simple");
		System.out.println("Quering simple: " +
				q1.uniqueResult());

		Query q2 = s.createQuery("from Entity e where e.comp.derived=?");
		q2.setString(0, "derived");
		System.out.println("Quering derived: " +
				q2.uniqueResult());
	}


	static void testCritQuery(Session s) throws Exception	{
		Criteria c1 = s.createCriteria(Entity.class);
		c1.add(Restrictions.eq("comp.simple", "simple"));
		System.out.println("Criteria simple: " +
				c1.uniqueResult());
		
		Criteria c2 = s.createCriteria(Entity.class);
		c2.add(Restrictions.eq("comp.derived", "derived"));
		System.out.println("Criteria derived: " +
				c2.uniqueResult());
	}
}
