package test;

public class Entity {
	private String id;
	private Comp comp = new Comp();
	
	public String getId() {	return id;	}
	public void setId(String id) {
		this.id = id;
	}
	
	public Comp getComp() {	return comp;	}
	public void setComp(Comp comp) {
		this.comp = comp;
	}
	
	/*
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return "comp.simple=" + getComp().getSimple() 
		+ ", comp.derived=" + getComp().getDerived();
	}
}
