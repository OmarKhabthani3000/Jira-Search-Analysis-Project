package test;

public class Comp {
	private String simple;
	private String derived;

	public String getSimple() {	return simple;	}
	public void setSimple(String simple) {
		this.simple = simple;
	}

	public String getDerived() {	return derived;	}
	public void setDerived(String derived) {
		this.derived = derived;
	}
	
}
