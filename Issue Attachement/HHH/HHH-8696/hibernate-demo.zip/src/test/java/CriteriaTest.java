import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.service.ServiceRegistryBuilder;
import org.hibernate.sql.JoinType;
import org.hibernate.transform.Transformers;
import org.junit.Test;

import java.util.List;

public class CriteriaTest {

    @Test
    public void test_multiSelectQuery() {
        Configuration configure = new Configuration().configure("HibernateDemo-config.xml");
        SessionFactory sessionFactory = configure.buildSessionFactory(new ServiceRegistryBuilder().applySettings(configure.getProperties()).buildServiceRegistry());

        Session session = sessionFactory.openSession();

        try {
            Criteria criteria = session.createCriteria("A");
            criteria = criteria.createAlias("B", "B", JoinType.LEFT_OUTER_JOIN);
            criteria = criteria.createAlias("B.C", "B#C", JoinType.LEFT_OUTER_JOIN);
            criteria = criteria.createAlias("B.C.D", "B#C#D", JoinType.LEFT_OUTER_JOIN);
            ProjectionList projectionList = Projections.projectionList();
            projectionList.add(Projections.property("id"), "id");
            projectionList.add(Projections.property("B.id"), "B.id");
            projectionList.add(Projections.property("B#C.id"), "B.C.id");
            projectionList.add(Projections.property("B#C#D.id"), "B.C.D.id");
            criteria = criteria.setProjection(projectionList);
            criteria = criteria.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);

            List list = criteria.list();
            System.out.println("Success!");
        } finally {
            session.close();
        }
    }
}
