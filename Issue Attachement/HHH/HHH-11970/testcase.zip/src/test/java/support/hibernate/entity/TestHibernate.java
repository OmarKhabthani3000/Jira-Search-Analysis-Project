package support.hibernate.entity;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import support.hibernate.util.AutoCloser;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.LogManager;

import org.junit.Test;
import org.junit.BeforeClass;
import org.junit.AfterClass;

public class TestHibernate {
	private static Logger log = Logger.getLogger(TestHibernate.class.getCanonicalName());

	private static EntityManager entityManager;

	private static final AutoCloser m_closer = new AutoCloser();

	@BeforeClass
	public static void setUp() throws Exception {
		log.info("Configuring Hibernate " + org.hibernate.Version.getVersionString());
		try {
			// Configures settings from annotations + persistence.xml
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("TEST");
			m_closer.push(emf);
			entityManager = emf.createEntityManager();
			m_closer.push(entityManager);
		} catch (Throwable t) {
			log.warn("Setup failure", t);
		}
	}

	@AfterClass
	public static void tearDown() throws Exception {
		if (entityManager != null) {
			try {
				m_closer.close();
			} finally {
				entityManager = null;
				m_closer.clear();
			}
		}
	}

	@Test
	public void test() {
		log.info("---> test started.");
		EntityTransaction transaction = entityManager.getTransaction();
		try {
			transaction.begin();
			{
				for (int i = 0 ; i < 2 ; i++) {
					Task task = new Task("Major Project");
					log.info("------> Persisting entity('" + task.getName() + "')");
					entityManager.persist(task);
					Employee e = new Employee("employee0" + i);
					e.setTask(task);
					log.info("------> Persisting entity('" + e.getName() + "')");
					entityManager.persist(e);
				}

				entityManager.flush();
				entityManager.clear();
			}
			transaction.commit();

			transaction.begin();
			{
				// remote the underlying task rows so that the fk refs are invalid
				entityManager.createQuery("delete from Task").executeUpdate();

				setLogLevel(Level.TRACE);
				for (Employee e : entityManager.createQuery("from Employee e", Employee.class).getResultList()) {
					log.info("------> Found entity('" + e.getName() + "')");
					Task t = e.getTask();
					if (t != null) {
						log.info("------> Found entity('" + t.getName() + "')");
					}
				}
				setLogLevel(Level.OFF);
			}
			transaction.commit();
		} finally {
			if (transaction.isActive()) {
				try {
					transaction.rollback();
				} catch (Throwable t) {
					log.warn("Rollback failure", t);
				}
			}
			log.info("---> test completed.");
		}
	}

	private static void setLogLevel(Level level) {
		LogManager.getLogger("org.hibernate.SQL").setLevel(level);
		LogManager.getLogger("org.hibernate.type.descriptor.sql.BasicBinder").setLevel(level);
		LogManager.getLogger(TestHibernate.class.getCanonicalName()).setLevel(level);
	}
}
