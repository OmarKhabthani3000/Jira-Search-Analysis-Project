package support.hibernate.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.ConstraintMode;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
public class Employee {
	@Id
	private String name;

	@OneToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
	@NotFound(action = NotFoundAction.IGNORE)
	private Task task;

	public Employee(String name) {
		this();
		setName(name);
	}

	public String getName() {
		return name;
	}

	public Task getTask() {
		return task;
	}

	public void setTask(Task task) {
		this.task = task;
	}

	protected Employee() {
		// this form used by Hibernate
	}

	protected void setName(String name) {
		this.name = name;
	}
}
