drop schema if exists public cascade;
create schema public; 


CREATE TABLE "widget"(
 "id" integer NOT NULL,
 "dimension" numeric(10,2) null,
 "cost" numeric(20,10) null
)
WITH (OIDS=FALSE)
;

ALTER TABLE "widget" ADD CONSTRAINT "widget_pk" PRIMARY KEY ("id")
;

