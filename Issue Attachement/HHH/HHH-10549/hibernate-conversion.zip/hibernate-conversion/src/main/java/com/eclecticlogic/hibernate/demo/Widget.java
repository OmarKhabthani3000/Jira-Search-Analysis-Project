/** 
 *  Copyright (c) 2011-2016 Eclectic Logic LLC. 
 *  All rights reserved. 
 *   
 *  This software is the confidential and proprietary information of 
 *  Eclectic Logic LLC ("Confidential Information").  You shall 
 *  not disclose such Confidential Information and shall use it only
 *  in accordance with the terms of the license agreement you entered 
 *  into with Eclectic Logic LLC.
 *
 **/
package com.eclecticlogic.hibernate.demo;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author kabram.
 *
 */
@Entity
@Table(name = "widget")
public class Widget {

    private int id;
    private BigDecimal dimension;
    private Money cost;


    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }


    @Column(name = "dimension")
    public BigDecimal getDimension() {
        return dimension;
    }


    public void setDimension(BigDecimal dimension) {
        this.dimension = dimension;
    }


    @Column(name = "cost")
    @Convert(converter = MoneyConverter.class)
    public Money getCost() {
        return cost;
    }


    public void setCost(Money cost) {
        this.cost = cost;
    }

}
