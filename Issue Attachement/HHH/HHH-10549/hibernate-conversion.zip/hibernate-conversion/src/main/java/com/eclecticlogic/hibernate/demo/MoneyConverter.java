/** 
 *  Copyright (c) 2011-2016 Eclectic Logic LLC. 
 *  All rights reserved. 
 *   
 *  This software is the confidential and proprietary information of 
 *  Eclectic Logic LLC ("Confidential Information").  You shall 
 *  not disclose such Confidential Information and shall use it only
 *  in accordance with the terms of the license agreement you entered 
 *  into with Eclectic Logic LLC.
 *
 **/
package com.eclecticlogic.hibernate.demo;

import java.math.BigDecimal;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

/**
 * @author kabram.
 *
 */
//@Converter(autoApply = true)
public class MoneyConverter implements AttributeConverter<Money, BigDecimal> {

    public BigDecimal convertToDatabaseColumn(Money attribute) {
        return attribute;
    }


    public Money convertToEntityAttribute(BigDecimal dbData) {
        return new Money(dbData.toString());
    }

}
