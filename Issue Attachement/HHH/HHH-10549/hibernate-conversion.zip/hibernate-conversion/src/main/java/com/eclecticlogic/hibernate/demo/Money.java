/** 
 *  Copyright (c) 2011-2016 Eclectic Logic LLC. 
 *  All rights reserved. 
 *   
 *  This software is the confidential and proprietary information of 
 *  Eclectic Logic LLC ("Confidential Information").  You shall 
 *  not disclose such Confidential Information and shall use it only
 *  in accordance with the terms of the license agreement you entered 
 *  into with Eclectic Logic LLC.
 *
 **/
package com.eclecticlogic.hibernate.demo;

import java.math.BigDecimal;
import java.math.RoundingMode;


/**
 * @author kabram.
 *
 */
@SuppressWarnings("serial")
public class Money extends BigDecimal {

    public Money(String value) {
        super(value);
    }
    
    
    public Money(BigDecimal value) {
        super(value.toString());
    }


    @Override
    public BigDecimal add(BigDecimal augend) {
        return new Money(this.add(augend).setScale(10, RoundingMode.HALF_EVEN));
    }
}
