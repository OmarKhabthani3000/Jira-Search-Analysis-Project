package com.eclecticlogic.hibernate.demo;

import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Transactional;

@SpringBootApplication
@Transactional
public class Demo implements CommandLineRunner {

    @PersistenceContext
    private EntityManager manager;


    public static void main(String[] args) {
        SpringApplication.run(new Object[] { Demo.class }, args);
    }


    public void run(String... arg0) throws Exception {
        writeWidget();
    }


    public void writeWidget() {
        Widget w = new Widget();
        w.setId(1);
        w.setDimension(new BigDecimal("1.0"));
        w.setCost(new Money("2.0"));
        manager.persist(w);
        manager.flush();
        manager.close();
    }

}
