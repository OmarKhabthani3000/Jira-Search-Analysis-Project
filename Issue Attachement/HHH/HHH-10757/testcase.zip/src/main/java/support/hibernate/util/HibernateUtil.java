package support.hibernate.util;

import java.sql.Connection;

import javax.persistence.EntityManager;

import support.redhat.reflect.ClassUtil;

public class HibernateUtil {
	/**
	 * Borrow the connection from the {@EntityManager}
	 */
	public static Connection getConnection(EntityManager entityManager) {
		try {
			Object session = entityManager.getDelegate();
			// SessionImpl moved from org.hibernate.impl (3.3.2) to org.hibernate.internal (4.x)
			Object connection = ClassUtil.getMethod(session.getClass(), "connection").invoke(session);
			return java.sql.Connection.class.cast(connection);
		} catch (Throwable t) {
			throw new RuntimeException(t);
		}
	}

}
