package org.hibernate.bugs;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "T_USER_ROLE", indexes={@Index(name = "t_user_role_id_indx", columnList="ID", unique = true),
		@Index(name = "t_user_role_uindx", columnList="USER_ID, ROLE_ID", unique = true)})
public class UserRole implements Serializable {
	private static final long serialVersionUID = -5191761439973850886L;

	@Id
	@Column(name = "ID", nullable = false)
	@SequenceGenerator(name="userRoleIdGen", sequenceName="s_t_user_role", initialValue=1, allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="userRoleIdGen")
	private Long id;
	
	@Column(name = "USER_ID", nullable = false)
	private Long userId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "USER_ID", foreignKey=@ForeignKey(name = "t_user_role_uid_fk"), nullable = false, insertable = false, updatable = false)
	private User user;
	
	@Column(name = "ROLE_ID", nullable = false)
	private Long roleId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ROLE_ID", referencedColumnName = "ID", foreignKey=@ForeignKey(name = "t_user_role_rid_fk"), nullable = false, insertable = false, updatable = false)
	private Role role;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getRoleId() {
		return roleId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}
	
	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserRole other = (UserRole) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "UserRole [id=" + id + ", userId=" + userId + ", roleId=" + roleId + "]";
	}
}
