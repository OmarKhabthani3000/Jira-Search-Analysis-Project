/*
 * Created on Feb 28, 2005
 */
package org.hibernate.test.subqueries;

import java.util.HashSet;
import java.util.Set;

/**
 * @author gg
 */
public class B {
    private Integer id;
    private A a;
    private Set cs;

    /**
     * @return Returns the a.
     */
    public A getA() {
        return this.a;
    }

    /**
     * @param a The a to set.
     */
    public void setA(A a) {
        this.a = a;
    }

    /**
     * @return Returns the id.
     */
    public Integer getId() {
        return this.id;
    }

    /**
     * @param id The id to set.
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return Returns the cs.
     */
    public Set getCs() {
        if (this.cs == null)
            this.cs = new HashSet();
        return this.cs;
    }

    /**
     * @param cs The cs to set.
     */
    public void setCs(Set cs) {
        this.cs = cs;
    }
}