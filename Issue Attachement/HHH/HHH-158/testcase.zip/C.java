/*
 * Created on Feb 28, 2005
 */
package org.hibernate.test.subqueries;

/**
 * @author gg
 */
public class C {
    private Integer id;
    private B b;

    /**
     * @return Returns the b.
     */
    public B getB() {
        return this.b;
    }

    /**
     * @param b The b to set.
     */
    public void setB(B b) {
        this.b = b;
    }

    /**
     * @return Returns the id.
     */
    public Integer getId() {
        return this.id;
    }

    /**
     * @param id The id to set.
     */
    public void setId(Integer id) {
        this.id = id;
    }
}