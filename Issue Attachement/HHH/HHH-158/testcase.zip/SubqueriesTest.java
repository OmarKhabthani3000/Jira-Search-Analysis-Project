/*
 * Created on Feb 28, 2005
 */
package org.hibernate.test.subqueries;

import java.util.List;
import junit.framework.TestCase;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;

/**
 * @author gg
 */
public class SubqueriesTest extends TestCase {

    public SubqueriesTest() {
        super();
    }

    public SubqueriesTest(String name) {
        super(name);
    }

    /**
     * Default test.
     */
    public void testWithReturnedObject() {
        Session s = openSession();
        Transaction tx = s.beginTransaction();
        A a = this.createA(s);
        B b = this.createB(s, a);
        C c = createC(s, b);
        Criteria criteria = this.createCriteria(s, true);
        try {
            List results = criteria.list();
            assertEquals("One object should have been returned", 1, results.size());
        } catch (NullPointerException npe) {
            throw npe; // I think the SubqueryExpression.params instance variable is null in getTypedValues() 
        } finally {
            s.delete(c);
            s.delete(b);
            s.delete(a);
            tx.commit();
            s.close();
        }
    }

    /**
     * Checks that no object is returned even if some <code>C</code> objects exist, ie that the aliases are properly propagated.
     */
    public void testWithNoReturnedObject() {
        Session s = openSession();
        Transaction tx = s.beginTransaction();
        A a = this.createA(s);
        B b = this.createB(s, a);
        B dummyB = this.createB(s, null);
        C c = this.createC(s, dummyB);
        Criteria criteria = this.createCriteria(s, true);
        try {
            List results = criteria.list();
            assertEquals("no object should have been returned", 0, results.size());
        } catch (NullPointerException npe) {
            throw npe; // I think the SubqueryExpression.params instance variable is null in getTypedValues()
        } finally {
            s.delete(c);
            s.delete(dummyB);
            s.delete(b);
            s.delete(a);
            tx.commit();
            s.close();
        }
    }

    /**
     * @param s
     * @param shouldCreateExecutableCriteria if <code>true</code>, forces a <code>getExecutableCriteria()</code> call on each <code>DetachedCriteria</code>.
     * @return
     */
    private Criteria createCriteria(Session s, boolean shouldCreateExecutableCriteria) {
        Criteria criteria = s.createCriteria(A.class, "alias0");
        // criteria.add(Restrictions.eq("label", A_LABEL));
        String alias0 = criteria.getAlias();
        DetachedCriteria detached1 = DetachedCriteria.forClass(B.class, "alias1");
        String alias1 = detached1.getAlias();
        detached1.add(Restrictions.eqProperty("a.id", alias0 + ".id"));
        detached1.setProjection(Projections.property("id"));
        if (shouldCreateExecutableCriteria)
            detached1.getExecutableCriteria(s);
        DetachedCriteria detached2 = DetachedCriteria.forClass(C.class, "alias2");
        detached2.add(Restrictions.eqProperty("b.id", alias1 + ".id"));
        detached2.setProjection(Projections.property("id"));
        if (shouldCreateExecutableCriteria)
            detached2.getExecutableCriteria(s);
        detached1.add(Subqueries.exists(detached2));
        criteria.add(Subqueries.exists(detached1));
        return criteria;
    }

    /**
     * @param s
     * @param b
     * @return
     */
    private C createC(Session s, B b) {
        C c = new C();
        c.setB(b);
        s.save(c);
        return c;
    }

    /**
     * @param s
     * @param a
     * @return
     */
    private B createB(Session s, A a) {
        B b = new B();
        b.setA(a);
        s.save(b);
        return b;
    }

    /**
     * @param s
     * @param aLabel
     * @return
     */
    private A createA(Session s) {
        A a = new A();
        s.save(a);
        return a;
    }

    private Session openSession() {
        Configuration cfg = new Configuration().configure().addClass(A.class).addClass(B.class).addClass(C.class);
        SessionFactory sessions = cfg.buildSessionFactory();
        Session session = sessions.openSession();
        return session;
    }
}