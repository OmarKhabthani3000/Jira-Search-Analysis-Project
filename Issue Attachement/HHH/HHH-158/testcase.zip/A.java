/*
 * Created on Feb 28, 2005
 */
package org.hibernate.test.subqueries;

import java.util.HashSet;
import java.util.Set;

/**
 * @author gg
 */
public class A {
    private Integer id;
    private Set bs;

    public void addB(B b) {
        this.getBs().add(b);
    }

    /**
     * @return Returns the id.
     */
    public Integer getId() {
        return this.id;
    }

    /**
     * @return Returns the bs.
     */
    public Set getBs() {
        if (this.bs == null)
            this.bs = new HashSet();
        return this.bs;
    }

    /**
     * @param bs The bs to set.
     */
    public void setBs(Set bs) {
        this.bs = bs;
    }

    /**
     * @param id The id to set.
     */
    public void setId(Integer id) {
        this.id = id;
    }
}