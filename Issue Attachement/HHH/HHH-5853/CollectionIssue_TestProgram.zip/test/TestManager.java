package test;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import org.hibernate.stat.Statistics;

import java.io.Serializable;
import java.sql.Statement;
import java.util.*;
import test.HibernateUtil;
import org.hibernate.criterion.*;
import org.hibernate.event.EventSource;
import org.hibernate.event.FlushEntityEvent;
import org.hibernate.type.*;
import org.hibernate.util.IdentityMap;
import org.hibernate.engine.*;

import com.mysql.jdbc.ResultSet;
public class TestManager {
	
	
	
	 public static void main(String[] args)
	   {
	           try{
	                   TestManager mgr = new TestManager();
	                   String opr = "get";
	                   if (opr.equals("add"))	                	 
	                   {
	                      mgr.addObject();	               
	                   }
	                   else
	                   {
	                	   mgr.getObject();
	                   
	                   }
	                   HibernateUtil.getSessionFactory().close();
	           }
	           catch(Exception e)
	           {
	                   System.err.println("EXCEPTION : "+e);
	                   e.printStackTrace();
	           }

	   }
	
	
	 
	 
	 
	   
	 	
	   private void addObject()
	   {
		 
          
           Session session = HibernateUtil.getSessionFactory().getCurrentSession();		
           session.beginTransaction();   
           Parent mo=new Parent();         
           mo.setName("test");          
           mo.setDisplayName("test");               
           mo.getMembers().add("members");          
	       session.save(mo);           
           session.getTransaction().commit();
        
           
	   }
	   
	   private Parent fetchOperation(Session session, String key )
	   {
		    Criteria criteria = session.createCriteria(test.Parent.class);
		    
	        criteria.add(Restrictions.naturalId().set("name", key));//No I18N
	        criteria.setCacheable(true);	       
	        criteria.setFetchMode("members", FetchMode.JOIN);	       
	        Parent obj=(Parent)criteria.uniqueResult();
	        if(obj!=null)
	        {
	        	obj.getMembers().size();
	        }
	        return obj;
	   }
	   
	   	private void  getObject()
	   	{
	   		
		      Session session = HibernateUtil.getSessionFactory().openSession();
			  session.beginTransaction();		  
			  Parent  obj2= (Parent)fetchOperation(session,"test");            
			  session.getTransaction().commit();	  
		
	        
       
		    
		  

	   }
	  

}
