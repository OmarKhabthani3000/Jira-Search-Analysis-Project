package test;
import org.hibernate.*;
import org.hibernate.type.*;
import java.lang.*;
import java.sql.Time;
import java.util.Iterator;
import java.util.Set;
import java.util.HashSet;
import java.util.List;
public class Parent 
{

	 private String name = "parent";
	 
	 public String getName()
	 {
	        return name;
	 }

	 public void setName(String name)
	 {
	        this.name = name;
	 }
	 private Long moid;
	 
	 public Long getMoid()
	 {
	       return this.moid;
	 }
	 private void setMoid(Long moid)
	 {
	       this.moid=moid;
	 }
	 
	 public String displayName ="";
	 
	 public void setDisplayName(String dName)
	 {
	       
		
		 this.displayName = dName;
	 }
	 
	  public String getDisplayName()
	  {
		
		  return displayName;
	  }
	  Set members=new HashSet();
	  public Set getMembers()
	  {
	
	    	return this.members;
	  }
	  
	  public void setMembers (Set<String> members1)
	  {	  
	    	this.members.size();
		  this.members = members1;    	
	  }

	
      
     
      private int version;

      /**
       * for internal use only.
       */

      public int getVersion()
      {
         return this.version;
      }
      /**
       * for internal use only.
       */
      private void setVersion(int version)
      {
         this.version=version;
      }
	  
}
