package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

/**
 * TODO Description
 *
 * @author hummich
 * @since 13/04/2018
 */
@Entity
@Table(name = "ADDRESSES")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "ADDRESS_TYPE", discriminatorType = DiscriminatorType.INTEGER)
public abstract class AbstractAddress {

    public static final int FOO_ADDRESS = 1;

    public static final int BAR_ADDRESS = 2;

    @Id
    @GeneratedValue
    private int id;

    @Column(name = "ADDRESS_TYPE", updatable = false, nullable = false, insertable = false)
    private int addressType;

    public int getId() {
        return this.id;
    }

    public int getAddressType() {
        return this.addressType;
    }

}
