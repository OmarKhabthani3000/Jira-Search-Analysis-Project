package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * TODO Description
 *
 * @author hummich
 * @since 13/04/2018
 */
@Entity
@DiscriminatorValue(value = "" + AbstractAddress.FOO_ADDRESS)
public class FooAddress extends AbstractAddress {

    @Column(name = "FOO")
    private String foo;

    public String getFoo() {
        return this.foo;
    }

    public void setFoo(final String foo) {
        this.foo = foo;
    }

}
