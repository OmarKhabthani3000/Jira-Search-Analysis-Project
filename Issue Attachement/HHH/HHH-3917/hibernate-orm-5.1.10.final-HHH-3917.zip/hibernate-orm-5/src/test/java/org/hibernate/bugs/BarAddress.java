package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * TODO Description
 *
 * @author hummich
 * @since 13/04/2018
 */
@Entity
@DiscriminatorValue(value = "" + AbstractAddress.BAR_ADDRESS)
public class BarAddress extends AbstractAddress {

    @Column(name = "BAR")
    private String bar;

    public String getBar() {
        return this.bar;
    }

    public void setBar(final String bar) {
        this.bar = bar;
    }

}
