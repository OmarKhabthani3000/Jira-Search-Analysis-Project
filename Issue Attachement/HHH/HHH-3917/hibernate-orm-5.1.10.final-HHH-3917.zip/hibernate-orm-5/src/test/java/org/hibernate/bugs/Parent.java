package org.hibernate.bugs;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * TODO Description
 *
 * @author hummich
 * @since 13/04/2018
 */
@Entity
@Table(name = "PARENTS")
public class Parent {

    @Id
    @GeneratedValue
    private int id;

    @Column(name = "ADDRESS_ID")
    private int addressId;

    @ManyToOne(fetch =  FetchType.LAZY)
    @JoinColumn(name = "ADDRESS_ID", updatable = false, insertable = false)
    @NotFound(action = NotFoundAction.IGNORE)
    private FooAddress fooAddress;

    @ManyToOne(fetch =  FetchType.LAZY)
    @JoinColumn(name = "ADDRESS_ID", updatable = false, insertable = false)
    @NotFound(action = NotFoundAction.IGNORE)
    private BarAddress barAddress;

    public int getId() {
        return this.id;
    }

    public int getAddressId() {
        return this.addressId;
    }

    public void setAddressId(final int addressId) {
        this.addressId = addressId;
    }

    public FooAddress getFooAddress() {
        return this.fooAddress;
    }

    public BarAddress getBarAddress() {
        return this.barAddress;
    }

}
