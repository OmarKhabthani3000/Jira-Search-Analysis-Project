package org.hibernate.bugs;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	private static final Logger LOG = LoggerFactory.getLogger(JPAUnitTestCase.class);

	@Before
	public void init() {
        this.entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
        this.entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh3917() throws Exception {
		EntityManager entityManager = this.entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		// Do stuff...

        final BarAddress address = new BarAddress();
        address.setBar("TEST - will have id=1");
        entityManager.persist(address);

        final Parent parent = new Parent();
        parent.setAddressId(address.getId());

        entityManager.persist(parent);
		entityManager.getTransaction().commit();
        entityManager.close();

		LOG.info("\n\n---------------- LOAD -----------------\n\n");
		entityManager = this.entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
		final Parent result = entityManager.find(Parent.class, parent.getId());
        entityManager.getTransaction().commit();
		entityManager.close();
	}
}
