package hibernate.bug.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.ElementCollection;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Person implements Serializable {

    private Long id;
    private Set<MyEmbeddable> elementCollection = new HashSet<MyEmbeddable>(0);
    
    public Person() {
    }

    @Id
    @GeneratedValue
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @ElementCollection
    public Set<MyEmbeddable> getElementCollection() {
        return elementCollection;
    }

    public void setElementCollection(Set<MyEmbeddable> elementCollection) {
        this.elementCollection = elementCollection;
    }
}
