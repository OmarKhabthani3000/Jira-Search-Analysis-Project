package hibernate.bug;

import hibernate.bug.model.Person;
import hibernate.bug.model.MyEmbeddable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Person p = new Person();
        p.getElementCollection().add(new MyEmbeddable("123"));
        
        em.persist(p);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void test() {
        EntityManager em = emf.createEntityManager();
        
        List<MyEmbeddable> l = em.createQuery(
                "SELECT e FROM Person p LEFT JOIN p.elementCollection e", MyEmbeddable.class)
                .getResultList();
        Assert.assertEquals(1, l.size());
        Assert.assertEquals("123", l.get(0).getName());
        
        em.close();
    }
}
