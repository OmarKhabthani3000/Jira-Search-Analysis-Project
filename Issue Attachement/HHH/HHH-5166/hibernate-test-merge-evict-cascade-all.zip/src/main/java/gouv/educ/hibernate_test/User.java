package gouv.educ.hibernate_test;

import java.util.Set;

/**
 * Entit� Utilisateur (User)
 * 
 * @author cmalosse (refonte)
 */
public class User implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private int id;
	private String login;
	private String nomUser;
	private String prenomUser;
	private String password;
	private String courriel;
	private Set<Role> roles;

	
    /**
     * Constructeur par d�faut
     */
	public User() {
		super();
	}
	
	public int getId() {
		return this.id;
	}

	public String getLogin() {
		return this.login;
	}

	public String getNomUser() {
		return this.nomUser;
	}

	public String getPrenomUser() {
		return this.prenomUser;
	}

	public String getPassword() {
		return this.password;
	}

	public String getCourriel() {
		return courriel;
	}

	public Set<Role> getRoles() {
		return this.roles;
	}

	

	public void setCourriel(String courriel) {
		this.courriel = courriel;
	}


	public void setLogin(String newValue) {
		this.login = newValue;
	}

	public void setNomUser(String newValue) {
		this.nomUser = newValue;
	}

	public void setId(int newValue) {
		this.id = newValue;
	}

	public void setPassword(String newValue) {
		this.password = newValue;
	}

	public void setPrenomUser(String newValue) {
		this.prenomUser = newValue;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof User){
			User u = (User) obj;
			return this.getLogin().equals(u.getLogin())
			&& this.getNomUser().equals(u.getNomUser())
			&& this.getPrenomUser().equals(u.getPrenomUser())
			&& this.getCourriel().equals(u.getCourriel())
			&& this.getPassword().equals(u.getPassword());
		}
		return false;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}


}
