/*
 * Created on 13 sept. 2005
 */
package gouv.educ.hibernate_test;


/**
 * Entit� Role
 * 
 * @author cmalosse (refonte)
 */
public class Role {

	private static final long serialVersionUID = 1L;
	
	private int id;
	private String typeRole;
	private String libelleRole;

    /**
     * Constructeur par d�faut
     */
	public Role() {
		super();
	}

	public Role(int id) {
		this.id = id;
	}

	public Role(int id, String typeRole, String libelleRole) {
		this.id = id;
		this.typeRole = typeRole;
		this.libelleRole = libelleRole;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTypeRole() {
		return this.typeRole;
	}

	public void setTypeRole(String typeRole) {
		this.typeRole = typeRole;
	}

	public String getLibelleRole() {
		return this.libelleRole;
	}

	public void setLibelleRole(String libelleRole) {
		this.libelleRole = libelleRole;
	}

}
