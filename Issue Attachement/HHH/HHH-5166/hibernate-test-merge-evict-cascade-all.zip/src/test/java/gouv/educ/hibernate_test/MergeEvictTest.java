package gouv.educ.hibernate_test;


import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.junit.functional.FunctionalTestCase;

/**
 * This Unit test reproduct a bug that appear when
 * I call the method evict on merged objects. Evict 
 * seems to leave the session in inconsistent state.
 * 
 * @author Alexandre FRADIN
 *
 */
public class MergeEvictTest extends FunctionalTestCase{
	
	private static Logger LOGGER = Logger.getLogger(MergeEvictTest.class); 

	
	public MergeEvictTest(String string) {
		super(string);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	protected void prepareTest() throws Exception {
		super.prepareTest();
		
		Session session =  openSession(); 
		session.getTransaction().begin();
		
		//clean up DB
		List<User> users = session.createCriteria(User.class).list();
		for(User u : users){
			session.delete(u);
		}
		// populate DB
		for (UserEnum u : UserEnum.values()) {
			session.persist(u.creerUser());
		}
		session.getTransaction().commit();
		session.close();
	}

	public void testEvictHibernate(){

		Session session =  openSession();
		
		try{
		
		session.getTransaction().begin();
		
		// create detached user
		Set<Role> newRoles = new HashSet<Role>();
		newRoles.add(RoleEnum.Role1.creerRole());
		User detachedUser = UserEnum.User1.creerUser();
		detachedUser.setPassword(UserEnum.User4.getPassword());
		detachedUser.setRoles(newRoles);
		
		// merge detached user
		session.load(User.class, detachedUser.getId());
		User persistentUser = (User) session.merge(User.class.toString(),detachedUser);
		Role rManaged = persistentUser.getRoles().iterator().next();
		assertTrue("Operation merge non appliqu�e en cascade",
				session.contains(rManaged));
		
		// evict persistent user 
		session.evict(persistentUser);
//		session.clear();//works with clear
		
		session.flush();
		
		assertFalse("Operation evict non appliqu�e en cascade",
				session.contains(rManaged));
		
		// search an other user
		session.get(User.class, UserEnum.User4.getId());// works if I comment this line
		
		//commit
		session.getTransaction().commit();
		}catch (Exception e) {
			fail(e.getMessage());
			LOGGER.error(e,e);
			session.getTransaction().rollback();
		}finally{
			session.close();
		}
		
	}

	public String[] getMappings() {
		return new String[]{"Role.hbm.xml","User.hbm.xml"};
	}
	
	@Override
	public String getBaseForMappings() {
		return "./";
	}
	
	
}
