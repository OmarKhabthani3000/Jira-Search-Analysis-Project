package gouv.educ.hibernate_test;


import java.util.HashSet;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.junit.functional.FunctionalTestCase;

/**
 * This Unit test reproduct a bug that appear when
 * I call the method evict on merged objects. Evict 
 * seems to leave the session in inconsistent state.
 * 
 * @author Alexandre FRADIN
 *
 */
public class MergeEvictTest extends FunctionalTestCase{
	
	private static Logger LOGGER = Logger.getLogger(MergeEvictTest.class); 

	
	public MergeEvictTest(String string) {
		super(string);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	protected void prepareTest() throws Exception {
		super.prepareTest();
		
		Session session =  openSession(); 
		session.getTransaction().begin();
		
		//clean up DB
		List<User> users = session.createCriteria(User.class).list();
		for(User u : users){
			session.delete(u);
		}
		// populate DB
		for (UserEnum u : UserEnum.values()) {
			session.persist(u.creerUser());
		}
		// add role1 to user1
		User u1 = (User) session.get(User.class, UserEnum.User1.getId());
		u1.setRoles(new HashSet<Role>());
		u1.getRoles().add(RoleEnum.Role1.creerRole());
		
		session.getTransaction().commit();
		session.close();
	}
	
	public void testEvictHibernateWithUpdateOnly(){

		Session session =  openSession();
		
		try{
		
		session.getTransaction().begin();
		
		//make sure to not flush update before instance validation
		FlushMode initialFlushMode = session.getFlushMode();
		session.setFlushMode(FlushMode.MANUAL);
		
		// create detached user
		User detachedUser = UserEnum.User1.creerUser();
		//modify user and role attributes => while trigger update operations
		detachedUser.setPassword(UserEnum.User4.getPassword());
		detachedUser.setRoles(new HashSet<Role>());
		Role role1 = RoleEnum.Role1.creerRole();
		role1.setLibelleRole(RoleEnum.Role2.getLibelleRole());
		detachedUser.getRoles().add(role1);
		
		// merge detached user
		session.load(User.class, detachedUser.getId());
		User persistentUser = (User) session.merge(User.class.toString(),detachedUser);
		
		// evict persistent user (in real life, only if this instance is not valide)
		session.evict(persistentUser);
		//		session.clear();//works with clear
		session.setFlushMode(initialFlushMode);
		// search an other user
		session.get(User.class, UserEnum.User4.getId());// works if I comment this line
		
		//commit
		session.getTransaction().commit();
		}catch (Exception e) {
			fail(e.getMessage());
			LOGGER.error(e,e);
			session.getTransaction().rollback();
		}finally{
			session.close();
		}
		
	}
	
	public void testEvictHibernateWithInsertUpdate(){

		Session session =  openSession();
		
		try{
		
		session.getTransaction().begin();
		
		//make sure to not flush update before instance validation
		FlushMode initialFlushMode = session.getFlushMode();
		session.setFlushMode(FlushMode.MANUAL);
		
		// create detached user
		User detachedUser = UserEnum.User1.creerUser();
		//modify user attribute => while trigger update operations
		detachedUser.setPassword(UserEnum.User4.getPassword());
		detachedUser.setRoles(new HashSet<Role>());
		detachedUser.getRoles().add(RoleEnum.Role1.creerRole());
		//add new role => while trigger insert operations
		detachedUser.getRoles().add(RoleEnum.Role2.creerRole());
		
		
		// merge detached user
		session.load(User.class, detachedUser.getId());
		User persistentUser = (User) session.merge(User.class.toString(),detachedUser);
		
		// evict persistent user (in real life, only if this instance is not valide)
		session.evict(persistentUser);
		//		session.clear();//works with clear
		session.setFlushMode(initialFlushMode);
		// search an other user
		session.get(User.class, UserEnum.User4.getId());// works if I comment this line
		
		//commit
		session.getTransaction().commit();
		}catch (Exception e) {
			fail(e.getMessage());
			LOGGER.error(e,e);
			session.getTransaction().rollback();
		}finally{
			session.close();
		}
		
	}
	

	public String[] getMappings() {
		return new String[]{"Role.hbm.xml","User.hbm.xml"};
	}
	
	@Override
	public String getBaseForMappings() {
		return "./";
	}
	
	
}
