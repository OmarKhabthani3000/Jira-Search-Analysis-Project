package gouv.educ.hibernate_test;

public enum UserEnum {
	User1(1, "Dupont", "Jean", "jean.dupont@yahoo.fr", "pass", "jdupont"), User2(
			2, "Lemaitre", "Yves", "ylemaitre@gmail.com", "maison",
			"ylemaitre"), User3(3, "Lemp", "Nicolas", "nlemp@gmail.com",
			"test", "mlemp"), User4(4, "Dubois", "Francois",
			"fdubois@msn.net", "rtey", "mdubois");

	private int id;

	private String nomUser;

	private String prenomUser;

	private String courriel;

	private String password;

	private String login;

	public String getNomUser() {
		return nomUser;
	}

	private UserEnum(int id, String nomUser, String prenomUser,
			String courriel, String password, String login) {
		this.id = id;
		this.nomUser = nomUser;
		this.prenomUser = prenomUser;
		this.courriel = courriel;
		this.password = password;
		this.login = login;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setNomUser(String nomUser) {
		this.nomUser = nomUser;
	}

	public String getPrenomUser() {
		return prenomUser;
	}

	public void setPrenomUser(String prenomUser) {
		this.prenomUser = prenomUser;
	}

	public String getCourriel() {
		return courriel;
	}

	public void setCourriel(String courriel) {
		this.courriel = courriel;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public User creerUser() {
		User user = new User();
		user.setId(id);
		user.setLogin(login);
		user.setPrenomUser(prenomUser);
		user.setNomUser(nomUser);
		user.setPassword(password);
		user.setCourriel(courriel);
		return user;
	}

}
