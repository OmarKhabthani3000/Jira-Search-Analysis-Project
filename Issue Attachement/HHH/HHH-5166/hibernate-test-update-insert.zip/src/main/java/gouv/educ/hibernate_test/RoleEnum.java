package gouv.educ.hibernate_test;

public enum RoleEnum {

	Role1(1,"DRH","MANAGER"),
	Role2(2,"Salari�","EMPLOYE");
	
	private int id;
	
	private String libelleRole;
	
	private String typeRole;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLibelleRole() {
		return libelleRole;
	}

	public void setLibelleRole(String libelleRole) {
		this.libelleRole = libelleRole;
	}

	public String getTypeRole() {
		return typeRole;
	}

	public void setTypeRole(String typeRole) {
		this.typeRole = typeRole;
	}

	private RoleEnum(int id, String libelleRole, String typeRole) {
		this.id = id;
		this.libelleRole = libelleRole;
		this.typeRole = typeRole;
	}
	
	public Role creerRole(){
		return new Role(id,libelleRole,typeRole);
	}
	
}
