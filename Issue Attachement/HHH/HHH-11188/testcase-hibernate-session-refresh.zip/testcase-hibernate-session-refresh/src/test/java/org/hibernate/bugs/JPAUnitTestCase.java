package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Session;
import org.hibernate.bugs.domain.Order;
import org.hibernate.testing.TestForIssue;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	@TestForIssue(jiraKey = "HHH-11188")
	public void hhh11188Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		entityManager.getMetamodel().getEntities();

		Order order = new Order();
		entityManager.persist(order);

		entityManager.getTransaction().commit();
		entityManager.close();

		entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		// TODO HHH-11188: Hibernate 5.2.X session.refresh now throws "entity not managed"
		refresh(entityManager, order);
		Assert.assertTrue("entity sould be managed", entityManager.contains(order));

		entityManager.getTransaction().commit();
		entityManager.close();
	}

	private void refresh(EntityManager entityManager, Order order) {
		if(entityManager.contains(order)) {
			entityManager.refresh(order);
		} else {
			// when not managed: refresh directly with the Hibernate Session
			((Session)entityManager.getDelegate()).refresh(order);
		}
	}
}
