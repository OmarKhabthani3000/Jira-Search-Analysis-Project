package com.example.entity;

import jdk.nashorn.internal.objects.annotations.Getter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;
import java.util.Optional;

@Entity
@Table(name = "SUB_SUB_TABLE")
@IdClass(SubSubEntity.SubSubEntityId.class)
public class SubSubEntity implements Serializable {

    @Id
    @Column(name = "ID_NUM", insertable = false, updatable = false)
    private Long idNum;

    @Id
    @Column(name = "CODE")
    private String code;

    @Id
    @Column(name = "IND_NUM", insertable = false, updatable = false)
    private String indNum;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns({
            @JoinColumn(name = "ID_NUM", referencedColumnName = "ID_NUM"),
            @JoinColumn(name = "IND_NUM", referencedColumnName = "IND_NUM")
    })
    @Id
    private SubEntity subEntity;

    public Long getIdNum() {
        return idNum;
    }

    public void setIdNum(Long idNum) {
        this.idNum = idNum;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getIndNum() {
        return indNum;
    }

    public void setIndNum(String indNum) {
        this.indNum = indNum;
    }

    public SubEntity getSubEntity() {
        return subEntity;
    }

    public void setSubEntity(SubEntity subEntity) {
        idNum = Optional.ofNullable(subEntity).map(SubEntity::getMainEntity).map(MainEntity::getIdNum).orElse(null);
        code = Optional.ofNullable(subEntity).map(SubEntity::getIndNum).orElse(null);
        this.subEntity = subEntity;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        SubSubEntity that = (SubSubEntity) o;
        return Objects.equals(idNum, that.idNum) &&
                Objects.equals(code, that.code) &&
                Objects.equals(indNum, that.indNum);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), idNum, code, indNum);
    }

    @Override
    public String toString() {
        return "SubSubEntity{" +
                "idNum=" + idNum +
                ", code='" + code + '\'' +
                ", indNum='" + indNum + '\'' +
                '}';
    }

    public static class SubSubEntityId implements Serializable {

        private Long idNum;

        private String code;

        private String indNum;

        public Long getIdNum() {
            return idNum;
        }

        public void setIdNum(Long idNum) {
            this.idNum = idNum;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getIndNum() {
            return indNum;
        }

        public void setIndNum(String indNum) {
            this.indNum = indNum;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            SubSubEntityId that = (SubSubEntityId) o;
            return Objects.equals(idNum, that.idNum) &&
                    Objects.equals(code, that.code) &&
                    Objects.equals(indNum, that.indNum);
        }

        @Override
        public int hashCode() {

            return Objects.hash(idNum, code, indNum);
        }
    }


}
