package com.example.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "SUB_TABLE")
public class SubEntity implements Serializable {

    @Id
    @Column(name = "SUB_ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "subIdNumSequence")
    @SequenceGenerator(name = "subIdNumSequence", sequenceName = "SEQ_SUB_ID", allocationSize = 1)
    private Long subIdNum;

    @Column(name = "IND_NUM")
    private String indNum;

    @Column(name = "FAMILY_IDENTIFIER")
    private String familyIdentifier;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_NUM")
    private MainEntity mainEntity;

    @OneToMany(mappedBy = "subEntity", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SubSubEntity> subSubEntities = new ArrayList<>();

    @OneToMany(mappedBy = "subEntity", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AnotherSubSubEntity> anotherSubSubEntities = new ArrayList<>();

    public Long getSubIdNum() {
        return subIdNum;
    }

    public void setSubIdNum(Long subIdNum) {
        this.subIdNum = subIdNum;
    }

    public String getIndNum() {
        return indNum;
    }

    public void setIndNum(String indNum) {
        this.indNum = indNum;
    }

    public String getFamilyIdentifier() {
        return familyIdentifier;
    }

    public void setFamilyIdentifier(String familyIdentifier) {
        this.familyIdentifier = familyIdentifier;
    }

    public MainEntity getMainEntity() {
        return mainEntity;
    }

    public void setMainEntity(MainEntity mainEntity) {
        this.mainEntity = mainEntity;
    }

    public List<SubSubEntity> getSubSubEntities() {
        return subSubEntities;
    }

    public void setSubSubEntities(List<SubSubEntity> subSubEntities) {
        this.subSubEntities = subSubEntities;
    }

    public List<AnotherSubSubEntity> getAnotherSubSubEntities() {
        return anotherSubSubEntities;
    }

    public void setAnotherSubSubEntities(List<AnotherSubSubEntity> anotherSubSubEntities) {
        this.anotherSubSubEntities = anotherSubSubEntities;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        SubEntity subEntity = (SubEntity) o;
        return Objects.equals(subIdNum, subEntity.subIdNum);
    }

    @Override
    public int hashCode() {

        return Objects.hash(super.hashCode(), subIdNum);
    }

    @Override
    public String toString() {
        return "SubEntity{" +
                "subIdNum=" + subIdNum +
                ", indNum='" + indNum + '\'' +
                ", familyIdentifier='" + familyIdentifier + '\'' +
                ", subSubEntities=" + subSubEntities +
                ", anotherSubSubEntities=" + anotherSubSubEntities +
                '}';
    }
}
