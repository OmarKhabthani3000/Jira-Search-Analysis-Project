package com.example.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;
import java.util.Optional;

@Entity
@Table(name = "ANOTHER_SUB_SUB_TABLE")
@IdClass(AnotherSubSubEntity.AnotherSubSubEntityId.class)
public class AnotherSubSubEntity implements Serializable {

    @Id
    @Column(name = "ID_NUM", insertable = false, updatable = false)
    private Long idNum;

    @Id
    @Column(name = "PERSON", insertable = false, updatable = false)
    private String person;

    @Id
    @Column(name = "SOURCE_CODE")
    private String sourceCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns({
            @JoinColumn(name = "ID_NUM", referencedColumnName = "ID_NUM", insertable = false, updatable = false),
            @JoinColumn(name = "PERSON", referencedColumnName = "FAMILY_IDENTIFIER", insertable = false, updatable = false)
    })
    @Id
    private SubEntity subEntity;

    public Long getIdNum() {
        return idNum;
    }

    public void setIdNum(Long idNum) {
        this.idNum = idNum;
    }

    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person;
    }

    public String getSourceCode() {
        return sourceCode;
    }

    public void setSourceCode(String sourceCode) {
        this.sourceCode = sourceCode;
    }

    public SubEntity getSubEntity() {
        return subEntity;
    }

    public void setSubEntity(SubEntity subEntity) {
        idNum = Optional.ofNullable(subEntity).map(SubEntity::getMainEntity).map(MainEntity::getIdNum).orElse(null);
        person = Optional.ofNullable(subEntity).map(SubEntity::getFamilyIdentifier).orElse(null);
        this.subEntity = subEntity;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AnotherSubSubEntity that = (AnotherSubSubEntity) o;
        return Objects.equals(idNum, that.idNum) &&
                Objects.equals(person, that.person) &&
                Objects.equals(sourceCode, that.sourceCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idNum, person, sourceCode);
    }

    @Override
    public String toString() {
        return "AnotherSubSubEntity{" +
                "idNum=" + idNum +
                ", person='" + person + '\'' +
                ", sourceCode='" + sourceCode + '\'' +
                '}';
    }

    public static class AnotherSubSubEntityId implements Serializable {

        private Long idNum;

        private String person;

        private String sourceCode;

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            AnotherSubSubEntityId that = (AnotherSubSubEntityId) o;
            return Objects.equals(idNum, that.idNum) &&
                    Objects.equals(person, that.person) &&
                    Objects.equals(sourceCode, that.sourceCode);
        }

        @Override
        public int hashCode() {
            return Objects.hash(idNum, person, sourceCode);
        }

        public Long getIdNum() {
            return idNum;
        }

        public void setIdNum(Long idNum) {
            this.idNum = idNum;
        }

        public String getPerson() {
            return person;
        }

        public void setPerson(String person) {
            this.person = person;
        }

        public String getSourceCode() {
            return sourceCode;
        }

        public void setSourceCode(String sourceCode) {
            this.sourceCode = sourceCode;
        }
    }

}

