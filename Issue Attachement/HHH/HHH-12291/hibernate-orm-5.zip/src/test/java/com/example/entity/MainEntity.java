package com.example.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "MAIN_TABLE")
public class MainEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "idNum")
    @SequenceGenerator(name = "idNum", sequenceName = "id_num", allocationSize = 1)
    @Column(name="ID_NUM")
    private Long idNum;

    @OneToMany(mappedBy = "mainEntity", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SubEntity> subEntities = new ArrayList<>();

    public void addSubEntity(SubEntity subEntity) {
        subEntity.setMainEntity(this);
        subEntities.add(subEntity);
    }

    public void removeSubEntity(SubEntity subEntity) {
        subEntity.setMainEntity(null);
        subEntities.remove(subEntity);
    }

    public Long getIdNum() {
        return idNum;
    }

    public void setIdNum(Long idNum) {
        this.idNum = idNum;
    }

    public List<SubEntity> getSubEntities() {
        return subEntities;
    }

    public void setSubEntities(List<SubEntity> subEntities) {
        this.subEntities = subEntities;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        MainEntity that = (MainEntity) o;
        return Objects.equals(idNum, that.idNum);
    }

    @Override
    public int hashCode() {

        return Objects.hash(super.hashCode(), idNum);
    }
}
