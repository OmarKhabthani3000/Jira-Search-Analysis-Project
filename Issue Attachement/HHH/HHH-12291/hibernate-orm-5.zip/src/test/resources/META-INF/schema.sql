create table MAIN_TABLE (ID_NUM bigint not null, primary key (ID_NUM));
create table SUB_TABLE (SUB_ID bigint not null, FAMILY_IDENTIFIER varchar(255), IND_NUM varchar(255), ID_NUM bigint, primary key (SUB_ID));
create table SUB_SUB_TABLE (CODE varchar(255) not null,ID_NUM bigint not null,IND_NUM varchar(255) not null,primary key (CODE, ID_NUM, IND_NUM));
create table ANOTHER_SUB_SUB_TABLE (ID_NUM bigint not null,PERSON varchar(255) not null,SOURCE_CODE varchar(255) not null,primary key (ID_NUM, PERSON, SOURCE_CODE));
alter table SUB_TABLE ADD CONSTRAINT FK_SUB_TABLE_1 FOREIGN KEY (ID_NUM) REFERENCES MAIN_TABLE (ID_NUM);
alter table ANOTHER_SUB_SUB_TABLE ADD CONSTRAINT FK_ASST_1 FOREIGN KEY (ID_NUM) REFERENCES MAIN_TABLE (ID_NUM);