package test;

public class Local {

}
