package test;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class TestCase {
	
	public static void main(String[] args) {

		SessionFactory sessionFactory;
		try {
            sessionFactory = new Configuration().configure().buildSessionFactory();
        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }

		Session session = sessionFactory.openSession();
		
		Criteria criteria;
		
		criteria = session.createCriteria(test.Locale.class);
		criteria.list();
		
		// whoops, wrong import
		criteria = session.createCriteria(java.util.Locale.class);
		criteria.list();
		// whoops, wrong class
		criteria = session.createCriteria(test.Local.class);
		criteria.list();
		System.err.println("Err I shouldn't be able to query an unmapped classed");
	}
}
