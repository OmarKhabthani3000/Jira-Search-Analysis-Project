/**
 * 
 */
package nl.apg.poc.locking;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.LockModeType;
import javax.persistence.OptimisticLockException;
import javax.persistence.Persistence;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author ed10041
 * 
 */
public class LockingTest {

    private EntityManagerFactory factory;

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
        factory = Persistence.createEntityManagerFactory("default");
        Thread.sleep(500);
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
        if (factory != null) {
            factory.close();
        }
        Thread.sleep(500);
    }

    /**
     * Test locking: change the parent object concurrently in the same thread. This should result in an optimistic lock exception.
     * 
     * @throws Throwable
     *             OptimisticLockException expected
     */
    @Test(expected = OptimisticLockException.class)
    public void testChangingSameParentConcurrently() throws Throwable {
        final long parentId = createTestData(1);

        final EntityManager em1 = factory.createEntityManager();
        final EntityManager em2 = factory.createEntityManager();

        em1.getTransaction().begin();
        em2.getTransaction().begin();

        final Parent parent1 = findParent(em1, parentId);
        final Parent parent2 = findParent(em2, parentId);

        parent1.setName("NewName1");
        parent2.setName("NewName2");

        updateParent(em1, parent1);
        updateParent(em2, parent2);

        commitWithExpectedRollback(em1, em2);
    }

    /**
     * Test locking: changing the parent and child in two separate transactions. The parent change is committed first.
     * 
     * @throws Throwable
     *             OptimisticLockException expected
     */
    @Test(expected = OptimisticLockException.class)
    public void testChangingParentAndChildInSeparateTransactionsParentFirst() throws Throwable {
        final long parentId = createTestData(1);

        final EntityManager em1 = factory.createEntityManager();
        final EntityManager em2 = factory.createEntityManager();

        em1.getTransaction().begin();
        em2.getTransaction().begin();

        final Parent parent1 = findParent(em1, parentId);
        final Parent parent2 = findParent(em2, parentId);

        parent1.setName("NewName1");
        final Child child2 = parent2.getChildren().iterator().next();
        child2.setName("NewChild2");

        updateParent(em1, parent1);
        updateParent(em2, parent2);

        commitWithExpectedRollback(em1, em2);
    }

    /**
     * Test locking: changing the parent and child in two separate transactions. The child change is committed first.
     * 
     * @throws Throwable
     *             OptimisticLockException expected
     */
    @Test(expected = OptimisticLockException.class)
    public void testChangingParentAndChildInSeparateTransactionsChildFirst() throws Throwable {
        final long parentId = createTestData(1);

        final EntityManager em1 = factory.createEntityManager();
        final EntityManager em2 = factory.createEntityManager();

        em1.getTransaction().begin();
        em2.getTransaction().begin();

        final Parent parent1 = findParent(em1, parentId);
        final Parent parent2 = findParent(em2, parentId);

        final Child child1 = parent1.getChildren().iterator().next();
        child1.setName("NewChild2");
        parent2.setName("NewName1");

        updateParent(em1, parent1);
        updateParent(em2, parent2);

        commitWithExpectedRollback(em1, em2);
    }

    /**
     * Test locking: changing the parent and child in two separate transactions. The child addition is committed first.
     * 
     * @throws Throwable
     *             OptimisticLockException expected
     */
    @Test(expected = OptimisticLockException.class)
    public void testChangingParentAndAddNewChildInSeparateTransactionsChildFirst() throws Throwable {
        final long parentId = createTestData(1);

        final EntityManager em1 = factory.createEntityManager();
        final EntityManager em2 = factory.createEntityManager();

        em1.getTransaction().begin();
        em2.getTransaction().begin();

        final Parent parent1 = findParent(em1, parentId);
        final Parent parent2 = findParent(em2, parentId);

        final Child child1 = parent1.addChild();
        child1.setName("NewChild2");
        parent2.setName("NewName1");

        updateParent(em1, parent1);
        updateParent(em2, parent2);

        commitWithExpectedRollback(em1, em2);
    }

    /**
     * Test locking: changing the parent and child in two separate transactions. The parent change is committed first.
     * 
     * @throws Throwable
     *             OptimisticLockException expected
     */
    @Test(expected = OptimisticLockException.class)
    public void testChangingParentAndAddNewChildInSeparateTransactionsParentFirst() throws Throwable {
        final long parentId = createTestData(1);

        final EntityManager em1 = factory.createEntityManager();
        final EntityManager em2 = factory.createEntityManager();

        em1.getTransaction().begin();
        em2.getTransaction().begin();

        final Parent parent1 = findParent(em1, parentId);
        final Parent parent2 = findParent(em2, parentId);

        parent1.setName("NewName1");
        final Child child1 = parent2.addChild();
        child1.setName("NewChild2");

        updateParent(em1, parent1);
        updateParent(em2, parent2);

        commitWithExpectedRollback(em1, em2);
    }

    /**
     * Test locking: add children in two separate transactions.
     * 
     * @throws Throwable
     *             OptimisticLockException expected
     */
    @Test(expected = OptimisticLockException.class)
    public void testAddTwoNewChildrenInSeparateTransactions() throws Throwable {
        final long parentId = createTestData(1);

        final EntityManager em1 = factory.createEntityManager();
        final EntityManager em2 = factory.createEntityManager();

        em1.getTransaction().begin();
        em2.getTransaction().begin();

        final Parent parent1 = findParent(em1, parentId);
        final Parent parent2 = findParent(em2, parentId);

        final Child child1 = parent1.addChild();
        child1.setName("NewChild1");
        final Child child2 = parent2.addChild();
        child2.setName("NewChild2");

        updateParent(em1, parent1);
        updateParent(em2, parent2);

        commitWithExpectedRollback(em1, em2);
    }

    /**
     * Test locking: updating a child object which was removed in another thread. This should result in an OptimisticLockException
     * as the child belongs to the aggregate and the aggregate was modified in the first transaction.
     * 
     * @throws Throwable
     *             OptimisticLockException expected
     */
    @Test(expected = OptimisticLockException.class)
    public void testChangingRemovedChild() throws Throwable {
        final long parentId = createTestData(1);

        final EntityManager em1 = factory.createEntityManager();
        final EntityManager em2 = factory.createEntityManager();

        em1.getTransaction().begin();
        em2.getTransaction().begin();

        final Parent parent1 = findParent(em1, parentId);
        final Parent parent2 = findParent(em2, parentId);

        final Child child1 = parent1.getChildren().iterator().next();
        parent1.removeChild(child1);

        final Child child2 = parent2.getChildren().iterator().next();
        child2.setName("NewChild2");

        updateParent(em1, parent1);
        updateParent(em2, parent2);

        commitWithExpectedRollback(em1, em2);
    }

    /**
     * Test locking: Update a parent after removal
     * 
     * @throws Throwable
     *             OptimisticLockException expected
     */
    @Test(expected = OptimisticLockException.class)
    public void testUpdateParentAfterRemoval() throws Throwable {
        final long parentId = createTestData(1);

        final EntityManager em1 = factory.createEntityManager();
        final EntityManager em2 = factory.createEntityManager();

        em1.getTransaction().begin();
        em2.getTransaction().begin();

        final Parent parent1 = findParent(em1, parentId);
        final Parent parent2 = findParent(em2, parentId);

        parent2.setName("NewName1");

        removeParent(em1, parent1);
        updateParent(em2, parent2);

        commitWithExpectedRollback(em1, em2);
    }

    /**
     * Test locking: Remove parent after updating.
     * 
     * @throws Throwable
     *             OptimisticLockException expected
     */
    @Test(expected = OptimisticLockException.class)
    public void testUpdateParentBeforeRemoval() throws Throwable {
        final long parentId = createTestData(1);

        final EntityManager em1 = factory.createEntityManager();
        final EntityManager em2 = factory.createEntityManager();

        em1.getTransaction().begin();
        em2.getTransaction().begin();

        final Parent parent1 = findParent(em1, parentId);
        final Parent parent2 = findParent(em2, parentId);

        parent1.setName("NewName1");

        updateParent(em1, parent1);
        removeParent(em2, parent2);

        commitWithExpectedRollback(em1, em2);
    }

    // TODO http://www.avaje.org/occ.html --> Transaction isolation level.
    // http://sahits.ch/blog/blog/2013/01/10/transaction-isolation-with-spring-and-hibernate/

    /**
     * Test locking: Parent 1 is modified in the first transaction. Parent 2 is the second, although the second transaction also uses Parent
     * 1. This should result in an OptimisticLockingException. Intermediate changes to read only objects are considered a locking error.
     * 
     * @throws Throwable
     *             OptimisticLockException expected
     */
    @Test(expected = OptimisticLockException.class)
    public void testCommitWithNoChangesOnEntityChangedInOtherTransaction() throws Throwable {
        final long parentId1 = createTestData(1);
        final long parentId2 = createTestData(2);

        final EntityManager em1 = factory.createEntityManager();
        final EntityManager em2 = factory.createEntityManager();

        em1.getTransaction().begin();
        em2.getTransaction().begin();

        final Parent parent11 = findParent(em1, parentId1);
        final Parent parent21 = findParent(em2, parentId1);
        final Parent parent22 = findParent(em2, parentId2);

        parent11.setName("NewName1");
        parent21.getName(); // Only a readonly operation.
        parent22.setName("NewName2");

        updateParent(em1, parent11);
        updateParent(em2, parent22);

        commitWithExpectedRollback(em1, em2);
    }

    /**
     * Test locking: Parent 1 is modified in the first transaction. Parent 2 is the second, although the second transaction also uses Parent
     * 1. Parent 1 is modified with the original value (should result in no database action) being set. This should result in an
     * OptimisticLockingException. Intermediate changes to read only objects are considered a locking error.
     * 
     * @throws Throwable
     *             OptimisticLockException expected
     */
    @Test(expected = OptimisticLockException.class)
    public void testCommitWithSameValueChangeOnEntityChangedInOtherTransaction() throws Throwable {
        final long parentId1 = createTestData(1);
        final long parentId2 = createTestData(2);

        final EntityManager em1 = factory.createEntityManager();
        final EntityManager em2 = factory.createEntityManager();

        em1.getTransaction().begin();
        em2.getTransaction().begin();

        final Parent parent11 = findParent(em1, parentId1);
        final Parent parent21 = findParent(em2, parentId1);
        final Parent parent22 = findParent(em2, parentId2);

        parent11.setName("NewName1");
        parent21.setName(parent21.getName());
        parent22.setName("NewName2");

        updateParent(em1, parent11);
        updateParent(em2, parent21);
        updateParent(em2, parent22);

        commitWithExpectedRollback(em1, em2);
    }

    /**
     * Test locking: Parent 2 is modified in the second transaction. Parent1 is used in both. This should not result in an
     * OptimisticLockingException.
     * Intermediate changes to read only objects are disregarded.
     */
    @Test
    public void testCommitWithNoChangesOnEntityOtherChangedInOtherTransaction() {
        final long parentId1 = createTestData(1);
        final long parentId2 = createTestData(2);

        final EntityManager em1 = factory.createEntityManager();
        final EntityManager em2 = factory.createEntityManager();

        em1.getTransaction().begin();
        em2.getTransaction().begin();

        final Parent parent11 = findParent(em1, parentId1);
        final Parent parent21 = findParent(em2, parentId1);
        final Parent parent22 = findParent(em2, parentId2);

        parent11.getName(); // Only a readonly operation.
        parent21.getName(); // Only a readonly operation.
        parent22.setName("NewName2");

        updateParent(em2, parent22);

        em1.getTransaction().commit();
        em2.getTransaction().commit();

        em1.close();
        em2.close();
    }

    @Test
    public void testRemoveWithReadLocking() {
        final long parentId1 = createTestData(1);
        final long parentId2 = createTestData(2);
        final long parentId3 = createTestData(3);
        final long parentId4 = createTestData(4);

        final EntityManager em1 = factory.createEntityManager();

        em1.getTransaction().begin();

        final TypedQuery<Parent> query = em1.createQuery("select p from Parent p", Parent.class);
        query.setLockMode(LockModeType.OPTIMISTIC);

        for (final Parent parent : query.getResultList()) {
            em1.remove(parent);
        }

        em1.getTransaction().commit();
        em1.close();
    }

    /**
     * Find a parent by ID.
     * 
     * @param em
     *            The entity manager
     * @param parentId
     *            Primary key id of parent (from {@link #createTestData(int)}.
     * @return The found parent.
     */
    private Parent findParent(final EntityManager em, final long parentId) {
        final Parent parent = em.find(Parent.class, parentId);
        em.lock(parent, LockModeType.OPTIMISTIC);
        return parent.toDomain();
    }

    private void removeParent(final EntityManager em, final Parent parent) {
        final Parent attached = em.merge(parent);
        em.remove(attached);
    }

    private void updateParent(final EntityManager em, final Parent parent) {
        final long oldVersion = parent.getVersion();
        final Parent attached = em.merge(parent);
        // TODO: This behaviour is needed to simulate the @OptmisticLock(cascade=true) behaviour of EclipseLink in Hibernate.
        if (attached.getVersion() == oldVersion) {
            attached.incrementVersion();
        }
    }

    private void commitWithExpectedRollback(final EntityManager em1, final EntityManager em2) throws Throwable {
        em1.flush();
        em1.getTransaction().commit();
        try {
            em2.flush();
            em2.getTransaction().commit();
        } catch (final RollbackException e) {
            throw e.getCause();
        } finally {
            em1.close();
            em2.close();
        }
    }

    private long createTestData(final int idx) {
        final EntityManager em = factory.createEntityManager();

        final Parent parent = new Parent();
        parent.setName("parent" + idx);
        final Child child1 = parent.addChild();
        child1.setName("child1");
        final Child child2 = parent.addChild();
        child2.setName("child2");

        em.getTransaction().begin();

        em.persist(parent);
        em.flush();

        em.getTransaction().commit();

        em.close();

        return parent.getId();
    }

}
