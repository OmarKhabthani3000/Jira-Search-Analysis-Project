/**
 * 
 */
package nl.apg.poc.locking;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Version;

/**
 * @author ed10041
 * 
 */
@Entity
public class Child {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Version
    private long version;

    private String name;

    @ManyToOne
    private Parent parent;

    Child() {

    }

    public Child(final Parent parent) {
        this.parent = parent;
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name
     *            the name to set
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * @return the parent
     */
    public Parent getParent() {
        return parent;
    }

    /**
     * @param parent
     * @return
     */
    public Child toDomain(final Parent parent) {
        final Child child = new Child(parent);
        child.id = this.id;
        child.name = this.name;
        child.version = this.version;
        return child;
    }

    /**
     * @return the version
     */
    public long getVersion() {
        return version;
    }

}
