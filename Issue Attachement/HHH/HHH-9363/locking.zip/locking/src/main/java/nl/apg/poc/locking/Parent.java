/**
 * 
 */
package nl.apg.poc.locking;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Version;

import org.eclipse.persistence.annotations.OptimisticLocking;
import org.eclipse.persistence.annotations.PrivateOwned;

/**
 * @author ed10041
 * 
 */
@Entity
@OptimisticLocking(cascade = true)
public class Parent {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Version
    private Long version;

    private String name;

    @OneToMany(mappedBy = "parent", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @PrivateOwned
    private final Set<Child> children = new HashSet<Child>();

    /**
     * 
     */
    public Parent() {
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name
     *            the name to set
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * @return the children
     */
    public Set<Child> getChildren() {
        return children;
    }

    /**
     * @return
     */
    public Child addChild() {
        final Child child = new Child(this);
        children.add(child);
        return child;
    }

    /**
     * @param child
     */
    public void removeChild(final Child child) {
        children.remove(child);
    }

    public Parent toDomain() {
        final Parent parent = new Parent();
        parent.id = this.id;
        parent.name = this.name;
        parent.version = this.version;
        for (final Child child : children) {
            parent.children.add(child.toDomain(parent));
        }
        return parent;
    }

    /**
     * @return the version
     */
    public long getVersion() {
        return version;
    }

    public void incrementVersion() {
        version++;
    }

}
