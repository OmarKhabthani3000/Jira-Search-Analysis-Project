-- application_configurations

CREATE TABLE application_configurations (id BIGSERIAL NOT NULL PRIMARY KEY);