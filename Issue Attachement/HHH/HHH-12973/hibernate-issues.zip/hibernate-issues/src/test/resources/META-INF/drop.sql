-- application_configurations

DROP TABLE IF EXISTS application_configurations CASCADE;
