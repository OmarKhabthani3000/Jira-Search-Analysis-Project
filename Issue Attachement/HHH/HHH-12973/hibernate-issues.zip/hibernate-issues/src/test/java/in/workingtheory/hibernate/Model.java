package in.workingtheory.hibernate;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.persistence.*;

@Entity
@Table(name = "application_configurations")
public class Model
{
	private static final Logger logger = LogManager.getLogger(Model.class);

	@Id
	@Column(name = "id")
	@SequenceGenerator(name = "application_configurations_id_seq", sequenceName = "application_configurations_id_seq", initialValue = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_configurations_id_seq")
	private Long id;

	public Long getId()
	{
		return id;
	}

	public void setId(final Long id)
	{
		this.id = id;
	}
}
