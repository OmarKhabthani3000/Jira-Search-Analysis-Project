package in.workingtheory.hibernate;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.jpa.HibernatePersistenceProvider;
import org.junit.jupiter.api.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import java.util.Collections;

public class SequenceGeneratorTest
{
	private static final Logger logger = LogManager.getLogger(SequenceGeneratorTest.class);

	@Test
	void testSequenceGenerator()
	{
		// Creating persistence provider
		final HibernatePersistenceProvider persistenceProvider = new HibernatePersistenceProvider();

		// Creating entity manager factory
		final EntityManagerFactory entityManagerFactory = persistenceProvider.createEntityManagerFactory("Mastering-Hibernate", Collections.emptyMap());
		final EntityManager entityManager = entityManagerFactory.createEntityManager();

		for (int i = 0; i < 5; i++)
		{
			final Model model = new Model();

			entityManager.persist(model);

			logger.info("Generated Id : {}", model.getId());
		}

	}
}
