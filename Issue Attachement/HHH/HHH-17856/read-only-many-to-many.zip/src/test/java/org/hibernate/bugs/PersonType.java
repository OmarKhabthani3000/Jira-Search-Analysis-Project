package org.hibernate.bugs;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "PERSON_TYPE")
public class PersonType {
    @GeneratedValue
    @Id
    private Long id;

    @Column(name = "NAME")
    private String name;

    @ManyToMany
    @JoinTable(name = "PERSON_TYPE_CHANGE",
            joinColumns = {@JoinColumn(name = "SOURCE_PERSON_TYPE_ID")},
            inverseJoinColumns = {@JoinColumn(name = "TARGET_PERSON_TYPE_ID")})
    private List<PersonType> personTypes = new ArrayList<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<PersonType> getPersonTypes() {
        return personTypes;
    }

    public void setPersonTypes(List<PersonType> personTypes) {
        this.personTypes = personTypes;
    }
}
