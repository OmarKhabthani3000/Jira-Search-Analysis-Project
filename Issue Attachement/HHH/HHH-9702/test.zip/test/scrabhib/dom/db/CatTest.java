/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package scrabhib.dom.db;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 *
 * @author Zielu
 */
public class CatTest {
    
    public CatTest() {
    }
    

    
    @Test
    public void testSomeMethod2() {
        SessionFactory emf = new Configuration().configure().buildSessionFactory();
        Session em = emf.openSession();
        
        
        Cat cat = new Cat();
        Item item = new Item();
        cat.items.add(item);
        
        em.beginTransaction();
        em.save(cat);
        em.getTransaction().commit();
        em.close();

        assertTrue(true);
         
    }
}
