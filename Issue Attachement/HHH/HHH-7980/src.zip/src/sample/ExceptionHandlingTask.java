package sample;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import javax.sql.DataSource;
import javax.transaction.TransactionManager;

/**
 * @author shahamit
 */

public class ExceptionHandlingTask {

    public static void main(String[] args) {
        ApplicationContext appContext =
                new ClassPathXmlApplicationContext("sample/conf/spring.xml");

        DataSource dataSource = appContext.getBean("dataSource", DataSource.class);
        final JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

        TransactionTemplate template = new TransactionTemplate(
                appContext.getBean("transactionManager", PlatformTransactionManager.class));

        template.execute(new TransactionCallbackWithoutResult() {

            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {
                jdbcTemplate.execute("select * from t1");
            }
        });

    }
}
