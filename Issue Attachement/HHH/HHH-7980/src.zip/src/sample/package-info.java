@GenericGenerator(name = "uid-generator",
        strategy = "sequence-identity",
        parameters = @Parameter(name = "sequence", value = PersistenceService.UID_SEQUENCE_NAME))
package sample;

import com.spmsoftware.appframework.persistence.PersistenceService;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;