package org.hibernate.test.subclassbagofsibling;


public class BaseDocument {
    protected DocumentKey documentKey;
	protected int groupId;

    public BaseDocument() {
    }
	public BaseDocument(DocumentKey documentKey, int groupId) {
		this.documentKey = documentKey;
		this.groupId = groupId;
	}    
    public DocumentKey getDocumentKey() {
        return documentKey;
    }
    public void setDocumentKey(DocumentKey documentKey) {
        this.documentKey = documentKey;
    }
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

}
