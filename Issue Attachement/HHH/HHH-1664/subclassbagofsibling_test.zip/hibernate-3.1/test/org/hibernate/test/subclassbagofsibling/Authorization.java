package org.hibernate.test.subclassbagofsibling;

public class Authorization extends BaseDocument {
	
	public Authorization(DocumentKey documentKey, int groupId) {
		super(documentKey, groupId);
	}

    protected Authorization() {}   
}
