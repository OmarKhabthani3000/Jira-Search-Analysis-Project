package org.hibernate.test.subclassbagofsibling;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.TestCase;

public class HibTest extends TestCase {

	public HibTest(String x) {
		super(x);
	}

	protected boolean recreateSchema() {
		return true;
	}

	protected String[] getMappings() {
		return new String[] { "subclassbagofsibling/BaseDocument.hbm.xml" };
	}

	public void testFoo() {
		Session s = openSession();
		Transaction t = s.beginTransaction();

		int groupId = 1;
		int id = 1;
		Authorization auth1 = new Authorization(new DocumentKey("A" + (id++),
				"A", "AUTH"), groupId);
		Authorization auth2 = new Authorization(new DocumentKey("A" + (id++),
				"A", "AUTH"), groupId);
		Authorization auth3 = new Authorization(new DocumentKey("A" + (id++),
				"A", "AUTH"), groupId);

		DocumentKey vchKey = new DocumentKey("A", "A", "VCH");
		Voucher v1 = new Voucher(vchKey, groupId);
		v1.addAuthorization(auth1);
		v1.addAuthorization(auth2);
		v1.addAuthorization(auth3);
		s.persist(v1);
		t.commit();
		s.close();

		s = openSession();
		t = s.beginTransaction();
		v1 = (Voucher) s.load(Voucher.class, vchKey);
		assertNotNull(v1);
		List authorizations = v1.getAuthorizations();
		assertNotNull(authorizations);
		assertEquals(3, authorizations.size());
		System.out.println("auths: " + authorizations);
		t.commit();
		s.close();
		
		// Verify that an empty collection also works
		s = openSession();
		t = s.beginTransaction();
		groupId = 2;
		vchKey = new DocumentKey("A"+(id++), "A", "VCH");
		v1 = new Voucher(vchKey, groupId);
		s.persist(v1);
		t.commit();
		s.close();
		
		s = openSession();
		t = s.beginTransaction();
		v1 = (Voucher) s.load(Voucher.class, vchKey);
		assertNotNull(v1);
		authorizations = v1.getAuthorizations();
		assertNotNull(authorizations);
		assertEquals(0, authorizations.size());
		System.out.println("auths: " + authorizations);
		t.commit();
		s.close();
	}

}
