package org.hibernate.test.subclassbagofsibling;

import java.util.ArrayList;
import java.util.List;


public class Voucher extends BaseDocument {
	
	private List authorizations = new ArrayList();
	
    public Voucher(DocumentKey documentKey, int groupId) {
		super(documentKey, groupId);
	}

    public Voucher() {}

	public List getAuthorizations() {
		return authorizations;
	}

	public void setAuthorizations(List authorizations) {
		this.authorizations = authorizations;
	}
    
	public void addAuthorization(Authorization a) {
		authorizations.add(a);
	}
    
}
