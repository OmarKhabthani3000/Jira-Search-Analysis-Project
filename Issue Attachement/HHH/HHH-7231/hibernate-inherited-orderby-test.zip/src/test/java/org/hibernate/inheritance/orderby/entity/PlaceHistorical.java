package org.hibernate.inheritance.orderby.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name="PLACE_HIST")
@Inheritance(strategy=InheritanceType.JOINED)
public abstract class PlaceHistorical {
	    
	@Id
	@Column(name="HIST_PLACE_ID")
	private Long id;
	
	@Column(name="HIST_PLACE_NAME")
	private String name;
	
	@Column(name="HIST_COUNT")
	private Long historyCount;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getHistoryCount() {
		return historyCount;
	}

	public void setHistoryCount(Long historyCount) {
		this.historyCount = historyCount;
	}

	
	
}