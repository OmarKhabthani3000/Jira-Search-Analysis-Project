package org.hibernate.inheritance.orderby.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="LOCALITY_HIST")
@PrimaryKeyJoinColumn(name="HIST_PLACE_ID", referencedColumnName="HIST_PLACE_ID")
public class LocalityHistorical extends PlaceHistorical {

	@ManyToOne(optional=false)
	@JoinColumn(name="PLACE_ID")
	private Locality locality;
	
	@Column(name="LOCALITY_MAYOR")
	private String mayor;

	public Locality getLocality() {
		return locality;
	}

	public void setLocality(Locality locality) {
		this.locality = locality;
	}

	public String getMayor() {
		return mayor;
	}

	public void setMayor(String mayor) {
		this.mayor = mayor;
	}

}
