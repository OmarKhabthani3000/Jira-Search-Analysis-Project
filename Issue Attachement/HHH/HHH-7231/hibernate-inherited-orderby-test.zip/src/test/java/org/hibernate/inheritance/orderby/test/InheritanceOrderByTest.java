package org.hibernate.inheritance.orderby.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.Hibernate;
import org.hibernate.inheritance.orderby.entity.Locality;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class InheritanceOrderByTest {

	private EntityManagerFactory emf;
	private EntityManager em;
	
	@Before
	public void setUp() throws Exception {
		this.emf = Persistence.createEntityManagerFactory("LocalityTest");
		this.em = emf.createEntityManager();
	}

	@After
	public void tearDown() throws Exception {
		if (this.em != null) {
			this.em.close();
		}
		if (this.emf != null) {
			this.emf.close();
		}
	}
	
	@Test
	public void inheritanceOrderByTest() {
		
		//Create locality object
		
		Long localityId = 1L;
		
    	Locality locality = new Locality();
    	locality.setId(localityId);
    	locality.setName("London");
    	locality.setMayor("London Major");
		
		EntityTransaction tx = null;
		try {
			//Create transaction
		    tx = em.getTransaction();
		    tx.begin();
	    	    	
	    	//Persist entity and
			em.persist(locality);

			//Commit transaction
		    tx.commit();
		    								    		    
		} catch (RuntimeException e) {
		    if ( tx != null && tx.isActive() ) tx.rollback();
		    throw e; // or display error message
		}
		
		//clear entitymanager before loading
		em.clear();
		
		//Retrieve object from database
		locality = em.find(Locality.class, localityId);
		
		//Initialize proxy of field history
		//ERROR HAPPENS HERE!!!! CHECK GENERATED SQL
		Hibernate.initialize(locality.getHistory());
		
	}
	
}
