package org.hibernate.inheritance.orderby.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="LOCALITY")
@PrimaryKeyJoinColumn(name="PLACE_ID", referencedColumnName="PLACE_ID")
public class Locality extends Place {
	
	@Column(name="LOCALITY_MAYOR")
	private String mayor;

	@OneToMany(mappedBy="locality")
	@OrderBy("historyCount")
	private Set<LocalityHistorical> history;

	public String getMayor() {
		return mayor;
	}

	public void setMayor(String mayor) {
		this.mayor = mayor;
	}

	public Set<LocalityHistorical> getHistory() {
		return history;
	}

	public void setHistory(Set<LocalityHistorical> history) {
		this.history = history;
	}
	
}
