//$Id: DynamicComponentTest,v 1.1 2005/02/07 03:02:50 oneovthafew Exp $
package org.hibernate.test.dynamiccomponent;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.test.TestCase;

/**
 * @author <a href=mailto:daniel.seiler@truesolutions.ch>Daniel Seiler</a>
 */
public class DynamicComponentTest extends TestCase {
	
	public DynamicComponentTest(String str) {
		super(str);
	}
	
	public void testDynamicComponentTest() {
		// creating and saving the artifact
		Session s = openSession();
		Transaction t = s.beginTransaction();
		Artifact artifact = new Artifact();
		Property p = new Property();
		p.setName("name");
		p.setValue("Daniel Seiler");
		artifact.setProperty(p);
		GroupList gl = new GroupList();
		gl.setName("address");
		Property p2 = new Property();
		p2.setName("homeaddress");
		p2.setValue("Switzerland");
		Group group = new Group();
		group.setProperty(p2);
		group.setParent(artifact);
		List l = new ArrayList();
		l.add(group);
		gl.setGroups(l);
		artifact.setGroupList(gl);
		s.saveOrUpdate("ARTIFACT1",artifact);
		t.commit();
		s.close();
		// retrieving the artifact		
		s = openSession();
		t = s.beginTransaction();
		artifact = (Artifact) s.get("ARTIFACT1",new Long(1));
		// now the groupLists map should contain a GroupList object with the key address
		// in that GroupList object there should be one Group entry that contains one
		// property 'homeaddress' with the value 'Switzerland'
		assertNotNull(artifact.getGroupLists());
		t.commit();
		s.close();
	}
	
	protected String[] getMappings() {
		return new String[] { "dynamiccomponent/Artifact.hbm.xml" };
	}

	public static Test suite() {
		return new TestSuite(DynamicComponentTest.class);
	}

}

