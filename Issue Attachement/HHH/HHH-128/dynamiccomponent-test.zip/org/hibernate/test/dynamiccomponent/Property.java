package org.hibernate.test.dynamiccomponent;

/**
 * @author <a href=mailto:daniel.seiler@truesolutions.ch>Daniel Seiler</a>
 *
 */
public class Property {
	
	private String name;
	private Object value;

	public Property() {}
		
	
	public Object getValue() {
		return value;
	}
	
	public void setValue(Object value) {
		this.value = value;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
}
