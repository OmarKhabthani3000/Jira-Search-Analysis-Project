package org.hibernate.test.dynamiccomponent;

import java.util.ArrayList;
import java.util.List;

/**
 * @author <a href=mailto:daniel.seiler@truesolutions.ch>Daniel Seiler</a>
 *
 */
public class GroupList {

	private List groups = new ArrayList();
	private String name;

	GroupList() {
		super();
	}

	public List getGroups() {
		return groups;
	}
	
	public void setGroups(List groups) {
		this.groups = groups;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
}
