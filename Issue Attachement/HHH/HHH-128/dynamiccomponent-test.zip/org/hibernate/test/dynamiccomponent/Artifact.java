package org.hibernate.test.dynamiccomponent;

/**
 * @author <a href=mailto:daniel.seiler@truesolutions.ch>Daniel Seiler</a>
 *
 */
public class Artifact extends Group {

	public Artifact(){}
	
}
