package org.hibernate.test.dynamiccomponent;

import java.util.HashMap;
import java.util.Map;

/**
 * @author <a href=mailto:daniel.seiler@truesolutions.ch>Daniel Seiler</a>
 *
 */
public class Group {

	private Map properties = new HashMap();
	private Map groupLists = new HashMap();
	private Long id;
	private Group parent;
	
	public Group() {}
	
	public Map getProperties() {
		return properties;
	}
	
	public Property getProperty(String name) {
		return (Property)properties.get(name);
	}
	
	public void setProperty(Property p) {
		properties.put(p.getName(),p);
	}

	public Map getGroupLists() {
		return groupLists;
	}

	public GroupList getGroupList(String name) {
		return (GroupList)groupLists.get(name);
	}
	
	public void setGroupList(GroupList gl) {
		groupLists.put(gl.getName(),gl);
	}

	public void setProperties(Map properties) {
		this.properties = properties;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
		
	public void setGroupLists(Map groupLists) {
		this.groupLists = groupLists;
	}
	
	
	public Group getParent() {
		return parent;
	}
	public void setParent(Group parent) {
		this.parent = parent;
	}
}
