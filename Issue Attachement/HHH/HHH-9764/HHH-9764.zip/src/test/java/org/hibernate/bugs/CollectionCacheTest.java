package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.cfg.Configuration;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;


/**
 * CollectionCacheTest - Test to check Collection Cache
 *
 * @author Vlad Mihalcea
 */
public class CollectionCacheTest extends ORMUnitTestCase {

    @Override
    protected Class<?>[] getAnnotatedClasses() {
        return new Class<?>[] {
                Repository.class,
                Commit.class
        };
    }

    @Override
    protected void configure(Configuration configuration) {
        super.configure( configuration );
		configuration.setProperty("hibernate.cache.use_second_level_cache", Boolean.TRUE.toString());
		configuration.setProperty("hibernate.cache.region.factory_class", "org.hibernate.cache.ehcache.EhCacheRegionFactory");
    }

    @Test
    public void hhh_9764() {
        Session session = null;
        Transaction txn = null;
        try {
            session = openSession();
            txn = session.beginTransaction();

            Repository repository = new Repository("Hibernate-Master-Class");
            repository.setId(1L);
            session.save(repository);

            Commit commit1 = new Commit();
            commit1.setId(1L);
            commit1.getChanges().add(new Change("README.txt", "0a1,5..."));
            commit1.getChanges().add(new Change("web.xml", "17c17..."));

            Commit commit2 = new Commit();
            commit2.setId(2L);
            commit2.getChanges().add(new Change("README.txt", "0b2,5..."));

            repository.addCommit(commit1);
            repository.addCommit(commit2);

            txn.commit();
        } catch (RuntimeException e) {
            if ( txn != null && txn.isActive() ) txn.rollback();
            throw e;
        } finally {
            if (session != null) {
                session.close();
            }
        }

        sessionFactory().getCache().evictCollectionRegions();

        Session s1 = null;
        Transaction tx1 = null;
        try {
            s1 = openSession();
            tx1 = s1.beginTransaction();

            Repository r1 = (Repository) s1.get(Repository.class, 1L);
            Commit c1 = (Commit) s1.get(Commit.class, 1L);

            Session s2 = null;
            Transaction tx2 = null;
            try {
                s2 = openSession();
                tx2 = s2.beginTransaction();

                Commit c2 = (Commit) s2.get(Commit.class, 1L);
                c2.setReview(true);

                tx2.commit();
            } catch (RuntimeException e) {
                if ( tx2 != null && tx2.isActive() ) tx2.rollback();
                throw e;
            } finally {
                if (s2 != null) {
                    s2.close();
                }
            }

            int size = r1.getCommits().size();
            assertEquals(2, size);

            tx1.commit();
        } catch (RuntimeException e) {
            if ( tx1 != null && tx1.isActive() ) tx1.rollback();
            throw e;
        } finally {
            if (s1 != null) {
                s1.close();
            }
        }
    }

    /**
     * Repository - Repository
     *
     * @author Vlad Mihalcea
     */
    @Entity(name = "Repository")
    @org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    public static class Repository {

        @Id
        private Long id;

        private String name;

        @org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
        @OneToMany(mappedBy = "repository", cascade = CascadeType.ALL, orphanRemoval = true)
        private List<Commit> commits = new ArrayList<Commit>();

        public Repository() {
        }

        public Repository(Long id) {
            this.id = id;
        }

        public Repository(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public List<Commit> getCommits() {
            return commits;
        }

        public void addCommit(Commit commit) {
            commits.add(commit);
            commit.setRepository(this);
        }

        public void removeCommit(Commit commit) {
            commits.remove(commit);
            commit.setRepository(null);
        }
    }

    /**
     * Commit - Commit
     *
     * @author Vlad Mihalcea
     */
    @Entity(name = "Commit")
    @Table(name = "commit")
    @org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    public static class Commit {

        @Id
        private Long id;

        private boolean review;

        @ManyToOne(fetch = FetchType.LAZY)
        private Repository repository;

        @Version
        private int version;

        @ElementCollection
        @CollectionTable(
                name="commit_change",
                joinColumns=@JoinColumn(name="commit_id")
        )
        @org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
        @OrderColumn(name = "index_id")
        private List<Change> changes = new ArrayList<Change>();

        public Commit() {
        }

        public Commit(Long id) {
            this.id = id;
        }

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public boolean isReview() {
            return review;
        }

        public void setReview(boolean review) {
            this.review = review;
        }

        public Repository getRepository() {
            return repository;
        }

        public void setRepository(Repository repository) {
            this.repository = repository;
        }

        public List<Change> getChanges() {
            return changes;
        }
    }

    /**
     * Change - Change
     *
     * @author Vlad Mihalcea
     */
    @Embeddable
    public static class Change {

        @Column(name = "path", nullable = false)
        private String path;

        @Column(name = "diff", nullable = false)
        private String diff;

        public Change() {
        }

        public Change(String path, String diff) {
            this.path = path;
            this.diff = diff;
        }

        public String getPath() {
            return path;
        }

        public String getDiff() {
            return diff;
        }
    }
}
