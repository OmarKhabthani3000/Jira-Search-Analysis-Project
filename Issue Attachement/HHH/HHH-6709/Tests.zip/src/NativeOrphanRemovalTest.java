
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Equivalent of JPAOrphanRemovalTest, but using Hibernate's native
 * API instead of JPA.
 */
public class NativeOrphanRemovalTest
{
	private SessionFactory sf;
	private int parentId;
	
	@Before
	public void setUp()
	{
		// set up Hibernate
		sf = new Configuration().configure().buildSessionFactory();
		
		Session session = sf.openSession();
		session.beginTransaction();

		// relate and persist one parent and one child entity
		
		Parent parent = new Parent();
		Child child = new Child();
		child.setParent(parent);
		parent.getChildren().add(child);
		session.save(child);
		session.save(parent);
		parentId = parent.getId();
		
		session.getTransaction().commit();
		
		// verify entities have been persisted
		
		assertEquals(1, session.createQuery("FROM Parent").list().size());
		assertEquals(1, session.createQuery("FROM Child").list().size());
		
		session.close();
	}
	
	@Test
	public void testDisconnectRelationship()
	{
		Session session = sf.openSession();
		session.beginTransaction();
		
		// disconnect entity relationship
		
		Parent parent = (Parent)session.get(Parent.class, parentId);
		parent.getChildren().get(0).setParent(null);
		parent.getChildren().clear();
		
		session.getTransaction().commit();
		
		// verify that no orphans remain in db
		assertTrue(session.createQuery("FROM Child").list().isEmpty());
		
		session.close();
	}
	
	@Test
	public void testRemoveEntity()
	{
		Session session = sf.openSession();
		session.beginTransaction();
		
		// remove parent entity
		
		Parent parent = (Parent)session.get(Parent.class, parentId);
		session.delete(parent);
		
		// verify that no orphans remain in db
		assertTrue(session.createQuery("FROM Child").list().isEmpty());
		
		session.close();
	}
	
	@After
	public void tearDown()
	{
		sf.close();
	}
}
