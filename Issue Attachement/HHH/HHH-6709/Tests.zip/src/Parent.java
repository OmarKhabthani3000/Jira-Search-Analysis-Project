
import java.util.*;
import javax.persistence.*;

@Entity
public class Parent
{
	@Id
	@GeneratedValue
	private int id;

	@OneToMany(mappedBy="parent", orphanRemoval=true)
	private List<Child> children = new LinkedList<Child>();

	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public List<Child> getChildren() {
		return children;
	}
	
	public void setChildren(List<Child> children) {
		this.children = children;
	}
	
	@Override
	public boolean equals(Object obj) {
		return id == ((Parent)obj).id;
	}
	
	@Override
	public int hashCode() {
		return id;
	}
}