
import static org.junit.Assert.*;
import javax.persistence.*;
import org.junit.*;

/**
 * Simple orphan removal test.
 */
public class JPAOrphanRemovalTest
{
	private EntityManagerFactory emf;
	private int parentId;
	
	@Before
	public void setUp()
	{
		// set up JPA
		emf = Persistence.createEntityManagerFactory("TestPersistenceUnit");
		
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();

		// relate and persist one parent and one child entity
		
		Parent parent = new Parent();
		Child child = new Child();
		child.setParent(parent);
		parent.getChildren().add(child);
		em.persist(child);
		em.persist(parent);
		parentId = parent.getId();
		
		em.getTransaction().commit();
		
		// verify entities have been persisted
		
		assertEquals(1, em.createQuery("SELECT p FROM Parent p").getResultList().size());
		assertEquals(1, em.createQuery("SELECT c FROM Child c").getResultList().size());
	}
	
	@Test
	public void testDisconnectRelationship()
	{
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		// disconnect entity relationship
		
		Parent parent = em.find(Parent.class, parentId);
		parent.getChildren().get(0).setParent(null);
		parent.getChildren().clear();
		
		em.getTransaction().commit();
		
		// verify that no orphans remain in db
		assertTrue(em.createQuery("SELECT c FROM Child c").getResultList().isEmpty());
	}
	
	@Test
	public void testRemoveEntity()
	{
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		// remove parent entity
		
		Parent parent = em.find(Parent.class, parentId);
		em.remove(parent);
		
		// verify that no orphans remain in db
		assertTrue(em.createQuery("SELECT c FROM Child c").getResultList().isEmpty());
	}
	
	@After
	public void tearDown()
	{
		emf.close();
	}
}
