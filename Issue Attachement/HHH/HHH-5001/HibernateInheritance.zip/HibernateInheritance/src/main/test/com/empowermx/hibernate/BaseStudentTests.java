/*
 * Created on Mar 10, 2010
 * $Id$
 *
 * Copyright (c) 2006 by EmpowerMX. All Rights Reserved.
 */
package com.empowermx.hibernate;

/**
 * Declare methods shared by all Student tests
 * 
 * @author matt.accola
 * @version $Revision$ $Date$
 */
public class BaseStudentTests extends BasePersonTests
{

    protected final String addLazyPersonAddr()
    {
        return addAddr(new LazyStudentImpl());
    }

    protected final String addAddr(final Person person)
    {
        final Addr addr = new Addr();
        addr.setPerson(person);
        final String addrId = (String) getHibernateTemplate().save(addr);
        getHibernateTemplate().flush();
        getHibernateTemplate().clear();
        return addrId;
    }

    protected final String addStudentWithStudentFather()
    {
        final LazyStudentImpl student = new LazyStudentImpl();
        final LazyStudentImpl father = new LazyStudentImpl();
        student.setFather(father);
        father.getChildren().add(student);
        final String studentId = (String) getHibernateTemplate().save(student);
        getHibernateTemplate().flush();
        getHibernateTemplate().clear();
        return studentId;
    }

}
