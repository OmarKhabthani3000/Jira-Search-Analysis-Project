/*
 * Created on Jan 16, 2008
 * $Id: Test_Hibernate_TaskCardExecution.java,v 1.4 2010/02/24 16:33:24 dhruva.nagalla Exp $
 *
 * Copyright (c) 2006 by EmpowerMX. All Rights Reserved.
 */
package com.empowermx.hibernate;

import org.springframework.orm.hibernate3.HibernateTemplate;

/**
 * Test handling of {@link LazyStudentImpl} objects via different loading
 * strategies (find, get, iterate, load)
 * 
 * @author rajesh.vunnam
 */
public class Test_Hibernate_Student extends BaseStudentTests
{

    /**
     * Load using {@link HibernateTemplate#find(String, Object)} by use of super
     * class LazyPersonImpl and try to do different operations.
     */
    public void test_HibernateFind_Superclass()
    {
        final String studentId = addStudentWithStudentFather();
        final String queryString = "from LazyPersonImpl where id = ?";
        final Person person = (Person) getHibernateTemplate().find(queryString, studentId).get(0);

        typeCheckStudent(person);
    }

    /**
     * Load using {@link HibernateTemplate#get(Class, java.io.Serializable)} by
     * use of super class LazyPersonImpl and try to do different operations.
     */
    public void test_HibernateGet_Superclass()
    {
        final String studentId = addStudentWithStudentFather();
        final Person person = (Person) getHibernateTemplate().get(LazyPersonImpl.class, studentId);

        typeCheckStudent(person);
    }

    /**
     * Load using {@link HibernateTemplate#iterate(String, Object)} by use of
     * super class LazyPersonImpl and try to do different operations.
     */
    public void test_HibernateIterate_Superclass()
    {
        final String studentId = addStudentWithStudentFather();
        final String queryString = "from LazyPersonImpl where id = ?";
        final Person person = (Person) getHibernateTemplate().iterate(queryString, studentId).next();

        typeCheckStudent(person);
    }

    /**
     * Load using {@link HibernateTemplate#load(Class, java.io.Serializable)} by
     * use of super class LazyPersonImpl and try to do different operations.
     */
    public void test_HibernateLoad_Superclass()
    {
        final String studentId = addStudentWithStudentFather();

        final Person person = (Person) getHibernateTemplate().load(LazyPersonImpl.class, studentId);

        typeCheckStudent(person);
    }

}
