/*
 * Created on Mar 10, 2010
 * $Id$
 *
 * Copyright (c) 2006 by EmpowerMX. All Rights Reserved.
 */
package com.empowermx.hibernate;

/**
 * Test handling of {@link LazyStudentImpl} objects via mapped associations
 * 
 * @author matt.accola
 * @version $Revision$ $Date$
 */
public class Test_Hibernate_Student_Associations extends BaseStudentTests
{

    /**
     * Access an object of type {@link LazyStudentImpl} via ManyToOne (with
     * targetEntity set to superclass) association and try to do different
     * operations.
     */
    public void test_ManyToOne()
    {
        final String studentId = addStudentWithStudentFather();
        final Person person = (Person) getHibernateTemplate().load(LazyPersonImpl.class, studentId);

        final Person father = person.getFather();

        /* In this case the original father object is LazyStudentImpl */
        typeCheckStudent(father);
    }

    /**
     * Access an object of type {@link LazyStudentImpl} via OneToMany (with
     * targetEntity set to superclass) association and try to do different
     * operations.
     */
    public void test_OneToMany()
    {
        final String studentId = addStudentWithStudentFather();
        final Person person = (Person) getHibernateTemplate().load(LazyPersonImpl.class, studentId);

        for (final Person child : person.getChildren())
        {
            System.out.println(child);

            if (child instanceof Student)
            {
                typeCheckStudent(child);
            }
            if (child instanceof Lecturer)
            {
                typeCheckLecturer(child);
            }
            if (child instanceof Lecturer)
            {
                typeCheckPrincipal(child);
            }
        }
    }

    /**
     * Access an object of type {@link LazyStudentImpl} via OneToOne (with
     * targetEntity set to superclass) association and try to do different
     * operations.
     */
    public void test_OneToOne()
    {
        final String addrid = addLazyPersonAddr();
        final Addr addr = (Addr) getHibernateTemplate().load(Addr.class, addrid);
        final Person person = addr.getPerson();

        /* In this case the original person object is LazyStudentImpl */
        typeCheckStudent(person);
    }

}
