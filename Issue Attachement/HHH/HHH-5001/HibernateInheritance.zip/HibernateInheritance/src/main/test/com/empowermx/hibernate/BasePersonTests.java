/*
 * Created on Mar 10, 2010
 * $Id$
 *
 * Copyright (c) 2006 by EmpowerMX. All Rights Reserved.
 */
package com.empowermx.hibernate;

import java.util.HashSet;
import java.util.Set;

import junit.framework.AssertionFailedError;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Declare methods shared by all Person tests
 * 
 * @author matt.accola
 * @version $Revision$ $Date$
 */
public class BasePersonTests extends BaseTests
{
    private final Log log = LogFactory.getLog(this.getClass());

    protected final void typeCheckLecturer(final Person person)
    {
        /* Check for Proper Types */
        if (log.isDebugEnabled())
        {
            final StringBuilder b = new StringBuilder("Implemented interface: ");
            for (final Class i : person.getClass().getInterfaces())
            {
                b.append("\n\t" + i.getName());
            }
            log.debug(b.toString());
        }
        assertTrue(person.getClass().getName(), person instanceof Lecturer);
        @SuppressWarnings("unused")
        final Lecturer student = (Lecturer) person;

        /* Check for Improper Type Lazy false */
        try
        {
            // Will throw exception here
            @SuppressWarnings("unused")
            final Student lecturer = (Student) person;
            fail("was able to cast to wrong type");
        } catch (final ClassCastException cc)
        {
            System.err.println("ClassCastException when downcasting to Student: " + cc.getMessage());
        }
        assertFalse("instanceof true for wrong type", person instanceof Student);
        assertFalse("instanceof true for wrong type", Student.class.isAssignableFrom(person.getClass()));

        try
        {
            // Will throw exception here
            @SuppressWarnings("unused")
            final Principal principal = (Principal) person;
            fail("was able to cast to wrong type: " + Principal.class.getSimpleName());
        } catch (final ClassCastException cc)
        {
            System.err.println("ClassCastException when downcasting to Principal: " + cc.getMessage());
        }
        assertFalse("instanceof true for wrong type: " + Principal.class.getSimpleName(), Principal.class
                .isAssignableFrom(person.getClass()));

        /* Method Invocation From Proper Interfaces */
        ((Lecturer) person).getSalary();

        /* Method Invocation on Improper Interface: Lecturer */
        try
        {
            ((Student) person).getMarks();
            fail("was able to cast to wrong type and invoke method: " + Lecturer.class.getSimpleName());
        } catch (final ClassCastException cc)
        {
            System.err.println("ClassCastException when invoking method on Lecturer: " + cc.getMessage());
        }

        /* Method Invocation on Improper Interface: Principal */
        try
        {
            ((Principal) person).getPrincipalCertificateNumber();
            fail("was able to cast to wrong type and invoke method: " + Principal.class.getSimpleName());
        } catch (final ClassCastException cc)
        {
            System.err.println("ClassCastException when invoking method on Principal: " + cc.getMessage());
        }
    }

    protected final void typeCheckPrincipal(final Person person)
    {
        // TODO add method impl
    }

    protected final void typeCheckStudent(final Person person)
    {
        /* Check for Proper Types */
        assertTrue(person instanceof Student);
        @SuppressWarnings("unused")
        final Student student = (Student) person;

        /* Check for Improper Type Lazy false */
        try
        {
            // Will throw exception here
            @SuppressWarnings("unused")
            final Lecturer lecturer = (Lecturer) person;
            fail("was able to cast to wrong type");
        } catch (final ClassCastException cc)
        {
            System.err.println("ClassCastException when downcasting to Lecturer: " + cc.getMessage());
        }
        assertFalse("instanceof true for wrong type", person instanceof Lecturer);
        assertFalse("instanceof true for wrong type", Lecturer.class.isAssignableFrom(person.getClass()));

        final Set<AssertionFailedError> exceptions = new HashSet<AssertionFailedError>();
        /* Check for Improper Types Lazy true */
        try
        {
            // Will throw exception here
            @SuppressWarnings("unused")
            final Principal principal = (Principal) person;
            fail("was able to cast to wrong type: " + Principal.class.getSimpleName());
        } catch (final ClassCastException cc)
        {
            System.err.println("ClassCastException when downcasting to Principal: " + cc.getMessage());
        } catch (final AssertionFailedError e)
        {
            exceptions.add(e);
        }
        try
        {
            assertFalse("instanceof true for wrong type: " + Principal.class.getSimpleName(), Principal.class
                    .isAssignableFrom(person.getClass()));
        } catch (final AssertionFailedError e1)
        {
            exceptions.add(e1);
        }

        /* Method Invocation From Proper Interfaces */
        ((Student) person).getMarks();

        /* Method Invocation on Improper Interface: Lecturer */
        try
        {
            ((Lecturer) person).getSalary();
            fail("was able to cast to wrong type and invoke method: " + Lecturer.class.getSimpleName());
        } catch (final ClassCastException cc)
        {
            System.err.println("ClassCastException when invoking method on Lecturer: " + cc.getMessage());
        }

        /* Method Invocation on Improper Interface: Principal */
        try
        {
            ((Principal) person).getPrincipalCertificateNumber();
            fail("was able to cast to wrong type and invoke method: " + Principal.class.getSimpleName());
        } catch (final ClassCastException cc)
        {
            System.err.println("ClassCastException when invoking method on Principal: " + cc.getMessage());
        }

        failOnAssertionErrors(exceptions);
    }

    private void failOnAssertionErrors(final Set<AssertionFailedError> exceptions)
    {
        assertTrue("Queued assertion failures found: " + exceptions.toString(), exceptions.isEmpty());
    }

}
