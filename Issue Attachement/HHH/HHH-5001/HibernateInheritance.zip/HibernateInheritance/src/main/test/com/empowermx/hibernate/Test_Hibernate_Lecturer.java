/**
 * 
 */
package com.empowermx.hibernate;

import org.springframework.orm.hibernate3.HibernateTemplate;

/**
 * Test handling of {@link EagerLecturerImpl} objects via different loading
 * strategies (find, get, iterate, load)
 * 
 * @author rajesh.vunnam
 */
public class Test_Hibernate_Lecturer extends BasePersonTests
{

    /**
     * Load using {@link HibernateTemplate#find(String, Object)} by use of super
     * class LazyPersonImpl and try to do different operations.
     */
    public void test_HibernateFind_Superclass()
    {
        final String lecturerId = addLecturer();
        final String queryString = "from LazyPersonImpl where id = ?";
        final Person person = (Person) getHibernateTemplate().find(queryString, lecturerId).get(0);

        typeCheckLecturer(person);
    }

    /**
     * Load using {@link HibernateTemplate#get(Class, java.io.Serializable)} by
     * use of super class LazyPersonImpl and try to do different operations.
     */
    public void test_HiberNateGet_Superclass()
    {
        final String lecturerId = addLecturer();
        final Person person = (Person) getHibernateTemplate().get(LazyPersonImpl.class, lecturerId);

        typeCheckLecturer(person);
    }

    /**
     * Load using {@link HibernateTemplate#iterate(String, Object)} by use of
     * super class LazyPersonImpl and try to do different operations.
     */
    public void test_HibernateIterate_Superclass()
    {
        final String lecturerId = addLecturer();
        final String queryString = "from LazyPersonImpl where id = ?";
        final Person person = (Person) getHibernateTemplate().iterate(queryString, lecturerId).next();

        typeCheckLecturer(person);
    }

    /**
     * Load using {@link HibernateTemplate#load(Class, java.io.Serializable)} by
     * use of super class LazyPersonImpl and try to do different operations.
     */
    public void test_HibernateLoad_Superclass()
    {
        final String lecturerId = addLecturer();
        final Person person = (Person) getHibernateTemplate().load(LazyPersonImpl.class, lecturerId);

        typeCheckLecturer(person);
    }

    private String addLecturer()
    {
        final EagerLecturerImpl lecturer = new EagerLecturerImpl();
        final String lecturerId = (String) getHibernateTemplate().save(lecturer);
        getHibernateTemplate().flush();
        getHibernateTemplate().clear();
        return lecturerId;
    }
}
