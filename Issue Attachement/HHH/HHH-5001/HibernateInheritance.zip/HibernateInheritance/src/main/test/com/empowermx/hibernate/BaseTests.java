/*
 * Created on Mar 7, 2010
 * $Id$
 *
 * Copyright (c) 2006 by EmpowerMX. All Rights Reserved.
 */
package com.empowermx.hibernate;

import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.test.AbstractTransactionalDataSourceSpringContextTests;

/**
 * Load the Spring {@link ApplicationContext} and inject
 * {@link HibernateTemplate}
 * 
 * @author matt.accola
 * @version $Revision$ $Date$
 */
public class BaseTests extends AbstractTransactionalDataSourceSpringContextTests
{
    private HibernateTemplate hibernateTemplate;

    @Override
    protected String[] getConfigLocations()
    {
        return new String[]{"/applicationContext.xml", "/applicationContext-hibernate.xml"};
    }

    @SuppressWarnings("all")
    public HibernateTemplate getHibernateTemplate()
    {
        return hibernateTemplate;
    }

    @SuppressWarnings("all")
    public void setHibernateTemplate(final HibernateTemplate hibernateTemplate)
    {
        this.hibernateTemplate = hibernateTemplate;
    }

}
