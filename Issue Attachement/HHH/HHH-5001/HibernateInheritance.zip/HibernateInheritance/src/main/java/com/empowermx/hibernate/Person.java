/*
 * Created on Feb 24, 2010
 * $Id$
 *
 * Copyright (c) 2006 by EmpowerMX. All Rights Reserved.
 */
package com.empowermx.hibernate;

import java.util.List;

public interface Person
{
    Person getFather();

    List<Person> getChildren();
}
