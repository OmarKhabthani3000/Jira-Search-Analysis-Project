/*
 * Created on Feb 24, 2010
 * $Id$
 *
 * Copyright (c) 2006 by EmpowerMX. All Rights Reserved.
 */
package com.empowermx.hibernate;

public interface Student extends Person
{
    Integer getMarks();
}
