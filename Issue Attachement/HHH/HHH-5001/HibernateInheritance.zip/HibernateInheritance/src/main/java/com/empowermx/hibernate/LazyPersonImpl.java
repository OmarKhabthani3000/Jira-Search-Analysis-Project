/*
 * Created on Feb 24, 2010
 * $Id$
 *
 * Copyright (c) 2006 by EmpowerMX. All Rights Reserved.
 */
package com.empowermx.hibernate;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.ForceDiscriminator;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Proxy;

@Entity
@Proxy(lazy = true, proxyClass = Person.class)
@Table(name = "PERSON")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "DISCRIMINATOR", length = 50, discriminatorType = DiscriminatorType.STRING)
@DiscriminatorValue("null")
@ForceDiscriminator
public abstract class LazyPersonImpl implements Person
{
    private String id;
    private Person father;
    private List<Person> children = new ArrayList<Person>();

    @Id
    @Column(name = "ID", nullable = false)
    @GeneratedValue(generator = "uuid.hex")
    @GenericGenerator(name = "uuid.hex", strategy = "uuid.hex")
    public String getId()
    {
        return id;
    }

    public void setId(final String id)
    {
        this.id = id;
    }

    @ManyToOne(fetch = FetchType.LAZY, targetEntity = LazyPersonImpl.class)
    @Cascade({CascadeType.ALL, CascadeType.DELETE_ORPHAN})
    @JoinColumn(name = "FATHER_ID")
    public Person getFather()
    {
        return father;
    }

    public void setFather(final Person father)
    {
        this.father = father;
    }

    @OneToMany(mappedBy = "father", fetch = FetchType.LAZY, targetEntity = LazyPersonImpl.class)
    @Cascade({CascadeType.ALL, CascadeType.DELETE_ORPHAN})
    public List<Person> getChildren()
    {
        return children;
    }

    public void setChildren(final List<Person> relPersions)
    {
        this.children = children;
    }

}
