/**
 * 
 */
package com.empowermx.hibernate;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import org.hibernate.annotations.Proxy;

/**
 * @author rajesh.vunnam
 */
@Entity
@Proxy(lazy = true, proxyClass = Principal.class)
@DiscriminatorValue("Principal")
public class LazyPrincipalImpl extends LazyPersonImpl implements Principal
{
    private String principalCertificateNumber;

    @Basic
    @Column(name = "CERTIFICATE_NUMBER")
    @SuppressWarnings("all")
    public String getPrincipalCertificateNumber()
    {
        return principalCertificateNumber;
    }

    @SuppressWarnings("all")
    public void setPrincipalCertificateNumber(final String principalCertificateNumber)
    {
        this.principalCertificateNumber = principalCertificateNumber;
    }
}
