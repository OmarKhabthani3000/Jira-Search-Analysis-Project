/**
 * 
 */
package com.empowermx.hibernate;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import org.hibernate.annotations.Proxy;

/**
 * @author rajesh.vunnam
 */
@Entity
@Proxy(lazy = false, proxyClass = Lecturer.class)
@DiscriminatorValue("Lecturer")
public class EagerLecturerImpl extends LazyPersonImpl implements Lecturer
{
    private Integer salary;

    @Basic
    @Column(name = "SAL")
    @SuppressWarnings("all")
    public Integer getSalary()
    {
        return salary;
    }

    public void setSalary(final Integer salary)
    {
        this.salary = salary;
    }

}
