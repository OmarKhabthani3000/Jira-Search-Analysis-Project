/**
 * 
 */
package com.empowermx.hibernate;

/**
 * @author rajesh.vunnam
 */
public interface Principal extends Person
{
    String getPrincipalCertificateNumber();
}
