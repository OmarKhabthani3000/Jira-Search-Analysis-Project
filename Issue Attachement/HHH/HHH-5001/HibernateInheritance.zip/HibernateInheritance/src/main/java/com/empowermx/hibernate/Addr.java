/**
 * 
 */
package com.empowermx.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.GenericGenerator;

/**
 * @author rajesh.vunnam
 */
@Entity
@Table(name = "ADDR")
public class Addr
{
    private String id;
    private Person person;

    @Id
    @Column(name = "ID", nullable = false)
    @GeneratedValue(generator = "uuid.hex")
    @GenericGenerator(name = "uuid.hex", strategy = "uuid.hex")
    public String getId()
    {
        return id;
    }

    public void setId(final String id)
    {
        this.id = id;
    }

    @OneToOne(fetch = FetchType.LAZY, targetEntity = LazyPersonImpl.class)
    @Cascade({CascadeType.ALL, CascadeType.DELETE_ORPHAN})
    @JoinColumn(name = "PERSON_ID")
    public Person getPerson()
    {
        return person;
    }

    public void setPerson(final Person relatedPerson)
    {
        this.person = relatedPerson;
    }
}
