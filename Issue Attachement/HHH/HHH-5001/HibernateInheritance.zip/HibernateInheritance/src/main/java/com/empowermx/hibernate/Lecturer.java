/**
 * 
 */
package com.empowermx.hibernate;

/**
 * @author rajesh.vunnam
 */
public interface Lecturer extends Person
{
    Integer getSalary();

    void setSalary(Integer sal);
}
