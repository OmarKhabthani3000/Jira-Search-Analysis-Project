/*
 * Created on Feb 24, 2010
 * $Id$
 *
 * Copyright (c) 2006 by EmpowerMX. All Rights Reserved.
 */
package com.empowermx.hibernate;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import org.hibernate.annotations.Proxy;

@Entity
@Proxy(lazy = true, proxyClass = Student.class)
@DiscriminatorValue("Student")
public class LazyStudentImpl extends LazyPersonImpl implements Student
{
    private Integer marks;

    @Basic
    @Column(name = "GRADE")
    @SuppressWarnings("all")
    public Integer getMarks()
    {
        return marks;
    }

    public void setMarks(final Integer marks)
    {
        this.marks = marks;
    }
}
