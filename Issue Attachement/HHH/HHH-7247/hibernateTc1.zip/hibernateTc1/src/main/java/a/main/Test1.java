/**
 * 
 */
package a.main;

import javax.persistence.EntityManager;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;

import a.entity.Category;
import a.entity.Person;
import a.entity.PersonCategory;

public class Test1 {


	public static void main(String[] args) throws Exception 
	{
		EntityManager em = Persistence.createEntityManagerFactory("ppp2").createEntityManager();
		try{		
			em.getTransaction().begin();
			em.setFlushMode( FlushModeType.COMMIT );


			/*
			 * loading peter a Person that have only the student category 
			 */
			Person peter = (Person) em.createQuery(" select p from a.entity.Person p where name='Peter' ").getSingleResult();
			
			
			/*
			 * loading professorCategory
			 */
			Category professorCategory = (Category) em.createQuery(" select c from a.entity.Category c where name='professor' ").getSingleResult();

			
			/*
			 * creating the connection between perter and the professor category
			 * ( Now we wanna him to be both ) 
			 */
			PersonCategory pc = new PersonCategory( peter , professorCategory );
			/*
			 * The great stuff here is that Hibernate dont need to load the lazy collection
			 * That "add" operation is queued in the persistent collection.
			 * Nice! 
			 */
			peter.getCategories().add( pc ) ;		
			
			
			/*
			 * If we uncomment the source below the flush will work for both hibernate 3.3.2 and 3.5.6
			 * This is true because this bug only happens when we add a element in a uninitialized persistent collection.
			 */
			//System.out.println( peter.getCategories() );
			
			
			/*
			 * Anyway if we do a System.out.println( peter.getCategories() ) here: 			 
			 * Both versions will be able to initialize the collection with the elements in db + the added 'professor' category 
			 * and both versions won't write on db ( since my flushmode is commit ). We are doing great this far. This behaviour is just perfect.
			 * 
			 */
			
			
			/*
			 * hibernate 3.5 is capable of correctly flush the PersistenceContext state to the database
			 * hibernate 3.3.2 throws a TransientObjectException that shouldn't be thrown here
			 * 
			 * It's possible to workaround this bug by persisting the PersonCategory object or initializing the lazy collection 
			 * This workaround don't solve my problem because im work on some automatic logics to avoid any programmers on the team to break the consistency of the PersistentContext 
			 * ( by "fixing" bi-directional inconsistencies on OneToMany-ManyToOne relationships )
			 * So in my case I can't just persist the data to avoid changing the programmers logic and also I can't initialize the
			 * lazy collections ( mostly by performance reasons )   
			 * 
			 */
			em.flush();
			
			
		}catch (Exception e) {			
			e.printStackTrace();
		}finally{
			try{
				em.getTransaction().rollback();		
				em.close();
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}





}
