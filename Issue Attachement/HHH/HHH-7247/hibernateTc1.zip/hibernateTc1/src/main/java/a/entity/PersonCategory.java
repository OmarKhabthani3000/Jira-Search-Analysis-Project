package a.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity(name="personcategory")
public class PersonCategory
{
	private Integer id;
	
	private Person person;
	private Category category;
	
	
	public PersonCategory(){
	}
	
	public PersonCategory(Person person, Category category){
		super();
		this.person = person;
		this.category = category;
	}
	
	
	@Id
	@GeneratedValue
	public Integer getId(){
		return id;
	}
	public void setId(Integer id){
		this.id = id;
	}
	
	@ManyToOne(fetch=FetchType.LAZY,cascade={CascadeType.PERSIST,CascadeType.MERGE})
	@JoinColumn(name="category",referencedColumnName="id")
	public Category getCategory(){
		return category;
	}
	public void setCategory(Category mcategoria)
	{
		this.category = mcategoria;
	}
		
	
	@ManyToOne(fetch=FetchType.LAZY,cascade={CascadeType.PERSIST,CascadeType.MERGE} )
	@JoinColumn( name="person" , referencedColumnName="id" )
	public Person getPerson()
	{
		return person;
	}
	public void setPerson(Person mpessoa)
	{
		this.person = mpessoa;
	}
	@Override
	public String toString()
	{
		return "'"+getPerson()+" is "+getCategory()+"'";
	}
}
