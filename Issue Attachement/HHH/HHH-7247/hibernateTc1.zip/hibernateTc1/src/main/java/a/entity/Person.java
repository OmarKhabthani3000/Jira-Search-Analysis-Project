package a.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;


@Entity(name="person")
public class Person
{

	private Integer id;
	private String name;
	private List<PersonCategory> categories = new ArrayList<PersonCategory>();

	public Person()
	{
	}
	
	public Person(Integer id, String nome)
	{
		super();
		this.id = id;
		this.name = nome;
	}
	
	@Id
	@GeneratedValue
	public Integer getId(){
		return id;
	}
	public void setId(Integer id){
		this.id = id;
	}
	
	public String getName(){
		return name;
	}
	public void setName(String name){
		this.name = name;
	}
	
	@Cascade( { CascadeType.ALL, CascadeType.DELETE_ORPHAN } )
	@OneToMany(mappedBy="person",fetch=FetchType.LAZY)
	public List<PersonCategory> getCategories(){
		return categories;
	}
	
	@SuppressWarnings("unused")
	private void setCategories(List<PersonCategory> categories){
		this.categories = categories;
	}
	
	@Override
	public String toString()
	{
		return getName()+"";
	}

}
