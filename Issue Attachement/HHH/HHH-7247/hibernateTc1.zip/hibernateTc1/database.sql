CREATE TABLE person ( 
	id  	int(11) AUTO_INCREMENT NOT NULL,
	name	varchar(45) NULL 
	)
GO
INSERT INTO person(id, name)
  VALUES(1, 'Peter')
GO
INSERT INTO person(id, name)
  VALUES(2, 'Jonh')
GO

CREATE TABLE category ( 
	id  	int(11) AUTO_INCREMENT NOT NULL,
	name	varchar(45) NULL 
	)
GO
INSERT INTO category(id, name)
  VALUES(1, 'student')
GO
INSERT INTO category(id, name)
  VALUES(2, 'professor')
GO

CREATE TABLE personcategory ( 
	id      	int(11) AUTO_INCREMENT NOT NULL,
	category	int(11) NULL,
	person  	int(11) NULL 
	)
GO
INSERT INTO personcategory(id, category, person)
  VALUES(1, 1, 1)
GO
INSERT INTO personcategory(id, category, person)
  VALUES(2, 1, 2)
GO
INSERT INTO personcategory(id, category, person)
  VALUES(3, 2, 2)
GO
