package example;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;
import javax.transaction.TransactionManager;
import javax.transaction.UserTransaction;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.AdviceMode;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseFactory;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaDialect;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.transaction.AfterTransaction;
import org.springframework.test.context.transaction.BeforeTransaction;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.jta.JtaTransactionManager;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = HibernateJTABugTest.TestConfiguration.class)
public class HibernateJTABugTest {

	private Long primaryKey;

    @Autowired
    MyEntityRepository entityRepository;

	@BeforeTransaction
	public void prepareData(){
		MyEntity entity = new MyEntity();
		entity.setName("xxx");
		entityRepository.save(entity);
		primaryKey = entity.getId();
	}

    @Test
    @Transactional
    public void testFind() {
    	MyEntity myEntity = entityRepository.findOne(primaryKey);
    	assertThat(myEntity, notNullValue());
    }

	@AfterTransaction
	public void clean() {
    	entityRepository.delete(primaryKey);
	}

    @Configuration
    @EnableJpaRepositories("example")
    @EnableTransactionManagement(mode = AdviceMode.ASPECTJ)
    public static class TestConfiguration {

        @Bean
        public DataSource dataSource() {
            EmbeddedDatabaseFactory f = new EmbeddedDatabaseFactory();
            f.setDatabaseType(EmbeddedDatabaseType.H2);
            return f.getDatabase();
        }

		@Bean
		public LocalContainerEntityManagerFactoryBean entityManagerFactory() throws Exception {
			LocalContainerEntityManagerFactoryBean localContainerEntityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
			localContainerEntityManagerFactoryBean.setPersistenceUnitName("default");
			localContainerEntityManagerFactoryBean.setJtaDataSource(dataSource());
			localContainerEntityManagerFactoryBean.setPackagesToScan(MyEntity.class.getPackage().getName());
			localContainerEntityManagerFactoryBean.setJpaDialect(new HibernateJpaDialect());

			HibernateJpaVendorAdapter jpaVendorAdapter = new HibernateJpaVendorAdapter();
			jpaVendorAdapter.setDatabasePlatform("org.hibernate.dialect.H2Dialect");
			localContainerEntityManagerFactoryBean.setJpaVendorAdapter(jpaVendorAdapter);

			localContainerEntityManagerFactoryBean.setJpaPropertyMap(jpaPropertiesMap());
			return localContainerEntityManagerFactoryBean;
		}

        public Map<String, String> jpaPropertiesMap(){
        	Map<String, String> result = new HashMap<String, String>();
        	result.put("hibernate.transaction.jta.platform", "org.hibernate.service.jta.platform.internal.JBossStandAloneJtaPlatform");
        	result.put("hibernate.current_session_context_class", "jta");
        	result.put("javax.persistence.transactionType", "JTA");
        	result.put("javax.persistence.schema-generation.database.action", "create");
        	return result;
        }

        @Bean
        public PlatformTransactionManager transactionManager() {
        	JtaTransactionManager tm = new JtaTransactionManager();
        	tm.setUserTransaction(userTx());
        	tm.setTransactionManager(txManager());
        	tm.setNestedTransactionAllowed(true);
        	return tm;
        }

        @Bean
        public UserTransaction userTx() {
        	return com.arjuna.ats.jta.UserTransaction.userTransaction();
        }

        @Bean
        public TransactionManager txManager() {
        	return com.arjuna.ats.jta.TransactionManager.transactionManager();
        }
    }
}
