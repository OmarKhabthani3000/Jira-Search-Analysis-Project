package example;

import static javax.persistence.GenerationType.AUTO;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

import org.hibernate.envers.Audited;

@Entity
@Audited
@NamedQuery(name = "test", query = "from MyEntity")
public class MyEntity {

    @Id @GeneratedValue(strategy = AUTO)
    private Long id;
    private String name;

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
