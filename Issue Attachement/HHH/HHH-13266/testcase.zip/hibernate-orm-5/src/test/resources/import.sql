insert into Model (id, timestamp) values (1, PARSEDATETIME ('01-01-1600 00:00:00','dd-MM-yyyy hh:mm:ss'))
