package com.foo;

import org.hibernate.dialect.Oracle10gDialect;
import org.hibernate.id.SequenceIdentityGenerator;

public class Oracle10gDialectWithSequence extends Oracle10gDialect {

	@Override
	public Class<?> getNativeIdentifierGeneratorClass() {
		return SequenceIdentityGenerator.class;
	}
}
