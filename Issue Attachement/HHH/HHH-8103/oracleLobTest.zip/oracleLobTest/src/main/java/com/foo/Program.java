package com.foo;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Program {

	private static final String conString = "jdbc:oracle:thin:user/password@server:port/database";
	private static SessionFactory sessionFactory;

	public static void main(String[] args) throws Exception {

		try {
			System.out.println("--- Starting Hibernate Test ---");
			hibernateTest();
			System.out.println("Hibernate test finished successfully\n");
		} catch (Exception e) {
			print( e );
		}
		System.out.println("done");
	}

	private static void print( Throwable t ) {
		while( t != null ) {
			System.out.println( "Exception message: " + t.getMessage() );
			t = t.getCause();
		}
	}

	private static void hibernateTest() {
		Session session = getSessionFactory().openSession();
		session.beginTransaction();
		LobTestEntity entity = new LobTestEntity();
		entity.setInternName("intern name");
		entity.setDisplayName("display name");
		entity.setLongText("long text");
		entity.setRepository_id(42L);
		session.persist(entity);
		session.getTransaction().commit();
	}
	
	private static SessionFactory getSessionFactory() {
		if( sessionFactory == null ) {
			sessionFactory = buildSessionFactory();
		}
		return sessionFactory;
	}

	private static SessionFactory buildSessionFactory()
			throws HibernateException {
		Configuration cfg = new Configuration();
		cfg.addAnnotatedClass(LobTestEntity.class);
		cfg.setProperty("hibernate.connection.url", conString );
		cfg.setProperty("hibernate.show_sql", "true" );
		cfg.setProperty("hibernate.hbm2ddl.auto", "create");

		// Our specific Dialect with SequenceIdentityGenerator
		cfg.setProperty("hibernate.dialect", "com.foo.Oracle10gDialectWithSequence");

		//needed for oracle ID Generation via SequenceIdentityGenerator.class
		cfg.setProperty("hibernate.jdbc.use_get_generated_keys", "true");	
		
		// our configuration with doesn't seem to matter
//		cfg.setProperty("hibernate.flushMode", "COMMIT");
//		cfg.setProperty("hibernate.max_fetch_depth", "3");
//		cfg.setProperty("hibernate.default_batch_fetch_size", "200");
//		cfg.setProperty("hibernate.jdbc.fetch_size", "1000");
//		cfg.setProperty("hibernate.jdbc.batch_size", "100");
//		cfg.setProperty("hibernate.jdbc.batch_versioned_data", "true");

		return cfg.buildSessionFactory();
	}
}
