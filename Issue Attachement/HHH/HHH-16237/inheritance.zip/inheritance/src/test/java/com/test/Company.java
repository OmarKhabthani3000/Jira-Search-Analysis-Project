package com.test;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.Basic;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import java.util.EnumMap;
import java.util.Map;
import org.hibernate.annotations.DiscriminatorFormula;

@Entity
@DiscriminatorFormula( "'CustomCompany'" )
@Access( AccessType.PROPERTY )
public class Company extends ObjectWithUnid {

	private String name;

	private Map<CompanyStandardFileType,File> standardFiles;

	@Basic
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	@ElementCollection( fetch = FetchType.LAZY )
	public Map<CompanyStandardFileType,File> getStandardFiles() {
		if( standardFiles == null ){
			this.standardFiles = new EnumMap<>( CompanyStandardFileType.class );
		}

		return standardFiles;
	}
	public void setStandardFiles(Map<CompanyStandardFileType,File> standardFiles) {
		this.standardFiles = standardFiles;
	}
}