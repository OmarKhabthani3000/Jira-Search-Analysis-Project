package com.test;

public enum CompanyStandardFileType {
	EMPLOYMENT_CONTRACT
}