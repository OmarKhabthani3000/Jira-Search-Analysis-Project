package com.test;

import jakarta.persistence.Persistence;
import java.io.IOException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class CompanyCustomTest {

	@Test
	public void testPersistStandardFiles() throws IOException {
		var emf = Persistence.createEntityManagerFactory( "tests" );
		var em = emf.createEntityManager();

		em.getTransaction().begin();
		var company = new CustomCompany();
		company.setName( "Test Company" );
		em.persist( company );
		em.getTransaction().commit();

		em.getTransaction().begin();
		company = em.find( CustomCompany.class, company.getId() );

		var file = new File();
		file.setBytes( File.class.getResourceAsStream( "dummy.txt" ).readAllBytes() );
		company.getStandardFiles().put( CompanyStandardFileType.EMPLOYMENT_CONTRACT, file );

		Assertions.assertDoesNotThrow( () -> em.getTransaction().commit() );

		emf.close();
		em.close();
	}
}