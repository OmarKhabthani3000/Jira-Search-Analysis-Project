package com.test;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.Basic;
import jakarta.persistence.Embeddable;

@Embeddable
@Access( AccessType.PROPERTY )
public class File {

	protected byte[] bytes;

	@Basic
	public byte[] getBytes() {
		return bytes;
	}
	public void setBytes(byte[] bytes) {
		this.bytes = bytes;
	}
}