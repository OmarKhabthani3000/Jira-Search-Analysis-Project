package com.test;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.Version;
import java.util.UUID;
import org.hibernate.annotations.GenericGenerator;

@MappedSuperclass
@Access( AccessType.PROPERTY )
public class ObjectWithUnid {

	private UUID id;

	private int version;

	protected ObjectWithUnid() {
	}

	@Id
	@GeneratedValue(
			generator = "system-uuid"
	)
	@GenericGenerator(
			name = "system-uuid",
			strategy = "uuid2"
	)
	@Column(
			nullable = false
	)
	public UUID getId() {
		return this.id;
	}

	public void setId(UUID unid) {
		this.id = unid;
	}

	@Version
	public int getVersion() {
		return version;
	}
	protected void setVersion(int version) {
		this.version = version;
	}
}