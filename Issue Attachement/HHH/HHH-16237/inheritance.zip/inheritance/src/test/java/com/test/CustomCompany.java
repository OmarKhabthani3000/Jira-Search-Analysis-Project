package com.test;

import jakarta.persistence.Basic;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue( "CustomCompany" )
public class CustomCompany extends Company {

	@Basic
	private String customProperty;
}