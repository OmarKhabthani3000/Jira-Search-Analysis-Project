//$Id: SubqueryExpression.java,v 1.2 2008/01/18 13:24:15 dtoney Exp $
package org.hibernate.criterion;

import java.util.HashMap;
import java.util.Iterator;

import org.hibernate.Criteria;
import org.hibernate.EntityMode;
import org.hibernate.HibernateException;
import org.hibernate.dialect.Dialect;
import org.hibernate.engine.QueryParameters;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.engine.TypedValue;
import org.hibernate.impl.CriteriaImpl;
//import org.hibernate.impl.SessionImpl;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.loader.criteria.CriteriaQueryTranslator;
import org.hibernate.persister.entity.AbstractEntityPersister;
import org.hibernate.persister.entity.OuterJoinLoadable;
import org.hibernate.sql.JoinFragment;
import org.hibernate.sql.Select;
import org.hibernate.type.Type;
import org.hibernate.util.StringHelper;

/**
 * @author Gavin King
 */
public abstract class SubqueryExpression implements Criterion {

	private CriteriaImpl criteriaImpl;
	private String quantifier;
	private String op;
	private QueryParameters params;
	private Type[] types;

	protected Type[] getTypes() {
		return types;
	}

	protected SubqueryExpression(String op, String quantifier, DetachedCriteria dc) {
		this.criteriaImpl = dc.getCriteriaImpl();
		this.quantifier = quantifier;
		this.op = op;
	}

	protected abstract String toLeftSqlString(Criteria criteria, CriteriaQuery outerQuery);

	public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery)
	throws HibernateException {

		Criteria topCriteria = criteria;
		while (topCriteria instanceof CriteriaImpl.Subcriteria) {
		    topCriteria = ((CriteriaImpl.Subcriteria) topCriteria).getParent();
		}

		final SessionImplementor session = ( (CriteriaImpl) topCriteria ).getSession(); //ugly!
		final SessionFactoryImplementor factory = session.getFactory();

		final OuterJoinLoadable rootPersister = (OuterJoinLoadable) factory.getEntityPersister( criteriaImpl.getEntityOrClassName() );
		CriteriaQueryTranslator innerQuery = new CriteriaQueryTranslator(
				factory,
				criteriaImpl,
				criteriaImpl.getEntityOrClassName(), //implicit polymorphism not supported (would need a union)
				criteriaQuery.generateSQLAlias(),
				criteriaQuery
		);

		params = innerQuery.getQueryParameters(); //TODO: bad lifecycle....
		types = innerQuery.getProjectedTypes();

		StringBuffer sbFrom = new StringBuffer();
		sbFrom.append(rootPersister.fromTableFragment( innerQuery.getRootSQLALias() ))
		 .append(rootPersister.fromJoinFragment( innerQuery.getRootSQLALias(), true, false ));

		StringBuffer sbWhere = new StringBuffer();
		sbWhere.append(innerQuery.getWhereCondition())
		 .append(rootPersister.whereJoinFragment( innerQuery.getRootSQLALias(), true, false ));

        HashMap persisterMap = new HashMap();
        persisterMap.put(criteriaImpl, rootPersister);

		for (Iterator it = criteriaImpl.iterateSubcriteria(); it.hasNext(); ) {
		    CriteriaImpl.Subcriteria subCriteria = (CriteriaImpl.Subcriteria) it.next();
            String alias = innerQuery.getSQLAlias(subCriteria);
			String entityName = innerQuery.getEntityName(subCriteria);
		    if ((alias!=null) && (entityName!=null)) {
                OuterJoinLoadable topPersister = (OuterJoinLoadable) persisterMap.get(subCriteria.getParent());
		        OuterJoinLoadable propertyPersister = (OuterJoinLoadable) factory.getEntityPersister(entityName);
                persisterMap.put(subCriteria, propertyPersister);
                JoinFragment jf = topPersister.getFactory().getDialect().createOuterJoinFragment();
                Type type = topPersister.getPropertyType(subCriteria.getPath());
                String[] pkColumns = null;
                if (type.isCollectionType()) {
                    // FIXME: This is a hack. Well, the whole thing is a hack :-) but it's generic enough.
                    // The statement below, however, assumes that collection belongs to the
                    // topmost class in the mapping, which is not always true.
                    pkColumns = ((AbstractEntityPersister) topPersister).getRootTableKeyColumnNames();
                } else {
                    pkColumns = propertyPersister.getKeyColumnNames();
                }
                // find correct table / alias for property
                String propertyTableAlias = innerQuery.getRootSQLALias();
                String propertyTableName = topPersister.getPropertyTableName(subCriteria.getPath());
                if ((propertyTableName!=null) && !topPersister.getTableName().equals(propertyTableName)) {
                    int index1 = sbFrom.indexOf(" " + propertyTableName + " ") + propertyTableName.length() + 2;
                    int index2 = sbFrom.indexOf(",", index1);
                    if (index2 < 0) {
                    	index2 = sbFrom.indexOf(" ", index1);
                    }
                    if (index2>0) {
                        propertyTableAlias = sbFrom.substring(index1, index2);
                    } else {
                        propertyTableAlias = sbFrom.substring(index1);
                    }
                }
                jf.addJoin(propertyPersister.getTableName(), alias,
                 StringHelper.qualify(propertyTableAlias, topPersister.getPropertyColumnNames(subCriteria.getPath())),
                 pkColumns, JoinFragment.INNER_JOIN );
		        sbFrom.append(jf.toFromFragmentString());
		        sbWhere.append(jf.toWhereFragmentString());
                if (!alias.equals(innerQuery.getRootSQLALias())) {
                    sbFrom.append(propertyPersister.fromJoinFragment(alias, true, false));
                    sbWhere.append(propertyPersister.whereJoinFragment(alias, true, false));
                }
			} // if
		}

		Dialect dialect = factory.getDialect();
		String sql = new Select(dialect)
		 .setWhereClause(sbWhere.toString())
		 .setGroupByClause(innerQuery.getGroupBy())
		 .setSelectClause(innerQuery.getSelect())
		 .setFromClause(sbFrom.toString())
		 .toStatementString();
		sql = sql.substring(0, sql.length() - dialect.getForReadOnlyString().length());

		final StringBuffer buf = new StringBuffer()
			.append( toLeftSqlString(criteria, criteriaQuery) );
		if (op!=null) buf.append(' ').append(op).append(' ');
		if (quantifier!=null) buf.append(quantifier).append(' ');
		return buf.append('(').append(sql).append(')')
			.toString();
	}

	public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery)
	throws HibernateException {
        if (params == null) {
	        final SessionFactoryImplementor factory = ( (CriteriaImpl) criteria ).getSession().getFactory();
	    	final OuterJoinLoadable persister = (OuterJoinLoadable) factory.getEntityPersister( criteriaImpl.getEntityOrClassName() );
	    	CriteriaQueryTranslator innerQuery = new CriteriaQueryTranslator(
	    			factory,
	    			criteriaImpl,
	    			criteriaImpl.getEntityOrClassName(), //implicit polymorphism not supported (would need a union)
	    			criteriaQuery.generateSQLAlias(),
	    			criteriaQuery);
	    	params = innerQuery.getQueryParameters(); //TODO: bad lifecycle....
        }
		Type[] types = params.getPositionalParameterTypes();
		Object[] values = params.getPositionalParameterValues();
		TypedValue[] tv = new TypedValue[types.length];
		for ( int i=0; i<types.length; i++ ) {
			tv[i] = new TypedValue( types[i], values[i], EntityMode.POJO );
		}
		return tv;
	}
}
