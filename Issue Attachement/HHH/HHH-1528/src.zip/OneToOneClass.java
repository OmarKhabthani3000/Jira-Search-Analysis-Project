import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import javax.persistence.*;

@Entity public class OneToOneClass {
    @Id private Long id;

    @OneToOne
    @PrimaryKeyJoinColumn
    private OneClass whatever;
}
