import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.hibernate.Query;

/**
 * Description
 * <p/>
 * $Id$
 * <p/>
 * User: dekan
 * Date: 24/2/2006
 * Copyright (C) 2004 DCMS Development BV
 */
public class BugDemo {
    public static void main(String[] args) {
        SessionFactory sessionFactory = new AnnotationConfiguration()
                .addAnnotatedClass(OneClass.class)
                .addAnnotatedClass(OneToOneClass.class)
                .buildSessionFactory();

        Session session = sessionFactory.getCurrentSession();
        session.beginTransaction();

        OneClass one = (OneClass) session.load(OneClass.class, 1L);
        Query query = session.createQuery("FROM OneToOneClass oto WHERE oto.whatever=:whatever");
        query.setParameter("whatever", one);
        query.list();

        session.close();
    }
}
