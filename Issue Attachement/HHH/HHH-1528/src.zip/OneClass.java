import javax.persistence.Id;
import javax.persistence.Entity;

@Entity public class OneClass {
    @Id private Long id;
}
