package app;

public class Node {
    private boolean expanded;
    private boolean leaf;
    private Object value;
    private String label;
    
    public Node(Object value, String label, boolean leaf, boolean expanded) {
        this.value = value;
        this.label = label;
        this.leaf = leaf;
        this.expanded = expanded;
    }

    public boolean isExpanded() {
        return expanded;
    }

    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }

    public boolean isLeaf() {
        return leaf;
    }

    public void setLeaf(boolean leaf) {
        this.leaf = leaf;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
