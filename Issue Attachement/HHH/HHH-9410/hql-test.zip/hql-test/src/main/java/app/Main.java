package app;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HqlTestPU");
        EntityManager em = emf.createEntityManager();
        
        createExampleProducts(em);
        
        String hql = 
                "select new app.Node(p.id, p.name, "
                + "case when (select 1 from Product p2 where p2.fullPath like concat(p.fullPath, '%') and p2 != p) "
                + " then true else false end, true)"
                + " from Product p";
        
        em.createQuery(hql).getResultList();
        
        em.close();
        emf.close();
    }

    private static void createExampleProducts(EntityManager em) {
        Product p1 = new Product();
        p1.setName("A");
        p1.setFullPath("A|");
        
        Product p2 = new Product();
        p2.setName("A1");
        p2.setFullPath("A|A1|");
        
        Product p3 = new Product();
        p3.setName("B");
        p3.setFullPath("B|");
        
        em.getTransaction().begin();
        em.persist(p1);
        em.persist(p2);
        em.persist(p3);
        em.getTransaction().commit();
    }
}
