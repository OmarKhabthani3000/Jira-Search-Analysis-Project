package org.hibernate.bugs.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Entity
public class Child1 extends Base {
	@JdbcTypeCode(SqlTypes.JSON)
	@Column(columnDefinition = "json")
	private Data1 data = new Data1();
}
