package org.hibernate.bugs.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Entity
public class Child2 extends Base {
	@JdbcTypeCode(SqlTypes.JSON)
	@Column(columnDefinition = "json")
	private Data2 data = new Data2();
}
