package org.hibernate.bugs.entities;

public class Data2 {
	private String b = "b";

	public String getB() {
		return b;
	}

	public void setB(String b) {
		this.b = b;
	}
}