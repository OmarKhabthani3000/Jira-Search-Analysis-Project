package org.hibernate.bugs.entities;

public class Data1 {
	private String a = "a";

	public String getA() {
		return a;
	}

	public void setA(String a) {
		this.a = a;
	}
}