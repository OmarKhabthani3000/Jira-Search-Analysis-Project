package bug;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AnotherBean {

    @Id
    Integer id;

    String bar;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBar() {
        return bar;
    }

    public void setBar(String bar) {
        this.bar = bar;
    }
}
