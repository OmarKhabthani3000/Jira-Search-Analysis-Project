package bug;

import org.hibernate.jpa.QueryHints;

import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.HashMap;

public class Reproducer {


    public static void main(String[] args) {
        new Reproducer().testLoad();
    }

    public void testLoad() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("reproducer");
        EntityManager entityManager = emf.createEntityManager();

        entityManager.getTransaction().begin();
        // Persist sample data
        AnotherBean anotherBean = new AnotherBean();
        anotherBean.setId(1);
        anotherBean.setBar("contents of bar");
        entityManager.persist(anotherBean);

        MyBean myBean = new MyBean();
        myBean.setId(1);
        myBean.setFoo("contents of foo");
        myBean.setAnotherBean(anotherBean);
        entityManager.persist(myBean);
        entityManager.getTransaction().commit();

        // Evict cache and create another entitymanager to load sample data from DB
        emf.getCache().evictAll();
        entityManager.close();
        entityManager = emf.createEntityManager();

        // Create entity graph
        EntityGraph<MyBean> entityGraph = entityManager.createEntityGraph(MyBean.class);
        entityGraph.addSubgraph("anotherBean");

        HashMap<String, Object> hints = new HashMap<>();
        hints.put(QueryHints.HINT_FETCHGRAPH, entityGraph);
        myBean = entityManager.find(MyBean.class, 1, hints);
        entityManager.close();

        // Check loaded
        myBean.getAnotherBean().getBar();

        // Try again from 2nd level cache
        entityManager = emf.createEntityManager();
        entityGraph = entityManager.createEntityGraph(MyBean.class);
        entityGraph.addAttributeNodes("anotherBean");

        hints = new HashMap<>();
        hints.put(QueryHints.HINT_FETCHGRAPH, entityGraph);
        myBean = entityManager.find(MyBean.class, 1);
        entityManager.close();

        // Should load but will give exception
        myBean.getAnotherBean().getBar();
        System.exit(0);
    }

    private void fail() {
        System.out.println("FAILED");
        System.exit(1);
    }
}
