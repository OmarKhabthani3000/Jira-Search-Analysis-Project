package test;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class D {
	private Long id;
	private C c;

	@Id
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	@ManyToOne
	@JoinColumn(name="cId", referencedColumnName="missing")
	public C getC() {
		return c;
	}
	
	public void setC(C c) {
		this.c = c;
	}
}
