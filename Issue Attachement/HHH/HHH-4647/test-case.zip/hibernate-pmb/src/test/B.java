package test;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class B {
	private Long id;
	private A a;

	@Id
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	@ManyToOne
	@JoinColumn(name="aId", referencedColumnName="`id`")
	public A getA() {
		return a;
	}
	
	public void setA(A a) {
		this.a = a;
	}
}
