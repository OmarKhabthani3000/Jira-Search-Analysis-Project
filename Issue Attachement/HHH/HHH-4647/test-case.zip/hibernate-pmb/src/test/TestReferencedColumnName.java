package test;

import org.hibernate.cfg.AnnotationConfiguration;
import org.junit.Test;

public class TestReferencedColumnName {
    @Test
	public void testQuotedReferencedColumnName() {
        AnnotationConfiguration config = new AnnotationConfiguration();
        config.addAnnotatedClass(A.class);
        config.addAnnotatedClass(B.class);
        config.buildSessionFactory();
	}
    
    @Test
    public void testInvalidReferencedColumnNameOnQuotedTable() {
        AnnotationConfiguration config = new AnnotationConfiguration();
        config.addAnnotatedClass(C.class);
        config.addAnnotatedClass(D.class);
        config.buildSessionFactory();
    }
}
