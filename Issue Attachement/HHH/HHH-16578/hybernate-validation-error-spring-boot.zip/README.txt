# Prerequisites:

Docker, Java 17, Gradle

# Start mysql in this folder:

docker run -it --rm -e MYSQL_ROOT_PASSWORD=test -e TZ=Europe/London -p 3309:3306 -v "${PWD}"/mysql_setup.sql:/docker-entrypoint-initdb.d/mysql_setup.sql mysql:8

# Change in to ./code folder and run:

gradle bootrun

# You should see an exception along these lines:

Schema-validation: wrong column type encountered in column [level] in table [test_data]; found [tinyint (Types#TINYINT)], but expecting [tinyint unsigned default '0' (Types#INTEGER)]

# Comment line 28 and uncomment line 27 in code/src/main/java/com/example/demo/TestEntity.java so that you have the following:

    @Column(name = "level", columnDefinition = "tinyint") // uncomment to fix
//    @Column(name = "level", columnDefinition = "tinyint UNSIGNED DEFAULT '0'") // comment to fix
    private int level;

# Run 'gradle bootrun' again and the exception goes away (the app stars and shuts down successfully, "BUILD SUCCESSFUL" message should be displayed). The same happens with "delete_date" column of type datetime.