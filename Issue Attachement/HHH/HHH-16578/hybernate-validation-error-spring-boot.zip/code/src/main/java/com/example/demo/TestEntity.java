package com.example.demo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
@Table(name = "test_data")
public class TestEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", columnDefinition = "INT(10) UNSIGNED NOT NULL")
    private Integer id;

//    @Column(name = "level", columnDefinition = "tinyint") // uncomment to fix
    @Column(name = "level", columnDefinition = "tinyint UNSIGNED DEFAULT '0'") // comment to fix
    private int level;

    @Column(name = "delete_date", columnDefinition = "datetime") // comment to create an exception
//    @Column(name = "delete_date", columnDefinition = "datetime DEFAULT '1970-01-01 00:00:00'") // uncomment to
//    create an exception
    private String deleteDate;
}
