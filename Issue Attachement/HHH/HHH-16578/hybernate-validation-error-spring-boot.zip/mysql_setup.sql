DROP DATABASE IF EXISTS test;
CREATE DATABASE test;
USE test;
CREATE USER 'test'@'%' IDENTIFIED BY 'test123';
GRANT ALL PRIVILEGES on test.* to 'test'@'%';
FLUSH PRIVILEGES;

CREATE TABLE `test_data` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `level` tinyint unsigned DEFAULT '0',
  `delete_date` datetime DEFAULT '1970-01-01 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `test`.`test_data` (`id`, `level`, `delete_date`) VALUES (1, 2, '2015-08-04 10:02:46');