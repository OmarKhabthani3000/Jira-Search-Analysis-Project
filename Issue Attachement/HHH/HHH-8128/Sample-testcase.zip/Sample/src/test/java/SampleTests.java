import com.emc.fbu.eli.Sample.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Created with IntelliJ IDEA.
 * User: oxmane
 * Date: 31/03/13
 * Time: 12:17
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-config.xml"})
@Transactional
public class SampleTests {

    @Autowired
    private ARepository aRepository;

    @Autowired
    private BRepository bRepository;

    @Autowired
    private CRepository cRepository;

    @PersistenceContext(unitName = "HibernatePersistenceUnit")
    private EntityManager entityManager;

    @Test
    @Rollback(false)
    public void testInsert() {
        C c = new C();
        B b = new B();
        A a1 = new A();
        A a2 = new A();

        a1.setB(b);
        a2.setC(c);

        b.addC(c);

        aRepository.save(a1);
        aRepository.save(a2);
    }

    @Test
    @Rollback(false)
    public void testDelete() {
        B b = bRepository.findAll().iterator().next();
        C c = cRepository.findAll().iterator().next();
        aRepository.delete(b.getA().getId());

        aRepository.delete(c.getA().getId());
    }
}
