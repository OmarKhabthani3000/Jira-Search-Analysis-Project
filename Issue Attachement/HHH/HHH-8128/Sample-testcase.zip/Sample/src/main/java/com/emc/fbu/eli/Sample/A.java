package com.emc.fbu.eli.Sample;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Created with IntelliJ IDEA.
 * User: oxmane
 * Date: 31/03/13
 * Time: 12:10
 */

@Entity
public class A {
    private String id;

    private B b;

    private C c;

    @Id
    @GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid")
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @OneToOne(fetch = FetchType.EAGER, mappedBy = "a", cascade = CascadeType.ALL)
    public B getB() {
        return b;
    }

    public void setB(B b) {
        this.b = b;

        if (b != null && b.getA() != this) {
            b.setA(this);
        }
    }

    @OneToOne(fetch = FetchType.EAGER, mappedBy = "a", cascade = CascadeType.ALL)
    public C getC() {
        return c;
    }

    public void setC(C c) {
        this.c = c;

        if (c != null && c.getA() != this) {
            c.setA(this);
        }
    }
}
