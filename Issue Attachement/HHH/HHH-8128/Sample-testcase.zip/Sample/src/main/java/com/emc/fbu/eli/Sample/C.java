package com.emc.fbu.eli.Sample;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Created with IntelliJ IDEA.
 * User: oxmane
 * Date: 31/03/13
 * Time: 12:10
 */

@Entity
public class C {
    private String id;

    private B b;

    private A a;

    @Id
    @GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid")
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @ManyToOne
    public B getB() {
        return b;
    }

    public void setB(B b) {
        this.b = b;

        if (b != null && !b.getCs().contains(this)) {
            b.addC(this);
        }
    }

    @OneToOne
    public A getA() {
        return a;
    }

    public void setA(A a) {
        this.a = a;

        if (a != null && a.getC() != this) {
            a.setC(this);
        }
    }
}
