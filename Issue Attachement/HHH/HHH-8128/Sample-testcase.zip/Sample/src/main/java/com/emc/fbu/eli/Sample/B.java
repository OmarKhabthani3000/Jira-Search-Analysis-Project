package com.emc.fbu.eli.Sample;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: oxmane
 * Date: 31/03/13
 * Time: 12:10
 */

@Entity
public class B {
    private String id;

    private List<C> cs = new LinkedList<C>();

    private A a;

    @Id
    @GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid")
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "b", cascade = CascadeType.ALL)
    public List<C> getCs() {
        return cs;
    }

    private void setCs(List<C> cs) {
        this.cs = cs;
    }

    public void addC(C c) {
        cs.add(c);

        if (c != null && c.getB() != this) {
            c.setB(this);
        }
    }

    @OneToOne
    public A getA() {
        return a;
    }

    public void setA(A a) {
        this.a = a;

        if (a != null && a.getB() != this) {
            a.setB(this);
        }
    }
}
