package com.emc.fbu.eli.Sample;

import org.springframework.data.repository.CrudRepository;

/**
 * Created with IntelliJ IDEA.
 * User: oxmane
 * Date: 31/03/13
 * Time: 12:16
 */

public interface CRepository extends CrudRepository<C, String> {
}
