package hibernate.bug;

import hibernate.bug.model.Category;
import hibernate.bug.model.Comic;
import java.util.Arrays;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
    }
    
    @Test
    public void test1() {
        EntityManager em = emf.createEntityManager();
        
        List<Comic> l = em.createQuery(
                "FROM Comic c WHERE (:category) MEMBER OF c.categories", Comic.class)
                .setParameter("category", Arrays.asList(Category.CATEGORY, Category.CATEGORY2))
                .getResultList();
        Assert.assertEquals(0, l.size());
        
        em.close();
    }
    
    @Test
    public void test2() {
        EntityManager em = emf.createEntityManager();
        
        List<Comic> l = em.createQuery(
                "FROM Comic c WHERE (:category) IN ELEMENTS(c.categories)", Comic.class)
                .setParameter("category", Arrays.asList(Category.CATEGORY, Category.CATEGORY2))
                .getResultList();
        Assert.assertEquals(0, l.size());
        
        em.close();
    }
}
