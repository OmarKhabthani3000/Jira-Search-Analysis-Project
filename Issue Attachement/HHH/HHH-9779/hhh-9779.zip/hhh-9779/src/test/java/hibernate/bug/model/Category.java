package hibernate.bug.model;

public enum Category {

    CATEGORY(1), CATEGORY2(2);

    private final Integer id;

    Category(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }
}
