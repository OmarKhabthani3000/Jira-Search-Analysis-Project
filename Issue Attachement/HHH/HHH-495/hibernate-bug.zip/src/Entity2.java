/*
 * � Copyright 2004-2005 Hewlett-Packard
 */

public class Entity2
{
   private Integer id;

   public Integer getId()
   {
      return id;
   }

   public void setId(Integer id)
   {
      this.id = id;
   }
}
