/*
 * � Copyright 2004-2005 Hewlett-Packard
 */

import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class Main
{
   public static void main(String[] args) throws Exception
   {
      Configuration configuration = new Configuration();
      configuration.configure();
      SessionFactory factory = configuration.buildSessionFactory();

      Integer zero = new Integer(0);

      Session loader = factory.openSession();

      Entity2 existing = (Entity2)loader.get(Entity2.class, zero);
      if (existing == null)
      {
         Session inserter = factory.openSession();
         Transaction tx = inserter.beginTransaction();

         Entity1 entity1 = new Entity1();
         entity1.setId(zero);

         Entity2 entity2 = new Entity2();
         entity2.setId(zero);

         inserter.save(entity1);
         inserter.save(entity2);
         tx.commit();
         inserter.close();
      }

      Entity1 entity1 = (Entity1)loader.load(Entity1.class, zero);
      System.out.println("entity1 = " + entity1);
   }
}
