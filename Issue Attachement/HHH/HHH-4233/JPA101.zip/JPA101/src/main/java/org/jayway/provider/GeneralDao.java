package org.jayway.provider;

import java.util.List;

import org.jayway.domain.Person;

public interface GeneralDao {

	public List<Person> findPersons();

	public void persist(Object obj);

}
