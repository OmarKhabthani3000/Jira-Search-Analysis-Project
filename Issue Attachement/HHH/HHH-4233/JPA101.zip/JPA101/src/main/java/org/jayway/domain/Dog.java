package org.jayway.domain;

import javax.persistence.Entity;

@Entity
public class Dog extends Mammal {
	
	private int packSize = 0;

	public int getPackSize() {
		return packSize;
	}

	public void setPackSize(int packSize) {
		this.packSize = packSize;
	}
	
	public Dog() {
		// TODO Auto-generated constructor stub
	}

}
