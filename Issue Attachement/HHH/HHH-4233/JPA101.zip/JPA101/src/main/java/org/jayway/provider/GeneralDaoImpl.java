package org.jayway.provider;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.jayway.domain.BaseEntity;
import org.jayway.domain.Person;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class GeneralDaoImpl implements GeneralDao, InitializingBean {

	private EntityManager entityManager;

	public GeneralDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	public void afterPropertiesSet() throws Exception {
	}

	public void merge(Object obj) {

		entityManager.merge(obj);

	}

	public List<Person> findPersons() {
		Criteria criteria = getHibernateSession().createCriteria(Person.class);

		return (List<Person>) criteria.list();
	}

	protected Session getHibernateSession() {
		return (Session) entityManager.getDelegate();
	}

	public void persist(Object obj) {

		if (obj instanceof BaseEntity) {
			BaseEntity baseEntity = (BaseEntity) obj;
			if (baseEntity.getId() == null)
				entityManager.persist(obj);
			else {
				entityManager.merge(obj);
			}

		} else {
			entityManager.persist(obj);
		}

	}

	/**
	 * 
	 * @param entityManager
	 */
	@PersistenceContext(type = PersistenceContextType.EXTENDED)
	public void setEntityManager(final EntityManager entityManager) {
		this.entityManager = entityManager;
	}

}
