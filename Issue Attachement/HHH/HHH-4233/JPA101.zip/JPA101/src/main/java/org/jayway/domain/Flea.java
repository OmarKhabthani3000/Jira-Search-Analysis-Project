package org.jayway.domain;

import javax.persistence.Entity;

@Entity
public class Flea extends BaseEntity {
	private String blodType;

	public Flea() {
		// TODO Auto-generated constructor stub
	}

	public String getBlodType() {
		return blodType;
	}

	public void setBlodType(String blodType) {
		this.blodType = blodType;
	}

}
