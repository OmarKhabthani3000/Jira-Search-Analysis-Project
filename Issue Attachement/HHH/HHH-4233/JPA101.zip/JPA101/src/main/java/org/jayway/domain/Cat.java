package org.jayway.domain;

import javax.persistence.Entity;

@Entity
public class Cat extends Mammal {

	private int territoryRange = 0;

	public int getTerritoryRange() {
		return territoryRange;
	}

	public void setTerritoryRange(int territoryRange) {
		this.territoryRange = territoryRange;
	}

	public Cat() {
		// TODO Auto-generated constructor stub
	}
	

}
