package org.jayway;

import org.jayway.provider.GeneralDao;
import org.springframework.beans.factory.annotation.Required;

public abstract class BaseTest extends TestSupport {

	protected GeneralDao dbProvider;

	@Override
	protected void onSetUpBeforeTransaction() throws Exception {
		super.onSetUpBeforeTransaction();
	}

	@Required
	public void setDbProvider(GeneralDao dbProvider) {
		this.dbProvider = dbProvider;
	}

}
