package org.jayway;

import java.util.List;

import org.jayway.domain.Cat;
import org.jayway.domain.Dog;
import org.jayway.domain.Mammal;
import org.jayway.domain.Person;

public class DaoTest extends BaseTest {

	private void loadData() {
		Person person = new Person();
		person.setName("John Doe");

		Cat cat = new Cat();
		cat.setName("Sir Kitty");
		cat.setOwner(person);
		cat.setTerritoryRange(30);
		person.getPets().add(cat);
		dbProvider.persist(person);

		person = new Person();
		person.setName("Jane Doe");

		cat = new Cat();
		cat.setName("Miss Kitty");
		cat.setOwner(person);
		cat.setTerritoryRange(30);
		person.getPets().add(cat);

		Dog dog = new Dog();
		dog.setName("Lassie");
		dog.setOwner(person);
		dog.setPackSize(1);
		person.getPets().add(dog);
		dbProvider.persist(person);

	}

	public void testIsSomethingWorking() {
		loadData();

		List<Person> persons = dbProvider.findPersons();
		assertNotNull(persons);
		assertTrue(persons.size() == 2);
		Person person = persons.get(0);

		assertTrue(person.getPets().size() == 1);
		Mammal mammal = person.getPets().get(0);
		assertTrue(mammal.getName().compareTo("Sir Kitty") == 0);
		assertEquals(person, mammal.getOwner());

	}

}
