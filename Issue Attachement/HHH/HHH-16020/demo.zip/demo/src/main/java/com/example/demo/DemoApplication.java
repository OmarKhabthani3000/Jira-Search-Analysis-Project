package com.example.demo;

import jakarta.persistence.EntityManager;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @Bean
    ApplicationRunner runner(PersonRepository repo, EntityManager em) {
        return args -> {
            repo.save(Person.create("Alice"));
            repo.save(Person.create("Bob"));
            repo.save(Person.create("Car"));

            em.createNativeQuery("select id, name from person where name like :name")
                    .setParameter("name", "A%")
                    .setFirstResult(1)
                    .getResultStream()
                    .forEach(System.out::println);
        };
    }

}

