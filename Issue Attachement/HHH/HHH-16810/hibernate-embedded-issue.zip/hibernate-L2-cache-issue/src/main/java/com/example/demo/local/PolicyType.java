package com.example.demo.local;

public enum PolicyType {
    ALL,
    NONE
}