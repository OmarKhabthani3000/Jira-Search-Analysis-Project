package com.example.demo.local;

import org.springframework.data.repository.CrudRepository;

public interface OperatorDao extends CrudRepository<Operator, String> {
}
