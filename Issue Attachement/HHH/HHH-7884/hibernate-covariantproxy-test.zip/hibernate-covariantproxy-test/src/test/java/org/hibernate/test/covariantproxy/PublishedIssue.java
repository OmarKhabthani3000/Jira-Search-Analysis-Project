package org.hibernate.test.covariantproxy;

import javax.persistence.Entity;

@Entity
public class PublishedIssue extends Issue {

}
