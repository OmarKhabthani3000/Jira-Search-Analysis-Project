package org.hibernate.test.covariantproxy;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.Method;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.proxy.HibernateProxy;
import org.hibernate.proxy.pojo.javassist.JavassistLazyInitializer;
import org.hibernate.testing.TestForIssue;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

public class CovariantProxyTest extends BaseCoreFunctionalTestCase {

    @Test
    @TestForIssue(jiraKey = "HHH-7883")
    public void testThatCallingAMethodWithCovariantReturnTypeInitialisesProxy() throws Exception {
        Session session = openSession();
        session.beginTransaction();
        try {
            PublishedIssue i = new PublishedIssue();
            i.setId(11);
            session.save(i);
            PublishedArticle a = new PublishedArticle();
            a.setIssue(i);
            a.setId(12);
            session.save(a);
            session.flush();
            session.clear();
            Integer id = a.getId();

            Method getIdentifierMethod = PublishedArticle.class.getMethod("getId");
            Method setIdentifierMethod = PublishedArticle.class.getMethod("setId", Integer.class);

            PublishedArticle subclassProxy = (PublishedArticle) JavassistLazyInitializer.getProxy(
                    PublishedArticle.class.getName(), PublishedArticle.class, new Class[] { HibernateProxy.class },
                    getIdentifierMethod, setIdentifierMethod, null, id, (SessionImplementor) session);
            assertFalse(Hibernate.isInitialized(subclassProxy));

            subclassProxy.getIssue();

            assertTrue(Hibernate.isInitialized(subclassProxy));
        } catch (Exception e) {
            session.getTransaction().rollback();
            throw e;
        } finally {
            session.close();
        }
    }
    
    @Override
    protected Class<?>[] getAnnotatedClasses() {
        return new Class[] {Article.class, PublishedArticle.class, Issue.class, PublishedIssue.class};
    }
    
}
