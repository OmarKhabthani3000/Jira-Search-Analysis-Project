package org.hibernate.test.covariantproxy;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class PublishedArticle extends Article {

    @ManyToOne
    @JoinColumn(name="issue_id")
    private PublishedIssue issue;
    
    @Override
    public PublishedIssue getIssue() {
        return issue;
    }

    public void setIssue(PublishedIssue issue) {
        this.issue = issue;
    }
    
}
