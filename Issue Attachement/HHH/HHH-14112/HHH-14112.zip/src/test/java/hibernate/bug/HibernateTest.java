package hibernate.bug;

import hibernate.bug.model.Element;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.util.List;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void test1() {
        EntityManager em = emf.createEntityManager();

        List<Element> l = em.createQuery(
            "SELECT 1 FROM Form u")
            .getResultList();
        Assert.assertEquals(1, l.size());

        em.close();
    }
}
