package hibernate.bug.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "SYS_FORM")
@DiscriminatorValue("Form")
public class Form extends Element {

}
