package hibernate.bug.model;


import org.hibernate.annotations.Where;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name = "SYS_ELEMENT")
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "DTYPE", discriminatorType = DiscriminatorType.STRING, length = 63)
@DiscriminatorValue("Element")
@Where(clause="DELETED = 0" )
public class Element {

    @Id
    @GeneratedValue
    private Long id;
    private String name;
    private boolean deleted;

}
