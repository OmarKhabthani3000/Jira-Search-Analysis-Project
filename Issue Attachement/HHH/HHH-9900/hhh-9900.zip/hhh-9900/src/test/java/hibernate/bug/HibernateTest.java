package hibernate.bug;

import hibernate.bug.model.CacheTest;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {

    private EntityManagerFactory emf;

    private Map createProperties() {
        Properties p = new Properties();
        p.put("hibernate.cache.use_query_cache", true);
        p.put("hibernate.cache.region.factory_class", "org.hibernate.cache.infinispan.InfinispanRegionFactory");
        return p;
    }

    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test", createProperties());

        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        // Create one of each entity type
        CacheTest doc = new CacheTest(true, false, false);
        em.persist(doc);

        em.flush();
        tx.commit();
        em.close();
    }

    @Test
    public void testIssue() {
        EntityManager em = emf.createEntityManager();
        
        List<CacheTest> results = em.createQuery("SELECT c FROM CacheTest c WHERE c.boola = ?1 AND c.boolb = ?2 AND c.boolc = ?1", CacheTest.class)
                .setParameter(1, true)
                .setParameter(2, false)
                .setHint("org.hibernate.cacheable", true)
                .getResultList();
        
        assertEquals(0, results.size());
        
        results = em.createQuery("SELECT c FROM CacheTest c WHERE c.boola = ?1 AND c.boolb = ?2 AND c.boolc = ?2", CacheTest.class)
                .setParameter(1, true)
                .setParameter(2, false)
                .setHint("org.hibernate.cacheable", true)
                .getResultList();
        
        assertEquals(1, results.size());
        
        em.close();
    }
}
