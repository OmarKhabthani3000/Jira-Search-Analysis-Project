package hibernate.bug.model;

import javax.persistence.*;

@Entity
public class CacheTest {

    private long id;
    private boolean boola;
    private boolean boolb;
    private boolean boolc;

    public CacheTest() {
    }

    public CacheTest(boolean boola, boolean boolb, boolean boolc) {
        this.boola = boola;
        this.boolb = boolb;
        this.boolc = boolc;
    }

    @Id
    @GeneratedValue
    public long getId() {
        return this.id;
    }

    public void setId(final long id) {
        this.id = id;
    }

    public boolean isBoola() {
        return boola;
    }

    public void setBoola(boolean boola) {
        this.boola = boola;
    }

    public boolean isBoolb() {
        return boolb;
    }

    public void setBoolb(boolean boolb) {
        this.boolb = boolb;
    }

    public boolean isBoolc() {
        return boolc;
    }

    public void setBoolc(boolean boolc) {
        this.boolc = boolc;
    }
}
