package com.example.demo.model;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.AutoConfigureTestEntityManager;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@SpringBootTest
@AutoConfigureTestEntityManager
public class MarketValueTest {
	@Autowired
	private TestEntityManager entityManager;

	@Test
	void test() {
		var value = new MarketValue("test");

		entityManager.persistAndFlush(value);

		entityManager.clear();

		var persisted = entityManager.find(MarketValue.class, value.getId());
		assertThat(persisted).isEqualTo(value);

		var query = entityManager.getEntityManager()
				.createQuery("from MarketValue where :codes is null", MarketValue.class);
		query.setParameter("codes", List.of());

		assertThat(query.getResultList()).hasSize(1).element(0).satisfies(e -> {
			assertThat(e).isEqualTo(value);
		});

	}

}
