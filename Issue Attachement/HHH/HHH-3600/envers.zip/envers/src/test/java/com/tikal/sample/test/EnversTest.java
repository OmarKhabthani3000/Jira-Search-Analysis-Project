package com.tikal.sample.test;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.junit.Test;

import com.tikal.sample.model.Car;
import com.tikal.sample.model.Person;


public class EnversTest {
	private SessionFactory sessionFactory;

	{
		Configuration cfg = new AnnotationConfiguration().configure("hibernate/hibernate.cfg.xml");
		cfg.setProperty("hibernate.current_session_context_class", "thread");
		sessionFactory = cfg.buildSessionFactory();
	}

	private Session currentSession() {
		return sessionFactory.getCurrentSession();
	}

	@Test
	public void testCreatePerson() {
		Person person = new Person("aaa");
		Car car = new Car("abc");
		try {
			currentSession().beginTransaction();
			currentSession().save(person);
			currentSession().save(car);
			person.addCar(car);
			currentSession().getTransaction().commit();
		} catch (RuntimeException e) {
			currentSession().getTransaction().rollback();
			throw e;
		}
	}

}
