package com.tikal.sample.model;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
@org.jboss.envers.Versioned
public class Person {
	@Id
	@GeneratedValue
	private Integer id;

	private String name;

	@OneToMany(mappedBy = "person")
	private Set<Car> cars = new HashSet<Car>();

	public Person() {
	}

	public Person(String name) {
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public Set<Car> getCars() {
		return Collections.unmodifiableSet(cars);
	}

	public void addCar(Car car) {
		cars.add(car);
		if (car.getPerson() != this) {
			car.setPerson(this);
		}
	}

	public void removeCar(Car car) {
		cars.remove(car);
		if (car.getPerson() == this) {
			car.setPerson(null);
		}
	}



}
