package com.tikal.sample.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
@org.jboss.envers.Versioned
public class Car {
	@Id
	@GeneratedValue
	private Integer id;

	private String serialNo;

	@ManyToOne
	@JoinColumn(name = "person_id")
	private Person person;

	public Car() {
	}

	public Car(String serialNo) {
		this.serialNo = serialNo;
	}

	public Integer getId() {
		return id;
	}

	public String getSerialNo() {
		return serialNo;
	}

	public void setPerson(Person person) {
		if (this.person != null && this.person.getCars().contains(this)) {
			this.person.removeCar(this);
		}
		this.person = person;
		if (person != null && !person.getCars().contains(this)) {
			person.addCar(this);
		}
	}

	public Person getPerson() {
		return person;
	}

}
