package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@DataJpaTest
@EnableJpaRepositories(basePackageClasses = TestEntityRepository.class)
@EntityScan(basePackageClasses = TestEntity.class)
class TestEntityRepositoryTests {

	@Autowired
	TestEntityRepository repository;

	@Test
	void test() {
		TestEntity entity = new TestEntity();
		entity.setName("test");
		this.repository.save(entity);
		
		Specification<TestEntity> spec = (root, cq, cb) -> cb.equal(root.get("parent"), entity);
		assertThat(this.repository.count(spec)).isEqualTo(0L);

	}

}
