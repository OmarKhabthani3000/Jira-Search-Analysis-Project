package com.example.demo;

import java.util.Collection;

import org.springframework.lang.Nullable;

import jakarta.persistence.CascadeType;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.OneToMany;

@MappedSuperclass
public abstract class AbstractTreeableEntity<T extends AbstractTreeableEntity<T>> {

	@Id
	@GeneratedValue
	private @Nullable Long id;

	protected String name;

	@ManyToOne(fetch = FetchType.LAZY)
	protected T parent;

	@OneToMany(cascade = CascadeType.REMOVE, mappedBy = "parent")
	protected Collection<T> children;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public T getParent() {
		return parent;
	}

	public void setParent(T parent) {
		this.parent = parent;
	}

	public Collection<T> getChildren() {
		return children;
	}

	public void setChildren(Collection<T> children) {
		this.children = children;
	}

}
