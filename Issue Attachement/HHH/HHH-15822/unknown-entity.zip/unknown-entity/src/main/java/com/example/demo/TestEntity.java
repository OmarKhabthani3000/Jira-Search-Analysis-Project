package com.example.demo;

import jakarta.persistence.Entity;

@Entity

class TestEntity extends AbstractTreeableEntity<TestEntity> {

}
