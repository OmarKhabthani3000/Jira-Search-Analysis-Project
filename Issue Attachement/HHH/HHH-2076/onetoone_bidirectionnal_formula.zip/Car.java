package org.hibernate.test.onetoone.bidirectionnalformula;

import java.io.Serializable;

public class Car implements Serializable{
	
	// composite id
	private String company;
	private String registration;
	
	
	private String color;
	private Person person;
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getRegistration() {
		return registration;
	}
	public void setRegistration(String registration) {
		this.registration = registration;
	}
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public boolean equals(Object that) {
		if ( !(that instanceof Car) ) return false;
		Car car = (Car) that;
		return car.getCompany().equals(company) && 
		car.getRegistration().equals( registration );
	}
	
	public int hashCode() {
		return (registration + company).hashCode();
	}
}
