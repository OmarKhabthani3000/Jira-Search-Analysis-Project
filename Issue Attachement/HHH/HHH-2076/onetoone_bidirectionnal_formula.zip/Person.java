package org.hibernate.test.onetoone.bidirectionnalformula;

import java.io.Serializable;

public class Person implements Serializable{
	
	// Composite Id
	private String company;
	private String name;
	
	
	private Car car;
	private int age;
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Car getCar() {
		return car;
	}
	public void setCar(Car car) {
		this.car = car;
	}
	
	public boolean equals(Object that) {
		if ( !(that instanceof Person) ) return false;
		Person person = (Person) that;
		return person.getCompany().equals(company) && 
		person.getName().equals( name );
	}
	
	public int hashCode() {
		return (name + company).hashCode();
	}
}
