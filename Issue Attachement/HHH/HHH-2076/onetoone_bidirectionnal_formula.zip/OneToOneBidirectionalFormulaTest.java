package org.hibernate.test.onetoone.bidirectionnalformula;

import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.test.TestCase;



public class OneToOneBidirectionalFormulaTest extends TestCase {

	public OneToOneBidirectionalFormulaTest(String str) {
		super(str);
	}
	
	
	public void testReadOneToOneBidirectionalFormula(){
		
		// populate
		Person p = new Person();
		p.setCompany("global company");
		p.setName("Luc Sky");
		p.setAge(29);
		
		Car c = new Car();
		c.setCompany("global company");
		c.setRegistration("94568 GH 41");
		c.setColor("blue");
		
		p.setCar(c);
		c.setPerson(p);
		
		Session s = openSession();
		Transaction t = s.beginTransaction();
		s.persist(c);
		s.persist(p);
		t.commit();
		s.close();
		
		
		// read with criteria
		s = openSession();
		t = s.beginTransaction();

		c = (Car)s.createCriteria(Car.class).uniqueResult();
		assertNotNull(c);
		p= c.getPerson();
		assertNotNull(p);
		assertEquals(29, p.getAge());
		
		t.commit();
		s.close();
		
		// read with criteria and Join
		s = openSession();
		t = s.beginTransaction();

		c = (Car)s.createCriteria(Car.class).setFetchMode("person", FetchMode.JOIN).uniqueResult();
		assertNotNull(c);
		p= c.getPerson();
		assertNotNull(p);
		assertEquals(29, p.getAge());
		
		t.commit();
		s.close();

		
		// read with HQL and join
		s = openSession();
		t = s.beginTransaction();

		c = (Car)s.createQuery("FROM Car as c left join fetch c.person").uniqueResult();
		assertNotNull(c);
		p= c.getPerson();
		assertNotNull(p);
		assertEquals(29, p.getAge());
		
		assertNotNull(c);
		p= c.getPerson();
		assertNotNull(p);
		assertEquals(29, p.getAge());
		
		t.commit();
		s.close();
		
		
		
		// link person -> car to null
		s = openSession();
		t = s.beginTransaction();

		c = (Car)s.createQuery("FROM Car").uniqueResult();
		assertNotNull(c);
		p= c.getPerson();
		assertNotNull(p);
		assertEquals(29, p.getAge());
		
		assertNotNull(c);
		p= c.getPerson();
		assertNotNull(p);
		assertEquals(29, p.getAge());
		
		p.setCar(null);
		s.delete(c);
		
		t.commit();
		s.close();
		
		
		
	}
	
	public void testUpdateOneToOneBidirectionalFormula(){
		
		// populate
		Person p = new Person();
		p.setCompany("global company");
		p.setName("Luc Sky");
		p.setAge(29);
		
		Car c = new Car();
		c.setCompany("global company");
		c.setRegistration("94568 GH 41");
		c.setColor("blue");
		
		p.setCar(c);
		c.setPerson(p);
		
		Session s = openSession();
		Transaction t = s.beginTransaction();
		s.persist(c);
		s.persist(p);
		t.commit();
		s.close();
		
		

		// link person -> car to null
		s = openSession();
		t = s.beginTransaction();

		c = (Car)s.createQuery("FROM Car").uniqueResult();
		assertNotNull(c);
		p= c.getPerson();
		assertNotNull(p);
		assertEquals(29, p.getAge());
		
		assertNotNull(c);
		p= c.getPerson();
		assertNotNull(p);
		assertEquals(29, p.getAge());
		
		p.setCar(null);
		s.delete(c);
		
		t.commit();
		s.close();
		
		
		
	}
	
	protected void configure(Configuration cfg) {
		cfg.setProperty(Environment.USE_SECOND_LEVEL_CACHE, "false");
		cfg.setProperty(Environment.GENERATE_STATISTICS, "true");
		cfg.setProperty(Environment.DEFAULT_BATCH_FETCH_SIZE, "2");
	}
	
	protected String[] getMappings() {
		return new String[] { "onetoone/bidirectionnalformula/Person.hbm.xml" };
	}

}
