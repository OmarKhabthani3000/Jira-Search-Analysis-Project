package dk.nykredit.hibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class OrphanRemovalIT {
    EntityManager em;

    @Before
    public void createPersistenceManager() throws Exception {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("integration");
        createData(emf);

        em = emf.createEntityManager();
        em.getTransaction().begin();
    }

    @After
    public void commitTransaction() throws Exception {
        em.getTransaction().commit();
    }

    @Test
    public void testOrphanRemoval() {
        TypedQuery<Parent> parentQuery = em.createQuery("select p from Parent p where p.semanticId = :id", Parent.class);
        parentQuery.setParameter("id", "parent");
        Parent p = parentQuery.getSingleResult();

        Child c1 = p.getChildren().iterator().next();
        p.removeChild(c1);

        Child c2 = new Child("child", p);
        p.addChild(c2);

        em.persist(p);
    }

    private void createData(EntityManagerFactory emf) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        Parent p = new Parent("parent");
        Child c = new Child("child", p);
        p.addChild(c);

        em.persist(p);
        em.getTransaction().commit();
        em.close();
    }

}
