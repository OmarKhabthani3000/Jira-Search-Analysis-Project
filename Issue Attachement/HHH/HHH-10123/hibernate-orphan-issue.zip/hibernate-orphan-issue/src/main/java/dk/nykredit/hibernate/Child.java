package dk.nykredit.hibernate;

import java.util.Objects;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * Class to act in the role as child to the parent class.
 */
@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "FK_PARENT_TID", "SID" }))
public class Child {
    @Id
    @Column(name = "TID", length = 36, nullable = false)
    private String tId;

    @Column(name = "SID", length = 100, nullable = false, unique = true)
    private String semanticId;

    @ManyToOne(optional = false)
    @JoinColumn(name = "FK_PARENT_TID", nullable = false)
    private Parent parent;

    protected Child() {
        // No arg constructor required by JPA
    }

    public Child(String semanticId, Parent parent) {
        this.semanticId = semanticId;
        this.parent = parent;
        tId = UUID.randomUUID().toString();
    }

    public String getSemanticId() {
        return semanticId;
    }

    public Parent getParent() {
        return parent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Child child = (Child) o;
        return Objects.equals(semanticId, child.semanticId) &&
            Objects.equals(parent, child.parent);
    }

    @Override
    public int hashCode() {
        return Objects.hash(semanticId, parent);
    }
}
