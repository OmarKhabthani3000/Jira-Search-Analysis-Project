package dk.nykredit.hibernate;

import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 * Class to act in the role as parent containing a list of children.
 */
@Entity
public class Parent {
    @Id
    @Column(name = "TID", length = 36, nullable = false)
    private String tId;

    @Column(name = "SID", length = 100, nullable = false, unique = true)
    private String semanticId;

    @OneToMany(mappedBy = "parent", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Child> children;

    protected Parent() {
        // No arg constructor required by JPA
    }

    public Parent(String semanticId) {
        this.semanticId = semanticId;
        tId = UUID.randomUUID().toString();
        children = new HashSet<>();
    }

    public String getSemanticId() {
        return semanticId;
    }

    public void addChild(Child child) {
        children.add(child);
    }

    public void removeChild(Child child) {
        children.remove(child);
    }

    public Set<Child> getChildren() {
        return Collections.unmodifiableSet(children);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Parent parent = (Parent) o;
        return Objects.equals(semanticId, parent.semanticId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(semanticId);
    }
}
