/*
 * CertificateTypeField.java
 *
 * Created on Tue Nov 28 19:38:19 WST 2006
 * By mm
 *
 */

package au.com.anstat.oscar.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Title:        Entity from table CertificateTypeFields
 * Description:  Models a row from the CertificateTypeFields table as a Java class
 *               This class is automatically generated from the database schema.
 *               DO NOT EDIT OUTSIDE THE TAGS
 *                    // --- Start Custom ...
 *                    // --- End Custom ...
 * Copyright:    Copyright (c) 2006
 * Company:      ARCUS Software Pty Ltd
 * @author Manuel Mall
 * @version Tue Nov 28 19:38:19 WST 2006
 */

@Entity
@Table(name="CertificateTypeFields")
@IdClass(CertificateTypeFieldId.class)
public class CertificateTypeField
    implements java.io.Serializable
{

    // The member variables for the database columns
    @Id
    @Column(name="Code"
          , length=10
          , nullable=false
          , insertable=true
          , updatable=false)
    private String code; // varchar 
    @Id
    @Column(name="Name"
          , length=20
          , nullable=false
          , insertable=true
          , updatable=false)
    private String name; // varchar 
    @Column(name="Mandatory"
          , nullable=false
          , insertable=true
          , updatable=true)
    private byte mandatory; // tinyint 
    @Column(name="GroupType"
          , length=30
          , nullable=true
          , insertable=true
          , updatable=true)
    private String groupType; // varchar 


    /**
     * Default constructor.
     * Initialises all fields with their defined default values.
     */
    public CertificateTypeField()
    {
        setCode("");
        setName("");
        setMandatory((byte)0);
    }


    /**
     * Gets the value of the property representing the Code column.
     * @return The value
     */
    public String getCode()
    {
        return this.code;
    }

    /**
     * Sets the value of the property representing the Code column.
     * @param code The new value
     */
    protected void setCode(String code)
    {
        this.code = code;
    }

    /**
     * Gets the value of the property representing the Name column.
     * @return The value
     */
    public String getName()
    {
        return this.name;
    }

    /**
     * Sets the value of the property representing the Name column.
     * @param name The new value
     */
    protected void setName(String name)
    {
        this.name = name;
    }

    /**
     * Gets the value of the property representing the Mandatory column.
     * @return The value
     */
    public byte getMandatory()
    {
        return this.mandatory;
    }

    /**
     * Sets the value of the property representing the Mandatory column.
     * @param mandatory The new value
     */
    protected void setMandatory(byte mandatory)
    {
        this.mandatory = mandatory;
    }

    /**
     * Gets the value of the property representing the GroupType column.
     * @return The value
     */
    public String getGroupType()
    {
        return this.groupType;
    }

    /**
     * Sets the value of the property representing the GroupType column.
     * @param groupType The new value
     */
    protected void setGroupType(String groupType)
    {
        this.groupType = groupType;
    }


// --- Start Custom Methods
// --- End Custom Methods

    /**
     * Generates a string representation of the object
     * @return The string
     */
    public String toString()
    {
        return
            this.getClass().getName() + ":" + "\n"
            + "    Code=" + getCode() + "\n"
            + "    Name=" + getName() + "\n"
            + "    Mandatory=" + getMandatory() + "\n"
            + "    GroupType=" + getGroupType()
        ;
    }

}
