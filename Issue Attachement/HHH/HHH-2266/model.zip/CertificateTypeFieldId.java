package au.com.anstat.oscar.model;

/**
 * Title:        Composite Id from table CertificateTypeFields
 * Description:  Models a row from the CertificateTypeFields table as a Java class
 *               This class is automatically generated from the database schema.
 *               DO NOT EDIT OUTSIDE THE TAGS
 *                    // --- Start Custom ...
 *                    // --- End Custom ...
 *               DO NOT USE DIRECTLY ! Use its subclass instead
 * Copyright:    Copyright (c) 2002
 * Company:      ARCUS Software Pty Ltd
 * @author Manuel Mall
 * @version Sat Nov 11 23:43:16 WST 2006
 */

public class CertificateTypeFieldId
    implements java.io.Serializable
{

    // The member variables for the database id columns
    private String code; // varchar 
    private String name; // varchar 

    /**
     * Default constructor.
     * Initialises all fields with their defined default values.
     */
    public CertificateTypeFieldId()
    {
        setCode("");
        setName("");
    }


    /**
     * Gets the value of the property representing the Code column.
     * @return The value
     */
    public String getCode()
    {
        return this.code;
    }

    /**
     * Sets the value of the property representing the Code column.
     * @param code The new value
     */
    public void setCode(String code)
    {
        this.code = code;
    }


    /**
     * Gets the value of the property representing the Name column.
     * @return The value
     */
    public String getName()
    {
        return this.name;
    }

    /**
     * Sets the value of the property representing the Name column.
     * @param name The new value
     */
    public void setName(String name)
    {
        this.name = name;
    }

// --- Start Custom Methods
// --- End Custom Methods

}
