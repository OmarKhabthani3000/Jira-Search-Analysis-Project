import java.util.List;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import ejbql.models.*;

/** */
public class Main {
    
    /** Sample code running creating an emf an*/
    public static void main (String[] args) {

        // Create EntityManagerFactory for a persistence unit called j2seEnvironment.
        EntityManagerFactory emf = 
            Persistence.createEntityManagerFactory("j2seEnvironment");

        // create EntityManager
        EntityManager em = emf.createEntityManager();

        // get Transaction
        EntityTransaction tx = em.getTransaction();

        // create customer

        // run a simple Java Persistence query 
        String ejbql = "SELECT Count(oi) FROM OrderItem oi";
        Query query = em.createQuery(ejbql);
        List result = query.getResultList();
    }
}
