package ejbql.models;

import java.io.Serializable;
import javax.persistence.*;

public class OrderItemId 
    implements Serializable {

    private Integer orderId;
    private Integer itemId;

    public OrderItemId() {}

    public Integer getOrderId() { 
        return orderId; 
    }
    
    public void setOrderId(Integer id) { 
        this.orderId = id; 
    }

    public Integer getItemId() { 
        return itemId; 
    }
    
    public void setItemId(Integer id) { 
        this.itemId = id; 
    }

}
