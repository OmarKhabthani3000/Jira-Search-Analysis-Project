package ejbql.models;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name="ORDER_ITEM")
@IdClass(OrderItemId.class)
public class OrderItem 
    implements Serializable {

    @Id
    @Column(name="ORDERID")
    private Integer orderId;
    @Id
    @Column(name="ITEMID")
    private Integer itemId;
    @Column(name="QUANTITY")
    private int quantity;
    @Column(name="TOTALPRICE")
    private float totalPrice;

    public OrderItem() {}

    public Integer getOrderId() { 
        return orderId; 
    }
    
    public void setOrderId(Integer id) { 
        this.orderId = id; 
    }

    public Integer getItemId() { 
        return itemId; 
    }
    
    public void setItemId(Integer id) { 
        this.itemId = id; 
    }

    public int getQuantity() { 
        return quantity; 
    }
    
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public float getTotalPrice() {
        return totalPrice;
    }
    
    public void setTotalPrice(float price) {
        this.totalPrice = price;
    }   
}
