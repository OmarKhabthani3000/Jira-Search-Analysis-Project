package org.hibernate.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

import java.sql.Blob;

@Entity
public class BlobEntity
{

    @Id
    @GeneratedValue
    private Integer id;

    @Column
    private Blob blobValue;

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Blob getBlobValue()
    {
        return blobValue;
    }

    public void setBlobValue(Blob blobValue)
    {
        this.blobValue = blobValue;
    }
}
