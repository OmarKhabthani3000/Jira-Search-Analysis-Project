package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import jakarta.persistence.TypedQuery;
import org.hibernate.engine.jdbc.BlobProxy;
import org.hibernate.entities.BlobEntity;
import org.hibernate.query.Query;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.nio.charset.StandardCharsets;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh18480Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		BlobEntity blobEntity = new BlobEntity();
		blobEntity.setBlobValue(BlobProxy.generateProxy("initial".getBytes(StandardCharsets.UTF_8)));
		entityManager.persist(blobEntity);

		byte[] updatedBytes = "update1".getBytes(StandardCharsets.UTF_8);
		blobEntity.setBlobValue(BlobProxy.generateProxy(updatedBytes));
		entityManager.merge(blobEntity);

		Assert.assertEquals(new String(updatedBytes), new String(blobEntity.getBlobValue().getBytes(1, (int) blobEntity.getBlobValue().length())));

		updatedBytes = "update2".getBytes(StandardCharsets.UTF_8);
		TypedQuery<?> query = entityManager.createQuery("UPDATE BlobEntity b SET b.blobValue = :blobValue WHERE b.id = :id",null);
		query.setParameter("id", blobEntity.getId());
		query.setParameter("blobValue", BlobProxy.generateProxy(updatedBytes));
		query.executeUpdate();

		entityManager.detach(blobEntity);
		blobEntity = entityManager.find(BlobEntity.class, blobEntity.getId());
		Assert.assertEquals(new String(updatedBytes), new String(blobEntity.getBlobValue().getBytes(1, (int) blobEntity.getBlobValue().length())));

		// Do stuff...
		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
