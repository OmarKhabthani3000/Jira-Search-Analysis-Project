//$Id: OneToManyTest.java 9914 2006-05-09 09:37:18Z max.andersen@jboss.com $
package org.hibernate.test.onetomany;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import oracle.jdbc.driver.OracleDriver;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.Oracle9Dialect;

public class OneToManyTest extends TestCase {

    private SessionFactory sessions;

    private Session session;

    public OneToManyTest(String str) {
        super(str);
    }

    public Session openSession() throws HibernateException {
        session = getSessions().openSession();
        return session;
    }

    protected SessionFactory getSessions() {
        return sessions;
    }

    protected void setUp() throws Exception {
        if (getSessions() == null) {
            buildSessionFactory();
        }
    }

    private void buildSessionFactory() throws Exception {
        if (getSessions() != null) {
            getSessions().close();
        }

        try {

            Configuration cfg = new Configuration();
            cfg.setProperty(Environment.CACHE_PROVIDER,
                    "org.hibernate.cache.HashtableCacheProvider");
            cfg.setProperty(Environment.HBM2DDL_AUTO, "create-drop");
            cfg.setProperty(Environment.DIALECT, Oracle9Dialect.class
                            .getName());
            cfg.setProperty(Environment.DRIVER, OracleDriver.class.getName());
            cfg.setProperty(Environment.URL, "jdbc:oracle:thin:@localhost:1521:XE");
            cfg.setProperty(Environment.USER, "store");
            cfg.setProperty(Environment.PASS, "store");
            cfg.addFile(OneToManyTest.class.getResource("parent.hbm.xml").getFile());
            sessions = cfg.buildSessionFactory();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    @SuppressWarnings("unchecked")
    public void testOneToMany() {
        Session s = openSession();
        Transaction t = s.beginTransaction();
        Child c = new Child();
        c.setName("Child One");
        Parent p = new Parent();
        p.setName("Parent");
        p.getChildren().add(c);
        s.save(p);
        s.flush();
        t.rollback();
    }
        
    public static Test suite() {
        return new TestSuite(OneToManyTest.class);
    }

}
