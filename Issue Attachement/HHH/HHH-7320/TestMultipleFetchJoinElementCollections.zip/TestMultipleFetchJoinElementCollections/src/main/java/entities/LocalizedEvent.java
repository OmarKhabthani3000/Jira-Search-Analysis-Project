package entities;

import javax.persistence.Embeddable;

@Embeddable
public class LocalizedEvent {

	private String text;
}
