package entities;

import javax.persistence.Embeddable;

@Embeddable
public class LocalizedArticle {

	private String text;
}
