import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.Test;

import entities.Article;


public class FetchJoinElementCollectionTest {
	
	private static final String WORKING_QUERY = "SELECT DISTINCT a FROM Article a LEFT OUTER JOIN FETCH a.event LEFT OUTER JOIN FETCH a.event.localized";
	private static final String NOT_WORKING_QUERY = "SELECT DISTINCT a FROM Article a LEFT OUTER JOIN FETCH a.localized LEFT OUTER JOIN FETCH a.event LEFT OUTER JOIN FETCH a.event.localized";
	
	@Test
	public void test(){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Test");  
		EntityManager em = emf.createEntityManager();
		
		em.createQuery(WORKING_QUERY, Article.class);
		em.createQuery(NOT_WORKING_QUERY, Article.class);
	}

}
