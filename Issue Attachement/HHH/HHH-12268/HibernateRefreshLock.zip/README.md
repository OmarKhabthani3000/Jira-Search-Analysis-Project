# HibernateRefreshTest
Simple unit tests illustrating potential defects in Hibernate refresh with lock API
