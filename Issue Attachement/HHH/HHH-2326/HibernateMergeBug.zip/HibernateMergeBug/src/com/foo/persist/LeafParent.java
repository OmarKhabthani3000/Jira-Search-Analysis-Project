package com.foo.persist;

import java.util.Set;


public class LeafParent {
	
	private Long internalId;
	
	private String leafParentId;
	
	private Integer version;
	
	private Set<Association> associationSet;
	
	public Long getInternalId() {
		return internalId;
	}

	public void setInternalId(Long internalId) {
		this.internalId = internalId;
	}

	public String getLeafParentId() {
		return leafParentId;
	}

	public void setLeafParentId(String leafParentId) {
		this.leafParentId = leafParentId;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((leafParentId == null) ? 0 : leafParentId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final LeafParent other = (LeafParent) obj;
		if (leafParentId == null) {
			if (other.leafParentId != null)
				return false;
		} else if (!leafParentId.equals(other.leafParentId))
			return false;
		return true;
	}

	public Set<Association> getAssociationSet() {
		return associationSet;
	}

	public void setAssociationSet(Set<Association> associationSet) {
		this.associationSet = associationSet;
	}

	
}
