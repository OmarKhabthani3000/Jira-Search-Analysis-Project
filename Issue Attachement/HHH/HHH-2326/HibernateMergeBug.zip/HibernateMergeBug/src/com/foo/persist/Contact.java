package com.foo.persist;

import java.util.Set;

public class Contact {

	private Set<ContactIssue> contactIssueSet;
	
	private Long internalId;

	private String name;

	private Integer version;

	public Long getInternalId() {
		return internalId;
	}

	public void setInternalId(Long internalId) {
		this.internalId = internalId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Contact other = (Contact) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	
   /**
    * @return the contactIssueSet
    */
   public Set<ContactIssue> getContactIssueSet() {
   	return contactIssueSet;
   }

	
   /**
    * @param pContactIssueSet the contactIssueSet to set
    */
   public void setContactIssueSet(Set<ContactIssue> pContactIssueSet) {
   	contactIssueSet = pContactIssueSet;
   }

	
}
