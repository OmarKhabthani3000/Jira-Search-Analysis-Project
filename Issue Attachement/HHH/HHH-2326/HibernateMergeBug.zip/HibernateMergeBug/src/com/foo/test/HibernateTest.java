package com.foo.test;

import java.util.HashSet;

import junit.framework.JUnit4TestAdapter;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import com.foo.persist.Association;
import com.foo.persist.Friend;
import com.foo.persist.LeafParent;
import com.foo.persist.RootParent;
import com.foo.util.HibernateSessionFactory;

public class HibernateTest {
	
	private void doMerge(Object pObj) {
		Session lSession;
		lSession = HibernateSessionFactory.getSession();
		Transaction t = lSession.beginTransaction();
		lSession.merge(pObj);
		t.commit();
		lSession.close();
	}
	
	@Test
	public void testInsert() throws Exception {
		
		RootParent lNewRootParent = new RootParent(); 
		lNewRootParent.setRootParentId("RPR1");
		HashSet<Association> lAssociationSet = new HashSet<Association>();
		Association lAssociation = new Association();
		lAssociation.setRootParent(lNewRootParent);
		LeafParent lLeafParent = new LeafParent();
		lLeafParent.setLeafParentId("LPR1");
		lAssociation.setLeafParent(lLeafParent);
		lAssociationSet.add(lAssociation);
		lNewRootParent.setAssociationSet(lAssociationSet);
		Friend lFriend = new Friend();
		lFriend.setFriendId("FRIEND1");
		lNewRootParent.setFriend(lFriend);
		
		doMerge(lNewRootParent);
		
	}
	
	
	public static junit.framework.Test suite() {
		return new JUnit4TestAdapter(HibernateTest.class);
	}
}
