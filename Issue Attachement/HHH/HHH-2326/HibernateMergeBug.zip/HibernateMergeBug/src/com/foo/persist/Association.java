package com.foo.persist;

import java.io.Serializable;

public class Association implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3746181614360357763L;
	
	private RootParent rootParent;
	
	private LeafParent leafParent;

	private Integer version;

	public LeafParent getLeafParent() {
		return leafParent;
	}

	public void setLeafParent(LeafParent leafParent) {
		this.leafParent = leafParent;
	}

	public RootParent getRootParent() {
		return rootParent;
	}

	public void setRootParent(RootParent rootParent) {
		this.rootParent = rootParent;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((leafParent == null) ? 0 : leafParent.hashCode());
		result = PRIME * result + ((rootParent == null) ? 0 : rootParent.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Association other = (Association) obj;
		if (leafParent == null) {
			if (other.leafParent != null)
				return false;
		} else if (!leafParent.equals(other.leafParent))
			return false;
		if (rootParent == null) {
			if (other.rootParent != null)
				return false;
		} else if (!rootParent.equals(other.rootParent))
			return false;
		return true;
	}

	
}
