package com.foo.persist;

import java.util.Set;

public class Friend {
	
	private Long internalId;
	
	private String friendId;
	
	private Integer version;
	
	private Set<RootParent> rootParentSet;

	public String getFriendId() {
		return friendId;
	}

	public void setFriendId(String friendId) {
		this.friendId = friendId;
	}

	public Long getInternalId() {
		return internalId;
	}

	public void setInternalId(Long internalId) {
		this.internalId = internalId;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Set<RootParent> getRootParentSet() {
		return rootParentSet;
	}

	public void setRootParentSet(Set<RootParent> rootParentSet) {
		this.rootParentSet = rootParentSet;
	}

}
