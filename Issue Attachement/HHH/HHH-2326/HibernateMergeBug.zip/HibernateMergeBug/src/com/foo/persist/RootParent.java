package com.foo.persist;

import java.util.Set;

public class RootParent {
	
	private Long internalId;
	
	private String rootParentId;
	
	private Integer version;
	
	private Set<Association> associationSet;
	
	private Friend friend;

	public Set<Association> getAssociationSet() {
		return associationSet;
	}

	public void setAssociationSet(Set<Association> associationSet) {
		this.associationSet = associationSet;
	}

	public Long getInternalId() {
		return internalId;
	}

	public void setInternalId(Long internalId) {
		this.internalId = internalId;
	}

	public String getRootParentId() {
		return rootParentId;
	}

	public void setRootParentId(String rootParentId) {
		this.rootParentId = rootParentId;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((rootParentId == null) ? 0 : rootParentId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final RootParent other = (RootParent) obj;
		if (rootParentId == null) {
			if (other.rootParentId != null)
				return false;
		} else if (!rootParentId.equals(other.rootParentId))
			return false;
		return true;
	}

	public Friend getFriend() {
		return friend;
	}

	public void setFriend(Friend friend) {
		this.friend = friend;
	}
	
	

}
