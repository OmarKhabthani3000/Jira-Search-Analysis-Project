package com.foo.persist;

import java.util.Set;

public class Parent {

	private Long internalId;
	private String parentId;
	private Set<ContactIssue> contactIssueSet;
	private Integer version;
	
	public Long getInternalId() {
		return internalId;
	}
	public void setInternalId(Long internalId) {
		this.internalId = internalId;
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	public Set<ContactIssue> getContactIssueSet() {
		return contactIssueSet;
	}
	public void setContactIssueSet(Set<ContactIssue> contactIssueSet) {
		this.contactIssueSet = contactIssueSet;
	}
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((parentId == null) ? 0 : parentId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Parent other = (Parent) obj;
		if (parentId == null) {
			if (other.parentId != null)
				return false;
		} else if (!parentId.equals(other.parentId))
			return false;
		return true;
	}
	
	
	
	
}
