package subselect;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.hibernate.Session;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SubselectTest {

    private EntityManagerFactory entityManagerFactory;
    protected EntityManager entityManager;

    private static final boolean USE_MULTI_LOAD = true;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");

        entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
    }

    @After
    public void destroy() {
        entityManager.getTransaction().rollback();
        entityManagerFactory.close();
    }

    @Test
    public void testSubselectFetching() {
        int numberOfParents = 100;
        int numberOfChildrenPerParent = 1000;

        List<Integer> parentIds = new ArrayList<>();

        for (int i = 0; i < numberOfParents; i++) {
            Parent parent = new Parent();
            entityManager.persist(parent);
            parentIds.add(parent.getId());

            for (int j = 0; j < numberOfChildrenPerParent; j++) {
                FetchedBySubselect child = new FetchedBySubselect();
                child.setParent(parent);
                entityManager.persist(child);

            }

        }

        entityManager.flush();
        entityManager.clear();

        setLogLevel(Level.DEBUG);

        LogManager.getLogger("test").debug(">>>>> querying parent:");

        List<Parent> resultList = loadParents(parentIds);

        LogManager.getLogger("test").debug(">>>>> querying children:");

        resultList.forEach(p -> p.getAssociation());

        //        LogManager.getLogger("test").debug(">>>>> querying parent: size = " + list.size());

        //        LogManager.getLogger("test").debug(">>>>> explicitly accessing association:");

        //        Collection<FetchedBySubselect> association = list.iterator().next().getAssociation();
        //        LogManager.getLogger("test").debug(">>>>> querying child: size = " + association.size());

        setLogLevel(Level.OFF);
    }

    private List<Parent> loadParents(List<Integer> parentIds) {
        if (USE_MULTI_LOAD) {
            Session session = entityManager.unwrap(Session.class);
            return session.byMultipleIds(Parent.class).enableSessionCheck(true).multiLoad(parentIds);
        } else {
            TypedQuery<Parent> query = entityManager.createQuery("from Parent p where p.id in :ids", Parent.class);
            query.setParameter("ids", parentIds);
            return query.getResultList();
        }
    }

    private void setLogLevel(Level level) {
        LogManager.getLogger("org.hibernate.SQL").setLevel(level);
        LogManager.getLogger("test").setLevel(level);
    }
}
