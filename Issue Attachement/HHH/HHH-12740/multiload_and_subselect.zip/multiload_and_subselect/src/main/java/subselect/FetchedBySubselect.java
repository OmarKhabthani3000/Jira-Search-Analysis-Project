package subselect;

import static javax.persistence.GenerationType.AUTO;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class FetchedBySubselect {

    @Id
    @GeneratedValue(strategy = AUTO)
    private int id;

    @ManyToOne(fetch = FetchType.LAZY, optional = true)
    private Parent parent;

    public FetchedBySubselect() {
    }

    public Parent getParent() {
        return parent;
    }

    public void setParent(Parent parent) {
        this.parent = parent;
    }

    public int getId() {
        return id;
    }
}
