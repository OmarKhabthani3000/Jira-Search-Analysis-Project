package subselect;

import static javax.persistence.GenerationType.AUTO;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
public class Parent {

    @Id
    @GeneratedValue(strategy = AUTO)
    private int id;

    @OneToMany(mappedBy = "parent", fetch = FetchType.LAZY)
    @Fetch(FetchMode.SUBSELECT)
    //    @BatchSize(size = 1000)
    private List<FetchedBySubselect> association = new ArrayList<>();

    public Collection<FetchedBySubselect> getAssociation() {
        association.sort(Comparator.comparing(FetchedBySubselect::getId));
        return association;
    }

    public int getId() {
        return id;
    }
}
