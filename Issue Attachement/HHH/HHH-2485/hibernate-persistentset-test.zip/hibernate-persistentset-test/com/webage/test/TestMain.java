package com.webage.test;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.webage.test.hibernate.Child;
import com.webage.test.hibernate.HibernateUtil;
import com.webage.test.hibernate.Parent;

public class TestMain extends TestCase {
		   
	public void testCreate() {
		Session s = HibernateUtil.currentSession();
		Transaction tr = s.beginTransaction();
		Parent parent = new Parent();
		parent.setName("name");

		Child child;
		Set children = new HashSet();

		child = new Child();
		child.setName("Child 1");
		children.add(child);
				
		child = new Child();
		child.setName("Child 2");
		children.add(child);

		parent.setChildren(children);
		s.save(parent);
		tr.commit();
	    HibernateUtil.closeSession();
	}

	public void testGet() {
		Session s = HibernateUtil.currentSession();
		Parent parent = (Parent)s.get(Parent.class, new Long(1));
		System.out.println("Parent;"+parent.getName());

		Iterator<Child> iter = parent.getChildren().iterator();
		while( iter.hasNext())
			System.out.println("Child:"+iter.next().getName());
		
		s.flush();
		HibernateUtil.closeSession();
	}
}
