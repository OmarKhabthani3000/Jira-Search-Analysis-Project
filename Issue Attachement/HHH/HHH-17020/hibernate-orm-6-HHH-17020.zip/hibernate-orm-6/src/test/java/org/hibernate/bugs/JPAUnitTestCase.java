package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.hibernate.bugs.entity.FixedProduct;
import org.hibernate.bugs.entity.Operator;
import org.hibernate.bugs.entity.Product;
import org.hibernate.bugs.entity.Product.ProductPK;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static java.util.Map.entry;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hibernate.bugs.entity.Country.USA;
import static org.hibernate.cfg.CacheSettings.USE_QUERY_CACHE;
import static org.hibernate.cfg.CacheSettings.USE_SECOND_LEVEL_CACHE;
import static org.hibernate.cfg.JdbcSettings.JAKARTA_JDBC_DRIVER;
import static org.hibernate.cfg.SchemaToolingSettings.HBM2DDL_AUTO;
import static org.hibernate.tool.schema.Action.CREATE;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;
    private static final String JDBC_DRIVER = "org.h2.Driver";

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU",
                Map.ofEntries(entry(JAKARTA_JDBC_DRIVER, JDBC_DRIVER),
                        entry(HBM2DDL_AUTO, CREATE),
                        entry(USE_SECOND_LEVEL_CACHE, false),
                        entry(USE_QUERY_CACHE, false)));
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void HHH_17020() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        String string = "ID";
        String operatorID = "operatorID";
        ProductPK id = new ProductPK(string, operatorID, USA);
        String test = "test";
        Operator operator = new Operator(operatorID);
        Product product = new FixedProduct(string, operator);
        product.setDescription(test);
        entityManager.persist(product);


        entityManager.getTransaction().commit();
        entityManager.getTransaction().begin();

        FixedProduct byId = entityManager.find(FixedProduct.class, id, new HashMap<>());
        assertThat(byId.getDescription()).isEqualTo(test);
        assertThat(byId.getOperator().getOperatorId()).isEqualTo(operatorID);
        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
