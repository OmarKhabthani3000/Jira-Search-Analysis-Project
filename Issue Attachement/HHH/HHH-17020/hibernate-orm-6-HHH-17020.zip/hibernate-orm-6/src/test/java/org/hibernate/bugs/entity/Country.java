package org.hibernate.bugs.entity;

public enum Country {
    USA,
    FRA;
}
