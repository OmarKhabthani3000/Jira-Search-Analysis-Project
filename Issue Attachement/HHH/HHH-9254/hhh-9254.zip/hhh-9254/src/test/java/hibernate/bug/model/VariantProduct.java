package hibernate.bug.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity(name = VariantProduct.NAME)
@DiscriminatorValue("variant")
public class VariantProduct extends Product {

    public static final String NAME = "variant";
    
    private long id;

    public VariantProduct() {
    }
}
