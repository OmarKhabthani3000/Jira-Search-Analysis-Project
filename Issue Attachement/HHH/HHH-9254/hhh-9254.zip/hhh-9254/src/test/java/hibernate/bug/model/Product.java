package hibernate.bug.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity(name = Product.NAME)
@Table(name = Product.NAME)
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorValue("product")
public class Product extends AbstractEntity {

    public static final String NAME = "product";

    private long id;

    public Product() {
    }
}
