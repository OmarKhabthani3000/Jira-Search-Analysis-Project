package hibernate.bug;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
    }
    
    @Test
    public void test() {
        EntityManager em = emf.createEntityManager();
        
        try {
            em.createNativeQuery("SELECT * FROM variant").getResultList();
            Assert.fail("The table 'variant' should not exist!");
        } catch (PersistenceException ex) {
            // An exception will be thrown when the table does not exist
        }
        
        List<Object[]> l = em.createQuery("FROM variant").getResultList();
        Assert.assertEquals(0, l.size());
        
        em.close();
    }
}
