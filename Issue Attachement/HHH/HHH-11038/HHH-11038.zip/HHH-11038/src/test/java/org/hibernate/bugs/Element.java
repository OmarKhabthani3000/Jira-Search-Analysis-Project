package org.hibernate.bugs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "element")
public class Element {
   @Id
   @Column(name = "id", nullable = false)
   @GeneratedValue(strategy = GenerationType.AUTO)
   public long id;

   @Column(name = "key", nullable = false)
   public String key = "key";

   @ManyToOne(optional = false)
   @JoinColumn(name = "container_id", nullable = false)
   public Container container;
}
