package org.hibernate.bugs;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "container")
public class Container {
   @Id
   @Column(name = "id", nullable = false)
   @GeneratedValue(strategy = GenerationType.AUTO)
   public long id;

   @OneToMany(mappedBy = "container", cascade = CascadeType.ALL, orphanRemoval = true)
   @MapKeyColumn(name = "key", insertable = false, updatable = false)
   public Map<String, Element> elements = new HashMap<>();
}
