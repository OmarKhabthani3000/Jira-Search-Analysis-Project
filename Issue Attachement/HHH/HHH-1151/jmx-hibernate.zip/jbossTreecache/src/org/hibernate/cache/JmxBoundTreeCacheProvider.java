package org.hibernate.cache;

import java.util.ArrayList;
import java.util.Properties;

import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.MBeanServerInvocationHandler;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.transaction.TransactionManager;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.cache.TreeCache;
import org.jboss.cache.TreeCacheMBean;

/**
 * <p>Obtain a JBoss TreeCache from JMX. Useful when you want to configure 
 * the TreeCache from a JMX console. 
 * This class is based in the <code>DeployedTreeCacheProvider</code>.</p>
 * 
 * @author <a href="mailto:mercefrancesc@yahoo.es">Francesc Xavier Magdaleno</a>
 * @see org.hibernate.cache.TreeCacheProvider
 * @see org.jboss.hibernate.cache.DeployedTreeCacheProvider
 * @version 1.0
 */
public class JmxBoundTreeCacheProvider implements CacheProvider {
	// ~ Static fields/initializers
	// =============================================
	/** property related to the agent id*/
	public static final String AGENT_ID_PROP = "hibernate.treecache.agentId";
	/** property related to the object name that you have registered the TreeCache*/
	public static final String OBJECT_NAME_PROP = "hibernate.treecache.objectName";
	/** logging*/
	private static final Log log = LogFactory.getLog(JmxBoundTreeCacheProvider.class);
	// ~ Constants fields
	// ========================================================
	/** The JBoss TreeCache*/
	private TreeCache cache;
	/** Transaction Manager*/
	private TransactionManager tm;
	// ~ Constructors
	// ===========================================================
	// ~ Public Methods
	// ================================================================
	/**
	 * 
	 * @see org.hibernate.cache.CacheProvider#buildCache(java.lang.String, java.util.Properties)
	 */
	public Cache buildCache(String regionName, Properties properties) throws CacheException {
		//return the Hibernate Cache
		return new org.hibernate.cache.TreeCache(cache,regionName,tm);
	}
	
	/**
	 * @see org.hibernate.cache.CacheProvider#nextTimestamp()
	 */
	public long nextTimestamp() {
		return System.currentTimeMillis() / 100;
	}

	/**
	 * 
	 * @see org.hibernate.cache.CacheProvider#start(java.util.Properties)
	 */
	public void start(final Properties properties) throws CacheException {
		//retrieve the JMX ObjectName 
		String objectName = properties.getProperty(OBJECT_NAME_PROP,"org.hibernate:service=treecache");
		//agentId, the agent identifier of the MBeanServer to retrieve.
		String agentId  = properties.getProperty(AGENT_ID_PROP);
		//TreeCache MBean
		TreeCacheMBean cacheMBean = getTreeCacheMBean(objectName,agentId);
		//retrieve the instance
		this.cache = cacheMBean.getInstance();
		//Retrieve the TM from the configured cache,
		//if someone has been configured. It is allowed null values
		tm = this.cache.getTransactionManager();
		if(tm==null){
			log.warn("No available a Transaction Manager in JBoss TreeCache. " +
					 "Please provide one from your JMX console");
		}
		//we assume that the lifecycle is done using the 
		//JMX console, therefore start it is not call in this step.
	}

	/**
	 * 
	 * @see org.hibernate.cache.CacheProvider#stop()
	 */
	public void stop() {
      //we assume that the lifecycle is done using the 
	  //JMX console, therefore we do not call stop.
	  this.cache = null;
	}

	/**
	 * 
	 * @see org.hibernate.cache.CacheProvider#isMinimalPutsEnabledByDefault()
	 */
	public boolean isMinimalPutsEnabledByDefault(){
		return true;
	}
	// ~ Protected Methods
	// ================================================================
	
	/**
	 * @param objectName
	 * @return
	 * @throws CacheException
	 */
	protected TreeCacheMBean getTreeCacheMBean(String objectName, String agentId) throws CacheException{
		try {
			if(objectName==null){
				//[paranoic check]
				log.error("Null values not allowed");
				throw new IllegalArgumentException("Null values not allowed");
			}
			ObjectName objName = ObjectName.getInstance(objectName);
			//retrieve the TreeCache and proxy
			TreeCacheMBean cacheMBean =(TreeCacheMBean) 
			      MBeanServerInvocationHandler.newProxyInstance(locateMBeanServer(agentId),objName,TreeCacheMBean.class,false);
			return cacheMBean;
		} catch (MalformedObjectNameException e) {
			throw new CacheException(e);
		} 
	}
	
	protected MBeanServer locateMBeanServer(String agentId) throws CacheException{
		ArrayList servers = MBeanServerFactory.findMBeanServer(agentId);
		// Check to see if an MBeanServer is registered.
		if (servers == null || servers.size() == 0) {
			log.error("Not a MBeanServer instance available");
			throw new CacheException("Not a MBeanServer instance available");
		}
		//retrieve the first one, despite the fact that
		//more than one has benn found
		MBeanServer server = (MBeanServer) servers.get(0);
		//return the MBeanServer
		return server;
	}
	// ~ Package Methods
	// ================================================================
	// ~ Private Methods
	// ================================================================
}
