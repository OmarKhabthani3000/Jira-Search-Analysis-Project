package sample.entities;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

@Access(AccessType.PROPERTY)
@Entity
@Table (name = "DUP_TEST_B")
public class B extends A {
    protected String testB;

    public B() {
    }

    public B(String testA, String testB) {
	super(testA);
	this.testB = testB;
    }

    @Id
    public String getTestA() {
        return testA;
    }
    public void setTestA(String test) {
        this.testA = test;
    }

    @Id
    public String getTestB() {
        return testB;
    }
    public void setTestB(String test) {
        this.testB = test;
    }
}
