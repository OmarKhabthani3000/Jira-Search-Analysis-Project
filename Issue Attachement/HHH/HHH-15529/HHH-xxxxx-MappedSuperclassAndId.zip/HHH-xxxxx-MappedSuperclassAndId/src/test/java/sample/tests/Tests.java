package sample.tests;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.Before;
import org.junit.Test;

import sample.entities.B;

public class Tests {
    private EntityManagerFactory emf;
    private EntityManager em;

    @Before
    public void before() {
      emf = Persistence.createEntityManagerFactory("TEST");
      em = emf.createEntityManager();
    }

    protected void insertRow(String testA, String testB) {
        B b = new B(testA, testB);

        EntityTransaction tx = em.getTransaction();
        tx.begin();
        em.persist(b);
        tx.commit();
    }

    @Test
    public void test() {
	insertRow("a", "1");
	insertRow("a", "2");
	insertRow("b", "1");
    }

}
