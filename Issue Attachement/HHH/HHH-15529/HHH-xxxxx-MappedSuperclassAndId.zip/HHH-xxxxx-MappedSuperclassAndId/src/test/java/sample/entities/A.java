package sample.entities;

import java.io.Serializable;

import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class A implements Serializable {
    protected String testA;

    public A() {
    }

    public A(String testA) {
	this.testA = testA;
    }

    public String getTestA() {
        return testA;
    }
    public void setTestA(String test) {
        this.testA = test;
    }

}
