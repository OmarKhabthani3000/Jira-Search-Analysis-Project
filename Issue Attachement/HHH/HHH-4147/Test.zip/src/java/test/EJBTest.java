package test;

import static junit.framework.Assert.*;

import java.util.Hashtable;

import javax.naming.InitialContext;

import junit.extensions.TestSetup;
import junit.framework.JUnit4TestAdapter;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

import org.jboss.ejb3.embedded.EJB3StandaloneBootstrap;
import org.junit.Before;
import org.junit.Test;

import ejb.CardDAOLocal;
import entity.Card;
import entity.Key;

public class EJBTest {

	private Card card;

	private Key key;

	public static void main(String[] args) {
		TestRunner.run(suite());
	}

	public static junit.framework.Test suite() {
		TestSuite suite = new TestSuite("Test for ANN-381");
		suite.addTest(new JUnit4TestAdapter(EJBTest.class));

		// setup test so that embedded JBoss is started/stopped once for all
		// tests here.
		TestSetup wrapper = new TestSetup(suite) {
			protected void setUp() {
				startupEmbeddedJboss();
			}

			protected void tearDown() {
				shutdownEmbeddedJboss();
			}
		};

		return wrapper;
	}

	@Before
	public void setup() {
		card = new Card("cardId");
		key = new Key("keyId");
		card.addField(card, key);
	}

	@Test
	public void persist() throws Exception {
		InitialContext ctx = getInitialContext();
		CardDAOLocal CardDAOLocal = (CardDAOLocal) ctx.lookup("CardDAOBean/local");
		CardDAOLocal.createKey(key);
		CardDAOLocal.createCard(card);
		Card card = CardDAOLocal.findCard(this.card.getId());
		assertNotNull(card);
	}

	private static void startupEmbeddedJboss() {
		EJB3StandaloneBootstrap.boot(null);
		EJB3StandaloneBootstrap.scanClasspath();
	}

	private static void shutdownEmbeddedJboss() {
		EJB3StandaloneBootstrap.shutdown();
	}

	public static InitialContext getInitialContext() throws Exception {
		Hashtable properties = getInitialContextProperties();
		return new InitialContext(properties);
	}

	private static Hashtable getInitialContextProperties() {
		Hashtable<String, String> props = new Hashtable<String, String>();
		props.put("java.naming.factory.initial",
				"org.jnp.interfaces.LocalOnlyContextFactory");
		props.put("java.naming.factory.url.pkgs",
				"org.jboss.naming:org.jnp.interfaces");
		return props;
	}

}
