package ejb;

import javax.ejb.Local;

import entity.Card;
import entity.Key;

@Local
public interface CardDAOLocal {

	void createCard(Card card);

	Card findCard(String id);

	void createKey(Key key);
}
