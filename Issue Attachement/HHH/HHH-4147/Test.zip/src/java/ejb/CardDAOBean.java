package ejb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import entity.Card;
import entity.Key;

@Stateless
public class CardDAOBean implements CardDAOLocal {

	@PersistenceContext
	private EntityManager entityManager;

	public void createCard(Card card) {
		entityManager.persist(card);
	}

	public Card findCard(String id) {
		return entityManager.find(Card.class, id);
		/*Query query = entityManager.createQuery("select c from Card c where c.id = :id");
		query.setParameter("id", id);
		return (Card) query.getSingleResult();*/
	}

	public void createKey(Key key) {
		entityManager.persist(key);
	}

}
