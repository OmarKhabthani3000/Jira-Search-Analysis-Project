package entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Key implements Serializable {
	@Id
	private String id;

	public Key(String id) {
		this.id = id;
	}

	Key() {
	}
}