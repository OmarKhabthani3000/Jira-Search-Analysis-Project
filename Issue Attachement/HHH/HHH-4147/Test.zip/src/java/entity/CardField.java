package entity;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

@Entity
public class CardField implements Serializable {

	@EmbeddedId
	private PrimaryKey primaryKey;

	CardField(Card card, Key key) {
		this.primaryKey = new PrimaryKey(card, key);
	}

	CardField() {
	}
}
