package entity;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;

@Embeddable
public class PrimaryKey implements Serializable {
	@ManyToOne(optional = false)
	private Card card;

	@ManyToOne(optional = false)
	private Key key;

	public PrimaryKey(Card card, Key key) {
		this.card = card;
		this.key = key;
	}
	
	PrimaryKey() {}
}
