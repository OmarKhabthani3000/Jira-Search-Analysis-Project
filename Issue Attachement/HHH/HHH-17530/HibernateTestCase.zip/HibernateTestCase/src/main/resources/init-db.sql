CREATE TABLE product (
    id BIGSERIAL PRIMARY KEY,
    name TEXT,
    owner_id BIGINT
);

CREATE TABLE people (
    id BIGSERIAL PRIMARY KEY,
    firstname TEXT,
    lastname TEXT
);

INSERT INTO people (id, firstname, lastname) VALUES (1, 'John', 'Doe');

INSERT INTO product (id, name, owner_id) VALUES (1, 'Product 1', 1);