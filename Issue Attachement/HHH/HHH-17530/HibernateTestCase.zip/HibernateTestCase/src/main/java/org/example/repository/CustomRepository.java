package org.example.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Selection;
import org.example.entity.PeopleLightEntity;
import org.example.entity.ProductEntity;
import org.example.entity.ProductLightEntity;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.query.QueryUtils;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CustomRepository {

    @PersistenceContext
    private EntityManager em;

    public List<ProductLightEntity> findAllLight() {
        CriteriaBuilder cb = em.getCriteriaBuilder();

        CriteriaQuery<ProductLightEntity> cq = cb.createQuery(ProductLightEntity.class);

        Root<ProductEntity> root = cq.from(ProductEntity.class);

        var criteriaQuery = cq.select(createSelect(cb, root));

        criteriaQuery.where(cb.equal(root.get("name"), "Product 1"));

        // This line cause the issue
        Sort sort = Sort.by("name").ascending();

        cq.orderBy(QueryUtils.toOrders(sort, root, cb));

        var query = em.createQuery(criteriaQuery);

        // Simulate paging
        query.setFirstResult(0);
        query.setMaxResults(2);

        return query.getResultList();
    }

    private Selection<ProductLightEntityImpl> createSelect(CriteriaBuilder cb, Root<ProductEntity> root) {

        // How to LEFT join using cb.construct ?
        // Join<ProductEntity, PeopleEntity> ownerJoin = root.join("owner", JoinType.LEFT);

        var select = cb.construct(ProductLightEntityImpl.class,
                root.get("id"),
                root.get("name"),
                cb.construct(PeopleLightEntityImpl.class,
                        root.get("owner").get("id"),
                        root.get("owner").get("firstname"),
                        root.get("owner").get("lastname"))
        );

        return select;
    }

    private static class ProductLightEntityImpl implements ProductLightEntity {

        public ProductLightEntityImpl(Long id, String name, PeopleLightEntity owner) {
            this.id = id;
            this.name = name;
            this.owner = owner;
        }

        private Long id;
        private String name;
        private PeopleLightEntity owner;

        @Override
        public Long getId() {
            return id;
        }

        @Override
        public String getName() {
            return name;
        }

        @Override
        public PeopleLightEntity getOwner() {
            return owner;
        }
    }

    private static class PeopleLightEntityImpl implements PeopleLightEntity{

        public PeopleLightEntityImpl(Long id, String firstname, String lastname) {
            this.id = id;
            this.firstname = firstname;
            this.lastname = lastname;
        }

        private Long id;
        private String firstname;
        private String lastname;

        @Override
        public Long getId() {
            return id;
        }

        @Override
        public String getFirstname() {
            return firstname;
        }

        @Override
        public String getLastname() {
            return lastname;
        }
    }
}
