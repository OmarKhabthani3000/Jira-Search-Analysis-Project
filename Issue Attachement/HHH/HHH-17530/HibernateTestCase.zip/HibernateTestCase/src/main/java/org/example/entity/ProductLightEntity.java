package org.example.entity;

public interface ProductLightEntity {

        Long getId();
        String getName();
        PeopleLightEntity getOwner();
}
