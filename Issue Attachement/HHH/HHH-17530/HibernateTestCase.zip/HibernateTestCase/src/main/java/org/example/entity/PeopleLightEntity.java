package org.example.entity;

public interface PeopleLightEntity {

    Long getId();
    String getFirstname();
    String getLastname();
}
