package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Selection;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @BeforeEach
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
    }

    @AfterEach
    public void destroy() {
        entityManagerFactory.close();
    }

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh123Test() throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        assertThat(findAllLight(entityManager)).hasSize(1);

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    public List<ProductLightEntity> findAllLight(EntityManager entityManager) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();

        CriteriaQuery<ProductLightEntity> cq = cb.createQuery(ProductLightEntity.class);

        Root<ProductEntity> root = cq.from(ProductEntity.class);

        var criteriaQuery = cq.select(createSelect(cb, root));

        criteriaQuery.where(cb.equal(root.get("name"), "Product 1"));

        // This line cause the issue
        cq.orderBy(cb.asc(root.get("name")));

        var query = entityManager.createQuery(criteriaQuery);

        // Simulate paging
        query.setFirstResult(0);
        query.setMaxResults(2);

        return query.getResultList();
    }

    private Selection<ProductLightEntityImpl> createSelect(CriteriaBuilder cb, Root<ProductEntity> root) {

        // How to LEFT join using cb.construct ?
        // Join<ProductEntity, PeopleEntity> ownerJoin = root.join("owner", JoinType.LEFT);

        var select = cb.construct(ProductLightEntityImpl.class,
                root.get("id"),
                root.get("name"),
                cb.construct(PeopleLightEntityImpl.class,
                        root.get("owner").get("id"),
                        root.get("owner").get("firstname"),
                        root.get("owner").get("lastname"))
        );

        return select;
    }

    private static class ProductLightEntityImpl implements ProductLightEntity {

        public ProductLightEntityImpl(Long id, String name, PeopleLightEntity owner) {
            this.id = id;
            this.name = name;
            this.owner = owner;
        }

        private Long id;
        private String name;
        private PeopleLightEntity owner;

        @Override
        public Long getId() {
            return id;
        }

        @Override
        public String getName() {
            return name;
        }

        @Override
        public PeopleLightEntity getOwner() {
            return owner;
        }
    }

    private static class PeopleLightEntityImpl implements PeopleLightEntity{

        public PeopleLightEntityImpl(Long id, String firstname, String lastname) {
            this.id = id;
            this.firstname = firstname;
            this.lastname = lastname;
        }

        private Long id;
        private String firstname;
        private String lastname;

        @Override
        public Long getId() {
            return id;
        }

        @Override
        public String getFirstname() {
            return firstname;
        }

        @Override
        public String getLastname() {
            return lastname;
        }
    }
}