package org.example;

public interface ProductLightEntity {

        Long getId();
        String getName();
        PeopleLightEntity getOwner();
}
