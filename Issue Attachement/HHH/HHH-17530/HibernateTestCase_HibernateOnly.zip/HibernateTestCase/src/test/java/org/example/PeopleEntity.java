package org.example;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity(name = "people")
public class PeopleEntity implements PeopleLightEntity {

    @Id
    private Long id;

    private String firstname;
    private String lastname;

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public String getFirstname() {
        return firstname;
    }

    @Override
    public String getLastname() {
        return lastname;
    }
}
