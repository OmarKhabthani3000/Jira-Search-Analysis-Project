package org.example;

public interface PeopleLightEntity {

    Long getId();
    String getFirstname();
    String getLastname();
}
