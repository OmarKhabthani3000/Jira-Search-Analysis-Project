package com.example.demo;

import static java.util.stream.Collectors.groupingBy;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

@Component
public class Startup implements ApplicationRunner {
  @Autowired
  BookRepository bookRepository;

  @Autowired
  AuthorRepository authorRepository;

  @Autowired
  EntityManager em;

  Logger logger = LoggerFactory.getLogger(Startup.class);

  Random rand = new Random(420);

  @Override
  public void run(ApplicationArguments args) {
    // SETUP DATA
    List authors = new ArrayList<Author>();
    var books = new ArrayList<Book>();

    for (int i = 0; i < 100; i++) {
      var a = new Author();
      a.setId(i + 1L);
      a.setName("A" + i);
      authors.add(a);
    }

    authors = authorRepository.saveAll(authors);

    for (int i = 0; i < 500; i++) {
      var b = new Book();
      b.setId(i + 1L);
      b.setTitle("B" + i);
      var myAuthors = new ArrayList<Author>();
      for (int j = 0; j < 7; j++) {
        var as = authors.get(rand.nextInt(0, authors.size()));
        myAuthors.add((Author) as);
      }
      b.setAuthors(myAuthors);
      books.add(b);
    }

    bookRepository.saveAll(books);

    // Query data
    var booksOrderByTitle = bookRepository.findAll(PageRequest.of(0, 50, Sort.by("title")));
    logger.info("Retrieved {} books when sorting by 'title'", booksOrderByTitle.getContent().size());

    var booksOrderByAuthors = bookRepository.findAll(PageRequest.of(0, 50, Sort.by("authors")));
    // 47 books are returned here but should be 50
    logger.info("Retrieved {} books when sorting by 'authors'", booksOrderByAuthors.getContent().size());

    /*
     * Output
     * Hibernate: select b1_0.id,b1_0.title from book b1_0 order by b1_0.title offset ? rows fetch first ? rows only
     * Hibernate: select count(b1_0.id) from book b1_0
     * Retrieved 50 books when sorting by 'title'
     * Hibernate: select b1_0.id,b1_0.title from book b1_0 left join book_authors a1_0 on b1_0.id=a1_0.book_id order by a1_0.authors_id offset ? rows fetch first ? rows only
     * Retrieved 47 books when sorting by 'authors'
     */


    // Using CriteriaBuilder directly
    CriteriaBuilder cb = em.getCriteriaBuilder();

    CriteriaQuery<Book> cq = cb.createQuery(Book.class);
    Root<Book> root = cq.from(Book.class);
    Join<Object, Object> join = root.join("authors", JoinType.LEFT);
    cq.orderBy(cb.asc(join));
    TypedQuery<Book> query = em.createQuery(cq).setFirstResult(0).setMaxResults(50);
    var booksQ = query.getResultList();
    var groupedBooks = booksQ.stream().collect(groupingBy(b -> b.getId()));
    logger.info("Retrieved {} books (from criteriaBuilder) when sorting by 'authors'", booksQ.size());
    logger.info("Grouped by id count: {}", groupedBooks.size());

    /*
    Output with hibernate5
    Hibernate: select book0_.id as id1_1_, book0_.title as title2_1_ from book book0_ left outer join book_authors authors1_ on book0_.id=authors1_.book_id left outer join author author2_ on authors1_.authors_id=author2_.id order by author2_.id asc limit ?
    Retrieved 50 books (from criteriaBuilder) when sorting by 'authors'

    With hibernate6 (wrong query)
    Hibernate: select b1_0.id,b1_0.title from book b1_0 left join book_authors a1_0 on b1_0.id=a1_0.book_id order by a1_0.authors_id offset ? rows fetch first ? rows only
    Retrieved 46 books (from criteriaBuilder) when sorting by 'authors'
     */
  }
}
