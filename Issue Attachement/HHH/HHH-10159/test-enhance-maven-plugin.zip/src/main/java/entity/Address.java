package entity;

import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Address {

	@Id
	@GeneratedValue
	private Long id;

	@OneToMany(fetch = FetchType.LAZY)
	private Set<Address> address = new LinkedHashSet<Address>();

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "address", cascade=CascadeType.ALL, orphanRemoval=true)
	private Set<Country> linkedCountries = new LinkedHashSet<Country>();

}
