package org.sandbox.optimisticlocking.dao;

import org.sandbox.optimisticlocking.dao.entity.EmployeeEntity;

public interface EmployeeDao {

	EmployeeEntity getById(Integer id);

	Integer save(EmployeeEntity employee);

	void update(EmployeeEntity employee);

}
