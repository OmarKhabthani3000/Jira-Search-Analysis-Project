package org.sandbox.optimisticlocking.domain;

import java.util.Set;

public class Employee {

	private Long id;

	private Integer version;

	private String firstName;

	private Set<Project> projects;


	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(final Integer version) {
		this.version = version;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(final String firstName) {
		this.firstName = firstName;
	}

	public Set<Project> getProjects() {
		return projects;
	}

	public void setProjects(final Set<Project> projects) {
		this.projects = projects;
	}

	@Override
	public String toString() {
		return "Employee{" +
				"id=" + id +
				", version=" + version +
				", firstName='" + firstName + '\'' +
				", projects=" + projects +
				'}';
	}

}
