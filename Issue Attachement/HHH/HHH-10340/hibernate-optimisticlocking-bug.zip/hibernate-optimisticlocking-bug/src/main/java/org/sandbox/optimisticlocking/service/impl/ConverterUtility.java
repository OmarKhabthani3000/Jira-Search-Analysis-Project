package org.sandbox.optimisticlocking.service.impl;

import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;

import java.util.ArrayList;
import java.util.List;

public class ConverterUtility {

	private static Mapper mapper = new DozerBeanMapper();
	
	public static <TDestination> TDestination convert(final Object sourceObject, final Class<TDestination> destinationClass) {
		if (sourceObject == null) {
			return null;
		}

		return mapper.map(sourceObject, destinationClass);
	}

	public static <TDestination> List<TDestination> convert(final List<?> sourceObjectList, final Class<TDestination> destinationClass) {
		final List<TDestination> result = new ArrayList<TDestination>(sourceObjectList.size());
		for (final Object o : sourceObjectList) {
			result.add(convert(o, destinationClass));
		}

		return result;
	}

}
