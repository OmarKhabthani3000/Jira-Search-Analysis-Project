package org.sandbox.optimisticlocking.dao.impl;

import org.hibernate.SessionFactory;
import org.sandbox.optimisticlocking.dao.EmployeeDao;
import org.sandbox.optimisticlocking.dao.entity.EmployeeEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeHibernateDao extends HibernateDaoSupport implements EmployeeDao {

	@Autowired
	public EmployeeHibernateDao(final SessionFactory sessionFactory) {
		this.setSessionFactory(sessionFactory);
	}

	@Override
	public EmployeeEntity getById(final Integer id) {
		return this.getHibernateTemplate().get(EmployeeEntity.class, id);
	}

	@Override
	public Integer save(final EmployeeEntity employee) {
		return (Integer) this.getHibernateTemplate().save(employee);
	}

	@Override
	public void update(final EmployeeEntity employee) {
		this.getHibernateTemplate().update(employee);
	}
}
