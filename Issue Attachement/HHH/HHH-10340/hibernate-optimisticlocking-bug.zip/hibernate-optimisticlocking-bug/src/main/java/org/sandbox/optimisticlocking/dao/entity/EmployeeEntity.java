package org.sandbox.optimisticlocking.dao.entity;

import java.util.Set;

public class EmployeeEntity {

	private Integer id;

	private Integer version;

	private String firstName;

	private Set<ProjectEntity> projects;


	public Integer getId() {
		return id;
	}

	public void setId(final Integer id) {
		this.id = id;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(final Integer version) {
		this.version = version;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(final String firstName) {
		this.firstName = firstName;
	}

	public Set<ProjectEntity> getProjects() {
		return projects;
	}

	public void setProjects(final Set<ProjectEntity> projects) {
		this.projects = projects;
	}

}
