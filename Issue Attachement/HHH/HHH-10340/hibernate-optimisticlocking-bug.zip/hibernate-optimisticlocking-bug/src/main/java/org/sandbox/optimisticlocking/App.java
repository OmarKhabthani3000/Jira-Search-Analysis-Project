package org.sandbox.optimisticlocking;

import org.sandbox.optimisticlocking.domain.Employee;
import org.sandbox.optimisticlocking.service.EmployeeService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("optimisticlocking-context.xml");

		final EmployeeService employeeService = ctx.getBean("employeeService", EmployeeService.class);

		// INSERT
		final Integer employeeId = employeeService.save(createEmployee());

		// SELECT
		final Employee employee = employeeService.getById(employeeId);

		// UPDATE
		employeeService.update(employee);
	}

	private static Employee createEmployee() {
		Employee e = new Employee();
		e.setFirstName("Piotr");

		return e;
	}

}
