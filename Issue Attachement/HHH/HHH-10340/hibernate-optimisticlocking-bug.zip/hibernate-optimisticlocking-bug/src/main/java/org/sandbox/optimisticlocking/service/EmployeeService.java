package org.sandbox.optimisticlocking.service;

import org.sandbox.optimisticlocking.domain.Employee;

public interface EmployeeService {

	Employee getById(Integer id);

	Integer save(Employee employee);

	void update(Employee employee);

}
