package org.sandbox.optimisticlocking.service.impl;

import org.sandbox.optimisticlocking.dao.EmployeeDao;
import org.sandbox.optimisticlocking.dao.entity.EmployeeEntity;
import org.sandbox.optimisticlocking.domain.Employee;
import org.sandbox.optimisticlocking.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional(rollbackFor = Throwable.class)
@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao dao;

	@Override
	public Employee getById(final Integer id) {
		return convert(this.dao.getById(id));
	}

	@Override
	public Integer save(final Employee employee) {
		return this.dao.save(convert(employee));
	}

	@Override
	public void update(final Employee employee) {
		this.dao.update(convert(employee));
	}

	private static EmployeeEntity convert(final Employee employee) {
		return ConverterUtility.convert(employee, EmployeeEntity.class);
	}

	private static Employee convert(final EmployeeEntity employeeEntity) {
		return ConverterUtility.convert(employeeEntity, Employee.class);
	}

}
