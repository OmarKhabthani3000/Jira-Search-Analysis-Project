ALTER TABLE employee ALTER COLUMN version SET DEFAULT 0;

-- CREATE TABLE employee(employee_id    int auto_increment    NOT NULL, first_name     text, version        integer default 0);
-- CREATE TABLE employee_to_project(employee_id  integer,  project_id   integer);
-- CREATE TABLE project(project_id  int auto_increment   NOT NULL, name        text);
