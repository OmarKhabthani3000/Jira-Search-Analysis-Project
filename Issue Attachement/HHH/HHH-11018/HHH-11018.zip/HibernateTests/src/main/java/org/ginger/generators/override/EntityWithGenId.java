package org.ginger.generators.override;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="ENTWIGEN")
@SequenceGenerator(name="entGenIdSeq", sequenceName="ENTWIGEN_ID_SEQ")
@Access(AccessType.FIELD)
public class EntityWithGenId {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator="entGenIdSeq")
    private Long myId;

    private String someStuff;
    
    public EntityWithGenId() {
    	super();
    }

    public EntityWithGenId(String someStuff) {
    	this.someStuff = someStuff;
    }

	public Long getMyId() {
		return myId;
	}

	public void setMyId(Long myId) {
		this.myId = myId;
	}

	public String getSomeStuff() {
		return someStuff;
	}

	public void setSomeStuff(String someStuff) {
		this.someStuff = someStuff;
	}
	
	@Override
	public String toString() {
		return new StringBuilder(getSomeStuff()).append(":").append(getMyId()).toString();
	}
    
}
