package org.ginger.generators.override;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.junit.runners.MethodSorters;

@RunWith(JUnit4.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class GeneratorOverrideTest {
	private static final String MARVIN = "Marvin";
	private static final String SMOKEY = "Smokey";
	private static final String EDWIN = "Edwin";
	
	private static EntityManagerFactory entityManagerFactory;
	
	@AfterClass
	public static void tearDown() {
		if (entityManagerFactory != null) {
			entityManagerFactory.close();
		}
	}

	@BeforeClass
	public static void setUp() {
		System.out.println("STARTING TEST ... LOADING EMF ...");
		
		entityManagerFactory = Persistence.createEntityManagerFactory( "genoverridetest" );
		
		System.out.println("EMF LOADED ...");
	}
	
	@Test
	public void testGeneratedEntityIds() {
		Work work = new Work() {
			public void work(EntityManager sess) {
				EntityWithGenId anEnt = new EntityWithGenId(MARVIN);
				sess.persist(anEnt);
			}
		};
		transact(work);

		work = new Work() {
			public void work(EntityManager sess) {
				EntityWithGenId anEnt = new EntityWithGenId(SMOKEY);
				sess.persist(anEnt);
			}
		};
		transact(work);

		work = new Work() {
			public void work(EntityManager sess) {
				EntityWithGenId anEnt = new EntityWithGenId(EDWIN);
				sess.persist(anEnt);
			}
		};
		transact(work);

		System.out.println("... ENTITIES CREATED ...");
		
		work = new Work() {
			public void work(EntityManager sess) {
				List<EntityWithGenId> ents = sess.createQuery("FROM org.ginger.generators.override.EntityWithGenId").getResultList();
				for (EntityWithGenId anEnt : ents) {
					System.out.println(anEnt.toString());
					assertEquals(CustomIdGenerator.generationAlgorithm(anEnt), anEnt.getMyId().longValue());
				}
			}
		};
		transact(work);

		System.out.println("... DONE!");
	}
	
	public static void transact(Work work) {
		EntityManager sess = entityManagerFactory.createEntityManager();
		sess.getTransaction().begin();
		work.work(sess);
		sess.getTransaction().commit();
		sess.close();
	}
	
	
	interface Work {
		void work(EntityManager sess);
	}
}
