package org.ginger.generators.override;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.boot.model.relational.Database;
import org.hibernate.dialect.Dialect;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.PersistentIdentifierGenerator;

public class CustomIdGenerator implements PersistentIdentifierGenerator {
	private int tick = 0;

	public static long generationAlgorithm(EntityWithGenId object) {
		return (long) Math.abs(object.getSomeStuff().hashCode());
	}
	
	@Override
	public Serializable generate(SharedSessionContractImplementor session, Object object) throws HibernateException {
		if (object instanceof EntityWithGenId) {
			long abs_hash = generationAlgorithm((EntityWithGenId) object);
			return Long.valueOf(abs_hash);
		} else {
			return System.currentTimeMillis()+tick++;
		}
	}

	@Override
	public void registerExportables(Database database) {
		// This type does not go anywhere near the database so nothing to do here ...
	}

	@Override
	public String[] sqlCreateStrings(Dialect dialect) throws HibernateException {
		return new String[0];
	}

	@Override
	public String[] sqlDropStrings(Dialect dialect) throws HibernateException {
		return new String[0];
	}

	@Override
	public Object generatorKey() {
		return CustomIdGenerator.class.getName();
	}

}
