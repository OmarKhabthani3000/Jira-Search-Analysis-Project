package org.sample.hibernate;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.sample.hibernate.model.Department;
import org.sample.hibernate.model.Person;
import org.sample.hibernate.util.HibernateUtil;

public class Test1 {

	@Test
	public void testInnerJoin() {

		Session session = HibernateUtil.getNewSession();
		try {
			session.beginTransaction();
			Query query = session.createQuery("select p, p.department from Person p");
			List result = query.list();
			System.out.println(result.size() + " results");
			assertEquals(2, result.size());
			
			for (Object obj  :  result) {
				Object[] row = (Object[]) obj;
				Person p = (Person) row[0];			
				System.out.println(p.getId() + " " + p.getName() + " "
						+ (p.getDepartment() != null ? p.getDepartment().getName() : "not assigned"));
			}
			session.getTransaction().commit();
		} finally {
			session.close();
		}
	}

	@Test
	public void testOuterJoin() {

		Session session = HibernateUtil.getNewSession();
		try {
			session.beginTransaction();
			Query query = session.createQuery("select p, p.department from Person p left join p.department");
			List result = query.list();
			System.out.println(result.size() + " results");
			assertEquals(3, result.size());
			
			for (Object obj  :  result) {
				Object[] row = (Object[]) obj;
				Person p = (Person) row[0];			
				System.out.println(p.getId() + " " + p.getName() + " "
						+ (p.getDepartment() != null ? p.getDepartment().getName() : "not assigned"));
			}
			session.getTransaction().commit();
		} finally {
			session.close();
		}
	}

	@BeforeClass
	public static void beforeClass() {
		Session session = HibernateUtil.getNewSession();
		session.beginTransaction();

		ArrayList<Person> people = new ArrayList<>();
		ArrayList<Department> departments = new ArrayList<>();

		for (String s : new String[] { "peter", "paul", "mary" }) {
			Person p = new Person();
			p.setName(s);
			session.save(p);
			people.add(p);
		}

		for (String s : new String[] { "hr", "accounting", "engineering" }) {
			Department d = new Department();
			d.setName(s);
			session.save(d);
			departments.add(d);
		}

		people.get(0).setDepartment(departments.get(0));
		people.get(1).setDepartment(departments.get(0));

		session.getTransaction().commit();
		session.close();
	}

	@AfterClass
	public static void afterClass() {
		HibernateUtil.close();
	}
}
