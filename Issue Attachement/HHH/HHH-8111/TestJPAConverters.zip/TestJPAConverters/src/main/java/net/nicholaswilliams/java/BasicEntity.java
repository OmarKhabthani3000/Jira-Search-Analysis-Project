package net.nicholaswilliams.java;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "BasicTable")
public class BasicEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    private long id;
    private String name;

    @Id
    @Basic
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "entityName")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
