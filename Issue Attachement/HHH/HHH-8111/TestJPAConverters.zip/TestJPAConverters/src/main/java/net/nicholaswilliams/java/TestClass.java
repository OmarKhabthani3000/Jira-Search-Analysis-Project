package net.nicholaswilliams.java;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class TestClass {
    private Connection connection;

    private EntityManager entityManager;
    private EntityManagerFactory entityManagerFactory;
    private EntityTransaction transaction;

    private TestClass() {

    }

    private void createDatabase() throws SQLException{
        System.out.println("Starting HSQLDB and creating database.");

        this.connection = DriverManager.getConnection("jdbc:hsqldb:mem:Log4j", "sa", "");

        Statement statement = this.connection.createStatement();
        statement.executeUpdate("CREATE TABLE BasicTable ( id INTEGER IDENTITY, entityName VARCHAR(255) )");
        statement.close();

        statement = this.connection.createStatement();
        statement.executeUpdate(
                "CREATE TABLE ComplexTable ( id INTEGER IDENTITY, entityName VARCHAR(255), location VARCHAR(1024) )"
        );
        statement.close();

        System.out.println("HSQLDB started and database created.");
        System.out.println();
        System.out.flush();
    }

    private void createPersistenceUnit() {
        System.out.println("Creating entity manager and persistence unit.");
        this.entityManagerFactory = Persistence.createEntityManagerFactory("test-jpa-converters");
        this.entityManager = this.entityManagerFactory.createEntityManager();
        this.transaction = this.entityManager.getTransaction();
        System.out.println("Done creating entity manager and persistence unit.");
        System.out.println();
        System.out.flush();
    }

    private void persistBasicEntities() {
        System.out.println("Persisting two basic entities.");
        System.out.flush();
        try {
            this.transaction.begin();

            BasicEntity entity = new BasicEntity();
            entity.setName("Test 1");
            this.entityManager.persist(entity);
            System.out.println("Entity ID: " + entity.getId());

            entity = new BasicEntity();
            entity.setName("Test 2");
            this.entityManager.persist(entity);
            System.out.println("Entity ID: " + entity.getId());

            this.transaction.commit();

            System.out.println("Done persisting basic entities.");
        } catch (Exception e) {
            System.out.println("Error while persistent basic entities.");
            System.out.flush();
            e.printStackTrace(System.out);
        }
        System.out.println();
        System.out.flush();
    }

    private void persistComplexEntities() {
        System.out.println("Persisting two complex entities.");
        System.out.flush();
        try {
            this.transaction.begin();

            ComplexEntity entity = new ComplexEntity();
            entity.setName("Test 1");
            entity.setLocation(new StackTraceElement("com.foo.Bar", "method1", "Bar.java", 15));
            this.entityManager.persist(entity);
            System.out.println("Entity ID: " + entity.getId());

            entity = new ComplexEntity();
            entity.setName("Test 2");
            entity.setLocation(new StackTraceElement("com.bar.Foo", "method2", "Foo.java", -1));
            this.entityManager.persist(entity);
            System.out.println("Entity ID: " + entity.getId());

            this.transaction.commit();

            System.out.println("Done persisting complex entities.");
        } catch (Exception e) {
            System.out.println("Error while persistent complex entities.");
            e.printStackTrace(System.out);
        }
        System.out.println();
        System.out.flush();
    }

    private void shutDown() throws SQLException {
        System.out.println("Closing persistence unit.");
        this.transaction = null;

        if (this.entityManager != null && this.entityManager.isOpen()) {
            this.entityManager.close();
        }

        if (this.entityManagerFactory != null && this.entityManagerFactory.isOpen()) {
            this.entityManagerFactory.close();
        }
        System.out.println("Persistence unit closed.");

        System.out.println("Shutting down HSQLDB.");
        if (this.connection != null && !this.connection.isClosed()) {
            this.connection.close();
        }
        System.out.println("HSQLDB shut down.");
    }

    public static void main(String... arguments) throws Exception {
        TestClass test = new TestClass();
        test.createDatabase();
        test.createPersistenceUnit();
        test.persistBasicEntities();
        test.persistComplexEntities();
        test.shutDown();
    }
}
