package net.nicholaswilliams.java;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "ComplexTable")
public class ComplexEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    private long id;
    private String name;
    private StackTraceElement location;

    @Id
    @Basic
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "entityName")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Convert(converter = StackTraceElementAttributeConverter.class)
    public StackTraceElement getLocation() {
        return location;
    }

    public void setLocation(StackTraceElement location) {
        this.location = location;
    }
}
