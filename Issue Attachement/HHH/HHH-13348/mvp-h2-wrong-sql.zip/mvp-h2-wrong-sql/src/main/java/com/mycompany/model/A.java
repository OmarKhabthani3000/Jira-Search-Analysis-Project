package com.mycompany.model;

import static javax.persistence.CascadeType.PERSIST;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class A {

  private Long id;
  private List<B> bs;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  @OneToMany(cascade = PERSIST)
  public List<B> getBs() {
    return bs;
  }

  public void setBs(List<B> chidlren) {
    this.bs = chidlren;
  }
}
