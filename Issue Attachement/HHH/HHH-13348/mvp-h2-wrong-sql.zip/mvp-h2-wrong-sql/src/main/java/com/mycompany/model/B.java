package com.mycompany.model;

import static javax.persistence.CascadeType.PERSIST;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class B {

  private Long id;
  private A a;
  private List<C> cs;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  @ManyToOne
  @JoinColumn(name = "a_id")
  public A getA() {
    return a;
  }

  public void setA(A a) {
    this.a = a;
  }

  @OneToMany(cascade = PERSIST)
  public List<C> getCs() {
    return cs;
  }

  public void setCs(List<C> cs) {
    this.cs = cs;
  }
}
