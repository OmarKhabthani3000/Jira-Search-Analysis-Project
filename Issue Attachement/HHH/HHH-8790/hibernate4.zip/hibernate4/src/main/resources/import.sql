-- You can use this file to load seed data into the database using SQL statements
insert into MemberHibernate4Demo (id, name, email, phone_number, address, startDate) values (0, 'John Smith', 'john.smith@mailinator.com', '2125551212', 'Boston NY', '2013-10-01') 
insert into MemberHibernate4Demo (id, name, email, phone_number, address, startDate) values (1, 'Madhumita Sadhukhan', 'msadhukh@gmail.com', '2135551214', 'Brno CZ', '2013-10-02') 
insert into MemberHibernate4Demo (id, name, email, phone_number, address, startDate) values (2, 'Mickey Mouse', 'mickey@gmail.com', '2135551214', 'Brno CZ', '2013-10-03')
