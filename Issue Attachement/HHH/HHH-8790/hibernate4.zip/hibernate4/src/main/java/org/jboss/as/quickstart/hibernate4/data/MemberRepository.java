package org.jboss.as.quickstart.hibernate4.data;

import java.util.List;
import java.util.Date;
import java.util.GregorianCalendar;
import java.text.SimpleDateFormat;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TemporalType;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.Filter;
import org.jboss.as.quickstart.hibernate4.model.Member;

@ApplicationScoped
public class MemberRepository {

    @Inject
    private EntityManager em;

    public Member findById(Long id) {
        return em.find(Member.class, id);
    }

    @SuppressWarnings("unchecked")
    public List<Member> findAllOrderedByName() {
        // using Hibernate Session and Criteria Query via Hibernate Native API
        Session session = (Session) em.getDelegate();
        Criteria cb = session.createCriteria(Member.class);
        cb.addOrder(Order.asc("name"));
        return (List<Member>) cb.list();
        // return members;
    }
    
    @SuppressWarnings("unchecked")
    public List<Member> findAllOrderedByNameJPA() {
    	
    	System.out.println("findAllOrderedByNameJPA...");
    	// With GregorianCalendar the execution failed in EAP6.1, but NOT in EAP5!
    	GregorianCalendar date = new GregorianCalendar();
    	date.setTime(new Date());
    	
    	// With Date the execution successes in EAP6.1!
        Date date1 = new Date();
        
        Query query = em.createQuery("from Member where startDate <= :startdate");
        query.setParameter("startdate", date, TemporalType.TIMESTAMP);
        return query.getResultList();
        // return members;
    }
    
    @SuppressWarnings("unchecked")
    public List<Member> findAllOrderedByAddressFilter() {
    	
    	System.out.println("findAllOrderedByAddressFilter2...");
    	// With GregorianCalendar the execution failed in EAP6.1, but NOT in EAP5!
    	Session session = (Session) em.getDelegate();
    	Filter fiter = session.enableFilter("ignoreSome").setParameter("youraddress", "Brno%");
        Criteria cb = session.createCriteria(Member.class);
        
        cb.addOrder(Order.asc("name"));
        
        Query query = em.createQuery("from Member where address like :youraddress escape '\'");
        query.setParameter("youraddress", "Brno%");
        //cb.add(arg0)
        return (List<Member>) cb.list();
        //return query.getResultList();
        // return members;
    }
}
