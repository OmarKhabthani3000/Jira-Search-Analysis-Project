package hibernatebug;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
//@DiscriminatorValue("suite")
@PrimaryKeyJoinColumn(name = "parent_id")
public class InheritingEntity extends ParentEntity {

}
