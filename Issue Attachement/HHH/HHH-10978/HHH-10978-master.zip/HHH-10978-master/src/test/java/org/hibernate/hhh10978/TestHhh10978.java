package org.hibernate.hhh10978;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.junit.Test;

public class TestHhh10978 {

	private static final String DATABASE = "Test";
	private static final String PASSWORD = "Test";
	private static final String URL = "jdbc:sqlserver://localhost:1433;DatabaseName=" + TestHhh10978.DATABASE;
	private static final String USERNAME = "sa";

	@Test
	public void testHhh10978JoinTableAnnotationWithDefaultCatalog() throws Exception {
		final Configuration configuration = new Configuration();
		configuration.setProperty("hibernate.connection.driver_class", "com.microsoft.sqlserver.jdbc.SQLServerDriver");
		configuration.setProperty("hibernate.connection.password", TestHhh10978.PASSWORD);
		configuration.setProperty("hibernate.connection.url", TestHhh10978.URL);
		configuration.setProperty("hibernate.connection.username", TestHhh10978.USERNAME);
		configuration.setProperty("hibernate.current_session_context_class", "thread");
		configuration.setProperty("hibernate.default_catalog", TestHhh10978.DATABASE);
		configuration.setProperty("hibernate.hbm2ddl.auto", "validate");

		final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.applySettings(configuration.getProperties())
				.build();

		final SessionFactory sessionFactory = new MetadataSources(registry)
				.addAnnotatedClass(DaoProject.class)
				.addAnnotatedClass(DaoTask.class)
				.buildMetadata()
				.buildSessionFactory();

		try (final Session session = sessionFactory.getCurrentSession()) {
			final Transaction transaction = session.getTransaction();
			transaction.begin();

			try {
				session.createQuery("FROM DaoProject", DaoProject.class).getResultList();
			} finally {
				transaction.commit();
			}

		}

	}

	@Test
	public void testHhh10978JoinTableAnnotationWithoutDefaultCatalog() throws Exception {
		final Configuration configuration = new Configuration();
		configuration.setProperty("hibernate.connection.driver_class", "com.microsoft.sqlserver.jdbc.SQLServerDriver");
		configuration.setProperty("hibernate.connection.password", TestHhh10978.PASSWORD);
		configuration.setProperty("hibernate.connection.url", TestHhh10978.URL);
		configuration.setProperty("hibernate.connection.username", TestHhh10978.USERNAME);
		configuration.setProperty("hibernate.current_session_context_class", "thread");
		configuration.setProperty("hibernate.hbm2ddl.auto", "validate");

		final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.applySettings(configuration.getProperties())
				.build();

		final SessionFactory sessionFactory = new MetadataSources(registry)
				.addAnnotatedClass(DaoProject.class)
				.addAnnotatedClass(DaoTask.class)
				.buildMetadata()
				.buildSessionFactory();

		try (final Session session = sessionFactory.getCurrentSession()) {
			final Transaction transaction = session.getTransaction();
			transaction.begin();

			try {
				session.createQuery("FROM DaoProject", DaoProject.class).getResultList();
			} finally {
				transaction.commit();
			}

		}

	}

	@Test
	public void testHhh10978TableAnnotationWithDefaultCatalog() throws Exception {
		final Configuration configuration = new Configuration();
		configuration.setProperty("hibernate.connection.driver_class", "com.microsoft.sqlserver.jdbc.SQLServerDriver");
		configuration.setProperty("hibernate.connection.password", TestHhh10978.PASSWORD);
		configuration.setProperty("hibernate.connection.url", TestHhh10978.URL);
		configuration.setProperty("hibernate.connection.username", TestHhh10978.USERNAME);
		configuration.setProperty("hibernate.current_session_context_class", "thread");
		configuration.setProperty("hibernate.default_catalog", TestHhh10978.DATABASE);
		configuration.setProperty("hibernate.hbm2ddl.auto", "validate");

		final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.applySettings(configuration.getProperties())
				.build();

		final SessionFactory sessionFactory = new MetadataSources(registry)
				.addAnnotatedClass(DaoTask.class)
				.buildMetadata()
				.buildSessionFactory();

		try (final Session session = sessionFactory.getCurrentSession()) {
			final Transaction transaction = session.getTransaction();
			transaction.begin();

			try {
				session.createQuery("FROM DaoTask", DaoTask.class).getResultList();
			} finally {
				transaction.commit();
			}

		}

	}

	@Test
	public void testHhh10978TableAnnotationWithoutDefaultCatalog() throws Exception {
		final Configuration configuration = new Configuration();
		configuration.setProperty("hibernate.connection.driver_class", "com.microsoft.sqlserver.jdbc.SQLServerDriver");
		configuration.setProperty("hibernate.connection.password", TestHhh10978.PASSWORD);
		configuration.setProperty("hibernate.connection.url", TestHhh10978.URL);
		configuration.setProperty("hibernate.connection.username", TestHhh10978.USERNAME);
		configuration.setProperty("hibernate.current_session_context_class", "thread");
		configuration.setProperty("hibernate.hbm2ddl.auto", "validate");

		final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.applySettings(configuration.getProperties())
				.build();

		final SessionFactory sessionFactory = new MetadataSources(registry)
				.addAnnotatedClass(DaoTask.class)
				.buildMetadata()
				.buildSessionFactory();

		try (final Session session = sessionFactory.getCurrentSession()) {
			final Transaction transaction = session.getTransaction();
			transaction.begin();

			try {
				session.createQuery("FROM DaoTask", DaoTask.class).getResultList();
			} finally {
				transaction.commit();
			}

		}

	}

}
