package org.hibernate.hhh10978;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(schema = "schema1", name = "Project")
public class DaoProject {

	private Integer id;
	private String name;
	private List<DaoTask> tasks;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	public Integer getId() {
		return id;
	}

	public void setId(final Integer id) {
		this.id = id;
	}

	@Column(name = "Name", length = 64, nullable = false)
	public String getName() {
		return name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	@OneToMany
	@JoinTable(schema = "schema1", name = "Project_Tasks",
		joinColumns = @JoinColumn(name = "Project_ID"),
		inverseJoinColumns = @JoinColumn(name = "Task_ID"))
	public List<DaoTask> getTasks() {
		return tasks;
	}

	public void setTasks(final List<DaoTask> tasks) {
		this.tasks = tasks;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (name == null ? 0 : name.hashCode());
		result = prime * result + (tasks == null ? 0 : tasks.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final DaoProject other = (DaoProject) obj;
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		} else if (!name.equals(other.name)) {
			return false;
		}
		if (tasks == null) {
			if (other.tasks != null) {
				return false;
			}
		} else if (!tasks.equals(other.tasks)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("DaoProject [id=").append(id)
			.append(", name=").append(name)
			.append(", tasks=").append(tasks).append("]");
		return builder.toString();
	}

}
