# Unit Tests for https://hibernate.atlassian.net/browse/HHH-10978

Download the Microsoft JDBC Driver 6.0 for SQL Server (`sqljdbc_6.0.7507.100_enu.tar.gz`) from:

https://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=11774

Copy the `sqljdbc42.jar` into the `lib` directory.

You must set all constants in TestHhh10978:
```java
private static final String DATABASE = "YOUR_DATABASE";
private static final String PASSWORD = "YOUR_DB_PASSWORD";
private static final String URL = "jdbc:sqlserver://YOUR_DB_HOST:YOUR_DB_PORT;DatabaseName=" + TestHhh10978.DATABASE;
private static final String USERNAME = "YOUR_DB_USERNAME";
```

Your database must be prepared:

```sql
USE YOUR_DATABASE;
GO

CREATE SCHEMA schema1;
GO

CREATE TABLE schema1.Task(
  ID INT IDENTITY NOT NULL,
  NAME VARCHAR(64) NOT NULL,
  PRIMARY KEY(ID)
);

CREATE TABLE schema1.Project(
  ID INT IDENTITY NOT NULL,
  NAME VARCHAR(64) NOT NULL,
  PRIMARY KEY(ID)
);

CREATE TABLE schema1.Project_Tasks(
  PROJECT_ID INT NOT NULL,
  TASK_ID INT NOT NULL,
  PRIMARY KEY(PROJECT_ID, TASK_ID)
);
GO
```
