CREATE TABLE `demo_table`
(
    `id`         BIGINT NOT NULL,
    `year_month` INT(6) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci;