package com.demo.hhh16241;

import jakarta.persistence.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.*;
import org.testcontainers.containers.MariaDBContainer;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.time.YearMonth;

@SpringBootTest
@ActiveProfiles("test")
@TestPropertySource(locations = "classpath:application.yml")
@Testcontainers
class Hhh16241ApplicationTests {

	private static final MariaDBContainer<?> mariaDBContainer = new MariaDBContainer<>("mariadb:10.4.26")
			.withDatabaseName("demodb")
			.withUsername("demouser")
			.withPassword("demopwd")
			.withCommand("--character-set-server=utf8mb4", "--collation-server=utf8mb4_unicode_ci");

	@DynamicPropertySource
	static void properties(DynamicPropertyRegistry registry) {
		mariaDBContainer.start();
		registry.add("spring.datasource.url", mariaDBContainer::getJdbcUrl);
		registry.add("spring.datasource.username", mariaDBContainer::getUsername);
		registry.add("spring.datasource.password", mariaDBContainer::getPassword);
	}

	@Autowired
	private EntityManagerFactory entityManagerFactory;

	@Test
	void test_HHH_16241_persist() {
		var entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(new DemoEntity(1L, YearMonth.of(2022, 12)));
		entityManager.persist(new DemoEntity(2L, YearMonth.of(2023, 1)));
		entityManager.persist(new DemoEntity(3L, YearMonth.of(2023, 2)));
		entityManager.persist(new DemoEntity(4L, YearMonth.of(2023, 3)));
		Assertions.assertThrows(RollbackException.class, () -> entityManager.getTransaction().commit());
	}

	@Test
	void test_HHH_16241_max(@Autowired EntityManager entityManager) {
		Assertions.assertThrows(IllegalArgumentException.class, () -> entityManager.createQuery("SELECT MAX(de.yearMonth) FROM DemoEntity de"));
	}
}
