package com.demo.hhh16241;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
import java.time.YearMonth;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "demo_table")
public class DemoEntity implements Serializable {
    @Id
    @Column(name = "id")
    private long id;
    @Convert(converter = YearMonthConverter.class)
    @Column(name = "year_month")
    private YearMonth yearMonth;
}
