package com.demo.hhh16241;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hhh16241Application {

	public static void main(String[] args) {
		SpringApplication.run(Hhh16241Application.class, args);
	}

}
