package eu.iunxi.test;

import java.sql.DriverManager;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author fred
 */
public class LazyCollectionTest {
    
    protected static EntityManagerFactory emf;

    public LazyCollectionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        emf = Persistence.createEntityManagerFactory("test");
    }
    
    @AfterClass
    public static void tearDownClass() {
        if(emf != null && emf.isOpen())
        {
            emf.close();
        }

        try
        {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver").newInstance();
            DriverManager.getConnection("jdbc:derby:memory:test;drop=true");
        }
        catch(Exception e)
        {
            //e.printStackTrace();
        }
    }
    
    @Before
    public void setUp() {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        ParentEntity parent = new ParentEntity();
        parent.addChild(new ChildEntity());
        parent.addChild(new ChildEntity());
        parent.addChild(new ChildEntity());
        em.persist(parent);

        tx.commit();
        em.close();
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void test() {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<ParentEntity> q = cb.createQuery(ParentEntity.class);
        Root<ParentEntity> parentRoot = q.from(ParentEntity.class);
        CriteriaQuery<ParentEntity> parentSelect = q.select(parentRoot);
        
        ParentEntity parent = em.createQuery(parentSelect).getSingleResult();
        assertEquals(3, parent.getChildren().size());

        tx.commit();
        em.close();
    }
}
