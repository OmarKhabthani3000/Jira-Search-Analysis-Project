package eu.iunxi.test;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

/**
 *
 * @author fred
 */
@Entity
public class ParentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    public Long getId() {
        return id;
    }

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "parent")
    @LazyCollection(LazyCollectionOption.EXTRA)
    private Set<ChildEntity> children = new HashSet<>();

    public Set<ChildEntity> getChildren() {
        return Collections.unmodifiableSet(children);
    }

    public void addChild(ChildEntity child) {
        if (children.add(child)) {
            child.setParent(this);
        }
    }
}
