package eu.iunxi.test;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 *
 * @author fred
 */
@Entity
public class ChildEntity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    public Long getId() {
        return id;
    }

    @ManyToOne
    private ParentEntity parent;

    public ParentEntity getParent() {
        return parent;
    }

    public void setParent(ParentEntity parent) {
        // break recursion
        if (parent == this.parent) {
            return;
        }
        if (this.parent != null) {
            throw new IllegalArgumentException();
        }
        this.parent = parent;
        parent.addChild(this);
    }
}
