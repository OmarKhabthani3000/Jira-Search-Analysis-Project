package com.sia.hibernate.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;


@Entity(name="Garanz")
@Table(name = "GARANZ")
@org.hibernate.annotations.Entity(
		optimisticLock = org.hibernate.annotations.OptimisticLockType.ALL,
		dynamicUpdate=true
)
public class Garanz implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private Long idGar;
	private Integer codMax;

	private Integer nRis;
	private String unMisura;

	public Garanz() {
	}

	public Garanz(Long idGar) {
		this.idGar = idGar;
	}


	@Id
	@Column(name = "ID_GAR", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getIdGar() {
		return this.idGar;
	}

	public void setIdGar(Long idGar) {
		this.idGar = idGar;
		
	}

	@Column(name = "N_RIS", precision = 5, scale = 0)
	public Integer getNRis() {
		return this.nRis;
	}

	public void setNRis(Integer nRis) {
		this.nRis = nRis;
	}

	@Column(name = "COD_MAX", precision = 5, scale = 0)
	public Integer getCodMax() {
		return this.codMax;
	}

	public void setCodMax(Integer codMax) {
		this.codMax = codMax;
	}

	@Column(name = "UN_MISURA", length = 2)
	public String getUnMisura() {
		return this.unMisura;
	}

	public void setUnMisura(String unMisura) {
		this.unMisura = unMisura;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		Garanz garanz = (Garanz) o;

		return idGar != null ? idGar.equals(garanz.idGar) : garanz.idGar == null;
	}

	@Override
	public int hashCode() {
		return idGar != null ? idGar.hashCode() : 0;
	}
}
