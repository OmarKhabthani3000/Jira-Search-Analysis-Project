package com.sia.hibernate.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class HibernateSupport {

    private static EntityManagerFactory emf;
    private EntityManager em;

    static {
        try {
            Class.forName("oracle.jdbc.OracleDriver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public void begin() {
        getEm().getTransaction().begin();
    }

    public void end() {
        end(false);
    }

    public void end(boolean commit) {
        if (getEm().isOpen()) {
            getEm().flush();
            if (commit) {
                getEm().getTransaction().commit();
            } else {
                getEm().getTransaction().rollback();
            }

            getEm().close();
        }
    }

    public static EntityManagerFactory getEmf() {
        if (emf ==  null) {
            try {
                emf = Persistence.createEntityManagerFactory("testDatabase");
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return emf;
    }

    public EntityManager getEm() {
        if (em == null) {
            em = getEmf().createEntityManager();
        }

        return em;
    }
}
