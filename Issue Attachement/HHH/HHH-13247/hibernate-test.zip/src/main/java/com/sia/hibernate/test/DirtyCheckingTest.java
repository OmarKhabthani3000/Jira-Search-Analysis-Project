package com.sia.hibernate.test;


import com.sia.hibernate.entity.Garanz;

import javax.persistence.EntityManager;

public class DirtyCheckingTest {

    private HibernateSupport hibSupport;

    public static void main(String[] args) {
        DirtyCheckingTest dirtyCheckingTest = new DirtyCheckingTest();
        dirtyCheckingTest.test();
    }

    private void test() {
        hibSupport = new HibernateSupport();

        hibSupport.begin();
        try {
            Garanz g = getEm().find(Garanz.class, 51777L);
            g.setNRis(g.getNRis() + 1);
           // g.setCodMax(g.getCodMax() + 1);
            getEm().flush();
        } finally {
            hibSupport.end(false);
        }
    }

    private EntityManager getEm() {
        return hibSupport.getEm();
    }
}