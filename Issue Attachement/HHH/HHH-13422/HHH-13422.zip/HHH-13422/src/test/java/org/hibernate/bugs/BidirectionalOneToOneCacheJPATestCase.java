package org.hibernate.bugs;

import org.hibernate.SessionFactory;
import org.hibernate.bugs.model.Post;
import org.hibernate.bugs.model.PostDetails;
import org.hibernate.testing.TestForIssue;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import static org.junit.Assert.assertEquals;

@TestForIssue(jiraKey = "HHH-13422")
public class BidirectionalOneToOneCacheJPATestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");

        EntityManager entityManager = entityManagerFactory.createEntityManager();

        entityManager.getTransaction().begin();
        Post post = new Post("First post");
        PostDetails details = new PostDetails("John Doe");

        post.setDetails(details);
        details.setPost(post);

        entityManager.persist(post);
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    @After
    public void destroy() {
        entityManagerFactory.close();
    }

    @Test
    public void testHHH13422() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        // PUT OBJECTS IN CACHE
        entityManager.getTransaction().begin();
        {
            // this should put both post and postdetails in L2 cache
            Post post = entityManager.find(Post.class, 1L);
            PostDetails postDetails = entityManager.find(PostDetails.class, 2L);

            assertEquals(new Long(1), post.getId());
            assertEquals(new Long(2), postDetails.getId());
        }
        entityManager.getTransaction().commit();
        entityManager.close();

        // RETRIEVE FROM CACHE - FIND OWNER OF RELATIONSHIP
        entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        {
            long postCacheHits = getPostCacheHits();
            long postDetailsCacheHits = getPostDetailsCacheHits();


            // this should retrieve both post and postdetails from L2 cache
            PostDetails postDetails = entityManager.find(PostDetails.class, 2L);

            assertEquals(postCacheHits + 1, getPostCacheHits());
            assertEquals(postDetailsCacheHits + 1, getPostDetailsCacheHits());
        }
        entityManager.getTransaction().commit();
        entityManager.close();

        // RETRIEVE FROM CACHE - FIND INVERSE SIDE
        entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        {
            long postCacheHits = getPostCacheHits();
            long postDetailsCacheHits = getPostDetailsCacheHits();

            // this should retrieve both post and postdetails from L2 cache
            Post post = entityManager.find(Post.class, 1L);

            assertEquals(postCacheHits + 1, getPostCacheHits());

            // this fails
            assertEquals(postDetailsCacheHits + 1, getPostDetailsCacheHits());
        }
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    private long getCacheHits(Class clazz) {
        return (entityManagerFactory.unwrap(SessionFactory.class)).getStatistics().getDomainDataRegionStatistics(clazz.getName()).getHitCount();
    }

    private long getPostCacheHits() {
        return getCacheHits(Post.class);
    }

    private long getPostDetailsCacheHits() {
        return getCacheHits(PostDetails.class);
    }
}
