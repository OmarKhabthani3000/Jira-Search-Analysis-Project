/*
 *  © Stratégies
 */

package com.cadwin.testpufromscratch;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.hibernate.cfg.AvailableSettings;


/**
 *
 * @author Stratégies
 */
public class TestPU {

    private static final org.apache.log4j.Logger LOGGER = Logger.getLogger(TestPU.class);

    static final Properties properties = new Properties();

    static {
        properties.put(AvailableSettings.JAKARTA_PERSISTENCE_PROVIDER, "org.hibernate.jpa.HibernatePersistenceProvider");
        properties.put(AvailableSettings.USE_SECOND_LEVEL_CACHE, "false");
        properties.put(AvailableSettings.LOG_SESSION_METRICS, "true");
        properties.put(AvailableSettings.GENERATE_STATISTICS, "true");
    }

    private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("RCSDMStandaloneTestPU4", properties);

    public static void main(String[] args) {
        emf.getProperties().forEach((final String t, final Object u) -> {
            LOGGER.info(String.format("N:%s V%s", t, u));
        });
        final EntityManager em = emf.createEntityManager();
        //final Reference r = em.find(Reference.class, BigDecimal.ONE);
        //LOGGER.info(r.getErpDescr());
    }
}
