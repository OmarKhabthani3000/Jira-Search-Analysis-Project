package com.cadwin.rcsdm.pu.entities;


import jakarta.persistence.Basic;
import java.io.Serializable;
import java.util.Collection;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import jakarta.persistence.Table;

/**
 *
 * @author StratÃ©gies
 */
@Entity
@Table(name = "MY_ENTITY")

public class MyEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Id
    private Integer id;

    // Comment out the line below to complete PU initialization 
    Collection<MySubEntity> mySubEntity;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

}
