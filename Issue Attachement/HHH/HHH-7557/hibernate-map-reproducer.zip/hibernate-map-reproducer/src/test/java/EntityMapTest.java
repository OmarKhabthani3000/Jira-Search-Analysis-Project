import java.util.HashMap;
import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Environment;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.orm.hibernate3.annotation.AnnotationSessionFactoryBean;


public class EntityMapTest {

    SessionFactory sessionFactory;
    Session session;
    Transaction tx;

    @Before
    public void setUp() throws Exception {
        // Let Spring set up an embedded database for us
        AnnotationSessionFactoryBean sessionFactoryBean = new AnnotationSessionFactoryBean();
        sessionFactoryBean.setDataSource(new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.HSQL).build());
        // Add our annotated entity classes
        sessionFactoryBean.setAnnotatedClasses(new Class[]{MapKey.class,MapHolder.class,MapValue.class});
        Properties hibernateProperties = new Properties();
        // Show the SQL (you can see the deletes being issued)
        hibernateProperties.setProperty(Environment.SHOW_SQL, "true");
        // Create the schema automatically
        hibernateProperties.setProperty(Environment.HBM2DDL_AUTO, "update");
        sessionFactoryBean.setHibernateProperties(hibernateProperties);
        // Let Spring build us a SessionFactory
        sessionFactoryBean.afterPropertiesSet();
        sessionFactory = sessionFactoryBean.getObject();
    }

    @Test
    public void testInsertIntoMap() throws Exception {

        // Session 1: Insert 3 values into the map
        beginSession();
        MapHolder mapHolder = new MapHolder();
        mapHolder.setMap(new HashMap<MapKey,MapValue>());
        addMapEntry(mapHolder, "A", "1");
        addMapEntry(mapHolder, "B", "2");
        addMapEntry(mapHolder, "C", "3");
        session.save(mapHolder);
        // Verify there are 3 entries in the map
        Assert.assertEquals(3, mapHolder.getMap().size());
        Long mapHolderId = mapHolder.getId();
        endSession();

        // Session 2: Add a 4th value to the map
        beginSession();
        mapHolder = (MapHolder) session.get(MapHolder.class, mapHolderId);
        addMapEntry(mapHolder, "D", "4");
        // Verify there are 4 entries in the map
        Assert.assertEquals(4, mapHolder.getMap().size());
        endSession();

        // Session 3: Count the entries in the map
        beginSession();
        mapHolder = (MapHolder) session.get(MapHolder.class, mapHolderId);
        // Fails here (expected:<4> but was:<1>)
        Assert.assertEquals(4, mapHolder.getMap().size());
        endSession();
    }

    private void addMapEntry(MapHolder mapHolder, String key, String value) {
        System.out.println("Inserting ("+key+","+value+") into map");
        MapValue entityValue = new MapValue(value);
        session.save(entityValue);
        MapKey entityKey = new MapKey(key, entityValue);
        session.save(entityKey);
        mapHolder.getMap().put(entityKey, entityValue);
    }

    private void beginSession() {
        System.out.println("--- session begin ---");
        session = sessionFactory.openSession();
        tx = session.beginTransaction();
    }

    private void endSession() {
        tx.commit();
        session.close();
        System.out.println("--- session end ---");
    }
}
