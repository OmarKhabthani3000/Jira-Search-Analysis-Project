import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="map_value")
public class MapValue {

    private Long id;
    private String name;

    public MapValue() {}
    public MapValue(String name) {
        this.name = name;
    }

    @Id
    @GeneratedValue
    @Column(name="id", unique=true, nullable=false)
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    @Column(name="name", unique=true, nullable=false)
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if(this == obj) {
            return true;
        }
        if(obj == null) {
            return false;
        }
        if(!(obj instanceof MapValue)) {
            return false;
        }
        MapValue other = (MapValue) obj;
        if(getName() == null) {
            if(other.getName() != null) {
                return false;
            }
        } else if(!getName().equals(other.getName())) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("MapValue [id=").append(getId()).append(", name=").append(getName()).append("]");
        return builder.toString();
    }

}
