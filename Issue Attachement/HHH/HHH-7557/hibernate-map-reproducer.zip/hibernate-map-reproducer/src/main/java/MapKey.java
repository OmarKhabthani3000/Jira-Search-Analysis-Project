import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="map_key", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"name","default_map_value_id"})
})
public class MapKey {

    private Long id;
    private String name;
    private MapValue defaultValue;

    public MapKey() {}
    public MapKey(String name, MapValue defaultValue) {
        this.name = name;
        this.defaultValue = defaultValue;
    }

    @Id
    @GeneratedValue
    @Column(name="id", unique=true, nullable=false)
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    @Column(name="name", nullable=false)
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="default_map_value_id", nullable=false)
    public MapValue getDefaultValue() {
        return defaultValue;
    }
    public void setDefaultValue(MapValue defaultValue) {
        this.defaultValue = defaultValue;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getDefaultValue() == null) ? 0 : getDefaultValue().hashCode());
        result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if(this == obj) {
            return true;
        }
        if(obj == null) {
            return false;
        }
        if(!(obj instanceof MapKey)) {
            return false;
        }
        MapKey other = (MapKey) obj;
        if(getDefaultValue() == null) {
            if(other.getDefaultValue() != null) {
                return false;
            }
        } else if(!getDefaultValue().equals(other.getDefaultValue())) {
            return false;
        }
        if(getName() == null) {
            if(other.getName() != null) {
                return false;
            }
        } else if(!getName().equals(other.getName())) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("MapKey [id=").append(getId())
        .append(", name=").append(getName())
        .append(", defaultValue=").append(getDefaultValue())
        .append("]");
        return builder.toString();
    }

}
