package data;
import java.util.Calendar;

public class Donut {
	private Calendar duh;
	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Calendar getDuh() {
		return duh;
	}

	public void setDuh(Calendar duh) {
		this.duh = duh;
	}
	
}
