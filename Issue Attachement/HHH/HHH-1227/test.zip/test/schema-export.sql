alter table foo drop foreign key FK18CC617581076
drop table if exists bar
drop table if exists donut
drop table if exists foo
create table bar (bar_id varchar(255) not null, primary key (bar_id))
create table donut (id varchar(255) not null, duh date, primary key (id))
create table foo (foo_id varchar(255) not null, prop1 varchar(255), bar_id varchar(255), foo_index integer, primary key (foo_id))
alter table foo add index FK18CC617581076 (bar_id), add constraint FK18CC617581076 foreign key (bar_id) references bar (bar_id)
