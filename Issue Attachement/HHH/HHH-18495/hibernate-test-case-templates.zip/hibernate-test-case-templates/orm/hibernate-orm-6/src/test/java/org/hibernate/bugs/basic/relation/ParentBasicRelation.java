package org.hibernate.bugs.basic.relation;

import jakarta.persistence.*;

@Entity
class ParentBasicRelation {

	@Id
	private int id;

	@OneToOne(cascade = CascadeType.ALL)
	private ChildBasicRelation child;

	public ParentBasicRelation() {}

	public ParentBasicRelation(int id, ChildBasicRelation child) {
		this.id = id;
		this.child = child;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ChildBasicRelation getChild() {
		return child;
	}

	public void setChild(ChildBasicRelation child) {
		this.child = child;
	}
}
