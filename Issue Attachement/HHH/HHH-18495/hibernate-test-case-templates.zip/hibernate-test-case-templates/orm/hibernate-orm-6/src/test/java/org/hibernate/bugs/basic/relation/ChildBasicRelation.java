package org.hibernate.bugs.basic.relation;

import jakarta.persistence.*;

@Entity
class ChildBasicRelation {

	@Id
	private int id;

	private int parentId;

	public ChildBasicRelation() {}

	public ChildBasicRelation(int id, int parentId) {
		this.id = id;
		this.parentId = parentId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

}
