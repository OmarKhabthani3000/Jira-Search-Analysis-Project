package org.hibernate.bugs.mapped.by;

import jakarta.persistence.*;

@Entity
class ParentMappedBy {

	@Id
	private int id;

	@OneToOne(mappedBy = "parentId", cascade = CascadeType.ALL)
	private ChildMappedBy child;

	public ParentMappedBy() {}

	public ParentMappedBy(int id, ChildMappedBy child) {
		this.id = id;
		this.child = child;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ChildMappedBy getChild() {
		return child;
	}

	public void setChild(ChildMappedBy child) {
		this.child = child;
	}
}
