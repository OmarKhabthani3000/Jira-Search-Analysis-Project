package org.hibernate.bugs.mapped.by;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
class ChildMappedBy {

	@Id
	private int id;

	private int parentId;

	public ChildMappedBy() {}

	public ChildMappedBy(int id, int parentId) {
		this.id = id;
		this.parentId = parentId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

}
