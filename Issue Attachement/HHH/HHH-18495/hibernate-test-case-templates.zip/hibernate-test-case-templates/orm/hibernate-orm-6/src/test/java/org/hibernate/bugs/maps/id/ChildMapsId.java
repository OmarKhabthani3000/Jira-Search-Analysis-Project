package org.hibernate.bugs.maps.id;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
class ChildMapsId {

	@Id
	private int id;

	private int parentId;

	public ChildMapsId() {}

	public ChildMapsId(int id, int parentId) {
		this.id = id;
		this.parentId = parentId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

}
