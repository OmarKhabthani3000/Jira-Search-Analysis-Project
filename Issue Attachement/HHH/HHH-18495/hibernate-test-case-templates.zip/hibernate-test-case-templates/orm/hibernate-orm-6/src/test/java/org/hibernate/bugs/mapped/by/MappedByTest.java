/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs.mapped.by;

import org.flywaydb.core.Flyway;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.testing.orm.junit.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

@DomainModel(annotatedClasses = { ChildMappedBy.class, ParentMappedBy.class })
@ServiceRegistry(
	settings = {
		@Setting(name = AvailableSettings.SHOW_SQL, value = "true"),
		@Setting(name = AvailableSettings.FORMAT_SQL, value = "true"),
	}
)
@SessionFactory
class MappedByTest {

	@BeforeEach
	void setUp() {
		Flyway.configure()
			.dataSource("jdbc:h2:mem:db1", "sa", "")
			.load()
			.migrate();
	}

	@Test
	void mappedBySeemsToRequireBidirectionalRelationship(SessionFactoryScope scope) throws Exception {
		scope.inTransaction(session -> {
			int parentId = 1;
			int child = 1;
			ParentMappedBy parent = new ParentMappedBy(parentId, new ChildMappedBy(child, parentId));
			session.persist(parent);
		});
	}
}
