-- Basic relation tables
create table ParentBasicRelation
(
    id integer primary key
);

create table ChildBasicRelation
(
    id       integer primary key,
    parentId integer unique not null,
    foreign key (parentId) references ParentBasicRelation (id)
);

-- @JoinColumn tables
create table ParentJoinColumn
(
    id integer primary key
);

create table ChildJoinColumn
(
    id       integer primary key,
    parentId integer unique not null,
    foreign key (parentId) references ParentJoinColumn (id)
);

-- mappedBy tables
create table ParentMappedBy
(
    id integer primary key
);

create table ChildMappedBy
(
    id       integer primary key,
    parentId integer unique not null,
    foreign key (parentId) references ParentMappedBy (id)
);

-- @MapsId tables
create table ParentMapsId
(
    id integer primary key
);

create table ChildMapsId
(
    id       integer primary key,
    parentId integer unique not null,
    foreign key (parentId) references ParentMapsId (id)
);