package org.hibernate.bugs.join.column;

import jakarta.persistence.*;

@Entity
class ParentJoinColumn {

	@Id
	private int id;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "id", referencedColumnName = "parentId", insertable = false, updatable = false)
	private ChildJoinColumn child;

	public ParentJoinColumn() {}

	public ParentJoinColumn(int id, ChildJoinColumn child) {
		this.id = id;
		this.child = child;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ChildJoinColumn getChild() {
		return child;
	}

	public void setChild(ChildJoinColumn child) {
		this.child = child;
	}
}
