package org.hibernate.bugs.maps.id;

import jakarta.persistence.*;

@Entity
class ParentMapsId {

	@Id
	private Integer id;

	@OneToOne(cascade = CascadeType.ALL)
	@MapsId
	private ChildMapsId child;

	public ParentMapsId() {}

	public ParentMapsId(int id, ChildMapsId child) {
		this.id = id;
		this.child = child;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ChildMapsId getChild() {
		return child;
	}

	public void setChild(ChildMapsId child) {
		this.child = child;
	}
}
