package org.hibernate.bugs.join.column;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
class ChildJoinColumn {

	@Id
	private int id;

	private int parentId;

	public ChildJoinColumn() {}

	public ChildJoinColumn(int id, int parentId) {
		this.id = id;
		this.parentId = parentId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

}
