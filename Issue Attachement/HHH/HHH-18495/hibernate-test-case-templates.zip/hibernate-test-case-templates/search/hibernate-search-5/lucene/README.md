# Hibernate Test Case Templates: Hibernate Search with embedded Lucene

This directory contains a test case template for Hibernate Search
backed with an embedded Lucene engine.

You can run the integration tests:
* either using the command line with: `mvn verify`;
* or directly from your IDE. 
