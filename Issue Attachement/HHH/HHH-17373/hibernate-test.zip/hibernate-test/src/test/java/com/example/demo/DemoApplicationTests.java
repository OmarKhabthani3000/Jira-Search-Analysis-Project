package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApplicationTests {

	@Autowired
	private HumanRepository humanRepository;

	@Test
	void contextLoads() {
	}

	@Test
	void inserts() {

		humanRepository.saveAndFlush(new Human());
		humanRepository.saveAndFlush(new Human());
		humanRepository.saveAndFlush(new Human());
	}

}
