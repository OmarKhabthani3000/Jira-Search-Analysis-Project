package union;

public class UnionTableOneExt extends UnionTableOne {
  private String extName;

  public String getExtName() {
    return extName;
  }

  public void setExtName(String extName) {
    this.extName = extName;
  }
}
