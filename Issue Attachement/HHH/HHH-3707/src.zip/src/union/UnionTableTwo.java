package union;

public class UnionTableTwo extends UnionTable {
  private String twoName;

  public String getTwoName() {
    return twoName;
  }

  public void setTwoName(String twoName) {
    this.twoName = twoName;
  }
}
