package union;

public class UnionTable extends
    com.ebao.pub.ccp.service.ems.entity.impl.EntityImpl implements
    java.io.Serializable {
  Integer unionId;

  public Integer getUnionId() {
    return unionId;
  }

  public void setUnionId(Integer unionId) {
    this.unionId = unionId;
  }
  
}
