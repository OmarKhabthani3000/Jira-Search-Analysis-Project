package union;

public class UnionTableOne extends UnionTable {
  private String oneName;

  public String getOneName() {
    return oneName;
  }

  public void setOneName(String oneName) {
    this.oneName = oneName;
  }
  
}
