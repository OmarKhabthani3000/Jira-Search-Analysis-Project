package union;

import static org.junit.Assert.fail;

import javax.transaction.UserTransaction;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ebao.ls.foundation.dao.support.DaoSupportEntityName;
import com.ebao.pub.util.Trans;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
public class UnionTableDAOTest {
  @Autowired
  @Qualifier("UnionTableDAO")
  private DaoSupportEntityName<UnionTableOneExt> dao;

  //@Test
  public void testLoad() throws Exception {
  }

  @Test
  public void testSave() throws Exception {
    UserTransaction ut = null;
    try {
      ut = Trans.getUserTransaction();
      ut.begin();
      UnionTableOneExt unionTableTwoExt = new UnionTableOneExt();
      unionTableTwoExt.setOneName("oneName");
      unionTableTwoExt.setExtName("extName");
      unionTableTwoExt.setUnionId(1);
      dao.save(unionTableTwoExt);
      System.err.println(unionTableTwoExt.getUnionId());
      dao.getSession().flush();
      ut.commit();
    } catch (Exception e) {
      if (ut != null) {
        try {
          ut.rollback();
        } catch (Exception e1) {
        }
      }
      throw e;
    }
  }

  // @Test
  public void testFindById() {
    fail("Not yet implemented");
  }
}
