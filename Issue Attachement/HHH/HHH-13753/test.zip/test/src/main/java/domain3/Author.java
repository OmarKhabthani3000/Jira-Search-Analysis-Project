package domain3;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "author3")
public class Author implements Serializable {
	private static final long serialVersionUID = -7667631097433617300L;

	@Id
	@Access(AccessType.PROPERTY)
	private Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
