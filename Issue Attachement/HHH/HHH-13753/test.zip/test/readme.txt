Run mvn compile
Inpect the generated metamodel in target/generated-sources/annotations/*/Book_.java