/*******************************************************************************
 * Copyright: DOCUFY GmbH (c) 2015
 * Company: DOCUFY GmbH,
 *          Kapuzinerstraße 32,
 *          96047 Bamberg
 *          http://www.docufy.de
 * $LastChangedBy: philipp $
 * $LastChangedDate: 2015-02-03 18:26:15 +0100 (Di, 03 Feb 2015) $
 * $HeadURL: svn://svn.docufy.de/supplemental/philipp/fastlane2/trunk/fastlane-persistence/fastlane-cmsjpa/src/main/java/de/docufy/fastlane/cmsjpa/model/BaseModel.java $
 * $LastChangedRevision: 2275 $
 *******************************************************************************/
package model;

import java.io.Serializable;

import javax.persistence.MappedSuperclass;
import javax.persistence.PostLoad;
import javax.persistence.PostPersist;
import javax.persistence.Transient;

/**
 * Base class for models implementing {@link Persistable}
 * @author Joachim
 */
@MappedSuperclass
public abstract class BaseModel<ID extends Serializable> {

	private static final long serialVersionUID = 2570902832245532287L;

	@Transient
	private boolean isNew = false;

	/**
	 * @return the id
	 */
	public abstract ID getId();

	/**
	 * @return the isNew
	 */
	public boolean isNew() {
		return isNew;
	}

	/**
	 * @param isNew the isNew to set
	 */
	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	@PostPersist
	public void onPostPersist() {
		isNew = false;
	}

	@PostLoad
	public void onPostLoad() {
		isNew = false;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		BaseModel<?> other = (BaseModel<?>) obj;
		if (getId() == null) {
			if (other.getId() != null) {
				return false;
			}
		} else if (!getId().equals(other.getId())) {
			return false;
		}
		return true;
	}
}
