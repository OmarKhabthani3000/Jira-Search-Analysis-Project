package model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author Philipp
 * @author Joachim
 */
@Entity
@Table(name="revision")
public class IoRevisionModel extends BaseModel<IoRevisionPk> {

	private static final long serialVersionUID = -8146676627579077482L;

	@EmbeddedId
	private IoRevisionPk pk;

	@Column(name="rv_description")
	private String description;

	@Column(name="rv_size")
	private long size;

	/**
	 * @return the pk
	 */
	public IoRevisionPk getPk() {
		return pk;
	}

	/**
	 * @param pk the pk to set
	 */
	public void setPk(IoRevisionPk pk) {
		this.pk = pk;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the size
	 */
	public long getSize() {
		return size;
	}

	/**
	 * @param size the size to set
	 */
	public void setSize(long size) {
		this.size = size;
	}

	/* (non-Javadoc)
	 * @see org.springframework.data.domain.Persistable#getId()
	 */
	@Override
	public IoRevisionPk getId() {
		return getPk();
	}
}
