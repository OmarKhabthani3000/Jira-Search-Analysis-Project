package model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;


/**
 * @author Philipp
 */
@Embeddable
public class IoRevisionPk implements Serializable {

	private static final long serialVersionUID = -673069104614132111L;

	@Column(name="io_id", length=32)
	private String io;

	@Column(name="iov_number")
	private int version;

	@Column(name="ln_code", length=2)
	private String language;

	@Column(name="vr_code", length=2)
	private String variant;

	@Column(name="ft_id", length=32)
	private String format;

	@Column(name="rv_number")
	private int revision;

	/**
	 * 
	 */
	protected IoRevisionPk() {
		// Needed for JPA
	}

	/**
	 * @param io
	 * @param version
	 * @param language
	 * @param variant
	 * @param format
	 * @param revision
	 */
	public IoRevisionPk(String io, int version, String language, String variant,
			String format, int revision) {
		this.io = io;
		this.version = version;
		this.language = language;
		this.variant = variant;
		this.format = format;
		this.revision = revision;
	}

	/**
	 * @return the io
	 */
	public String getIo() {
		return io;
	}

	/**
	 * @param io the io to set
	 */
	public void setIo(String io) {
		this.io = io;
	}

	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}

	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * @return the variant
	 */
	public String getVariant() {
		return variant;
	}

	/**
	 * @param variant the variant to set
	 */
	public void setVariant(String variant) {
		this.variant = variant;
	}

	/**
	 * @return the format
	 */
	public String getFormat() {
		return format;
	}

	/**
	 * @param format the format to set
	 */
	public void setFormat(String format) {
		this.format = format;
	}

	/**
	 * @return the revision
	 */
	public int getRevision() {
		return revision;
	}

	/**
	 * @param revision the revision to set
	 */
	public void setRevision(int revision) {
		this.revision = revision;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((format == null) ? 0 : format.hashCode());
		result = prime * result + ((io == null) ? 0 : io.hashCode());
		result = prime * result
				+ ((language == null) ? 0 : language.hashCode());
		result = prime * result + revision;
		result = prime * result + ((variant == null) ? 0 : variant.hashCode());
		result = prime * result + version;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		IoRevisionPk other = (IoRevisionPk) obj;
		if (format == null) {
			if (other.format != null)
				return false;
		} else if (!format.equals(other.format))
			return false;
		if (io == null) {
			if (other.io != null)
				return false;
		} else if (!io.equals(other.io))
			return false;
		if (language == null) {
			if (other.language != null)
				return false;
		} else if (!language.equals(other.language))
			return false;
		if (revision != other.revision)
			return false;
		if (variant == null) {
			if (other.variant != null)
				return false;
		} else if (!variant.equals(other.variant))
			return false;
		if (version != other.version)
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "IoRevisionPk [io=" + io + ", version=" + version
				+ ", language=" + language + ", variant=" + variant
				+ ", format=" + format + ", revision=" + revision + "]";
	}
}
