package model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author Philipp
 */
@Entity
@Table(name="blob_storage")
public class BlobContentModel extends BaseModel<IoRevisionPk> {

	private static final long serialVersionUID = 6912741082614624944L;

	@EmbeddedId
	private IoRevisionPk pk;

	@OneToOne(fetch=FetchType.LAZY, optional=false)
	@JoinColumns({
		@JoinColumn(name="io_id", referencedColumnName="io_id", insertable=false, updatable=false), 
		@JoinColumn(name="iov_number", referencedColumnName="iov_number", insertable=false, updatable=false), 
		@JoinColumn(name="ln_code", referencedColumnName="ln_code", insertable=false, updatable=false), 
		@JoinColumn(name="vr_code", referencedColumnName="vr_code", insertable=false, updatable=false), 
		@JoinColumn(name="ft_id", referencedColumnName="ft_id", insertable=false, updatable=false), 
		@JoinColumn(name="rv_number", referencedColumnName="rv_number", insertable=false, updatable=false)
	})
	private IoRevisionModel ioRevisionModel;

	@Lob
	@Column(name="bls_data")
	private byte[] data;

	/**
	 * @return the pk
	 */
	public IoRevisionPk getPk() {
		return pk;
	}

	/**
	 * @param pk the pk to set
	 */
	public void setPk(IoRevisionPk pk) {
		this.pk = pk;
	}

	/**
	 * @return the data
	 */
	public byte[] getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(byte[] data) {
		this.data = data;
	}

	/**
	 * @return the ioRevisionModel
	 */
	public IoRevisionModel getIoRevision() {
		return ioRevisionModel;
	}

	/**
	 * @param ioRevisionModel the ioRevisionModel to set
	 */
	public void setIoRevision(IoRevisionModel ioRevisionModel) {
		this.ioRevisionModel = ioRevisionModel;
	}

	/* (non-Javadoc)
	 * @see org.springframework.data.domain.Persistable#getId()
	 */
	@Override
	public IoRevisionPk getId() {
		return getPk();
	}
}
