/**
 * 
 */
package test;

import java.nio.charset.StandardCharsets;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import model.BlobContentModel;
import model.IoRevisionModel;
import model.IoRevisionPk;

/**
 * @author nanz0phi
 *
 */
@RunWith(SpringRunner.class)
@ContextConfiguration("classpath:testcontext.xml")
public class ReferentialIntegrityBugTest {

	@PersistenceContext
	private EntityManager em;

	@Test
	@Transactional
	public void testInsert() {
		IoRevisionPk revPk = new IoRevisionPk("yadda", 1, "en", "US", "main", 1);
		byte[] data = "Hello world!".getBytes(StandardCharsets.UTF_8);
		
		IoRevisionModel rev = new IoRevisionModel();
		rev.setPk(revPk);
		rev.setNew(true);
		rev.setDescription("Description");
		rev.setSize(data.length);
		em.persist(rev);
		
		BlobContentModel blob = new BlobContentModel();
		blob.setPk(revPk);
		blob.setNew(true);
		blob.setData(data);
		blob.setIoRevision(rev);
		em.persist(blob);
		
		Query q = em.createQuery("from IoRevisionModel");
		Assert.assertEquals(1, q.getResultList().size());
	}
}
