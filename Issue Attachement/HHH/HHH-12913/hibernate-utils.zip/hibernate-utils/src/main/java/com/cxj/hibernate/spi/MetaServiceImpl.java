package com.cxj.hibernate.spi;

/**
 * Created by vipcxj on 2018/8/10.
 */
public class MetaServiceImpl implements MetaService {

}
