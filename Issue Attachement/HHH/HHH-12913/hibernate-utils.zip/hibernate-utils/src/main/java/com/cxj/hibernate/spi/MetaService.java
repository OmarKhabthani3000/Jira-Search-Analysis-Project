package com.cxj.hibernate.spi;

import org.hibernate.service.Service;

/**
 * Created by vipcxj on 2018/8/10.
 */
public interface MetaService extends Service {
}
