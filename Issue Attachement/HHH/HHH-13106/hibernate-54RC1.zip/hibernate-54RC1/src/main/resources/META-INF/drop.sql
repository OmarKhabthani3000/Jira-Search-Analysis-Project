-- roles

DROP TABLE IF EXISTS roles CASCADE;
