package in.workingtheory;

import in.workingtheory.model.Role;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.List;

@Service
public class RoleService
{
	private static final Logger logger = LogManager.getLogger(RoleService.class);

	private final RoleRepository repository;

	@Autowired
	public RoleService(final RoleRepository repository)
	{
		this.repository = repository;
	}


	@PostConstruct
	protected void initialize()
	{
		final List<Role> roles = repository.findAll();

		logger.info("Roles : {}", roles.size());
	}
}
