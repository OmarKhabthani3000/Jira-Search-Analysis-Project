package in.workingtheory;

import in.workingtheory.model.Role;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class RoleRepository
{
	@PersistenceContext
	private EntityManager entityManager;

	public List<Role> findAll()
	{
		return entityManager.createQuery("SELECT r FROM Role r", Role.class).getResultList();
	}
}
