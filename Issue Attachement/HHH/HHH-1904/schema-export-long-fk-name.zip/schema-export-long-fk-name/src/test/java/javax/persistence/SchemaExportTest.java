package javax.persistence;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

/**
 * @author BEcomputer06
 * Nov 21, 2010 1:29:28 AM IST
 */

public class SchemaExportTest {

	/**
	 * Why DenormalizedTable#createForeignKeys() assigns next foreign in 
	 *    fk.getName() + Integer.toHexString( getName().hashCode()
	 * fashion?
	 * 
	 */
	
	@Test
	public void foriegnKeyNameIsTooLong() {
		Map<String, String> properties = new HashMap<String, String>(1);
		properties.put("hibernate.hbm2ddl.auto", "create");
		Persistence.createEntityManagerFactory("default", properties); 
	}
	
}