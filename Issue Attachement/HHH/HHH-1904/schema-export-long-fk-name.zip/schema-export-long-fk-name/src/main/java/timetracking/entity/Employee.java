package timetracking.entity;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author BEcomputer06
 * 27-Oct-2010 11:18:02 AM
 */

@Entity
@Table(name="employee")
@Access(AccessType.PROPERTY)
public class Employee extends User {

	private String firstName;
	private String lastName;

	protected Employee() {
	}

	@Column(name="first_name")
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@Column(name="last_name")
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

}