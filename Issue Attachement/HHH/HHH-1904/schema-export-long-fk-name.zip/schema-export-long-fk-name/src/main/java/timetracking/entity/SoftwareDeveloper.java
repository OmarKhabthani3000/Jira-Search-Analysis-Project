package timetracking.entity;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author BEcomputer06
 * Nov 21, 2010 3:26:25 AM IST
 */

@Entity
@Table(name="software_developer")
@Access(AccessType.PROPERTY)
public class SoftwareDeveloper extends Employee {

	private String coreSkill;
	
	@Column(name="core_skill")
	public String getCoreSkill() {
		return coreSkill;
	}
	public void setCoreSkill(String coreSkill) {
		this.coreSkill = coreSkill;
	}
	
}