package timetracking.entity;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author BEcomputer06
 * 01-Nov-2010 5:53:49 PM
 */

@Entity
@Table(name="organization")
@Access(AccessType.PROPERTY)
public class Organization implements Serializable {

	private String entityId;
	private String name;

	protected Organization() {
	}

	public Organization(String name) {
		this();
		this.name = name;
	}

	@Id
	@Column(name="entity_id")
	public String getEntityId() {
		return entityId;
	}
	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}

	@Column(name="name", nullable=false, unique=true)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
