package timetracking.entity;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author BEcomputer06
 * Nov 21, 2010 12:52:25 AM IST
 */

@Entity
@Access(value=AccessType.PROPERTY)
@Table(name="users")
public class User extends TimeTrackingEntityImpl {

	private String userName;

	protected User() {
	}

	public User(String userName) {
		this.userName = userName;
	}

	@Column(name="user_name", nullable=false)
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

}