package timetracking.entity;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToOne;

/**
 * @author BEcomputer06
 * Nov 12, 2010 10:48:17 PM
 */

@Entity
@Access(AccessType.PROPERTY)
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public abstract class TimeTrackingEntityImpl implements Serializable {

	private String id;
	private Organization organization;

	protected TimeTrackingEntityImpl() {
	}

	@Id
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	@ManyToOne(optional=false, fetch=FetchType.LAZY)
	public Organization getOrganization() {
		return organization;
	}
	public void setOrganization(Organization organization) {
		this.organization = organization;
	}

}