package bugreport;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("DISCRIMINATOR_C")
public class C extends A {

	@Column(name = "COLUMN_C")
	private Integer attributeC;
}
