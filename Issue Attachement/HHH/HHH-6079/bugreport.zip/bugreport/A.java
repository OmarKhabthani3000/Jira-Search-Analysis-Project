package bugreport;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name = "TABLE_A")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "DISCRIMINATOR", discriminatorType = DiscriminatorType.STRING)
@DiscriminatorValue("DISCRIMINATOR_A")
public class A {

	@Id
	@org.hibernate.annotations.GenericGenerator(name = "generator::A", strategy = "org.hibernate.id.SequenceHiLoGenerator",
																							parameters = {
																								@org.hibernate.annotations.Parameter(name = "sequence", value = "SEQ_ANGE"),
																															@org.hibernate.annotations.Parameter(name = "max_lo", value = "99"),
																															@org.hibernate.annotations.Parameter(name = "parameters", value = "minvalue 1 start with 1 increment by 100 nocache")})
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator::A")
	@Column(name = "ID", columnDefinition = "NUMBER(38, 0)")
	private Long id;

	@Column(name = "COLUMN_A")
	private Integer attributeA;
}
