package bugreport;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("DISCRIMINATOR_B")
public class B extends A {

	@Column(name = "COLUMN_B")
	private Integer attributeB;

}
