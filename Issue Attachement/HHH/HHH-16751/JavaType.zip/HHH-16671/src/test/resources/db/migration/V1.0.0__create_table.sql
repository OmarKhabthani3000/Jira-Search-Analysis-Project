CREATE TABLE demo_table_hp
(
    year_month_key   DATE NOT NULL,
    year_month_value DATE NOT NULL,
    PRIMARY KEY (year_month_key)
);
