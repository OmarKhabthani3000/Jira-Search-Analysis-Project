package com.demo.hibernate.customtype;

import org.hibernate.type.descriptor.WrapperOptions;
import org.hibernate.type.descriptor.java.AbstractClassJavaType;
import org.hibernate.type.descriptor.java.ImmutableMutabilityPlan;
import org.hibernate.type.descriptor.jdbc.JdbcType;
import org.hibernate.type.descriptor.jdbc.JdbcTypeIndicators;

import java.sql.Date;
import java.sql.Types;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;

public class CustomYearMonthJavaType extends AbstractClassJavaType<YearMonth> {

    public static final DateTimeFormatter LOCAL_DATE_FORMATTER = new DateTimeFormatterBuilder().appendPattern("yyyy-MM-dd").toFormatter();

    public CustomYearMonthJavaType() {
        super(YearMonth.class, ImmutableMutabilityPlan.instance(), YearMonth::compareTo);
    }

    @Override
    public JdbcType getRecommendedJdbcType(JdbcTypeIndicators indicators) {
        return indicators.getTypeConfiguration()
                .getJdbcTypeRegistry()
                .getDescriptor(Types.DATE);
    }

    @Override
    public <X> X unwrap(YearMonth value, Class<X> type, WrapperOptions options) {
        if (value == null) {
            return null;
        }
        if (YearMonth.class.isAssignableFrom(type)) {
            return (X) value;
        }
        if (Date.class.isAssignableFrom(type)) {
            return (X) toNonNullValue(value);
        }
        if (String.class.isAssignableFrom(type)) {
            return (X) toNonNullString(value);
        }
        throw unknownUnwrap(type);
    }

    @Override
    public <X> YearMonth wrap(X value, WrapperOptions options) {
        if (value == null) {
            return null;
        }
        if (value instanceof Date) {
            return fromNonNullValue((Date) value);
        }
        if (value instanceof YearMonth) {
            return (YearMonth) value;
        }
        if (value instanceof String) {
            return fromNonNullString((String) value);
        }
        throw unknownWrap(value.getClass());
    }

    private YearMonth fromNonNullValue(Date value) {
        return YearMonth.from(value.toLocalDate());
    }

    public Date toNonNullValue(YearMonth value) {
        return Date.valueOf(LOCAL_DATE_FORMATTER.format(value.atDay(1)));
    }

    private String toNonNullString(YearMonth value) {
        return LOCAL_DATE_FORMATTER.format(value.atDay(1));
    }

    private YearMonth fromNonNullString(String s) {
        return YearMonth.from(LOCAL_DATE_FORMATTER.parse(s));
    }
}
