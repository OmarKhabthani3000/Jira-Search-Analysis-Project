package com.demo.hibernate;

import com.demo.hibernate.customtype.CustomYearMonthJavaType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.JavaType;

import java.io.Serializable;
import java.time.YearMonth;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "entity_with_javatype")
public class DemoEntityWithJavaType implements Serializable {
    @Id
    @Column(name = "year_month_key")
    @JavaType(CustomYearMonthJavaType.class)
    private YearMonth yearMonthId;

    @Column(name = "year_month_value")
    @JavaType(CustomYearMonthJavaType.class)
    private YearMonth yearMonthValue;

    public DemoEntityWithJavaType(YearMonth value) {
        this(value, value);
    }
}
