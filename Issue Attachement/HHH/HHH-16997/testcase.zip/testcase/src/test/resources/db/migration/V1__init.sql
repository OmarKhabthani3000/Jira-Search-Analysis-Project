create schema test;

create table test.t_entity_a (
    id integer,
    cmpa_a_id integer,
    cmpb_c_id integer,
    cmpb_d_id integer,
    constraint t_entity_a_pkey primary key (id)
);

create table test.t_entity_b (
    id integer,
    constraint  t_entity_b_pkey primary key (id)
);


create table test.t_entity_c (
    id integer,
    constraint t_entity_c_pkey primary key (id)
);

create table test.t_entity_d (
    id integer,
    constraint t_entity_d_pkey primary key (id)
);


insert into test.t_entity_a(id, cmpa_a_id, cmpb_c_id, cmpb_d_id)
values (1, null,  null, 1),
       (2, 1, null, null);

insert into test.t_entity_b(id) values (1);

insert into test.t_entity_d(id) values (1);

alter table test.t_entity_a
    add constraint t_entity_a_cmpa_a_fkey foreign key (cmpa_a_id)
        references test.t_entity_a(id);

alter table test.t_entity_a
    add constraint t_entity_a_cmpb_c_fkey foreign key (cmpb_c_id)
        references test.t_entity_c(id);

alter table test.t_entity_a
    add constraint t_entity_a_cmpb_d_fkey foreign key (cmpb_d_id)
        references test.t_entity_d(id);

alter table test.t_entity_b
    add constraint t_entity_a_entity_a_fkey foreign key (id)
        references test.t_entity_a(id);
