/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package testcase;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import static org.assertj.core.api.Assertions.assertThat;
import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.output.MigrateResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testcase.db.EntityA;
import testcase.db.EntityA_;

public class QueryTest {

    private static final Logger LOGGER = LogManager.getLogger();

    private EntityManagerFactory emf;
    private EntityManager em;


    @Test
    public void descOrder() {
        //given
        CriteriaBuilder cb = em.getCriteriaBuilder();
        var query = cb.createQuery(EntityA.class);
        var root = query.from(EntityA.class);
        //when
        query.select(root).orderBy(
                cb.desc(root.get(EntityA_.id))
        );
        var list = em.createQuery(query).getResultList();
        //then
        assertThat(list).hasSize(2);
        var proxiedEntity = list.get(1);
        assertThat(proxiedEntity.getId()).isEqualTo(1);
        assertThat(proxiedEntity.getComponentB()).isNotNull();
        assertThat(proxiedEntity.getComponentB().getEntityD()).isNotNull();
    }

    @Test
    public void ascOrder() {
        //given
        CriteriaBuilder cb = em.getCriteriaBuilder();
        var query = cb.createQuery(EntityA.class);
        var root = query.from(EntityA.class);
        //when
        query.select(root).orderBy(
                cb.asc(root.get(EntityA_.id))
        );
        var list = em.createQuery(query).getResultList();
        //then
        assertThat(list).hasSize(2);
        var proxiedEntity = list.get(0);
        assertThat(proxiedEntity.getId()).isEqualTo(1);
        assertThat(proxiedEntity.getComponentB()).isNotNull();
        assertThat(proxiedEntity.getComponentB().getEntityD()).isNotNull();
    }

    @BeforeClass
    private void beforeClass() {
        Flyway flyway = Flyway.configure().dataSource("jdbc:hsqldb:mem:jpa_test", "user", "password").load();
        MigrateResult migrateResult = flyway.migrate();
        LOGGER.info("Migrations: {}", migrateResult.migrationsExecuted);
        emf = Persistence.createEntityManagerFactory("jpa_test");
        em = emf.createEntityManager();
    }

    @AfterClass
    private void afterClass() {
        em.close();
        emf.close();
    }

    @BeforeMethod
    private void beforeMethod() {
        em.getTransaction().begin();
    }

    @AfterMethod
    private void afterMethod() {
        em.getTransaction().rollback();
    }
}
