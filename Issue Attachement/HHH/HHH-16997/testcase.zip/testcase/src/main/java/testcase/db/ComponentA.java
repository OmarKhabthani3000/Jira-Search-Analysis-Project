/*
 * Copyright (c) Krakfin
 * All rights reserved
 */

package testcase.db;

import jakarta.persistence.Embeddable;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import java.io.Serializable;

@Embeddable
public class ComponentA implements Serializable {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cmpa_a_id", referencedColumnName = "id", insertable = false, updatable = false)
    private EntityA entityA;


    public EntityA getEntityA() {
        return entityA;
    }

    public void setEntityA(EntityA entityA) {
        this.entityA = entityA;
    }
}
