/*
 * Copyright (c) Krakfin
 * All rights reserved
 */

package testcase.db;

import jakarta.persistence.Embedded;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.util.Objects;
import org.hibernate.annotations.Immutable;

@Entity
@Table(schema = "test", name = "t_entity_a")
public class EntityA implements Serializable {

    @Id
    private Integer id;
    @Embedded
    private ComponentA componentA;
    @Embedded
    private ComponentB componentB;
    @OneToOne(mappedBy = "entityA")
    private EntityB entityB;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public EntityB getEntityB() {
        return entityB;
    }

    public void setEntityB(EntityB entityB) {
        this.entityB = entityB;
    }

    public ComponentA getComponentA() {
        if (componentA == null) {
            componentA = new ComponentA();
        }
        return componentA;
    }

    public void setComponentA(ComponentA componentA) {
        this.componentA = componentA;
    }

    public ComponentB getComponentB() {
        if (componentB == null) {
            componentB = new ComponentB();
        }
        return componentB;
    }

    public void setComponentB(ComponentB componentB) {
        this.componentB = componentB;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EntityA entityA = (EntityA) o;
        return Objects.equals(id, entityA.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
