/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package testcase.db;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(schema = "test", name = "t_entity_c")
public class EntityC implements Serializable {

    @Id
    private Integer id;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EntityC entityC = (EntityC) o;
        return Objects.equals(id, entityC.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
