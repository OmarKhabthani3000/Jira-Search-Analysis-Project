/*
 * Copyright (c) Krakfin
 * All rights reserved
 */

package testcase.db;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.util.Objects;
import org.hibernate.annotations.Immutable;

@Entity
@Table(schema = "test", name = "t_entity_b")
public class EntityB implements Serializable {

    @Id
    @OneToOne
    @JoinColumn(name = "id", referencedColumnName = "id")
    private EntityA entityA;


    public EntityA getEntityA() {
        return entityA;
    }

    public void setEntityA(EntityA entityA) {
        this.entityA = entityA;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EntityB entityB = (EntityB) o;
        return Objects.equals(entityA, entityB.entityA);
    }

    @Override
    public int hashCode() {
        return Objects.hash(entityA);
    }
}
