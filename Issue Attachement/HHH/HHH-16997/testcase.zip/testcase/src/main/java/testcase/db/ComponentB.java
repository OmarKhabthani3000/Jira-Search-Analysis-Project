/*
 * Copyright (c) Krakfin
 * All rights reserved
 */
package testcase.db;

import jakarta.persistence.Embeddable;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import java.io.Serializable;

@Embeddable
public class ComponentB implements Serializable {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cmpb_c_id", referencedColumnName = "id")
    private EntityC entityC;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cmpb_d_id", referencedColumnName = "id")
    private EntityD entityD;


    public EntityC getEntityC() {
        return entityC;
    }

    public void setEntityC(EntityC entityC) {
        this.entityC = entityC;
    }

    public EntityD getEntityD() {
        return entityD;
    }

    public void setEntityD(EntityD entityD) {
        this.entityD = entityD;
    }
}
