package com.sia.test;

import javax.persistence.EntityManager;

public interface BaseServicesAdapterInterface {

	EntityManager getEm();
	void setEm(EntityManager em);

	String test(String whenToRollbackOnly);
}

