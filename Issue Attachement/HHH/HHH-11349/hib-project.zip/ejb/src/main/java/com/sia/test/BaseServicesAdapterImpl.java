package com.sia.test;

import java.util.Date;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext; 


@Stateless
//@TransactionManagement(TransactionManagementType.CONTAINER)
//@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class BaseServicesAdapterImpl implements BaseServicesAdapterInterface {

	@PersistenceContext 
	protected EntityManager em;

	@Resource SessionContext sessionContext;

	private String whenToRollbackOnly;
	

	public EntityManager getEm() {
        return em;
    }

    public void setEm(EntityManager em) {
        this.em = em;
    }
    
	@Override
	public String test(String whenToRollbackOnly) {
		System.out.println(String.format("TEST: SERVICE STARTED -> whenToRollbackOnly: %s", whenToRollbackOnly));
		this.whenToRollbackOnly = whenToRollbackOnly;
		
		persistEntityAndFlush();
		
		if (callSetRollbackOnlyAfterFlush()) {
			System.out.println("TEST: calling sessionContext.setRollbackOnly()");
			sessionContext.setRollbackOnly();
		}
		
		return "finished";
	}

	
	private boolean callSetRollbackOnlyAfterFlush() {
		return "afterFlush".equals(whenToRollbackOnly);
	}

	
	private void persistEntityAndFlush() {
		persistEntityAndFlush("TST", new Integer(5), new Long(-1), new Long(-1), 
				new Date(), "", null, new Date(), new Integer(10), "test transaction", 
				null, null, null, "");		
	}

	
	private Long persistEntityAndFlush(String tipoProcesso, Integer tpEntita, Long idEntita, Long progr,
			Date date, String stato, String subStato, Date dtStato, Integer ggTimer,
			String descrizione, String idPrcPerif1, String idPrcPerif2, String idPrcPerif3, String chiave1) {
			Long idProcesso = 0L;

			TestEntity testEntity = new TestEntity();
			testEntity.setTipoProcesso(tipoProcesso);
			testEntity.setTpEntita(tpEntita);
			testEntity.setIdEntita(idEntita);
			testEntity.setProgr(progr);
			testEntity.setChiave1(chiave1);
			testEntity.setDtRiferimentoOriginale(date);
			testEntity.setStato(stato);
			testEntity.setSubStato(subStato);
			testEntity.setDtStato(new Date());
			testEntity.setFlAttivo("A");
			testEntity.setDescrizione(descrizione);
			testEntity.setIdPrcPerif1(idPrcPerif1);
			testEntity.setIdPrcPerif2(idPrcPerif2);
			testEntity.setIdPrcPerif3(idPrcPerif3);

			testEntity.setIdProcesso(idProcesso);

			//em.find(TestEntity.class, new Long(-9999));
			
			if (callSetRollbackOnlyBeforePersist()) {
				System.out.println("TEST: calling sessionContext.setRollbackOnly()");
				sessionContext.setRollbackOnly();
			}
			
			System.out.println("TEST: calling persist()");
			getEm().persist(testEntity);
			System.out.println("TEST: persist() called");

			if (callSetRollbackOnlyBetweenPersistAndFlush()) {
				System.out.println("TEST: calling sessionContext.setRollbackOnly()");
				sessionContext.setRollbackOnly();
			}

			System.out.println("TEST: calling flush()");
			getEm().flush(); 
			System.out.println("TEST: flush() called");

			throw new RuntimeException("Too late?");
	}

	private boolean callSetRollbackOnlyBeforePersist() {
		return "beforePersist".equals(whenToRollbackOnly);
	}

	private boolean callSetRollbackOnlyBetweenPersistAndFlush() {
		return "betweenPersistAndFlush".equals(whenToRollbackOnly);
	}

	
}

