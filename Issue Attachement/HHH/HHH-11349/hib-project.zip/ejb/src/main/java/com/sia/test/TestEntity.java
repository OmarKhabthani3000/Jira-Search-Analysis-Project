package com.sia.test;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="PROCESSO")
public class TestEntity implements java.io.Serializable{
	
	private static final long serialVersionUID = 1L;
	
	
	private Long idProcesso;
	
	private String tipoProcesso;
	
	private Integer tpEntita;
	
	private Long idEntita;
	
	private Long progr;
	
	private Date dtRiferimentoOriginale;
	
	private String stato;
	
	private String subStato;
	
	private String flAttivo;
		
	private Date dtStato;

	private String descrizione;
	
	private String idPrcPerif1;
	
	private String idPrcPerif2;
	
	private String idPrcPerif3;
	
	private String chiave1;



	@Id
	@Column(name="ID_PROCESSO", precision = 10, scale = 0)	
	public Long getIdProcesso() {
		return idProcesso;
	}

	public void setIdProcesso(Long idProcesso) {
		this.idProcesso = idProcesso;
	}
	
	@Column(name="TIPO_PROCESSO", nullable = false, length = 7)
	public String getTipoProcesso() {
		return tipoProcesso;
	}

	public void setTipoProcesso(String tipoProcesso) {
		this.tipoProcesso = tipoProcesso;
	}
	
	@Column(name = "TP_ENTITA", nullable = false, precision = 5, scale = 0)
	public Integer getTpEntita() {
		return tpEntita;
	}

	public void setTpEntita(Integer tpEntita) {
		this.tpEntita = tpEntita;
	}
	
	@Column(name = "ID_ENTITA", precision = 10, scale = 0)
	public Long getIdEntita() {
		return idEntita;
	}

	public void setIdEntita(Long idEntita) {
		this.idEntita = idEntita;
	}
	
	@Column(name = "PROGR", precision = 10, scale = 0)
	public Long getProgr() {
		return progr;
	}

	public void setProgr(Long progr) {
		this.progr = progr;
	}
	
	@Temporal(TemporalType.DATE)
	@Column(name = "DT_RIFERIMENTO_ORIGINALE")
	public Date getDtRiferimentoOriginale() {
		return dtRiferimentoOriginale;
	}

	public void setDtRiferimentoOriginale(Date dtRiferimentoOriginale) {
		this.dtRiferimentoOriginale = dtRiferimentoOriginale;
	}
	
	@Column(name="STATO", length = 7)
	public String getStato() {
		return stato;
	}

	public void setStato(String stato) {
		this.stato = stato;
	}
	
	@Column(name="SUBSTATO", length = 7)
	public String getSubStato() {
		return subStato;
	}

	public void setSubStato(String subStato) {
		this.subStato = subStato;
	}
	
	@Column(name="FL_ATTIVO", length = 1)
	public String getFlAttivo() {
		return flAttivo;
	}

	public void setFlAttivo(String flAttivo) {
		this.flAttivo = flAttivo;
	}
	
	@Temporal(TemporalType.DATE)
	@Column(name = "DT_STATO")
	public Date getDtStato() {
		return dtStato;
	}

	public void setDtStato(Date dtStato) {
		this.dtStato = dtStato;
	}
	
	@Column(name="DESCRIZIONE", length = 100)
	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	@Column(name="ID_PRC_PERIF_1", length = 250)
	public String getIdPrcPerif1() {
		return idPrcPerif1;
	}

	public void setIdPrcPerif1(String idPrcPerif1) {
		this.idPrcPerif1 = idPrcPerif1;
	}

	@Column(name="ID_PRC_PERIF_2", length = 250)
	public String getIdPrcPerif2() {
		return idPrcPerif2;
	}

	public void setIdPrcPerif2(String idPrcPerif2) {
		this.idPrcPerif2 = idPrcPerif2;
	}

	@Column(name="ID_PRC_PERIF_3", length = 250)
	public String getIdPrcPerif3() {
		return idPrcPerif3;
	}

	public void setIdPrcPerif3(String idPrcPerif3) {
		this.idPrcPerif3 = idPrcPerif3;
	}
	
	@Column(name="CHIAVE_1", nullable = true, length = 10)
	public String getChiave1() {
		return chiave1;
	}

	public void setChiave1(String chiave1) {
		this.chiave1 = chiave1;
        }

}
