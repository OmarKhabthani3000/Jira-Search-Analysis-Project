package com.example.demo;

import com.example.demo.domain.LeafLayer;
import com.example.demo.domain.MiddleLayer;
import com.example.demo.domain.RootLayer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDate;
import java.util.ArrayList;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DemoApplicationTests {

	@Autowired
	private RootLayerRepository repository;

	@Test
	public void contextLoads() {
		RootLayer rootLayer = new RootLayer();
		rootLayer.setMiddleLayers( new ArrayList<>() );

		MiddleLayer middleLayer = new MiddleLayer();
		rootLayer.getMiddleLayers().add( middleLayer );
		middleLayer.setRootLayer( rootLayer );
		middleLayer.setValidFrom( LocalDate.of( 2019	,3,	19 ) );
		middleLayer.setLeafLayers( new ArrayList<>(  ) );

		LeafLayer leafLayer = new LeafLayer();
		leafLayer.setMiddleLayer( middleLayer );
		middleLayer.getLeafLayers().add( leafLayer );

		rootLayer = repository.saveAndFlush( rootLayer );

		repository.delete( rootLayer.getId() );
	}

}
