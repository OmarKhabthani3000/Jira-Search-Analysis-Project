/*
 * See the NOTICE file distributed with this work for additional information regarding copyright ownership.
 */
package com.example.demo;

import com.example.demo.domain.RootLayer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RootLayerRepository extends JpaRepository<RootLayer, Long>
{
}
