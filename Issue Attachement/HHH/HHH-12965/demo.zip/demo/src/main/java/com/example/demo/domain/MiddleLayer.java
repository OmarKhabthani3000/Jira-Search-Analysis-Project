/*
 * See the NOTICE file distributed with this work for additional information regarding copyright ownership.
 */
package com.example.demo.domain;

import org.hibernate.envers.Audited;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.time.LocalDate;
import java.util.List;

@Entity
@Audited
@IdClass( MiddleLayerPK.class )
public class MiddleLayer
{
  @Id
  @Column( name = "valid_from", nullable = false )
  private LocalDate validFrom;

  @Id
  @ManyToOne
  @JoinColumn( name = "root_layer_fk" )
  private RootLayer rootLayer;

  @OneToMany( mappedBy = "middleLayer", cascade = CascadeType.ALL, orphanRemoval = true )
  private List<LeafLayer> leafLayers;

  public LocalDate getValidFrom()
  {
    return validFrom;
  }

  public void setValidFrom( LocalDate validFrom )
  {
    this.validFrom = validFrom;
  }

  public RootLayer getRootLayer()
  {
    return rootLayer;
  }

  public void setRootLayer( RootLayer rootLayer )
  {
    this.rootLayer = rootLayer;
  }

  public List<LeafLayer> getLeafLayers()
  {
    return leafLayers;
  }

  public void setLeafLayers( List<LeafLayer> leafLayers )
  {
    this.leafLayers = leafLayers;
  }


}
