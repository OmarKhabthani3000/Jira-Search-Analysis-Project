/*
 * See the NOTICE file distributed with this work for additional information regarding copyright ownership.
 */
package com.example.demo.domain;

import org.hibernate.envers.Audited;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

@Audited
@Entity
public class LeafLayer
{
  @Id
  @GeneratedValue( strategy = GenerationType.AUTO )
  private Long id;

  @ManyToOne( optional = false )
  @JoinColumns( {@JoinColumn( name = "middle_layer_valid_from_fk", referencedColumnName = "valid_from" ),
          @JoinColumn( name = "middle_layer_root_layer_fk", referencedColumnName = "root_layer_fk" )} )
  private MiddleLayer middleLayer;

  public Long getId()
  {
    return id;
  }

  public void setId( Long id )
  {
    this.id = id;
  }

  public MiddleLayer getMiddleLayer()
  {
    return middleLayer;
  }

  public void setMiddleLayer( MiddleLayer middleLayer )
  {
    this.middleLayer = middleLayer;
  }

}
