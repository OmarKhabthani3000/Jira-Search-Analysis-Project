package com.demo.hibernate6.model;

import com.demo.hibernate6.model.animal.Elephant;
import com.demo.hibernate6.model.animal.Tiger;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.NamedAttributeNode;
import jakarta.persistence.NamedEntityGraph;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "ZOO")
@NamedEntityGraph(
    name = "get-zoo-with-all-animals",
    attributeNodes = {
      @NamedAttributeNode(value = "tiger"),
      @NamedAttributeNode(value = "elephants")
    })
public class Zoo {

  @Id
  @GeneratedValue(generator = "ZOO_SEQ")
  @SequenceGenerator(name = "ZOO_SEQ", sequenceName = "ZOO_SEQ")
  private Long id;

  private String name;

  @OneToOne(cascade = CascadeType.ALL, mappedBy = "zoo", fetch = FetchType.LAZY)
  private Tiger tiger;

  @OneToMany(
      mappedBy = "zoo",
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true)
  private List<Elephant> elephants;

  public Zoo() {
    super();
  }

  public Zoo(Long id, String name, Tiger tiger, List<Elephant> elephants) {
    super();
    this.id = id;
    this.name = name;
    this.tiger = tiger;
    this.elephants = elephants;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String lrn) {
    this.name = lrn;
  }

  public Tiger getTiger() {
    return tiger;
  }

  public void setTiger(Tiger tiger) {
    this.tiger = tiger;
  }

  public List<Elephant> getElephants() {
    return elephants;
  }

  public void setElephants(List<Elephant> elephants) {
    this.elephants = elephants;
  }

  public static Builder builder() {
    return new Builder();
  }

  public static class Builder {
    private Zoo zoo;

    private Builder() {
      zoo = new Zoo();
    }

    public Builder id(Long id) {
      zoo.id = id;
      return this;
    }

    public Builder name(String name) {
      zoo.name = name;
      return this;
    }

    public Builder tiger(Tiger tiger) {
      zoo.tiger = tiger;
      return this;
    }

    public Builder elephants(List<Elephant> elephants) {
      zoo.elephants = elephants;
      return this;
    }

    public Zoo build() {
      return zoo;
    }
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name);
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null) return false;
    if (getClass() != obj.getClass()) return false;
    Zoo other = (Zoo) obj;
    return Objects.equals(id, other.id) && Objects.equals(name, other.name);
  }

  @Override
  public String toString() {
    return "Zoo [id=" + id + ", name=" + name + "]";
  }
}
