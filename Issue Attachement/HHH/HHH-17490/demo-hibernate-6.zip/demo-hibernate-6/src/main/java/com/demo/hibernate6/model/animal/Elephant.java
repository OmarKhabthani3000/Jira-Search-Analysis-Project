package com.demo.hibernate6.model.animal;

import com.demo.hibernate6.model.Zoo;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import java.math.BigDecimal;

@Entity
@DiscriminatorValue("Elephant")
public class Elephant extends Animal {

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "ZOO_ID")
  private Zoo zoo;

  public Elephant() {
    super();
  }

  public Elephant(Long id, Integer sequenceNumber, BigDecimal weight) {
    super(id, sequenceNumber, weight);
  }

  public Zoo getZoo() {
    return zoo;
  }

  public void setZoo(Zoo zoo) {
    this.zoo = zoo;
  }

  public static ElephantBuilder elephantBuilder() {
    return new ElephantBuilder();
  }

  public static class ElephantBuilder {
    private Long id;
    private Integer sequenceNumber;
    private BigDecimal weight;

    public ElephantBuilder id(Long id) {
      this.id = id;
      return this;
    }

    public ElephantBuilder sequenceNumber(Integer sequenceNumber) {
      this.sequenceNumber = sequenceNumber;
      return this;
    }

    public ElephantBuilder weight(BigDecimal weight) {
      this.weight = weight;
      return this;
    }

    public Elephant build() {
      Elephant elephant = new Elephant(id, sequenceNumber, weight);
      return elephant;
    }
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    if (!super.equals(o)) return false; // Check the superclass equality first

    return true; // No additional fields to compare
  }

  @Override
  public int hashCode() {
    return super.hashCode(); // Only include fields from the superclass
  }

  @Override
  public String toString() {
    return "Elephant{"
        + "id="
        + getId()
        + ", sequenceNumber="
        + getSequenceNumber()
        + ", weight="
        + getWeight()
        +
        // Exclude the zoo field from the toString method
        '}';
  }
}
