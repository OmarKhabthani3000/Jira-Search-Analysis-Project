package com.demo.hibernate6;

import com.demo.hibernate6.model.Zoo;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.util.List;

public class AppWithNotInQuery {

  public static void main(String[] args) {

    EntityManagerFactory entityManagerFactory =
        Persistence.createEntityManagerFactory("templatePU");
    EntityManager entityManager = entityManagerFactory.createEntityManager();

    entityManager.getTransaction().begin();
    Zoo zoo = Zoo.builder().name("The Great Calcutta Zoo").build();

    entityManager.persist(zoo);

    entityManager.flush();
    entityManager.clear();

    entityManager.getTransaction().commit();

    entityManager.getTransaction().begin();
    List<Zoo> filteredZoos =
        entityManager
            .createQuery("select zoo from Zoo zoo where zoo.name NOT IN :zooNames", Zoo.class)
            .setParameter("zooNames", List.of())
            .getResultList();
    entityManager.getTransaction().commit();
    System.out.println("filteredZoos: " + filteredZoos); // nothing is returned
  }
}
