package org.hibernate.bugs.HHH11056;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Version;

import org.hibernate.annotations.SelectBeforeUpdate;
import org.hibernate.envers.Audited;

@Entity
@SelectBeforeUpdate
@Audited
public class Book implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private Long bookId;
	private String bookName;
	@ManyToOne
	@JoinColumn(name = "authorId", updatable = false) // note that the issue dissappears if you delete updatable=false.
	private Author author;
	@Version
	private Long version;

	public Book() {
	}

	public Book(Long bookId, String bookName, Author author) {
		this.bookId = bookId;
		this.bookName = bookName;
		this.author = author;
	}

	public Long getBookId() {
		return bookId;
	}

	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}

	public Long getVersion() {
		return version;
	}

	public void setVersion(Long version) {
		this.version = version;
	}

}
