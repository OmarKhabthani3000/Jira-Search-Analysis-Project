
package hibernate.bug.model;

import javax.persistence.Entity;

@Entity
public class Bro extends Person {
    
    private String broName;

    public Bro() {
    }

    public Bro(String broName, String name) {
        super(name);
        this.broName = broName;
    }

    public String getBroName() {
        return broName;
    }

    public void setBroName(String broName) {
        this.broName = broName;
    }
    
}
