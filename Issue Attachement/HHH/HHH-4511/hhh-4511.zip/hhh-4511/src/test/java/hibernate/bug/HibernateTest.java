package hibernate.bug;

import hibernate.bug.model.Bro;
import hibernate.bug.model.Person;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Person p1 = new Person("Marshall Eriksen");
        Bro b1 = new Bro("Ted", "Theodore Evelyn Mosby");
        
        em.persist(p1);
        em.persist(b1);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testIssue() {
        EntityManager em = emf.createEntityManager();
        
        List<Person> list = em.createQuery("FROM Person p ORDER BY p.name ASC", Person.class).getResultList();
        Assert.assertEquals(2, list.size());
        
        Assert.assertTrue(list.get(0) instanceof Person);
        Assert.assertTrue("Marshall Eriksen should not be a bro!", !(list.get(0) instanceof Bro));
        
        Assert.assertTrue(list.get(1) instanceof Person);
        Assert.assertTrue("Ted should be a bro!", list.get(1) instanceof Bro);
        
        em.close();
    }
    
}
