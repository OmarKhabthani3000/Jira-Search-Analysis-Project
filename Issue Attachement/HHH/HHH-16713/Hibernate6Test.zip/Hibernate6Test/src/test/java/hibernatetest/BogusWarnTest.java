package hibernatetest;

import java.io.Serializable;
import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.junit.jupiter.api.Test;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
class BaseEntity implements Serializable {
    private static final long serialVersionUID = -5412503864464287451L;

    @Id @GeneratedValue(strategy = GenerationType.AUTO) long id;
}

@Entity
class TheEntity extends BaseEntity {
    private static final long serialVersionUID = -5412503864464287451L;
}

public class BogusWarnTest {
    @Test
    public void test() {
        Transaction txn = null;
        final SessionFactory sessionFactory = newSessionFactory();
        try (final Session session = sessionFactory.openSession()) {
            txn = session.beginTransaction();
            session.persist(new TheEntity());
            session.flush();
            txn.rollback();
        }
    }

    protected SessionFactory newSessionFactory() {
        final Properties properties = new Properties();
        // log settings
        properties.put("hibernate.hbm2ddl.auto", "create");
        // driver settings
        properties.put("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        properties.put("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        properties.put("hibernate.connection.url", "jdbc:hsqldb:mem:tsg");
        properties.put("hibernate.connection.username", "sa");
        properties.put("hibernate.connection.password", "");
        properties.put("hibernate.jdbc.batch_size", "2");

        return new Configuration().addProperties(properties)
                                  .addAnnotatedClass(BaseEntity.class)
                                  .addAnnotatedClass(TheEntity.class)
                                  .buildSessionFactory(new StandardServiceRegistryBuilder().applySettings(properties).build());
    }
}
