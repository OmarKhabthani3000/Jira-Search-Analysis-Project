package com.myapp.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;

@Entity
@Audited
public class MyOtherEntity {

	@Id
	private Integer id;
	private String name;

	@ManyToOne
	private MyEntity myEntity;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public MyEntity getMyEntity() {
		return myEntity;
	}

	public void setMyEntity(MyEntity myEntity) {
		this.myEntity = myEntity;
	}

}
