import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.HibernateTemplate;

import junit.framework.TestCase;

public class Test extends TestCase {

	private HibernateTemplate template;

	protected void setUp() throws Exception {
		super.setUp();
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(
				"/config.xml");
		template = (HibernateTemplate) ctx.getBean("template");
	}

	public void testFindByIdAnnotated() {
		Annotated p = new Annotated("Foo");
		template.persist(p);
		assertEquals(1, template.findByNamedParam(
				"from Annotated where id=:Value", "Value", "Foo").size());
	}

	public void testMappedXmlSimple() {
		MappedByXml x = new MappedByXml("Foo");
		template.persist(x);
		assertEquals(1, template.findByNamedParam(
				"from MappedByXml where id=:Value", "Value", "Foo").size());
	}

	public void testMappedXmlComplex() {
		MappedComplex c = new MappedComplex("Foo");
		template.persist(c);
		assertEquals(1, template.findByNamedParam(
				"from MappedComplex where id=:Value", "Value", "Foo").size());
	}

	public void testMappedComplexWorkaround() {
		MappedComplex c = new MappedComplex("Foo");
		template.persist(c);
		assertEquals(1, template.findByNamedParam(
				"from MappedComplex c where c.inner.id=:Value", "Value", "Foo")
				.size());
	}
}
