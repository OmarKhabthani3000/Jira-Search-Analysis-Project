package de.empic.hibernateproblem;

public class HibernateProblem {
    public static final String PERSISTENCE_UNIT = "PERSISTENCE_UNIT";

    public String getGreeting() {
        return "Hello World!";
    }

    public static void main(String[] args) {
        System.out.println(new HibernateProblem().getGreeting());
    }
}
