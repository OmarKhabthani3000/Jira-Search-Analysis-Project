package de.empic.hibernateproblem;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;
import org.hibernate.QueryException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.MutationQuery;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.ParameterMetadata;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HibernateProblemTest {
    private static final String PERSISTENCE_UNIT = "PERSISTENCE_UNIT";
    private static final String NATIVE_NAMED_QUERY_1 = "NamedNativeQuery1";
    private static final String THE_CREATE = """
            CREATE TABLE CE_GENERIC_DATA (
               PARENT_ID BIGINT,
               PARENT_TYPE VARCHAR(50),
               GENERIC_DATA_DEFINITION_ID BIGINT,
               CREATOR_ID BIGINT
            );
            """;
        private static final String THE_INSERT = """
            INSERT INTO CE_GENERIC_DATA (
               PARENT_ID,
               PARENT_TYPE,
               GENERIC_DATA_DEFINITION_ID,
               CREATOR_ID
            ) VALUES (
               1001,
               '98C1',
               999,
               666
            );
            """;
    private static final String THE_SELECT = "SELECT PARENT_ID FROM CE_GENERIC_DATA WHERE PARENT_ID > ?2 " + // Long / BIGINT
            "AND PARENT_TYPE = ?1 " + // String / NVarchar2
            "AND GENERIC_DATA_DEFINITION_ID < ?2 " + // Long / BIGINT (same as in first line)
            "AND CREATOR_ID <> ?3"; // Long / BIGINT

    /**
     * When adding the native query as named query with the entity manager,
     * the ordinal number gets lost. It says "org.hibernate.QueryException: Ordinal parameter not bound : 4"
     */
    @Test
    public void test_Bad_NamedNativeQueriesWithEntityManager() {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT);
        final EntityManager entityManager = entityManagerFactory.createEntityManager();
        final NativeQuery<String> nativeQuery = (NativeQuery<String>) entityManager.createNativeQuery(THE_SELECT);
        logParamaterMetadata(nativeQuery); // => Amount of Parameters : 3
        entityManager.getEntityManagerFactory().addNamedQuery(NATIVE_NAMED_QUERY_1, nativeQuery);
        NativeQuery<String> namedNativeQuery = (NativeQuery<String>) entityManager.createNamedQuery(NATIVE_NAMED_QUERY_1);
        logParamaterMetadata(namedNativeQuery); // => Amount of Parameters : 4 !!!!
        setParameters(namedNativeQuery);
        try {
            final List resultList = namedNativeQuery.getResultList();
        } catch (QueryException e) {
            e.printStackTrace();
            Assert.fail("This org.hibernate.QueryException 'Ordinal parameter not bound : 4' should not occur.");
        }
    }

    /**
     * This test shows, that the ordinal parameters in the native query are gone in nativeQuery.getQueryString(),
     * but the query still works with ordinal parameters.
     */
    @Test
    public void test_Good_NamedNativeQueriesWithSession() {
        try (SessionFactory sessionFactory = getSessionFactory();
             Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            session.createNativeMutationQuery(THE_CREATE).executeUpdate();
            session.createNativeMutationQuery(THE_INSERT).executeUpdate();

            final NativeQuery<String> nativeQuery = session.createNativeQuery(THE_SELECT, String.class);
            logParamaterMetadata(nativeQuery); // => Amount of Parameters : 3
            setParameters(nativeQuery);
            Assert.assertNotNull(nativeQuery);
            // following output shows,
            // that all numbered parameters have been transferred to unnumbered parameters
            // but the query works with parameters bound to the position
            System.out.println(nativeQuery.getQueryString());

            final List<String> result = nativeQuery.list();
            Assert.assertFalse(result.isEmpty());
            transaction.commit();
        }
    }

    private SessionFactory getSessionFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put("hibernate.connection.driver_class", "org.h2.Driver");
        props.put("hibernate.connection.url", "jdbc:h2:mem:test");
        props.put("hibernate.connection.username", "sa");
        props.put("hibernate.connection.password", "");
        props.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
        props.put("hibernate.show_sql", "true");
        try {
            StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
                    .applySettings(props)
                    .build();
            Metadata metaData = new MetadataSources(standardRegistry)
                    .getMetadataBuilder()
                    .build();
            return metaData.getSessionFactoryBuilder()
                    .build();
        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    private void setParameters(Query query) {
        query.setParameter(1, "98C1");
        query.setParameter(2, 1000L);
        query.setParameter(3, 2000L);
    }

    private void logParamaterMetadata(NativeQuery<String> query) {
        final ParameterMetadata parameterMetadata = query.getParameterMetadata();
        System.out.println("Amount of Parameters : " + parameterMetadata.getParameterCount());
    }
}
