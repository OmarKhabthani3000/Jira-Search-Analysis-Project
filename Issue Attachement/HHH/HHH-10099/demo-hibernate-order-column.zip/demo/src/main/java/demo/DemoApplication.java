package demo;

import org.hibernate.HibernateException;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.dialect.Dialect;
import org.hibernate.metamodel.MetadataSources;
import org.hibernate.metamodel.source.MetadataImplementor;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.hibernate.tool.hbm2ddl.Target;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.context.ApplicationContext;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

@SpringBootApplication
public class DemoApplication
{

    private static ApplicationContext applicationContext;

    public static void main( String[] args )
    {
        applicationContext = SpringApplication.run( DemoApplication.class, args );
        exportSchema();
    }

    public static void exportSchema()
    {
        final SchemaExport export = new SchemaExport( getHibernate4Configuration() );
        export.setDelimiter( ";" );
        export.setFormat( true );
        export.setOutputFile( "target/schema.sql" );
        export.execute( Target.NONE, SchemaExport.Type.CREATE );

        for ( Object exception : export.getExceptions() )
        {
            System.out.println( exception.toString() );
        }
    }


    public static MetadataImplementor getHibernate5Configuration()
    {
        StandardServiceRegistryBuilder registryBuilder = new StandardServiceRegistryBuilder();

        registryBuilder.applySetting( "hibernate.dialect", "org.hibernate.dialect.HSQLDialect" );
        registryBuilder.applySetting( "hibernate.connection.driver_class",
                                      applicationContext.getBean( DataSourceProperties.class ).getDriverClassName() );
        registryBuilder.applySetting( "hibernate.connection.username",
                                      applicationContext.getBean( DataSourceProperties.class ).getUsername() );
        registryBuilder.applySetting( "hibernate.connection.password",
                                      applicationContext.getBean( DataSourceProperties.class ).getPassword() );
        registryBuilder.applySetting( "hibernate.connection.url",
                                      applicationContext.getBean( DataSourceProperties.class ).getUrl() );

        StandardServiceRegistry standardRegistry = registryBuilder.build();
        MetadataSources sources = new MetadataSources( standardRegistry );

        sources.addAnnotatedClass( CategoryModel.class );
        sources.addAnnotatedClass( ProductModel.class );

        return (MetadataImplementor) sources.buildMetadata();
    }

    private static Configuration getHibernate4Configuration()
    {
        final org.hibernate.cfg.Configuration config = new org.hibernate.cfg.Configuration()
        {
            //hibernate have a bug and returns duplicate sql ddl queries sometimes, removing all duplicates. The bug was still existent in hibernate 4.3.6.Final. Maybe related to HHH-9306
            @Override
            public String[] generateSchemaCreationScript( Dialect dialect )
                throws HibernateException
            {
                String[] originalResult = super.generateSchemaCreationScript( dialect );
                Set<String> uniqueResult = new LinkedHashSet<>( Arrays.asList( originalResult ) );
                return uniqueResult.toArray( new String[uniqueResult.size()] );
            }
        };

        config.addAnnotatedClass( CategoryModel.class );
        config.addAnnotatedClass( ProductModel.class );

        config.setProperty( "hibernate.dialect", "org.hibernate.dialect.HSQLDialect" );
        config.setProperty( "hibernate.connection.driver_class",
                            applicationContext.getBean( DataSourceProperties.class ).getDriverClassName() );
        config.setProperty( "hibernate.connection.username",
                            applicationContext.getBean( DataSourceProperties.class ).getUsername() );
        config.setProperty( "hibernate.connection.password",
                            applicationContext.getBean( DataSourceProperties.class ).getPassword() );
        config.setProperty( "hibernate.connection.url",
                            applicationContext.getBean( DataSourceProperties.class ).getUrl() );
        return config;
    }
}
