package demo;

import javax.persistence.ConstraintMode;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author Petar Tahchiev
 * @since 0.6
 */
@Entity
@Table( name = "product" )
public class ProductModel
{
    @Id
    private Long pk;

    @ManyToOne( optional = true, targetEntity = CategoryModel.class, fetch = FetchType.LAZY )
    @JoinColumn( unique = false, nullable = false, referencedColumnName = "pk", updatable = true, insertable = true, foreignKey = @ForeignKey( ConstraintMode.CONSTRAINT ), name = "category" )
    private CategoryModel category;

    public Long getPk()
    {
        return pk;
    }

    public void setPk( Long pk )
    {
        this.pk = pk;
    }

    public CategoryModel getCategory()
    {
        return category;
    }

    public void setCategory( CategoryModel category )
    {
        this.category = category;
    }
}
