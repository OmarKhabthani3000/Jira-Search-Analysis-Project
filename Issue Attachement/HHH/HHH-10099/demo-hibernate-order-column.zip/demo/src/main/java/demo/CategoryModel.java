package demo;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Table;
import java.util.Collection;

/**
 * @author Petar Tahchiev
 * @since 0.6
 */
@Entity
@Table( name = "category" )
public class CategoryModel
{
    @Id
    private Long pk;

    @OrderColumn( name = "product_order" )
    @OneToMany( fetch = FetchType.LAZY, targetEntity = ProductModel.class )
    @JoinTable( name = "category_products", joinColumns = @JoinColumn( name = "category_pk" ), inverseJoinColumns = @JoinColumn( name = "product_pk" ) )
    private Collection<ProductModel> products;

//    @OrderColumn( name = "product_order" )
//    @OneToMany( mappedBy = "category", fetch = FetchType.LAZY, targetEntity = ProductModel.class )
//    private Collection<ProductModel> products;

    public Long getPk()
    {
        return pk;
    }

    public void setPk( Long pk )
    {
        this.pk = pk;
    }

    public Collection<ProductModel> getProducts()
    {
        return products;
    }

    public void setProducts( Collection<ProductModel> products )
    {
        this.products = products;
    }
}
