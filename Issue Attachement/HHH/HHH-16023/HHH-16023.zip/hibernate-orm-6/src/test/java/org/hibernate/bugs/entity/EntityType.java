package org.hibernate.bugs.entity;

import jakarta.persistence.*;

@Entity
@DiscriminatorValue("SUPPORTING_ASSET_TYPE")
public class EntityType extends MyEntity<EntityType> {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "system_id")
    private System system;

}
