package org.hibernate.bugs.repository;

import jakarta.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.bugs.entity.MyEntity;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MyEntityRepository {
    private final EntityManager entityManager;

    public MyEntityRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public Set<MyEntity> findMyEntities() {
        Session session = entityManager.unwrap(Session.class);
        List<MyEntity> myEntities = session.getNamedNativeQuery("MyEntity.findMyEntity")
                .addEntity("ame", MyEntity.class)
                .getResultList();
        return new HashSet<>(myEntities);
    }
}
