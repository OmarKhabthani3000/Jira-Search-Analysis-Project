package org.hibernate.bugs.entity;

import jakarta.persistence.*;

@NamedNativeQueries(value = {
        @NamedNativeQuery(
                name = "MyEntity.findMyEntity",
                query = """
                        WITH RECURSIVE 
                            all_my_entities AS (
                                SELECT me.* FROM my_entity me)
                         SELECT {ame.*}
                         FROM all_my_entities ame
                         """)}
)
@Entity
@Table(name = "my_entity")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(discriminatorType = DiscriminatorType.STRING, name = "entity_type")
public class MyEntity<E extends MyEntity> {

    @Id
    @GeneratedValue
    private Long id;

    private String name;

}
