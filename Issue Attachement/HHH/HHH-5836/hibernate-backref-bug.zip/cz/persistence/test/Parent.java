package cz.persistence.test;

import javax.persistence.*;

@Entity
@Table(name = "PARENT")
public class Parent {
    @Id
    @Column(name = "ID")
    Long id;

    public Long getId() {
        return this.id;
    }
}
