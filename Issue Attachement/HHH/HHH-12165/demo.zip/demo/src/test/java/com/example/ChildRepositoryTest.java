package com.example;

import com.example.models.Child;
import com.example.models.Toy;
import com.example.repositories.ChildRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.assertj.core.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class ChildRepositoryTest {

    @Autowired
    private ChildRepository childRepository;

    @ComponentScan
    @SpringBootApplication
    static class IntegrationConfiguration{}

    @Test
    public void callHasToys() {
        //given
        final Toy tomsToy = new Toy();
        tomsToy.setName("toms toy");

        final Child tom = new Child();
        tom.setName("Tom");

        tom.addToy(tomsToy);
        childRepository.save(tom);

        final Child amy = new Child();
        amy.setName("Amy");
        childRepository.save(amy);

        //when
        List<Boolean> hasToys = childRepository.hasToys();

        //then
        assertThat(hasToys).containsExactly(true, false);
    }

    @Test
    public void callHasNoToys() {
        //given
        final Toy tomsToy = new Toy();
        tomsToy.setName("toms toy");

        final Child tom = new Child();
        tom.setName("Tom");

        tom.addToy(tomsToy);
        childRepository.save(tom);

        final Child amy = new Child();
        amy.setName("Amy");
        childRepository.save(amy);

        //when
        List<Boolean> hasToys = childRepository.hasNoToys();

        //then
        assertThat(hasToys).containsExactly(false, true);
    }
}
