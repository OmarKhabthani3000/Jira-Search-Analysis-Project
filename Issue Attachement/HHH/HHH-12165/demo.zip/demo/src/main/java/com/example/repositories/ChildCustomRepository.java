package com.example.repositories;

import java.util.List;

public interface ChildCustomRepository {
    List<Boolean> hasToys();

    List<Boolean> hasNoToys();
}
