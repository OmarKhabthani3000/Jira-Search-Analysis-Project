package com.example.models;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.HashSet;
import java.util.Set;

import static java.util.Collections.*;

@Entity
@Table(name = "child")
public class Child {

    @Id
    @GeneratedValue
    @Column(name = "id")
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @OneToMany(cascade = {CascadeType.ALL}, mappedBy = "child", orphanRemoval = true, fetch = FetchType.LAZY)
    private Set<Toy> toys = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public void addToy(final Toy toy) {
        toys.add(toy);
        toy.setChild(this);
    }

    public void removeToy(final Toy toy) {
        toys.remove(toy);
        toy.setChild(null);
    }

    public Set<Toy> getToys() {
        return unmodifiableSet(toys);
    }

    public void clearToys() {
        toys.forEach($ -> $.setChild(null));
        toys.clear();
    }
}
