package com.example.repositories.impl;

import com.example.models.Child;
import com.example.repositories.ChildCustomRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
public class ChildRepositoryImpl implements ChildCustomRepository {

    @PersistenceContext
    private EntityManager entityManager;

    //criteriaBuilder.isNotEmpty works
    @Override
    public List<Boolean> hasToys() {
        final CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        final CriteriaQuery<Boolean> query = criteriaBuilder.createQuery(Boolean.class);
        final Root<Child> root = query.from(Child.class);

        query.select(criteriaBuilder.construct(Boolean.class,
                criteriaBuilder.isNotEmpty(root.get("toys"))));
        return entityManager.createQuery(query).getResultList();
    }

    //criteriaBuilder.isEmpty does not
    @Override
    public List<Boolean> hasNoToys() {
        final CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        final CriteriaQuery<Boolean> query = criteriaBuilder.createQuery(Boolean.class);
        final Root<Child> root = query.from(Child.class);

        query.select(criteriaBuilder.construct(Boolean.class,
                criteriaBuilder.isEmpty(root.get("toys"))));
        return entityManager.createQuery(query).getResultList();
    }

}

