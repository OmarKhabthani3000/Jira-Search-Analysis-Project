

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * Class for DAO to work with class {@link Team}.
 */
public class TeamDao extends HibernateDaoSupport {

    /**
     * Stores entity.
     *
     * @param entity entity
     *
     * @return stored entity
     */
    public Team store(final Team entity) {
        getSession().saveOrUpdate(entity);
        return entity;
    }

}
