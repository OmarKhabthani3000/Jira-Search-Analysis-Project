

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

/**
 * Abstract human.
 */
@Entity
@Audited
@Table(name = "a_abstr_human")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class AbstractHuman implements Serializable {

    /**
     * UID.
     */
    private static final long serialVersionUID = -2941234766746699773L;

    /**
     * ID.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    /** Name of entity. */
    @Column(name = "name", length = 255, nullable = false)
    private String name;

    /**
     * Description.
     */
    @Column(name = "description", length = 2000, nullable = true)
    private String description;

    /**
     * Teams.
     */
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "a_human_to_team",
            joinColumns = { @JoinColumn(name = "abstr_human_id") },
            inverseJoinColumns = { @JoinColumn(name = "team_id") }
    )
    private Set<Team> teams;

    //-----------------------------------------------------------------------------
    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(final Long id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(final String description) {
        this.description = description;
    }

    /**
     * @return the teams
     */
    public Set<Team> getTeams() {
        return teams;
    }

    /**
     * @param teams the teams to set
     */
    public void setTeams(final Set<Team> teams) {
        this.teams = teams;
    }
}
