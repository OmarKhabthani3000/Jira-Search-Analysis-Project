

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * Class for DAO to work with class {@link ClassB}.
 */
public class HumanDao extends HibernateDaoSupport {

    /**
     * Stores entity.
     *
     * @param entity entity
     *
     * @return stored entity
     */
    public AbstractHuman store(final AbstractHuman entity) {
        getSession().saveOrUpdate(entity);
        return entity;
    }
}
