

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.envers.Audited;

/**
 * Student.
 */
@Entity
@Audited
@Table(name = "a_student",
uniqueConstraints = {@UniqueConstraint(columnNames = { "name" }) })
public class Student extends AbstractHuman implements Serializable {

    /**
     * UID.
     */
    private static final long serialVersionUID = 6114016357330723771L;

    /**
     * Abbrev.
     */
    @Column(name = "abbrev", length = 25, nullable = true)
    private String abbrev;

    /** Name again because of constraint. */
    @Column(name = "name", length = 255, nullable = false)
    private String name;
    //-------------------------------------------------------
    /**
     * @return the abbrev
     */
    public String getAbbrev() {
        return abbrev;
    }

    /**
     * @param abbrev the abbrev to set
     */
    public void setAbbrev(final String abbrev) {
        this.abbrev = abbrev;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(final String name) {
        this.name = name;
    }
}
