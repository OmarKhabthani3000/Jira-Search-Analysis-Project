

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

/**
 * Match.
 */
@Entity
@Audited
@Table(name = "a_match")
public class Match implements Serializable {

    /**
     * UID.
     */
    private static final long serialVersionUID = -754876920640466870L;

    /**
     * ID.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    /**
     * Name.
     */
    @Column(name = "name", length = 255, nullable = false)
    private String name;

    /**
     * Teams.
     */
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "a_team_to_match",
            joinColumns = { @JoinColumn(name = "team_id") },
            inverseJoinColumns = { @JoinColumn(name = "match_id") }
    )
    private Set<Team> teams;

    //--------------------------------------------------------------------

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(final Long id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * @return the matches
     */
    public Set<Team> getTeams() {
        return teams;
    }

    /**
     * @param teams the matches to set
     */
    public void setTeams(final Set<Team> teams) {
        this.teams = teams;
    }
}
