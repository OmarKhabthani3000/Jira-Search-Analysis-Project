

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.envers.Audited;

/**
 * Coach.
 */
@Entity
@Audited
@Table(name = "a_coach",
        uniqueConstraints = {@UniqueConstraint(columnNames = { "name" }) })
public class Coach extends AbstractHuman implements Serializable {

    /**
     * UID.
     */
    private static final long serialVersionUID = 1027311624635851653L;

    /**
     * Code.
     */
    @Column(name = "code", length = 100, nullable = true)
    private String code;

    /** Name again because of constraint. */
    @Column(name = "name", length = 255, nullable = false)
    private String name;

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(final String code) {
        this.code = code;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(final String name) {
        this.name = name;
    }
}
