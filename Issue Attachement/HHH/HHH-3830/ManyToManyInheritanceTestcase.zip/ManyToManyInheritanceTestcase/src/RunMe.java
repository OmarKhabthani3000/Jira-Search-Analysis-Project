import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

/***
 * Envers @ManyToMany + Inheritance testcase.
 */
public class RunMe {

    /** Dependency. */
    @Autowired
    private TeamDao teamAdao;
    /** Dependency. */
    @Autowired
    private HumanDao humanDao;
    /** Dependency. */
    @Autowired
    private MatchDao matchDao;

    /**
     * @param args
     */
    public static void main(String[] args) {
        Team team = new Team();
        Student student = new Student();
        Coach coach = new Coach();
        Match match = new Match();

        team.setName("Super team");

        student.setName("Student One");
        student.setAbbrev("sOne");

        coach.setName("Coach of Super Team");
        coach.setCode("codeCST");

        match.setName("First match");

        Set<Team> teams = new HashSet<Team>();
        teams.add(team);

        //does not create record in a_human_to_team_aud table
        coach.setTeams(teams);
        //does not create record in a_human_to_team_aud table
        student.setTeams(teams);

        //creates record in a_team_to_match_AUD table
        match.setTeams(teams);

        teamAdao.store(team);
        humanDao.store(student);
        humanDao.store(coach);
        matchDao.store(match);

    }

}
