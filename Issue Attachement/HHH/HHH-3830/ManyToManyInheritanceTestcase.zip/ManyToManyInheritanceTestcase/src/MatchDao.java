

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * Class for DAO to work with class {@link Match}.
 */
public class MatchDao extends HibernateDaoSupport {

    /**
     * Stores entity.
     *
     * @param entity entity
     *
     * @return stored entity
     */
    public Match store(final Match entity) {
        getSession().saveOrUpdate(entity);
        return entity;
    }
}
