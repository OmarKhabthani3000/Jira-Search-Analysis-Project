

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.envers.Audited;

/**
 * Team.
 */
@Entity
@Audited
@Table(name = "a_team",
        uniqueConstraints = {
        @UniqueConstraint(columnNames = { "name" })
        }
)
public class Team implements Serializable {

    /**
     * UID.
     */
    private static final long serialVersionUID = -4154417516643316721L;

    /**
     * ID.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    /**
     * Name.
     */
    @Column(name = "name", length = 255, nullable = false)
    private String name;

    /**
     * People.
     */
    @ManyToMany(mappedBy = "teams")
    private Set<AbstractHuman> humans;

    /**
     * Matches.
     */
    @ManyToMany(mappedBy = "teams")
    private List<Match> matches;

    //-----------------------------------------------------------------------------
    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(final Long id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * @return the people
     */
    public Set<AbstractHuman> getPeople() {
        return humans;
    }

    /**
     * @param people the people to set
     */
    public void setPeople(final Set<AbstractHuman> people) {
        this.humans = people;
    }

    /**
     * @return the matches
     */
    public List<Match> getMatches() {
        return matches;
    }

    /**
     * @param matches the matches to set
     */
    public void setMatches(final List<Match> matches) {
        this.matches = matches;
    }

}
