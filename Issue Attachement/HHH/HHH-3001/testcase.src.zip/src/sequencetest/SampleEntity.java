package sequencetest;

import java.io.Serializable;
import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.id.enhanced.SequenceStyleGenerator;


@Entity
@Table(name="ENTITIES")
@GenericGenerator( name = "EntitySequence",
  strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
  parameters = 
  {
    @Parameter(name = SequenceStyleGenerator.SEQUENCE_PARAM, value = "S_ENTITIES"),
    @Parameter(name = SequenceStyleGenerator.INITIAL_PARAM, value = "1"),
    @Parameter(name = SequenceStyleGenerator.INCREMENT_PARAM, value = "1"),
    @Parameter(name = SequenceStyleGenerator.OPT_PARAM, value = "none"),
    @Parameter(name = SequenceStyleGenerator.FORCE_TBL_PARAM, value = "false")
  }
)
public class SampleEntity implements Serializable
{
  private Long id = null;
  
  @Id
  @GeneratedValue(generator="EntitySequence")
  @Column(name="ENT_ID")
  public Long getId()
  {
    return id;
  }
  
  public void setId(Long id)
  {
    this.id = id;
  }
}



