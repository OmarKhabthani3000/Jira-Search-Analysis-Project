/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sequencetest;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

/**
 *
 * @author Sas László
 */
public class TestThread extends Thread
{

  protected final int id;

  protected final EntityManagerFactory entityManagerFactory;

  public TestThread(EntityManagerFactory entityManagerFactory, int id)
  {
    this.entityManagerFactory = entityManagerFactory;
    this.id = id;
  }

  @Override
  public void run()
  {
    System.out.println("Thread "+String.valueOf(id)+" started.");
    EntityManager em = null;
    try
    {
      em = entityManagerFactory.createEntityManager();
      EntityTransaction trans = null;
      try
      {
        for(int i=0; i<1000;i++)
        {
          trans = em.getTransaction();
          trans.begin();
          SampleEntity se = new SampleEntity();
          em.persist(se);
          trans.commit();
        }
      }
      finally
      {
        if(trans!=null && trans.isActive())
        {
          trans.rollback();
        }
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
    finally
    {
      if(em!=null)
      {
        em.close();
      }
    }
    System.out.println("Thread "+String.valueOf(id)+" stopped.");
  }
}
