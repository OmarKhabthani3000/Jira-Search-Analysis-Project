/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sequencetest;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Sas László
 */
public class Main
{
  public static final int MAX_THREADS = 10;
  /**
   * @param args the command line arguments
   */
  public static void main(String[] args)
  {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("SequenceTest");
    TestThread[] threads = new TestThread[MAX_THREADS];
    for(int i=0; i<MAX_THREADS; i++)
    {
      threads[i] = new TestThread(emf, i);
    }
    for(int i=0; i<MAX_THREADS; i++)
    {
      threads[i].start();
    }
  }
}
