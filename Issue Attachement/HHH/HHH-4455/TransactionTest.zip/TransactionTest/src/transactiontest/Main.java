package transactiontest;

import com.domain.Contact;
import com.domain.Location;
import com.domain.LocationTransaction;
import java.util.HashSet;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author stole
 */
public class Main {

    private static SessionFactory sf = new Configuration().configure().buildSessionFactory();

    public static void main(String[] args) {
        setup();
        System.out.println("Before test");
        printState();
        doTest();
        System.out.println("After test");
        printState();
    }

    private static void setup() {
        final Session s = sf.openSession();
        final Transaction tx = s.beginTransaction();
        try {
            //clear database
            s.createSQLQuery("TRUNCATE TABLE LocationTransaction").executeUpdate();
            s.createSQLQuery("TRUNCATE TABLE Transaction").executeUpdate();
            s.createSQLQuery("TRUNCATE TABLE Contact").executeUpdate();
            s.createSQLQuery("TRUNCATE TABLE Location").executeUpdate();

            Location l = new Location("l1", "l1");
            Contact c = new Contact(l, "contact");
            HashSet<Contact> contacts = new HashSet<Contact>(1);
            contacts.add(c);
            l.setContacts(contacts);
            s.save(l);

            LocationTransaction lt = new LocationTransaction();
            lt.setLocation(l);
            lt.setCompleted(false);
            s.save(lt);
            tx.commit();
        } catch (Exception e) {
            tx.rollback();
            System.out.println(e);
        } finally {
            s.close();
        }
    }

    private static void doTest() {
        final Session s = sf.openSession();
        final Transaction tx = s.beginTransaction();
        try {
            System.out.println("Start Test");

            Location l = (Location) s.createQuery("from Location l where l.name = 'l1'").uniqueResult();

            final Query deleteTransactionQuery = s.createQuery(
                    "delete from LocationTransaction lt " +
                    "where lt.location = (:location)");
            deleteTransactionQuery.setParameter("location", l);
            deleteTransactionQuery.executeUpdate();

            final Query deleteContactQuery = s.createQuery(
                    "delete from Contact c " +
                    "where c.location = (:location)");
            deleteContactQuery.setParameter("location", l);
            deleteContactQuery.executeUpdate();

            final Query deleteQuery = s.createQuery(
                    "delete from Location l where l = (:location)");
            deleteQuery.setParameter("location", l);
            deleteQuery.executeUpdate();

            //s.delete(l);
            throw new RuntimeException("test");
            //tx.commit();
        } catch (Exception e) {
            tx.rollback();
            System.out.println(e);
        } finally {
            s.close();
        }
    }

    private static void printState() {
        final Session s = sf.openSession();
        final Transaction tx = s.beginTransaction();
        try {
            System.out.println("LOCATIONS");
            List<Location> locations = s.createQuery("from Location").list();
            for (Location location : locations) {
                System.out.println("ID:" + location.getId() + ";" +
                        " Name:" + location.getName() + ";" +
                        " Address:" + location.getAddress());
            }

            System.out.println("LOCATION TRANSACTIONS");
            List<LocationTransaction> transactions = s.createQuery("from LocationTransaction").list();
            for (LocationTransaction locationTransaction : transactions) {
                System.out.println("ID:" + locationTransaction.getId() + ";" +
                        " Location ID:" + locationTransaction.getLocation().getId());
            }

            System.out.println("CONTACTS");
            List<Contact> contacts = s.createQuery("from Contact").list();
            for (Contact contact : contacts) {
                System.out.println("ID:" + contact.getId() + ";" +
                        " Location ID:" + contact.getLocation().getId() +
                        " Contact name:" + contact.getName());
            }
            tx.commit();
        } catch (Exception e) {
            tx.rollback();
            System.out.println(e);
        } finally {
            s.close();
        }
    }
}
