package com.domain;

import java.io.Serializable;

/**
 *
 * @author stole
 */
public final class LocationTransaction extends Transaction implements Serializable {

    private static final long serialVersionUID = 1L;
    private Location location;

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }
}
