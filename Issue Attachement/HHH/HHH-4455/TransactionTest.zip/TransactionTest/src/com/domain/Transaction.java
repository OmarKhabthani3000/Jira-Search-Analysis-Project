package com.domain;

import java.io.Serializable;

/**
 *
 * @author stole
 */
public abstract class Transaction implements Serializable {

    protected Long id;
    protected boolean completed;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean getCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public void setCompleted() {
        setCompleted(true);
    }
}
