package com.domain;

import java.io.Serializable;

/**
 *
 * @author stole
 */
public final class Contact implements Serializable {

    private static final long serialVersionUID = 1L;
    private Long id;
    private Location location;
    private String name;

    public Contact() {
    }

    public Contact(Location location, String name) {
        this.location = location;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
