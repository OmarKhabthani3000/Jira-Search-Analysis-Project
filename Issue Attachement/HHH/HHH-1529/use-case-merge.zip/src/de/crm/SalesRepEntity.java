package de.crm;


public class SalesRepEntity implements java.io.Serializable {
	private static final long serialVersionUID = -4090693388150752068L;

	private long id = 0;
	private String name = "";
	private CustomerEntity customer = null;

	public SalesRepEntity() {
		super();
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public CustomerEntity getCustomer() {
		return customer;
	}
	public void setCustomer(CustomerEntity customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "{id=" + id + ", name=" + name + "}";
	}
	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (other instanceof SalesRepEntity == false) return false;

		final SalesRepEntity s = (SalesRepEntity) other;
		return id == s.id && name.equals(s.name);
	}
}
