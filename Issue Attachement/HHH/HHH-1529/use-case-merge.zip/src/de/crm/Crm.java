package de.crm;

import static de.crm.HibernateUtil.getSession;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.Transaction;


final public class Crm {
	private static final String BEGIN = "BEGIN ";
	private static final String END = "END ";
	
	private static final Log LOG = LogFactory.getLog(Crm.class);
	private static final boolean DEBUG = LOG.isDebugEnabled();
	private static BufferedReader console = new BufferedReader(new InputStreamReader(System.in));

	public static void main(String[] args) throws IOException {
		System.out.print("Customer ID: ");
		final String idStr = console.readLine();
		final Long id = new Long(idStr);
		System.out.print("New Name: ");
		final String nachname = console.readLine();

		final CustomerEntity kunde = findCustomerById(id);
		kunde.setName(nachname);
		updateCustomer(kunde);

		System.out.println("Customer: " + kunde);
		console.close();
		HibernateUtil.shutdown();
	}
	
	/**
	 */
	public static CustomerEntity findCustomerById(long id) {
		if (DEBUG) LOG.debug(BEGIN + "findCustomerById: " + id);

		HibernateUtil.init();
		final Session session = getSession();
		final Transaction trans = session.getTransaction();
		
		trans.begin();
		CustomerEntity kunde = (CustomerEntity) session.get(CustomerEntity.class, id);
		trans.commit();
		
		HibernateUtil.close();
		if (DEBUG) LOG.debug(END + "findCustomerById: " + kunde);
		return kunde;
	}


	/**
	 */
	public static void updateCustomer(CustomerEntity customer) throws IOException {
		if (DEBUG) LOG.debug(BEGIN + "updateCustomer: " + customer);
		
		HibernateUtil.init();
		final Session session = getSession();
		final Transaction trans = session.getTransaction();
		
		trans.begin();

		// TODO: WHY ???
		//session.refresh(customer.getSalesRep());
		
		session.merge(customer);		
		trans.commit();

		HibernateUtil.close();
		if (DEBUG) LOG.debug(END + "updateCustomer");
	}

}