package de.crm;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	private static final SessionFactory SESSION_FACTORY;
	private static final ThreadLocal<Session> SESSION_THREADLOCAL = new ThreadLocal<Session>();

	static {
		try {
			SESSION_FACTORY = new Configuration().configure().buildSessionFactory();
		}
		catch (Throwable ex) {
			System.err.println("Initial SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}
	
	/**
	 * Session f&uuml;r DB-Operationen ermitteln
	 * @return Ein Objekt f&uuml;r die Session.
	 */
	public static boolean init() {
		Session session = SESSION_THREADLOCAL.get();
		if (session != null)
			return false;

		// Session oeffnen, falls noch nicht geoeffnet
		if (session == null) {
			session = SESSION_FACTORY.openSession();
			SESSION_THREADLOCAL.set(session);    // Zuweisung an ThreadLocal
		}
		return true;
	}

	/**
	 * Session f&uuml;r DB-Operationen ermitteln
	 * @return Ein Objekt f&uuml;r den EntityManager.
	 */
	public static Session getSession() {
		Session session = SESSION_THREADLOCAL.get();

		// Session oeffnen, falls noch nicht geoeffnet
		if (session == null) {
			session = SESSION_FACTORY.openSession();
			SESSION_THREADLOCAL.set(session);    // Zuweisung an ThreadLocal
		}

		return session;
	}

	/**
	 * Schlie&szlig;en der Session
	 */
	public static void close() {
		final Session session = SESSION_THREADLOCAL.get();
		if (session != null) {
			session.close();
			SESSION_THREADLOCAL.set(null);
		}
	}
	
	/**
	 * Schlie&szlig;en von SessionFactory: Beim Herunterfahren der Applikation.
	 */
	public static void shutdown() {
		SESSION_FACTORY.close();
	}
	
}