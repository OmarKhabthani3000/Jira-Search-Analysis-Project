package de.crm;


public class CustomerEntity implements java.io.Serializable {
	private static final long serialVersionUID = 910134214387197839L;

	protected long id = 0;
	protected String name = "";
	protected SalesRepEntity salesRep;

	public CustomerEntity() {
		super();
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}
	public void setName(String nachname) {
		this.name = nachname;
	}

	public SalesRepEntity getSalesRep() {
		return salesRep;
	}

	public void setSalesRep(SalesRepEntity betreuer) {
		this.salesRep = betreuer;
	}

	@Override
	public String toString() {
		return "id=" + id + ", name=" + name;
	}

	@Override
	public boolean equals(Object other) {
		if (this == other) return true;
		if (other instanceof CustomerEntity == false) return false;

		final CustomerEntity c = (CustomerEntity) other;
		boolean result = id == c.id && name.equals(c.name);
		return result;
	}
}