SET search_path TO hska;

CREATE SEQUENCE customer_sequence START WITH 6;
ALTER TABLE customer
	ALTER COLUMN id SET NOT NULL,
	ADD CONSTRAINT customer_pk PRIMARY KEY(id),
	ALTER COLUMN id SET DEFAULT nextval('customer_sequence'),
	ALTER COLUMN name SET NOT NULL;

CREATE SEQUENCE sales_rep_sequence START WITH 44;
ALTER TABLE sales_rep
	ALTER COLUMN id SET NOT NULL,
	ADD CONSTRAINT sales_rep_pk PRIMARY KEY(id),
	ALTER COLUMN id SET DEFAULT nextval('sales_rep_sequence'),
	ALTER COLUMN name SET NOT NULL,
	ALTER COLUMN customer_fk SET NOT NULL;
CREATE INDEX sales_rep_customer_index ON sales_rep(customer_fk);
