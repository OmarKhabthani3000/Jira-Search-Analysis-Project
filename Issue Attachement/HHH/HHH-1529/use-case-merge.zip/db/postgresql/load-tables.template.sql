SET search_path TO hska;
SET datestyle TO 'DMY';

COPY customer
	FROM '@BASEDIR@/csv/customer.csv'
	DELIMITER ';' CSV HEADER;

COPY sales_rep
	FROM '@BASEDIR@/csv/sales_rep.csv'
	DELIMITER ';' CSV HEADER;
