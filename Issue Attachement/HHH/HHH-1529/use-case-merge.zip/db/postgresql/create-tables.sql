SET search_path TO hska;

-- Tablespaces werden von PostgreSQL nur unterstuetzt,
-- wenn das Betriebssystem symbolische Links (symbolic links) unterstuetzt.

CREATE TABLE customer(
	id BIGINT,
	name VARCHAR(32)
);

CREATE TABLE sales_rep(
	id BIGINT,
	name VARCHAR(32),
	customer_fk BIGINT
);
