/*  Aufruf:
 *  sqlplus system/<password> @reset-user
 */

REVOKE RESOURCE FROM hska;

COMMIT;
