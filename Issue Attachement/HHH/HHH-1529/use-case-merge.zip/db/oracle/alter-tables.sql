ALTER TABLE customer
	MODIFY id NOT NULL
/
ALTER TABLE customer
	ADD CONSTRAINT customer_pk PRIMARY KEY(id)
/
ALTER TABLE customer
	MODIFY name NOT NULL
/

ALTER TABLE sales_rep
	MODIFY id NOT NULL
/
ALTER TABLE sales_rep
	ADD CONSTRAINT sales_rep_pk PRIMARY KEY(id)
/
ALTER TABLE sales_rep
	MODIFY name NOT NULL
/
ALTER TABLE sales_rep
	MODIFY customer_fk NOT NULL
/
CREATE INDEX sales_rep_customer_index ON sales_rep(customer_fk)
/
ALTER TABLE sales_rep
	ADD CONSTRAINT sales_rep_customer_fk FOREIGN KEY (customer_fk) REFERENCES customer(id)
/


/*
 * Trigger
 */
CREATE SEQUENCE customer_sequence START WITH 6 NOMAXVALUE
/
CREATE OR REPLACE TRIGGER customer_trigger_insert
	BEFORE INSERT ON customer
	FOR EACH ROW
	BEGIN
		SELECT customer_sequence.NEXTVAL
		INTO   :NEW.id
		FROM   DUAL;
	END;
/

CREATE SEQUENCE sales_rep_sequence START WITH 44 NOMAXVALUE
/
CREATE OR REPLACE TRIGGER sales_rep_trigger_insert
	BEFORE INSERT ON sales_rep
	FOR EACH ROW
	BEGIN
		SELECT sales_rep_sequence.NEXTVAL
		INTO   :NEW.id
		FROM   DUAL;
	END;
/
