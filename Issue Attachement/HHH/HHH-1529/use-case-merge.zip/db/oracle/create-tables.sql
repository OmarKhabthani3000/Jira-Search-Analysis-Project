/*   Aufruf:
 *   sqlplus <user>/<password> @create-tables
 */

/*
 *   T A B E L L E N
 */
CREATE TABLE customer(
	id NUMBER(16),
	name NVARCHAR2(32)
);

CREATE TABLE sales_rep(
	id NUMBER(16),
	name NVARCHAR2(32),
	customer_fk NUMBER(16)
);
