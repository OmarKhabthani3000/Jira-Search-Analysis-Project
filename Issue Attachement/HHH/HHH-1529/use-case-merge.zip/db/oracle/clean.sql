/* Aufruf:
 * sqlplus <user>/<password> @clean
 */

DROP USER hska cascade;