/*  Aufruf:
 *  sqlplus system/<password> @create-user
 */

/*
 *   U S E R
 */
CREATE USER hska
	IDENTIFIED BY hskapassword
	DEFAULT TABLESPACE USERS;

GRANT CONNECT, RESOURCE TO hska;

COMMIT;
