package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.bugs.model.Entity1;
import org.hibernate.bugs.model.Entity2;
import org.hibernate.bugs.model.Entity2;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	@Test
	public void testCascadeManyToManyCollection() throws Exception {
		EntityManager em;
		Entity1 entity1;
		Entity2 entity2;
		
		// step 1: insert entity1 with entity2 children
		em = begin();
		entity1 = new Entity1();
		entity1.setId(1L);

		entity2 = new Entity2();
		entity2.setId(1L);
		entity1.getEntities2().add(entity2);

		em.persist(entity2);
		em.persist(entity1);
		commitAndClear(em);

		// step 2: read entity1 and then delete it (expected: entity.children are deleted too, because mapped as orphanremoval=true
		em = begin();
		entity1 = em.find(Entity1.class, 1L);
		// IMPORTANT: uncommenting the next line makes the test pass under hibernate 5.1.3
//		entity1.getEntities2().size();
		try {
			em.remove(entity1);
			commitAndClear(em);
		} catch (RuntimeException e) {
			// if we get here, an exception because auf fk constraint is thrown
			e.printStackTrace();
			Assert.fail("fk exception because entry in ManyToMany has not been deleted");
		}
	}

	private EntityManager begin() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		return entityManager;
	}
	
	private void commitAndClear(EntityManager em) {
		em.getTransaction().commit();
		em.clear();
	}
}
