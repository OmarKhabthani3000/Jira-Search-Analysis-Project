import org.hibernate.SQLQuery;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.classic.Session;
import org.hibernate.dialect.DerbyDialect;
import org.hibernate.junit.functional.FunctionalTestCase;


public class BidiOneBasedIndexedCollectionTest extends FunctionalTestCase {

	public BidiOneBasedIndexedCollectionTest(String string) {
		super(string);
	}

	public String getBaseForMappings() {
		return "";
	}
	
	public String[] getMappings() {
		return new String[] { "mappings.hbm.xml" };
	}

	public String getCacheConcurrencyStrategy() {
		return null;
	}

	public void configure(Configuration cfg) {

		cfg.setProperty(Environment.DRIVER, "org.apache.derby.jdbc.EmbeddedDriver");
		cfg.setProperty(Environment.URL, "jdbc:derby:embedded;create=true");
		cfg.setProperty(Environment.POOL_SIZE, "1");
		cfg.setProperty(Environment.SHOW_SQL, "true");
	}

	public void testOneBasedIndex() {
		Parent parent = new Parent();
		parent.addToChildren(new Child());
		parent.addToChildren(new Child());
		parent.addToChildren(new Child());
		
		Session session = openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(parent);
			session.getTransaction().commit();
			
			// Ensure the child index column value is 1.
			SQLQuery sql = session.createSQLQuery("SELECT {child.*} FROM CHILD {child} WHERE IDX = 0");
			sql.addEntity("child", Child.class);
			assertNull("Child at index 0 found.", sql.uniqueResult());
		}
		finally {
			session.close();
		}
	}
}
