
public class Child {
	private Long idChild;
	private Parent parent;
	private Long version;
	
	public Long getIdChild() {
		return idChild;
	}
	public void setIdChild(Long idChild) {
		this.idChild = idChild;
	}
	public Parent getParent() {
		return parent;
	}
	public void setParent(Parent parent) {
		this.parent = parent;
	}
	public void setVersion(Long version) {
		this.version = version;
	}
	public Long getVersion() {
		return version;
	}
}
