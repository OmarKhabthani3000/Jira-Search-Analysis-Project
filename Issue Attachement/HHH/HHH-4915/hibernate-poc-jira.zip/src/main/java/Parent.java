import java.util.ArrayList;
import java.util.List;


public class Parent {
	private Long idParent;
	private List children = new ArrayList();
	private Long version;
	
	public Long getIdParent() {
		return idParent;
	}
	public void setIdParent(Long idParent) {
		this.idParent = idParent;
	}
	public List getChildren() {
		return children;
	}
	public void setChildren(List children) {
		this.children = children;
	}
	public void addToChildren(Child child) {
		this.children.add(child);
		child.setParent(this);
	}
	public void setVersion(Long version) {
		this.version = version;
	}
	public Long getVersion() {
		return version;
	}
}
