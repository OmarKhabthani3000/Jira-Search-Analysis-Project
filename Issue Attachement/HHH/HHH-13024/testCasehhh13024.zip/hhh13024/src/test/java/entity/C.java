package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Entity
public class C implements Serializable {
  @Id
  @Column(name = "ID", unique = true, nullable = false, precision = 10)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "C_IDNR")
  private Long id;

  @Column(name = "NONPK", unique = true, nullable = false, length = 10)
  private String nonPk;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getNonPk() {
    return nonPk;
  }

  public void setNonPk(String nonPk) {
    this.nonPk = nonPk;
  }
}
