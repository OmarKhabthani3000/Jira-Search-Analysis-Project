package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import entity.A;
import entity.B;
import entity.C;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh13024Test() throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();

		Session session = entityManager.unwrap(Session.class);

		C c = new C();
		c.setNonPk("TEMP");

		A a = new A();
		a.setcValue(c);

		B b = new B();
		b.setcValue(c);

		session.persist(c);
		session.persist(a);
		session.persist(b);

		session.flush();

		session.clear();

		Query query1 = session.createQuery("SELECT a FROM A a JOIN FETCH a.cValue WHERE a.id = 1");
		query1.list();

		Query query2 = session.createQuery("SELECT b FROM B b JOIN FETCH b.cValue WHERE b.id = 1");
		query2.list();

		transaction.commit();
		entityManager.close();
	}
}
