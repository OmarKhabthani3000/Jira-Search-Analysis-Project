package x2.elements.interfaces;
public interface TransactionI { }
