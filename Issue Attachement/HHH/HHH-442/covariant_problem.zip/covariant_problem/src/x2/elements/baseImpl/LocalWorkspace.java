package x2.elements.baseImpl;
import x2.elements.interfaces.LocalWorkspaceI;
public class LocalWorkspace implements LocalWorkspaceI {
    private long         id;
    private Transaction  unCommittedTrx;
    private Transaction  visibleCommittedTrx;
    private long getId() {
        return id;
    }
    private void setId(long id) {
        this.id = id;
    }
    public Transaction getUnCommittedTrx() {
        return unCommittedTrx;
    }
    protected void setUnCommittedTrx(Transaction unCommittedTrx) {
        this.unCommittedTrx = unCommittedTrx;
    }
    public Transaction getVisibleCommittedTrx() {
        return visibleCommittedTrx;
    }
    protected void setVisibleCommittedTrx(Transaction visibleCommittedTrx) {
        this.visibleCommittedTrx = visibleCommittedTrx;
    }
}
