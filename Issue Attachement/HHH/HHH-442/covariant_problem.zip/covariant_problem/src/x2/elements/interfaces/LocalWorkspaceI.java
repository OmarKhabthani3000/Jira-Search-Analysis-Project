package x2.elements.interfaces;
public interface LocalWorkspaceI  {
    public TransactionI  getVisibleCommittedTrx();
}
