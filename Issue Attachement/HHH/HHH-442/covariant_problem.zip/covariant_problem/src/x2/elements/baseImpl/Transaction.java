package x2.elements.baseImpl;
import x2.elements.interfaces.TransactionI;
public class Transaction implements TransactionI {
    private long           id;
    private long getId() {
        return id;
    }
    private void setId(long id) {
        this.id = id;
    }
}
