package persistence.baseImpl;
import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import x2.elements.baseImpl.LocalWorkspace;
import x2.elements.baseImpl.Transaction;

public class PersistenceLayer {
    public static void main(String[] args) {
        Configuration config = new Configuration();
        try {
            config.addClass(LocalWorkspace.class);
            config.addClass(Transaction.class);
        } catch (MappingException e) {
            return ;
        }
        SessionFactory sessionFact = null;
        try {
            sessionFact = config.buildSessionFactory(); 
            Session session = sessionFact.openSession();
        } catch (HibernateException e) {
            e.printStackTrace();
        }
    }
}
