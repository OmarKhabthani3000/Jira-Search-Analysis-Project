package org.hibernate.bugs;

import java.io.Serializable;
import java.util.Objects;

public class AddressId implements Serializable {

    private Integer adressNr;
    private Integer lfdAdrNr;

    public Integer getAdressNr() {
        return this.adressNr;
    }

    public void setAdressNr(Integer adressNr) {
        this.adressNr = adressNr;
    }

    public Integer getLfdAdrNr() {
        return this.lfdAdrNr;
    }

    public void setLfdAdrNr(Integer lfdAdrNr) {
        this.lfdAdrNr = lfdAdrNr;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 61 * hash + Objects.hashCode(this.adressNr);
        hash = 61 * hash + Objects.hashCode(this.lfdAdrNr);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AddressId other = (AddressId) obj;
        if (!Objects.equals(this.adressNr, other.adressNr)) {
            return false;
        }
        return Objects.equals(this.lfdAdrNr, other.lfdAdrNr);
    }
}
