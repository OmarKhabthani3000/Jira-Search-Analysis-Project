package org.hibernate.bugs;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.hibernate.annotations.JoinColumnOrFormula;
import org.hibernate.annotations.JoinColumnsOrFormulas;
import org.hibernate.annotations.JoinFormula;

@Entity
@Table(name = "address")
@IdClass(AddressId.class)
public class Address {

    private Integer adressNr;
    private Integer lfdAdrNr;
    private String konzernNr;
    private Address konzern;
    private List<Address> konzernDaughters;

    @Id
    @Column(name = "address_nr")
    public Integer getAdressNr() {
        return adressNr;
    }

    public void setAdressNr(Integer adressNr) {
        this.adressNr = adressNr;
    }

    @Id
    @Column(name = "lfd_adr_nr")
    public Integer getLfdAdrNr() {
        return lfdAdrNr;
    }

    public void setLfdAdrNr(Integer lfdAdrNr) {
        this.lfdAdrNr = lfdAdrNr;
    }

    @Column(name = "konzern_nr")
    public String getKonzernNr() {
        return konzernNr;
    }

    public void setKonzernNr(String konzernNr) {
        this.konzernNr = konzernNr;
    }

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "konzern")
    public List<Address> getKonzernDaughters() {
        return konzernDaughters;
    }

    public void setKonzernDaughters(List<Address> konzernDaughters) {
        this.konzernDaughters = konzernDaughters;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumnsOrFormulas({
        @JoinColumnOrFormula(column = @JoinColumn(name = "konzern_nr", referencedColumnName = "address_nr", insertable = false, updatable = false)),
        @JoinColumnOrFormula(formula = @JoinFormula(value = "0", referencedColumnName = "lfd_adr_nr"))
    })
    public Address getKonzern() {
        return konzern;
    }

    public void setKonzern(Address konzern) {
        this.konzern = konzern;
    }
}
