/* 
 * Created on 2007-06-27 10:26:54 by pdyk
 * 
 */

package com.mycompany;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;

public class ManyTest extends TestCase {

	public void testMany() {

		try {

			SessionFactory factory = DaoTestUtils.buildFactory();

			Session session = factory.openSession();
			Transaction t = session.beginTransaction();

			Attribute a = new Attribute();
			a.setName("aname");

			session.save(a);

			Product p = new Product();
			p.setName("pname");
			p.setAttributeValues(new HashMap());

			AttributeValue av = new AttributeValue();
			av.setValue("12");

			p.getAttributeValues().put(a, av);

			session.save(p);
			
			t.commit();
			session.close();
			

			session = factory.openSession();
			t = session.beginTransaction();

			DetachedCriteria dc = DetachedCriteria.forClass(Product.class);

			List l = dc.getExecutableCriteria(session).list();

			for (Iterator iter = l.iterator(); iter.hasNext();) {
				Product product = (Product) iter.next();

				System.out.println(product);
        System.out.println(product.getAttributeValues().size());

        //trows exception for hibernate > 3.2.0 
				session.delete(product);
			}
			
			t.commit();
			session.close();

      session = factory.openSession();
      t = session.beginTransaction();

			dc = DetachedCriteria.forClass(Product.class);
			assertTrue(dc.getExecutableCriteria(session).list().isEmpty());

      t.commit();
      session.close();

		}
		catch (Exception e) {

			e.printStackTrace();
			fail(e.getMessage());
		}

	}
}
