/* 
 * Created on 2007-06-27 09:56:33 by pdyk
 * 
 */

package com.mycompany;


public class AttributeValue {

	private long id;
	private String value;
	private Product product;
	private Attribute attribute;

	
	public long getId() {
	
		return id;
	}
	public void setId(long id) {
	
		this.id = id;
	}
	public String getValue() {
	
		return value;
	}
	public void setValue(String value) {
	
		this.value = value;
	}
	public Attribute getAttribute() {
	
		return attribute;
	}
	public void setAttribute(Attribute attribute) {
	
		this.attribute = attribute;
	}
	public Product getProduct() {
	
		return product;
	}
	public void setProduct(Product product) {
	
		this.product = product;
	}
	
	public int hashCode() {

		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((attribute == null) ? 0 : attribute.hashCode());
		result = PRIME * result + ((product == null) ? 0 : product.hashCode());
		result = PRIME * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}
	
	public boolean equals(Object obj) {

		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final AttributeValue other = (AttributeValue) obj;
		if (attribute == null) {
			if (other.attribute != null)
				return false;
		}
		else if (!attribute.equals(other.attribute))
			return false;
		if (product == null) {
			if (other.product != null)
				return false;
		}
		else if (!product.equals(other.product))
			return false;
		if (value == null) {
			if (other.value != null)
				return false;
		}
		else if (!value.equals(other.value))
			return false;
		return true;
	}
	
	
}
