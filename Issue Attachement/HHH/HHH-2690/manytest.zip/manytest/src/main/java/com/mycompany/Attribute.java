/* 
 * Created on 2007-06-27 09:56:22 by pdyk
 * 
 */

package com.mycompany;


public class Attribute {

	private long id;
	private String name;

	
	public long getId() {
	
		return id;
	}
	public void setId(long id) {
	
		this.id = id;
	}
	
	public String getName() {
	
		return name;
	}
	public void setName(String name) {
	
		this.name = name;
	}
	
	public boolean equals(Object object) {
	
		if (!(object instanceof Attribute)) {
			return false;
		}
		Attribute rhs = (Attribute) object;
		
		return rhs.getName().equals(name);
	}
	
	public int hashCode() {
	
		return (Attribute.class + name).hashCode();
	}
	
	
	
	
}
