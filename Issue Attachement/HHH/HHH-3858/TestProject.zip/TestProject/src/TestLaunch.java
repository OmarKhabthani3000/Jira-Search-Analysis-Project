import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;



public class TestLaunch {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Configuration configuration=new Configuration().configure();
		Session sess = configuration.buildSessionFactory().openSession();
		Transaction transaction = sess.beginTransaction();	
		OrderHead head=new OrderHead("hello");
		head.orderLinesLink=new ArrayList();
		head.orderLinesLink.add(new OrderLine(2323));
		sess.save(head);
		sess.flush();
		
		/*
		Criteria crit = sess.createCriteria(OrderHead.class).createCriteria("orderLinesLink");								
		List list = crit.list();
	//	Query q = sess.createQuery("from OrderHead as o inner join o.orderLinesLink");
	//	List list = q.list();
		System.out.println(list.size());*/
		sess.close();		
	}

}
