package edu.cmu.hazen.jpa.test;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
public class Person {
	@Id
	@Column(length = 16)
	private UUID id;
	private String name;
	@Cascade(CascadeType.ALL)
	private ContactInfo contactInfo;

	public Person() {}

	public Person(UUID id, String name, ContactInfo contactInfo) {
		super();
		this.id = id;
		this.name = name;
		this.contactInfo = contactInfo;
	}

	@Override
	public String toString() {
		return "{id: " + id + ", name: " + name + ", contactInfo: " + contactInfo
				+ "}";
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ContactInfo getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(ContactInfo contactInfo) {
		this.contactInfo = contactInfo;
	}
}
