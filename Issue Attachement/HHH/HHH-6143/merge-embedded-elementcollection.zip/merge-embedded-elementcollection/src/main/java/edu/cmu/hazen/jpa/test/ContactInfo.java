package edu.cmu.hazen.jpa.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Embeddable
public class ContactInfo {
	@ElementCollection(fetch = FetchType.EAGER)
	@Cascade(CascadeType.ALL)
	private List<String> emailAddresses;
	@Temporal(TemporalType.DATE)
	private Date lastModified = new Date();

	public ContactInfo() {}

	public ContactInfo(List<String> emailAddresses) {
		super();
		this.emailAddresses = emailAddresses;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result =
				prime * result
						+ ((emailAddresses == null) ? 0 : emailAddresses.hashCode());
		result =
				prime * result + ((lastModified == null) ? 0 : lastModified.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		ContactInfo other = (ContactInfo) obj;
		if (emailAddresses == null) {
			if (other.emailAddresses != null) return false;
		} else if (!emailAddresses.equals(other.emailAddresses)) return false;
		if (lastModified == null) {
			if (other.lastModified != null) return false;
		} else if (!lastModified.equals(other.lastModified)) return false;
		return true;
	}

	@Override
	public String toString() {
		return "{emailAddresses: " + emailAddresses + ", lastModified: "
				+ lastModified + "}";
	}

	public List<String> getEmailAddresses() {
		return emailAddresses;
	}

	public void setEmailAddresses(List<String> emailAddresses) {
		this.emailAddresses = emailAddresses;
	}

	public ContactInfo add(String... emailAddresses) {
		if (this.emailAddresses == null) {
			this.emailAddresses =
					new ArrayList<String>(Arrays.asList(emailAddresses));
		} else {
			Collections.addAll(this.emailAddresses, emailAddresses);
		}
		return this;
	}

	public Date getLastModified() {
		return lastModified;
	}

	public void setLastModified(Date lastModified) {
		this.lastModified = lastModified;
	}
}
