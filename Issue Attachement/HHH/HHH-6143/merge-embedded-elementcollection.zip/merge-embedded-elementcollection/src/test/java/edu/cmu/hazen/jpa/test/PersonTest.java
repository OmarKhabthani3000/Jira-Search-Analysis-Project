package edu.cmu.hazen.jpa.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.MethodRule;
import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.Statement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PersonTest {
	private static final Logger log = LoggerFactory.getLogger(PersonTest.class);
	private EntityManager em;

	@Rule
	public MethodRule initializeJPA = new MethodRule() {
		private EntityManagerFactory emf;

		public Statement apply(final Statement base, FrameworkMethod method,
				Object target) {
			return new Statement() {
				@Override
				public void evaluate() throws Throwable {
					emf =
							Persistence
									.createEntityManagerFactory("MERGE_EMBEDDED_ELEMENTCOLLECTION_TEST");
					em = emf.createEntityManager();
					try {
						base.evaluate();
					} finally {
						em.close();
						emf.close();
					}
				}
			};
		}
	};

	@Test
	public void mergePerson() {
		UUID id = new UUID(0, 0);
		Person person =
				new Person(id, "Joe", new ContactInfo().add("joe@work.com"));

		// merge person
		log.debug("Merging Person instance");
		em.getTransaction().begin();
		try {
			// ignore return value from merge
			em.merge(person);
			em.getTransaction().commit();
		} finally {
			if (em.getTransaction().isActive()) em.getTransaction().rollback();
		}

		// retrieve person
		log.debug("Retrieving Person instance");
		Person person2 = null;
		em.getTransaction().begin();
		try {
			person2 = em.find(Person.class, id);
			em.getTransaction().commit();
		} finally {
			if (em.getTransaction().isActive()) em.getTransaction().rollback();
		}

		// compare
		log.debug("Comparing Person instances");
		log.debug("Expected: " + person);
		log.debug("Actual: " + person2);
		assertNotNull(person);
		assertNotNull(person2);
		assertEquals(person.getId(), person2.getId());
		assertEquals(person.getName(), person2.getName());
		assertEquals(person.getContactInfo(), person2.getContactInfo());
	}
}
