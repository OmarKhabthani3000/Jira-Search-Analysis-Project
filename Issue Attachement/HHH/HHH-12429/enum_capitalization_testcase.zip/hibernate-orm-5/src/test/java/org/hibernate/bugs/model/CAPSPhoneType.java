package org.hibernate.bugs.model;

public enum CAPSPhoneType {
    LAND_LINE,
    MOBILE
}

