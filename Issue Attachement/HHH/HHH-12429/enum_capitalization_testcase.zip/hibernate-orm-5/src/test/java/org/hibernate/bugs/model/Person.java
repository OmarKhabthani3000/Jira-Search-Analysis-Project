package org.hibernate.bugs.model;

import javax.persistence.*;
import java.util.HashMap;
import java.util.Map;

@Entity(name = "Person")
public class Person {

    @Id
    private Long id;

    @ElementCollection(fetch = FetchType.EAGER)
    @MapKeyEnumerated(EnumType.STRING)
    @MapKeyColumn(name = "key")
    @Column(name = "value")
    @CollectionTable(name = "phone_desc", joinColumns = @JoinColumn(name = "type_phone_desc_id"))
    private Map<CAPSPhoneType, String> capsPhoneType = new HashMap<>();

    @ElementCollection(fetch = FetchType.EAGER)
    @MapKeyEnumerated(EnumType.STRING)
    @MapKeyColumn(name = "key")
    @Column(name = "value")
    @CollectionTable(name = "phone_desc", joinColumns = @JoinColumn(name = "type_phone_desc_id"))
    private Map<NoCapsPhoneType, String> noCapsPhoneType = new HashMap<>();

    public Person() {
    }

}