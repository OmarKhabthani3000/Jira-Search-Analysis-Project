package org.hibernate.bugs.model;

public class PhoneTypeReport {
    private final long id;
    private final String s1;
    private final String s2;

    public PhoneTypeReport(long id, String s1, String s2) {
        this.id = id;
        this.s1 = s1;
        this.s2 = s2;
    }

}
