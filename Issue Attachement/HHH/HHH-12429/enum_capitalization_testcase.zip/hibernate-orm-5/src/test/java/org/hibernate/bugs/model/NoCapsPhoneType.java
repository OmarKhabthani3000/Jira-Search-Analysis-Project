package org.hibernate.bugs.model;

public enum NoCapsPhoneType {
    LAND_LINE,
    MOBILE
}

