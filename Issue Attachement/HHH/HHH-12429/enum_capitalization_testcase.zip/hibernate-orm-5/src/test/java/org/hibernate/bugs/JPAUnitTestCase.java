package org.hibernate.bugs;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {
	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
    @Test
    public void noCapsTest_AlwaysOK() throws Exception {

		String noCapsQuery = "SELECT new org.hibernate.bugs.model.PhoneTypeReport(p.id, value(p1), value(p2)) " +
				" from Person p " +
				" LEFT JOIN p.noCapsPhoneType p1 ON KEY(p1) = org.hibernate.bugs.model.NoCapsPhoneType.MOBILE " +
				" LEFT JOIN p.noCapsPhoneType p2 ON KEY(p2) = org.hibernate.bugs.model.NoCapsPhoneType.LAND_LINE ";
		EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.createQuery(noCapsQuery).getResultList();
        entityManager.getTransaction().commit();
        entityManager.close();
    }

	@Test
	public void capsTest_WillFailOn_5_2_14() throws Exception {
		String capsQuery = "SELECT new org.hibernate.bugs.model.PhoneTypeReport(p.id, value(p1), value(p2)) " +
				" from Person p " +
				" LEFT JOIN p.capsPhoneType p1 ON KEY(p1) = org.hibernate.bugs.model.CAPSPhoneType.MOBILE " +
				" LEFT JOIN p.capsPhoneType p2 ON KEY(p2) = org.hibernate.bugs.model.CAPSPhoneType.LAND_LINE ";
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.createQuery(capsQuery).getResultList();
		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
