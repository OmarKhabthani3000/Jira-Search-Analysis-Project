package app;

import db.Customer;
import db.Association;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MyMain {
    
    
    /**
     * Simulate another user/process commits our customer!
     */
    private static void anotherUserCommits()
    {
        executeSQL("UPDATE CUSTOMER SET VERSION=999 WHERE CUSTOMER_ID=1");
        //"UPDATE ASSOCIATION SET VERSION=999 WHERE CUSTOMER_ID=1");
    }
    
    
    private static void executeSQL(String sql)
    {
        Connection conn = null;
        Statement st = null;
        try
        {
            Class.forName("org.firebirdsql.jdbc.FBDriver").newInstance();
            conn = DriverManager.getConnection("jdbc:firebirdsql://localhost/testdb", "SYSDBA", "masterkey");
            st = conn.createStatement();
            st.executeUpdate(sql);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            if( st != null )
            {
                try { st.close(); } catch(SQLException ignored) { }
            }
            if( conn != null )
            {
                try { conn.close(); } catch(SQLException ignored) { }
            }
        }
    }
    
    
    private static void cleanup(Transaction tx)
    {
        if( tx != null )
        {
            try
            {
                tx.rollback();
            }
            catch(HibernateException ex)
            {
                ex.printStackTrace();
            }
        }
        
        try
        {
            HibernateUtil.closeSession();
        }
        catch(HibernateException ex)
        {
            ex.printStackTrace();
        }
    }
    
    
    
    private static <T> void updateObject(T o)
        throws HibernateException
    {
        Transaction tx = null;
        
        Session s = HibernateUtil.getSession();
        try
        {
            tx = s.beginTransaction();
            
            s.update( o );
            
            tx.commit();
        }
        catch(HibernateException e)
        {
            cleanup(tx);
            throw( e );
        }
        // leave the session open!
    }
    
    
    private static <T> T loadObject(Class cls, Serializable id)
        throws HibernateException
    {
        T obj = null;
        
        Session s = HibernateUtil.getSession();
        Transaction tx = null;
        try
        {
            tx = s.beginTransaction();
            
            // Return the persistent instance of the given entity class with 
            // the given identifier, assuming that the instance exists.
            // Use this only to retrieve an instance that you assume exists, 
            // where non-existence would be an actual error.
            obj = (T) s.load(cls, id);
            
            tx.commit();
        }
        catch(HibernateException e)
        {
            cleanup(tx);
            throw( e );
        }
        // leave the session open!
        
        return( obj );
    }
    
    
    private static <T> void reloadObject(boolean useRefresh, T o, Serializable id)
        throws HibernateException
    {
        
        Session s = HibernateUtil.getSession();
        Transaction tx = null;
        try
        {
            tx = s.beginTransaction();
            
            // reload object
            if( useRefresh )
            {
                s.refresh( o );
            }
            else
            {
                // expire from session cache
                if( s.contains( o ) )
                {
                    s.evict( o );
                }
                
                s.load(o, id);
            }
            
            tx.commit();
        }
        catch(HibernateException e)
        {
            cleanup(tx);
            throw( e );
        }
        // leave the session open!
    }
    
    
    
    public static void main(String[] args)
    {
        boolean USE_REFRESH = false; // set it to true to see that refresh() works!
        
        /**
         * FireBird DB service must be started!
         * DB is assumed to be empty!
         */
        
        // init db data
        executeSQL("DELETE FROM CUSTOMER");
        executeSQL("DELETE FROM ASSOCIATION");
        executeSQL("INSERT INTO CUSTOMER(CUSTOMER_ID,VERSION,FULLNAME) VALUES(1,0,'Gregory Kotsaftis')");
        executeSQL("INSERT INTO CUSTOMER(CUSTOMER_ID,VERSION,FULLNAME) VALUES(2,0,'Kostas Filippaios')");
        executeSQL("INSERT INTO ASSOCIATION(ASSOCIATION_ID,VERSION,CUSTOMER_ID,ANOTHER_CUSTOMER_ID) VALUES(100,0,1,2)");
        executeSQL("INSERT INTO ASSOCIATION(ASSOCIATION_ID,VERSION,CUSTOMER_ID,ANOTHER_CUSTOMER_ID) VALUES(200,0,2,1)");
        
        // hibernate init
        Configuration cfg = new Configuration();
        cfg.setProperty("hibernate.connection.driver_class", "org.firebirdsql.jdbc.FBDriver");
        cfg.setProperty("hibernate.connection.url", "jdbc:firebirdsql://localhost/testdb");
        cfg.setProperty("hibernate.connection.username", "SYSDBA");
        cfg.setProperty("hibernate.connection.password", "masterkey");
        cfg.setProperty("hibernate.dialect", "org.hibernate.dialect.FirebirdDialect");
        cfg.setProperty("hibernate.c3p0.acquire_increment", "1");
        cfg.setProperty("hibernate.c3p0.idle_test_period", "100");
        cfg.setProperty("hibernate.c3p0.max_size", "100");
        cfg.setProperty("hibernate.c3p0.min_size", "10");
        cfg.setProperty("hibernate.c3p0.max_statements", "0");
        cfg.setProperty("hibernate.c3p0.timeout", "100");
        cfg.addClass(db.Customer.class);
        cfg.addClass(db.Association.class);
        HibernateUtil.init( cfg );
        
        // db access
        
/* (1) load the customers */
        Customer cust1 = null;
        Customer cust2 = null;
        try
        {
            cust1 = loadObject(Customer.class, 1);
            cust2 = loadObject(Customer.class, 2);
        }
        catch(HibernateException e)
        {
            e.printStackTrace();
            System.exit( 1 );
        }
        System.out.println("LOAD cust1="+cust1.getFullname()+"#"+cust1.getCustomerId());
        System.out.println("LOAD cust2="+cust2.getFullname()+"#"+cust2.getCustomerId());
        
/* (2) simulate another user modifies our customer */
        anotherUserCommits();
        
/* (3) try to update our customer forcing an exception and a session close... */
        try
        {
            cust1.setFullname("George Mavrakis");
            updateObject(cust1);
        }
        catch(HibernateException e)
        {
            System.err.println("another user modified our customer!");
            // ignore this one, was done intentionally
        }
        
/* (4) now our customer is detached, try to reload him */
        try
        {
            System.out.println("Reloading data so user can see the changes...");
            reloadObject(USE_REFRESH, cust1, cust1.getCustomerId());
        }
        catch(HibernateException e)
        {
            e.printStackTrace();
            System.exit( 1 );
        }
        System.out.println("RELOAD cust1="+cust1.getFullname()+"#"+cust1.getCustomerId());
        
        // hibernate clean up
        try
        {
            HibernateUtil.closeSession();
            HibernateUtil.shutdown();
        }
        catch(HibernateException e)
        {
            e.printStackTrace();
        }
        
        /**
         * FireBird DB service can be stoped!
         */
    }
    
}
