package app;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public final class HibernateUtil {
    
    private static SessionFactory m_dbSessionFactory = null;    
    private static final ThreadLocal<Session> m_session =
        new ThreadLocal<Session>();
    
    
    /**
     * Creates the SessionFactory based on a specific configuration.
     * NOTE: MUST be invoked before any actual access to db.
     */
    public static void init(Configuration cfg)
        throws HibernateException
    {
        m_dbSessionFactory = cfg.buildSessionFactory();
    }
    
    
    /**
     * Closes the SessionFactory.
     * Should be called before application exit().
     * NOTE: all opened sessions for all threads should be closed
     * using the related closeSession().
     */
    public static void shutdown()
        throws HibernateException
    {
        m_dbSessionFactory.close();
    }

    
    /**
     * Opens a new session for current thread or
     * returns the active session if one exists.
     */
    public static Session getSession()
        throws HibernateException
    {
        Session s = m_session.get();
        if( s == null )
        {
            // Open a new Session, if this thread has none yet
            s = m_dbSessionFactory.openSession();
            
            // Store it in the ThreadLocal variable
            m_session.set(s);
        }
        
        return( s );
    }
    
    
    /**
     * Closes the active session for current thread if any.
     */
    public static void closeSession()
        throws HibernateException
    {
        Session s = m_session.get();
        
        if( s != null )
        {
            s.close();
        }
        
        m_session.set( null );
    }
    
}
