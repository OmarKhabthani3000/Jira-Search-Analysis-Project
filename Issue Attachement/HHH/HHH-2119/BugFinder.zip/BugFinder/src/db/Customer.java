package db;

import java.util.HashSet;
import java.util.Set;

public class Customer {
    
    private Integer customerId;
    
    private int version;
    
    private String fullname;
    
    private Set<Association> associations;
    
    
    public Customer()
    {
        setAssociations( new HashSet<Association>() );
    }

    public Integer getCustomerId()
    {
        return customerId;
    }

    public void setCustomerId(Integer customerId)
    {
        this.customerId = customerId;
    }

    public int getVersion()
    {
        return version;
    }

    public void setVersion(int version)
    {
        this.version = version;
    }

    public String getFullname()
    {
        return fullname;
    }

    public void setFullname(String fullname)
    {
        this.fullname = fullname;
    }

    public Set<Association> getAssociations()
    {
        return associations;
    }

    public void setAssociations(Set<Association> associations)
    {
        this.associations = associations;
    }

}
