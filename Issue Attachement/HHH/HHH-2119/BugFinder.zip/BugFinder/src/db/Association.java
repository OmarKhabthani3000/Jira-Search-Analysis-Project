package db;

public class Association {
    
    private Integer associationId;
    
    private int version;
    
    private Customer customer;
    private Customer associatedCustomer;
    
    
    public Association()
    {
    }

    public Integer getAssociationId()
    {
        return associationId;
    }

    public void setAssociationId(Integer associationId)
    {
        this.associationId = associationId;
    }

    public int getVersion()
    {
        return version;
    }

    public void setVersion(int version)
    {
        this.version = version;
    }

    public Customer getCustomer()
    {
        return customer;
    }

    public void setCustomer(Customer customer)
    {
        this.customer = customer;
    }

    public Customer getAssociatedCustomer()
    {
        return associatedCustomer;
    }

    public void setAssociatedCustomer(Customer associatedCustomer)
    {
        this.associatedCustomer = associatedCustomer;
    }
}
