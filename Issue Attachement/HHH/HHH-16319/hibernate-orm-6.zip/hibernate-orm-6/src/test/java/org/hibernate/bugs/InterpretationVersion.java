package org.hibernate.bugs;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Embeddable
@NoArgsConstructor
@AllArgsConstructor
public class InterpretationVersion implements Serializable {
    @Column(name = "interpretation_version", nullable = false, updatable = false)
    public Long version;

    @Column(name = "interpretation_uuid", nullable = false, updatable = false)
    public UUID uuid;
}
