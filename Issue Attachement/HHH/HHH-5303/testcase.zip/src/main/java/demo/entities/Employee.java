package demo.entities;


import javax.persistence.*;


@Entity
@Cacheable(false)
public class Employee {
    @Id    
    private Long id;

    private String name;

    @Version
    int version;


    private double salary;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

   

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @PrePersist
    public void prePersistHook() {
        System.out.println("Hi, I'm going to be persisted");
    }
}