package demo;

import demo.entities.Employee;
import org.junit.*;

import javax.persistence.*;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Without locking employees explicitly you would get a wrong total salary because the update done by
 * the second thread is not visible
 */
public class Tester {
    private EntityManagerFactory emf;

    @Before
    public void testData() throws Exception {
        emf = Persistence.createEntityManagerFactory("testPU");
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
        Employee emp1 = new Employee();
        emp1.setId(1L);
        emp1.setSalary(2000);
        em.persist(emp1);

        Employee emp2 = new Employee();
        emp2.setId(2L);
        emp2.setSalary(2200);
        em.persist(emp2);

        Employee emp3 = new Employee();
        emp3.setId(3L);
        emp3.setSalary(2300);
        em.persist(emp3);

        Employee emp4 = new Employee();
        emp4.setId(4L);
        emp4.setSalary(2400);
        em.persist(emp4);

        em.getTransaction().commit();

        em.close();


    }

    @After
    public void cleanup() {
        emf.close();

    }

    @Test
    public void testCacheAfterInsert() {
        EntityManager em = emf.createEntityManager();
        Cache cache = emf.getCache();

        boolean contains = cache.contains(Employee.class, 1L);
        assertFalse(contains);

        em.find(Employee.class, 1L);

        em.close();

    }

    @Test
    public void testCacheAfterFind() {
        EntityManager em = emf.createEntityManager();
        Cache cache = emf.getCache();

        boolean contains = cache.contains(Employee.class, 1L);

        em.find(Employee.class, 1L);

        assertFalse(contains);


        em.close();
    }
}
 
 