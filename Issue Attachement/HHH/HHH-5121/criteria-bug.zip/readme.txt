This is a test application provided to illustrate the bug related to usage of Oracle
analytic functions with the JPA 2.0 Criteria API.

In order to run the test cases, the following needs to be be done:

1. Configure the JDBC URL and credentials

In src/main/resources/applicationContext.xml, look for the Spring bean named "dataSource" and
modify the value of the "url" property to replace the server name "CHANGE_ME" with the actual
server name hosting the Oracle XE DB.

If you will be using any other Oracle DB, then you'll also need to modify the service name.

The application uses the HR schema which comes by default with any Oracle XE installation. The
table used is the "REGION" table. In case you do not have the HR schema in your DB, I've provided
the script required to create the "REGION" table under the "sql" folder.

2. Change Oracle JDBC driver dependency in POM

Since the Oracle JDBC driver is not available on any Maven2 public repository, the dependency
setting for the driver will vary from one repository to the other.

Search for the dependency named "ojdbc" in the "pom.xml" and modify it to match your local
repository.

