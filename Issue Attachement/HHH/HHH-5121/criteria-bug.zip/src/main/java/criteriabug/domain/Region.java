package criteriabug.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "REGIONS")
public class Region {
	private static final long serialVersionUID = 1L;

	private Long regionId;
	private String regionName;

	@Id
	@Column(name = "REGION_ID", nullable = false)
	public Long getRegionId() {
		return this.regionId;
	}

	public void setRegionId(Long newRegionId) {
		this.regionId = newRegionId;
	}

	@Column(name = "REGION_NAME", nullable = false)
	public String getRegionName() {
		return this.regionName;
	}

	public void setRegionName(String newRegionName) {
		this.regionName = newRegionName;
	}
}
