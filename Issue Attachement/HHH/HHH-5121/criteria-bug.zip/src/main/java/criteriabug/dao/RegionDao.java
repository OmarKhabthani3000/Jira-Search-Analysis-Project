package criteriabug.dao;

import java.util.List;

import criteriabug.domain.Region;

public interface RegionDao {

    /**
     * Returns all regions.
     * 
     * @return a List of all Region objects. 
     */
	List<Region> findAllRegions();
	
	/**
	 * Returns all regions and their count using an Oracle analytical
	 * function.
	 * 
	 * This is a simplistic example that is only used to demonstrate the
	 * bug.
	 * 
	 * @return a List of Object arrays each containing a Region object
	 * 			and the total count.
	 */
	List<Object[]> findAllRegionsAndCount();
}
