package criteriabug.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import criteriabug.dao.RegionDao;
import criteriabug.domain.Region;

@Repository
public class RegionDaoImpl implements RegionDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	public List<Region> findAllRegions() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Region> cq = cb.createQuery(Region.class);

        cq.from(Region.class);

        TypedQuery<Region> q = entityManager.createQuery(cq);
        return q.getResultList();
	}

	public List<Object[]> findAllRegionsAndCount() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Object[]> cq = cb.createQuery(Object[].class);
        
        Root<Region> region = cq.from(Region.class);
        Expression<Long> count = 
            cb.function("COUNT(*) OVER", Long.class);
        cq.multiselect(region, count);

        TypedQuery<Object[]> q = entityManager.createQuery(cq);
        return q.getResultList();
	}
}
