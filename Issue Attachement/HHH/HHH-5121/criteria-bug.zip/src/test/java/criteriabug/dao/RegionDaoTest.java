package criteriabug.dao;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;
import org.unitils.database.annotations.Transactional;
import org.unitils.spring.annotation.SpringBeanByType;

import criteriabug.BaseTestCase;
import criteriabug.domain.Region;

@Transactional
public class RegionDaoTest extends BaseTestCase {

	@SpringBeanByType
	RegionDao regionDao;

	@Test
	public void testFindAllRegions() {
		List<Region> allRegions = regionDao.findAllRegions();
		assertTrue("No regions returned; verify that table has records",
				allRegions.size() > 0);
		
		for (Region r : allRegions) {
			System.out.println(new StringBuffer("Region (id = ")
				.append(r.getRegionId()).append(") (name = ")
				.append(r.getRegionName()).append(")"));
		}
	}
	
	@Test
	public void testFindAllRegionsAndCount() {
		List<Object[]> results = regionDao.findAllRegionsAndCount();
		assertTrue("No regions returned; verify that table has records",
				results.size() > 0);

		assertTrue("Count returned is not correct",
				results.size() == (Long)results.get(0)[1]);
	}
}
