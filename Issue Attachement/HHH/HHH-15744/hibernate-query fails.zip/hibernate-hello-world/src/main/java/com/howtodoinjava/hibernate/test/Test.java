package com.howtodoinjava.hibernate.test;

public interface Test {
    String getName();
}
