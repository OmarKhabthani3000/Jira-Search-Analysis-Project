package com.howtodoinjava.hibernate.test;

import org.hibernate.Session;

import com.howtodoinjava.hibernate.test.dto.TestEntity;

public class TestHibernate {

	public static void main(String[] args) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();

		TestEntity test = new TestEntity();
		test.setName("test");

		session.persist(test);

		session.getTransaction().commit();


		var query = session.createQuery("from com.howtodoinjava.hibernate.test.dto.TestEntity u where (u.name = ?1)", TestEntity.class);
		query.setParameter(1, "test");
		System.out.println("With implementation: " + query.getSingleResult().getName());

		var queryWorks = session.createQuery("from com.howtodoinjava.hibernate.test.Test u", Test.class);
		System.out.println("With interface: " + queryWorks.getSingleResult().getName());

		var queryFails = session.createQuery("from com.howtodoinjava.hibernate.test.Test u where (u.name = ?1)", Test.class);
		queryFails.setParameter(1, "test");
		System.out.println("With interface and where clause: " + queryFails.getSingleResult().getName());

		HibernateUtil.shutdown();
	}

}
