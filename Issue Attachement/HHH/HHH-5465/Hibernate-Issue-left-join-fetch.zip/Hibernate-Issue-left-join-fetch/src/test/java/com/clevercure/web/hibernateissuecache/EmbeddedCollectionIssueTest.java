/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.clevercure.web.hibernateissuecache;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.ejb.embeddable.EJBContainer;
import javax.inject.Inject;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

/**
 *
 * @author Christian
 */
public class EmbeddedCollectionIssueTest {

    @Inject
    Service service;
    
    @Test
    public void testTest() throws Exception {
        EJBContainer container = EJBContainer.createEJBContainer();
        container.getContext().bind("inject", this);
        
        User user = new User();
        user.setName("john");
        Contact contact = new Contact();
        contact.setName("John Doe");
        Set<EmailAddress> emailAddresses = new HashSet<EmailAddress>();
        emailAddresses.add(new EmailAddress("test1@test.com"));
        emailAddresses.add(new EmailAddress("test2@test.com"));
        emailAddresses.add(new EmailAddress("test3@test.com"));
        contact.setEmailAddresses(emailAddresses);
        contact = service.saveContact(contact);
        user.setContact(contact);
        user = service.saveUser(user);
        User freshUser = service.getById(user.getId());
        assertThat("Left join fetch did not work", user.getContact().getEmailAddresses(), is(freshUser.getContact().getEmailAddresses()));
    }
}