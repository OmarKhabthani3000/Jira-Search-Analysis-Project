package com.clevercure.web.hibernateissuecache;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class Service {

    @PersistenceContext()
    private EntityManager em;

    public User getById(long id) {
        return em.createQuery("SELECT user From User user LEFT OUTER JOIN FETCH user.contact contact LEFT OUTER JOIN FETCH contact.emailAddresses2 LEFT OUTER JOIN FETCH contact.emailAddresses WHERE user.id = :id", User.class).setParameter("id", id).getSingleResult();
    }

    public User saveUser(User user) {
        return em.merge(user);
    }

    public Contact saveContact(Contact contact) {
        return em.merge(contact);
    }
}
