import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.classic.Session;

public class Main
{
  public static void main(String[] args)
  {
    SessionFactory sessionFactory = new AnnotationConfiguration().addAnnotatedClass(EntityA.class).addAnnotatedClass(EntityB.class).addAnnotatedClass(EntityC.class).configure().buildSessionFactory();
    Session session = sessionFactory.getCurrentSession();
    Transaction txn = session.beginTransaction();

    // confirm that its valid to left join fetch an element collection using an explicit join to the collection
    session.createQuery("from EntityB b left join fetch b.items").list();

    // confirm that its valid to left join fetch one-to-one relationship
    session.createQuery("from EntityA a left join fetch a.entityB").list();

    // confirm that its valid to left join fetch one-to-one relationship and then fetch join an element collection using implicit join syntax  
    session.createQuery("from EntityA a left join fetch a.entityB.items").list();

    // confirm that its valid to left join fetch one-to-many joined entities and then left fetch join an element collection using explicit join syntax
    session.createQuery("from EntityA a left join fetch a.entityCs c left join fetch c.items").list();

    // demonstrate the we cannot left join fetch a one-to-one relationship and then left join fetch an element collection using explicit join syntax
    session.createQuery("from EntityA a left join fetch a.entityB b left join fetch b.items").list();
    txn.commit();
  }
}
