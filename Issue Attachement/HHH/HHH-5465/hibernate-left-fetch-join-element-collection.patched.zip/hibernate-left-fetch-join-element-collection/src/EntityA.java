import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class EntityA
{
  @Id
  int id;

  @OneToOne
  EntityB entityB;

  @OneToMany
  @JoinColumn(name = "entitya")
  Set<EntityC> entityCs = new HashSet<EntityC>();

  protected EntityA()
  {}

  protected EntityA(int id)
  {
    this.id = id;
  }

  public Integer getId()
  {
    return id;
  }

  public void setId(int id)
  {
    this.id = id;
  }

  public EntityB getEntityB()
  {
    return entityB;
  }

  public void setEntityB(EntityB entityB)
  {
    this.entityB = entityB;
  }

  public Set<EntityC> getEntityCs()
  {
    return entityCs;
  }

  public void setEntityCs(Set<EntityC> entityCs)
  {
    this.entityCs = entityCs;
  }
}
