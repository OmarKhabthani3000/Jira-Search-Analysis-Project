import java.util.HashSet;
import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class EntityB
{
  @ElementCollection
  Set<String> items = new HashSet<String>();

  @Id
  int id;

  protected EntityB()
  {}

  protected EntityB(int id)
  {
    this.id = id;
  }

  public Integer getId()
  {
    return id;
  }

  public void setId(int id)
  {
    this.id = id;
  }

  public Set<String> getItems()
  {
    return items;
  }

  public void setItems(Set<String> items)
  {
    this.items = items;
  }
}