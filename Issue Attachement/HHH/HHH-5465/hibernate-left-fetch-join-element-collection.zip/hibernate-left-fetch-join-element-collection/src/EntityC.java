import java.util.HashSet;
import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class EntityC
{
  @ElementCollection
  Set<String> items = new HashSet<String>();

  @Id
  int id;

  @OneToOne
  EntityC entityB;

  protected EntityC()
  {}

  protected EntityC(int id)
  {
    this.id = id;
  }

  public int getId()
  {
    return id;
  }

  public void setId(int id)
  {
    this.id = id;
  }

  public Set<String> getItems()
  {
    return items;
  }

  public void setItems(Set<String> items)
  {
    this.items = items;
  }
}