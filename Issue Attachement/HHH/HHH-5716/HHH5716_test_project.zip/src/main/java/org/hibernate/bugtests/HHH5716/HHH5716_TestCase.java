package org.hibernate.bugtests.HHH5716;

import javax.persistence.EntityManager;

import junit.framework.TestCase;

import org.hibernate.bugtests.HHH5716.data.Node;
import org.hibernate.bugtests.HHH5716.data.Transport;

/**
 * See http://opensource.atlassian.com/projects/hibernate/browse/HHH-3046
 * 
 * @author pavol.zibrita
 */
public class HHH5716_TestCase extends TestCase {

	String[] dbSetup = {
			"drop sequence NODE_SEQ",
			"drop sequence TRANSPORT_SEQ",
			"drop table NODE cascade constraints",
			"drop table TRANSPORT cascade constraints",
			"create sequence NODE_SEQ",
			"create sequence TRANSPORT_SEQ",
			"create table NODE (nodeID number(10) not null, name varchar2(100), constraint PK_NODE primary key (NODEID))",
			"create table TRANSPORT (transportID number(10) not null, name varchar2(100), deliveryNodeID number(10), constraint PK_TRANSPORT primary key (TRANSPORTID))",
			"alter table TRANSPORT " +
			    "add constraint FK_TRAN_DELIVERYNODE foreign key (DELIVERYNODEID) " +
			       "references NODE (NODEID) on delete cascade",
	};
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		EntityManager em = EntityManagerHelper.createEntityManager();
		for (String sql : dbSetup) {
			try {
				em.getTransaction().begin();
				em.createNativeQuery(sql).executeUpdate();
				em.getTransaction().commit();
			} catch (Exception e) {
				em.getTransaction().rollback();
				System.out.println(e.getMessage());
			}
		}
		EntityManagerHelper.commitAndCloseEntityManager(em);	
	}
	
	private Node deliveryNode;
	
	private Transport transport;
	

	private Node createObjects()
	{
		transport = new Transport();
		transport.setName("transportB");
		
		deliveryNode = new Node();
		deliveryNode.setName("deliveryNodeB");
		
		deliveryNode.getDeliveryTransport().add(transport);
		transport.setDeliveryNode(deliveryNode);
		
		return deliveryNode;
	}
	
	private Long saveData() {
		EntityManager em = EntityManagerHelper.createEntityManager();
		
		Node node = createObjects();
		em.persist(node);
		
		EntityManagerHelper.commitAndCloseEntityManager(em);
		return node.getNodeID();
	}
	
	/**
	 * THE test method 
	 */
	public void testBug_HHH5716()
	{
		Long nodeID = saveData();
		Node node;
		EntityManager em = EntityManagerHelper.createEntityManager();
		node = em.find(Node.class, nodeID);

		assertEquals("There should be 1 transport on node!", 1, node.getDeliveryTransport().size());
		EntityManagerHelper.commitAndCloseEntityManager(em);		


		em = EntityManagerHelper.createEntityManager();
		node = em.find(Node.class, nodeID);
		node.getDeliveryTransport().clear();
		transport = em.find(Transport.class, transport.getTransportID());
		em.remove(transport);
		assertEquals("There should be 0 transports on node!", 0, node.getDeliveryTransport().size());
		EntityManagerHelper.commitAndCloseEntityManager(em);		

	}
}
