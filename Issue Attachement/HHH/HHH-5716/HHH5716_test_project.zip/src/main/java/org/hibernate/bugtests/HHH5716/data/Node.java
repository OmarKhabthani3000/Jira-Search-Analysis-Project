package org.hibernate.bugtests.HHH5716.data;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Transient;

@Entity
public class Node {

	@Id
	@SequenceGenerator(name="NODE_SEQ", sequenceName="NODE_SEQ", initialValue=1, allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="NODE_SEQ")
	private Long nodeID;
	
	private String name;
	
	/** the list of orders that are delivered at this node */
	@OneToMany(fetch=FetchType.LAZY, cascade={CascadeType.ALL}, mappedBy="deliveryNode", orphanRemoval=false)
	private Set<Transport> deliveryTransport = new HashSet<Transport>();
	
	@Transient
	private String transientField = "node original value";

	public Set<Transport> getDeliveryTransport() {
		return deliveryTransport;
	}

	public void setDeliveryTransport(Set<Transport> deliveryTransport) {
		this.deliveryTransport = deliveryTransport;
	}

	public Long getNodeID() {
		return nodeID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String toString()
	{
		StringBuffer buffer = new StringBuffer();
		
		buffer.append(name + " id: " + nodeID + "\n");
		
		for (Transport transport : deliveryTransport) {
			buffer.append("Delivery transport: " + transport);
		}
		
		return buffer.toString();
	}

	public String getTransientField() {
		return transientField;
	}

	public void setTransientField(String transientField) {
		this.transientField = transientField;
	}

}
