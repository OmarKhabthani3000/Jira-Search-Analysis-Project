package org.hibernate.bugtests.HHH5716;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class EntityManagerHelper {

	private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("default");
	
	private EntityManagerHelper() {}

	/**
	 * Retrieve an application managed entity manager and start transaction
	 * @return entityManager
	 */
	public static EntityManager createEntityManager() {
		EntityManager em = emf.createEntityManager(); 
		em.getTransaction().begin();
		return em;
	}

	/**
	 * Commit transaction and close entity manager
	 * @param em entity manager
	 */
	public static void commitAndCloseEntityManager(EntityManager em) {
		if (em.getTransaction().isActive()) {
			em.getTransaction().commit();
		}
    	em.close();
	}
}
