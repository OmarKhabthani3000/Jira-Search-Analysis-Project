package hibernatetestgradle.main;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.Serializable;
import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.junit.jupiter.api.Test;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.DiscriminatorType;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "TYPE", discriminatorType = DiscriminatorType.STRING)
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
class MainEntity implements Serializable {
    private static final long serialVersionUID = -5412503864464287451L;

    @Id @GeneratedValue long id;
}

@Entity
@DiscriminatorValue("SUB")
class SubEntity extends MainEntity {
    private static final long serialVersionUID = -5412503864464287451L;
    @Column String someString;
}

public class RootCacheEntryTest {
    @Test
    public void test() {
        Transaction txn = null;
        final SessionFactory sessionFactory = newSessionFactory();
        long id;
        try (final Session session = sessionFactory.openSession()) {
            txn = session.beginTransaction();
            final SubEntity subEntity = new SubEntity();
            subEntity.someString = "notNull";
            session.persist(subEntity);
            session.flush();
            txn.commit();
            id = subEntity.id;
        }

        sessionFactory.getCache().evictAllRegions();

        try (final Session session = sessionFactory.openSession()) {
            txn = session.beginTransaction();
            session.get(SubEntity.class, id);
            txn.rollback();
        }

        try (final Session session = sessionFactory.openSession()) {
            txn = session.beginTransaction();
            final SubEntity s = session.get(SubEntity.class, id);
            assertEquals("notNull", s.someString);
            txn.rollback();
        }
    }

    protected SessionFactory newSessionFactory() {
        final Properties properties = new Properties();
        // log settings
        properties.put("hibernate.hbm2ddl.auto", "create");
        properties.put("hibernate.show_sql", true);
        // driver settings
        properties.put("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
        properties.put("hibernate.connection.driver_class", "org.hsqldb.jdbcDriver");
        properties.put("hibernate.connection.url", "jdbc:hsqldb:mem:tsg");
        properties.put("hibernate.connection.username", "sa");
        properties.put("hibernate.connection.password", "");
        properties.put("hibernate.cache.use_second_level_cache", true);
        properties.put("hibernate.cache.region.factory_class", "jcache");
        properties.put("org.ehcache.jsr107.EhcacheCachingProvider", "org.ehcache.jsr107.EhcacheCachingProvider");
        properties.put("hibernate.javax.cache.uri", "ehcache.xml");
        properties.put("hibernate.cache.use_structured_entries", true);

        return new Configuration().addProperties(properties)
                                  .addAnnotatedClass(MainEntity.class)
                                  .addAnnotatedClass(SubEntity.class)
                                  .buildSessionFactory(new StandardServiceRegistryBuilder().applySettings(properties).build());
    }
}
