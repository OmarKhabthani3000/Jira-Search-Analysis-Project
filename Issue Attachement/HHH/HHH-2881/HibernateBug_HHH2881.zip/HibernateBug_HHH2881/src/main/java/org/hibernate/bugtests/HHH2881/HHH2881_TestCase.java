package org.hibernate.bugtests.HHH2881;

import javax.persistence.EntityManager;

import org.hibernate.bugtests.data.Node;
import org.hibernate.bugtests.data.Route;
import org.hibernate.bugtests.data.Tour;
import org.hibernate.bugtests.data.Transport;

import junit.framework.TestCase;

/**
 * See http://opensource.atlassian.com/projects/hibernate/browse/HHH-2881
 * 
 * We want to achieve stack like this:
 * 
 * PersistentBag.beforeInitialize(CollectionPersister, int) line: xx //here is the same collection reinitialized again, and loaded again
   CollectionLoadContext.getLoadingCollection(CollectionPersister, Serializable) line: 127
   EntityLoader(Loader).readCollectionElement(Object, Serializable, CollectionPersister, CollectionAliases, ResultSet, SessionImplementor) line: 1003
   EntityLoader(Loader).readCollectionElements(Object[], ResultSet, SessionImplementor) line: 646
   EntityLoader(Loader).getRowFromResultSet(ResultSet, SessionImplementor, QueryParameters, LockMode[], EntityKey, List, EntityKey[], boolean) line: 591
   EntityLoader(Loader).doQuery(SessionImplementor, QueryParameters, boolean) line: 701
   EntityLoader(Loader).doQueryAndInitializeNonLazyCollections(SessionImplementor, QueryParameters, boolean) line: 236
   EntityLoader(Loader).loadEntity(SessionImplementor, Object, Type, Object, String, Serializable, EntityPersister) line: 1860
   EntityLoader(AbstractEntityLoader).load(SessionImplementor, Object, Object, Serializable) line: 48
   EntityLoader(AbstractEntityLoader).load(Serializable, Object, SessionImplementor) line: 42
   SingleTableEntityPersister(AbstractEntityPersister).load(Serializable, Object, LockMode, SessionImplementor) line: 3044
   DefaultLoadEventListener.loadFromDatasource(LoadEvent, EntityPersister, EntityKey, LoadEventListener$LoadType) line: 395
   DefaultLoadEventListener.doLoad(LoadEvent, EntityPersister, EntityKey, LoadEventListener$LoadType) line: 375
   DefaultLoadEventListener.load(LoadEvent, EntityPersister, EntityKey, LoadEventListener$LoadType) line: 139
   DefaultLoadEventListener.proxyOrLoad(LoadEvent, EntityPersister, EntityKey, LoadEventListener$LoadType) line: 195
   DefaultLoadEventListener.onLoad(LoadEvent, LoadEventListener$LoadType) line: 103
   SessionImpl.fireLoad(LoadEvent, LoadEventListener$LoadType) line: 878
   SessionImpl.internalLoad(String, Serializable, boolean, boolean) line: 846
   ManyToOneType(EntityType).resolveIdentifier(Serializable, SessionImplementor) line: 557
   ManyToOneType.assemble(Serializable, SessionImplementor, Object) line: 196
   TypeFactory.assemble(Serializable[], Type[], SessionImplementor, Object) line: 420
   CacheEntry.assemble(Serializable[], Object, Serializable, EntityPersister, Interceptor, EventSource) line: 96
   CacheEntry.assemble(Object, Serializable, EntityPersister, Interceptor, EventSource) line: 82
   DefaultLoadEventListener.assembleCacheEntry(CacheEntry, Serializable, EntityPersister, LoadEvent) line: 553
   DefaultLoadEventListener.loadFromSecondLevelCache(LoadEvent, EntityPersister, LoadEventListener$LoadType) line: 508
   DefaultLoadEventListener.doLoad(LoadEvent, EntityPersister, EntityKey, LoadEventListener$LoadType) line: 357
   DefaultLoadEventListener.load(LoadEvent, EntityPersister, EntityKey, LoadEventListener$LoadType) line: 139
   DefaultLoadEventListener.proxyOrLoad(LoadEvent, EntityPersister, EntityKey, LoadEventListener$LoadType) line: 195
   DefaultLoadEventListener.onLoad(LoadEvent, LoadEventListener$LoadType) line: 103
   SessionImpl.fireLoad(LoadEvent, LoadEventListener$LoadType) line: 878
   SessionImpl.internalLoad(String, Serializable, boolean, boolean) line: 846
   ManyToOneType(EntityType).resolveIdentifier(Serializable, SessionImplementor) line: 557
   ManyToOneType.assemble(Serializable, SessionImplementor, Object) line: 196
   PersistentBag.initializeFromCache(CollectionPersister, Serializable, Object) line: xxx //NOW HERE IS THE Bag initializing from cache, it fails, see top of the stack!!
   CollectionCacheEntry.assemble(PersistentCollection, CollectionPersister, Object) line: 35
   DefaultInitializeCollectionEventListener.initializeCollectionFromCache(Serializable, CollectionPersister, PersistentCollection, SessionImplementor) line: 130
   DefaultInitializeCollectionEventListener.onInitializeCollection(InitializeCollectionEvent) line: 48
   SessionImpl.initializeCollection(PersistentCollection, boolean) line: 1716
   PersistentBag(AbstractPersistentCollection).forceInitialization() line: 454
   StatefulPersistenceContext.initializeNonLazyCollections() line: 794
   QueryLoader(Loader).doQueryAndInitializeNonLazyCollections(SessionImplementor, QueryParameters, boolean) line: 241
   QueryLoader(Loader).doList(SessionImplementor, QueryParameters) line: 2220
   QueryLoader(Loader).listIgnoreQueryCache(SessionImplementor, QueryParameters) line: 2104
   QueryLoader(Loader).list(SessionImplementor, QueryParameters, Set, Type[]) line: 2099
   QueryLoader.list(SessionImplementor, QueryParameters) line: 378
   QueryTranslatorImpl.list(SessionImplementor, QueryParameters) line: 338
   HQLQueryPlan.performList(QueryParameters, SessionImplementor) line: 172
   SessionImpl.list(String, QueryParameters) line: 1121
   QueryImpl.list() line: 79
   QueryImpl.getResultList() line: 66
   //some stack before, uninportant 
 * 
 * @author pavol.zibrita
 */
public class HHH2881_TestCase extends TestCase {

	String[] dbSetup = {
			"drop sequence NODE_SEQ",
			"drop sequence TRANSPORT_SEQ",
			"drop sequence ROUTE_SEQ",
			"drop sequence TOUR_SEQ",
			"drop table ROUTE cascade constraints",
			"drop table NODE cascade constraints",
			"drop table TRANSPORT cascade constraints",
			"drop table TOUR cascade constraints",
			"create sequence NODE_SEQ",
			"create sequence TRANSPORT_SEQ",
			"create sequence ROUTE_SEQ",
			"create sequence TOUR_SEQ",
			"create table NODE (nodeID number(10) not null, routeID number(10) not null, tourID number(10), name varchar2(100), constraint PK_NODE primary key (NODEID))",
			"create table ROUTE (routeID number(10) not null, name varchar2(100), constraint PK_ROUTE primary key (ROUTEID))",
			"create table TOUR (tourID number(10) not null, name varchar2(100), constraint PK_TOUR primary key (TOURID))",
			"create table TRANSPORT (transportID number(10) not null, name varchar2(100), pickupNodeID number(10), deliveryNodeID number(10), constraint PK_TRANSPORT primary key (TRANSPORTID))",
			"alter table NODE " +
			    "add constraint FK_NODE_ROUTE foreign key (ROUTEID) " +
			       "references ROUTE (ROUTEID) on delete cascade",
			"alter table TRANSPORT " +
			    "add constraint FK_TRAN_DELIVERYNODE foreign key (DELIVERYNODEID) " +
			       "references NODE (NODEID) on delete cascade",
			"alter table TRANSPORT " +
			    "add constraint FK_TRAN_PICKUPNODE foreign key (PICKUPNODEID) " +
			       "references NODE (NODEID) on delete cascade"
	};
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		EntityManager em = EntityManagerHelper.createEntityManager();
		for (String sql : dbSetup) {
			try {
				em.getTransaction().begin();
				em.createNativeQuery(sql).executeUpdate();
				em.getTransaction().commit();
			} catch (Exception e) {
				em.getTransaction().rollback();
				System.out.println(e.getMessage());
			}
		}
		EntityManagerHelper.commitAndCloseEntityManager(em);	
	}
	
	private Node pickupNode;
	
	private Node deliveryNode;
	
	private Tour tour;
	
	private Transport transport;
	private Transport transportInverse;
	

	private void createObjects(Route route)
	{
		tour = new Tour();
		tour.setName("tourB");
		
		transport = new Transport();
		transport.setName("transportB");

		transportInverse = new Transport();
		transportInverse.setName("transportInverse");

		pickupNode = new Node();
		pickupNode.setName("pickupNodeB");

		deliveryNode = new Node();
		deliveryNode.setName("deliveryNodeB");
	}
	
	private void setRelations(Route route)
	{
		pickupNode.setRoute(route);
		pickupNode.setTour(tour);
		pickupNode.getPickupTransport().add(transport);
		pickupNode.getDeliveryTransport().add(transportInverse);
		
		deliveryNode.setRoute(route);
		deliveryNode.setTour(tour);
		deliveryNode.getDeliveryTransport().add(transport);
		deliveryNode.getPickupTransport().add(transportInverse);
		
		tour.getNode().add(pickupNode);
		tour.getNode().add(deliveryNode);
		
		route.getNode().add(pickupNode);
		route.getNode().add(deliveryNode);
		
		transport.setPickupNode(pickupNode);
		transport.setDeliveryNode(deliveryNode);

		transportInverse.setPickupNode(pickupNode);
		transportInverse.setDeliveryNode(pickupNode);
	}
	
	private void saveData() {
		EntityManager em = EntityManagerHelper.createEntityManager();
		
		Route route = new Route();
		route.setName("routeA");
		route.setTransientField(new String("sfnaouisrbn"));
		
		createObjects(route);
		
		transport.setTransientField("aaaaaaaaaaaaaa");
		pickupNode.setTransientField("pickup node aaaaaaaaaaa");
		deliveryNode.setTransientField("delivery node aaaaaaaaa");
		
		setRelations(route);
		em.persist(route);
		
		EntityManagerHelper.commitAndCloseEntityManager(em);
	}
	
	void loadData()
	{
		EntityManager em = EntityManagerHelper.createEntityManager();
		
		Route route = em.find(Route.class, 1L);

		assertEquals(route.getNode().size(), 2);
		assertEquals(route.getNode().get(0).getPickupTransport().size(), 2);
		assertEquals(route.getNode().get(0).getDeliveryTransport().size(), 1);
		assertEquals(route.getNode().get(1).getPickupTransport().size(), 0);
		assertEquals(route.getNode().get(1).getDeliveryTransport().size(), 1);
		
		EntityManagerHelper.commitAndCloseEntityManager(em);		
	}

	/**
	 * The test method 
	 */
	public void testBug_HHH3046()
	{
		saveData();
		loadData();
		assertTrue("First load passed without problems (not cached yet)!", true);
		loadData();
	}
}
