package org.hibernate.bugtests.data;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Transient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
public class Route {
	
	@Id
	@SequenceGenerator(name="ROUTE_SEQ", sequenceName="ROUTE_SEQ", initialValue=1, allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ROUTE_SEQ")
	private Long routeID;
	
	/** A List of nodes contained in this route. */
	@OneToMany(targetEntity=Node.class, fetch=FetchType.LAZY, cascade=CascadeType.ALL, mappedBy="route")
	@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
	private List<Node> nodeList = new ArrayList<Node>();
	
	private String name;
	
	@Transient
	private String transientField = null;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Node> getNode() {
		return nodeList;
	}

	public void setNode(List<Node> node) {
		this.nodeList = node;
	}

	public Long getRouteID() {
		return routeID;
	}
	
	public String toString()
	{
		StringBuffer buffer = new StringBuffer();
		
		buffer.append("Route name: " + name + " id: " + routeID + " transientField: " + transientField + "\n");
		for (Node node : nodeList) {
			buffer.append("Node: ").append(node);
		}
		
		return buffer.toString();
	}

	public String getTransientField() {
		return transientField;
	}

	public void setTransientField(String transientField) {
		this.transientField = transientField;
	}
}
