package dk.hibernatetest.model;

/**
 * No Documentation
 */
@javax.persistence.Entity
public class B extends dk.hibernatetest.model.AbstractEntity {
    private static final long serialVersionUID = 325417243L;

    /**
     * No documentation
     */
    @javax.persistence.OneToMany(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    , mappedBy = "b")
    private java.util.Set<dk.hibernatetest.model.C> cCollection = new java.util.HashSet<dk.hibernatetest.model.C>();

    /**
     * No documentation
     */
    @javax.persistence.ManyToOne(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    , optional = false)
    private dk.hibernatetest.model.A a;

    /**
     * No documentation
     */
    @javax.persistence.ManyToOne(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    , optional = false)
    private dk.hibernatetest.model.F f;

    public java.util.Set<dk.hibernatetest.model.C> getCCollection() {
        return cCollection;
    }

    public void setCCollection(
        java.util.Set<dk.hibernatetest.model.C> parameter) {
        this.cCollection = parameter;
    }

    public dk.hibernatetest.model.A getA() {
        return a;
    }

    public void setA(dk.hibernatetest.model.A parameter) {
        this.a = parameter;
    }

    public dk.hibernatetest.model.F getF() {
        return f;
    }

    public void setF(dk.hibernatetest.model.F parameter) {
        this.f = parameter;
    }
}
