package dk.hibernatetest.model;

/**
 * No Documentation
 */
@javax.persistence.Entity
public class E extends dk.hibernatetest.model.AbstractEntity {
    private static final long serialVersionUID = 1226955558L;

    /**
     * No documentation
     */
    @javax.persistence.ManyToOne(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    , optional = false)
    private dk.hibernatetest.model.F f;

    public dk.hibernatetest.model.F getF() {
        return f;
    }

    public void setF(dk.hibernatetest.model.F parameter) {
        this.f = parameter;
    }
}
