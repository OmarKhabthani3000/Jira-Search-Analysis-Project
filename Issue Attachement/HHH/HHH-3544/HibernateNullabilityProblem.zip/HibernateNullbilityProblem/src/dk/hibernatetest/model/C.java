package dk.hibernatetest.model;

/**
 * No Documentation
 */
@javax.persistence.Entity
public class C extends dk.hibernatetest.model.AbstractEntity {
    private static final long serialVersionUID = 1226955752L;

    /**
     * No documentation
     */
    @javax.persistence.ManyToOne(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    , optional = false)
    private dk.hibernatetest.model.A a;

    /**
     * No documentation
     */
    @javax.persistence.ManyToOne(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    )
    private dk.hibernatetest.model.G g;

    /**
     * No documentation
     */
    @javax.persistence.ManyToOne(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    , optional = false)
    private dk.hibernatetest.model.B b;

    public dk.hibernatetest.model.A getA() {
        return a;
    }

    public void setA(dk.hibernatetest.model.A parameter) {
        this.a = parameter;
    }

    public dk.hibernatetest.model.G getG() {
        return g;
    }

    public void setG(dk.hibernatetest.model.G parameter) {
        this.g = parameter;
    }

    public dk.hibernatetest.model.B getB() {
        return b;
    }

    public void setB(dk.hibernatetest.model.B parameter) {
        this.b = parameter;
    }
}
