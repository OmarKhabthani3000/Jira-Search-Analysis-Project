package dk.hibernatetest.model;

/**
 * No Documentation
 */
@javax.persistence.Entity
public class F extends dk.hibernatetest.model.AbstractEntity {
    private static final long serialVersionUID = 1471534025L;

    /**
     * No documentation
     */
    @javax.persistence.OneToMany(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    , mappedBy = "f")
    private java.util.Set<dk.hibernatetest.model.B> bCollection = new java.util.HashSet<dk.hibernatetest.model.B>();

    /**
     * No documentation
     */
    @javax.persistence.OneToOne(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    )
    private dk.hibernatetest.model.H h;

    public java.util.Set<dk.hibernatetest.model.B> getBCollection() {
        return bCollection;
    }

    public void setBCollection(
        java.util.Set<dk.hibernatetest.model.B> parameter) {
        this.bCollection = parameter;
    }

    public dk.hibernatetest.model.H getH() {
        return h;
    }

    public void setH(dk.hibernatetest.model.H parameter) {
        this.h = parameter;
    }
}
