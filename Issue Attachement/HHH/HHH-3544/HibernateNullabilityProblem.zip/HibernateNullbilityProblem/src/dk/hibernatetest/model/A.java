package dk.hibernatetest.model;

/**
 * No Documentation
 */
@javax.persistence.Entity
public class A extends dk.hibernatetest.model.AbstractEntity {
    private static final long serialVersionUID = 864804063L;

    /**
     * No documentation
     */
    @javax.persistence.OneToMany(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    , mappedBy = "a")
    private java.util.Set<dk.hibernatetest.model.B> bCollection = new java.util.HashSet<dk.hibernatetest.model.B>();

    /**
     * No documentation
     */
    @javax.persistence.ManyToMany(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    , mappedBy = "aCollection")
    private java.util.Set<dk.hibernatetest.model.D> dCollection = new java.util.HashSet<dk.hibernatetest.model.D>();

    /**
     * No documentation
     */
    @javax.persistence.OneToMany(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    , mappedBy = "a")
    private java.util.Set<dk.hibernatetest.model.C> cCollection = new java.util.HashSet<dk.hibernatetest.model.C>();

    public java.util.Set<dk.hibernatetest.model.B> getBCollection() {
        return bCollection;
    }

    public void setBCollection(
        java.util.Set<dk.hibernatetest.model.B> parameter) {
        this.bCollection = parameter;
    }

    public java.util.Set<dk.hibernatetest.model.D> getDCollection() {
        return dCollection;
    }

    public void setDCollection(
        java.util.Set<dk.hibernatetest.model.D> parameter) {
        this.dCollection = parameter;
    }

    public java.util.Set<dk.hibernatetest.model.C> getCCollection() {
        return cCollection;
    }

    public void setCCollection(
        java.util.Set<dk.hibernatetest.model.C> parameter) {
        this.cCollection = parameter;
    }
}
