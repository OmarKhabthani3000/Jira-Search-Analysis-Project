package dk.hibernatetest.model;

/**
 * No Documentation
 */
@javax.persistence.Entity
public class H extends dk.hibernatetest.model.AbstractEntity {
    private static final long serialVersionUID = 1226955562L;

    /**
     * No documentation
     */
    @javax.persistence.OneToOne(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    )
    private dk.hibernatetest.model.G g;

    public dk.hibernatetest.model.G getG() {
        return g;
    }

    public void setG(dk.hibernatetest.model.G parameter) {
        this.g = parameter;
    }
}
