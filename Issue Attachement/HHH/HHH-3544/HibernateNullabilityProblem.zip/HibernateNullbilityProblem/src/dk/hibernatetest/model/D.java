package dk.hibernatetest.model;

/**
 * No Documentation
 */
@javax.persistence.Entity
public class D extends dk.hibernatetest.model.AbstractEntity {
    private static final long serialVersionUID = 2417176961L;

    /**
     * No documentation
     */
    @javax.persistence.ManyToMany(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    )
    private java.util.Set<dk.hibernatetest.model.A> aCollection = new java.util.HashSet<dk.hibernatetest.model.A>();

    /**
     * No documentation
     */
    @javax.persistence.OneToMany(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    )
    private java.util.Set<dk.hibernatetest.model.E> eCollection = new java.util.HashSet<dk.hibernatetest.model.E>();

    public java.util.Set<dk.hibernatetest.model.A> getACollection() {
        return aCollection;
    }

    public void setACollection(
        java.util.Set<dk.hibernatetest.model.A> parameter) {
        this.aCollection = parameter;
    }

    public java.util.Set<dk.hibernatetest.model.E> getECollection() {
        return eCollection;
    }

    public void setECollection(
        java.util.Set<dk.hibernatetest.model.E> parameter) {
        this.eCollection = parameter;
    }
}
