package dk.hibernatetest.model;

/**
 * No Documentation
 */
@javax.persistence.Entity
public class G extends dk.hibernatetest.model.AbstractEntity {
    private static final long serialVersionUID = 325417437L;

    /**
     * No documentation
     */
    @javax.persistence.OneToMany(cascade =  {
        javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}
    , mappedBy = "g")
    private java.util.Set<dk.hibernatetest.model.C> cCollection = new java.util.HashSet<dk.hibernatetest.model.C>();

    public java.util.Set<dk.hibernatetest.model.C> getCCollection() {
        return cCollection;
    }

    public void setCCollection(
        java.util.Set<dk.hibernatetest.model.C> parameter) {
        this.cCollection = parameter;
    }
}
