package events;
import org.hibernate.*;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.RestrictionsExt;

import java.util.*;

import util.HibernateUtil;

public class EventManager {

    public static void main(String[] args) {
        EventManager mgr = new EventManager();

        mgr.prepareData();

        mgr.testCriteria();

        HibernateUtil.getSessionFactory().close();
    }

    /**
     *
     */
    private void prepareData() {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();

        Person pers1 = new Person();
        pers1.setAge(1);
        Set<String> emails = new HashSet<String>();
        emails.add("email_1@Pers1");
        emails.add("email_2@Pers1");
        pers1.setEmailAddresses(emails );
        pers1.setFirstname("Pers1");
//        pers1.setId(1L);
        pers1.setLastname("Fam1");
        session.save(pers1);

        Person pers2 = new Person();
        pers2.setAge(2);
        emails = new HashSet<String>();
        emails.add("email_1@Pers2");
        emails.add("email_2@Pers2");
        pers2.setEmailAddresses(emails );
        pers2.setFirstname("Pers2");
//        pers2.setId(2L);
        pers2.setLastname("Fam2");
        session.save(pers2);

        Person pers3 = new Person();
        pers3.setAge(3);
        emails = new HashSet<String>();
        emails.add("email_1@Pers3");
        emails.add("email_2@Pers3");
        pers3.setEmailAddresses(emails );
        pers3.setFirstname("Pers3");
//        pers3.setId(3L);
        pers3.setLastname("Fam3");
        session.save(pers3);

        Event ev = new Event();
        ev.setDate(new Date());
        Set<Person> perss = new HashSet<Person>();
        perss.add(pers1);
        ev.setParticipants(perss);
        ev.setData("dat1");
        ev.setInfo("Event 1");
//        ev.setId(1L);
        session.save(ev);

        ev = new Event();
        ev.setDate(new Date());
        perss = new HashSet<Person>();
        perss.add(pers2);
        ev.setParticipants(perss);
        ev.setData("dat2");
        ev.setInfo("Event 2");
//        ev.setId(2L);
        session.save(ev);

        ev = new Event();
        ev.setDate(new Date());
        perss = new HashSet<Person>();
        perss.add(pers1);
        perss.add(pers2);
        ev.setParticipants(perss);
        ev.setData("dat2");
        ev.setInfo("Event 3");
//        ev.setId(3L);
        session.save(ev);

        session.getTransaction().commit();
    }

    /**
     *
     */
    @SuppressWarnings("unchecked")
    private void testCriteria() {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();

        Criteria crit = session.createCriteria(Event.class);
        Criteria perc = crit.createCriteria("participants","parts");
        // this statement will add condition to join
        perc.add(RestrictionsExt.joinOn(Restrictions.eq("firstname", "Pers2")));
        // this statement will add condition to WHERE cause
        crit.add(Restrictions.like("parts.lastname", "%"));

        /* This will generate SQL:
   select
        this_.id as id0_1_,
        this_.data as data0_1_,
        this_.ev_date as ev3_0_1_,
        this_.info as info0_1_,
        participan3_.event_id as event2_,
        parts1_.id as particip1_,
        parts1_.id as id1_0_,
        parts1_.age as age1_0_,
        parts1_.firstname as firstname1_0_,
        parts1_.lastname as lastname1_0_
    from
        events this_
    inner join
        person_event participan3_
            on this_.id=participan3_.event_id
    inner join
        person parts1_
            on participan3_.participants_id=parts1_.id
            and parts1_.firstname=?
    where
        parts1_.lastname like ?

StringType:133 - binding 'Pers2' to parameter: 1
StringType:133 - binding '%' to parameter: 2

          */
        @SuppressWarnings("unused")
        List<Event> list = crit.list();
        session.getTransaction().commit();
    }

}