package events;

import java.util.*;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.CollectionOfElements;

@Entity
@Table(name="events")
public class Event {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name="id")
    private Long id;

    @Basic
    @Column(name="data")
    private String data;

    @Basic
    @Column(name="ev_date")
    private Date date;

    @ManyToMany(fetch=FetchType.LAZY)
    @JoinTable(
            name = "person_event",
            joinColumns = @JoinColumn(name = "event_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "participants_id", referencedColumnName = "id")
    )
    private Set<Person>  participants         = new HashSet<Person>();

    @Column(name="info", nullable=false)
    private String info;


    public Event() {}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }


//    public Set<Person> getParticipants() {
//        return participants;
//    }
//
//    public void setParticipants(Set<Person> participants) {
//        this.participants = participants;
//    }

    /**
     * @return the participantFirstName
     */
    public String getInfo() {
        return this.info;
    }

    /**
     * @param aParticipantFirstName the participantFirstName to set
     */
    public void setInfo(String info) {
        this.info = info;
    }

    public Set<Person> getParticipants() {
        return this.participants;
    }

    public void setParticipants(Set<Person> participants) {
        this.participants = participants;
    }

}