package events;

import java.util.*;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.CollectionOfElements;

@Entity
@Table(name = "person")
public class Person {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id")
    private Long        id;
    @Basic
    private int         age;
    @Basic
    private String      firstname;
    @Basic
    private String      lastname;

    @CollectionOfElements
    @JoinTable(name = "person_email_addr", joinColumns = @JoinColumn(name = "pers_id"))
    @Column(name = "email_address", nullable = false)
    private Set<String> emailAddresses = new HashSet<String>();

    @ManyToMany(fetch=FetchType.LAZY)
    @JoinTable(
            name = "person_event",
            joinColumns = @JoinColumn(name = "participants_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "event_id", referencedColumnName = "id")
    )
    private Set<Event>  event         = new HashSet<Event>();

    public Person() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public Set getEmailAddresses() {
        return emailAddresses;
    }

    public void setEmailAddresses(Set emailAddresses) {
        this.emailAddresses = emailAddresses;
    }

    public Set<Event> getEvents() {
        return this.event;
    }

    public void setEvents(Set<Event> events) {
        this.event = events;
    }

}