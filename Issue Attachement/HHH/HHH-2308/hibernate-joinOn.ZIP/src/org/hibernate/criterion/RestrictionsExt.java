/**
 *
 */
package org.hibernate.criterion;

import org.hibernate.criterion.Criterion;

/**
 * @author SPulyaev
 *
 */
public class RestrictionsExt {

    /**
     * Apply an "in" constraint to the named property
     * @param propertyName
     * @param values
     * @return Criterion
     */
    public static Criterion joinOn(Criterion criterion) {
        return new JoinExpression(criterion);
    }

}
