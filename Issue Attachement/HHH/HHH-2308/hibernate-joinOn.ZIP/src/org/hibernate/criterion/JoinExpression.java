/**
 *
 */
package org.hibernate.criterion;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.dialect.MySQLDialect;
import org.hibernate.engine.TypedValue;

/**
 * @author SPulyaev
 *
 */
public class JoinExpression implements Criterion {

    /**
     *
     */
    private static final long serialVersionUID = 5451773131614467307L;
    private Criterion criterion;

    protected JoinExpression(Criterion criterion) {
        this.criterion = criterion;
    }

    public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery)
    throws HibernateException {
        if ( criteriaQuery.getFactory().getDialect() instanceof MySQLDialect ) {
            return criterion.toSqlString(criteria, criteriaQuery);
        }
        return criterion.toSqlString(criteria, criteriaQuery);
    }

    public TypedValue[] getTypedValues(
        Criteria criteria, CriteriaQuery criteriaQuery)
    throws HibernateException {
        return criterion.getTypedValues(criteria, criteriaQuery);
    }

    public String toString() {
        return "not " + criterion.toString();
    }

}
