# TestCase used jars

This failure was tested on DB2 drivers version 10.5 .
When this code was run on our project with hibernate 5.3.2, all worked fine.

You need to include libs

db2jcc-10.5.jar
db2jcc_license_cu-10.5.jar

into db2-connector