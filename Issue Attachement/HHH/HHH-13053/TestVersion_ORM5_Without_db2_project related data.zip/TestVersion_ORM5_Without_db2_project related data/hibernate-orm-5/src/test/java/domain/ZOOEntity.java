package domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * @author Primo� Vrane�i�
 */

@javax.persistence.Entity(name="ZOOEntityTest")
@Table(name="NZ.ZOO")
@Cache(usage= CacheConcurrencyStrategy.READ_WRITE)
public class ZOOEntity
{
  private List<AnimalEntity> m_animalEntities = new ArrayList<>();  ////////// FIXME comment entire line here and
  //private List<AnimalEntity> m_animalEntities;                    ////////// uncomment this and in JPAUnitTestCase to successfully run scenario
  
  private Long m_id;
  
  public ZOOEntity()
  {
  }
  
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name="ID_ZOO")
  public Long getId()
  {
    return m_id;
  }
  
  public void setId(Long id)
  {
    m_id = id;
  }
  
  @OneToMany(fetch = FetchType.LAZY, mappedBy = "ZOOEntity", cascade = {CascadeType.ALL})
  public List<AnimalEntity> getAnimalEntities()
  {
    return m_animalEntities;
  }
  
  public void setAnimalEntities(List<AnimalEntity> animalEntities)
  {
    m_animalEntities = animalEntities;
  }
}