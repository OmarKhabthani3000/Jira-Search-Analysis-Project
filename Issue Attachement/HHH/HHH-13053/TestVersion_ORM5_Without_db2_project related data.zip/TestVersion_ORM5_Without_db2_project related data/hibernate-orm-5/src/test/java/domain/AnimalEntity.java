package domain;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * @author Primo� Vrane�i�
 */

@javax.persistence.Entity(name="AnimalEntityTest")
@Table(name="NZ.ANIMAL")
@Cache(usage= CacheConcurrencyStrategy.READ_WRITE)
public class AnimalEntity
{
  private ZOOEntity m_zooEntity;
  private Long m_id;

  @Id
  @GeneratedValue(generator = "AnimalSequenceStyleGenerator")
  @GenericGenerator(name = "AnimalSequenceStyleGenerator", strategy ="org.hibernate.id.enhanced.SequenceStyleGenerator",
      parameters = {
          @Parameter(name = "sequence_name", value = "NZ.SEQ_ANIMAL"),
          @Parameter(name = "optimizer", value = "pooled"),
          @Parameter(name = "increment_size", value = "50") })  //parameter must be equal SEQ_OBROK INCREMENT BY parameter
  @Column(name="ID_ANIMAL")
  public Long getId()
  {
    return m_id;
  }

  public void setId(Long id)
  {
    m_id = id;
  }

  @ManyToOne(fetch= FetchType.LAZY)
  @JoinColumn(name="ID_ZOO", nullable=false)
  public ZOOEntity getZOOEntity()
  {
    return m_zooEntity;
  }

  public void setZOOEntity(ZOOEntity zooEntity)
  {
    m_zooEntity = zooEntity;
  }
}
