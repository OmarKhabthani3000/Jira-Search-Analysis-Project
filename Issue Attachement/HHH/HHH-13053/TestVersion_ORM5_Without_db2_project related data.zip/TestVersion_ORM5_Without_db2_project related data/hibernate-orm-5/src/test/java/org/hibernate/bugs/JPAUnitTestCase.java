package org.hibernate.bugs;

import java.time.LocalDateTime;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import domain.AnimalEntity;
import domain.ZOOEntity;


/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
    
    try
    {
      Class.forName("com.ibm.db2.jcc.DB2Driver");
    }
    catch (Exception ex)
    {
      System.out.println("safasfasf");
    }
    
    entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
		
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

  /**
   * @author Primo� Vrane�i�
   *
   * This unit test, shows behaviour of hibernate 5.3.5 .
   * With version 5.3.2, this problem does not occur
   *
   * There is problem, when parent entity has generated value IDENTITY and batch update is enabled.
   *
   *
   * This happens only (if all conditions are met):
   *    - parent has generated value IDENTITY (changing this to SEQUENCE fixes problem)
   *    - if parent entity has child list initialized on class instantialization
   *    - and one parent is read from database, and the other is created in session and flushed
   *    - than two child entities are created for each, and linked and flushed .
   *    - persisence factory property 'hibernate.order_updates' is set to true
   *
   * LOG OF EXCEPTION
   *
   * Error output of class: java.lang.ClassCastException:449895102
   * org.hibernate.action.internal.DelayedPostInsertIdentifier cannot be cast to java.lang.Long
   *  Stack:
   * java.lang.Long.compareTo(Long.java:54)
   * org.hibernate.internal.util.compare.ComparableComparator.compare(ComparableComparator.java:23)
   * org.hibernate.internal.util.compare.ComparableComparator.compare(ComparableComparator.java:18)
   * org.hibernate.type.AbstractStandardBasicType.compare(AbstractStandardBasicType.java:215)
   * org.hibernate.action.internal.CollectionAction.compareTo(CollectionAction.java:159)
   * org.hibernate.engine.spi.ExecutableList.add(ExecutableList.java:227)
   * org.hibernate.engine.spi.ActionQueue.addAction(ActionQueue.java:307)
   * org.hibernate.engine.spi.ActionQueue.addAction(ActionQueue.java:371)
   * org.hibernate.event.internal.AbstractFlushingEventListener.flushCollections(AbstractFlushingEventListener.java:301)
   * org.hibernate.event.internal.AbstractFlushingEventListener.flushEverythingToExecutions(AbstractFlushingEventListener.java:95)
   * org.hibernate.event.internal.DefaultFlushEventListener.onFlush(DefaultFlushEventListener.java:38)
   * org.hibernate.internal.SessionImpl.doFlush(SessionImpl.java:1454)
   * org.hibernate.internal.SessionImpl.flush(SessionImpl.java:1440)
   */
  
  @Test
  public void testFailWithDelayedPostInsertIdentifyer()
  {
    EntityManager entityManager = entityManagerFactory.createEntityManager();
    entityManager.setFlushMode(FlushModeType.COMMIT);
    Session session = (Session)entityManager.getDelegate();
    session.setHibernateFlushMode(FlushMode.MANUAL);
    entityManager.getTransaction().begin();
    
    // DB2 connection check
    try
    {
      Query q = entityManager.createNativeQuery("SELECT CURRENT TIMESTAMP FROM SYSIBM.SYSDUMMY1");
      LocalDateTime timestamp = ((java.sql.Timestamp)q.getSingleResult()).toLocalDateTime();
      System.out.println("-------------------------------------------------------------------------------");
      System.out.println("DB2 TIMESTAMP " + timestamp);
      System.out.println("-------------------------------------------------------------------------------");
    }
    catch (Exception ex)
    {
      System.out.println("connection exception");
      throw ex;
    }
    
    ZOOEntity zooEntityExisting = entityManager.find(ZOOEntity.class, 1L);
    ZOOEntity zooEntityGenerated = new ZOOEntity();
    
    entityManager.persist(zooEntityGenerated);
    entityManager.flush();
    
    AnimalEntity animalEntity1 = new AnimalEntity();
    animalEntity1.setZOOEntity(zooEntityExisting);
    zooEntityExisting.getAnimalEntities().add(animalEntity1);
    
    AnimalEntity animalEntity2 = new AnimalEntity();
    animalEntity2.setZOOEntity(zooEntityGenerated);
    //zooEntityGenerated.setAnimalEntities(new ArrayList<>());   //////////////// FIXME uncomment entire line and correct ZOOEntity FIXME to achive success
    zooEntityGenerated.getAnimalEntities().add(animalEntity2);
    
    entityManager.flush();
    
    System.out.println("This time, test run has been successful");
    System.out.println("This time, test run has been successful");
    System.out.println("This time, test run has been successful");
    System.out.println("This time, test run has been successful");
    System.out.println("This time, test run has been successful");
    System.out.println("This time, test run has been successful");
    System.out.println("This time, test run has been successful");
    
    entityManager.getTransaction().commit();
    entityManager.close();
  }
}

