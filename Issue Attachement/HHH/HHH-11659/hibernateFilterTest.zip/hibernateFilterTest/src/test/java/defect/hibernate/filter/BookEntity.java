package defect.hibernate.filter;

import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.NamedQuery;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Entity to demo Hibernate 5.2.10's filter not working with outer join
 * Created by fuj on 4/24/17.
 */
@Entity
@FilterDef(name= BookEntity.activeFilter, defaultCondition = "active=true")
@Filter(name= BookEntity.activeFilter)
@NamedQuery(name= BookEntity.matchBookMovieNames,
	query="select b, m from BookEntity b left outer join MovieEntity m on b.name=m.name")
public class BookEntity {
	public static final String activeFilter = "activeFilter";
	public static final String matchBookMovieNames = "BookEntity.matchBookMovieNames";

	@Id
	private int id;

	private String name;

	private boolean active;

	public BookEntity() {
	}

	public BookEntity(int id, String name, boolean active) {
		this.id = id;
		this.name = name;
		this.active = active;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "BookEntity{" +
				"id=" + id +
				", name='" + name + '\'' +
				", active=" + active +
				'}';
	}
}
