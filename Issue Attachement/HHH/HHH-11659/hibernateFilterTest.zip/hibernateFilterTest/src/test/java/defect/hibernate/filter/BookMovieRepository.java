package defect.hibernate.filter;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

/**
 * Repository performing an outer-join query
 */
@Repository
public class BookMovieRepository {
	@PersistenceContext
	EntityManager em;

	@Transactional
	public <T> T save(T entiy) {
		return em.merge(entiy);
	}

	/**
	 * perform a query with the active-filter enabled.
	 *
	 * @return active books with matching active movies.  (supposedly. the "active" movie part doesn't work)
	 */
	public List<Object[]> matchBookMovieNames() {
		em.unwrap(Session.class)
				.enableFilter(BookEntity.activeFilter);
		return em.createNamedQuery(BookEntity.matchBookMovieNames)
				.getResultList();
	}
}
