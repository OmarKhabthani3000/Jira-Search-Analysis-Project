package defect.hibernate.filter;

import defect.hibernate.filter.BookEntity;
import org.hibernate.annotations.Filter;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Entity to demo Hibernate 5.2.10's filter not working with outer join
 * Created by fuj on 4/24/17.
 */
@Entity
@Filter(name= BookEntity.activeFilter, condition = "active=true")
public class MovieEntity {
	@Id
	private int id;

	private String name;

	private boolean active;

	public MovieEntity() {
	}

	public MovieEntity(int id, String name, boolean active) {
		this.id = id;
		this.name = name;
		this.active = active;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "MovieEntity{" +
				"id=" + id +
				", name='" + name + '\'' +
				", active=" + active +
				'}';
	}
}
