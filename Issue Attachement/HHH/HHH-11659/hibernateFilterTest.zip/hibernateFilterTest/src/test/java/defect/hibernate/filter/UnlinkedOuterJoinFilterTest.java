package defect.hibernate.filter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

import static org.testng.Assert.assertEquals;

/**
 * This test shows that a filter is not properly applied to the right-hand side of a left outer join.
 */
@TestPropertySource("classpath:defectTest.properties")
@ContextConfiguration(classes = DefectTestConfig.class)
public class UnlinkedOuterJoinFilterTest extends AbstractTransactionalTestNGSpringContextTests {
	@Autowired
	BookMovieRepository repo;

	@BeforeClass
	public void loadData() {
		BookEntity book = new BookEntity(1, "Tale of 2 Cities", true);
		repo.save(book);

		book = new BookEntity(2, "Tale of 2 Cities", false);
		repo.save(book);

		MovieEntity movie = new MovieEntity(1, "Tale of 2 Cities", true);
		repo.save(movie);
		movie = new MovieEntity(2, "Tale of 2 Cities", false);
		repo.save(movie);
	}

	/**
	 * The query below utilizes an active-filter that restricts results to rows with the "active" flag.
	 * If the filter is properly applied, the query should return a single row with matching
	 * "active" book and movie.  However, as of Hibernate 5.2.10, it returns 2 rows and fails the
	 * assertion: although only one active book is found, both the active and inactive movies
	 * are turned.
	 */
	@Test
	public void testFilter() {
		List<Object[]> result = repo.matchBookMovieNames();
		result.forEach(i -> System.out.println("Row: " + i[0] + ", " + i[1]));
		assertEquals(result.size(), 1);
	}
}