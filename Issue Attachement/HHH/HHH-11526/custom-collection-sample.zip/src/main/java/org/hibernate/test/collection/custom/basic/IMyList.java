package org.hibernate.test.collection.custom.basic;

import java.util.List;

public interface IMyList<X> extends List<X> {

}
