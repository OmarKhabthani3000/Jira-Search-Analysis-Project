package org.hibernate.test.collection.custom.basic.issue;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * @author Gavin King
 * @author Steve Ebersole
 */
@Entity
public class EmailNOK {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private String address;

	EmailNOK() {
	}

	public EmailNOK(String address) {
		this.address = address;
	}

	public Long getId() {
		return id;
	}

	private void setId(Long id) {
		this.id = id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String type) {
		this.address = type;
	}

	public boolean equals(Object that) {
		if (!(that instanceof EmailNOK))
			return false;
		EmailNOK p = (EmailNOK) that;
		return this.address.equals(p.address);
	}

	public int hashCode() {
		return address.hashCode();
	}

}
