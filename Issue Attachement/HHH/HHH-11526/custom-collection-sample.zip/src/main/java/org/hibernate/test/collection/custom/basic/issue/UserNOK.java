package org.hibernate.test.collection.custom.basic.issue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Transient;

import org.hibernate.annotations.CollectionType;
import org.hibernate.test.collection.custom.basic.IMyList;
import org.hibernate.test.collection.custom.basic.MyList;

/**
 * @author Gavin King
 * @author Steve Ebersole
 */
@Entity
public class UserNOK {

	@Id
	private String userName;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
	@CollectionType(type = "org.hibernate.test.collection.custom.basic.MyListType")
	@JoinColumn(name = "userName")
	@OrderColumn(name = "displayOrder")
	private IMyList<EmailNOK> emailAddresses = new MyList<EmailNOK>();

	@Transient
	private Map sessionData = new HashMap();

	UserNOK() {
	}

	public UserNOK(String name) {
		userName = name;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	// does not work :( public IMyList<Email> getEmailAddresses() {
	public List<EmailNOK> getEmailAddresses() {
		return emailAddresses;
	}

	public void setEmailAddresses(IMyList<EmailNOK> emailAddresses) {
		this.emailAddresses = emailAddresses;
	}

	public Map getSessionData() {
		return sessionData;
	}

	public void setSessionData(Map sessionData) {
		this.sessionData = sessionData;
	}
}
