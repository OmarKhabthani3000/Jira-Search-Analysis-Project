package org.hibernate.test.collection.custom.basic;

import static org.junit.Assert.*;

import org.hibernate.test.collection.custom.basic.works.User;
import org.junit.Before;
import org.junit.Test;

import hibernate.util.JPAHibernateTest;

public class UserTest extends JPAHibernateTest {
	
	@Before
    public void initializeDatabase(){
		em.persist(new User("mcarvalho"));
    }

    @Test
    public void testGetUserByIdSuccess() {
        User user = em.find(User.class, "mcarvalho");
        assertNotNull(user);
    }

}
