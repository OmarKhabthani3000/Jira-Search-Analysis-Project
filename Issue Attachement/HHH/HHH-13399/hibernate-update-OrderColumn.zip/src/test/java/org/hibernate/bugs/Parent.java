package org.hibernate.bugs;

import javax.persistence.*;
import java.util.*;

@Entity
public class Parent {

    @Id
    @Column
    private UUID id;

    @Column
    private String name;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "parent_id", nullable = false, updatable = false)
    @OrderColumn(name = "child_index", nullable = false)
    private List<Child> children = new ArrayList<>();

    private Parent() {
    }

    public Parent(String name, List<Child> children) {
        this(UUID.randomUUID(), name, children);
    }

    public Parent(UUID id, String name, List<Child> children) {
        this.id = id;
        this.name = name;
        this.children = children;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Parent simple = (Parent) o;
        return Objects.equals(id, simple.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<Child> getChildren() {
        return Collections.unmodifiableList(children);
    }

    @Override
    public String toString() {
        StringBuilder buf = new StringBuilder("[\n");
        for (Child child : children) {
            buf.append("\t");
            buf.append(String.valueOf(child));
            buf.append("\n");
        }
        buf.append("]");
        return String.format("Parent{id=%s, name='%s', children=%s}", id, name, buf.toString());
    }

    public Parent removeChild() {
        children.remove(1);
        return this;
    }

    public Parent addChild() {
        children.add(new Child("new"));
        return this;
    }

    public Parent reorderChildren() {
        Collections.shuffle(children);
        return this;
    }
}
