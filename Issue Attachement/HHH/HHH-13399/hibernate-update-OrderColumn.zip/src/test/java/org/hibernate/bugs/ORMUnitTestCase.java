/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 * <p>
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

    private final String jdbcUrl = String.format("jdbc:h2:file:%s;DB_CLOSE_DELAY=-1;AUTO_SERVER=TRUE", new File("target/h2data").getAbsolutePath().replaceAll("\\\\", "/"));
    private Parent parent;

    // Add your entities here.
    @Override
    protected Class[] getAnnotatedClasses() {
        return new Class[]{
                Parent.class,
                Child.class
        };
    }

    // Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
    @Override
    protected void configure(Configuration configuration) {
        super.configure(configuration);

        configuration.setProperty(AvailableSettings.SHOW_SQL, Boolean.TRUE.toString());
        configuration.setProperty(AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString());
        configuration.setProperty(AvailableSettings.FORMAT_SQL, Boolean.FALSE.toString());
        configuration.setProperty("hibernate.connection.url", jdbcUrl);
    }

    @Override
    protected boolean isCleanupTestDataRequired() {
        return true;
    }

    @Before
    public void setUp() throws SQLException {
        parent = new Parent("barry", new ArrayList<>(Arrays.asList(new Child("one"), new Child("two"), new Child("three"), new Child("four"))));
        doInNewSessionAndTx(session -> {
            System.out.println("******** SAVE session.save()");
            session.save(parent);
        });
        printActualTable("Child table after save...");
    }

    @Test
    public void reOrderingChildrenWithMergeDoesNotUpdate() throws SQLException {
        Parent expectedUpdate = detached(parent)
                .reorderChildren();

        doInNewSessionAndTx(session -> {
            System.out.println("******** MERGE session.merge()");
            session.merge(expectedUpdate);
        });
        Parent loaded = loadById(parent.getId());
        printActualTable("Child table after merge");

        assertEquals(expectedUpdate, loaded);
    }

    @Test
    public void reOrderingChildrenInTxDoesNotUpdate() throws SQLException {
        Parent[] expectedUpdate = new Parent[1];
        doInNewSessionAndTx(session -> {
            System.out.println("******** LOAD & UPDATE");
            Parent toUpdate = session.get(Parent.class, parent.getId());
            toUpdate.reorderChildren();
            expectedUpdate[0] = toUpdate;
        });
        Parent loaded = loadById(parent.getId());
        printActualTable("Child table after load & update");

        assertEquals(expectedUpdate[0], loaded);
    }

    @Test
    public void removingChildrenWithMergeDoesNotUpdate() throws SQLException {
        Parent expectedUpdate = detached(parent)
                .removeChild();

        doInNewSessionAndTx(session -> {
            System.out.println("******** MERGE session.merge()");
            session.merge(expectedUpdate);
        });
        Parent loaded = loadById(parent.getId());
        printActualTable("Child table after merge");

        assertEquals(expectedUpdate, loaded);
    }

    @Test
    public void removingChildrenInTxDoesNotUpdate() throws SQLException {
        Parent[] expectedUpdate = new Parent[1];
        doInNewSessionAndTx(session -> {
            System.out.println("******** LOAD & UPDATE");
            Parent toUpdate = session.get(Parent.class, parent.getId());
            toUpdate.removeChild();
            expectedUpdate[0] = toUpdate;
        });
        Parent loaded = loadById(parent.getId());
        printActualTable("Child table after load & update");

        assertEquals(expectedUpdate[0], loaded);
    }

    @Test
    public void removingChildrenAndAddingWithMergeDoesNotUpdate() throws SQLException {
        Parent expectedUpdate = detached(parent)
                .removeChild()
                .addChild();

        doInNewSessionAndTx(session -> {
            System.out.println("******** MERGE session.merge()");
            session.merge(expectedUpdate);
        });
        Parent loaded = loadById(parent.getId());
        printActualTable("Child table after merge :-o");

        assertEquals(expectedUpdate, loaded);
    }

    @Test
    public void removingChildrenAndAddingInTxDoesNotUpdate() throws SQLException {
        Parent[] expectedUpdate = new Parent[1];
        doInNewSessionAndTx(session -> {
            System.out.println("******** LOAD & UPDATE");
            Parent toUpdate = session.get(Parent.class, parent.getId());
            toUpdate.removeChild()
                    .addChild();
            expectedUpdate[0] = toUpdate;
        });
        Parent loaded = loadById(parent.getId());
        printActualTable("Child table after load & update");

        assertEquals(expectedUpdate[0], loaded);
    }


    private Parent loadById(UUID id) {
        Parent[] parent = new Parent[1];
        doInNewSessionAndTx(session -> {
            System.out.println("******** GET BY ID");
            parent[0] = session.get(Parent.class, id);
        });
        return parent[0];
    }

    private void doInNewSessionAndTx(Operation operation) {
        Session session = openSession();
        Transaction tx = session.beginTransaction();
        // Do stuff...
        operation.perform(session);

        tx.commit();
        session.close();
    }

    private void printActualTable(String message) throws SQLException {
        Connection connection = DriverManager.getConnection(jdbcUrl, "sa", "");
        ResultSet resultSet = connection.createStatement().executeQuery("select * from CHILD");
        System.out.println("=============================================================================");
        System.out.println(message);
        System.out.println("=============================================================================");
        System.out.println("ID                               PARENT_ID                        IDX NAME");
        while (resultSet.next()) {
            String id = resultSet.getString("id");
            String parentId = resultSet.getString("parent_id");
            String name = resultSet.getString("name");
            int childIndex = resultSet.getInt("child_index");
            System.out.println(String.format("%s %s %s   %s", id, parentId, childIndex, name));
        }
        System.out.println("=============================================================================");
    }

    private Parent detached(Parent parent) {
        return new Parent(parent.getId(), parent.getName(), detached(parent.getChildren()));
    }

    private List<Child> detached(List<Child> children) {
        return children.stream().map(this::detached).collect(Collectors.toList());
    }

    private Child detached(Child child) {
        return new Child(child.getId(), child.getName());
    }

    private void assertEquals(Parent expected, Parent actual) {
        Assert.assertEquals("Oh dear...", expected.toString(), actual.toString());
    }

    public interface Operation {
        void perform(Session session);
    }

}
