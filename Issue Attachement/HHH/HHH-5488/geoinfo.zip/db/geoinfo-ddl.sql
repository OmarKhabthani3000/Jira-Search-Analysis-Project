
USE geoinfo;

# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

-- -----------------------------------------------------
-- Table `Countries`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Countries` ;

CREATE  TABLE IF NOT EXISTS `Countries` (
  `code` CHAR(2) NOT NULL ,
  `name` VARCHAR(50) NOT NULL ,
  PRIMARY KEY (`code`) );

-- -----------------------------------------------------
-- Table `States`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `States` ;

CREATE  TABLE IF NOT EXISTS `States` (
  `country_code` CHAR(2) NOT NULL ,
  `code` VARCHAR(5) NOT NULL ,
  `name` VARCHAR(100) NOT NULL ,
  PRIMARY KEY (`country_code`, `code`) ,
  CONSTRAINT `states_countries_fk`
    FOREIGN KEY (`country_code` )
    REFERENCES `Countries` (`code` )
    ON DELETE CASCADE
    ON UPDATE CASCADE);

CREATE INDEX `states_countries_fk` ON `States` (`country_code` ASC) ;

-- -----------------------------------------------------
-- Table `Zips`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Zips` ;

CREATE  TABLE IF NOT EXISTS `Zips` (
  `country_code` CHAR(2) NOT NULL ,
  `code` VARCHAR(10) NOT NULL ,
  PRIMARY KEY (`country_code`, `code`) ,
  CONSTRAINT `zips_countries_fk`
    FOREIGN KEY (`country_code` )
    REFERENCES `Countries` (`code` )
    ON DELETE NO ACTION
    ON UPDATE CASCADE);

CREATE INDEX `zips_countries_fk` ON `Zips` (`country_code` ASC) ;


-- -----------------------------------------------------
-- Table `Cities`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Cities` ;

CREATE  TABLE IF NOT EXISTS `Cities` (
  `country_code` CHAR(2) NOT NULL ,
  `state_code` VARCHAR(5) NOT NULL ,
  `name` VARCHAR(100) NOT NULL ,
  PRIMARY KEY (`country_code`, `state_code`, `name`) ,
  CONSTRAINT `cities_states_fk`
    FOREIGN KEY (`country_code` , `state_code` )
    REFERENCES `States` (`country_code` , `code` )
    ON DELETE NO ACTION
    ON UPDATE CASCADE);

CREATE INDEX `cities_states_fk` ON `Cities` (`country_code` ASC, `state_code` ASC) ;


-- -----------------------------------------------------
-- Table `ZipAreas`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ZipAreas` ;

CREATE  TABLE IF NOT EXISTS `ZipAreas` (
  `country_code` CHAR(2) NOT NULL ,
  `state_code` VARCHAR(5) NOT NULL ,
  `city_name` VARCHAR(100) NOT NULL ,
  `zip_code` VARCHAR(10) NOT NULL ,
  PRIMARY KEY (`country_code`, `state_code`, `city_name`, `zip_code`) ,
  CONSTRAINT `zipareas_zips_fk`
    FOREIGN KEY (`country_code` , `zip_code` )
    REFERENCES `Zips` (`country_code` , `code` )
    ON DELETE NO ACTION
    ON UPDATE CASCADE,
  CONSTRAINT `zipareas_cities_fk`
    FOREIGN KEY (`country_code` , `state_code` , `city_name` )
    REFERENCES `Cities` (`country_code` , `state_code` , `name` )
    ON DELETE NO ACTION
    ON UPDATE CASCADE);

CREATE INDEX `zipareas_zips_fk` ON `ZipAreas` (`country_code` ASC, `zip_code` ASC) ;

CREATE INDEX `zipareas_cities_fk` ON `ZipAreas` (`country_code` ASC, `state_code` ASC, `city_name` ASC) ;


-- -----------------------------------------------------
-- Table `PostAddresses`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `PostAddresses` ;

CREATE  TABLE IF NOT EXISTS `PostAddresses` (
  `id` INT(11)  NOT NULL AUTO_INCREMENT ,
  `country_code` CHAR(2) NOT NULL ,
  `state_code` VARCHAR(5) NOT NULL ,
  `city_name` VARCHAR(100) NOT NULL ,
  `zip_code` VARCHAR(10) NOT NULL ,
  `is_primary` TINYINT(1)  NOT NULL DEFAULT TRUE ,
  `street_name` VARCHAR(100) NULL DEFAULT NULL ,
  `street_nbr` VARCHAR(10) NULL DEFAULT NULL ,
  PRIMARY KEY (`id`) ,
  CONSTRAINT `postaddresses_zipareas_fk`
    FOREIGN KEY (`country_code` , `state_code` , `city_name` , `zip_code` )
    REFERENCES `ZipAreas` (`country_code` , `state_code` , `city_name` , `zip_code` )
    ON DELETE NO ACTION
    ON UPDATE CASCADE);

CREATE INDEX `postaddresses_zipareas_fk` ON `PostAddresses` (`country_code` ASC, `state_code` ASC, `city_name` ASC, `zip_code` ASC) ;

