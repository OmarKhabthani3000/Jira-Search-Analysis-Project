package geoinfotest;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import org.apache.commons.lang.NullArgumentException;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Embeddable
public class StateId implements Serializable
{
	@Column(name = "country_code")
	private String countryCode;

	@Column(name = "code")
	private String code;

	public StateId()
	{
	}

	public StateId(String countryCode, String code)
	{
		if ( countryCode == null )
		{
			throw new NullArgumentException("countryCode is null!");
		}

		if ( code == null )
		{
			throw new NullArgumentException("code is null!");
		}

		this.countryCode = countryCode;
		this.code = code;
	}

	public String getCountryCode()
	{
		return countryCode;
	}

	public String getCode()
	{
		return code;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		StateId rhs = (StateId)obj;

		return new EqualsBuilder().append(countryCode, rhs.getCountryCode()).append(code, rhs.getCode()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(2057511099, 92821).append(countryCode).append(code).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("countryCode", countryCode).append("code", code).toString();
	}

}
