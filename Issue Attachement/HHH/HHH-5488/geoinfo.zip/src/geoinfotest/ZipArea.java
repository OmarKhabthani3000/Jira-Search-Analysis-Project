package geoinfotest;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

// UN-/COMMENT ANNOTATIONS HERE: (and in PostAddress.java) -> silent fail if PostAddress annotation removed only!
@Entity
@Table(name = "ZipAreas")
public class ZipArea implements Serializable
{
	@EmbeddedId
	private ZipAreaId id;

	@ManyToOne
	@JoinColumns(value = {@JoinColumn(name = "country_code", referencedColumnName = "country_code", insertable = false, updatable = false), @JoinColumn(name = "zip_code", referencedColumnName = "code", insertable = false, updatable = false)})
	private Zip zip = null;

	@ManyToOne
	@JoinColumns(value = {@JoinColumn(name = "country_code", referencedColumnName = "country_code", insertable = false, updatable = false), @JoinColumn(name = "state_code", referencedColumnName = "state_code", insertable = false, updatable = false), @JoinColumn(name = "city_name", referencedColumnName = "name", insertable = false, updatable = false)})
	private City city = null;

	public ZipArea()
	{
	}

	public ZipAreaId getId()
	{
		return id;
	}

	public void setId(ZipAreaId id)
	{
		this.id = id;
	}

	public Zip getZip()
	{
		return zip;
	}

	public void setZip(Zip zip)
	{
		this.zip = zip;
	}

	public City getCity()
	{
		return city;
	}

	public void setCity(City city)
	{
		this.city = city;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		ZipArea rhs = (ZipArea)obj;

		return new EqualsBuilder().append(id, rhs.getId()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(1474865463, 92821).append(id).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("id", id).append("zip", zip).append("city", city).toString();
	}

}
