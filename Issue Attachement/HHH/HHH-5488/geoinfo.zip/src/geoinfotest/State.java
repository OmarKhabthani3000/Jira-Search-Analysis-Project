package geoinfotest;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.apache.commons.lang.NullArgumentException;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "States")
public class State implements Serializable
{
	@EmbeddedId
	private StateId id;

	@Column(name = "name")
	private String name;

	@ManyToOne
	@JoinColumn(name = "country_code", referencedColumnName = "code", insertable = false, updatable = false)
	private Country country = null;

	public State()
	{
	}

	public State(String name)
	{
		if ( name == null )
		{
			throw new NullArgumentException("name is null!");
		}

		this.name = name;
	}

	public StateId getId()
	{
		return id;
	}

	public void setId(StateId id)
	{
		this.id = id;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Country getCountry()
	{
		return country;
	}

	public void setCountry(Country country)
	{
		this.country = country;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		State rhs = (State)obj;

		return new EqualsBuilder().append(id, rhs.getId()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(1619665827, 92821).append(id).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("id", id).append("name", name).append("country", country).toString();
	}

}
