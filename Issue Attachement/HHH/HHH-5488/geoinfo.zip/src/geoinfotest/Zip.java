package geoinfotest;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "Zips")
public class Zip implements Serializable
{
	@EmbeddedId
	private ZipId id;

	@ManyToOne
	@JoinColumn(name = "country_code", referencedColumnName = "code", insertable = false, updatable = false)
	private Country country = null;

	public Zip()
	{
	}

	public ZipId getId()
	{
		return id;
	}

	public void setId(ZipId id)
	{
		this.id = id;
	}

	public Country getCountry()
	{
		return country;
	}

	public void setCountry(Country country)
	{
		this.country = country;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		Zip rhs = (Zip)obj;

		return new EqualsBuilder().append(id, rhs.getId()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(1636505177, 92821).append(id).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("id", id).append("country", country).toString();
	}

}
