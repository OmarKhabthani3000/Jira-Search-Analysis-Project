package geoinfotest;

import java.io.Serializable;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import org.apache.commons.lang.NullArgumentException;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Embeddable
public class ZipAreaId implements Serializable
{
	@Embedded
	private ZipId zipId;

	@Embedded
	private CityId cityId;

	public ZipAreaId()
	{
	}

	public ZipAreaId(ZipId zipId, CityId cityId)
	{
		if ( zipId == null )
		{
			throw new NullArgumentException("zipId is null!");
		}

		if ( cityId == null )
		{
			throw new NullArgumentException("cityId is null!");
		}

		this.zipId = zipId;
		this.cityId = cityId;
	}

	public ZipId getZipId()
	{
		return zipId;
	}

	public CityId getCityId()
	{
		return cityId;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		ZipAreaId rhs = (ZipAreaId)obj;

		return new EqualsBuilder().append(zipId, rhs.getZipId()).append(cityId, rhs.getCityId()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(534363405, 92821).append(zipId).append(cityId).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("zipId", zipId).append("cityId", cityId).toString();
	}

}
