package geoinfotest;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.apache.commons.lang.NullArgumentException;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "Countries")
public class Country implements Serializable
{
	@Column(name = "name")
	private String name;

	@Id
	@Column(name = "code")
	private String code;

	public Country()
	{
	}

	public Country(String name, String code)
	{
		if ( name == null )
		{
			throw new NullArgumentException("name is null!");
		}

		if ( code == null )
		{
			throw new NullArgumentException("code is null!");
		}

		this.name = name;
		this.code = code;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getCode()
	{
		return code;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		Country rhs = (Country)obj;

		return new EqualsBuilder().append(code, rhs.getCode()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(340149201, 92821).append(code).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("name", name).append("code", code).toString();
	}

}
