package geoinfotest;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.persistence.*;

public class GeoInfoTestServlet extends HttpServlet
{
	EntityManagerFactory emf;

	public GeoInfoTestServlet()
	{
		this.emf = Persistence.createEntityManagerFactory("geoinfo");
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		EntityManager em = emf.createEntityManager();
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Geo Info</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<h1>Hello Geo Info!</h1>");
		
		out.println("<p>");
		out.println("No data needed for Hibernate entity manager to fail (causing HTTP 404 error).");
		out.println("</p>");

		out.println("</body>");
		out.println("</html>");

	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		doGet(req, res);
	}


}
