package geoinfotest;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import org.apache.commons.lang.NullArgumentException;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Embeddable
public class CityId implements Serializable
{
	@Embedded
	private StateId stateId;

	@Column(name = "name")
	private String name;

	public CityId()
	{
	}

	public CityId(StateId stateId, String name)
	{
		if ( stateId == null )
		{
			throw new NullArgumentException("stateId is null!");
		}

		if ( name == null )
		{
			throw new NullArgumentException("name is null!");
		}

		this.stateId = stateId;
		this.name = name;
	}

	public StateId getStateId()
	{
		return stateId;
	}

	public String getName()
	{
		return name;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		CityId rhs = (CityId)obj;

		return new EqualsBuilder().append(stateId, rhs.getStateId()).append(name, rhs.getName()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(1443465393, 92821).append(stateId).append(name).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("stateId", stateId).append("name", name).toString();
	}

}
