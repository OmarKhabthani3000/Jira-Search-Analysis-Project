package geoinfotest;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.apache.commons.lang.NullArgumentException;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "PostAddresses")
public class PostAddress implements Serializable
{
	@Id
	@Column(name = "id")
	private Integer id;

	@Column(name = "is_primary")
	private Boolean isPrimary = true;

	@Column(name = "street_name")
	private String streetName = null;

	@Column(name = "street_nbr")
	private String streetNbr = null;

    // UN-/COMMENT ANNOTATIONS HERE: (and optionally in ZipArea.java)
	@ManyToOne
	@JoinColumns(value = {@JoinColumn(name = "country_code", referencedColumnName = "country_code"), @JoinColumn(name = "state_code", referencedColumnName = "state_code"), @JoinColumn(name = "city_name", referencedColumnName = "city_name"), @JoinColumn(name = "zip_code", referencedColumnName = "zip_code")})
	private ZipArea zipArea = null;

	public PostAddress()
	{
	}

	public PostAddress(Integer id, Boolean isPrimary)
	{
		if ( id == null )
		{
			throw new NullArgumentException("id is null!");
		}

		if ( isPrimary == null )
		{
			throw new NullArgumentException("isPrimary is null!");
		}

		this.id = id;
		this.isPrimary = isPrimary;
	}

	public PostAddress(Integer id, Boolean isPrimary, String streetName, String streetNbr)
	{
		if ( id == null )
		{
			throw new NullArgumentException("id is null!");
		}

		if ( isPrimary == null )
		{
			throw new NullArgumentException("isPrimary is null!");
		}

		if ( streetName == null )
		{
			throw new NullArgumentException("streetName is null!");
		}

		if ( streetNbr == null )
		{
			throw new NullArgumentException("streetNbr is null!");
		}

		this.id = id;
		this.isPrimary = isPrimary;
		this.streetName = streetName;
		this.streetNbr = streetNbr;
	}

	public Integer getId()
	{
		return id;
	}

	public void setId(Integer id)
	{
		this.id = id;
	}

	public Boolean getIsPrimary()
	{
		return isPrimary;
	}

	public void setIsPrimary(Boolean isPrimary)
	{
		this.isPrimary = isPrimary;
	}

	public String getStreetName()
	{
		return streetName;
	}

	public void setStreetName(String streetName)
	{
		this.streetName = streetName;
	}

	public String getStreetNbr()
	{
		return streetNbr;
	}

	public void setStreetNbr(String streetNbr)
	{
		this.streetNbr = streetNbr;
	}

	public ZipArea getZipArea()
	{
		return zipArea;
	}

	public void setZipArea(ZipArea zipArea)
	{
		this.zipArea = zipArea;
	}

	@Override
	public boolean equals(Object obj)
	{
		if ( obj == null )
		{
			return false;
		}

		if ( obj == this )
		{
			return true;
		}

		if ( obj.getClass() != getClass() )
		{
			return false;
		}

		PostAddress rhs = (PostAddress)obj;

		return new EqualsBuilder().append(id, rhs.getId()).isEquals();
	}

	@Override
	public int hashCode()
	{
		return new HashCodeBuilder(680445067, 92821).append(id).toHashCode();
	}

	@Override
	public String toString()
	{
		return new ToStringBuilder(this).append("id", id).append("isPrimary", isPrimary).append("streetName", streetName).append("streetNbr", streetNbr).append("zipArea", zipArea).toString();
	}

}
