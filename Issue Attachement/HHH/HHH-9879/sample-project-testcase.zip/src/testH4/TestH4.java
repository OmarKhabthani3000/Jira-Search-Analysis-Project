package testH4;

import javax.persistence.Persistence;

public class TestH4 {

	public static void main(String[] args) {
		try {
			
			Persistence.createEntityManagerFactory("TestPU");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
