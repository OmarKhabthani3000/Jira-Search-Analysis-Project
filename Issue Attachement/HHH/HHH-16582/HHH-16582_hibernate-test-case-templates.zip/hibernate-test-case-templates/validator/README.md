# Hibernate Test Case Templates: Hibernate Validator

This repo contains a test case template useful for reporting bugs against Hibernate Validator.
