package hibernate.bug;

import hibernate.bug.model.Document;
import hibernate.bug.model.Person;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class SubqueryInCaseWhenTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        Person p1 = new Person();
        Person p2 = new Person();
        Document d = new Document();
        
        d.getContacts().put(1, p1);
        d.getContacts().put(2, p2);
        
        em.persist(p1);
        em.persist(p2);
        em.persist(d);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void test() {
        EntityManager em = emf.createEntityManager();
        
        List l = em.createQuery("SELECT CASE WHEN d.id IS NOT NULL THEN (SELECT COUNT(p.id) FROM Person p) ELSE 0 END FROM Document d").getResultList();
        Assert.assertEquals(1, l.size());
        Assert.assertEquals(2, ((Number) l.get(0)).intValue());
        
        em.close();
    }
}
