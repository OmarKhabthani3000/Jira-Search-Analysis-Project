package hibernate;
import java.util.*;
import java.util.List;
import java.util.ArrayList;

public class Application {
	
	String  appId;
	String  appName;
	String appFolderName;
	String userName;
	Date createdTs;
	Date lastModifiedTs;
	String regionId;
	Set submissions;
	
	public Application(){		
	}


	public String getAppFolderName() {
		return appFolderName;
	}


	public void setAppFolderName(String appFolderName) {
		this.appFolderName = appFolderName;
	}


	public String getAppId() {
		return appId;
	}


	public void setAppId(String appId) {
		this.appId = appId;
	}


	public String getAppName() {
		return appName;
	}


	public void setAppName(String appName) {
		this.appName = appName;
	}


	public Date getCreatedTs() {
		return createdTs;
	}


	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	

	public Date getLastModifiedTs() {
		return lastModifiedTs;
	}


	public void setLastModifiedTs(Date lastModifiedTs) {
		this.lastModifiedTs = lastModifiedTs;
	}

	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getRegionId() {
		return regionId;
	}


	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}


	public Set getSubmissions() {
		return submissions;
	}


	public void setSubmissions(Set submissions) {
		this.submissions = submissions;
	}
	
	

}
