package hibernatestore;

import java.io.File;
import java.util.*;

import hibernate.*;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;






public class Main {
	
	public static void main(String args[]){
		
		saveSubmission();
		
	}	
	
	
	
	public static void saveSubmission()
	{
		try{
			SessionFactory sessionFactory=HibernateFactory.buildsessionFactory();
			Session session= sessionFactory.openSession(); 
			Transaction tx=HibernateFactory.begintransaction(session);
			
			
			Submissions oSub=new Submissions();
			// oSub.setApplicationId();//Ho will I set applicationId as "64FB620AD8F94985A58DC1467C4718C9"
			oSub.setSubmissionNo("0005");
			oSub.setSubmissionOrder(5);
			oSub.setUserName("Sreekanth");
			oSub.setCreatedTs(new java.util.Date());
			oSub.setLastModifiedTs(new Date());
			oSub.setStfVersion("5.0");
			oSub.setRegionalVersion("11.0");
			oSub.setIchVersion("4.0");
			session.saveOrUpdate(oSub);
			HibernateFactory.commitTransaction(tx);
			System.out.println("Done");			 
			HibernateFactory.close(session);
			
		}
		catch(Exception e)
		{
			
		}
	}
			

}
