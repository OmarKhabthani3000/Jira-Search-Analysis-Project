package hibernate;

import java.util.*;

public class Submissions {

	String submissionId;
	String submissionNo;
	int submissionOrder;
	String ichVersion;
	String regionalVersion;
	String stfVersion;
	String userName;
	Date createdTs;
	Date lastModifiedTs;	
	Application application;
	
	
	
	
	public Submissions()	{
	}



	public Application getApplication() {
		return application;
	}



	public void setApplication(Application application) {
		this.application = application;
	}



	public Date getCreatedTs() {
		return createdTs;
	}



	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}



	public String getIchVersion() {
		return ichVersion;
	}



	public void setIchVersion(String ichVersion) {
		this.ichVersion = ichVersion;
	}



	public Date getLastModifiedTs() {
		return lastModifiedTs;
	}



	public void setLastModifiedTs(Date lastModifiedTs) {
		this.lastModifiedTs = lastModifiedTs;
	}



	public String getRegionalVersion() {
		return regionalVersion;
	}



	public void setRegionalVersion(String regionalVersion) {
		this.regionalVersion = regionalVersion;
	}



	public String getStfVersion() {
		return stfVersion;
	}



	public void setStfVersion(String stfVersion) {
		this.stfVersion = stfVersion;
	}



	public String getSubmissionId() {
		return submissionId;
	}



	public void setSubmissionId(String submissionId) {
		this.submissionId = submissionId;
	}



	public String getSubmissionNo() {
		return submissionNo;
	}



	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}



	public int getSubmissionOrder() {
		return submissionOrder;
	}



	public void setSubmissionOrder(int submissionOrder) {
		this.submissionOrder = submissionOrder;
	}



	public String getUserName() {
		return userName;
	}



	public void setUserName(String userName) {
		this.userName = userName;
	}



}
