/*==============================================================*/
/* Table: A                                                     */
/*==============================================================*/
create table A
(
   ID                   int not null,
   DESCRIPTIONA         varchar(120),
   ROWVERSION           int,
   primary key (ID)
)
type = InnoDB;

/*==============================================================*/
/* Index: IX_A_ROWVERSION                                       */
/*==============================================================*/
create index IX_A_ROWVERSION on A
(
   ROWVERSION
);

/*==============================================================*/
/* Table: ACLINK                                                */
/*==============================================================*/
create table ACLINK
(
   AID                  int not null,
   CID                  int not null,
   primary key (AID, CID)
);

/*==============================================================*/
/* Table: B                                                     */
/*==============================================================*/
create table B
(
   ID                   int not null,
   DESCRIPTIONB         varchar(100),
   primary key (ID)
)
type = InnoDB;

/*==============================================================*/
/* Table: C                                                     */
/*==============================================================*/
create table C
(
   ID                   int not null,
   DESCRIPTIONC         varchar(120),
   ROWVERSION           int,
   primary key (ID)
)
type = InnoDB;

alter table ACLINK add constraint FK_ACLink_A foreign key (AID)
      references A (ID) on delete restrict on update restrict;

alter table ACLINK add constraint FK_ACLink_C foreign key (CID)
      references C (ID) on delete restrict on update restrict;

alter table B add constraint FK_B_A foreign key (ID)
      references A (ID) on delete restrict on update restrict;
