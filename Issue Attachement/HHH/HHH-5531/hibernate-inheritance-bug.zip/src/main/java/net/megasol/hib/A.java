package net.megasol.hib;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "A")
public class A {
	@Id
	@Column(name = "Id", nullable = false)
	private int mId;

	@Column(name = "DescriptionA", nullable = false)
	private String mDescriptionA;

	@SuppressWarnings("FieldMayBeFinal")
	@OneToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "ACLink",
			joinColumns = @JoinColumn(name = "AId"),
			inverseJoinColumns = @JoinColumn(name = "CId"))
	private Set<C> mCs = new java.util.HashSet<C>();

	@Version
	@Column(name = "RowVersion", nullable = false)
	private int mRowVersion;

	public A() {
	}

	public A(int pId) {
		mId = pId;
	}

	public int getId() {
		return mId;
	}

	public Set<C> getCs() {
		return mCs;
	}

	public String getDescriptionA() {
		return mDescriptionA;
	}

	public void setDescriptionA(String pDescriptionA) {
		mDescriptionA = pDescriptionA;
	}

	public int getRowVersion() {
		return mRowVersion;
	}
}
