package net.megasol.hib;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Main {
	private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);

	private Main() {}

	public static void main(String[] pArgs) {
		Configuration config = new Configuration();
		config.configure();
		SessionFactory sessionFactory = config.buildSessionFactory();

		noInheritance(sessionFactory);
		inheritance(sessionFactory); //This will fail
	}

	private static void noInheritance(SessionFactory pFactory) {
		Session session = pFactory.openSession();
		Transaction transaction = session.beginTransaction();

		A a = new A(1);
		a.setDescriptionA("AAA");
		session.save(a);
		transaction.commit();
		session.close();

		session = pFactory.openSession();
		transaction = session.beginTransaction();
		session.setDefaultReadOnly(true);

		a = (A) session.get(A.class, 1);
		C c = new C(1);
		c.setDescriptionC("CCC");
		session.save(c);

		a.getCs().add(c);
		transaction.commit();
		session.close();

		LOGGER.info("No inheritance version of A works...");
	}

	//Does not work!
	private static void inheritance(SessionFactory pFactory) {
		Session session = pFactory.openSession();
		Transaction transaction = session.beginTransaction();

		B b = new B(2);
		b.setDescriptionA("AAA");
		b.setDescriptionB("BBB");
		session.save(b);
		transaction.commit();
		session.close();

		session = pFactory.openSession();
		transaction = session.beginTransaction();
		session.setDefaultReadOnly(true);

		b = (B) session.get(B.class, 2);
		C c = new C(2);
		c.setDescriptionC("CCC");
		session.save(c);

		b.getCs().add(c);
		transaction.commit();
		session.close();
	}
}
