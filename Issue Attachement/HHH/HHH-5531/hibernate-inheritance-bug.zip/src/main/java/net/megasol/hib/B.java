package net.megasol.hib;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "B")
public class B extends ParentA {
	@Column(name = "DescriptionB", nullable = false)
	private String mDescriptionB;

	public B() {
	}

	public B(int pId) {
		super(pId);
	}

	public String getDescriptionB() {
		return mDescriptionB;
	}

	public void setDescriptionB(String pDescriptionB) {
		mDescriptionB = pDescriptionB;
	}
}
