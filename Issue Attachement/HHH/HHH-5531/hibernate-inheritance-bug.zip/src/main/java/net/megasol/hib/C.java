package net.megasol.hib;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "C")
public class C {
	@Id
	@Column(name = "Id", nullable = false)
	private int mId;

	@Column(name = "DescriptionC", nullable = false)
	private String mDescriptionC;

	@Version
	@Column(name = "RowVersion", nullable = false)
	private int mRowVersion;

	public C() {
	}

	public C(int pId) {
		mId = pId;
	}

	public String getDescriptionC() {
		return mDescriptionC;
	}

	public void setDescriptionC(String pDescriptionC) {
		mDescriptionC = pDescriptionC;
	}

	public int getRowVersion() {
		return mRowVersion;
	}
}
