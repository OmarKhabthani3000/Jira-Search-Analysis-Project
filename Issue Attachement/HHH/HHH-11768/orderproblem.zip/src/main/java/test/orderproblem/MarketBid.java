package test.orderproblem;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.TableGenerator;

@Entity
@Access(AccessType.FIELD)
public class MarketBid {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "MarketBid")
	@TableGenerator(name = "MarketBid", pkColumnValue = "MarketBid", allocationSize = 10000)
	private Long id;

	@ManyToOne(optional = false, cascade = CascadeType.PERSIST)
	private MarketBidGroup group;

	public Long getId() {
		return id;
	}

	public void setGroup(MarketBidGroup group) {
		this.group = group;
	}

}
