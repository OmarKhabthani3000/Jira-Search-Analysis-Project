package test.orderproblem;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.TableGenerator;

@Entity
@Access(AccessType.FIELD)
public class MarketBidGroup {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "MarketBidGroup")
	@TableGenerator(name = "MarketBidGroup", pkColumnValue = "MarketBidGroup", allocationSize = 10000)
	private Long id;

	@OneToMany(mappedBy = "group")
	private final Set<MarketBid> marketBids = new HashSet<>();

	public void addMarketBid(MarketBid marketBid) {
		this.marketBids.add(marketBid);
	}

}
