package test.orderproblem;

import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class OrderProblemTest {
	private SessionFactory sessionFactory;

	@Before
	public void setup() {
		final Configuration configure = new Configuration().configure();
		sessionFactory = configure
				.buildSessionFactory(new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build());
	}

	@After
	public void teardown() {
		sessionFactory.close();
	}

	@Test
	public void testOrder() {
		Long bidId;
		try (Session session = sessionFactory.openSession()) {
			session.setFlushMode(FlushMode.COMMIT);
			session.getTransaction().begin();

			// create new MarketBid and -Group
			final MarketBidGroup group = new MarketBidGroup();
			final MarketBid bid = new MarketBid();
			bid.setGroup(group);
			session.persist(bid);

			session.getTransaction().commit();

			bidId = bid.getId();
		}
		try (Session session = sessionFactory.openSession()) {
			session.setFlushMode(FlushMode.COMMIT);
			session.getTransaction().begin();

			// add MarketResult to existing MarketBid
			final MarketBid existingBid = session.load(MarketBid.class, bidId);
			final MarketResult resultForExistingBid = new MarketResult();
			resultForExistingBid.setMarketBid(existingBid);
			session.persist(resultForExistingBid);

			// create new MarketBid, -Group and -Result
			final MarketBidGroup newGroup = new MarketBidGroup();
			final MarketBid newBid = new MarketBid();
			newBid.setGroup(newGroup);
			final MarketResult newResult = new MarketResult();
			newResult.setMarketBid(newBid);

			session.persist(newBid);
			session.persist(newResult);

			session.getTransaction().commit();
		}
	}
}
