package org.hibernate.bugs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.NaturalIdLoadAccess;
import org.hibernate.Session;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

    private EntityManagerFactory entityManagerFactory;

    @Before
    public void init() {
        entityManagerFactory = Persistence.createEntityManagerFactory("templatePU");
    }

    @After
    public void destroy() {
        if (entityManagerFactory != null) {
            entityManagerFactory.close();
        }
    }

    @Test
	// OK
    public void bothNonNull() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        final Session session = (Session) entityManager.getDelegate();
        final NaturalIdLoadAccess<SimpleEntity> crit = session.byNaturalId(SimpleEntity.class);
        crit.using("a", 1);
        crit.using("b", 2);

        Assert.assertNull(crit.load());
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    @Test
	// OK
    public void firstIsNull() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        final Session session = (Session) entityManager.getDelegate();
        final NaturalIdLoadAccess<SimpleEntity> crit = session.byNaturalId(SimpleEntity.class);
        crit.using("a", null);
        crit.using("b", 2);

        Assert.assertNull(crit.load());
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    @Test
	// OK
    public void secondIsNull() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        final Session session = (Session) entityManager.getDelegate();
        final NaturalIdLoadAccess<SimpleEntity> crit = session.byNaturalId(SimpleEntity.class);
        crit.using("a", 1);
        crit.using("b", null);

        Assert.assertNull(crit.load());
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    @Test
	// Problem
    public void bothAreNull() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        final Session session = (Session) entityManager.getDelegate();
        final NaturalIdLoadAccess<SimpleEntity> crit = session.byNaturalId(SimpleEntity.class);
        crit.using("a", null);
        crit.using("b", null);

        Assert.assertNull(crit.load());
        entityManager.getTransaction().commit();
        entityManager.close();
    }

}
