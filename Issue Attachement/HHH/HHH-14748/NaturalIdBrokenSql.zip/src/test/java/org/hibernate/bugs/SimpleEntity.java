package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.NaturalId;

@Entity
public class SimpleEntity {

    @Id
    private Long id;

    @NaturalId
    private Integer a;

    @NaturalId
    private Integer b;

}