/*
 * Copyright (c) Krakfin
 * All rights reserved
 */

public class Main {

    public static void main(String[] args) {

    }
}
