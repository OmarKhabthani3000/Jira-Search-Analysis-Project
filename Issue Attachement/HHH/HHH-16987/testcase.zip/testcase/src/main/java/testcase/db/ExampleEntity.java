/*
 * Copyright (c) Krakfin
 * All rights reserved
 */

package testcase.db;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.util.Objects;

@Entity
public class ExampleEntity {

    @Id
    private int id;

    public static ExampleEntity of(int id) {
        var obj = new ExampleEntity();
        obj.setId(id);
        return obj;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ExampleEntity that = (ExampleEntity) o;
        return id == that.id;
    }

    @Override public int hashCode() {
        return Objects.hash(id);
    }
}
