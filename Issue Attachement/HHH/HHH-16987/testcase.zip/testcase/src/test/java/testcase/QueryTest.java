package testcase;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import static org.assertj.core.api.Assertions.assertThat;
import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.output.MigrateResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testcase.db.ExampleEntity;
import testcase.db.ExampleEntity_;

public class QueryTest {


    private static final Logger LOGGER = LogManager.getLogger();

    private EntityManagerFactory emf;
    private EntityManager em;

    @Test
    public void doQuery() {
        //given
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<ExampleEntity> query = cb.createQuery(ExampleEntity.class);
        Root<ExampleEntity> root = query.from(ExampleEntity.class);
        //when
        query.select(root).where(
                cb.equal(root.get(ExampleEntity_.id), 1)
        );
        var entity = em.createQuery(query).getSingleResult();
        //then
        assertThat(entity).isNotNull();
    }


    @BeforeClass
    private void beforeClass() {
        Flyway flyway = Flyway.configure().dataSource("jdbc:hsqldb:mem:jpa_test", "user", "password").load();
        MigrateResult migrateResult = flyway.migrate();
        LOGGER.info("Migrations: {}", migrateResult.migrationsExecuted);
        emf = Persistence.createEntityManagerFactory("jpa_test");
        em = emf.createEntityManager();
    }

    @AfterClass
    private void afterClass() {
        em.close();
        emf.close();
    }

    @BeforeMethod
    private void beforeMethod() {
        em.getTransaction().begin();
    }

    @AfterMethod
    private void afterMethod() {
        em.getTransaction().rollback();
    }
}
