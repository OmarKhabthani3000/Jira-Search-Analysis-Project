

create table exampleentity (
    id integer primary key
);


insert into exampleentity(id)
    values (1), (2);
