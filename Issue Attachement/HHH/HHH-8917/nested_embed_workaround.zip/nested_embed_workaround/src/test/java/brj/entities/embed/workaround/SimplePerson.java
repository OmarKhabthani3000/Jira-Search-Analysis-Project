package brj.entities.embed.workaround;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "TEST_SIMPLE_PERSON_OK")
@Access(AccessType.FIELD)
@SecondaryTable(name = SimplePerson.SECONDARY)
public class SimplePerson {

    public static final String SECONDARY = "SECONDARY_PERSON_OK";

    @Id
    @GeneratedValue
    private long id;

    @Version
    private long version;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "code1.code", column = @Column(table = SECONDARY, name = "CODE1")),
            @AttributeOverride(name = "code2.code", column = @Column(table = SECONDARY, name = "CODE2")),
            @AttributeOverride(name = "a_name", column = @Column(table = SECONDARY, name = "NAME"))})
    private EmbeddableWithCodes embeddableWithCodes;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getVersion() {
        return version;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (id ^ (id >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        SimplePerson other = (SimplePerson) obj;
        if (id != other.id)
            return false;
        return true;
    }

    public EmbeddableWithCodes getEmbeddableWithCodes() {
        return embeddableWithCodes;
    }

    public void setEmbeddableWithCodes(EmbeddableWithCodes embeddableWithCodes) {
        this.embeddableWithCodes = embeddableWithCodes;
    }

}
