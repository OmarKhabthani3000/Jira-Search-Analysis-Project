package brj.entities.embed.workaround;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;

@Embeddable
public class EmbeddableWithCodes {

    @Embedded
    private SimpleEmbeddable code1;
    @Embedded
    private SimpleEmbeddable code2;
    //prefix with 'a' change the order in which the fields are processed
    private String a_name;

    public String getA_name() {
        return a_name;
    }

    public void setA_name(String name) {
        this.a_name = name;
    }

    public SimpleEmbeddable getCode1() {
        return code1;
    }

    public void setCode1(SimpleEmbeddable code1) {
        this.code1 = code1;
    }

    public SimpleEmbeddable getCode2() {
        return code2;
    }

    public void setCode2(SimpleEmbeddable code2) {
        this.code2 = code2;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((a_name == null) ? 0 : a_name.hashCode());
        result = prime * result + ((code1 == null) ? 0 : code1.hashCode());
        result = prime * result + ((code2 == null) ? 0 : code2.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        EmbeddableWithCodes other = (EmbeddableWithCodes) obj;
        if (a_name == null) {
            if (other.a_name != null)
                return false;
        } else if (!a_name.equals(other.a_name))
            return false;
        if (code1 == null) {
            if (other.code1 != null)
                return false;
        } else if (!code1.equals(other.code1))
            return false;
        if (code2 == null) {
            if (other.code2 != null)
                return false;
        } else if (!code2.equals(other.code2))
            return false;
        return true;
    }

}
