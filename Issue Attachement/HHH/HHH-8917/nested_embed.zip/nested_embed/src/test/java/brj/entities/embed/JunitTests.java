package brj.entities.embed;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.Assert;
import org.junit.Test;

public class JunitTests {

    @Test
    public void test() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("TEST");
        EntityManager em = emf.createEntityManager();

        SimplePerson person = new SimplePerson();
        EmbeddableWithCodes embeddableWithCodes = new EmbeddableWithCodes();
        embeddableWithCodes.setName("Test");
        embeddableWithCodes.setCode1(new SimpleEmbeddable(1));
        embeddableWithCodes.setCode2(new SimpleEmbeddable(2));
        person.setEmbeddableWithCodes(embeddableWithCodes);

        EntityTransaction tx = em.getTransaction();
        tx.begin();
        em.persist(person);
        tx.commit();
        em.close();

        // Reload and Compare Revision
        em = emf.createEntityManager();
        SimplePerson personLoaded = em.find(SimplePerson.class, person.getId());
        Assert.assertNotNull(personLoaded);
        Assert.assertEquals(person, personLoaded);
        Assert.assertEquals(person.getEmbeddableWithCodes(), personLoaded.getEmbeddableWithCodes());
    }

}
