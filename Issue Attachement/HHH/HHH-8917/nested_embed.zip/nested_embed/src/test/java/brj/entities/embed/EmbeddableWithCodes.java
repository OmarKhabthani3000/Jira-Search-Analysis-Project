package brj.entities.embed;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;

@Embeddable
public class EmbeddableWithCodes {

    @Embedded
    private SimpleEmbeddable code1;
    @Embedded
    private SimpleEmbeddable code2;
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public SimpleEmbeddable getCode1() {
        return code1;
    }

    public void setCode1(SimpleEmbeddable code1) {
        this.code1 = code1;
    }

    public SimpleEmbeddable getCode2() {
        return code2;
    }

    public void setCode2(SimpleEmbeddable code2) {
        this.code2 = code2;
    }

}
