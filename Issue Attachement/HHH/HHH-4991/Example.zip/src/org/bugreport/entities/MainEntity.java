package org.bugreport.entities;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class MainEntity
{
	@Id
	@Column(name = "main_id")
	@GeneratedValue
	public Long id;
	
	@OneToMany(mappedBy = "entity", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	public List<SubMainEntity> subentities;
	
	@ManyToMany
	(
			targetEntity = SideEntity.class,
			cascade={CascadeType.PERSIST, CascadeType.MERGE},
			fetch = FetchType.LAZY
	)
	@JoinTable
	(
			name="MainSide",
			joinColumns={@JoinColumn(name="main_id")},
			inverseJoinColumns={@JoinColumn(name="side_id")}
	)
	public Set<SideEntity> sides = new HashSet<SideEntity>();
	
	@Column
	public String data;
	
}
