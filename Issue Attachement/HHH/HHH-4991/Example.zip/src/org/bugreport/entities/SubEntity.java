package org.bugreport.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class SubEntity
{
	@Id
	@Column(name = "sub_id")
	@GeneratedValue
	public Long id;
	
	@ManyToOne
	@JoinColumn(name="submain_id")
	public SubMainEntity entity;

	@Column
	public String data;

}
