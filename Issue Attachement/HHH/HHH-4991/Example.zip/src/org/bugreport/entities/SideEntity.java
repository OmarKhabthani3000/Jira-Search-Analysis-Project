package org.bugreport.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.xml.bind.annotation.XmlTransient;

@Entity
public class SideEntity
{
	@Id
	@Column(name = "side_id")
	@GeneratedValue
	public Long id;
	

	@ManyToMany(
	        mappedBy = "sides",
	        targetEntity = MainEntity.class,
	        fetch = FetchType.LAZY
	    )
	@XmlTransient
	public Set<MainEntity> mains = new HashSet<MainEntity>();
	
	@Column
	public String data;

}
