package org.bugreport.main;

import java.util.List;

import org.bugreport.entities.SubEntity;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

public class BugreportTest
{

	public static void main(String[] args) throws Exception
	{
            SessionFactory sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
            Session session = sessionFactory.getCurrentSession();
            Transaction tx = session.beginTransaction();
            Criteria c = session.createCriteria(SubEntity.class)
            					.createAlias("entity", "e")
            					.createAlias("e.entity", "ee")
            					.createAlias("ee.sides", "s")
            					.setProjection(Projections.count("id"));
            c.add(Restrictions.ne("s.data", "abc"));

            List<Object> list = c.list();

            for (Object entity : list)
			{
            	System.out.println(entity);
			}
            
            tx.commit();
	}

}
