package com.bstirbat.entity;

import com.bstirbat.converter.StringListConverter;

import javax.persistence.*;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Entity(name = "Product")
public class Product {

//    @Id
//    @Column
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private int id;
//
//    @Column
//    private String name;
//
//    @Column
//    private String description;

    //@Column
    @Convert(converter = StringListConverter.class)
    private List<String> paths;

    public Product() {

    }

//    public int getId() {
//        return id;
//    }
//
//    public void setId(int id) {
//        this.id = id;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getDescription() {
//        return description;
//    }
//
//    public void setDescription(String description) {
//        this.description = description;
//    }

    public List<String> getPaths() {
        return paths;
    }

    public Set<String> getPaths(final String startPath) {
        return paths.stream()
                .filter(p -> p.startsWith(startPath))
                .collect(Collectors.toSet());
    }

    public void setPaths(List<String> paths) {
        this.paths = paths;
    }
}
