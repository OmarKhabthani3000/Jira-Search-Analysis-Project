package hbug960;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.criterion.Restrictions;
import org.hibernate.dialect.Dialect;

import com.mckoi.runtime.McKoiDBMain;

public class Main {

	private static final String EMBEDDED_MCKOI_PREFIX = "jdbc:mckoi:local://";

	private static final String EMBEDDED_MCKOI_DIR = "./db/";

	private static final String EMBEDDED_MCKOI_CONF = "db.conf";

	private static final String EMBEDDED_MCKOI_URL = EMBEDDED_MCKOI_PREFIX
			+ EMBEDDED_MCKOI_DIR + EMBEDDED_MCKOI_CONF;

	private static Configuration conf;

	private static SessionFactory sessionFactory;

	public static void main(String[] main) throws Exception {
		conf = new Configuration();
		conf.configure("hbug960/hibernate.cfg.xml");
		sessionFactory = conf.buildSessionFactory();
		setupDB();
		Session session = getSessionFactory().openSession();
		Property width = (Property) session.createCriteria(Property.class).add(
				Restrictions.eq("name", "width")).list().get(0);
		Property height = (Property) session.createCriteria(Property.class)
				.add(Restrictions.eq("name", "height")).list().get(0);
		Component book = (Component) session.createCriteria(Component.class)
				.add(Restrictions.eq("name", "book")).list().get(0);
		Component library = (Component) session.createCriteria(Component.class)
				.add(Restrictions.eq("name", "library")).list().get(0);

		assertEq(library.getName(), "library");
		assertEq(book.getParent().getName(), "library");
		assertEq(book.getName(), "book");
		assertEq(width.getName(), "width");
		assertEq(height.getName(), "height");

		assertEq(((Value) book.getValues().get(width)).getValue(), "wide");
		assertEq(((Value) library.getValues().get(height)).getValue(), "tall");

		String hqlWorks = "select "
			+ "library.name, "
			+ "width.value, "
			+ "height.value "
			+ "from "
			+ "Component as library "
			+ "left join library.children as book with book.parent=:parent "
			+ "left join library.values as height with height.property=:height " // A
			+ "left join book.values as width with width.property=:width " // B
			+ "where library=:library";
		String hqlBroken = "select "
			+ "library.name, "
			+ "width.value, "
			+ "height.value "
			+ "from "
			+ "Component as library "
			+ "left join library.children as book with book.parent=:parent "
			+ "left join library.values as height with height.property=:height " //B
			+ "left join book.values as width with width.property=:width " // A
			+ "where library=:library";
		//Query query = session.createQuery(hqlWorks);
		Query query = session.createQuery(hqlBroken);
		query.setParameter("width", width);
		query.setParameter("height", height);
		query.setParameter("library", library);
		query.setParameter("parent", library);
		List result = query.list();
		Object[] firstRow = (Object[]) result.get(0);

		for (int r = 0; r < result.size(); r++) {
			Object[] row = (Object[]) result.get(0);
			for (int i = 0; i < row.length; i++) {
				Object object = row[i];
				System.out.print(object);
				System.out.print(", ");
			}
		}
		System.out.println();

		assertEq("library", firstRow[0]);
		assertEq("wide", firstRow[1]);
		assertEq("tall", firstRow[2]);

		session.close();
	}

	private static void assertEq(Object v1, Object v2) {
		if (v1 == v2)
			return;
		if (v1 == null || v2 == null || !v1.equals(v2))
			throw new RuntimeException("'" + v1 + "' not equal to '" + v2 + "'");
	}

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	private static void setupDB() throws IOException, SQLException {
		String url = conf.getProperty(Environment.URL);
		if (EMBEDDED_MCKOI_URL.equals(url)) {
			File confDir = new File(EMBEDDED_MCKOI_DIR);
			confDir.mkdirs();
			File confFile = new File(confDir, EMBEDDED_MCKOI_CONF);
			if (!confFile.exists()) {
				InputStream dataIS = Main.class.getResourceAsStream("db.conf");
				FileOutputStream out = new FileOutputStream(confFile);
				copyFile(dataIS, out);
				String username = conf.getProperty(Environment.USER);
				String password = conf.getProperty(Environment.PASS);
				String[] args = new String[] { "-conf", confFile.toString(),
						"-create", username, password };
				McKoiDBMain.main(args);
				createDB();
			}
		}

	}

	private static void copyFile(InputStream in, OutputStream out)
			throws IOException {
		byte[] buf = new byte[1024];
		int size;
		while ((size = in.read(buf)) != -1)
			out.write(buf, 0, size);
		out.close();
		in.close();
	}

	public static void createDB() throws SQLException {
		Session session = getSessionFactory().openSession();
		Connection conn = session.connection();

		Dialect dialect = Dialect.getDialect(conf.getProperties());

		String[] create = conf.generateSchemaCreationScript(dialect);

		for (int i = 0; i < create.length; i++) {
			String sql = create[i];
			System.out.println(sql);
			conn.createStatement().executeQuery(sql).close();
		}
		conn.commit();

		session.close();
		Property width = new Property("width");
		Property height = new Property("height");
		Component library = new Component("library");
		Component book = new Component("book");
		book.setParent(library);
		Value tall = new Value(book, height, "tall");
		Value wide = new Value(book, width, "wide");

		session = getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		session.persist(width);
		session.persist(height);
		session.persist(library);
		session.persist(book);
		session.persist(tall);
		session.persist(wide);
		tx.commit();
		session.close();
	}
}
