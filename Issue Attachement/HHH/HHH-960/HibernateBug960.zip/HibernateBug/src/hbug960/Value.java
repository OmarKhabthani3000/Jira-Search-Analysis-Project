package hbug960;

import java.io.Serializable;

public class Value implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2904746587219342825L;

	private Component component;

	private Property property;

	private String value;

	public Value() {

	}

	public Value(Component component, Property property, String value) {
		this.component = component;
		this.property = property;
		this.value = value;
	}

	public Component getComponent() {
		return component;
	}

	public void setComponent(Component component) {
		this.component = component;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Property getProperty() {
		return property;
	}

	public void setProperty(Property property) {
		this.property = property;
	}
}
