package org.example.enversbug;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.envers.Audited;

@Entity
@Audited
public class GroupMember {
    @Id
    @GeneratedValue(generator="increment")
    @GenericGenerator(name="increment", strategy = "increment")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "uniqueGroup_id", insertable = false, updatable = false)
    private UniqueGroup uniqueGroup;

    @ManyToMany(mappedBy = "members")
    private List<MultiGroup> multiGroups = new ArrayList<MultiGroup>();

    public void addMultiGroup(MultiGroup multiGroup) {
        multiGroups.add(multiGroup);
    }
}
