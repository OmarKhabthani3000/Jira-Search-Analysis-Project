package org.example.enversbug;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class GroupMemberTest {

    private EntityManagerFactory entityManagerFactory;
    private EntityManager entityManager;

    @Before
    public void setUp() {
        entityManagerFactory = Persistence.createEntityManagerFactory("org.example.enversbug");
        entityManager = entityManagerFactory.createEntityManager();
    }

    @After
    public void tearDown() {
        entityManagerFactory.close();
    }

    @Test
    public void test() {
        UniqueGroup uniqueGroup = new UniqueGroup();
        GroupMember member = new GroupMember();
        uniqueGroup.addMember(member);

        persist(uniqueGroup, member);

        assertThat(currentAuditUniqueGroupId(), is(BigInteger.valueOf(uniqueGroup.getId())));

        MultiGroup multiGroup = new MultiGroup();
        multiGroup.addMember(member);
        member.addMultiGroup(multiGroup);

        persist(multiGroup);

        assertThat(currentAuditUniqueGroupId(), is(BigInteger.valueOf(uniqueGroup.getId())));

        entityManager.close();
    }

    private BigInteger currentAuditUniqueGroupId() {
        return (BigInteger) entityManager.createNativeQuery(
                "select uniqueGroup_id from groupmember_aud order by rev desc limit 1"
        ).getSingleResult();
    }

    private void persist(Object... entities) {
        entityManager.getTransaction().begin();
        for (Object entity : entities) {
            entityManager.persist(entity);
        }
        entityManager.getTransaction().commit();
    }
}
