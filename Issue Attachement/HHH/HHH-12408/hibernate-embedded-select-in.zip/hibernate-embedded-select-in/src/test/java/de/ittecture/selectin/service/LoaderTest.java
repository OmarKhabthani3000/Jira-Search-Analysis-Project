package de.ittecture.selectin.service;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import de.ittecture.selectin.entity.Country;
import de.ittecture.selectin.entity.Operator;

public class LoaderTest {
	
	private EntityManager em;
	
	private Country germany;
	
	@Before
	public void setup() {
		EntityManagerFactory emf = Persistence
                .createEntityManagerFactory("OperatorPU");
        em = emf.createEntityManager();
		
		germany = createCountry("DE");
		Country england = createCountry("UK");
		createOperator("Tina", germany);
		createOperator("John", england);
	}

    private Country createCountry(String name) {
        em.getTransaction().begin();
        Country country = new Country(name);
        em.persist(country);
        em.getTransaction().commit();
        return country;
    }

    private void createOperator(String name, Country country) {
        em.getTransaction().begin();
        Operator operator = new Operator(name);
        operator.getClassification().setTerritories(Arrays.asList(country));
        em.persist(operator);
        em.getTransaction().commit();
    }
    
    @Test
    public void canPrintOperators() {
    	System.out.println("-- loading operators --");
    	Loader loader = new Loader(em);
    	List<Operator> operators = loader.findByCountries(Arrays.asList(germany.getId()));
    	operators.forEach((x) -> System.out.printf("- %s%n", x));
    	Assert.assertThat(operators.size(), CoreMatchers.equalTo(1));
    }
}