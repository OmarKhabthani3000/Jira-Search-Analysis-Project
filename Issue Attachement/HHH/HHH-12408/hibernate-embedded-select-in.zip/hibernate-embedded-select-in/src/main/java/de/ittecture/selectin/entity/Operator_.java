package de.ittecture.selectin.entity;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(Operator.class)
public class Operator_ {

	public static volatile SingularAttribute<Operator, Integer> id;
	public static volatile SingularAttribute<Operator, String> name;
	public static volatile SingularAttribute<Operator, Classification> classification;
}