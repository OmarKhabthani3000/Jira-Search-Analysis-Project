package de.ittecture.selectin.entity;

import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(Classification.class)
public class Classification_ {

	public static volatile SetAttribute<Classification, Territory> territories;
}