package de.ittecture.selectin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class Country extends Territory {
	
	@Column(nullable = false)
	private String countryCode;

	public Country() {
		super();
	}

	public Country(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
}