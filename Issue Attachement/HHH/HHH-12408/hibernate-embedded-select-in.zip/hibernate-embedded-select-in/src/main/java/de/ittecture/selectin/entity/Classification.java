package de.ittecture.selectin.entity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;

import org.hibernate.annotations.Formula;

@Embeddable
public class Classification {
	/**
	 * From {@linkplain http://stackoverflow.com/questions/1324266/can-i-make-an-embedded-hibernate-entity-non-nullable here}
	 * 
	 * Question for alternative {@linkplain http://www.coderanch.com/t/629485/ORM/databases/columns-Embedded-field-NULL-JPA here}
	 */
	@Formula("0")
	private int dummy;

	/*
	 * We need <any> order of territory entries. Otherwise components get confused
	 * on managed items. Which order is taken is not relevant. But it has to be stable.
	 */
	@ManyToMany(fetch = FetchType.EAGER)
	private Set<Territory> territories;

	public Classification() {
		super();
	}
	
	public Classification(Classification classification) {
		this.setTerritories(classification.getTerritories() == null ? null : new ArrayList<Territory>(classification.getTerritories()));
	}

	public List<Territory> getTerritories() {
		return this.territories == null ? new ArrayList<Territory>() : new ArrayList<Territory>(territories);
	}

	public Classification setTerritories(List<Territory> territories) {
		this.territories = territories == null ? null : new HashSet<Territory>(territories);
		return this;
	}
}
