package de.ittecture.selectin.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;

import de.ittecture.selectin.entity.Classification_;
import de.ittecture.selectin.entity.Operator;
import de.ittecture.selectin.entity.Operator_;
import de.ittecture.selectin.entity.Territory;

public class Loader {

	private final EntityManager entityManager;

	public Loader(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public List<Operator> findByCountries(List<Serializable> countries) {
		return new OperatorsInCountriesFactory(entityManager)
				.restrictedByCountries(countries)
				.create();
	}
	
	private static class OperatorsInCountriesFactory {
		
		private final EntityManager entityManager;
		
		private final CriteriaBuilder builder;
		private final CriteriaQuery<Operator> query;
		private final Root<Operator> root;
		private final ArrayList<Predicate> restrictions;
		
		public OperatorsInCountriesFactory(EntityManager entityManager) {
			this.entityManager = entityManager;
			
			this.builder = entityManager.getCriteriaBuilder();
			this.query = builder.createQuery(Operator.class);
			this.root = query.from(Operator.class);
			
			this.restrictions = new ArrayList<Predicate>();
		}
		
		public List<Operator> create() {
			query.select(root);

			query.where(
					builder.and(
							restrictions.toArray(new Predicate[restrictions.size()])
					)
			);
			query.orderBy(builder.asc(root.get(Operator_.name)));
			TypedQuery<Operator> result = entityManager.createQuery(query);
			return result.getResultList();
		}

		public OperatorsInCountriesFactory restrictedByCountries(List<Serializable> countries) {
			if (countries != null && !countries.isEmpty()) {
				Subquery<Operator> includedCountries = query.subquery(Operator.class);
				Root<Operator> includeRoot = includedCountries.from(Operator.class);
				includedCountries.select(includeRoot);
				final Expression<Set<Territory>> path = includeRoot.get(Operator_.classification).get(Classification_.territories);
				includedCountries.where(
						path.in(countries)
				);
				
				restrictions.add(builder.in(root.get("id")).value(includedCountries));
			}
			return this;
		}
	}
}