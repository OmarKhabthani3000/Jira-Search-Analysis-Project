/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * License: GNU Lesser General Public License (LGPL), version 2.1 or later. See the lgpl.txt file in
 * the root directory or <http://www.gnu.org/licenses/lgpl-2.1.html>.
 */
package com.test.cc;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.GeometryFactory;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:inheritanceSecondaryTableTestBeans.xml")
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class,
    TransactionalTestExecutionListener.class})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
public class InheritanceSecondaryTableTest51Reworked {

  @Inject
  private transient TopLevelRepository repository;

  @Test
  public void testInheritanceWithSecondaryTableFail() {

    GeometryFactory geometryFactory = new GeometryFactory();

    // Set up a circle
    final ShapeCircleEntity circle = new ShapeCircleEntity();
    circle.setCentre("CENTRE");

    // Set up a point.
    ShapePointEntity point = new ShapePointEntity();
    Geometry pointGeom = geometryFactory.createPoint(new Coordinate(1, 1));
    point.setShape(pointGeom);

    // Set up another point.
    ShapePointEntity point2 = new ShapePointEntity();
    Geometry pointGeom2 = geometryFactory.createPoint(new Coordinate(2, 2));
    point2.setShape(pointGeom2);

    // Define the top level entity.
    final TopLevelEntity top = new TopLevelEntity();

    // Create an area containing a point and add to the top level entity.
    final GeographicArea geographicArea = new GeographicArea();
    geographicArea.setTopLevel(top);

    geographicArea.setShape(point);
    top.getGeographicAreas().add(geographicArea);

    // Create a different point in the nested list
    List<NestedGeographicArea> nestedAreaList = new ArrayList<NestedGeographicArea>();

    NestedGeographicArea nestedArea = new NestedGeographicArea();
    nestedArea.setShape(point2);
    nestedArea.setParentGeographicArea(geographicArea);

    nestedAreaList.add(nestedArea);

    // Add the nested list to the area.
    geographicArea.setNestedGeographicAreas(nestedAreaList);

    repository.saveAndFlush(top);
  }

  @Test
  public void testInheritanceWithSecondaryTableWorks() {

    GeometryFactory geometryFactory = new GeometryFactory();

    // Set up a circle
    final ShapeCircleEntity circle = new ShapeCircleEntity();
    circle.setCentre("CENTRE");

    // Set up a point.
    ShapePointEntity point = new ShapePointEntity();
    Geometry pointGeom = geometryFactory.createPoint(new Coordinate(1, 1));
    point.setShape(pointGeom);

    // Define the top level entity.
    final TopLevelEntity top = new TopLevelEntity();

    // Create an area containing a point and add to the top level entity.
    final GeographicArea geographicArea = new GeographicArea();
    geographicArea.setTopLevel(top);

    geographicArea.setShape(point);
    top.getGeographicAreas().add(geographicArea);

    // Create a circle in the nested list
    List<NestedGeographicArea> nestedAreaList = new ArrayList<NestedGeographicArea>();

    NestedGeographicArea nestedArea = new NestedGeographicArea();
    nestedArea.setShape(circle);
    nestedArea.setParentGeographicArea(geographicArea);

    nestedAreaList.add(nestedArea);

    // Add the nested list to the area.
    geographicArea.setNestedGeographicAreas(nestedAreaList);

    repository.saveAndFlush(top);
  }
}
