package com.test.cc;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;

@Entity
@DiscriminatorValue("CIRCLE")
@SecondaryTable(name = "SHAPE_CIRCLE", pkJoinColumns = @PrimaryKeyJoinColumn(name = "SHAPE_ID"))
public class ShapeCircleEntity extends ShapeEntity {
  @Column(table = "SHAPE_CIRCLE")
  private String centre;

  public String getCentre() {
    return centre;
  }

  public void setCentre(String centre) {
    this.centre = centre;
  }
}
