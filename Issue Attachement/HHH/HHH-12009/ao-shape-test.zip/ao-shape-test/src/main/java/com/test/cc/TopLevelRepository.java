package com.test.cc;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TopLevelRepository extends JpaRepository<TopLevelEntity, Integer> {

}
