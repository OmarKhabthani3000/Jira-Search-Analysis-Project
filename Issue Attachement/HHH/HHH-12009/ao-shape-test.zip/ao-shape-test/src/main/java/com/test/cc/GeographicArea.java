
package com.test.cc;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "GEOGRAPHIC_AREA")
public class GeographicArea {

  @Id
  @GeneratedValue
  private Integer id;

  /// The reference to the top level class.
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "TOP_LEVEL_ID")
  private TopLevelEntity topLevel;

  @Column(name = "TOP_LEVEL_ID", updatable = false, insertable = false)
  private Long topLevelId;

  // The reference to the shape.
  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "SHAPE_ID")
  private ShapeEntity shape;

  @OneToMany(mappedBy = "parentGeographicArea", fetch = FetchType.LAZY, cascade = {CascadeType.ALL},
      orphanRemoval = true)
  private List<NestedGeographicArea> nestedGeographicAreas;

  public List<NestedGeographicArea> getNestedGeographicAreas() {
    return nestedGeographicAreas;
  }

  public void setNestedGeographicAreas(List<NestedGeographicArea> nestedGeographicAreas) {
    this.nestedGeographicAreas = nestedGeographicAreas;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public TopLevelEntity getTopLevel() {
    return topLevel;
  }

  public void setTopLevel(TopLevelEntity topLevel) {
    this.topLevel = topLevel;
  }

  public ShapeEntity getShape() {
    return shape;
  }

  public void setShape(ShapeEntity shape) {
    this.shape = shape;
  }
}
