/**
 * Title: GeoDBTestDataSourceFactory
 * 
 * Copyright (c) 2014 Thales UK Ltd, Throop Road, Templecombe, Somerset, BA8 0DH, UK
 * 
 * Company: Thales UK Ltd
 *
 * Safety Integrity Level: None
 * 
 * Classification: NOT PROTECTIVELY MARKED
 *
 * Security Enforcement Level: Security Irrelevant
 */
package com.test.cc;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import geodb.GeoDB;

/**
 * Gets a test GeoDB Data Source
 */
@SuppressWarnings({"PMD.SignatureDeclareThrowsException"})
// Suppress cos the throws comes from FactoryBean.
public class GeoDBTestDataSourceFactory implements FactoryBean<Object> {
  /**
   * Logger
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(GeoDBTestDataSourceFactory.class);

  /**
   * The object created by this factory.
   */
  private transient DataSource dataSource;

  /**
   * Constructor
   */
  public GeoDBTestDataSourceFactory() {
    // Empty constructor
  }

  /**
   * This method is automatically called by Spring to expose the DataSource as a bean
   * 
   * @return Object
   * @throws Exception
   */
  public Object getObject() throws Exception {
    return getDataSource();
  }

  /**
   * Get object type
   * 
   * @return
   */
  public Class<?> getObjectType() {
    return DataSource.class;
  }

  /**
   * Is Singleton
   * 
   * @return
   */
  public boolean isSingleton() {
    return true;
  }

  /**
   * Factory method that returns the fully-initialized test data source. Useful when this class is
   * used programatically instead of deployed as a Spring bean.
   *
   * @return the data source
   */
  public DataSource getDataSource() {
    if (dataSource == null) {
      this.dataSource = createDataSource();
    }
    return dataSource;
  }

  /**
   * Create a valid datasource for testing
   * 
   * @return The datasource
   */
  private DataSource createDataSource() {
    DriverManagerDataSource newDataSource = new DriverManagerDataSource();
    newDataSource.setDriverClassName("org.h2.Driver");
    newDataSource.setUrl("jdbc:h2:mem:test;DB_CLOSE_DELAY=-1");
    newDataSource.setUsername("sa");
    newDataSource.setPassword("sa");

    try {
      GeoDB.InitGeoDB(newDataSource.getConnection());
    } catch (SQLException exception) {
      LOGGER.error("Failed to initialise Test GeoDB", exception);
    }

    return newDataSource;
  }
}
