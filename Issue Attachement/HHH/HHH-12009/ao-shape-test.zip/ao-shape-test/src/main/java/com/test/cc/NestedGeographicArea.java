package com.test.cc;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


@Entity
@Table(name = "NESTED_GEOGRAPHIC_AREA")
public class NestedGeographicArea {

  /** unique identifier */
  @Id
  @GeneratedValue
  private Long id;

  @ManyToOne
  @JoinColumn(name = "GEOGRAPHIC_AREA_ID")
  private GeographicArea parentGeographicArea;

  /** Associated shape */
  // uni-directional one-to-one association to ShapeEntity
  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "SHAPE_ID")
  private ShapeEntity shape;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public GeographicArea getParentGeographicArea() {
    return parentGeographicArea;
  }

  public void setParentGeographicArea(GeographicArea parentGeographicArea) {
    this.parentGeographicArea = parentGeographicArea;
  }

  /**
   * @return the shape
   */
  public ShapeEntity getShape() {
    return shape;
  }

  /**
   * @param shape the shape to set
   */
  public void setShape(ShapeEntity shape) {
    this.shape = shape;
    if (this.shape != null) {
      // this.shape.setPartition(null);
    }
  }

  /**
   * (non-Javadoc)
   * 
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj) {
    return EqualsBuilder.reflectionEquals(obj, this);
  }

  /**
   * (non-Javadoc)
   * 
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode() {
    return HashCodeBuilder.reflectionHashCode(this);
  }


  /**
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

}
