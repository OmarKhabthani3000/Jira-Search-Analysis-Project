package com.test.cc;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("POLYGON")
public class ShapePolygonEntity extends ShapeEntity {
  // polygon is stored in SHAPE
}
