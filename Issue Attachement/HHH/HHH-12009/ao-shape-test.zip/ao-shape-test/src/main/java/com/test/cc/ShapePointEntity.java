/**
 * Title: ShapePoint
 * 
 * Copyright (c) 2017 Thales UK Ltd, Throop Road, Templecombe, Somerset, BA8 0DH, UK
 * 
 * Company: Thales UK Ltd
 *
 * Safety Integrity Level: None
 * 
 * Classification: NOT PROTECTIVELY MARKED
 *
 * Security Enforcement Level: Security Irrelevant
 */
package com.test.cc;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("POINT")
public class ShapePointEntity extends ShapeEntity {

}
