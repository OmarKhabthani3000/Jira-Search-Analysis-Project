import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "OUTER_INNER")
public class OuterEntity implements Serializable {
    private OuterId id;
    private InnerId innerId;
    private InnerObjectId innerObjectId;

    @EmbeddedId
    @AttributeOverrides({
            @AttributeOverride(name = "value", column = @Column(name = "ID_VALUE", nullable = false))})
    public OuterId getId() {
        return id;
    }

    public void setId(OuterId id) {
        this.id = id;
    }

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "value", column = @Column(name = "INNER_ID_VALUE"))})
    public InnerId getInnerId() {
        return innerId;
    }

    public void setInnerId(InnerId innerId) {
        this.innerId = innerId;
    }
}
