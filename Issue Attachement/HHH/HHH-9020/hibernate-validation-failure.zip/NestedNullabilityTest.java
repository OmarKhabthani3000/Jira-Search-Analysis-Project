public class NestedNullabilityTest {

    @BeforeClass
    public static void setupDatabase() throws Exception {
        // issue DDL ...
    }

    @Test
    public void entityWithInner() throws Exception {
    // WORKS

        JPA jpa = // ... get JPA instance somehow

        OuterEntity entity = new OuterEntity();

        OuterId id = new OuterId();
        id.setValue(UUIDGenerator.generate());
        entity.setId(id);

        InnerId inner = new InnerId();
        inner.setValue("blabla");
        entity.setInnerId(inner);

        jpa.persist(entity);

        jpa.flush();
    }

    @Test
    public void entityWithoutInner() throws Exception {
    // FAILS
    
        JPA jpa = // ... get JPA instance somehow

        OuterEntity entity = new OuterEntity();

        OuterId id = new OuterId();
        id.setValue(UUIDGenerator.generate());
        entity.setId(id);

        jpa.persist(entity);

        jpa.flush();
    }
}
