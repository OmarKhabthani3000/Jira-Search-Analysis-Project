package ru.arptek.arpsite.data.manytoonelazy;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import ru.arptek.arpsite.data.DefaultSealedObject;

@Entity
public class BeanA extends DefaultSealedObject {
    private BeanB parent;

    @ManyToOne(fetch = FetchType.LAZY)
    public BeanB getParent() {
        return parent;
    }

    public void setParent(BeanB parent) {
        this.parent = parent;
    }
}
