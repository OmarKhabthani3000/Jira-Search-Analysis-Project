/*
 * Copyright 2001-2005 Fizteh-Center Lab., MIPT, Russia
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Created on 04.06.2005
 */
package ru.arptek.arpsite.data.manytoonelazy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.ejb.Ejb3Configuration;
import org.hibernate.proxy.HibernateProxy;

import ru.arptek.arpsite.data.AbstractHibernateJUnitTest;

public class TestWithoutCache extends AbstractHibernateJUnitTest {

    @Override
    protected void entityConfiguration(Ejb3Configuration cfg) {
        cfg.addAnnotatedClass(BeanA.class);
        cfg.addAnnotatedClass(BeanB.class);
    }

    public void testLoad() {
        SessionFactory sessionFactory = getSessionFactory();

        {
            Session session = sessionFactory.openSession();
            Transaction transaction = session.beginTransaction();

            BeanB beanB = new BeanB();
            beanB.setId(1);
            session.save(beanB);
            beanB = (BeanB) session.load(BeanB.class, 1);

            BeanA beanA = new BeanA();
            beanA.setId(2);
            beanA.setParent(beanB);
            session.save(beanA);

            transaction.commit();
            session.close();
        }

        {
            Session session = sessionFactory.openSession();
            Transaction transaction = session.beginTransaction();

            BeanB beanB = (BeanB) session.load(BeanB.class, 1);

            assertTrue(beanB instanceof HibernateProxy);
            assertTrue(((HibernateProxy) beanB).getHibernateLazyInitializer()
                    .isUninitialized());

            BeanA beanA = (BeanA) session.load(BeanA.class, 2);

            assertTrue(beanA instanceof HibernateProxy);
            assertTrue(((HibernateProxy) beanA).getHibernateLazyInitializer()
                    .isUninitialized());

            beanB = beanA.getParent();
            assertTrue(beanB instanceof HibernateProxy);
            assertTrue(((HibernateProxy) beanB).getHibernateLazyInitializer()
                    .isUninitialized());

            transaction.commit();
            session.close();
        }
    }

    public void testFind() {
        SessionFactory sessionFactory = getSessionFactory();

        {
            Session session = sessionFactory.openSession();
            Transaction transaction = session.beginTransaction();

            BeanB beanB = new BeanB();
            beanB.setId(1);
            session.save(beanB);
            beanB = (BeanB) session.load(BeanB.class, 1);

            BeanA beanA = new BeanA();
            beanA.setId(2);
            beanA.setParent(beanB);
            session.save(beanA);

            transaction.commit();
            session.close();
        }

        {
            Session session = sessionFactory.openSession();
            Transaction transaction = session.beginTransaction();

            org.hibernate.Query query = session.createQuery("SELECT a "
                    + "FROM ru.arptek.arpsite.data.manytoonelazy.BeanA a "
                    + "WHERE id=2");
            BeanA beanA = (BeanA) query.uniqueResult();

            BeanB beanB = beanA.getParent();
            assertTrue(beanB instanceof HibernateProxy);
            assertTrue(((HibernateProxy) beanB).getHibernateLazyInitializer()
                    .isUninitialized());

            transaction.commit();
            session.close();
        }
    }
}
