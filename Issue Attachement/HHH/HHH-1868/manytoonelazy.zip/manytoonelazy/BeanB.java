package ru.arptek.arpsite.data.manytoonelazy;

import javax.persistence.Entity;

import ru.arptek.arpsite.data.DefaultSealedObject;

@Entity
public class BeanB extends DefaultSealedObject {

}
