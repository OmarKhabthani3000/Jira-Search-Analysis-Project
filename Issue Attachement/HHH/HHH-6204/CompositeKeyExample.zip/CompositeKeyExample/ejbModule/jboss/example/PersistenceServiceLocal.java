package jboss.example;

import javax.ejb.Local;

@Local
public interface PersistenceServiceLocal extends PersistenceService {

}
