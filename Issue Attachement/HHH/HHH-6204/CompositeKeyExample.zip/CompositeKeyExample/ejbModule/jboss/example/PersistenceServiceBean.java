package jboss.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.ejb.Stateless;
import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

@Stateless(name="PersistenceService")
public class PersistenceServiceBean implements PersistenceServiceLocal,
		PersistenceServiceRemote {
	
	@PersistenceContext(unitName="MyPU")
	private EntityManager em;
	
	public void test(){
		Works w = em.find(Works.class, "XYZ");
		List<String> gn = w.getGlobalNotes();
		System.out.println(gn.toString());
		
//		DoesNotWorkPk dnwpk = new DoesNotWorkPk();
//		dnwpk.setId1("ZZZ");
//		dnwpk.setId2("00");
//		DoesNotWork dnw = em.find(DoesNotWork.class, dnwpk);
//		List<String> notes = dnw.getGlobalNotes();
//		if(notes != null && notes.size() > 0){
//			for(String s: notes){
//				System.out.println(s);
//			}
//		}
	}

	public void testStraightJDBC() throws SQLException {
		Connection con = null;
		Statement stmt = null;
		try{
			InitialContext ctx = new InitialContext();
			DataSource ds = (DataSource)ctx.lookup("java:/MyDS");
			con = ds.getConnection();
			stmt = con.createStatement();
//			stmt.execute("select count(*) from vgras029_v031");
			stmt.execute("select count(*) from vgras029_v03");
		}catch(Exception e){
			throw new SQLException(e);
		}finally{
			if(null != stmt){
				try{
					stmt.close();
				}catch(Exception stmte){
					stmte.printStackTrace();
				}
			}
			if(null != con){
				try{
					con.close();
				}catch(Exception sqle){
					sqle.printStackTrace();
				}
			}
		}
	}

}
