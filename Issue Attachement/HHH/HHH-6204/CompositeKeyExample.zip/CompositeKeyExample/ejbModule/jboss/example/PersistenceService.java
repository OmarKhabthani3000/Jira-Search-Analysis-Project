package jboss.example;

import java.sql.SQLException;

public interface PersistenceService {
	public void test();
	public void testStraightJDBC() throws SQLException;

}
