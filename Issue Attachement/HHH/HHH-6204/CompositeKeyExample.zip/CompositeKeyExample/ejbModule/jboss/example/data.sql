-- MySQL dump 10.13  Distrib 5.1.56, for redhat-linux-gnu (i386)
--
-- ------------------------------------------------------
-- Server version	5.1.56

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vgras001_v031`
--

DROP TABLE IF EXISTS `vgras001_v031`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vgras001_v031` (
  `prod_no` varchar(14) NOT NULL,
  `glob_addit_info_tid` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vgras001_v031`
--

LOCK TABLES `vgras001_v031` WRITE;
/*!40000 ALTER TABLE `vgras001_v031` DISABLE KEYS */;
INSERT INTO `vgras001_v031` VALUES ('XYZ',1);
/*!40000 ALTER TABLE `vgras001_v031` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vgras007_v031`
--

DROP TABLE IF EXISTS `vgras007_v031`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vgras007_v031` (
  `track_no` varchar(17) NOT NULL,
  `track_ext` char(2) NOT NULL,
  `production_credits_tid` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vgras007_v031`
--

LOCK TABLES `vgras007_v031` WRITE;
/*!40000 ALTER TABLE `vgras007_v031` DISABLE KEYS */;
INSERT INTO `vgras007_v031` VALUES ('ZZZ','00',1);
/*!40000 ALTER TABLE `vgras007_v031` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vgras029_v031`
--

DROP TABLE IF EXISTS `vgras029_v031`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vgras029_v031` (
  `text_id` int(11) NOT NULL,
  `seq_no` smallint(6) NOT NULL,
  `text_part` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vgras029_v031`
--

LOCK TABLES `vgras029_v031` WRITE;
/*!40000 ALTER TABLE `vgras029_v031` DISABLE KEYS */;
INSERT INTO `vgras029_v031` VALUES (1,1,'Foo Foo Foo'),(1,2,'Bar Bar Bar');
/*!40000 ALTER TABLE `vgras029_v031` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-05-02 17:46:41
