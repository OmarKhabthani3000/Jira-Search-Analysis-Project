package jboss.example;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Table;

import org.hibernate.annotations.CollectionOfElements;
import org.hibernate.annotations.IndexColumn;

@Entity
@Table(name = "vgras001_v031")
public class Works implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "prod_no")
  private String worksId;

  @Column(name = "glob_addit_info_tid", insertable=false, updatable=false)
  private Long globalAdditionalInfoTId;

  @CollectionOfElements
  @JoinTable(
		  name="vgras029_v031",
		  joinColumns=@JoinColumn(name="text_id", referencedColumnName="glob_addit_info_tid"))
  @Column(name = "text_part", insertable=false, updatable=false)
  @IndexColumn(name = "seq_no", base=1)
  private List<String> globalNotes = new ArrayList<String>();

  public String getWorksId() {
    return worksId;
  }

  public void setWorksId(String worksId) {
    this.worksId = worksId;
  }

  public List<String> getGlobalNotes() {
    return globalNotes;
  }

  public void setGlobalNotes(List<String> globalNotes) {
    this.globalNotes = globalNotes;
  }

  public Long getGlobalAdditionalInfoTId() {
    return globalAdditionalInfoTId;
  }

  public void setGlobalAdditionalInfoTId(Long globalAdditionalInfoTId) {
    this.globalAdditionalInfoTId = globalAdditionalInfoTId;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((worksId == null) ? 0 : worksId.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (!(obj instanceof Works))
      return false;
    Works other = (Works) obj;
    if (worksId == null) {
      if (other.worksId != null)
        return false;
    } else if (!worksId.equals(other.worksId))
      return false;
    return true;
  }

}
