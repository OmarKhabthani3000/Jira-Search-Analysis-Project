package jboss.example;

import javax.ejb.Remote;

@Remote
public interface PersistenceServiceRemote extends PersistenceService {

}
