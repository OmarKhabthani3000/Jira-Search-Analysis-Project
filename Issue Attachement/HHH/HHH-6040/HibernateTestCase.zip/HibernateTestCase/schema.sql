create table TestEntity (id number(19,0) not null, primary key (id));
create sequence SEQ_ID;
