package com.example.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public abstract class TestEntity {

	@GeneratedValue(generator = "seq_id")
    @SequenceGenerator(name = "seq_id", sequenceName = "SEQ_ID", initialValue = 1000, allocationSize = 100)
	@Id
	private Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
