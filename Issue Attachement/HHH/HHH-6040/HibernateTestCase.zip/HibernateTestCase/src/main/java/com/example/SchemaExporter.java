package com.example;

import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class SchemaExporter {

	public static void main(String... args) {
		Configuration configuration = new Configuration();
		configuration.configure();
		SchemaExport schemaExport = new SchemaExport(configuration);
		schemaExport.setOutputFile("schema.sql");
		schemaExport.setDelimiter(";");
		schemaExport.execute(true, false, false, true);
	}
}
