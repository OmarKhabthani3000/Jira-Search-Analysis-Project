package org.hibernate.mapping;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Transient;
import javax.persistence.Version;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicUpdate
public class VersionedParent {
    private Integer id;
    private Long version;
    private Set<UnversionedMappingVersionedParent> children;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="Id", nullable=false)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        if (!Objects.equals(id, getId())) {
            this.id = id;

            getChildren().forEach(c -> {
                if (c.getId() == null) {
                    c.setId(new MappingId());
                }
                c.getId().setParentId(id);
            });
        }
    }

    @Version
    @Column(name="Version", nullable=false)
    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    @OneToMany(mappedBy="parent", cascade={ javax.persistence.CascadeType.DETACH, javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.REFRESH, javax.persistence.CascadeType.REMOVE }, orphanRemoval=true)
    @Cascade({ org.hibernate.annotations.CascadeType.DELETE, org.hibernate.annotations.CascadeType.LOCK, org.hibernate.annotations.CascadeType.REPLICATE })
    protected Set<UnversionedMappingVersionedParent> getChildren() {
        if (children == null) {
            children = new HashSet<>();
        }
        return this.children;
    }

    protected void setChildren(Set<UnversionedMappingVersionedParent> value) {
        if (value == null && this.children != null) {
            this.children.clear();
        } else {
            this.children = value;
        }
    }

    @Transient
    public Collection<UnversionedMappingVersionedParent> getChildrenCollection() {
        return new ArrayList<>(getChildren());
    }

    public void addChild(UnversionedMappingVersionedParent addValue) {
        if (addValue != null && !this.getChildren().contains(addValue)) {
            this.children.add(addValue);
            addValue.addParent(this);
        }
    }

    public void removeChild(UnversionedMappingVersionedParent removeValue) {
        if (this.children != null && this.children.contains(removeValue)) {
            this.children.remove(removeValue);
            removeValue.removeParent();
        }
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof VersionedParent)) {
            return false;
        }
        VersionedParent other = (VersionedParent) obj;
        return Objects.equals(getId(), other.getId());
    }
}
