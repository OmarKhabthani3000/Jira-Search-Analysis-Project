package org.hibernate.mapping;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class MappingId implements Serializable {
    private static final long serialVersionUID = -4896032953810358940L;

    private Integer parentId;
    private Integer childId;

    @Column(name="ParentId", nullable=false)
    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    @Column(name="ChildId", nullable=false)
    public Integer getChildId() {
        return childId;
    }

    public void setChildId(Integer childId) {
        this.childId = childId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getParentId(), getChildId());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MappingId)) {
            return false;
        }
        MappingId other = (MappingId) obj;
        return Objects.equals(getParentId(), other.getParentId()) && Objects.equals(getChildId(), other.getChildId());
    }

    @Override
    public String toString() {
        return "[" + getParentId() + " | " + getChildId() + "]";
    }
}
