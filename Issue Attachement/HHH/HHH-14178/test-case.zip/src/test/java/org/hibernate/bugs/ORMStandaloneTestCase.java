package org.hibernate.bugs;

import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.mapping.Child;
import org.hibernate.mapping.MappingId;
import org.hibernate.mapping.UnversionedMappingUnversionedParent;
import org.hibernate.mapping.UnversionedMappingVersionedParent;
import org.hibernate.mapping.UnversionedParent;
import org.hibernate.mapping.VersionedMappingUnversionedParent;
import org.hibernate.mapping.VersionedParent;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a standalone test case for Hibernate ORM.  Although this is perfectly
 * acceptable as a reproducer, usage of ORMUnitTestCase is preferred!
 */
public class ORMStandaloneTestCase {
    private SessionFactory sf;

    private VersionedParent vp;
    private Child c1, c2, c3;
    private UnversionedParent up;
    private UnversionedMappingVersionedParent umpvp1;
    private UnversionedMappingUnversionedParent umup2;
    private VersionedMappingUnversionedParent vmup3;

    @Before
    public void setup() {
        StandardServiceRegistryBuilder srb = new StandardServiceRegistryBuilder();

        Metadata metadata = new MetadataSources(srb.build())
                .addAnnotatedClass(VersionedParent.class)
                .addAnnotatedClass(UnversionedParent.class)
                .addAnnotatedClass(Child.class)
                .addAnnotatedClass(UnversionedMappingVersionedParent.class)
                .addAnnotatedClass(UnversionedMappingUnversionedParent.class)
                .addAnnotatedClass(VersionedMappingUnversionedParent.class)
                .addAnnotatedClass(MappingId.class)
                .buildMetadata();

        sf = metadata.buildSessionFactory();

        // Create versioned parent and add a mapping for parent-child
        vp = new VersionedParent();

        // Create mapping for versioned parent (do not associate to parent just yet)
        c1 = new Child();
        umpvp1 = new UnversionedMappingVersionedParent();
        umpvp1.addChild(c1);

        // Create unversioned parent
        up = new UnversionedParent();

        // Create the same relation as above but this time parent has no version attribute (do not associate to parent just yet)
        c2 = new Child();
        umup2 = new UnversionedMappingUnversionedParent();
        umup2.addChild(c2);

        // And finally, do a third mapping where this time the mapping itself has a version attribute
        c3 = new Child();
        vmup3 = new VersionedMappingUnversionedParent();
        vmup3.addChild(c3);
    }

    @After
    public void cleanup() {
        try (Session s = sf.openSession()) {
            s.setHibernateFlushMode(FlushMode.MANUAL);

            Transaction trx = s.beginTransaction();
            try {
                if (up.getId() != null) {
                    s.delete(up);
                }
                if (vp.getId() != null) {
                    s.delete(vp);
                }
                if (c1.getId() != null) {
                    s.delete(c1);
                }
                if (c2.getId() != null) {
                    s.delete(c2);
                }
                if (c3.getId() != null) {
                    s.delete(c3);
                }

                s.flush();
                trx.commit();
            } catch (RuntimeException e) {
                if (trx.isActive()) {
                    trx.rollback();
                }
                throw e;
            }
        }
    }

    @Test
    public void UnversionedMappingVersionedParentSaveUpdate() throws Exception {
        try (Session s = sf.openSession()) {
            s.setHibernateFlushMode(FlushMode.MANUAL);

            Transaction trx = s.beginTransaction();
            try {
                // Associate the mapping to parent
                vp.addChild(umpvp1);

                // Persist Child associated with versioned parent
                s.saveOrUpdate(c1);
                Assert.assertNotEquals(Integer.valueOf(0), c1.getId());

                // Persist VersionParent. This assigns the ID to the parent but not to the mapping because saveUpdate cascade is not enabled
                s.saveOrUpdate(vp);
                Assert.assertNotEquals(Integer.valueOf(0), vp.getId());

                // Persist mapping now that parent id is generated, up until now everything works as expected
                s.saveOrUpdate(umpvp1);
                Assert.assertNotNull(umpvp1.getId());
                Assert.assertNotEquals(Integer.valueOf(0), umpvp1.getId().getParentId());
                Assert.assertNotEquals(Integer.valueOf(0), umpvp1.getId().getChildId());

                s.flush();
                trx.commit();
            } catch (RuntimeException e) {
                // Transaction is rolled back so we do not want delete code in cleanup to execute.
                // Reset any possible ID assignments
                vp.setId(null);
                c1.setId(null);

                if (trx.isActive()) {
                    trx.rollback();
                }
                throw e;
            }
        }
    }

    @Test
    public void UnversionedMappingUnversionedParentSaveUpdate() throws Exception {
        try (Session s = sf.openSession()) {
            s.setHibernateFlushMode(FlushMode.MANUAL);

            Transaction trx = s.beginTransaction();
            try {
                // Associate the mapping to parent
                up.addUnversionedMappings(umup2);

                // Persist child associated with unversionned mapping of unversioned parent
                s.saveOrUpdate(c2);
                Assert.assertNotEquals(Integer.valueOf(0), c2.getId());

                // Persist Unversioned Parent. This should assign the ID to the parent just like in the case above but in reality it fails with assertion that vpc1 is transient in delete orphan detection code
                s.saveOrUpdate(up);
                Assert.assertNotEquals(Integer.valueOf(0), up.getId());

                // Persist Unversionned Mapping now that parent id is generated, all works just like in the case of versioned parent
                s.saveOrUpdate(umup2);
                Assert.assertNotNull(umup2.getId());
                Assert.assertNotEquals(Integer.valueOf(0), umup2.getId().getParentId());
                Assert.assertNotEquals(Integer.valueOf(0), umup2.getId().getChildId());

                s.flush();
                trx.commit();
            } catch (RuntimeException e) {
                // Transaction is rolled back so we do not want delete code in cleanup to execute.
                // Reset any possible ID assignments
                up.setId(null);
                c2.setId(null);

                if (trx.isActive()) {
                    trx.rollback();
                }
                throw e;
            }
        }
    }

    @Test
    public void VersionedMappingUnversionedParentSaveUpdate() throws Exception {
        try (Session s = sf.openSession()) {
            s.setHibernateFlushMode(FlushMode.MANUAL);

            Transaction trx = s.beginTransaction();
            try {
                // Associate the mapping to parent
                up.addVersionedMappings(vmup3);

                // Persist child associated with versioned mapping of unversioned parent
                s.saveOrUpdate(c3);
                Assert.assertNotEquals(Integer.valueOf(0), c3.getId());

                // Persist Unversioned Parent. This should assign the ID to the parent just like in the two cases above but in reality it fails with assertion that vmup3 is transient in delete orphan detection code
                s.saveOrUpdate(up);
                Assert.assertNotEquals(Integer.valueOf(0), up.getId());

                // Persist Versioned Mapping, the code never reaches here as it throws an exception in the previous line
                s.saveOrUpdate(vmup3);
                Assert.assertNotNull(vmup3.getId());
                Assert.assertNotEquals(Integer.valueOf(0), vmup3.getId().getParentId());
                Assert.assertNotEquals(Integer.valueOf(0), vmup3.getId().getChildId());

                s.flush();
                trx.commit();
            } catch (RuntimeException e) {
                // Transaction is rolled back so we do not want delete code in cleanup to execute.
                // Reset any possible ID assignments
                up.setId(null);
                c3.setId(null);

                if (trx.isActive()) {
                    trx.rollback();
                }
                throw e;
            }
        }
    }

    @Test
    public void VersionedMappingUnversionedParentPersist() throws Exception {
        try (Session s = sf.openSession()) {
            s.setHibernateFlushMode(FlushMode.MANUAL);

            Transaction trx = s.beginTransaction();
            try {
                // Associate the mapping to parent
                up.addVersionedMappings(vmup3);

                // Persist child associated with versioned mapping of unversioned parent
                s.persist(c3);
                Assert.assertNotEquals(Integer.valueOf(0), c3.getId());

                // Persist Unversioned Parent. This is exactly the same as previous test but uses persist rather than saveUpdate. Everything works as expected (like first two test cases)
                s.persist(up);
                Assert.assertNotEquals(Integer.valueOf(0), up.getId());

                // Persist Versionned Mapping now that parent id is generated, all works just like in the case of unversioned mapping and versionned parent
                s.persist(vmup3);
                Assert.assertNotNull(vmup3.getId());
                Assert.assertNotEquals(Integer.valueOf(0), vmup3.getId().getParentId());
                Assert.assertNotEquals(Integer.valueOf(0), vmup3.getId().getChildId());

                s.flush();
                trx.commit();
            } catch (RuntimeException e) {
                // Transaction is rolled back so we do not want delete code in cleanup to execute.
                // Reset any possible ID assignments
                up.setId(null);
                c3.setId(null);

                if (trx.isActive()) {
                    trx.rollback();
                }
                throw e;
            }
        }
    }
}
