package org.hibernate.mapping;

import java.util.Objects;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;

import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicUpdate
public class UnversionedMappingUnversionedParent {
    private MappingId id;
    private Child child;

    @EmbeddedId
    public MappingId getId() {
        return this.id;
    }

    public void setId(MappingId id) {
        this.id = id;
    }

    protected UnversionedParent parent;

    @ManyToOne(optional=false, fetch=FetchType.LAZY)
    @MapsId("parentId")
    @JoinColumn(name="ParentId", nullable=false)
    public UnversionedParent getParent() {
        return this.parent;
    }

    protected void setParent(UnversionedParent value) {
        this.parent = value;
    }

    public void addParent(UnversionedParent value) {
        UnversionedParent oldParent = getParent();
        if (!Objects.equals(value, oldParent)) {
            if (oldParent != null) {
                setParent(null);
                oldParent.removeUnversionedMappings(this);
            }

            if (value != null) {
                setParent(value);
                if (getId() == null) {
                    setId(new MappingId());
                }
                getId().setParentId(value.getId());
                value.addUnversionedMappings(this);
            }
        }
    }

    public void removeParent() {
        addParent(null);
    }

    @ManyToOne(optional=false, fetch=FetchType.LAZY)
    @MapsId("childId")
    @JoinColumn(name="ChildId", nullable=false)
    public Child getChild() {
        return child;
    }

    protected void setChild(Child child) {
        this.child = child;
    }

    public void addChild(Child value) {
        Child oldChild = getChild();
        if (!Objects.equals(value, oldChild)) {
            if (oldChild != null) {
                setChild(null);
            }

            if (value != null) {
                setChild(value);
                if (getId() == null) {
                    setId(new MappingId());
                }
                getId().setChildId(value.getId());
            }
        }
    }

    public void removeChild() {
        addChild(null);
    }

    @Override
    public int hashCode() {
        return 17;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof UnversionedMappingUnversionedParent)) {
            return false;
        }
        UnversionedMappingUnversionedParent other = (UnversionedMappingUnversionedParent) obj;
        return Objects.equals(getId(), other.getId());
    }
}
