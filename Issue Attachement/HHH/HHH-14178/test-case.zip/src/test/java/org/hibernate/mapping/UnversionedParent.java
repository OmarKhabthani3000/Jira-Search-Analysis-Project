package org.hibernate.mapping;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Transient;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicUpdate
public class UnversionedParent {
    private Integer id;
    private Set<UnversionedMappingUnversionedParent> unversionedMappings;
    private Set<VersionedMappingUnversionedParent> versionedMappings;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="Id", nullable=false)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        if (!Objects.equals(id, getId())) {
            this.id = id;

            getUnversionedMappings().forEach(c -> {
                if (c.getId() == null) {
                    c.setId(new MappingId());
                }
                c.getId().setParentId(id);
            });
        }
    }

    @OneToMany(mappedBy="parent", cascade={ javax.persistence.CascadeType.DETACH, javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.REFRESH, javax.persistence.CascadeType.REMOVE }, orphanRemoval=true)
    @Cascade({ org.hibernate.annotations.CascadeType.DELETE, org.hibernate.annotations.CascadeType.LOCK, org.hibernate.annotations.CascadeType.REPLICATE })
    protected Set<UnversionedMappingUnversionedParent> getUnversionedMappings() {
        if (unversionedMappings == null) {
            unversionedMappings = new HashSet<>();
        }
        return this.unversionedMappings;
    }

    protected void setUnversionedMappings(Set<UnversionedMappingUnversionedParent> value) {
        if (value == null && this.unversionedMappings != null) {
            this.unversionedMappings.clear();
        } else {
            this.unversionedMappings = value;
        }
    }

    @Transient
    public Collection<UnversionedMappingUnversionedParent> getUnversionedMappingsCollection() {
        return new ArrayList<>(getUnversionedMappings());
    }

    public void addUnversionedMappings(UnversionedMappingUnversionedParent addValue) {
        if (addValue != null && !this.getUnversionedMappings().contains(addValue)) {
            this.unversionedMappings.add(addValue);
            addValue.addParent(this);
        }
    }

    public void removeUnversionedMappings(UnversionedMappingUnversionedParent removeValue) {
        if (this.unversionedMappings != null && this.unversionedMappings.contains(removeValue)) {
            this.unversionedMappings.remove(removeValue);
            removeValue.removeParent();
        }
    }

    @OneToMany(mappedBy="parent", cascade={ javax.persistence.CascadeType.DETACH, javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.REFRESH, javax.persistence.CascadeType.REMOVE }, orphanRemoval=true)
    @Cascade({ org.hibernate.annotations.CascadeType.DELETE, org.hibernate.annotations.CascadeType.LOCK, org.hibernate.annotations.CascadeType.REPLICATE })
    protected Set<VersionedMappingUnversionedParent> getVersionedMappings() {
        if (versionedMappings == null) {
            versionedMappings = new HashSet<>();
        }
        return this.versionedMappings;
    }

    protected void setVersionedMappings(Set<VersionedMappingUnversionedParent> value) {
        if (value == null && this.versionedMappings != null) {
            this.versionedMappings.clear();
        } else {
            this.versionedMappings = value;
        }
    }

    @Transient
    public Collection<VersionedMappingUnversionedParent> getVersionedMappingsCollection() {
        return new ArrayList<>(getVersionedMappings());
    }

    public void addVersionedMappings(VersionedMappingUnversionedParent addValue) {
        if (addValue != null && !this.getVersionedMappings().contains(addValue)) {
            this.versionedMappings.add(addValue);
            addValue.addParent(this);
        }
    }

    public void removeVersionedMappings(VersionedMappingUnversionedParent removeValue) {
        if (this.versionedMappings != null && this.versionedMappings.contains(removeValue)) {
            this.versionedMappings.remove(removeValue);
            removeValue.removeParent();
        }
    }

    @Override
    public int hashCode() {
        return 17;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof UnversionedParent)) {
            return false;
        }
        UnversionedParent other = (UnversionedParent) obj;
        return Objects.equals(getId(), other.getId());
    }
}
