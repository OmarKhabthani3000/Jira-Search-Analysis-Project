package org.beginningee6.tutorial;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.util.List;
import java.util.ArrayList;

/**
 * @author Antonio Goncalves & Alexis Moussine-Pouchkine
 *         Tutorial - Beginning with The Java EE 6 Platform
 *         http://www.antoniogoncalves.org
 *         http://blogs.sun.com/alexismp
 *         --
 *         Main class creating a Book and querying the database
 */
public class Main {

    // ======================================
    // =             Entry point            =
    // ======================================

    public static void main(String[] args) {

        // Creates an instance of book
        Book book = new Book();
        book.setTitle("The Hitchhiker's Guide to the Galaxy");
        book.setPrice(12.5F);
        book.setDescription("Science fiction comedy series created by Douglas Adams.");
        book.setIsbn("1-84023-742-2");
        book.setNbOfPage(354);
        book.setIllustrations(false);
        List<String> tags = new ArrayList<String>();
        tags.add("scifi");
        tags.add("french");
        book.setTags(tags);

        // Gets an entity manager and a transaction
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("tutorialPU");
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();

        // Persists the book to the database
        tx.begin();
        em.persist(book);
        tx.commit();

        // Displays the books
        System.out.println("====== All books");
        List<Book> books = em.createNamedQuery("findAllBooks").getResultList();
        for (Book b : books ) {
            System.out.println("==> " + b);
        }

        System.out.println("\n====== All Scifi books");
        books = em.createNamedQuery("findAllScifiBooks").getResultList();
        for (Book b : books ) {
            System.out.println("==> " + b);
        }

        em.close();
        emf.close();
    }
}