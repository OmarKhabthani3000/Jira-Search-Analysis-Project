package org.beginningee6.tutorial;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

/**
 * @author Antonio Goncalves & Alexis Moussine-Pouchkine
 *         Tutorial - Beginning with The Java EE 6 Platform
 *         http://www.antoniogoncalves.org
 *         http://blogs.sun.com/alexismp
 *         --
 */
public class BookTest {

    // ======================================
    // =             Attributes             =
    // ======================================
    private static EntityManagerFactory emf;
    private static EntityManager em;
    private static EntityTransaction tx;

    // ======================================
    // =          Lifecycle Methods         =
    // ======================================

    @BeforeClass
    public static void initEntityManager() throws Exception {
        emf = Persistence.createEntityManagerFactory("tutorialPU");
        em = emf.createEntityManager();
    }

    @AfterClass
    public static void closeEntityManager() throws SQLException {
        if (em != null) em.close();
        if (emf != null) emf.close();
    }

    @Before
    public void initTransaction() {
        tx = em.getTransaction();
    }

    // ======================================
    // =              Unit tests            =
    // ======================================

    @Test
    public void shouldCreateABook() throws Exception {

        // Retrieves all the books from the database
        int nbOfBook = em.createNamedQuery("findAllBooks").getResultList().size();

        // Creates an instance of book
        Book book = new Book();
        book.setTitle("The Hitchhiker's Guide to the Galaxy");
        book.setPrice(12.5F);
        book.setDescription("Science fiction comedy book");
        book.setIsbn("1-84023-742-2");
        book.setNbOfPage(354);
        book.setIllustrations(false);
        List<String> tags = new ArrayList<String>();
        tags.add("scifi");
        tags.add("fun");
        book.setTags(tags);

        // Persists the book to the database
        tx.begin();
        em.persist(book);
        tx.commit();
        assertNotNull("ID should not be null", book.getId());

        // Finds the book
        tx.begin();
        book = em.find(Book.class, book.getId());
        tx.commit();
        assertEquals("Title should not be The Hitchhiker's Guide to the Galaxy", "The Hitchhiker's Guide to the Galaxy", book.getTitle());
        assertEquals("Tags should be scifi, fun", "scifi, fun", book.getTagsAsString());

        // Retrieves all the books from the database and checks there's one extra
        assertEquals("Should have an extra book", nbOfBook + 1, em.createNamedQuery("findAllBooks").getResultList().size());

        // Removes the book from the database
        tx.begin();
        em.remove(book);
        tx.commit();

        // Finds the book
        tx.begin();
        book = em.find(Book.class, book.getId());
        tx.commit();
        assertNull("The book should not have been found", book);

        // Retrieves all the books from the database and checks there's one less
        assertEquals("Should have a book less", nbOfBook, em.createNamedQuery("findAllBooks").getResultList().size());
    }

    @Test
    public void shouldFindScifiBooks() throws Exception {

        // Retrieves all the books from the database
        int nbOfBook = em.createNamedQuery("findAllBooks").getResultList().size();
        int nbOfScifiBook = em.createNamedQuery("findAllScifiBooks").getResultList().size();

        // Creates an instance of a scifi book
        Book book = new Book();
        book.setTitle("The Hitchhiker's Guide to the Galaxy");
        book.setPrice(12.5F);
        book.setDescription("Science fiction comedy book");
        book.setIsbn("1-84023-742-2");
        book.setNbOfPage(354);
        book.setIllustrations(false);
        List<String> tags = new ArrayList<String>();
        tags.add("scifi");
        tags.add("fun");
        book.setTags(tags);

        // Persists the book to the database
        tx.begin();
        em.persist(book);
        tx.commit();
        assertNotNull("ID should not be null", book.getId());

        // Retrieves all the books from the database and checks there's one extra
        assertEquals("Should have an extra book", nbOfBook + 1, em.createNamedQuery("findAllBooks").getResultList().size());
        assertEquals("Should have an extra book", nbOfScifiBook + 1, em.createNamedQuery("findAllScifiBooks").getResultList().size());

        // Creates an instance of book
        book = new Book();
        book.setTitle("Java EE 6");
        book.setPrice(22.5F);
        book.setDescription("Great java ee book");
        book.setIsbn("1-64021-752-2");
        book.setNbOfPage(474);
        book.setIllustrations(true);
        tags = new ArrayList<String>();
        tags.add("java");
        tags.add("good");
        book.setTags(tags);

        // Persists the book to the database
        tx.begin();
        em.persist(book);
        tx.commit();
        assertNotNull("ID should not be null", book.getId());

        // Retrieves all the books from the database and checks there's one extra
        assertEquals("Should have an extra book", nbOfBook + 2, em.createNamedQuery("findAllBooks").getResultList().size());
        assertEquals("Should have an extra book", nbOfScifiBook + 1, em.createNamedQuery("findAllScifiBooks").getResultList().size());

        // Creates an other instance of a scifi book
        book = new Book();
        book.setTitle("Dune");
        book.setPrice(42.5F);
        book.setDescription("Roots of scifi book");
        book.setIsbn("1-004023-71-9");
        book.setNbOfPage(784);
        book.setIllustrations(false);
        tags = new ArrayList<String>();
        tags.add("scifi");
        tags.add("dense");
        book.setTags(tags);

        // Persists the book to the database
        tx.begin();
        em.persist(book);
        tx.commit();
        assertNotNull("ID should not be null", book.getId());

        // Retrieves all the books from the database and checks there's one extra
        assertEquals("Should have an extra book", nbOfBook + 3, em.createNamedQuery("findAllBooks").getResultList().size());
        assertEquals("Should have an extra book", nbOfScifiBook + 2, em.createNamedQuery("findAllScifiBooks").getResultList().size());

    }
}
