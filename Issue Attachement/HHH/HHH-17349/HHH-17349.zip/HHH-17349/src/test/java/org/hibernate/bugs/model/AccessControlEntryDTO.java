package org.hibernate.bugs.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Access_Control_Entries")
public class AccessControlEntryDTO
    implements Serializable
{
    /** */
    private static final long serialVersionUID = -4471769440258847713L;

    /** */
    @Id
    @GeneratedValue
    @Column(name = "id")
    private Integer pk;

    /** */
    @Column(name = "name", length = 256, nullable = false)
    private String name;

    /** */
    @ManyToOne
    @JoinColumn(name = "parent")
    private AccessControlEntryDTO parent;

    public Integer getPk()
    {
        return pk;
    }

    public void setPk(final Integer pk)
    {
        this.pk = pk;
    }

    public String getName()
    {
        return name;
    }

    public void setName(final String name)
    {
        this.name = name;
    }

    public AccessControlEntryDTO getParent()
    {
        return parent;
    }

    public void setParent(final AccessControlEntryDTO parent)
    {
        this.parent = parent;
    }
}
