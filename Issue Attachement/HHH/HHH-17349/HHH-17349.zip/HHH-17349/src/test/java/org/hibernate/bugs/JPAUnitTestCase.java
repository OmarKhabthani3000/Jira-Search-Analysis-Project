package org.hibernate.bugs;

import org.hibernate.bugs.model.AccessControlEntryDTO;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh17283Test() throws Exception {
		final EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

        final TypedQuery<AccessControlEntryDTO> query = entityManager.createQuery("" +
                "SELECT outer_AccessControlEntryDTO " +
                "FROM " + AccessControlEntryDTO.class.getName() + " AS outer_AccessControlEntryDTO " +
                "WHERE outer_AccessControlEntryDTO.pk IN ( " +
                "  WITH ace_tree AS" +
                "  (" +
                "    SELECT a.pk as pk, a.parent.pk as parent" +
                "    FROM " + AccessControlEntryDTO.class.getName() + " a " +
                "    WHERE a.pk = 1 " +
                "    UNION ALL " +
                "    SELECT c.pk, c.parent " +
                "    FROM ace_tree p " +
                "      INNER JOIN " + AccessControlEntryDTO.class.getName() + " c on (p.pk = c.parent.pk) " +
                "  )" +
                "  SELECT DISTINCT pk " +
                "  FROM ace_tree " +
                ") ",
                AccessControlEntryDTO.class
        );

        query.getResultList();

		entityManager.getTransaction().commit();
		entityManager.close();
	}

    // Entities are auto-discovered, so just add them anywhere on class-path
    // Add your tests, using standard JUnit.
    @Test
    public void hhh17283SuccessTest() throws Exception {
        final EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        final TypedQuery<AccessControlEntryDTO> query = entityManager.createQuery("" +
                "  WITH ace_tree AS" +
                "  (" +
                "    SELECT a.pk as pk, a.parent.pk as parent" +
                "    FROM " + AccessControlEntryDTO.class.getName() + " a " +
                "    WHERE a.pk = 1 " +
                "    UNION ALL " +
                "    SELECT c.pk, c.parent " +
                "    FROM ace_tree p " +
                "      INNER JOIN " + AccessControlEntryDTO.class.getName() + " c on (p.pk = c.parent.pk) " +
                "  )" +
                "  SELECT DISTINCT pk " +
                "  FROM ace_tree ",
                AccessControlEntryDTO.class
        );

        query.getResultList();

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
