package notWorking;


import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class User {
	
	@Id 
    @SequenceGenerator(name = "user", sequenceName = "user_id") 
    @GeneratedValue(generator = "user")  
    private int id; 
	
	private String name;
	
	@OneToMany(mappedBy = "user")
    private List<ExcludedGroupUser> excludedUsers;

    @OneToMany(mappedBy = "user")
    private List<IncludedGroupUser> includedUsers;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<ExcludedGroupUser> getExcludedUsers() {
		return excludedUsers;
	}

	public void setExcludedUsers(List<ExcludedGroupUser> excludedUsers) {
		this.excludedUsers = excludedUsers;
	}

	public List<IncludedGroupUser> getIncludedUsers() {
		return includedUsers;
	}

	public void setIncludedUsers(List<IncludedGroupUser> includedUsers) {
		this.includedUsers = includedUsers;
	}
	
}
