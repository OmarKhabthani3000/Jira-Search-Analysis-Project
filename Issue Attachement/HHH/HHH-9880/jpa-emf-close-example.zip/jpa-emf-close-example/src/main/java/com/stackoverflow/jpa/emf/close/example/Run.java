package com.stackoverflow.jpa.emf.close.example;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

public class Run {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(null);
        EntityManager em = emf.createEntityManager();

        // 
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<MyEntity> query = cb.createQuery(MyEntity.class);
        List<MyEntity> resultList = em.createQuery(query.select(query.from(MyEntity.class))).getResultList();
        //
        
        System.out.println(resultList);
        em.close();
        emf.close(); // Here the exception is raised!
    }
}
