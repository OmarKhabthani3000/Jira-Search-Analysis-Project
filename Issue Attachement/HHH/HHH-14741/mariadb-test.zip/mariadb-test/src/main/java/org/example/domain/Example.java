package org.example.domain;

import javax.persistence.*;

@Entity
public class Example {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public long id;

	@Column(columnDefinition = "TINYINT")
	public Integer foo;
}
