This Spring Boot `3.0.6` project uses Hibernate `6.1.7.Final`.

The project contains just two entities: `Entity1` and `Entity2`. 
There is `@ManyToMany` relationship between these two entities via `relatedEntities2` attribute of `Entity1`. 

Run the test `findAllByEntity2NaturalId()` in `Entity1RepositoryTest`.

Inspect the last SELECT statement that is logged by `findAllByEntity2NaturalId()`.

```
    select
        e1_0.id 
    from
        entity_1 e1_0 
    join
        (join_table r1_0 
    join
        entity_2 r1_1 
            on r1_1.id=r1_0.entity_2_id) 
                on e1_0.id=r1_0.entity_1_id 
        where
            r1_1.natural_id=?
```

The many-to-many relationship via `join_table` is translated into two joins, where one is nested into the other one. 
```
    join
        (join_table r1_0 
            join
                entity_2 r1_1 
                    on r1_1.id=r1_0.entity_2_id) 
            on e1_0.id=r1_0.entity_1_id 
```

When using Hibernate `5.6.15.Final`, the structure of the JOIN's is different. The joins are "cascading":

```
    inner join
        join_table relatedent1_ 
            on entity1x0_.id=relatedent1_.entity_1_id 
    inner join
        entity_2 entity2x2_ 
            on relatedent1_.entity_2_id=entity2x2_.id 
```

Tested both types of queries on different tables and databases. The results were the same.
However, the execution plans are different. For nested joins, the performance is (much) worse 
for tables with large number of records.