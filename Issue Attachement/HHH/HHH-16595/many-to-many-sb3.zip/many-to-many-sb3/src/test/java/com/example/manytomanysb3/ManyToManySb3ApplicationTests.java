package com.example.manytomanysb3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManyToManySb3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
