package com.example.manytomanysb3.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "entity_1")
public class Entity1 {
    @Id
    private Long id;

    @ManyToMany
    @JoinTable(name = "join_table",
            joinColumns = @JoinColumn(name = "entity_1_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "entity_2_id", referencedColumnName = "id"))
    private Set<Entity2> relatedEntities2;
}
