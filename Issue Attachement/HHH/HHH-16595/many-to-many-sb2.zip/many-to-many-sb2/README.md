This Spring Boot `2.7.11` project uses Hibernate `5.6.15.Final`.

The project contains just two entities: `Entity1` and `Entity2`. 
There is `@ManyToMany` relationship between these two entities via `relatedEntities2` attribute of `Entity1`. 

Run the test `findAllByEntity2NaturalId()` in `Entity1RepositoryTest`.

Inspect the last SELECT statement that is logged by `findAllByEntity2NaturalId()`.

```
    select
        entity1x0_.id as id1_0_ 
    from
        entity_1 entity1x0_ 
    inner join
        join_table relatedent1_ 
            on entity1x0_.id=relatedent1_.entity_1_id 
    inner join
        entity_2 entity2x2_ 
            on relatedent1_.entity_2_id=entity2x2_.id 
    where
        entity2x2_.natural_id=?
```

The many-to-many relationship via `join_table` is translated into two "cascading" inner joins.
When using Hibernate `6.1.7.Final`, the structure of the JOIN's is different.