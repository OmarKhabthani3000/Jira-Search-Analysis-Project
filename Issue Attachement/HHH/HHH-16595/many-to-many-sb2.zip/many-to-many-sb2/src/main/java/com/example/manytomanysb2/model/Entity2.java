package com.example.manytomanysb2.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "entity_2")
public class Entity2 {
    @Id
    private Long id;

    private String naturalId;
}
