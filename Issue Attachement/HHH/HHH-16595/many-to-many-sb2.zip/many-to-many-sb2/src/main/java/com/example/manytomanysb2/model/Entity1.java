package com.example.manytomanysb2.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "entity_1")
public class Entity1 {
    @Id
    private Long id;

    @ManyToMany
    @JoinTable(name = "join_table",
            joinColumns = @JoinColumn(name = "entity_1_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "entity_2_id", referencedColumnName = "id"))
    private Set<Entity2> relatedEntities2;
}
