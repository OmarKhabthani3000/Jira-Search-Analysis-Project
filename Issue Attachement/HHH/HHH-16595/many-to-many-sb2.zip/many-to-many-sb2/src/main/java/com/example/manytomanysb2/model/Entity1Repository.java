package com.example.manytomanysb2.model;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface Entity1Repository extends JpaRepository<Entity1, Long> {
    @Query("select entity1" +
            "    from Entity1 entity1" +
            "    inner join entity1.relatedEntities2 as relatedEntities2" +
            "    where relatedEntities2.naturalId = :naturalId")
    List<Entity1> findAllByEntity2NaturalId(String naturalId);
}
