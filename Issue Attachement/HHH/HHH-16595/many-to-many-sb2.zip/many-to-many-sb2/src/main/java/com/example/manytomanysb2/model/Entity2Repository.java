package com.example.manytomanysb2.model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Entity2Repository extends JpaRepository<Entity2, Long> {
}
