package com.example.manytomanysb2.model;

import java.util.Set;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
class Entity1RepositoryTest {

    @Autowired
    Entity1Repository entity1Repository;
    @Autowired
    Entity2Repository entity2Repository;

    @Test
    void findAllByEntity2NaturalId() {
        var e2_1 = new Entity2(1L, "111");
        entity2Repository.save(e2_1);

        var e1_1 = new Entity1(1L, Set.of(e2_1));
        entity1Repository.save(e1_1);

        Assertions.assertThat(entity1Repository.findAllByEntity2NaturalId("111")).hasSize(1);
    }
}