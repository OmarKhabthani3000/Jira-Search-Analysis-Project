package taxi_fleet;

import java.util.*;
import java.util.stream.*;
import java.util.function.*;
import java.io.Serializable;
import javax.persistence.*;
import javax.persistence.criteria.*;
import javax.inject.*;
import javax.ejb.*;
import javax.enterprise.event.*;
import javax.enterprise.context.*;
import static util.PersistenceHelper.*;

import reporting.*;

@Stateless
public class TaxiService {
    
    public TaxiService() {
    }
    
    private EntityManager getEntityManager() {
        return util.PersistenceHelper.getEntityManager();
    }
    
    
    public Taxi create(Taxi toCreate) {
        getEntityManager().persist(toCreate);
        return toCreate;
    }
    public Taxi find(Object id) {
        return getEntityManager().find(Taxi.class, id);
    }
    public Taxi refresh(Taxi toRefresh) {
        getEntityManager().refresh(toRefresh);
        return toRefresh; 
    }
    public Taxi merge(Taxi toMerge) {
        return getEntityManager().merge(toMerge);
    }
    public List<Taxi> findAll() {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Taxi> cq = cb.createQuery(Taxi.class);
        Root<Taxi> taxi = cq.from(Taxi.class);
        return getEntityManager().createQuery(cq.select(taxi).orderBy(cb.asc(taxi.get("id"))).distinct(true)).getResultList();
    }
    public Taxi update(Taxi toUpdate) {
        assert toUpdate.getId() != null;
        getEntityManager().persist(toUpdate);
        return toUpdate;
    }
    public void delete(Object id) {
        Taxi found = getEntityManager().find(Taxi.class, id);
        if (found != null)
            getEntityManager().remove(found);
    }
    public List<Taxi> findByShift(Shift shift) {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Taxi> cq = cb.createQuery(Taxi.class);
        Root<Taxi> root = cq.from(Taxi.class);
        return getEntityManager().createQuery(cq.select(root).where(cb.equal(root.get("shift"), shift)).distinct(true)).getResultList();
    }
    public Collection<Taxi> available() {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Taxi> cq = cb.createQuery(Taxi.class);
        	        Root<Taxi> taxi_ = cq.from(Taxi.class);
        Subquery<Driver> driverSubquery = cq.subquery(Driver.class);
        Root<Driver> drivers = driverSubquery.from(Driver.class);
        return getEntityManager().createQuery(
            cq.distinct(true).where(
                cb.not(
                    cb.greaterThanOrEqualTo(
                		cb.count(driverSubquery.select(drivers).where(
                                cb.equal(drivers.get("taxi"), taxi_))),
                		taxi_.get("shift").get("shiftsPerDay")
                    )
                )
            )
        ).getResultList();
//        return getEntityManager().createQuery(
//        	    "SELECT t FROM Taxi t WHERE (SELECT COUNT(d) FROM Driver d where d.taxi = t) < t.shift.shiftsPerDay")
//        	   .getResultList();
        
//        return getEntityManager().createQuery(
//        	    "select distinct generatedAlias0 from taxi_fleet.Taxi as generatedAlias0 where count((select generatedAlias1 from taxi_fleet.Driver as generatedAlias1 where generatedAlias1.taxi=generatedAlias0))<generatedAlias0.shift.shiftsPerDay")
//        	   .getResultList();
    }
    
    public Collection<Taxi> empty() {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Taxi> cq = cb.createQuery(Taxi.class);
        Subquery<Driver> driverSubquery = cq.subquery(Driver.class);
        	        Root<Taxi> taxi_ = cq.from(Taxi.class);
        return getEntityManager().createQuery(
            cq.distinct(true).where(
                cb.isEmpty(
                    taxi_.get("drivers")
                )
            )
        ).getResultList();
    }
    
    public Collection<Taxi> full() {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Taxi> cq = cb.createQuery(Taxi.class);
        	        Root<Taxi> taxi_ = cq.from(Taxi.class);
        return getEntityManager().createQuery(
            cq.distinct(true).where(
                cb.greaterThanOrEqualTo(
                    cb.count(taxi_.get("drivers")),
                    taxi_.get("shift").get("shiftsPerDay")
                )
            )
        ).getResultList();
    }
}
