package taxi_fleet;

import java.util.*;
import java.util.stream.*;
import java.util.function.*;
import java.io.Serializable;
import javax.persistence.*;
import javax.inject.*;
import javax.ejb.*;
import javax.enterprise.event.*;
import javax.enterprise.context.*;
import static util.PersistenceHelper.*;
import reporting.*;

/**
 *  Drivers that can book taxis. 
 */
@Entity
public class Driver {
    
    
    
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    public Long getId() {
        return id;
    }
    
    /*************************** ATTRIBUTES ***************************/
    
    @Column(nullable=false)
    private String name = "";
    
    public String getName() {
        return this.name;
    }
    
    public void setName(String newName) {
        this.name = newName;
    }
    /*************************** RELATIONSHIPS ***************************/
    
    @ManyToOne
    private Taxi taxi;
    
    public Taxi getTaxi() {
        return this.taxi;
    }
    
    public void setTaxi(Taxi newTaxi) {
        this.taxi = newTaxi;
    }
    
    @OneToMany(mappedBy="driver")
    private Set<Charge> charges = new LinkedHashSet<>();
    
    public Set<Charge> getCharges() {
        return this.charges;
    }
    
    
    public void addToCharges(Charge newCharges) {
        this.charges.add(newCharges);
    }
    
    public void removeFromCharges(Charge existingCharges) {
        this.charges.remove(existingCharges);
    }
    /*************************** ACTIONS ***************************/
    
    /**
     *  Book a taxi that is currently available 
     */
    public void book(Taxi toRent) {
        // TBD: support for global-data based preconditions
        /*
        if (!(new TaxiService().findAll().stream().anyMatch(t -> 
            !t.isFull()
        ))) {
            throw new RuntimeException();
        }
        */
        if (toRent.isFull()) {
            throw new RuntimeException();
        }
        if (this.getTaxi() != null && toRent.getId().equals(this.getTaxi().getId())) {
            throw new RuntimeException();
        }
        this.setTaxi(toRent);
        toRent.addToDrivers(this);
    }
    /**
     *  Release a taxi that is currently booked 
     */
    public void release() {
        if (!this.isHasBooking()) {
            throw new RuntimeException();
        }
        if (this.getTaxi() != null) {
        	this.getTaxi().removeFromDrivers(this);
        	this.setTaxi(null);
        }
    }
    /*************************** DERIVED PROPERTIES ****************/
    
    public boolean isHasBooking() {
        return !(this.getTaxi() == null);
    }
    
    public boolean isPaymentDue() {
        return !this.getPendingCharges().isEmpty();
    }
    /*************************** DERIVED RELATIONSHIPS ****************/
    
    public Collection<Charge> getPendingCharges() {
        return this.getCharges().stream().filter(c -> 
            !c.isPaid()
        ).collect(Collectors.toList());
    }
    
}
