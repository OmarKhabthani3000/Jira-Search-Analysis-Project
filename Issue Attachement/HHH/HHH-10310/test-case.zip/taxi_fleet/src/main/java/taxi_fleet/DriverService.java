package taxi_fleet;

import java.util.*;
import java.util.stream.*;
import java.util.function.*;
import java.io.Serializable;
import javax.persistence.*;
import javax.persistence.criteria.*;
import javax.inject.*;
import javax.ejb.*;
import javax.enterprise.event.*;
import javax.enterprise.context.*;
import static util.PersistenceHelper.*;

import reporting.*;

@Stateless
public class DriverService {
    
    public DriverService() {
    }
    
    private EntityManager getEntityManager() {
        return util.PersistenceHelper.getEntityManager();
    }
    
    
    public Driver create(Driver toCreate) {
        getEntityManager().persist(toCreate);
        return toCreate;
    }
    public Driver find(Object id) {
        return getEntityManager().find(Driver.class, id);
    }
    public Driver refresh(Driver toRefresh) {
        getEntityManager().refresh(toRefresh);
        return toRefresh; 
    }
    public Driver merge(Driver toMerge) {
        return getEntityManager().merge(toMerge);
    }
    public List<Driver> findAll() {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Driver> cq = cb.createQuery(Driver.class);
        Root<Driver> driver = cq.from(Driver.class);
        return getEntityManager().createQuery(cq.select(driver).orderBy(cb.asc(driver.get("id"))).distinct(true)).getResultList();
    }
    public Driver update(Driver toUpdate) {
        assert toUpdate.getId() != null;
        getEntityManager().persist(toUpdate);
        return toUpdate;
    }
    public void delete(Object id) {
        Driver found = getEntityManager().find(Driver.class, id);
        if (found != null)
            getEntityManager().remove(found);
    }
}
