package reporting;

import java.io.Serializable;
import java.util.*;

public class ChargeDetails {
	private static final long serialVersionUID = 1L;
    public final double amount;
    
    public final Date date;
    
    public final String name;
    
    public ChargeDetails(double amount, Date date, String name) {
        this.amount = amount;
        this.date = date;
        this.name = name;
    }
    
    public double getAmount() {
        return amount;
    }    
    
    public Date getDate() {
        return date;
    }    
    
    public String getName() {
        return name;
    }    
}

