package taxi_fleet;

import java.util.*;
import java.util.stream.*;
import java.util.function.*;
import java.io.Serializable;
import javax.persistence.*;
import javax.inject.*;
import javax.ejb.*;
import javax.enterprise.event.*;
import javax.enterprise.context.*;
import static util.PersistenceHelper.*;
import reporting.*;

/**
 *  Charges for renting taxis. 
 */
@Entity
public class Charge {
    
    
    
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    public Long getId() {
        return id;
    }
    
    /*************************** ATTRIBUTES ***************************/
    
    @Column(nullable=false)
    private Date date;
    
    public Date getDate() {
        return this.date;
    }
    
    public void setDate(Date newDate) {
        this.date = newDate;
    }
    
    @Column
    private Date receivedOn;
    
    public Date getReceivedOn() {
        return this.receivedOn;
    }
    
    public void setReceivedOn(Date newReceivedOn) {
        this.receivedOn = newReceivedOn;
    }
    
    @Column(nullable=false)
    private String description;
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(String newDescription) {
        this.description = newDescription;
    }
    
    @Column(nullable=false)
    private double amount;
    
    public double getAmount() {
        return this.amount;
    }
    
    public void setAmount(double newAmount) {
        this.amount = newAmount;
    }
    
    @Column(nullable=false)
    @Enumerated(EnumType.STRING)
    private Charge.Status status = Charge.Status.Pending;
    
    public Charge.Status getStatus() {
        return this.status;
    }
    
    public void setStatus(Charge.Status newStatus) {
        this.status = newStatus;
    }
    /*************************** RELATIONSHIPS ***************************/
    
    @ManyToOne
    private Driver driver;
    
    public Driver getDriver() {
        return this.driver;
    }
    
    public void setDriver(Driver newDriver) {
        this.driver = newDriver;
    }
    
    @OneToOne
    private Taxi taxi;
    
    public Taxi getTaxi() {
        return this.taxi;
    }
    
    public void setTaxi(Taxi newTaxi) {
        this.taxi = newTaxi;
    }
    /*************************** ACTIONS ***************************/
    
    public void pay() {
        this.handleEvent(StatusEvent.Pay);
    }
    public void cancelPayment() {
        this.handleEvent(StatusEvent.CancelPayment);
    }
    /*************************** DERIVED PROPERTIES ****************/
    
    public boolean isPaid() {
        return (this.getStatus() == Charge.Status.Paid);
    }
    /*************************** STATE MACHINE ********************/
    
    public enum Status {
        Pending {
            @Override void handleEvent(Charge instance, StatusEvent event) {
                switch (event) {
                    case Pay :
                        doTransitionTo(instance, Paid);
                        break;
                    default : break; // unexpected events are silently ignored 
                }
            }                       
        },
        Paid {
            @Override void onEntry(Charge instance) {
                instance.setReceivedOn(java.sql.Date.valueOf(java.time.LocalDate.now()));
            }
            @Override void handleEvent(Charge instance, StatusEvent event) {
                switch (event) {
                    case CancelPayment :
                        instance.setReceivedOn(null);
                        doTransitionTo(instance, Pending);
                        break;
                    default : break; // unexpected events are silently ignored 
                }
            }                       
        };
        void onEntry(Charge instance) {
            // no entry behavior by default
        }
        void onExit(Charge instance) {
            // no exit behavior by default
        }
        /** Each state implements handling of events. */
        abstract void handleEvent(Charge instance, StatusEvent event);
        /** 
            Performs a transition.
            @param instance the instance to update
            @param newState the new state to transition to 
        */
        final void doTransitionTo(Charge instance, Status newState) {
            instance.status.onExit(instance);
            instance.status = newState;
            instance.status.onEntry(instance);
        }
    }
    
    public enum StatusEvent {
        Pay,
        CancelPayment
    }
    
    public void handleEvent(StatusEvent event) {
        status.handleEvent(this, event);
    }
    
}
