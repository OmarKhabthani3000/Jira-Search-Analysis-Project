package taxi_fleet;

import java.util.*;
import java.util.stream.*;
import java.util.function.*;
import java.io.Serializable;
import javax.persistence.*;
import javax.persistence.criteria.*;
import javax.inject.*;
import javax.ejb.*;
import javax.enterprise.event.*;
import javax.enterprise.context.*;
import static util.PersistenceHelper.*;

import reporting.*;

@Stateless
public class ChargeService {
    
    public ChargeService() {
    }
    
    private EntityManager getEntityManager() {
        return util.PersistenceHelper.getEntityManager();
    }
    
    
    public Charge create(Charge toCreate) {
        getEntityManager().persist(toCreate);
        return toCreate;
    }
    public Charge find(Object id) {
        return getEntityManager().find(Charge.class, id);
    }
    public Charge refresh(Charge toRefresh) {
        getEntityManager().refresh(toRefresh);
        return toRefresh; 
    }
    public Charge merge(Charge toMerge) {
        return getEntityManager().merge(toMerge);
    }
    public List<Charge> findAll() {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Charge> cq = cb.createQuery(Charge.class);
        Root<Charge> charge = cq.from(Charge.class);
        return getEntityManager().createQuery(cq.select(charge).orderBy(cb.asc(charge.get("id"))).distinct(true)).getResultList();
    }
    public Charge update(Charge toUpdate) {
        assert toUpdate.getId() != null;
        getEntityManager().persist(toUpdate);
        return toUpdate;
    }
    public void delete(Object id) {
        Charge found = getEntityManager().find(Charge.class, id);
        if (found != null)
            getEntityManager().remove(found);
    }
    public List<Charge> findByTaxi(Taxi taxi) {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Charge> cq = cb.createQuery(Charge.class);
        Root<Charge> root = cq.from(Charge.class);
        return getEntityManager().createQuery(cq.select(root).where(cb.equal(root.get("taxi"), taxi)).distinct(true)).getResultList();
    }
    public void newCharge(Taxi taxi, Driver payer, Date date) {
        if (date == null) date = java.sql.Date.valueOf(java.time.LocalDate.now()); 
        Charge charge = new Charge();
        charge.setDescription((taxi.getName() + " - ") + taxi.getShift().getDescription());
        charge.setAmount(taxi.getShift().getPrice());
        charge.setTaxi(taxi);
        charge.setDate(date);
        charge.setDriver(payer);
        payer.addToCharges(charge);
        persist(charge);
    }
    
    public Collection<Charge> pendingCharges() {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Charge> cq = cb.createQuery(Charge.class);
        	        Root<Charge> charge_ = cq.from(Charge.class);
        return getEntityManager().createQuery(
            cq.distinct(true).where(
                cb.not(
                    cb.equal(charge_.get("status"), Charge.Status.Paid)
                )
            )
        ).getResultList();
    }
    
    public Collection<Charge> byTaxi(Taxi taxi) {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Charge> cq = cb.createQuery(Charge.class);
        	        Root<Charge> charge_ = cq.from(Charge.class);
        return getEntityManager().createQuery(
            cq.distinct(true).where(
                cb.equal(charge_.get("taxi"), cb.parameter(Taxi.class, "taxi"))
            )
        ).setParameter("taxi", taxi).getResultList();
    }
    
    public Collection<Charge> paidCharges() {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Charge> cq = cb.createQuery(Charge.class);
        	        Root<Charge> charge_ = cq.from(Charge.class);
        return getEntityManager().createQuery(
            cq.distinct(true).where(
                cb.equal(charge_.get("status"), Charge.Status.Paid)
            )
        ).getResultList();
    }
}
