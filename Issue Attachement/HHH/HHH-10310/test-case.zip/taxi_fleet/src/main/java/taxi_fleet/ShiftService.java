package taxi_fleet;

import java.util.*;
import java.util.stream.*;
import java.util.function.*;
import java.io.Serializable;
import javax.persistence.*;
import javax.persistence.criteria.*;
import javax.inject.*;
import javax.ejb.*;
import javax.enterprise.event.*;
import javax.enterprise.context.*;
import static util.PersistenceHelper.*;

import reporting.*;

@Stateless
public class ShiftService {
    
    public ShiftService() {
    }
    
    private EntityManager getEntityManager() {
        return util.PersistenceHelper.getEntityManager();
    }
    
    public Collection<Taxi> getTaxis(Shift context) {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Taxi> cq = cb.createQuery(Taxi.class);
        	        Root<Taxi> taxi_ = cq.from(Taxi.class);
        return getEntityManager().createQuery(
            cq.distinct(true).where(
                cb.equal(taxi_.get("shift"), context.getId())
            )
        ).getResultList();
    }
    
    public Shift create(Shift toCreate) {
        getEntityManager().persist(toCreate);
        return toCreate;
    }
    public Shift find(Object id) {
        return getEntityManager().find(Shift.class, id);
    }
    public Shift refresh(Shift toRefresh) {
        getEntityManager().refresh(toRefresh);
        return toRefresh; 
    }
    public Shift merge(Shift toMerge) {
        return getEntityManager().merge(toMerge);
    }
    public List<Shift> findAll() {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Shift> cq = cb.createQuery(Shift.class);
        Root<Shift> shift = cq.from(Shift.class);
        return getEntityManager().createQuery(cq.select(shift).orderBy(cb.asc(shift.get("id"))).distinct(true)).getResultList();
    }
    public Shift update(Shift toUpdate) {
        assert toUpdate.getId() != null;
        getEntityManager().persist(toUpdate);
        return toUpdate;
    }
    public void delete(Object id) {
        Shift found = getEntityManager().find(Shift.class, id);
        if (found != null)
            getEntityManager().remove(found);
    }
}
