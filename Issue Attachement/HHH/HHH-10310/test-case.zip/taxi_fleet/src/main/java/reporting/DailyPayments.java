package reporting;

import java.io.Serializable;
import java.util.*;

public class DailyPayments {
	private static final long serialVersionUID = 1L;
    public final Date paymentDate;
    
    public final double dailyTotal;
    
    public DailyPayments(Date paymentDate, double dailyTotal) {
        this.paymentDate = paymentDate;
        this.dailyTotal = dailyTotal;
    }
    
    public Date getPaymentDate() {
        return paymentDate;
    }    
    
    public double getDailyTotal() {
        return dailyTotal;
    }    
}

