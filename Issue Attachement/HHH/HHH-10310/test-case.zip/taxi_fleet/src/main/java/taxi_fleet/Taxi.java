package taxi_fleet;

import java.util.*;
import java.util.stream.*;
import java.util.function.*;
import java.io.Serializable;
import javax.persistence.*;
import javax.inject.*;
import javax.ejb.*;
import javax.enterprise.event.*;
import javax.enterprise.context.*;
import static util.PersistenceHelper.*;
import reporting.*;

/**
 *  The vehicles that make up the fleet. 
 */
@Entity
public class Taxi {
    
    
    
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    public Long getId() {
        return id;
    }
    /*************************** PROVIDERS ***************************/
    
    @Inject @Transient private ChargeService chargeService = new ChargeService();
    
    /*************************** ATTRIBUTES ***************************/
    
    @Column(nullable=false)
    private String name = "";
    
    public String getName() {
        return this.name;
    }
    
    public void setName(String newName) {
        this.name = newName;
    }
    /*************************** RELATIONSHIPS ***************************/
    
    @OneToOne
    private Shift shift;
    
    public Shift getShift() {
        return this.shift;
    }
    
    public void setShift(Shift newShift) {
        this.shift = newShift;
    }
    
    @OneToMany(mappedBy="taxi")
    private Set<Driver> drivers = new LinkedHashSet<>();
    
    public Set<Driver> getDrivers() {
        return this.drivers;
    }
    
    
    public void addToDrivers(Driver newDrivers) {
        this.drivers.add(newDrivers);
    }
    
    public void removeFromDrivers(Driver existingDrivers) {
        this.drivers.remove(existingDrivers);
    }
    /*************************** ACTIONS ***************************/
    
    /**
     *  Create charges for every driver 
     */
    public void charge(Date date) {
        if (!this.isBooked()) {
            throw new RuntimeException();
        }
        this.getDrivers().forEach(toCharge -> {
            new ChargeService().newCharge(this, toCharge, date);
        });
    }
    /**
     *  Book this taxi for a driver. 
     */
    public void bookTo(Driver driver) {
        if (this.isFull()) {
            throw new RuntimeException();
        }
        if (!((driver.getTaxi() == null))) {
            throw new RuntimeException();
        }
        driver.book(this);
    }
    /*************************** DERIVED PROPERTIES ****************/
    
    public long getDriverCount() {
        return this.getDrivers().size();
    }
    
    public boolean isFull() {
        return this.getDriverCount() >= this.getShift().getShiftsPerDay();
    }
    
    public boolean isBooked() {
        return this.getDriverCount() > 0L;
    }
    /*************************** DERIVED RELATIONSHIPS ****************/
    
    public Collection<Charge> getPendingCharges() {
        return new ChargeService().byTaxi(this).stream().filter(c -> 
            !c.isPaid()
        ).collect(Collectors.toList());
    }
    
}
