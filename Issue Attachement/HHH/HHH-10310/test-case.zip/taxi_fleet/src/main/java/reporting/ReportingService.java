package reporting;

import java.util.*;
import java.util.stream.*;


public interface ReportingService {
    public Collection<ChargeDetails> listPendingCharges();
    public Collection<DailyPayments> paymentsPerDay();
}
