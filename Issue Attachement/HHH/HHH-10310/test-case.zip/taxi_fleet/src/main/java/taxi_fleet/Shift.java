package taxi_fleet;

import java.util.*;
import java.util.stream.*;
import java.util.function.*;
import java.io.Serializable;
import javax.persistence.*;
import javax.inject.*;
import javax.ejb.*;
import javax.enterprise.event.*;
import javax.enterprise.context.*;
import static util.PersistenceHelper.*;
import reporting.*;

/**
 *  Shift modalities. 
 */
@Entity
public class Shift {
    
    
    
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    public Long getId() {
        return id;
    }
    
    /*************************** ATTRIBUTES ***************************/
    
    @Column(nullable=false)
    private String description = "";
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(String newDescription) {
        this.description = newDescription;
    }
    
    @Column(nullable=false)
    private double price = 0.0;
    
    public double getPrice() {
        return this.price;
    }
    
    public void setPrice(double newPrice) {
        this.price = newPrice;
    }
    
    @Column(nullable=false)
    private long shiftsPerDay = 1L;
    
    public long getShiftsPerDay() {
        return this.shiftsPerDay;
    }
    
    public void setShiftsPerDay(long newShiftsPerDay) {
        if (!(newShiftsPerDay > 0L)) {
            throw new RuntimeException();
        }
        if (!(newShiftsPerDay <= 3L)) {
            throw new RuntimeException();
        }
        this.shiftsPerDay = newShiftsPerDay;
    }
    /*************************** DERIVED RELATIONSHIPS ****************/
    
    public Collection<Taxi> getTaxis() {
        return new ShiftService().getTaxis(this);
    }
    
}
