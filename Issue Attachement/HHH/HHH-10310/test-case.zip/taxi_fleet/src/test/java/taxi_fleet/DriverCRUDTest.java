package taxi_fleet;

import org.junit.*;  
import static org.junit.Assert.*;  
import java.util.*;
import java.util.Date;
import java.util.stream.*;
import java.text.*;
import java.util.function.*;
import javax.persistence.*;
import javax.enterprise.context.*;
import javax.inject.*;
import javax.ejb.*;
import java.sql.*;
import util.PersistenceHelper;


import taxi_fleet.*;

public class DriverCRUDTest {
    private DriverService driverService;

    private EntityManager em;
    private EntityTransaction tx;

    @Before
    public void initEM() {
        this.em = Persistence.createEntityManagerFactory("taxi_fleet-local").createEntityManager();
        util.PersistenceHelper.setEntityManager(em);
        this.tx = this.em.getTransaction();
        this.tx.begin();
        this.driverService = new DriverService();
    }
    
    @After
    public void tearDown() {
        if (tx != null)
            tx.rollback();
        if (em != null)
            em.close();    
    }
    
    @Test
    public void create() {
        Driver toCreate = new Driver();
        toCreate.setName("");
        Driver created = driverService.create(toCreate);
        Object id = created.getId();
        assertNotNull(id);
        em.clear();
        Driver retrieved = driverService.find(id);
        assertNotNull(retrieved);
        assertEquals(id, retrieved.getId());
        assertEquals(created.getName(), retrieved.getName());
    }
    @Test
    public void retrieve() {
        Driver toCreate1 = new Driver();
        toCreate1.setName("");
        driverService.create(toCreate1);
        Driver toCreate2 = new Driver();
        toCreate2.setName("");
        driverService.create(toCreate2);
        em.clear();
        Driver retrieved1 = driverService.find(toCreate1.getId());
        assertNotNull(retrieved1);
        assertEquals(toCreate1.getId(), retrieved1.getId());
        
        Driver retrieved2 = driverService.find(toCreate2.getId());
        assertNotNull(retrieved2);
        assertEquals(toCreate2.getId(), retrieved2.getId());
    }
    @Test
    public void update() {
        Driver toCreate = new Driver();
        toCreate.setName("");
        Object id = driverService.create(toCreate).getId();
        PersistenceHelper.flush(true);
        Driver retrieved = driverService.find(id);
        String originalValue = retrieved.getName();
        retrieved.setName("A string value");
        driverService.update(retrieved);
        PersistenceHelper.flush(true);
        Driver updated = driverService.find(id); 
        assertNotEquals(originalValue, updated.getName());
    }
    @Test
    public void delete() {
        Driver toDelete = new Driver();
        toDelete.setName("");
        Object id = driverService.create(toDelete).getId();
        assertNotNull(driverService.find(id));
        driverService.delete(id);
        assertNull(driverService.find(id));
    }
} 
