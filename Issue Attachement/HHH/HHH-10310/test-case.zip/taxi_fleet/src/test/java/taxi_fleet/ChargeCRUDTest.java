package taxi_fleet;

import org.junit.*;  
import static org.junit.Assert.*;  
import java.util.*;
import java.util.Date;
import java.util.stream.*;
import java.text.*;
import java.util.function.*;
import javax.persistence.*;
import javax.enterprise.context.*;
import javax.inject.*;
import javax.ejb.*;
import java.sql.*;
import util.PersistenceHelper;


import taxi_fleet.*;

public class ChargeCRUDTest {
    private ChargeService chargeService;

    private EntityManager em;
    private EntityTransaction tx;

    @Before
    public void initEM() {
        this.em = Persistence.createEntityManagerFactory("taxi_fleet-local").createEntityManager();
        util.PersistenceHelper.setEntityManager(em);
        this.tx = this.em.getTransaction();
        this.tx.begin();
        this.chargeService = new ChargeService();
    }
    
    @After
    public void tearDown() {
        if (tx != null)
            tx.rollback();
        if (em != null)
            em.close();    
    }
    
    @Test
    public void create() {
        Charge toCreate = new Charge();
        toCreate.setDate(new Timestamp(System.currentTimeMillis()));
        toCreate.setDescription("");
        toCreate.setAmount(0.0);
        toCreate.setStatus(Charge.Status.Pending);
        Charge created = chargeService.create(toCreate);
        Object id = created.getId();
        assertNotNull(id);
        em.clear();
        Charge retrieved = chargeService.find(id);
        assertNotNull(retrieved);
        assertEquals(id, retrieved.getId());
        assertTrue((created.getDate().getTime() - retrieved.getDate().getTime()) < 10000);
        assertEquals(created.getDescription(), retrieved.getDescription());
        assertEquals(created.getAmount(), retrieved.getAmount(), 0.00000001);
        assertEquals(created.getStatus(), retrieved.getStatus());
    }
    @Test
    public void retrieve() {
        Charge toCreate1 = new Charge();
        toCreate1.setDate(new Timestamp(System.currentTimeMillis()));
        toCreate1.setDescription("");
        toCreate1.setAmount(0.0);
        toCreate1.setStatus(Charge.Status.Pending);
        chargeService.create(toCreate1);
        Charge toCreate2 = new Charge();
        toCreate2.setDate(new Timestamp(System.currentTimeMillis()));
        toCreate2.setDescription("");
        toCreate2.setAmount(0.0);
        toCreate2.setStatus(Charge.Status.Pending);
        chargeService.create(toCreate2);
        em.clear();
        Charge retrieved1 = chargeService.find(toCreate1.getId());
        assertNotNull(retrieved1);
        assertEquals(toCreate1.getId(), retrieved1.getId());
        
        Charge retrieved2 = chargeService.find(toCreate2.getId());
        assertNotNull(retrieved2);
        assertEquals(toCreate2.getId(), retrieved2.getId());
    }
    @Test
    public void update() {
        Charge toCreate = new Charge();
        toCreate.setDate(new Timestamp(System.currentTimeMillis()));
        toCreate.setDescription("");
        toCreate.setAmount(0.0);
        toCreate.setStatus(Charge.Status.Pending);
        Object id = chargeService.create(toCreate).getId();
        PersistenceHelper.flush(true);
        Charge retrieved = chargeService.find(id);
        Charge.Status originalValue = retrieved.getStatus();
        retrieved.setStatus(Charge.Status.Paid);
        chargeService.update(retrieved);
        PersistenceHelper.flush(true);
        Charge updated = chargeService.find(id); 
        assertNotEquals(originalValue, updated.getStatus());
    }
    @Test
    public void delete() {
        Charge toDelete = new Charge();
        toDelete.setDate(new Timestamp(System.currentTimeMillis()));
        toDelete.setDescription("");
        toDelete.setAmount(0.0);
        toDelete.setStatus(Charge.Status.Pending);
        Object id = chargeService.create(toDelete).getId();
        assertNotNull(chargeService.find(id));
        chargeService.delete(id);
        assertNull(chargeService.find(id));
    }
} 
