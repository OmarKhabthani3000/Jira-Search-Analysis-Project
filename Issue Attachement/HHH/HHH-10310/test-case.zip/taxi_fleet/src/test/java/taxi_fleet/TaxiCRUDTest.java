package taxi_fleet;

import org.junit.*;  
import static org.junit.Assert.*;  
import java.util.*;
import java.util.Date;
import java.util.stream.*;
import java.text.*;
import java.util.function.*;
import javax.persistence.*;
import javax.enterprise.context.*;
import javax.inject.*;
import javax.ejb.*;
import java.sql.*;
import util.PersistenceHelper;


import taxi_fleet.*;

public class TaxiCRUDTest {
    private TaxiService taxiService;

    private EntityManager em;
    private EntityTransaction tx;

    @Before
    public void initEM() {
        this.em = Persistence.createEntityManagerFactory("taxi_fleet-local").createEntityManager();
        util.PersistenceHelper.setEntityManager(em);
        this.tx = this.em.getTransaction();
        this.tx.begin();
        this.taxiService = new TaxiService();
    }
    
    @After
    public void tearDown() {
        if (tx != null)
            tx.rollback();
        if (em != null)
            em.close();    
    }
    
    @Test
    public void create() {
        Taxi toCreate = new Taxi();
        toCreate.setName("");
        Taxi created = taxiService.create(toCreate);
        Object id = created.getId();
        assertNotNull(id);
        em.clear();
        Taxi retrieved = taxiService.find(id);
        assertNotNull(retrieved);
        assertEquals(id, retrieved.getId());
        assertEquals(created.getName(), retrieved.getName());
    }
    @Test
    public void retrieve() {
        Taxi toCreate1 = new Taxi();
        toCreate1.setName("");
        taxiService.create(toCreate1);
        Taxi toCreate2 = new Taxi();
        toCreate2.setName("");
        taxiService.create(toCreate2);
        em.clear();
        Taxi retrieved1 = taxiService.find(toCreate1.getId());
        assertNotNull(retrieved1);
        assertEquals(toCreate1.getId(), retrieved1.getId());
        
        Taxi retrieved2 = taxiService.find(toCreate2.getId());
        assertNotNull(retrieved2);
        assertEquals(toCreate2.getId(), retrieved2.getId());
    }
    @Test
    public void update() {
        Taxi toCreate = new Taxi();
        toCreate.setName("");
        Object id = taxiService.create(toCreate).getId();
        PersistenceHelper.flush(true);
        Taxi retrieved = taxiService.find(id);
        String originalValue = retrieved.getName();
        retrieved.setName("A string value");
        taxiService.update(retrieved);
        PersistenceHelper.flush(true);
        Taxi updated = taxiService.find(id); 
        assertNotEquals(originalValue, updated.getName());
    }
    @Test
    public void delete() {
        Taxi toDelete = new Taxi();
        toDelete.setName("");
        Object id = taxiService.create(toDelete).getId();
        assertNotNull(taxiService.find(id));
        taxiService.delete(id);
        assertNull(taxiService.find(id));
    }
} 
