package tests.test;

import java.util.*;
import java.util.stream.*;
import java.util.function.*;
import java.io.Serializable;




import org.junit.*;  
import static org.junit.Assert.*;  
import java.util.*;
import java.util.stream.*;
import java.util.function.*;
import java.io.Serializable;
import javax.persistence.*;
import javax.inject.*;
import javax.ejb.*;
import javax.enterprise.event.*;
import javax.enterprise.context.*;
import static util.PersistenceHelper.*;
import util.*;

import taxi_fleet.*;

public class TaxiScenarios {
        private EntityManager em;
        private EntityTransaction tx;
    
        @Before
        public void initEM() {
            this.em = Persistence.createEntityManagerFactory("taxi_fleet-local").createEntityManager();
            util.PersistenceHelper.setEntityManager(em);
            this.tx = this.em.getTransaction();
            this.tx.begin();
        }
        
        @After
        public void tearDown() {
            if (tx != null)
                tx.rollback();
            if (em != null)
                em.close();    
        }
    @Test
    public void available() {
        Shift shift = TestData.newShift("A shift type", 1L);
        Taxi taxi1 = TestData.newTaxi("Taxi 1", shift);
        Taxi taxi2 = TestData.newTaxi("Taxi 2", shift);
        Driver driver = TestData.newDriver("Driver 1");
        flush();
        
        refresh(taxi1, taxi2, driver);
        
        assertTrue(new TaxiService().available().contains(taxi1));
        assertTrue(new TaxiService().available().contains(taxi2));
        
        driver.book(taxi1);
        flush();
        
        refresh(taxi1, taxi2, driver);
        
        assertTrue(!new TaxiService().available().contains(taxi1));
        assertTrue(new TaxiService().available().contains(taxi2));
        
        driver.release();
        flush();
        
        refresh(taxi1, taxi2);
        
        assertTrue(new TaxiService().available().contains(taxi1));
        assertTrue(new TaxiService().available().contains(taxi2));
        flush();
    }
} 
