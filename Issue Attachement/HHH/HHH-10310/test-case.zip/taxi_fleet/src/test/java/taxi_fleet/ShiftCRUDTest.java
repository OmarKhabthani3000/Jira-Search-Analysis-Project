package taxi_fleet;

import org.junit.*;  
import static org.junit.Assert.*;  
import java.util.*;
import java.util.Date;
import java.util.stream.*;
import java.text.*;
import java.util.function.*;
import javax.persistence.*;
import javax.enterprise.context.*;
import javax.inject.*;
import javax.ejb.*;
import java.sql.*;
import util.PersistenceHelper;


import taxi_fleet.*;

public class ShiftCRUDTest {
    private ShiftService shiftService;

    private EntityManager em;
    private EntityTransaction tx;

    @Before
    public void initEM() {
        this.em = Persistence.createEntityManagerFactory("taxi_fleet-local").createEntityManager();
        util.PersistenceHelper.setEntityManager(em);
        this.tx = this.em.getTransaction();
        this.tx.begin();
        this.shiftService = new ShiftService();
    }
    
    @After
    public void tearDown() {
        if (tx != null)
            tx.rollback();
        if (em != null)
            em.close();    
    }
    
    @Test
    public void create() {
        Shift toCreate = new Shift();
        toCreate.setDescription("");
        toCreate.setPrice(0.0);
        Shift created = shiftService.create(toCreate);
        Object id = created.getId();
        assertNotNull(id);
        em.clear();
        Shift retrieved = shiftService.find(id);
        assertNotNull(retrieved);
        assertEquals(id, retrieved.getId());
        assertEquals(created.getDescription(), retrieved.getDescription());
        assertEquals(created.getPrice(), retrieved.getPrice(), 0.00000001);
    }
    @Test
    public void retrieve() {
        Shift toCreate1 = new Shift();
        toCreate1.setDescription("");
        toCreate1.setPrice(0.0);
        shiftService.create(toCreate1);
        Shift toCreate2 = new Shift();
        toCreate2.setDescription("");
        toCreate2.setPrice(0.0);
        shiftService.create(toCreate2);
        em.clear();
        Shift retrieved1 = shiftService.find(toCreate1.getId());
        assertNotNull(retrieved1);
        assertEquals(toCreate1.getId(), retrieved1.getId());
        
        Shift retrieved2 = shiftService.find(toCreate2.getId());
        assertNotNull(retrieved2);
        assertEquals(toCreate2.getId(), retrieved2.getId());
    }
    @Test
    public void update() {
        Shift toCreate = new Shift();
        toCreate.setDescription("");
        toCreate.setPrice(0.0);
        Object id = shiftService.create(toCreate).getId();
        PersistenceHelper.flush(true);
        Shift retrieved = shiftService.find(id);
        String originalValue = retrieved.getDescription();
        retrieved.setDescription("A string value");
        shiftService.update(retrieved);
        PersistenceHelper.flush(true);
        Shift updated = shiftService.find(id); 
        assertNotEquals(originalValue, updated.getDescription());
    }
    @Test
    public void delete() {
        Shift toDelete = new Shift();
        toDelete.setDescription("");
        toDelete.setPrice(0.0);
        Object id = shiftService.create(toDelete).getId();
        assertNotNull(shiftService.find(id));
        shiftService.delete(id);
        assertNull(shiftService.find(id));
    }
} 
