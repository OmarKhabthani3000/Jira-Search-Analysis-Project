package tests.test;

import java.util.*;
import java.util.stream.*;
import java.util.function.*;
import java.io.Serializable;
import javax.persistence.*;
import javax.inject.*;
import javax.ejb.*;
import javax.enterprise.event.*;
import javax.enterprise.context.*;
import static util.PersistenceHelper.*;

import taxi_fleet.*;

public class TestData {
    static Taxi newTaxi(String name, Shift shift) {
        refresh(shift);
        Taxi taxi = new Taxi();
        taxi.setName(name);
        taxi.setShift(shift);
        persist(taxi);
        flush();
        persist(taxi);
        return taxi;
    }
    
    static Shift newShift(String description, long shiftsPerDay) {
        Shift shift = new Shift();
        shift.setDescription(description);
        shift.setPrice(100L);
        shift.setShiftsPerDay(1L);
        persist(shift);
        flush();
        persist(shift);
        return shift;
    }
    
    static Driver newDriver(String name) {
        Driver driver = new Driver();
        driver.setName(name);
        persist(driver);
        flush();
        persist(driver);
        return driver;
    }
} 
