INSERT INTO taxi_fleet.Shift (id, description, price, shiftsPerDay) VALUES (1, 'Full day', 50.0, 1);
INSERT INTO taxi_fleet.Shift (id, description, price, shiftsPerDay) VALUES (2, 'Half day', 30.0, 2);
INSERT INTO taxi_fleet.Shift (id, description, price, shiftsPerDay) VALUES (3, 'Third', 25.0, 3);

INSERT INTO taxi_fleet.Taxi (id, name, shift_id) VALUES (1, 'Taxi 5', 2);
INSERT INTO taxi_fleet.Taxi (id, name, shift_id) VALUES (2, 'Taxi 1', 1);
INSERT INTO taxi_fleet.Taxi (id, name, shift_id) VALUES (3, 'Taxi 2', 3);
INSERT INTO taxi_fleet.Taxi (id, name, shift_id) VALUES (4, 'Taxi 3', 2);
INSERT INTO taxi_fleet.Taxi (id, name, shift_id) VALUES (5, 'Taxi 4', 2);

INSERT INTO taxi_fleet.Driver (id, name, taxi_id) VALUES (1, 'John Silver', 2);
INSERT INTO taxi_fleet.Driver (id, name, taxi_id) VALUES (2, 'Katie Gold', 5);
INSERT INTO taxi_fleet.Driver (id, name, taxi_id) VALUES (3, 'Martin Johnes', 4);
INSERT INTO taxi_fleet.Driver (id, name) VALUES (4, 'Al Gamble');
INSERT INTO taxi_fleet.Driver (id, name, taxi_id) VALUES (5, 'Ann Beasly', 4);
INSERT INTO taxi_fleet.Driver (id, name) VALUES (6, 'Donna Peterson');
INSERT INTO taxi_fleet.Driver (id, name, taxi_id) VALUES (7, 'Alice Camden', 5);
INSERT INTO taxi_fleet.Driver (id, name) VALUES (8, 'Terrence Morris');

INSERT INTO taxi_fleet.Charge (id, date, amount, driver_id, receivedOn, description, taxi_id, status) VALUES (1, '2014-02-22', 30.0, 5, '2014-02-22', 'Taxi 3 - Half day', 4, 'Paid');
INSERT INTO taxi_fleet.Charge (id, date, amount, driver_id, receivedOn, description, taxi_id, status) VALUES (2, '2014-02-22', 50.0, 7, null, 'Taxi 1 - Full day', 3, 'Pending');
INSERT INTO taxi_fleet.Charge (id, date, amount, driver_id, receivedOn, description, taxi_id, status) VALUES (3, '2014-02-22', 30.0, 3, '2014-02-22', 'Taxi 3 - Half day', 4, 'Paid');
INSERT INTO taxi_fleet.Charge (id, date, amount, driver_id, receivedOn, description, taxi_id, status) VALUES (4, '2014-02-22', 30.0, 2, null, 'Taxi 4 - Half day', 5, 'Pending');
INSERT INTO taxi_fleet.Charge (id, date, amount, driver_id, receivedOn, description, taxi_id, status) VALUES (5, '2014-02-22', 30.0, 3, null, 'Taxi 3 - Half day', 4, 'Pending');

ALTER SEQUENCE taxi_fleet.taxi_id_seq RESTART WITH 6;

ALTER SEQUENCE taxi_fleet.shift_id_seq RESTART WITH 4;

ALTER SEQUENCE taxi_fleet.driver_id_seq RESTART WITH 9;

ALTER SEQUENCE taxi_fleet.charge_id_seq RESTART WITH 6;
