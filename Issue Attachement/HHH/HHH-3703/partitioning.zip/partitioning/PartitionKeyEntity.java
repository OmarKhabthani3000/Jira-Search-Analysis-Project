/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2009, Red Hat Middleware LLC or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Middleware LLC.
 * 
 * Copyright (c) 2009, vjoon GmbH.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.envers.test.integration.partitioning;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.envers.AuditJoinTable;
import org.hibernate.envers.Audited;

/**
 * The entity that represents the partition key entity itself. This is the only entity with a single field primary key
 * (the partition key itself).
 * 
 * @author Olaf Meske (omeske at vjoon dot com), vjoon GmbH
 */
@Entity
@Audited
public class PartitionKeyEntity {

    @Id
    private long id;

    private String name;

    /**
     * Direct collection of childs of the <code>PartitionKeyEntity</code>. This is a foreign key reference with a single
     * column (partitionKey).
     */
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "partitionKey", fetch = FetchType.LAZY)
    @AuditJoinTable(inverseJoinColumns = { @JoinColumn(name = "partitionKey", insertable = false, updatable = false) })
    private Set<PartitionKeyChildEntity> childs;

    /**
     * Single item of <code>PartitionedItemEntity</code>. This is a foreign key reference with two columns (id,
     * partitionKey)
     */
    @ManyToOne
    @JoinColumns( {
                   @JoinColumn(name = "itemId", referencedColumnName = "id", insertable = false, updatable = false),
                   @JoinColumn(name = "id", referencedColumnName = "partitionKey", insertable = false, updatable = false) })
    private PartitionedItemEntity item;

    /**
     * This field is needed to handle the JoinColumns for the <code>item</code> member as read only.
     * 
     * @see <a href="package-summary.html#JPA_relationships">JPA relationship</a>
     */
    private Long itemId;

    /**
     * Default constructor. Needed for JPA handling.
     */
    public PartitionKeyEntity() {
        super();
        // needed for JPA
    }

    /**
     * Constructor with all needed parameters.
     * 
     * @param id the partition key value.
     */
    public PartitionKeyEntity(long id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PartitionKeyEntity other = (PartitionKeyEntity) obj;
        if (id != other.id)
            return false;
        return true;
    }

    /**
     * @return the childs
     */
    public Set<PartitionKeyChildEntity> getChilds() {
        return childs;
    }

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @return the item
     */
    public PartitionedItemEntity getItem() {
        return item;
    }

    /**
     * @return the itemId
     */
    public Long getItemId() {
        return itemId;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (id ^ (id >>> 32));
        return result;
    }

    /**
     * @param childs the childs to set
     */
    public void setChilds(Set<PartitionKeyChildEntity> childs) {
        this.childs = childs;
    }

    /**
     * @param id the id to set
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * @param item the item to set
     */
    public void setItem(PartitionedItemEntity item) {
        this.item = item;
        this.itemId = (item == null) ? null : item.getId();
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

}
