/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2009, Red Hat Middleware LLC or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Middleware LLC.
 * 
 * Copyright (c) 2009, vjoon GmbH.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.envers.test.integration.partitioning;

import java.util.Arrays;

import javax.persistence.EntityManager;

import org.hibernate.ejb.Ejb3Configuration;
import org.hibernate.envers.test.AbstractEntityTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * The unit test with a simple composed primary key for the revision entity.
 * 
 * @author Olaf Meske (omeske at vjoon dot com), vjoon GmbH
 */
public class PartitionedItemSimpleTest extends AbstractEntityTest {

    private PartitionedEntityPK item1PK;

    private PartitionedEntityPK item2PK;

    public void configure(Ejb3Configuration cfg) {
        cfg.addAnnotatedClass(PartitionedRevisionEntity.class);
        cfg.addAnnotatedClass(PartitionedItemEntity.class);
    }

    @BeforeClass(dependsOnMethods = "init")
    public void initData() {
        EntityManager em = getEntityManager();

        PartitionedItemEntity item1 = new PartitionedItemEntity(42, 100);
        item1.setName("original name");
        item1PK = item1.getPk();
        PartitionedItemEntity item2 = new PartitionedItemEntity(42, 101);
        item2PK = item2.getPk();

        // Revision 1
        em.getTransaction().begin();

        em.persist(item1);
        em.persist(item2);
        em.getTransaction().commit();

        // Revision 2
        em.getTransaction().begin();

        item1 = em.find(PartitionedItemEntity.class, item1PK);
        item1.setName("new name 1");
        item2 = em.find(PartitionedItemEntity.class, item2PK);
        item2.setName("new name 2");
        em.getTransaction().commit();

        // Revision 3
        em.getTransaction().begin();

        item1 = em.find(PartitionedItemEntity.class, item1PK);
        item1.setName("changed name1");
        em.getTransaction().commit();
    }

    @Test
    public void testRevisionsCounts() {
        assert Arrays.asList(1, 2, 3).equals(getAuditReader().getRevisions(PartitionedItemEntity.class, item1PK));
        assert Arrays.asList(1, 2).equals(getAuditReader().getRevisions(PartitionedItemEntity.class, item2PK));
    }

}
