/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2009, Red Hat Middleware LLC or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Middleware LLC.
 * 
 * Copyright (c) 2009, vjoon GmbH.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.envers.test.integration.partitioning;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;

/**
 * A simple partitioned child class entity.
 * 
 * @author Olaf Meske (omeske at vjoon dot com), vjoon GmbH
 */
@Entity
@Audited
public class PartitionedItemChildEntity {

    @Id
    private PartitionedEntityPK pk;

    @ManyToOne
    @JoinColumns( {
                   @JoinColumn(name = "itemId", referencedColumnName = "id", insertable = false, updatable = false),
                   @JoinColumn(name = "partitionKey", referencedColumnName = "partitionKey", insertable = false, updatable = false) })
    private PartitionedItemEntity item;

    /**
     * This field is needed to handle the JoinColumns for the <code>item</code> member as read only.
     * 
     * @see <a href="package-summary.html#JPA_relationships">JPA relationship</a>
     */
    private long itemId;

    /**
     * Default constructor. Needed for JPA handling.
     */
    protected PartitionedItemChildEntity() {
        super();
        // needed for JPA
    }

    /**
     * Constructor taking all parameters for the primary key.
     * 
     * @param partitionKey the partition key.
     * @param id the id of this instance.
     */
    public PartitionedItemChildEntity(long partitionKey, long id) {
        pk = new PartitionedEntityPK(partitionKey, id);
    }

    /**
     * @return the id
     */
    public long getId() {
        return (pk == null) ? 0 : pk.getId();
    }

    /**
     * @return the item
     */
    public PartitionedItemEntity getItem() {
        return item;
    }

    /**
     * @return the partitionKey.
     */
    public long getPartitionKey() {
        return (pk == null) ? 0 : pk.getPartitionKey();
    }

    /**
     * @return the pk
     */
    public PartitionedEntityPK getPk() {
        return pk;
    }

    /**
     * @param item the item to set
     */
    public void setItem(PartitionedItemEntity item) {
        this.item = item;
        this.itemId = (this.item == null) ? 0 : this.item.getId();
        if (this.itemId != 0) {
            assert this.itemId > 0;
        }
    }

}
