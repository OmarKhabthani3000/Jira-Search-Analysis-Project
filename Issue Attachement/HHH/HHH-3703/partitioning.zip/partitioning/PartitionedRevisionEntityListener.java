/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2009, Red Hat Middleware LLC or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Middleware LLC.
 * 
 * Copyright (c) 2009, vjoon GmbH.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.envers.test.integration.partitioning;

import org.hibernate.envers.RevisionListener;

/**
 * Listener that set the application specific values into the <code>RevisionEntry</code>.
 * 
 * @author Olaf Meske (omeske at vjoon dot com), vjoon GmbH
 */
public class PartitionedRevisionEntityListener implements RevisionListener {

    private PartitionedServices services = PartitionedServices.getInstance();

    private long nextRev = 0;

    /*
     * @see org.jboss.envers.RevisionListener#newRevision(java.lang.Object)
     */
    public void newRevision(Object pRevEntity) {
        PartitionedRevisionEntity revEntry = (PartitionedRevisionEntity) pRevEntity;
        // (re)set the primary key of the PartitionedRevisionEntity to match the
        // requirements for the partitioning.
        revEntry.setPartitionKey(services.getPartitionKey());

        // Just for testing, simple increase the revision number
        revEntry.setRevisionNumber(++nextRev);

        revEntry.setRevisionTimestamp(System.currentTimeMillis());
        String currentUser = "unset user";
        revEntry.setModifiedBy(currentUser);

    }

}
