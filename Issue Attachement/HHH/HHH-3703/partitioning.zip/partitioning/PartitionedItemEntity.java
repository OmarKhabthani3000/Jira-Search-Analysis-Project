/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2009, Red Hat Middleware LLC or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Middleware LLC.
 * 
 * Copyright (c) 2009, vjoon GmbH.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.envers.test.integration.partitioning;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.envers.Audited;

/**
 * A simple partitioned item entity.
 * 
 * @author Olaf Meske (omeske at vjoon dot com), vjoon GmbH
 */
@Entity
@Audited
public class PartitionedItemEntity {

    @Id
    private PartitionedEntityPK pk;

    private String name;

    /**
     * Default constructor. Needed for JPA handling.
     */
    protected PartitionedItemEntity() {
        super();
        // needed for JPA
    }

    /**
     * Constructor taking all parameters for the primary key.
     * 
     * @param partitionKey the partition key.
     * @param id the id of this instance.
     */
    public PartitionedItemEntity(long partitionKey, long id) {
        pk = new PartitionedEntityPK(partitionKey, id);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PartitionedItemEntity other = (PartitionedItemEntity) obj;
        if (pk == null) {
            if (other.pk != null)
                return false;
        } else if (!pk.equals(other.pk))
            return false;
        return true;
    }

    /**
     * @return the id
     */
    public long getId() {
        return (pk == null) ? 0 : pk.getId();
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the partitionKey.
     */
    public long getPartitionKey() {
        return (pk == null) ? 0 : pk.getPartitionKey();
    }

    /**
     * @return the pk
     */
    public PartitionedEntityPK getPk() {
        return pk;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((pk == null) ? 0 : pk.hashCode());
        return result;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

}
