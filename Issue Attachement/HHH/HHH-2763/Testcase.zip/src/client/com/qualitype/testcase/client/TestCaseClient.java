package com.qualitype.testcase.client;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.qualitype.testcase.server.ejb.entity.EntityA;
import com.qualitype.testcase.server.ejb.session.inf.TestCase;

public class TestCaseClient {

	/**
	 * These testcase will show, that an assertion failure "...collection xyz
	 * was not processed by flush" will be thrown, if you use following
	 * entity-constellation and an PostUpdateListener:
	 * 
	 * You have entities that:
	 * 
	 * <pre>
	 * 1.) two entities are having a m:n relation AND 
	 * 2.) we have defined an PostUpdateListener that iterates through all properties of the entity and
	 *     so also through the m:n relation (=Collection)
	 * </pre>
	 * 
	 */
	public static void main(String[] args) {

		TestCase testCase = null;
		try {
			testCase = (TestCase) getInitialContext().lookup(
					"server/TestCase/remote");
		} catch (NamingException ex) {
			ex.printStackTrace();
		}
		/*
		 * create an instance of entity A and an instance of entity B, then link
		 * both with each other via an m:n relationship
		 */
		EntityA entityA = testCase.createEntities();

		// now update a simple property of EntityA, due to this the
		// MyPostUpdateListener will be called, which iterates through all
		// properties of EntityA (and also the Collection of the m:n relation)
		// --> org.hibernate.AssertionFailure: collection
		// [com.qualitype.testcase.server.ejb.entity.EntityB.entitiesOfA] was
		// not processed by flush()
		testCase.updateEntity(entityA.getId());
	}

	public static Context getInitialContext()
			throws javax.naming.NamingException {
		Properties env = new Properties();
		env.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		env
				.put(Context.URL_PKG_PREFIXES,
						"org.jboss.naming:org.jnp.interfaces");
		env.put(Context.PROVIDER_URL, "jnp://127.0.0.1:1099");

		return new InitialContext(env);
	}
}
