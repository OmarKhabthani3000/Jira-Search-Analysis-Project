package com.qualitype.testcase.server.ejb.entity.intf;

public interface Auditable {

	public long getId();
}
