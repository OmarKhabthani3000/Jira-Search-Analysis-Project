package com.qualitype.testcase.server.ejb.session.inf;

import com.qualitype.testcase.server.ejb.entity.EntityA;

public interface TestCase {

	/**
	 * create and save all an instance of EntityA and EntityB and link each via
	 * m:n relation
	 * 
	 */
	public EntityA createEntities();

	/**
	 * Updates simple Property of EntityA -> as side effect the
	 * MyPostUpdateListener will be called These Update will result in an
	 * Assertion Failure
	 * 
	 * @param id
	 */
	public void updateEntity(long id);

}
