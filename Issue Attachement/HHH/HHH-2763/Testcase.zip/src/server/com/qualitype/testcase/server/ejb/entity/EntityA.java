package com.qualitype.testcase.server.ejb.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import com.qualitype.testcase.server.ejb.entity.intf.Auditable;

@Entity(name = "EntityA")
public class EntityA implements Auditable, Serializable {

	private long id;

	private String name;

	private Set<EntityB> entitiesOfB = new HashSet<EntityB>();

	@Id
	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Column
	public String getName() {
		return this.name;
	}

	public void setName(String loginName) {
		this.name = loginName;
	}

	@ManyToMany(fetch = FetchType.LAZY)
	// @Fetch(FetchMode.SELECT)
	public Set<EntityB> getEntitiesOfB() {
		return this.entitiesOfB;
	}

	public void setEntitiesOfB(Set<EntityB> groups) {
		this.entitiesOfB = groups;
	}
}
