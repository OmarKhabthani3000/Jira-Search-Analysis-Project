package com.qualitype.testcase.server.ejb.session;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.qualitype.testcase.server.ejb.entity.EntityA;
import com.qualitype.testcase.server.ejb.entity.EntityB;
import com.qualitype.testcase.server.ejb.session.inf.TestCase;

@Stateless(name = "TestCase")
@Remote(TestCase.class)
@Local(TestCase.class)
public class TestCaseBean implements TestCase {

	@PersistenceContext(unitName = "testUnit")
	private EntityManager em;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.qualitype.testcase.server.ejb.session.inf.TestCase#createEntities()
	 */
	public EntityA createEntities() {

		EntityA a = new EntityA();
		a.setName("Karl");
		this.em.persist(a);

		EntityB b = new EntityB();
		this.em.persist(b);

		// link each entity via m:n relation
		a.getEntitiesOfB().add(b);
		b.getEntitiesOfA().add(a);

		return a;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.qualitype.testcase.server.ejb.session.inf.TestCase#updateEntity(long)
	 */
	public void updateEntity(long id) {
		// re-attach to persistence context
		EntityA a = this.em.find(EntityA.class, id);
		// force an update, as a side effect the MyPostUpdateListener.class will
		// be called
		a.setName("Otto");
	}
}
