package com.qualitype.testcase.server.ejb.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import com.qualitype.testcase.server.ejb.entity.intf.Auditable;

@Entity(name = "EntityB")
public class EntityB implements Auditable, Serializable {

	private long id;

	private Set<EntityA> entitiesOfA = new HashSet<EntityA>();

	@Id
	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@ManyToMany(mappedBy = "entitiesOfB")
	public Set<EntityA> getEntitiesOfA() {
		return this.entitiesOfA;
	}

	public void setEntitiesOfA(Set<EntityA> users) {
		this.entitiesOfA = users;
	}

}
