package com.qualitype.testcase.server.hibernate.listener;

import java.util.Collection;

import org.hibernate.ejb.event.CallbackHandlerConsumer;
import org.hibernate.ejb.event.EntityCallbackHandler;
import org.hibernate.event.PostUpdateEvent;
import org.hibernate.event.PostUpdateEventListener;

import com.qualitype.testcase.server.ejb.entity.intf.Auditable;

/**
 * @author Sebastian Schnabl
 * 
 * Normally this listener is part of an system of
 * PostInsert,PostUpdate,PostDelete-Listeners for Audit purposes. But for this
 * test-case only a snippet will be used.
 */
public class MyPostUpdateListener implements PostUpdateEventListener,
		CallbackHandlerConsumer {

	EntityCallbackHandler callbackHandler;

	public void setCallbackHandler(EntityCallbackHandler handler) {
		this.callbackHandler = handler;
	}

	/**
	 * Iterate through all properties of the updated object and audit the
	 * changed values (old and new). In case of collection, log the id's of the
	 * associated entites in this collection
	 */
	public void onPostUpdate(PostUpdateEvent event) {
		Object[] oldValues = event.getOldState();
		String[] properties = event.getPersister().getPropertyNames();

		// Iterate through all fields of the updated object
		for (int ii = 0; ii < properties.length; ii++) {

			if (oldValues != null && oldValues[ii] instanceof Collection) {
				Collection col = (Collection) oldValues[ii];
				// Hibernate will initialize(load) the m:side of m:n collection,
				// but this will lead to following error later:
				// AssertionFailure:collection [n:side] was not processed
				// by flush()
				for (Object object : col) {
					((Auditable) object).getId();
				}
			}
		}
	}
}
