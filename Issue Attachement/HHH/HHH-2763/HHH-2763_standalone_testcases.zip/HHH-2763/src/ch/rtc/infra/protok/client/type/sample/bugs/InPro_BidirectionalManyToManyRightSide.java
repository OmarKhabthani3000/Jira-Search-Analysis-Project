/*
 *
 * RTC AG, Copyright (c) 2007
 * created 20.06.2007 by ramseiet
 */
package ch.rtc.infra.protok.client.type.sample.bugs;

import java.util.HashSet;
import java.util.Set;

/**
 * class for manyToMany Relations
 *
 * @author ramseiet
 */
public class InPro_BidirectionalManyToManyRightSide
{
    //~ Instance fields ----------------------------------------------------------------------------

    /** the id */
    private long m_id;

    /** the version */
    private long m_version;

    /** the name */
    private String m_name;

    /**
     * Set with InPro_BidirectionalManyToManyLeftSide
     */
    private Set m_leftSide = new HashSet();

    //~ Constructors -------------------------------------------------------------------------------

    /**
     *
     */
    public InPro_BidirectionalManyToManyRightSide()
    {
        super();
    }

    /**
     * @param id
     * @param name
     */
    public InPro_BidirectionalManyToManyRightSide(long id, String name)
    {
        super();
        m_id = id;
        m_name = name;
    }

    //~ Methods ------------------------------------------------------------------------------------

    /**
     * @return Returns the id.
     */
    public long getId()
    {
        return m_id;
    }

    /**
     * @param id The id to set.
     */
    public void setId(long id)
    {
        m_id = id;
    }

    /**
     * @return Returns the name.
     */
    public String getName()
    {
        return m_name;
    }

    /**
     * @param name The name to set.
     */
    public void setName(String name)
    {
        m_name = name;
    }

    /**
     * @return Returns the version.
     */
    public long getVersion()
    {
        return m_version;
    }

    /**
     * @param version The version to set.
     */
    public void setVersion(long version)
    {
        m_version = version;
    }

    /**
     * @return Returns the leftSide.
     */
    public Set getLeftSide()
    {
        return m_leftSide;
    }

    /**
     * @param leftSide The leftSide to set.
     */
    public void setLeftSide(Set leftSide)
    {
        m_leftSide = leftSide;
    }

    /**
     * add a InPro_BidirectionalManyToManyLeftSide class
     * @param leftSide
     */
    public void addLeftSide(InPro_BidirectionalManyToManyLeftSide leftSide)
    {
        m_leftSide.add(leftSide);
    }

    /**
     * remove a leftSide
     * @param leftSide
     * @return the removed class
     */
    public boolean removeRightSide(InPro_BidirectionalManyToManyLeftSide leftSide)
    {
        return m_leftSide.remove(leftSide);
    }
}
