/*
 *
 * RTC AG, Copyright (c) 2007
 * created 20.06.2007 by ramseiet
 */
package ch.rtc.infra.protok.client.type.sample.bugs;

import java.util.HashSet;
import java.util.Set;

/**
 * class for manyToMany Relations
 *
 * @author ramseiet
 */
public class InPro_ParentWithLazyCollectionOfChildren
{
    //~ Instance fields ----------------------------------------------------------------------------

    /** the id */
    private long m_id;

    /** the version */
    private long m_version;

    /** the name */
    private String m_name;

    /**
     * Set with InPro_ChildWithCollections
     */
    private Set m_childrenWithCollections = new HashSet();

    //~ Constructors -------------------------------------------------------------------------------

    /**
     *
     */
    public InPro_ParentWithLazyCollectionOfChildren()
    {
        super();
    }

    /**
     * @param id
     * @param name
     */
    public InPro_ParentWithLazyCollectionOfChildren(long id, String name)
    {
        super();
        m_id = id;
        m_name = name;
    }

    //~ Methods ------------------------------------------------------------------------------------

    /**
     * @return Returns the id.
     */
    public long getId()
    {
        return m_id;
    }

    /**
     * @param id The id to set.
     */
    public void setId(long id)
    {
        m_id = id;
    }

    /**
     * @return Returns the name.
     */
    public String getName()
    {
        return m_name;
    }

    /**
     * @param name The name to set.
     */
    public void setName(String name)
    {
        m_name = name;
    }

    /**
     * @return Returns the version.
     */
    public long getVersion()
    {
        return m_version;
    }

    /**
     * @param version The version to set.
     */
    public void setVersion(long version)
    {
        m_version = version;
    }

    /**
     * @return Returns the childrenWithNonLazyCollection.
     */
    public Set getChildrenWithCollections()
    {
        return m_childrenWithCollections;
    }

    /**
     * @param childrenWithNonLazyCollection The childrenWithNonLazyCollection to set.
     */
    public void setChildrenWithCollections(Set childrenWithNonLazyCollection)
    {
        m_childrenWithCollections = childrenWithNonLazyCollection;
    }
    
}
