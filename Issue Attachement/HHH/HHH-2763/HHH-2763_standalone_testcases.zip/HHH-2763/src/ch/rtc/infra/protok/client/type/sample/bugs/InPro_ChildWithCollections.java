/*
 *
 * RTC AG, Copyright (c) 2007
 * created 20.06.2007 by ramseiet
 */
package ch.rtc.infra.protok.client.type.sample.bugs;

import java.util.Set;

/**
 * <code>InPro_SimpleParent.java</code>
 *
 * @author $Author:   rat  $
 * @version $Revision:   1.1  $
 */
public class InPro_ChildWithCollections
{
    //~ Instance fields ----------------------------------------------------------------------------

    /** the id */
    private long m_id;

    /** the name */
    private String m_name;

    private Set m_collectionOfValues;
    
    private Set m_collectionOfSimpleObjects;
    //~ Constructors -------------------------------------------------------------------------------

    /**
     *
     */
    public InPro_ChildWithCollections()
    {
    }

    /**
     * @param id
     * @param name
     * @param children
     */
    public InPro_ChildWithCollections(long id, String name)
    {
        super();
        m_id = id;
        m_name = name;
    }

    //~ Methods ------------------------------------------------------------------------------------

    /**
     * @return Returns the id.
     */
    public long getId()
    {
        return m_id;
    }

    /**
     * @param id The id to set.
     */
    public void setId(long id)
    {
        m_id = id;
    }

    /**
     * @return Returns the name.
     */
    public String getName()
    {
        return m_name;
    }

    /**
     * @param name The name to set.
     */
    public void setName(String name)
    {
        m_name = name;
    }
    /**
     * @return Returns the collectionOfValues.
     */
    public Set getCollectionOfValues()
    {
        return m_collectionOfValues;
    }

    /**
     * @param unterstuetzteWaehrungen The collectionOfValues to set.
     */
    public void setCollectionOfValues(Set collectionOfValues)
    {
        m_collectionOfValues = collectionOfValues;
    }

    /**
     * @return Returns the simpleObjects.
     */
    public Set getCollectionOfSimpleObjects()
    {
        return m_collectionOfSimpleObjects;
    }

    /**
     * @param simpleObjects The simpleObjects to set.
     */
    public void setCollectionOfSimpleObjects(Set simpleObjects)
    {
        m_collectionOfSimpleObjects = simpleObjects;
    }
    
}
