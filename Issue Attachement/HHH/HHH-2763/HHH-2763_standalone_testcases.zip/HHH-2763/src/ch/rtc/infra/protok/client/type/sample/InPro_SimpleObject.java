/* 
 * 
 * RTC AG, Copyright (c) 2007 
 * created 20.06.2007 by delaloyc 
 */ 
package ch.rtc.infra.protok.client.type.sample;


public class InPro_SimpleObject
{
    long m_idSimpleObject;
    String m_SimpleObjectField1;
    
    /**
     * 
     */
    public InPro_SimpleObject()
    {
    }

    
    /**
     * @param idSimpleObject
     * @param simpleObjectField1
     */
    public InPro_SimpleObject(long idSimpleObject, String simpleObjectField1)
    {
        super();
        m_idSimpleObject = idSimpleObject;
        m_SimpleObjectField1 = simpleObjectField1;
    }


    /**
     * @return Returns the idSimpleObject.
     */
    public long getIdSimpleObject()
    {
        return m_idSimpleObject;
    }
    /**
     * @param idSimpleObject The idSimpleObject to set.
     */
    public void setIdSimpleObject(long idSimpleObject)
    {
        m_idSimpleObject = idSimpleObject;
    }
    /**
     * @return Returns the simpleObjectField1.
     */
    public String getSimpleObjectField1()
    {
        return m_SimpleObjectField1;
    }
    /**
     * @param simpleObjectField1 The simpleObjectField1 to set.
     */
    public void setSimpleObjectField1(String simpleObjectField1)
    {
        m_SimpleObjectField1 = simpleObjectField1;
    }
    
}


