package ch.rtc.infra.protok.client;

import java.io.File;

import java.net.URL;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.metadata.ClassMetadata;
import org.hibernate.persister.entity.EntityPersister;
import org.hibernate.type.Type;

/**
 * <code>HibernateUtil.java</code>.
 *
 * @author $Author:   oba  $
 */
public final class InPro_HibernateUtil
{
    //~ Static fields/initializers -----------------------------------------------------------------

    /** TODOC */
    private static String s_configFile = "hibernate.cfg.xml";

    /** SessionFactory. */
    public static SessionFactory SESSION_FACTORY;

    /** session. */
    public static final ThreadLocal SESSION = new ThreadLocal();

    //~ Constructors -------------------------------------------------------------------------------

    /** Konstruktor.*/
    public InPro_HibernateUtil() throws HibernateException
    {
    }

    //~ Methods ------------------------------------------------------------------------------------

    /** create a session factory with the current configuration File **/
    public static void createSessionFactory()
    {
        try
        {
            // close exisiting sessions
            closeSession();

            // Create the SessionFactory from hibernate.cfg.xml
            Configuration cfg = new Configuration();
            File localHibernateFile = new File(s_configFile);

            if (localHibernateFile.exists())
            {
                SESSION_FACTORY = cfg.configure(localHibernateFile).buildSessionFactory();
            }
            else
            {
                URL url = ClassLoader.getSystemClassLoader().getResource(s_configFile);
                SESSION_FACTORY = cfg.configure(url).buildSessionFactory();
            }

            Iterator iter = cfg.getCollectionMappings();

            while (iter.hasNext())
            {
                System.out.println(iter.next());
            }
        }
        catch (Throwable ex)
        {
            // Make sure you log the exception, as it might be swallowed
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    /**
     * currentSession.
     *
     * @return session
     *
     * @throws HibernateException on error
     */
    public static Session currentSession() throws HibernateException
    {
        return (Session) SESSION.get();
    }

    /**
     * closeSession.
     *
     * @throws HibernateException on error
     */
    public static void closeSession() throws HibernateException
    {
        Session s = (Session) SESSION.get();

        if (s != null)
        {
            s.close();
        }

        SESSION.set(null);
    }

    /**
     * closeSession.
     *
     * @throws HibernateException on error
     */
    public static void closeSession(Session session) throws HibernateException
    {
        session.close();
    }


    /**
     * TODOC
     *
     * @return TODOC
     */
    public static Session getNewSession()
    {
        // create the session factory lazy
        if (SESSION_FACTORY == null)
        {
            createSessionFactory();
        }

        // open a new session
        return SESSION_FACTORY.openSession();
    }

    /**
     * @return Returns the configFile.
     */
    public static String getConfigFile()
    {
        return s_configFile;
    }

    /**
     * @param configFile The configFile to set.
     */
    public static void setConfigFile(String configFile)
    {
        // close exisiting sessions
        closeSession();
        
        // init the session factory
        SESSION_FACTORY = null;
        
        s_configFile = configFile;
    }
}
