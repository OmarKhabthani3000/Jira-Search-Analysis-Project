package ch.rtc.infra.protok.client;

import ch.rtc.infra.protok.client.type.sample.InPro_SimpleObject;
import ch.rtc.infra.protok.client.type.sample.bugs.InPro_BidirectionalManyToManyLeftSide;
import ch.rtc.infra.protok.client.type.sample.bugs.InPro_BidirectionalManyToManyRightSide;
import ch.rtc.infra.protok.client.type.sample.bugs.InPro_ChildWithCollections;
import ch.rtc.infra.protok.client.type.sample.bugs.InPro_ParentWithLazyCollectionOfChildren;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.Serializable;

import java.util.HashSet;
import java.util.Set;


/**
 * @author delaloyc
 * Required to compile and run:
 *  - hibernate stuff
 *  - junit.jar
 *  - commons-collections.jar, commons-lang.jar
 *  - hsqldb.jar
 * These 2 cases :
 *   - testHibernateBugHHH2763Case1 (bidirectional many-to-many)
 *   - testHibernateBugHHH2763Case2 (one-to-many with many side having collections)
 * can be used to reproduce bug HHH-2763:
 *  (lazy) m:n relation + EventListener = AssertionFailure: collection [n-side] was not processed by flush()
 * described under http://opensource.atlassian.com/projects/hibernate/browse/HHH-2763-
 * The 2 test cases use a pre-update Listener wich causes collections to be initialized
 * during the flush phase (see InPro_HibernateBugHHH2763Listener).
 * An exception stack like this one is to expect when session.flush() is called:
 * <code><pre>
 * 14:10:40,843 ERROR AssertionFailure                        :22 - an assertion failure occured (this may indicate a bug in Hibernate, but is more likely due to unsafe use of the session)
 * org.hibernate.AssertionFailure: collection [ch.rtc.infra.protok.client.type.sample.bugs.InPro_ChildWithCollections.unterstuetzteWaehrungen] was not processed by flush()
 *  at org.hibernate.engine.CollectionEntry.postFlush(CollectionEntry.java:236)
 *  at org.hibernate.event.def.AbstractFlushingEventListener.postFlush(AbstractFlushingEventListener.java:333)
 *  at org.hibernate.event.def.DefaultFlushEventListener.onFlush(DefaultFlushEventListener.java:28)
 *  at org.hibernate.impl.SessionImpl.flush(SessionImpl.java:1000)
 *  at ch.rtc.infra.protok.client.InPro_ProtokHibernateEventListenerHibernateBugs_tc.testHibernateBugHHH2763(InPro_ProtokHibernateEventListenerHibernateBugs_tc.java:191)
 *  at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
 *  at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:39)
 *  at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:25)
 *  at java.lang.reflect.Method.invoke(Method.java:324)
 *  at junit.framework.TestCase.runTest(TestCase.java:154)
 *  at junit.framework.TestCase.runBare(TestCase.java:127)
 *  at junit.framework.TestResult$1.protect(TestResult.java:106)
 *  at junit.framework.TestResult.runProtected(TestResult.java:124)
 *  at junit.framework.TestResult.run(TestResult.java:109)
 *  at junit.framework.TestCase.run(TestCase.java:118)
 *  at junit.framework.TestSuite.runTest(TestSuite.java:208)
 *  at junit.framework.TestSuite.run(TestSuite.java:203)
 *  at org.eclipse.jdt.internal.junit.runner.junit3.JUnit3TestReference.run(JUnit3TestReference.java:128)
 *  at org.eclipse.jdt.internal.junit.runner.TestExecution.run(TestExecution.java:38)
 *  at org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:460)
 *  at org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:673)
 *  at org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.run(RemoteTestRunner.java:386)
 *  at org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.main(RemoteTestRunner.java:196)
 * </pre></code>
 */
public class InPro_ProtokHibernateEventListenerHibernateBugs_tc extends TestCase {
    /** Version dieser Klasse. */
    /**
     * @see junit.framework.TestCase#setUp()
     * @throws Exception on error
     */
    protected void setUp() throws Exception {
        super.setUp();

        // init the Hibernate config
        InPro_HibernateUtil.setConfigFile("hibernate_BugHHH2763.cfg.xml");
    }

    public void testHibernateBugHHH2763Case1() {
        System.out.println(">>> Starting TestCase testHibernateBugHHH2763Case1");

        Session session = InPro_HibernateUtil.getNewSession();
        Transaction tx = session.beginTransaction();
        tx.begin();

        InPro_BidirectionalManyToManyLeftSide left1 = new InPro_BidirectionalManyToManyLeftSide(1,
                "Left Side 1");
        InPro_BidirectionalManyToManyRightSide right1 = new InPro_BidirectionalManyToManyRightSide(1,
                "Right Side 1");

        Serializable idLeft1 = session.save(left1);
        Serializable idRight1 = session.save(right1);

        // add a relations to left1
        left1.addLazyRightSide(right1);
        right1.addLeftSide(left1);
        session.saveOrUpdate(left1);

        // flush, commit and close
        session.flush();
        tx.commit();
        InPro_HibernateUtil.closeSession(session);

        System.out.println(">>>>>> reproducing the bug....");
        // update a field of the left side 
        session = InPro_HibernateUtil.getNewSession();
        tx = session.beginTransaction();
        tx.begin();

        // load left side
        left1 = (InPro_BidirectionalManyToManyLeftSide) session.get(InPro_BidirectionalManyToManyLeftSide.class,
                idLeft1);
        System.out.println(">>>>>> left1 was loaded");

        // Update left side
        left1.setName("New name");
        System.out.println(">>>>>> left1.setName done. will flush sesssion");

        // flush, commit and close
        session.flush();  // will raise the exception
        System.out.println(">>>>>> session flushed, starting commit");
        tx.commit();
        System.out.println(">>>>>> tx commited, starting closing session");
        InPro_HibernateUtil.closeSession(session);
        System.out.println(">>>>>> session closed");
    }

    public void testHibernateBugHHH2763Case2() {
        System.out.println(">>> Starting TestCase testHibernateBugHHH2763Case2");

        Session session = InPro_HibernateUtil.getNewSession();

        Transaction tx = session.beginTransaction();
        tx.begin();

        // Create one parent and two children
        InPro_ParentWithLazyCollectionOfChildren parent = new InPro_ParentWithLazyCollectionOfChildren(13,
                "parent");
        InPro_ChildWithCollections child1 = new InPro_ChildWithCollections(55,
                "child1");
        InPro_ChildWithCollections child2 = new InPro_ChildWithCollections(65,
                "child2");

        Set collectionOfValues = new HashSet();
        collectionOfValues.add("CHF");
        collectionOfValues.add("DKK");
        collectionOfValues.add("FLT");

        Set collectionOfSimpleObjects = new HashSet();
        collectionOfSimpleObjects.add(new InPro_SimpleObject(10,
                "simple 10 for Child1"));
        collectionOfSimpleObjects.add(new InPro_SimpleObject(11,
                "simple 11 for Child1"));
        collectionOfSimpleObjects.add(new InPro_SimpleObject(12,
                "simple 12 for Child1"));

        // add collections to child1
        child1.setCollectionOfSimpleObjects(collectionOfSimpleObjects);
        child1.setCollectionOfValues(collectionOfValues);

        // save child1 and child2
        Serializable idChild1 = session.save(child1);
        Serializable idChild2 = session.save(child2);

        Set children = new HashSet();
        children.add(child1);
        children.add(child2);

        // add children to parent
        parent.setChildrenWithCollections(children);

        // save parent
        Serializable idParent = session.save(parent);

        // flush, commit and close session
        session.flush();
        tx.commit();
        InPro_HibernateUtil.closeSession(session);

        // Start a new session
        session = InPro_HibernateUtil.getNewSession();
        tx = session.beginTransaction();
        tx.begin();

        // load parent
        parent = (InPro_ParentWithLazyCollectionOfChildren) session.get(InPro_ParentWithLazyCollectionOfChildren.class,
                idParent);
        System.out.println(">>> about to change parent property");
        parent.setName("new name for parent");

        System.out.println(">>> about to call session.saveOrUpdate(parent);");
        session.saveOrUpdate(parent);

        System.out.println(">>> about to session.flush();");
        session.flush();   // will raise the exception

        System.out.println(">>> about to tx.commit();");
        tx.commit();

        System.out.println(
            ">>> about to InPro_HibernateUtil.closeSession(session);");
        InPro_HibernateUtil.closeSession(session);
    }
}
