package ch.rtc.infra.protok.client;

import java.util.Collection;
import java.util.Iterator;

import org.hibernate.event.PostLoadEvent;
import org.hibernate.event.PostLoadEventListener;
import org.hibernate.event.PostUpdateEvent;
import org.hibernate.event.PostUpdateEventListener;
import org.hibernate.event.PreLoadEvent;
import org.hibernate.event.PreLoadEventListener;
import org.hibernate.event.PreUpdateEvent;
import org.hibernate.event.PreUpdateEventListener;


public class InPro_HibernateBugHHH2763Listener implements PreUpdateEventListener,
    PostUpdateEventListener, PostLoadEventListener, PreLoadEventListener{
    private static final long serialVersionUID = 5073218051277640329L;

    public InPro_HibernateBugHHH2763Listener() {
        System.out.println("-- initializing InPro_HibernateBugHHH2763Listener");
    }

    public void onPostUpdate(PostUpdateEvent event) {
        Object entity = event.getEntity();
        System.out.println("-- onPostUpdate for " +
            entity.getClass().getName());
        return;
    }


    /**
     * {@inheritDoc}
     */
    public boolean onPreUpdate(PreUpdateEvent event) {
        Object entity = event.getEntity();
        System.out.println("-- Entering pre-update for " +
            entity.getClass().getName());
        
        Object[] oldValues = event.getOldState();
        String[] properties = event.getPersister().getPropertyNames();

        // Iterate through all fields of the updated object
        for (int ii = 0; ii < properties.length; ii++) {
            if (oldValues != null && oldValues[ii] instanceof Collection) {
                Collection col = (Collection) oldValues[ii];
                // Hibernate will initialize(load) the n:side of m:n collection,
                // but this will lead to following error later:
                // AssertionFailure:collection [n:side] was not processed
                // by flush()
                 for (Iterator iter = col.iterator(); iter.hasNext();)
                {
                    Object element = (Object) iter.next();
                }
            }
        }
        System.out.println("-- Exiting pre-update for " +
                        entity.getClass().getName());
        return true;
    }

    /**
     * {@inheritDoc}
     */
    public void onPostLoad(PostLoadEvent event)
    {
        Object entity = event.getEntity();
        System.out.println("-- onPostLoad " +
            entity.getClass().getName());
        
    }

    /**
     * {@inheritDoc}
     */
    public void onPreLoad(PreLoadEvent event)
    {
        Object entity = event.getEntity();
        System.out.println("-- onPreLoad " +
            entity.getClass().getName());
    }
    
    
    
}
