package test.hibernate.recurse;

public class D {

	private int valD;
	
	public int getValD() {
		return valD;
	}

	public void setValD(int val) {
		this.valD = val;
	}
	
	private C c;

	public C getC() {
		return c;
	}

	public void setC(C c) {
		this.c = c;
	}
	
}
