package test.hibernate.recurse;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.HSQLDialect;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		// Build configuration
		org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration();
		
		configuration.setProperty(Environment.DRIVER, "org.hsqldb.jdbcDriver");
		configuration.setProperty(Environment.URL, "jdbc:hsqldb:mem:Test");
		configuration.setProperty(Environment.USER, "sa");
		configuration.setProperty(Environment.DIALECT, HSQLDialect.class
				.getName());

		configuration.setProperty(Environment.SHOW_SQL, "true");

		configuration.setProperty(Environment.HBM2DDL_AUTO, "create-drop");

		configuration.addFile("src/test/hibernate/recurse/A.hbm.xml");
		
		// Build Session Factory
		SessionFactory sessionFactory = configuration.buildSessionFactory();

		
		// Create a sample tree A -> B -> C -> D
		// Where D has a parent C
		Session s = sessionFactory.openSession();
		Transaction tx = s.beginTransaction();

		A a = new A();
		B b = new B();
		C c = new C();
		D d = new D();

		a.setB(b);

		b.setC(c);

		c.setD(d);

		// This line sets the parent of d
		d.setC(c);

		s.save(a);

		s.flush();
		tx.commit();
		s.close();

		
		// Try to load the tree A -> B -> C -> D
		s = sessionFactory.openSession();
		tx = s.beginTransaction();
//		try {
			List<A> list = s.createQuery("from " + A.class.getName()).list();
	
			assert list.size() == 1;
	
			A qA = list.get(0);
	
	
			// This line raises the IllegalArgumentException
			// The assertion is not even evaluated.
			assert qA.getB().getC().getD().getC().equals(qA.getB().getC());

			tx.commit();
//		} catch (Throwable t) {
//			tx.rollback();
//			t.printStackTrace();
//		} finally {
			s.close();
//		}

	}

}
