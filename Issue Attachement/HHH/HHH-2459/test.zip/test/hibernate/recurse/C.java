package test.hibernate.recurse;

public class C {

	private int valC;
	
	public int getValC() {
		return valC;
	}

	public void setValC(int val) {
		this.valC = val;
	}
	
	private D d;

	public D getD() {
		return d;
	}

	public void setD(D d) {
		this.d = d;
	}
	
	
}
