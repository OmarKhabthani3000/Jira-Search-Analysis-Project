package test.hibernate.recurse;

public class B {

	private int valB;
	
	public int getValB() {
		return valB;
	}

	public void setValB(int val) {
		this.valB = val;
	}
	
	private C c;

	public C getC() {
		return c;
	}

	public void setC(C c) {
		this.c = c;
	}
	
	
	
}
