package net.batmat.hhh_logback_confreload.java.example;

import net.batmat.hhh4111.Book;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.joran.spi.JoranException;

/**
 *
 */
public class ShowProblemTest {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ShowProblemTest.class);

	@Test
	public void testLoggerConfReloading() throws Exception {
		initHibernate();

		Book b = new Book();
		b.setName("et biiiim");
		b.setWhatever(1254);

		LOGGER.info("Saving first book");
		session.save(b);

		long sleep = 10000;
		LOGGER.debug("Sleeping {} s", (sleep / 1000));
		Thread.sleep(sleep);
		// During the sleep, manually modify the org.hibernate.type from or to
		// trace value to see if it has any impact.
		// For example, start with <logger name="org.hibernate.type"
		// level="trace" />, you'll see the binding logs for the first book.
		// Then, during the sleeping pause, change this value to info, then see
		// that no binding logs will appear.
		//
		// Now, try to do the contrary : start with <logger
		// name="org.hibernate.type" level="info" />
		// During the pause, set it to trace. You'll see that it doesn't have
		// any effect.
		// 
		// Notice that if you start with debug, you obviously then can use the
		// dynamic reconfiguration feature since
		// org.hibernate.type.NullableType.IS_TRACE_ENABLED is true and lets you
		// enter the "if" statements that will delegate to the logging engine.

		LOGGER.info("Reloading logging configuration");
		reloadLoggingConf();

		Book b1 = new Book();
		b1.setName("et boum");
		b1.setWhatever(1540);
		LOGGER.info("Saving first book");
		session.save(b1);
		LOGGER.debug("End");
	}

	private void reloadLoggingConf() {
		LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();

		try {
			JoranConfigurator configurator = new JoranConfigurator();
			configurator.setContext(lc);
			// the context was probably already configured by default
			// configuration
			// rules
			lc.reset();
			configurator.doConfigure(ShowProblemTest.class
					.getResource("/logback-test.xml"));
		} catch (JoranException je) {
			je.printStackTrace();
		}
	}

	private SessionFactory sessionFactory;

	private Session session;

	private void initHibernate() {
		Configuration config = new AnnotationConfiguration();
		config.configure();
		sessionFactory = config.buildSessionFactory();
		session = sessionFactory.openSession();
	}
}
