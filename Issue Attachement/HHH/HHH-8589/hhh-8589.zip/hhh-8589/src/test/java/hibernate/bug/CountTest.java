package hibernate.bug;

import hibernate.bug.model.A;
import hibernate.bug.model.B;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class CountTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        B b1 = new B(1, "1");
        B b2 = new B(2, "2");
        A a1 = new A(1, "1");
        A a2 = new A(2, "2");
        A a3 = new A(3, "3");
        
        a1.setB(b1);
        a2.setB(b2);
        a3.setB(b2);
        
        em.persist(a1);
        em.persist(a2);
        em.persist(a3);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testSimple() {
        EntityManager em = emf.createEntityManager();
       
        // There are only 2 different b values
        Long size = em.createQuery("SELECT COUNT(a.b) FROM A a", Long.class).getSingleResult();
        Assert.assertEquals(2L, size.longValue());
    }
}
