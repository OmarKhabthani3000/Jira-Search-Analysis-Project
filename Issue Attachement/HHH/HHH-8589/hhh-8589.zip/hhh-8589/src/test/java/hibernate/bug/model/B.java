
package hibernate.bug.model;

import java.io.Serializable;
import javax.persistence.Embeddable;

@Embeddable
public class B implements Serializable{

    public Integer bId;
    public String bName;

    public B() {
    }

    public B(Integer id, String name) {
        this.bId = id;
        this.bName = name;
    }

    public Integer getbId() {
        return bId;
    }

    public void setbId(Integer bId) {
        this.bId = bId;
    }

    public String getbName() {
        return bName;
    }

    public void setbName(String bName) {
        this.bName = bName;
    }
}
