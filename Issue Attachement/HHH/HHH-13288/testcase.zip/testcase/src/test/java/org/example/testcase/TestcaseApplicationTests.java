package org.example.testcase;

import static org.junit.Assert.assertEquals;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.transaction.TestTransaction;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class TestcaseApplicationTests {

	@Autowired
	private EntityManager em;

	@Test
	public void testConverterIgnoredInWhere() {

		// create test-data
		SomeEntity entity = new SomeEntity();
		entity.setValue(100);
		em.persist(entity);

		String query = "select e from SomeEntity e where e.value=100";
		// works:
		SomeEntity someEntity = em.createQuery(query, SomeEntity.class).getSingleResult();

		// test with negative value
		someEntity.setValue(-100);
		em.persist(someEntity);
		query = "select e from SomeEntity e where e.value=-100";
		// fails:
		someEntity = em.createQuery(query, SomeEntity.class).getSingleResult();
	}

	@Test
	public void testConverterIgnoredInUpdate() {

		// create test-data
		SomeEntity entity = new SomeEntity();
		entity.setValue(100);
		em.persist(entity);
		em.flush();
		em.clear();

		String query = "update SomeEntity set value=-100";
		int count = em.createQuery(query).executeUpdate();
		assertEquals(1, count);

		SomeEntity result = em.find(SomeEntity.class, entity.getId());
		// fails: value is -50!
		assertEquals(-100, result.getValue());
	}
}
