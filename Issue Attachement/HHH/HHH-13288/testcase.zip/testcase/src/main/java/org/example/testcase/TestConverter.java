package org.example.testcase;

import javax.persistence.AttributeConverter;

public class TestConverter implements AttributeConverter<Integer, Integer> {
    @Override
    public Integer convertToDatabaseColumn(Integer attribute) {
        return attribute * 2;
    }

    @Override
    public Integer convertToEntityAttribute(Integer dbData) {
        return dbData / 2;
    }
}
