To run the test,
> mvn test

The test uses Hibernate.isInitialized() to verify that the fetch joined association is loaded

Results:

- testJPAQuery is successful
- testCriteriaQuery() fails with 'Fetch joined association should be initialized'
  * Note that the query generated is incorrect - failing to include the join

