package support.redhat.entity.association;

import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TEST_CHILD")
public class ChildEntity implements Serializable {

    private static final long serialVersionUID = 7406202066687561557L;

    @Id
    @Column(name = "C_GUID")
    private String guid = UUID.randomUUID().toString();

    @Column(name = "C_VALUE")
    private String value;

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
