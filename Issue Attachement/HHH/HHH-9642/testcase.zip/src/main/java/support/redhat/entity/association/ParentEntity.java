package support.redhat.entity.association;

import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TEST_PARENT")
public class ParentEntity implements Serializable {

    private static final long serialVersionUID = 1726166549874525335L;

    @Id
    @Column(name = "C_GUID")
    private String guid = UUID.randomUUID().toString();

    @Embedded
    private EmbeddedEntity embedded;

    @Column(name = "C_NAME")
    private String name;

    public ParentEntity() {
        embedded = new EmbeddedEntity();
    }

    /**
     * @return the guid
     */
    public String getGuid() {
        return guid;
    }

    /**
     * @param guid the guid to set
     */
    public void setGuid(String guid) {
        this.guid = guid;
    }

    /**
     * @return the embedded
     */
    public EmbeddedEntity getEmbedded() {
        return embedded;
    }

    /**
     * @param embedded the embedded to set
     */
    public void setEmbedded(EmbeddedEntity embedded) {
        this.embedded = embedded;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
}
