package support.redhat.entity.association;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import support.redhat.util.AutoCloser;

import junit.framework.TestCase;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Hibernate;

import support.redhat.entity.association.ParentEntity;
import support.redhat.entity.association.EmbeddedEntity_;
import support.redhat.entity.association.ParentEntity_;

public class TestHibernate extends TestCase {
	private EntityManager em;

	private final AutoCloser m_closer = new AutoCloser();

	@Override
	protected void setUp() throws Exception {
		try {
			// Configures settings from annotations + persistence.xml
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("TEST");
			m_closer.push(emf);
			em = emf.createEntityManager();
			m_closer.push(em);
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	@Override
	protected void tearDown() throws Exception {
		if (em != null) {
			m_closer.close();
			em = null;
		}
	}

	public void testCriteriaQuery() throws Exception {
		CriteriaBuilder cb = em.getCriteriaBuilder();

		CriteriaQuery<ParentEntity> cq = cb.createQuery(ParentEntity.class);
		Root<ParentEntity> root = cq.from(ParentEntity.class);

		root.fetch(ParentEntity_.embedded).fetch(EmbeddedEntity_.children);
		cq.where(cb.equal(root.get(ParentEntity_.guid), "P1"));

		TypedQuery<ParentEntity> typeQuery = em.createQuery(cq);

		System.out.println("############## JPQL ################################################################");
		System.out.println(typeQuery.unwrap(org.hibernate.Query.class).getQueryString());
		System.out.println("##############@@@@@@################################################################");

		System.out.println("############## SQL #################################################################");
		ParentEntity result = typeQuery.getSingleResult();
		System.out.println("##############@@@@@@################################################################");
		assertTrue("Fetch joined association should be initialized",
			Hibernate.isInitialized(result.getEmbedded().getChildren()));

		assertNotNull(result.getEmbedded().getChildren());
		// The below generates an extra implicit query to get the children that should have been join fetched above
		assertEquals(6, result.getEmbedded().getChildren().size());
	}

	public void testJPAQuery() {
		TypedQuery<ParentEntity> typeQuery = em.createQuery("SELECT parent FROM ParentEntity as parent "
			+ "LEFT JOIN FETCH parent.embedded.children "
			+ "WHERE parent.guid= 'P1'", ParentEntity.class);

		System.out.println("############## JPQL ################################################################");
		System.out.println(typeQuery.unwrap(org.hibernate.Query.class).getQueryString());
		System.out.println("##############@@@@@@################################################################");

		System.out.println("############## SQL #################################################################");
		ParentEntity result = typeQuery.getSingleResult();
		System.out.println("##############@@@@@@################################################################");
		assertTrue("Fetch joined association should be initialized",
			Hibernate.isInitialized(result.getEmbedded().getChildren()));

		assertNotNull(result.getEmbedded().getChildren());
		assertEquals(6, result.getEmbedded().getChildren().size());
	}
}
