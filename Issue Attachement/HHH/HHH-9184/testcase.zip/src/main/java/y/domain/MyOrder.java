package y.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

/**
 * This file will be overwritten the next time it is generated from g9.
 */
public class MyOrder implements Serializable {

    /** Serial Version UID. */
    private static final long serialVersionUID = 1L;

    /**
     * The optimistic lock. Available via standard bean get/set operations.
     */
    private Serializable lockFlag;

    /**
     * Access method for the lockFlag property.
     *
     * @return the current value of the lockFlag property
     */
    public Serializable getLockFlag() {
        return lockFlag;
    }

    /**
     * Sets the value of the lockFlag property.
     *
     * @param aLockFlag the new value of the lockFlag property
     */
    public void setLockFlag(Serializable aLockFlag) {
        lockFlag = aLockFlag;
    }

    private int orderNo;
    private Date orderDate;
    private Customer customer;
    private Set<OrderLine> orderLines;

    /**
     * Access method for orderNo.
     *
     * @return the current value of orderNo
     */
    public int getOrderNo() {
        return orderNo;
    }

    /**
     * Setter method for orderNo.
     *
     * @param aOrderNo the new value for orderNo
     */
    public void setOrderNo(int aOrderNo) {
        orderNo = aOrderNo;
    }

    /**
     * Access method for orderDate.
     *
     * @return the current value of orderDate
     */
    public Date getOrderDate() {
        return orderDate;
    }

    /**
     * Setter method for orderDate.
     *
     * @param aOrderDate the new value for orderDate
     */
    public void setOrderDate(Date aOrderDate) {
        orderDate = aOrderDate;
    }

    /**
     * Access method for customer.
     *
     * @return the current value of customer
     */
    public Customer getCustomer() {
        return customer;
    }

    /**
     * Setter method for customer.
     *
     * @param aCustomer the new value for customer
     */
    public void setCustomer(Customer aCustomer) {
        customer = aCustomer;
    }

    /**
     * Access method for orderLines.
     *
     * @return the current value of orderLines
     */
    public Set<OrderLine> getOrderLines() {
        return orderLines;
    }

    /**
     * Setter method for orderLines.
     *
     * @param aOrderLines the new value for orderLines
     */
    public void setOrderLines(Set<OrderLine> aOrderLines) {
        orderLines = aOrderLines;
    }

    /** Temporary value holder for group key fragment customerCustomerId */
    private transient int tempCustomerCustomerId;

    /**
     * Gets the key fragment customerId for member customer.
     * If this.customer is null, a temporary stored value for the key
     * fragment will be returned. The temporary value is set by setCustomerCustomerId.
     * This behavior is required by some persistence libraries to allow
     * fetching of objects in arbitrary order.
     *
     * @return Current (or temporary) value of the key fragment
     * @see Customer
     */
    public int getCustomerCustomerId() {
        return (getCustomer() == null ? tempCustomerCustomerId : getCustomer().getCustomerId());
    }

    /**
     * Sets the key fragment customerId from member customer.
     * If this.customer is null, the passed value will be temporary
     * stored, and returned by subsequent calls to getCustomerCustomerId.
     * This behaviour is required by some persistence libraries to allow
     * fetching of objects in arbitrary order.
     *
     * @param aCustomerId New value for the key fragment
     * @see Customer
     */
    public void setCustomerCustomerId(int aCustomerId) {
        if (getCustomer() == null) {
            tempCustomerCustomerId = aCustomerId;
        } else {
            getCustomer().setCustomerId(aCustomerId);
        }
    }

    /**
     * Compares the key for this instance with another MyOrder.
     *
     * @param other The object to compare to
     * @return True if other object is instance of class MyOrder and the key objects are equal
     */
    private boolean equalKeys(Object other) {
        if (this==other) {
            return true;
        }
        if (!(other instanceof MyOrder)) {
            return false;
        }
        MyOrder that = (MyOrder) other;
        if (this.getCustomerCustomerId() != that.getCustomerCustomerId()) {
            return false;
        }
        if (this.getOrderNo() != that.getOrderNo()) {
            return false;
        }
        return true;
    }

    /**
     * Compares this instance with another MyOrder.
     *
     * @param other The object to compare to
     * @return True if the objects are the same
     */
    @Override
    public boolean equals(Object other) {
        return this.equalKeys(other) && ((MyOrder)other).equalKeys(this);
    }

    /**
     * Returns a hash code for this instance.
     *
     * @return Hash code
     */
    @Override
    public int hashCode() {
        int i;
        int result = 17;
        i = getCustomerCustomerId();
        result = 37*result + i;
        i = getOrderNo();
        result = 37*result + i;
        return result;
    }

    /**
     * Returns a debug-friendly String representation of this instance.
     *
     * @return String representation of this instance
     */
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer("[MyOrder |");
        sb.append(" customerCustomerId=").append(getCustomerCustomerId());
        sb.append(" orderNo=").append(getOrderNo());
        sb.append("]");
        return sb.toString();
    }

}
