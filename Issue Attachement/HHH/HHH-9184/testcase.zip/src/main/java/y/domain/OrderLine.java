package y.domain;

import java.io.Serializable;

/**
 * This file will be overwritten the next time it is generated from g9.
 */
public class OrderLine implements Serializable {

    /** Serial Version UID. */
    private static final long serialVersionUID = 1L;

    /**
     * The optimistic lock. Available via standard bean get/set operations.
     */
    private Serializable lockFlag;

    /**
     * Access method for the lockFlag property.
     *
     * @return the current value of the lockFlag property
     */
    public Serializable getLockFlag() {
        return lockFlag;
    }

    /**
     * Sets the value of the lockFlag property.
     *
     * @param aLockFlag the new value of the lockFlag property
     */
    public void setLockFlag(Serializable aLockFlag) {
        lockFlag = aLockFlag;
    }

    private int lineId;
    private String productName;
    private MyOrder order;

    /**
     * Access method for lineId.
     *
     * @return the current value of lineId
     */
    public int getLineId() {
        return lineId;
    }

    /**
     * Setter method for lineId.
     *
     * @param aLineId the new value for lineId
     */
    public void setLineId(int aLineId) {
        lineId = aLineId;
    }

    /**
     * Access method for productName.
     *
     * @return the current value of productName
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Setter method for productName.
     *
     * @param aProductName the new value for productName
     */
    public void setProductName(String aProductName) {
        productName = aProductName;
    }

    /**
     * Access method for order.
     *
     * @return the current value of order
     */
    public MyOrder getOrder() {
        return order;
    }

    /**
     * Setter method for order.
     *
     * @param aOrder the new value for order
     */
    public void setOrder(MyOrder aOrder) {
        order = aOrder;
    }

    /**
     * Compares the key for this instance with another OrderLine.
     *
     * @param other The object to compare to
     * @return True if other object is instance of class OrderLine and the key objects are equal
     */
    private boolean equalKeys(Object other) {
        if (this==other) {
            return true;
        }
        if (!(other instanceof OrderLine)) {
            return false;
        }
        OrderLine that = (OrderLine) other;
        if (this.getLineId() != that.getLineId()) {
            return false;
        }
        return true;
    }

    /**
     * Compares this instance with another OrderLine.
     *
     * @param other The object to compare to
     * @return True if the objects are the same
     */
    @Override
    public boolean equals(Object other) {
        return this.equalKeys(other) && ((OrderLine)other).equalKeys(this);
    }

    /**
     * Returns a hash code for this instance.
     *
     * @return Hash code
     */
    @Override
    public int hashCode() {
        int i;
        int result = 17;
        i = getLineId();
        result = 37*result + i;
        return result;
    }

    /**
     * Returns a debug-friendly String representation of this instance.
     *
     * @return String representation of this instance
     */
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer("[OrderLine |");
        sb.append(" lineId=").append(getLineId());
        sb.append("]");
        return sb.toString();
    }

}
