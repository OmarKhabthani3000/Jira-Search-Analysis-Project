package y.domain;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.junit.Assert;
import org.junit.Test;

public class TestOrderLine {

	final static String DATA_FILE = "src/test/data/object.data";

	@Test
	@SuppressWarnings("unchecked")
	public void testRead() {
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(DATA_FILE));
			List<OrderLine> lines = (List<OrderLine>) ois.readObject();
			ois.close();

			Assert.assertEquals(3, lines.size());

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (InvalidObjectException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testWriteFromCode() {
		List<OrderLine> lines = loadFromCode();
		writeData(lines);
	}
	
	@Test
	public void testWriteFromDb() {
		List<OrderLine> lines = loadFromDb();
        writeData(lines);
	}

	private void writeData(List<OrderLine> lines) {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE));
			oos.writeObject(lines);
			oos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
	private List<OrderLine> loadFromDb() {
		Session session = getSession();
        session.beginTransaction();

        List<OrderLine> lines = (List<OrderLine>) session.createCriteria(OrderLine.class).list();

        session.getTransaction().commit();
        session.disconnect();
		return lines;
	}

	@SuppressWarnings("deprecation")
	private Session getSession() {
		Configuration cfg = new Configuration()
		 .addResource("y/domain/Customer.hbm.xml")
		 .addResource("y/domain/MyOrder.hbm.xml")
		 .addResource("y/domain/OrderLine.hbm.xml")
		 .setProperty("hibernate.connection.username", "y_user")
		 .setProperty("hibernate.connection.password", "y_pwd")
		 .setProperty("hibernate.connection.pool_size", "1")
		 .setProperty("hibernate.connection.driver_class", "com.mysql.jdbc.Driver")
		 .setProperty("hibernate.connection.url", "jdbc:mysql://localhost:3306/y")
		 .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
		return cfg.buildSessionFactory().openSession();
	}

	private List<OrderLine> loadFromCode() {
		MyOrder order = new MyOrder();
		order.setOrderNo(1);
		order.setCustomerCustomerId(1);
		order.setOrderDate(new Date());
		order.setLockFlag(1);
		order.setOrderLines(new HashSet<OrderLine>());

		OrderLine line = new OrderLine();
		line.setLineId(1);
		line.setProductName("P1");
		line.setLockFlag(1);
		line.setOrder(order);
		order.getOrderLines().add(line);

		line = new OrderLine();
		line.setLineId(2);
		line.setProductName("P2");
		line.setLockFlag(1);
		line.setOrder(order);
		order.getOrderLines().add(line);

		line = new OrderLine();
		line.setLineId(3);
		line.setProductName("P3");
		line.setLockFlag(1);
		line.setOrder(order);
		order.getOrderLines().add(line);
		
		List<OrderLine> lines = new ArrayList<OrderLine>();
		lines.addAll(order.getOrderLines());
		return lines;
	}

}
