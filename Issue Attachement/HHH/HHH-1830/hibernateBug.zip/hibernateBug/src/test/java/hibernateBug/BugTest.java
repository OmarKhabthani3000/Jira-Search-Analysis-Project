package hibernateBug;

import junit.framework.TestCase;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class BugTest extends TestCase {
	public void testBug() {
		SessionFactory sessionFactory = new Configuration().configure()
				.buildSessionFactory();
		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		Query q = session.createQuery("SELECT a.id FROM A a JOIN a.bs bs, B b "
				+ "WHERE b IN ELEMENTS(bs) AND b.c.s = 'foo'");
		q.uniqueResult();
		session.getTransaction().commit();
	}
}
