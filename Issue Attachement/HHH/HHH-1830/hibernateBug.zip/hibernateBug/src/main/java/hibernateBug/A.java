package hibernateBug;

import java.util.HashSet;
import java.util.Set;

public class A {
	private Set<B> bs = new HashSet<B>();
	private Long id;

	public Set<B> getBs() {
		return bs;
	}
	public Long getId() {
		return id;
	}
	public void setBs(Set<B> bs) {
		this.bs = bs;
	}
	public void setId(Long id) {
		this.id = id;
	}
}
