package hibernateBug;

public class B {
	private C c;
	private Long id;

	public C getC() {
		return c;
	}
	public Long getId() {
		return id;
	}
	public void setC(C c) {
		this.c = c;
	}
	public void setId(Long id) {
		this.id = id;
	}
}
