package br.hailtondecastro.hibernate.hql.internal.ast.util;

import org.hibernate.engine.internal.JoinSequence;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.hql.internal.ast.util.SessionFactoryHelper;

import br.hailtondecastro.hibernate.engine.internal.JoinSequenceWaHhh1830;

public class SessionFactoryHelperWaHhh1830 extends SessionFactoryHelper {

    public SessionFactoryHelperWaHhh1830(SessionFactoryImplementor sfi) {
        super(sfi);
        // TODO Auto-generated constructor stub
    }
    
    @Override
    public JoinSequence createJoinSequence() {
        return new JoinSequenceWaHhh1830(this.getFactory());
    }   
}
