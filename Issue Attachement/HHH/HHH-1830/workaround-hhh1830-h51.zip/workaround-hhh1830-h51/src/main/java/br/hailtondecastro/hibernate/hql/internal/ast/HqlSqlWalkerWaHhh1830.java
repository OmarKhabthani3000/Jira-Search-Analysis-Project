package br.hailtondecastro.hibernate.hql.internal.ast;

import java.util.Map;

import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.hql.internal.ast.HqlParser;
import org.hibernate.hql.internal.ast.HqlSqlWalker;
import org.hibernate.hql.internal.ast.QueryTranslatorImpl;

import br.hailtondecastro.hibernate.hql.internal.ast.util.SessionFactoryHelperWaHhh1830;

public class HqlSqlWalkerWaHhh1830 extends HqlSqlWalker {

    public HqlSqlWalkerWaHhh1830(QueryTranslatorImpl qti,
            SessionFactoryImplementor sfi, HqlParser parser,
            Map tokenReplacements, String collectionRole) {
        super(qti, sfi, parser, tokenReplacements, collectionRole);
        ReflectionUtilWaHhh1830.superSetField(this, "sessionFactoryHelper",
                new SessionFactoryHelperWaHhh1830(sfi));
        ReflectionUtilWaHhh1830.superSetField(this, "sessionFactoryHelper",
                new SessionFactoryHelperWaHhh1830(sfi));
    }

}
