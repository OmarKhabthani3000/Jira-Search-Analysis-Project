package br.hailtondecastro.hibernate.hql.internal.ast;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.MappingException;
import org.hibernate.QueryException;
import org.hibernate.engine.query.spi.EntityGraphQueryHint;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.hql.internal.antlr.SqlTokenTypes;
import org.hibernate.hql.internal.ast.HqlParser;
import org.hibernate.hql.internal.ast.HqlSqlWalker;
import org.hibernate.hql.internal.ast.QuerySyntaxException;
import org.hibernate.hql.internal.ast.QueryTranslatorImpl;
import org.hibernate.hql.internal.ast.tree.QueryNode;
import org.hibernate.hql.internal.ast.tree.Statement;
import org.hibernate.hql.internal.ast.util.ASTPrinter;
import org.hibernate.loader.hql.QueryLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import antlr.ANTLRException;
import antlr.RecognitionException;
import antlr.collections.AST;

public class QueryTranslatorImplWaHhh1830 extends QueryTranslatorImpl {
    private static final Logger AST_LOG = LoggerFactory
            .getLogger("org.hibernate.hql.ast.AST");

    private static final Logger LOG = LoggerFactory
            .getLogger(QueryTranslatorImplWaHhh1830.class);

    @SuppressWarnings("rawtypes")
    public QueryTranslatorImplWaHhh1830(String queryIdentifier, String query,
            Map enabledFilters, SessionFactoryImplementor factory) {
        super(queryIdentifier, query, enabledFilters, factory);
    }

    public QueryTranslatorImplWaHhh1830(String queryIdentifier, String query,
            Map enabledFilters, SessionFactoryImplementor factory,
            EntityGraphQueryHint entityGraphQueryHint) {
        super(queryIdentifier, query, enabledFilters, factory, entityGraphQueryHint);
    }

    @SuppressWarnings("rawtypes")
    @Override
    public void compile(Map replacements, boolean shallow)
            throws QueryException, MappingException {
        doCompile(replacements, shallow, null);
    }

    @SuppressWarnings("rawtypes")
    private synchronized void doCompile(Map replacements, boolean shallow,
            String collectionRole) {
        // If the query is already compiled, skip the compilation.
        if ( ReflectionUtilWaHhh1830.superGetField(this, "compiled") ) {
            LOG.debug( "compile() : The query is already compiled, skipping..." );
            return;
        }

        // Remember the parameters for the compilation.
        ReflectionUtilWaHhh1830.superSetField(this, "tokenReplacements", replacements);
        if ( ReflectionUtilWaHhh1830.superGetField(this, "thistokenReplacements") == null ) {
            ReflectionUtilWaHhh1830.superSetField(this, "tokenReplacements", new HashMap());
        }
        ReflectionUtilWaHhh1830.superSetField(this, "shallowQuery", shallow);

        try {
            // PHASE 1 : Parse the HQL into an AST.
            final HqlParser parser = ReflectionUtilWaHhh1830.superRun(this, "parse", true);

            // PHASE 2 : Analyze the HQL AST, and produce an SQL AST.
            final HqlSqlWalker w = analyze( parser, collectionRole );

            ReflectionUtilWaHhh1830.superSetField(this, "sqlAst", (Statement) w.getAST());

            // at some point the generate phase needs to be moved out of here,
            // because a single object-level DML might spawn multiple SQL DML
            // command executions.
            //
            // Possible to just move the sql generation for dml stuff, but for
            // consistency-sake probably best to just move responsiblity for
            // the generation phase completely into the delegates
            // (QueryLoader/StatementExecutor) themselves.  Also, not sure why
            // QueryLoader currently even has a dependency on this at all; does
            // it need it?  Ideally like to see the walker itself given to the delegates directly...

            if ( ((Statement)ReflectionUtilWaHhh1830.superGetField(this, "sqlAst")).needsExecutor() ) {
                ReflectionUtilWaHhh1830.superSetField(this, "statementExecutor",
                        ReflectionUtilWaHhh1830.superRun(this,
                                "buildAppropriateStatementExecutor", w));
            }
            else {
                // PHASE 3 : Generate the SQL.
                ReflectionUtilWaHhh1830.superRun(this, "generate",
                        (QueryNode) ReflectionUtilWaHhh1830.superGetField(this,
                                "sqlAst"));
                ReflectionUtilWaHhh1830.superSetField(this, "queryLoader",
                        new QueryLoader(this,
                                (SessionFactoryImplementor) ReflectionUtilWaHhh1830
                                        .superGetField(this, "factory"),
                                w.getSelectClause()));
            }

            ReflectionUtilWaHhh1830.superSetField(this, "compiled", true);
        }
        catch ( QueryException qe ) {
            if ( qe.getQueryString() == null ) {
                throw qe.wrapWithQueryString( this.getQueryString() );
            }
            else {
                throw qe;
            }
        }
        catch ( RecognitionException e ) {
            // we do not actually propagate ANTLRExceptions as a cause, so
            // log it here for diagnostic purposes
            LOG.trace( "Converted antlr.RecognitionException", e );
            throw QuerySyntaxException.convert( e, this.getQueryString() );
        }
        catch ( ANTLRException e ) {
            // we do not actually propagate ANTLRExceptions as a cause, so
            // log it here for diagnostic purposes
            LOG.trace( "Converted antlr.ANTLRException", e );
            throw new QueryException( e.getMessage(), this.getQueryString() );
        }

        //only needed during compilation phase...
        ReflectionUtilWaHhh1830.superSetField(this, "enabledFilters", null);

    }
    
    private static final ASTPrinter SQL_TOKEN_PRINTER = new ASTPrinter( SqlTokenTypes.class );

    private HqlSqlWalker analyze(HqlParser parser, String collectionRole) throws QueryException, RecognitionException {
        @SuppressWarnings("rawtypes")
        final HqlSqlWalker w = new HqlSqlWalkerWaHhh1830(this,
                (SessionFactoryImplementor) ReflectionUtilWaHhh1830
                        .superGetField(this, "factory"),
                parser, (Map) ReflectionUtilWaHhh1830.superGetField(this,
                        "tokenReplacements"),
                collectionRole);
        final AST hqlAst = parser.getAST();

        // Transform the tree.
        w.statement( hqlAst );

        if ( LOG.isDebugEnabled() ) {
            LOG.debug( SQL_TOKEN_PRINTER.showAsString( w.getAST(), "--- SQL AST ---" ) );
        }

        w.getParseErrorHandler().throwQueryException();

        return w;
    }
}
