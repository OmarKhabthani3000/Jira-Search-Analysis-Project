package org.hibernate.hql.internal.ast.tree;

import java.text.MessageFormat;

import org.hibernate.persister.entity.EntityPersister;
import org.hibernate.type.EntityType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.hailtondecastro.hibernate.hql.internal.ast.ReflectionUtilWaHhh1830;

public class FromElementWaHhh1830 extends FromElement {

    private static final Logger LOG = LoggerFactory
            .getLogger(FromElementWaHhh1830.class);

    @Override
    protected void doInitialize(FromClause fromClause, String tableAlias,
            String className, String classAlias, EntityPersister persister,
            EntityType type) {
//        if ( initialized ) {
//            throw new IllegalStateException( "Already initialized!!" );
//        }
//        this.fromClause = fromClause;
//        this.tableAlias = tableAlias;
//        this.className = className;
//        this.classAlias = classAlias;
//        this.elementType = new FromElementType( this, persister, type );
        // Register the FromElement with the FROM clause, now that we have the names and aliases.
        fromClause.registerFromElement( this );
        LOG.debug( MessageFormat.format("{0} : {1} ({2}) -> {3}", fromClause, className, classAlias == null ? "<no alias>" : classAlias, tableAlias ));
        
        
        if (ReflectionUtilWaHhh1830.superGetField(this, "initialized")) {
            throw new IllegalStateException( "Already initialized!!" );
        }
        ReflectionUtilWaHhh1830.superSetField(this, "fromClause", fromClause);
        ReflectionUtilWaHhh1830.superSetField(this, "tableAlias", tableAlias);
        ReflectionUtilWaHhh1830.superSetField(this, "className", className);
        ReflectionUtilWaHhh1830.superSetField(this, "classAlias", classAlias);
        ReflectionUtilWaHhh1830.superSetField(this, "elementType",
                new FromElementTypeWaHhh1830(this, persister, type));
        // Register the FromElement with the FROM clause, now that we have
        // the
        // names and aliases.
        fromClause.registerFromElement(this);
        LOG.debug(MessageFormat.format( "{0} : {1} ({2}) -> {3}", fromClause, className, classAlias == null ? "<no alias>" : classAlias, tableAlias ));
    }
}
