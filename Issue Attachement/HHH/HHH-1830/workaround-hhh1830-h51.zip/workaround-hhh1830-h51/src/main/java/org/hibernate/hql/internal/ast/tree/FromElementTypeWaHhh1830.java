package org.hibernate.hql.internal.ast.tree;

import java.util.Map;

import org.hibernate.hql.internal.CollectionProperties;
import org.hibernate.hql.internal.CollectionSubqueryFactory;
import org.hibernate.hql.internal.antlr.HqlSqlTokenTypes;
import org.hibernate.hql.internal.ast.tree.FromElement;
import org.hibernate.internal.util.collections.ArrayHelper;
import org.hibernate.persister.entity.EntityPersister;
import org.hibernate.persister.entity.PropertyMapping;
import org.hibernate.type.EntityType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.hailtondecastro.hibernate.engine.internal.JoinSequenceWaHhh1830;
import br.hailtondecastro.hibernate.hql.internal.ast.ReflectionUtilWaHhh1830;

public class FromElementTypeWaHhh1830 extends FromElementType {

    private static final Logger log = LoggerFactory
            .getLogger(FromElementTypeWaHhh1830.class);

    protected FromElementTypeWaHhh1830(FromElement fromElement) {
        super(fromElement);
    }

    public FromElementTypeWaHhh1830(FromElement fromElement,
            EntityPersister persister, EntityType entityType) {
        super(fromElement, persister, entityType);
    }

    @Override
    String[] toColumns(String tableAlias, String path, boolean inSelect,
            boolean forceAlias) {
        ReflectionUtilWaHhh1830.superRun(this, "checkInitialized");
        PropertyMapping propertyMapping = getPropertyMapping(path);
        // If this from element is a collection and the path is a collection
        // property (maxIndex, etc.) then
        // generate a sub-query.
        //
        // NOTE : in the case of this being a collection property in the
        // select, not generating the subquery
        // will not generally work. The specific cases I am thinking about
        // are the minIndex, maxIndex
        // (most likely minElement, maxElement as well) cases.
        // todo : if ^^ is the case we should thrown an exception here
        // rather than waiting for the sql error
        // if the dialect supports select-clause subqueries we could go
        // ahead and generate the subquery also
        if (!inSelect
                && ReflectionUtilWaHhh1830.superGetField(this,
                        "queryableCollection") != null
                && CollectionProperties.isCollectionProperty(path)) {
            Map enabledFilters = ((FromElement) ReflectionUtilWaHhh1830
                    .superGetField(this, "fromElement")).getWalker()
                            .getEnabledFilters();
            String subquery = CollectionSubqueryFactory
                    .createCollectionSubquery(
                            ((JoinSequenceWaHhh1830) ReflectionUtilWaHhh1830
                                    .superGetField(this, "joinSequence"))
                                            .copyForCollectionProperty()
                                            .setUseThetaStyle(true),
                            enabledFilters,
                            propertyMapping.toColumns(tableAlias, path));
            if (log.isDebugEnabled()) {
                log.debug("toColumns(" + tableAlias + "," + path
                        + ") : subquery = " + subquery);
            }
            return new String[] { "(" + subquery + ")" };
        } else {
            if (forceAlias) {
                return propertyMapping.toColumns(tableAlias, path);
            } else if (((FromElement) ReflectionUtilWaHhh1830
                    .superGetField(this, "fromElement")).getWalker()
                            .getStatementType() == HqlSqlTokenTypes.SELECT) {
                return propertyMapping.toColumns(tableAlias, path);
            } else if (((FromElement) ReflectionUtilWaHhh1830
                    .superGetField(this, "fromElement")).getWalker()
                            .getCurrentClauseType() == HqlSqlTokenTypes.SELECT) {
                return propertyMapping.toColumns(tableAlias, path);
            } else if (((FromElement) ReflectionUtilWaHhh1830
                    .superGetField(this, "fromElement")).getWalker()
                            .isSubQuery()) {
                // for a subquery, the alias to use depends on a few things
                // (we
                // already know this is not an overall SELECT):
                // 1) if this FROM_ELEMENT represents a correlation to the
                // outer-most query
                // A) if the outer query represents a multi-table
                // persister, we need to use the given alias
                // in anticipation of one of the multi-table
                // executors being used (as this subquery will
                // actually be used in the "id select" phase
                // of that multi-table executor)
                // B) otherwise, we need to use the persister's
                // table name as the column qualification
                // 2) otherwise (not correlated), use the given alias
                if (ReflectionUtilWaHhh1830.superRun(this, "isCorrelation")) {
                    if (ReflectionUtilWaHhh1830.superRun(this, "isMultiTable")) {
                        return propertyMapping.toColumns(tableAlias, path);
                    } else {
                        return propertyMapping.toColumns((String) ReflectionUtilWaHhh1830.superRun(this, "extractTableName"), path);
                    }
                } else {
                    return propertyMapping.toColumns(tableAlias, path);
                }
            } else {
                String[] columns = propertyMapping.toColumns(path);
                log.trace("Using non-qualified column reference [" + path
                        + " -> (" + ArrayHelper.toString(columns) + ")]");
                return columns;
            }
        }
    }
}
