package br.hailtondecastro.hibernate.hql.ast;

import java.util.Map;

import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.hql.FilterTranslator;
import org.hibernate.hql.QueryTranslator;
import org.hibernate.hql.QueryTranslatorFactory;
import org.hibernate.hql.ast.ASTQueryTranslatorFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ASTQueryTranslatorFactoryWaHhh1830 implements QueryTranslatorFactory {

    private static final Logger log = LoggerFactory.getLogger( ASTQueryTranslatorFactory.class );

    public ASTQueryTranslatorFactoryWaHhh1830() {
        log.info( "Using ASTQueryTranslatorFactory" );
    }

    /**
     * @see QueryTranslatorFactory#createQueryTranslator
     */
    public QueryTranslator createQueryTranslator(
            String queryIdentifier,
            String queryString,
            Map filters,
            SessionFactoryImplementor factory) {
        return new QueryTranslatorImplWaHhh1830( queryIdentifier, queryString, filters, factory );
    }

    /**
     * @see QueryTranslatorFactory#createFilterTranslator
     */
    public FilterTranslator createFilterTranslator(
            String queryIdentifier,
            String queryString,
            Map filters,
            SessionFactoryImplementor factory) {
        return new QueryTranslatorImplWaHhh1830( queryIdentifier, queryString, filters, factory );
    }

}
