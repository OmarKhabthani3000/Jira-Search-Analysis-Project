package br.hailtondecastro.hibernate.hql.ast;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.MappingException;
import org.hibernate.QueryException;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.hql.antlr.SqlTokenTypes;
import org.hibernate.hql.ast.HqlParser;
import org.hibernate.hql.ast.HqlSqlWalker;
import org.hibernate.hql.ast.QuerySyntaxException;
import org.hibernate.hql.ast.QueryTranslatorImpl;
import org.hibernate.hql.ast.tree.Statement;
import org.hibernate.hql.ast.util.ASTPrinter;
import org.hibernate.loader.hql.QueryLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import antlr.ANTLRException;
import antlr.RecognitionException;
import antlr.collections.AST;

public class QueryTranslatorImplWaHhh1830 extends QueryTranslatorImpl {
    private static final Logger AST_LOG = LoggerFactory
            .getLogger("org.hibernate.hql.ast.AST");

    private static final Logger log = LoggerFactory
            .getLogger(QueryTranslatorImplWaHhh1830.class);

    public QueryTranslatorImplWaHhh1830(String queryIdentifier, String query,
            Map enabledFilters, SessionFactoryImplementor factory) {
        super(queryIdentifier, query, enabledFilters, factory);
    }

    @Override
    public void compile(Map replacements, boolean shallow)
            throws QueryException, MappingException {
        doCompile(replacements, shallow, null);
    }

    private synchronized void doCompile(Map replacements, boolean shallow,
            String collectionRole) {
        // If the query is already compiled, skip the compilation.
        if ((Boolean) ReflectionUtilWaHhh1830.superGetField(this, "compiled")) {
            if (log.isDebugEnabled()) {
                log.debug(
                        "compile() : The query is already compiled, skipping...");
            }
            return;
        }

        // Remember the parameters for the compilation.
        ReflectionUtilWaHhh1830.superSetField(this, "tokenReplacements",
                replacements);
        if (ReflectionUtilWaHhh1830.superGetField(this,
                "tokenReplacements") == null) {
            ReflectionUtilWaHhh1830.superSetField(this, "tokenReplacements",
                    new HashMap());
        }
        ReflectionUtilWaHhh1830.superSetField(this, "shallowQuery", shallow);

        try {
            // PHASE 1 : Parse the HQL into an AST.
            HqlParser parser = ReflectionUtilWaHhh1830.superRun(this, "parse", true);

            // PHASE 2 : Analyze the HQL AST, and produce an SQL AST.
            HqlSqlWalker w = analyze(parser, collectionRole);

            ReflectionUtilWaHhh1830.superSetField(this, "sqlAst",
                    (Statement) w.getAST());

            // at some point the generate phase needs to be moved out of
            // here,
            // because a single object-level DML might spawn multiple SQL
            // DML
            // command executions.
            //
            // Possible to just move the sql generation for dml stuff, but
            // for
            // consistency-sake probably best to just move responsiblity for
            // the generation phase completely into the delegates
            // (QueryLoader/StatementExecutor) themselves. Also, not sure
            // why
            // QueryLoader currently even has a dependency on this at all;
            // does
            // it need it? Ideally like to see the walker itself given to
            // the delegates directly...

            if (((Statement) ReflectionUtilWaHhh1830.superGetField(this,
                    "sqlAst")).needsExecutor()) {
                ReflectionUtilWaHhh1830.superSetField(this, "statementExecutor",
                        ReflectionUtilWaHhh1830.superRun(this,
                                "buildAppropriateStatementExecutor", w));
            } else {
                // PHASE 3 : Generate the SQL.
                ReflectionUtilWaHhh1830.superRun(this, "generate",
                        ReflectionUtilWaHhh1830.superGetField(this, "sqlAst"));
                ReflectionUtilWaHhh1830.superSetField(this, "queryLoader",
                        new QueryLoader(this,
                                (SessionFactoryImplementor) ReflectionUtilWaHhh1830
                                        .superGetField(this, "factory"),
                                w.getSelectClause()));
            }

            ReflectionUtilWaHhh1830.superSetField(this, "compiled", true);
        } catch (QueryException qe) {
            qe.setQueryString((String) ReflectionUtilWaHhh1830
                    .superGetField(this, "hql"));
            throw qe;
        } catch (RecognitionException e) {
            // we do not actually propogate ANTLRExceptions as a cause, so
            // log it here for diagnostic purposes
            if (log.isTraceEnabled()) {
                log.trace("converted antlr.RecognitionException", e);
            }
            throw QuerySyntaxException.convert(e,
                    (String) ReflectionUtilWaHhh1830.superGetField(this,
                            "hql"));
        } catch (ANTLRException e) {
            // we do not actually propogate ANTLRExceptions as a cause, so
            // log it here for diagnostic purposes
            if (log.isTraceEnabled()) {
                log.trace("converted antlr.ANTLRException", e);
            }
            throw new QueryException(e.getMessage(),
                    (String) ReflectionUtilWaHhh1830.superGetField(this,
                            "hql"));
        }

        ReflectionUtilWaHhh1830.superSetField(this, "enabledFilters", null);// only
        // needed
        // during
        // compilation
        // phase...

    }

    private HqlSqlWalker analyze(HqlParser parser, String collectionRole)
            throws QueryException, RecognitionException {
        HqlSqlWalker w = new HqlSqlWalkerWaHhh1830(this,
                (SessionFactoryImplementor) ReflectionUtilWaHhh1830
                        .superGetField(this, "factory"),
                parser, (Map) ReflectionUtilWaHhh1830.superGetField(this,
                        "tokenReplacements"),
                collectionRole);

        // HHH-1830
        w.setASTFactory(new SqlASTFactoryWaHhh1830(w));

        AST hqlAst = parser.getAST();

        // Transform the tree.
        w.statement(hqlAst);

        if (AST_LOG.isDebugEnabled()) {
            ASTPrinter printer = new ASTPrinter(SqlTokenTypes.class);
            AST_LOG.debug(printer.showAsString(w.getAST(), "--- SQL AST ---"));
        }

        w.getParseErrorHandler().throwQueryException();

        return w;
    }
}
