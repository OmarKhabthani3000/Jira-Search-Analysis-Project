package br.hailtondecastro.hibernate.hql.ast;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.hibernate.hql.ast.tree.QueryNode;

import antlr.collections.AST;

public class ReflectionUtilWaHhh1830 {
    @SuppressWarnings("unchecked")
    public static <T> T superGetField(Object instance, String fieldName) {
        Field field;
        try {
            field = instance.getClass().getSuperclass()
                    .getDeclaredField(fieldName);
            field.setAccessible(true);
            return (T) field.get(instance);
        } catch (Throwable e) {
            throw new RuntimeException("This should not happen!", e);
        }
    }

    public static void superSetField(Object instance, String fieldName,
            Object value) {
        Field field;
        try {
            field = instance.getClass().getSuperclass()
                    .getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(instance, value);
        } catch (Throwable e) {
            throw new RuntimeException("This should not happen!", e);
        }
    }

    @SuppressWarnings("unchecked")
    public static <T> T superRun(Object instance, String name, Object... args) {
        try {
            Class<?>[] parameterTypes = new Class<?>[args.length];
            for (int i = 0; i < args.length; i++) {
                parameterTypes[i] = handleIfParamType(args[i].getClass(),
                        args[i]);
            }
            Method method;
            method = instance.getClass().getSuperclass().getDeclaredMethod(name,
                    parameterTypes);
            method.setAccessible(true);
            return (T) method.invoke(instance, args);
        } catch (Throwable e) {
            throw new RuntimeException("This should not happen!", e);
        }
    }

    private static Class<?> handleIfParamType(Class<?> clazz, Object instance) {
        if (clazz == Boolean.class)
            return Boolean.TYPE;
        else if (instance instanceof QueryNode)
            return AST.class;
        return clazz;
    }
}
