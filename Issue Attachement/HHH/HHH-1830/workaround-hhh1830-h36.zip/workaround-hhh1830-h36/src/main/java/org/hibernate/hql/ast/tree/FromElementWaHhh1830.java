package org.hibernate.hql.ast.tree;

import org.hibernate.persister.entity.EntityPersister;
import org.hibernate.type.EntityType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.hailtondecastro.hibernate.hql.ast.ReflectionUtilWaHhh1830;

public class FromElementWaHhh1830 extends FromElement {

    private static final Logger log = LoggerFactory
            .getLogger(FromElementWaHhh1830.class);

    public void initializeCollection(FromClause fromClause, String classAlias,
            String tableAlias) {
        doInitialize(fromClause, tableAlias, null, classAlias, null, null);
        ReflectionUtilWaHhh1830.superSetField(this, "initialized", true);
    }

    public void initializeEntity(FromClause fromClause, String className,
            EntityPersister persister, EntityType type, String classAlias,
            String tableAlias) {
        doInitialize(fromClause, tableAlias, className, classAlias, persister,
                type);
        ReflectionUtilWaHhh1830.superSetField(this, "sequence",
                fromClause.nextFromElementCounter());
        ReflectionUtilWaHhh1830.superSetField(this, "initialized", true);
    }

    private void doInitialize(FromClause fromClause, String tableAlias,
            String className, String classAlias, EntityPersister persister,
            EntityType type) {
        if (ReflectionUtilWaHhh1830.superGetField(this, "initialized")) {
            throw new IllegalStateException("Already initialized!!");
        }
        ReflectionUtilWaHhh1830.superSetField(this, "fromClause", fromClause);
        ReflectionUtilWaHhh1830.superSetField(this, "tableAlias", tableAlias);
        ReflectionUtilWaHhh1830.superSetField(this, "className", className);
        ReflectionUtilWaHhh1830.superSetField(this, "classAlias", classAlias);
        ReflectionUtilWaHhh1830.superSetField(this, "elementType",
                new FromElementTypeWaHhh1830(this, persister, type));
        // Register the FromElement with the FROM clause, now that we have
        // the
        // names and aliases.
        fromClause.registerFromElement(this);
        if (log.isDebugEnabled()) {
            log.debug(fromClause + " :  " + className + " ("
                    + (classAlias == null ? "no alias" : classAlias) + ") -> "
                    + tableAlias);
        }
    }
}
