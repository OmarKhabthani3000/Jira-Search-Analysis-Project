package br.hailtondecastro.hibernate.hql.ast;

import org.hibernate.hql.antlr.HqlSqlTokenTypes;
import org.hibernate.hql.ast.HqlSqlWalker;
import org.hibernate.hql.ast.SqlASTFactory;
import org.hibernate.hql.ast.tree.FromElement;
import org.hibernate.hql.ast.tree.FromElementWaHhh1830;

public class SqlASTFactoryWaHhh1830 extends SqlASTFactory {

    public SqlASTFactoryWaHhh1830(HqlSqlWalker walker) {
        super(walker);
        // TODO Auto-generated constructor stub
    }

    @Override
    public Class getASTNodeType(int tokenType) {
        if (tokenType == HqlSqlTokenTypes.FROM_FRAGMENT) {
            return FromElementWaHhh1830.class;
        }
        return super.getASTNodeType(tokenType);
    }
}
