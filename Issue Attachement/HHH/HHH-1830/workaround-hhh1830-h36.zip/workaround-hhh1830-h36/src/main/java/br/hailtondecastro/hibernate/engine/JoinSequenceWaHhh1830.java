package br.hailtondecastro.hibernate.engine;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.engine.JoinSequence;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.sql.JoinFragment;

import br.hailtondecastro.hibernate.hql.ast.ReflectionUtilWaHhh1830;

public class JoinSequenceWaHhh1830 extends JoinSequence {
    SessionFactoryImplementor factory;

    @SuppressWarnings("hiding")
    public JoinSequenceWaHhh1830(SessionFactoryImplementor factory) {
        super(factory);
        this.factory = factory;
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    public JoinSequence getFromPart() {
        JoinSequence fromPart = new JoinSequenceWaHhh1830(this.factory);
        ((List) ReflectionUtilWaHhh1830.superGetField(fromPart, "joins"))
                .addAll((Collection) ReflectionUtilWaHhh1830.superGetField(this,
                        "joins"));
        ReflectionUtilWaHhh1830.superSetField(fromPart, "useThetaStyle",
                ReflectionUtilWaHhh1830.superGetField(this, "useThetaStyle"));
        ReflectionUtilWaHhh1830.superSetField(fromPart, "rootAlias",
                ReflectionUtilWaHhh1830.superGetField(this, "rootAlias"));
        ReflectionUtilWaHhh1830.superSetField(fromPart, "rootJoinable",
                ReflectionUtilWaHhh1830.superGetField(this, "rootJoinable"));
        ReflectionUtilWaHhh1830.superSetField(fromPart, "selector",
                ReflectionUtilWaHhh1830.superGetField(this, "selector"));
        JoinSequence next = (JoinSequence) ReflectionUtilWaHhh1830
                .superGetField(this, "next");
        ReflectionUtilWaHhh1830.superSetField(fromPart, "next",
                next == null ? null : next.getFromPart());
        ReflectionUtilWaHhh1830.superSetField(fromPart, "isFromPart", true);

        return fromPart;
    }

    public JoinSequence copy() {
        JoinSequence copy = new JoinSequenceWaHhh1830(factory);
        List thisJoins = (List) ReflectionUtilWaHhh1830.superGetField(this,
                "joins");
        List copyJoins = (List) ReflectionUtilWaHhh1830.superGetField(copy,
                "joins");
        copyJoins.addAll(thisJoins);

        ReflectionUtilWaHhh1830.superSetField(copy, "useThetaStyle",
                ReflectionUtilWaHhh1830.superGetField(this, "useThetaStyle"));
        ReflectionUtilWaHhh1830.superSetField(copy, "rootAlias",
                ReflectionUtilWaHhh1830.superGetField(this, "rootAlias"));
        ReflectionUtilWaHhh1830.superSetField(copy, "rootJoinable",
                ReflectionUtilWaHhh1830.superGetField(this, "rootJoinable"));
        ReflectionUtilWaHhh1830.superSetField(copy, "selector",
                ReflectionUtilWaHhh1830.superGetField(this, "selector"));
        JoinSequence thisNext = (JoinSequence) ReflectionUtilWaHhh1830
                .superGetField(this, "next");
        JoinSequence copyNext = thisNext == null ? null : thisNext.copy();
        ReflectionUtilWaHhh1830.superSetField(copy, "next", copyNext);
        ReflectionUtilWaHhh1830.superSetField(copy, "conditions",
                ReflectionUtilWaHhh1830.superGetField(this, "conditions"));

        return copy;
    }

    /**
     * HHH-1830
     * 
     * @return
     */
    public JoinSequence copyForCollectionProperty() {
        JoinSequence copy = this.copy();
        ((List) ReflectionUtilWaHhh1830.superGetField(copy, "joins")).clear();
        Iterator joinIterator = this.iterateJoins();
        while (joinIterator.hasNext()) {
            Join join = (Join) joinIterator.next();
            copy.addJoin(join.getAssociationType(), join.getAlias(),
                    JoinFragment.INNER_JOIN, join.getLHSColumns());
        }
        return copy;
    }
}
