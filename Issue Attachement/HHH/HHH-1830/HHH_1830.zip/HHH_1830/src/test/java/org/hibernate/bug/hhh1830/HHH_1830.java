package org.hibernate.bug.hhh1830;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.hsqldb.server.HsqlServerFactory;
import org.hsqldb.server.Server;
import org.junit.Test;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

public class HHH_1830 {

	@Test
	public void test() throws Throwable {
		new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.HSQL).build();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hsql");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Parent parent = new Parent();
		Child child = new Child();
		parent.getChildren().add(child);
		em.persist(child);
		em.persist(parent);
		em.getTransaction().commit();
		em.getTransaction().begin();

		String qlString = "SELECT p.id, size(descendants) from Parent p left outer join p.children descendants group by p.id";
		TypedQuery<Object[]> q = em.createQuery(qlString, Object[].class);
		Object[] res = q.getSingleResult();
		System.err.println(res[0] + ": " + res[1]);

	}

}
