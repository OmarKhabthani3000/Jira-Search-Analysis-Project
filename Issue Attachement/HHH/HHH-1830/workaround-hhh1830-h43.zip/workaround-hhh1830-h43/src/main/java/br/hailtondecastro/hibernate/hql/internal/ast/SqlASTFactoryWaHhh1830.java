package br.hailtondecastro.hibernate.hql.internal.ast;

import org.hibernate.hql.internal.antlr.HqlSqlTokenTypes;
import org.hibernate.hql.internal.ast.HqlSqlWalker;
import org.hibernate.hql.internal.ast.SqlASTFactory;
import org.hibernate.hql.internal.ast.tree.FromElementWaHhh1830;

public class SqlASTFactoryWaHhh1830 extends SqlASTFactory {

    public SqlASTFactoryWaHhh1830(HqlSqlWalker walker) {
        super(walker);
    }

    @Override
    public Class getASTNodeType(int tokenType) {
        if (tokenType == HqlSqlTokenTypes.FROM_FRAGMENT) {
            return FromElementWaHhh1830.class;
        }
        return super.getASTNodeType(tokenType);
    }
}
