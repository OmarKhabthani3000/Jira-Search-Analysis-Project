package org.hibernate.test;

import java.io.Serializable;
import java.util.Objects;

public class GroupAssociationKey implements Serializable{

    public String memberOf;

    public String id;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GroupAssociationKey that = (GroupAssociationKey) o;
        return Objects.equals(memberOf, that.memberOf) &&
                Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(memberOf, id);
    }
}
