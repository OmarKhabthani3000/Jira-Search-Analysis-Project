package org.hibernate.test;

import org.hibernate.annotations.JoinFormula;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.util.Objects;

@Entity
@Table(name = "group_association")
@IdClass(GroupAssociationKey.class)
public class GroupAssociationEntity {

    @Id
    public String id;

    @Id
    public String memberOf;

    @ManyToOne
    @JoinFormula( "UPPER(id)" )
    public Group group;

    @ManyToOne
    @JoinFormula( "UPPER(memberOf)" )
    public Person person;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GroupAssociationEntity that = (GroupAssociationEntity) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(memberOf, that.memberOf);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, memberOf);
    }

    public Group getGroup() {
        return group;
    }

    public Person getPerson() {
        return person;
    }
}