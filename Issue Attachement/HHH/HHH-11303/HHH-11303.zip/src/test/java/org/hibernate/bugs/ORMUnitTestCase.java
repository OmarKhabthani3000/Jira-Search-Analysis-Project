/*
 * Copyright 2014 JBoss Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.hibernate.bugs;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;
import org.hibernate.test.Group;
import org.hibernate.test.GroupAssociationEntity;
import org.hibernate.test.Person;
import org.hibernate.testing.junit4.BaseCoreFunctionalTestCase;
import org.junit.Test;

import java.util.List;

import static junit.framework.TestCase.assertTrue;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using its built-in unit test framework.
 * Although ORMStandaloneTestCase is perfectly acceptable as a reproducer, usage of this class is much preferred.
 * Since we nearly always include a regression test with bug fixes, providing your reproducer using this method
 * simplifies the process.
 * <p>
 * What's even better?  Fork hibernate-orm itself, add your test case directly to a module's unit tests, then
 * submit it as a PR!
 */
public class ORMUnitTestCase extends BaseCoreFunctionalTestCase {

    // Add your entities here.
    @Override
    protected Class[] getAnnotatedClasses() {
        return new Class[]{
                Group.class,
                GroupAssociationEntity.class,
                Person.class
        };
    }

    // If you use *.hbm.xml mappings, instead of annotations, add the mappings here.
    @Override
    protected String[] getMappings() {
        return new String[]{
//				"Foo.hbm.xml",
//				"Bar.hbm.xml"
        };
    }

    // If those mappings reside somewhere other than resources/org/hibernate/test, change this.
    @Override
    protected String getBaseForMappings() {
        return "org/hibernate/test/";
    }

    // Add in any settings that are specific to your test.  See resources/hibernate.properties for the defaults.
    @Override
    protected void configure(Configuration configuration) {
        super.configure(configuration);

        configuration.setProperty(AvailableSettings.SHOW_SQL, Boolean.TRUE.toString());
        configuration.setProperty(AvailableSettings.FORMAT_SQL, Boolean.TRUE.toString());
        configuration.setProperty(AvailableSettings.HBM2DDL_AUTO, "none");
        //configuration.setProperty( AvailableSettings.GENERATE_STATISTICS, "true" );
    }

    // Add your tests, using standard JUnit.
    @Test
    public void hhh11303Test() throws Exception {
        // BaseCoreFunctionalTestCase automatically creates the SessionFactory and provides the Session.
        Session s = openSession();
        Transaction tx = s.beginTransaction();
        createTables(s);
        insertTestData(s);
        tx.commit();

        s.clear();
        tx = s.beginTransaction();
        Person person = s.find(Person.class, "abc1");
        List<GroupAssociationEntity> groups = person.groups;
        assertTrue(groups.size() > 0);

        tx.commit();
        s.close();
    }

    private void createTables(Session s) {
        s.createNativeQuery("create table groups (id varchar(255) not null, primary key (id))").executeUpdate();
        s.createNativeQuery("create table person (id varchar(255) not null, primary key (id))").executeUpdate();
        s.createNativeQuery("create table group_association (id varchar(255) not null,memberOf varchar(255) not null,primary key (id, memberOf))").executeUpdate();
    }


    private void insertTestData(Session s) {

        Person person1 = new Person();
        person1.id = "abc1";
        s.persist(person1);

        Person person2 = new Person();
        person2.id = "abc2";
        s.persist(person2);

        Group group = new Group();
        group.id = "g1";
        s.persist(group);

        GroupAssociationEntity p1g1 = new GroupAssociationEntity();
        p1g1.id = "G1";
        p1g1.memberOf = "ABC1";
        p1g1.group = group;
        p1g1.person = person1;
        s.persist(p1g1);

        GroupAssociationEntity p2g1 = new GroupAssociationEntity();
        p2g1.id = "G1";
        p2g1.memberOf = "ABC2";
        p2g1.group = group;
        p2g1.person = person2;
        s.persist(p2g1);
    }
}
