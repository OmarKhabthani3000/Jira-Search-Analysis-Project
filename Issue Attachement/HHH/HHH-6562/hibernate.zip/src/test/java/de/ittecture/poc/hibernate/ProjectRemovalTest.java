package de.ittecture.poc.hibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.junit.Before;
import org.junit.Test;

public class ProjectRemovalTest {

	private EntityManagerFactory emf;
	private EntityManager em;

	@Before
	public void setup() {
		emf = Persistence
				.createEntityManagerFactory(
						"foo");
		em = emf.createEntityManager();
	}

	@Test
	public void can_remove_project_from_body_shop() {
		Project raw = prepareBodyShopWithTwoProjects();
		BodyShop bodyShop = findBodyShopWithProject(
				raw);
		deleteProjectFromBodyShop(raw,
				bodyShop);
	}

	private Project prepareBodyShopWithTwoProjects() {
		em.getTransaction()
				.begin();

		Project efficient = new Project();
		efficient.setName("Efficient");
		em.persist(efficient);

		Project raw = new Project();
		raw.setName("Raw");
		em.persist(raw);

		BodyShop bodyShop = new BodyShop();
		bodyShop.setCustomerName(
				"John Doe Customs");
		bodyShop.getClassification()
				.getProjects()
				.add(efficient);
		bodyShop.getClassification()
				.getProjects()
				.add(raw);
		em.persist(bodyShop);
		em.flush();

		em.getTransaction()
				.commit();
		return raw;
	}

	private BodyShop findBodyShopWithProject(Project raw) {
		CriteriaBuilder builder = em
				.getCriteriaBuilder();
		CriteriaQuery<BodyShop> query = builder
				.createQuery(BodyShop.class);
		Root<BodyShop> root = query.from(
				BodyShop.class);
		query.where(root.get("classification")
				.get("projects")
				.in(raw));

		BodyShop future = em.createQuery(query)
				.getSingleResult();
		return future;
	}

	private void deleteProjectFromBodyShop(Project raw, BodyShop bodyShop) {
		em.getTransaction()
				.begin();
		bodyShop.remove(raw);
		em.persist(bodyShop);
		em.flush();
		em.getTransaction()
				.commit();
	}
}