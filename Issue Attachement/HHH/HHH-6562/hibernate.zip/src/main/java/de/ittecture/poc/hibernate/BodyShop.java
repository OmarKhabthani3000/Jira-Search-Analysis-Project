package de.ittecture.poc.hibernate;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name=BodyShop.TABLE_NAME)
public class BodyShop extends AbstractEntity {

	public static final String TABLE_NAME = "body_shops";

	@Column(name="customer_name", nullable=false)
	private String customerName;
	@Embedded
	private RangeClassification classification;
	
	public BodyShop() {
		setClassification(new RangeClassification());
	}
	
	public RangeClassification getClassification() {
		return classification;
	}
	
	public BodyShop setClassification(RangeClassification classification) {
		this.classification = classification == null ? new RangeClassification() : classification;
		return this;
	}

	public String getCustomerName() {
		return this.customerName;
	}

	public BodyShop setCustomerName(String customerName) {
		this.customerName = customerName;
		return this;
	}

	public BodyShop remove(Project project) {
		classification.remove(project);
		return this;
	}
}