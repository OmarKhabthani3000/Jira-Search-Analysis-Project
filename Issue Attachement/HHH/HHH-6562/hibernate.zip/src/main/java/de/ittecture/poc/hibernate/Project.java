package de.ittecture.poc.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = Project.TABLE_NAME)
public class Project extends AbstractEntity {

	public static final String TABLE_NAME = "projects";
	public static final String NAME = "name";
	
	@Column(nullable = false)
	private String name = null;

	public Project setName(String name) {
		this.name = name;
		return this;
	}

	public String getName() {
		return this.name;
	}
}