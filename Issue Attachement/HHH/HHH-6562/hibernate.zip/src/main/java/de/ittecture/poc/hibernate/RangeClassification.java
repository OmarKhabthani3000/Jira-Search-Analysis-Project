package de.ittecture.poc.hibernate;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;

import org.hibernate.annotations.Formula;

@Embeddable
public class RangeClassification {

	/**
	 * From {@linkplain http://stackoverflow.com/questions/1324266/can-i-make-an-embedded-hibernate-entity-non-nullable here}
	 * 
	 * Question for alternative {@linkplain http://www.coderanch.com/t/629485/ORM/databases/columns-Embedded-field-NULL-JPA here}
	 */
	@Formula("0")
	private int dummy;

	@ManyToMany(fetch = FetchType.EAGER)
	private Set<Project> projects;

	public RangeClassification() {
		setProjects(new HashSet<Project>());
	}

	public Set<Project> getProjects() {
		return this.projects;
	}

	public RangeClassification setProjects(Set<Project> projects) {
		this.projects = projects;
		return this;
	}

	public RangeClassification remove(Project entity) {
		List<Project> remaining = new ArrayList<>();
		for (Project project : projects) {
			if (!project.getId().equals(entity.getId())) {
				remaining.add(project);
			}
		}
		projects.clear();
		projects.addAll(remaining);
		return this;
	}
}