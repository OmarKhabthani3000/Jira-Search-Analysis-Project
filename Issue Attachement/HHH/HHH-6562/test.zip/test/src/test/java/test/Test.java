package test;

import com.mysema.query.jpa.JPQLQuery;
import com.mysema.query.jpa.impl.JPAQuery;
import junit.framework.Assert;
import org.hibernate.loader.custom.EntityFetchReturn;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: nardonep
 * Date: 09/06/11
 * Time: 13:38
 * To change this template use File | Settings | File Templates.
 */
public class Test {

    private EntityManagerFactory  emf;

    @BeforeMethod
    public void setUp() throws Exception {
        emf = Persistence.createEntityManagerFactory("library");

    }


    @AfterMethod
    public void tearDown() throws Exception {
        emf.close();
    }

    @org.testng.annotations.Test
    public void testTestSystem() throws Exception {
        EntityManager entityManager=emf.createEntityManager();

        entityManager.getTransaction().begin();

        BookID bid=new BookID();
        Library lib=new Library();

        entityManager.persist(bid);
        entityManager.persist(lib);


        BookVersion bv= new BookVersion();
        bv.setBookID(bid);
        bv.setLibrary(lib);




        bv.setDefinition(new BookDefinition());
        bv.getDefinition().setName("New Book");
        bv.getDefinition().setDescription("New Book");
        BookMark bm = new BookMark();
        bm.setComment("My Favourite Bit");
        bm.setPage(2356L);

        bv.getDefinition().setBookMarks(Arrays.asList(bm));


        entityManager.persist(bv);

        BookID bid2=new BookID();
        Library lib2=new Library();

        entityManager.persist(bid2);
        entityManager.persist(lib2);


        BookVersion bv2= new BookVersion();
        bv2.setBookID(bid2);
        bv2.setLibrary(lib2);




        bv2.setDefinition(new BookDefinition());
        bv2.getDefinition().setName("New Book 2");
        bv2.getDefinition().setDescription("New Book 2");
        BookMark bm21 = new BookMark();
        bm21.setComment("My Favourite Bit");
        bm21.setPage(2356L);
        BookMark bm22 = new BookMark();
        bm22.setComment("My Favourite Bit 2");
        bm22.setPage(2356L);

        bv2.getDefinition().setBookMarks(Arrays.asList(bm21,bm22));


        entityManager.persist(bv2);





        TypedQuery<BookVersion> typedQuery = entityManager.createQuery("SELECT  x FROM BookVersion x WHERE size(x.definition.bookMarks) = :sz  ",BookVersion.class);




          typedQuery.setParameter("sz", 1);

        List<BookVersion>  resultList = typedQuery.getResultList();

        Assert.assertEquals(1,resultList.size());

        QBookVersion bookVersion = QBookVersion.bookVersion;
        JPQLQuery query = new JPAQuery(entityManager);

        List<BookVersion> bob = query.from(bookVersion)
          .where(bookVersion.definition.bookMarks.size().eq(1))
          .list(bookVersion);
               Assert.assertEquals(1,resultList.size());



        {
        CriteriaBuilder cb=entityManager.getCriteriaBuilder();
          CriteriaQuery<BookVersion> cq  = cb.createQuery(BookVersion.class);
          Root<BookVersion> root  = cq.from(BookVersion.class);
          Join<BookVersion, BookDefinition> versionDefinition = root.join(BookVersion_.definition);

        ListJoin<BookDefinition,BookMark> bookMarksListJoin = versionDefinition.join(BookDefinition_.bookMarks);

        Expression<List<BookMark>> bookmarksExpression=versionDefinition.get(BookDefinition_.bookMarks);
        ParameterExpression<Integer> size=cb.parameter(Integer.class);

        CriteriaQuery<BookVersion> select = cq.select(root);
        select.where(cb.equal(cb.size(bookmarksExpression),size));

        typedQuery = entityManager.createQuery(select);
        typedQuery.setParameter(size, 1);

       resultList = typedQuery.getResultList();

        Assert.assertEquals(1,resultList.size());
        }

        entityManager.getTransaction().commit();
        emf.close();




    }
}
