
package ch.astorm.sql;

import org.hibernate.dialect.function.SQLFunctionTemplate;
import org.hibernate.spatial.dialect.mysql.MySQL5InnoDBSpatialDialect;
import org.hibernate.type.BooleanType;

/**
 * Special dialect class that registers the ID_INTERSECTS function so MySQL will be
 * able to use the index on the spatial column because the final query will look like 
 * <pre>... AND INTERSECTS(?1, ?2) AND 1 = 1 ...</pre>
 * 
 * See http://stackoverflow.com/questions/3894994/mysql-spatial-index-doesnt-work-when-equating-mbrcontains-to-true
 */
public class CustomMysqlSpatialInnoDBDialect extends MySQL5InnoDBSpatialDialect {
    public CustomMysqlSpatialInnoDBDialect() {
        registerFunction("id_intersects", new SQLFunctionTemplate(BooleanType.INSTANCE, "INTERSECTS(?1, ?2) AND 1"));
    }
}
