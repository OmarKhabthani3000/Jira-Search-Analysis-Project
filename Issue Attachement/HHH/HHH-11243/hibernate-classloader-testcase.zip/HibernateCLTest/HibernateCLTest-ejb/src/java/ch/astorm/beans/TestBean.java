
package ch.astorm.beans;

import ch.astorm.entities.Event;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;

@Startup
@Singleton
@LocalBean
@TransactionManagement(TransactionManagementType.BEAN)
public class TestBean {
    private static final Logger log = Logger.getLogger(TestBean.class.getName());
    private static final String ID_PREFIX = "GENID";
    private static final int NB_YEARS = 2;
    private static final int NB_MONTHS = 12;
    private static final int NB_EVENTS_PER_MONTH = 100;
    private static final int SPLITS = 100;
    private static final int NB_REQUESTS = 3;
    private static final int FIRST_YEAR = 2015;
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Resource
    private UserTransaction userTransaction;
    
    @PostConstruct
    public void test() {
        Logger global = Logger.getLogger("");
        for(Handler h : global.getHandlers()) { h.setLevel(Level.FINEST); }
        log.setLevel(Level.FINEST);
        
        try {
            generateEvents();
            //queryEvents();
        } catch(Throwable t) {
            log.log(Level.SEVERE, "An exception has occurred", t);
            throw new RuntimeException(t);
        }
    }
    
    public String queryEvents() {
        StringBuilder builder = new StringBuilder(1024);
        builder.append("<html><head/><body><table border=\"1\">");
        builder.append("<tr>");
        builder.append("<td>From</td>");
        builder.append("<td>To</td>");
        builder.append("<td>Results</td>");
        builder.append("<td>Time</td>");
        builder.append("</tr>");
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Random random = new Random();
        for(int req=0 ; req<NB_REQUESTS ; ++req) {
            try{
                //make a spatial query, for the fun
                int year = FIRST_YEAR+random.nextInt(NB_YEARS);
                int month = 1+random.nextInt(NB_MONTHS);
                int day = 1+random.nextInt(28);
                int hour = 8+random.nextInt(6);
                int hourDuration = random.nextInt(48);
                Date start = sdf.parse(year+"-"+(month<10 ? "0" : "")+month+"-"+(day<10 ? "0" : "")+day+" "+(hour<10 ? "0" : "")+hour+":00");
                Date end = new Date(start.getTime()+hourDuration*60*60*1000l);

                userTransaction.begin();
                long startRange = System.currentTimeMillis();
                Query query = entityManager.createQuery("SELECT p FROM Event p WHERE p.eventstart<=?1 AND p.eventend>=?2").setParameter(1, end).setParameter(2, start);
                List<Event> eventsRange = query.getResultList(); // <=== This call will (sometimes) generate a warning
                long elapsedRange = System.currentTimeMillis()-startRange;
                userTransaction.commit();

                builder.append("<tr>");
                builder.append("<td>").append(sdf.format(start)).append("</td>");
                builder.append("<td>").append(sdf.format(end)).append("</td>");
                builder.append("<td>").append(eventsRange.size()).append("</td>");
                builder.append("<td>").append(elapsedRange).append("ms</td>");
                builder.append("</tr>");
            } catch(Exception e) {
                builder.append("<tr>");
                builder.append("<td colspan=\"4\">").append(e.getMessage()).append("</td>");
                builder.append("</tr>");
            }
        }
        builder.append("</table></body></html>");
        return builder.toString();
    }
    
    private void generateEvents() throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        String[] domains = new String[]{"ABC", "DEF", "GHI"};
        int[] startHours = new int[]{6,7,8};
        int[] startMinutes = new int[]{0,15,30,45};
        int[] durations = new int[]{10,15,20,30,45,60,90,120,150,180,
                                    24*60,25*60,26*60,27*60, //1 day + 3 hours
                                    48*60,49*60,50*60,51*60  //2 days + 3 hours
                                   };
        
        Random random = new Random();
        int nbSplits = NB_EVENTS_PER_MONTH/SPLITS;
        for(int split=0 ; split<nbSplits ; ++split) {
            log.log(Level.FINE, "Creating events ({0}/{1})...", new Object[]{""+(split+1), ""+nbSplits});
            
            userTransaction.begin();
            for(int year=1 ; year<=NB_YEARS ; ++year) {
                int yearVal = (FIRST_YEAR-1)+year;
                for(int month=1 ; month<=NB_MONTHS ; ++month) {
                    //log.log(Level.FINE, "Creating {0} events for {1}/{2} (split {3}/{4})...", new Object[]{""+SPLITS, ""+yearVal, ""+month, split+1, nbSplits});
                    
                    for(int i=0 ; i<SPLITS ; ++i) {
                        String domain = domains[random.nextInt(domains.length)];
                        int day = random.nextInt(month==2 ? 28 : 30);
                        int startHour = startHours[random.nextInt(startHours.length)];
                        int startMinute = startMinutes[random.nextInt(startMinutes.length)];
                        int duration = durations[random.nextInt(durations.length)];

                        String strDate = yearVal+"-"+(month<10 ? "0" : "")+month+"-"+(day<10 ? "0" : "")+day+" "+
                                         (startHour<10 ? "0" : "")+startHour+":"+(startMinute<10 ? "0" : "")+startMinute;
                        Date startDate = sdf.parse(strDate);
                        Date endDate = new Date(startDate.getTime()+duration*60*1000l);

                        int uniqueId = ((split*NB_YEARS+(year-1))*NB_MONTHS+(month-1))*SPLITS+i;
                        Event event = new Event(domain, ID_PREFIX+uniqueId);
                        event.setLabel("Event number "+uniqueId);
                        event.setEventstart(startDate);
                        event.setEventend(endDate);

                        if(random.nextInt(100)>80) { event.setCommentary("This is a random comment, generated for event "+event.getIdpk()); }
                        entityManager.persist(event);
                    }
                }
            }
            userTransaction.commit();
        }
    }
}
