
package ch.astorm.entities.core;

public interface Shareable extends Cloneable {
    String getDomainpk();
    void setDomainpk(String domainpk);
    Shareable clone() throws CloneNotSupportedException;
}
