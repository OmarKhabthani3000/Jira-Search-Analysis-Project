
package ch.astorm.entities;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.Table;
import ch.astorm.entities.core.AbstractSimpleTable;
import ch.astorm.entities.core.NorecoTablePK;
import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineString;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "event")
public class Event extends AbstractSimpleTable<NorecoTablePK> implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected NorecoTablePK eventPK;
    @Column(name = "LABEL")
    private String label;
    @Column(name = "EVENTSTART")
    @Temporal(TemporalType.TIMESTAMP)
    private Date eventstart;
    @Column(name = "EVENTEND")
    @Temporal(TemporalType.TIMESTAMP)
    private Date eventend;
    @Lob
    @Column(name = "COMMENTARY")
    private String commentary;
    @Column(name = "SPDATA")
    private LineString spdata;

    @Override public NorecoTablePK getPk() { return eventPK; }
    @Override public void setPk(NorecoTablePK pk) { this.eventPK = pk; }
    @Override public String getIdpk() { return eventPK.getNorecopk(); }
    @Override public void setIdpk(String idpk) { eventPK.setNorecopk(idpk); }

    @PrePersist
    @PreUpdate
    private void adjustSpdata() {
        GeometryFactory gf = new GeometryFactory();
        spdata = gf.createLineString(new Coordinate[]{
            new Coordinate(1, (int)(eventstart.getTime()/1000.0)),
            new Coordinate(-1, (int)(eventend.getTime()/1000.0))
        });
    }
    
    public Event() {
    }

    public Event(NorecoTablePK eventPK) {
        this.eventPK = eventPK;
    }

    public Event(String domainpk, String norecopk) {
        this.eventPK = new NorecoTablePK(domainpk, norecopk);
    }
    
    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
    
    public String getCommentary() {
        return commentary;
    }

    public void setCommentary(String commentary) {
        this.commentary = commentary;
    }

    public LineString getSpdata() {
        return spdata;
    }

    public void setSpdata(LineString spdata) {
        this.spdata = spdata;
    }

    public Date getEventstart() {
        return eventstart;
    }

    public void setEventstart(Date eventstart) {
        this.eventstart = eventstart;
    }

    public Date getEventend() {
        return eventend;
    }

    public void setEventend(Date eventend) {
        this.eventend = eventend;
    }
}
