
package ch.astorm.entities.core;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class NorecoTablePK implements Serializable, Cloneable, Shareable {
    @Basic(optional = false)
    @Column(name = "DOMAINPK", nullable = false)
    private String domainpk;
    @Basic(optional = false)
    @Column(name = "NORECOPK", nullable = false)
    private String norecopk;

    public NorecoTablePK() {
    }

    public NorecoTablePK(String domainpk, String norecopk) {
        this.domainpk = domainpk;
        this.norecopk = norecopk;
    }

    @Override
    public String getDomainpk() {
        return domainpk;
    }

    @Override
    public void setDomainpk(String domainpk) {
        this.domainpk = domainpk;
    }

    public String getNorecopk() {
        return norecopk;
    }

    public void setNorecopk(String norecopk) {
        this.norecopk = norecopk;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (domainpk != null ? domainpk.hashCode() : 0);
        hash += (norecopk != null ? norecopk.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof NorecoTablePK)) {
            return false;
        }
        NorecoTablePK other = (NorecoTablePK) object;
        if ((this.domainpk == null && other.domainpk != null) || (this.domainpk != null && !this.domainpk.equals(other.domainpk))) {
            return false;
        }
        if ((this.norecopk == null && other.norecopk != null) || (this.norecopk != null && !this.norecopk.equals(other.norecopk))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return getClass().getName()+"[domainpk=" + domainpk + ", norecopk=" + norecopk + "]";
    }

    @Override
    public NorecoTablePK clone() throws CloneNotSupportedException {
        return (NorecoTablePK)super.clone();
    }
}
