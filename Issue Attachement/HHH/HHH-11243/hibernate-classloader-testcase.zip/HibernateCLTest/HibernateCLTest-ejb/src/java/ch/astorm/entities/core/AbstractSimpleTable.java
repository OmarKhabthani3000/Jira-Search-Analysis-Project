
package ch.astorm.entities.core;

import javax.persistence.Column;
import javax.persistence.Lob;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class AbstractSimpleTable<P extends Shareable> {
    
    @Lob
    @Column(name = "EDMSDESCRIPTOR")
    private String edmsdescriptor;
    
    public String getEdmsdescriptor() { return edmsdescriptor; }
    public void setEdmsdescriptor(String edmsdescriptor) { this.edmsdescriptor = edmsdescriptor; }
    public String getDomainpk() { return getPk().getDomainpk(); }
    public void setDomainpk(String domainpk) { getPk().setDomainpk(domainpk); }
    public String getIdpk() { throw new RuntimeException("not supported"); }
    public void setIdpk(String idpk) { throw new RuntimeException("not supported"); }
    
    /**
     * Defines the primary key.
     */
    public abstract P getPk();
    public abstract void setPk(P pk);
    
    @Override
    protected final AbstractSimpleTable<P> clone() throws CloneNotSupportedException {
        return (AbstractSimpleTable<P>)super.clone();
    }
    
    /**
     * Use this method to alter the domainpk field of an entity
     * It clones the entity and its identity object (xxxPK), and sets the domainpk field
     * using the domainList parameter.
     * @param domainList the new domains.
     * @return the entity with its domainpk set using the domainlist for its identity object
     */
    public final <T extends AbstractSimpleTable<P>> T clone(String domainList) throws CloneNotSupportedException {
        T t1 = (T)this.clone();
        P t1pk = (P)t1.getPk().clone();
        t1pk.setDomainpk(domainList);
        t1.setPk(t1pk);
        return t1;
    }
    
    @Override
    public final int hashCode() {
        return getPk().hashCode();
    }

    @Override
    public final boolean equals(Object object) {
        if(getClass().isInstance(object)) {
            AbstractSimpleTable<P> o = (AbstractSimpleTable<P>)object;
            P p1 = this.getPk();
            P p2 = o.getPk();
            return p1.equals(p2);
        }
        return false;
    }
    
    @Override
    public final String toString() {
        return getClass().getName()+"[pk=" + getPk() + "]";
    }
}
