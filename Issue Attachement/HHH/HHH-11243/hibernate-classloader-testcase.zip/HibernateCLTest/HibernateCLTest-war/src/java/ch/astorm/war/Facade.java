
package ch.astorm.war;

import ch.astorm.beans.TestBean;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns="/Facade", loadOnStartup=1)
public class Facade extends HttpServlet {
    @EJB
    private TestBean testBean;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String result = testBean.queryEvents();
        PrintWriter pw = resp.getWriter();
        pw.print(result);
        pw.close();
    }
}
