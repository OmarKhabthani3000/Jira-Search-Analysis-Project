package bug.test;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;

import org.hibernate.Session;


public class Test {

	public static void main(String[] args) throws IOException, SQLException {
		// for the first two printlns the image is there, however for the final println the retrieved image is null	 
		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		SomeBean sb = new SomeBean();
		Image img = new Image();
		img.setImageFromPath("<path to some image>");
		session.save(img);
		sb.setImage(img);
		session.save(sb);
		session.getTransaction().commit();

		session.beginTransaction();

		List someBeans = HibernateUtil.getSession().createQuery("from SomeBean")
				.list();
		for (Iterator iter = someBeans.iterator(); iter.hasNext();)
			System.out.println("Read image is "
					+ ImageIO.read(((SomeBean) iter.next()).getImage()
							.getImageBlob().getBinaryStream()));
		HibernateUtil.getSession().clear();

		someBeans = HibernateUtil.getSession().createQuery("from SomeBean")
				.list();
		for (Iterator iter = someBeans.iterator(); iter.hasNext();)
			System.out.println("Read image is "
					+ ImageIO.read(((SomeBean) iter.next()).getImage()
							.getImageBlob().getBinaryStream()));

		HibernateUtil.getSession().getTransaction().commit();
		// HibernateUtil.getSession().clear(); // uncomment this line and final line is not null
		HibernateUtil.getSession().beginTransaction();

		someBeans = HibernateUtil.getSession().createQuery("from SomeBean")
				.list();
		for (Iterator iter = someBeans.iterator(); iter.hasNext();)
			System.out.println("Read image is "
					+ ImageIO.read(((SomeBean) iter.next()).getImage()
							.getImageBlob().getBinaryStream()));
	}

}
