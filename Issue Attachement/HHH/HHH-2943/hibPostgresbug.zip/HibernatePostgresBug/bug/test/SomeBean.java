package bug.test;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class SomeBean {

	protected String id = java.util.UUID.randomUUID().toString();

	private Image image;

	@Id
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public SomeBean() {
	}

	@ManyToOne(cascade = CascadeType.ALL)
	public Image getImage() {
		return image;
	}

	public void setImage(Image image) {
		this.image = image;
	}
}
