package bug.test;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;

import javax.imageio.ImageIO;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import org.hibernate.Session;

@Entity
public class Image{

	protected String id = java.util.UUID.randomUUID().toString();

	private Blob imageBlob;

	public Image(){
		
	}

	@Id 
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public static Image getImage(String id) {
		Session sess = HibernateUtil.getSession();
		Image t = (Image) sess.load(Image.class, id);
		return t;
	}

	@Column(length=16777215, nullable=false)
	public Blob getImageBlob() {
		return imageBlob;
	}

	public void setImageBlob(Blob imageBlob) {
		this.imageBlob = imageBlob;
	}

	@Transient
	public void setBufferedImage(BufferedImage img)
	{
        if (img == null) {
            setImageBlob(null);
        } else {        
            try {
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                ImageIO.write(img, "png", b);
                b.flush();
                b.close();
                setImageBlob(new SerialBlob(b.toByteArray()));
            } catch(IOException e) {
            } catch (SerialException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
	}
	
	/**
	 * The following method will set this beans image by reading it from a file
	 * @param string the file containing the image
	 */
	@Transient
	public void setImageFromPath(String fileName) {
		File imgFile = new File(fileName);
		long imgFileSize = imgFile.length();
		byte byteValue[] = new byte[(int) imgFileSize];
		InputStream is;
		try {
			is = new BufferedInputStream(new FileInputStream(imgFile));
			is.read(byteValue);
			setImageBlob(new SerialBlob(byteValue));
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SerialException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
