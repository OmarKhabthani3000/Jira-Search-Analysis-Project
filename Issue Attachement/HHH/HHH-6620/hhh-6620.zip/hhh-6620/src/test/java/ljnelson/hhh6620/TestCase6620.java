/* -*- mode: Java; c-basic-offset: 2; indent-tabs-mode: nil -*-
 *
 * $Id$
 *
 * Copyright (c) 2011 Laird Nelson.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT.  IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * The original copy of this license is available at
 * http://www.opensource.org/license/mit-license.html.
 */
package ljnelson.hhh6620;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import static org.junit.Assert.*;

public class TestCase6620 {

  private EntityManagerFactory emf;

  private EntityManager em;

  @Before
  public void setUp() throws Exception {
    this.tearDown(); // be safe

    setUpTables();

    final EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
    assertNotNull(emf);
    assertTrue(emf.isOpen());
    this.emf = emf;

    final EntityManager em = emf.createEntityManager();
    assertNotNull(em);
    assertTrue(em.isOpen());
    this.em = em;
  }

  private static final Connection getConnection() throws Exception {
    final String testDatabaseCatalog = System.getProperty("testDatabaseCatalog", "test");
    final String user = System.getProperty("testDatabaseUser", "sa");
    final String password = System.getProperty("testDatabasePassword", "");
    final String connectionUrl = System.getProperty("testDatabaseConnectionURL", String.format("jdbc:h2:mem:%s;DB_CLOSE_DELAY=-1;TRACE_LEVEL_SYSTEM_OUT=3", testDatabaseCatalog));
    
    final Connection connection = DriverManager.getConnection(connectionUrl, user, password);
    assertNotNull(connection);
    return connection;
  }

  private static final void setUpTables() throws Exception {
    final Connection connection = getConnection();
    assertNotNull(connection);
    setUpTables(connection);
    connection.close();
  }

  private static final void setUpTables(final Connection connection) throws Exception {
    assertNotNull(connection);
    
    Statement statement = connection.createStatement();
    assertNotNull(statement);

    final String schema = System.getProperty("testDatabaseSchema", "test");
    if (schema != null && !schema.isEmpty()) {
      statement.executeUpdate(String.format("CREATE SCHEMA %s", schema));
    }
    
    String schemaPrefix = System.getProperty("testDatabaseSchemaPrefix");
    if (schemaPrefix == null) {
      if (schema != null && !schema.isEmpty()) {
	schemaPrefix = String.format("%s.", schema);
      } else {
	schemaPrefix = "";
      }
    }
    statement.executeUpdate(String.format("CREATE TABLE %sjpa_sequence ( sequence_name VARCHAR(100) NOT NULL PRIMARY KEY, last_value BIGINT NOT NULL DEFAULT 0 )", schemaPrefix));

    statement.executeUpdate(String.format("CREATE TABLE %sentity_table ( id BIGINT IDENTITY, long_description VARCHAR(255) )", schemaPrefix));

    statement.close();
  }

  @After
  public void tearDown() throws Exception {
    if (this.em != null && this.em.isOpen()) {
      this.em.close();
    }
    if (this.emf != null && this.emf.isOpen()) {
      this.emf.close();
    }
    shutDownDatabase();
  }

  private static final void shutDownDatabase() throws Exception {
    final Connection connection = getConnection();
    assertNotNull(connection);
    final Statement statement = connection.createStatement();
    statement.executeUpdate(String.format("SHUTDOWN"));
    statement.close();
    connection.close();
  }

  @Test
  public void showBug() {
    assertNotNull(this.em);
    assertTrue(this.em.isOpen());
    final Entity entity = new Entity();
    final EntityTransaction et = this.em.getTransaction();
    assertNotNull(et);
    et.begin();
    this.em.persist(entity);
    this.em.flush();
    et.commit();
    assertEquals(5000L, entity.getId());
  }

}