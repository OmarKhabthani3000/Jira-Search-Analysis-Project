package com.example.demo;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequestMapping("/test")
@RestController
@CrossOrigin
@AllArgsConstructor
class TestController {
    private final ParentRepository repository;

    @PostMapping
    public Parent createEntity() {
        var parentId = new ParentId("id1");
        var child1Id1 = new Child1Id(parentId, 1);
        var child1Id2 = new Child1Id(parentId, 2);

        var parent = new Parent(
                parentId,
                List.of(
                        new Child1(child1Id1, List.of()),
                        new Child1(child1Id2, List.of())
                )
        );

        return repository.save(parent);
    }
}
