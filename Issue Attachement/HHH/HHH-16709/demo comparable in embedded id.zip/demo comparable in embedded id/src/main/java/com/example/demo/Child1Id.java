package com.example.demo;

import jakarta.persistence.Embeddable;
import jakarta.persistence.Embedded;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Embeddable
@AllArgsConstructor
@NoArgsConstructor
class Child1Id {
    @Embedded
    private ParentId parentId;
    private Integer version;
}
