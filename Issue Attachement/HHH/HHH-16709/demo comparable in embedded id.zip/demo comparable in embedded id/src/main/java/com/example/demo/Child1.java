package com.example.demo;

import jakarta.persistence.CascadeType;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "child1")
@AllArgsConstructor
@NoArgsConstructor
class Child1 {

    @EmbeddedId
    private Child1Id child1Id;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "child1_id", referencedColumnName = "id")
    @JoinColumn(name = "child1_version", referencedColumnName = "version")
    private List<Child2> child2s;
}
