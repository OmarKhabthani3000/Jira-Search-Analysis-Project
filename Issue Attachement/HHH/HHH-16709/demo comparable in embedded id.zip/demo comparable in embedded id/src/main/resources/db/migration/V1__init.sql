CREATE TABLE public.parent(
    id VARCHAR(255) PRIMARY KEY
);

CREATE TABLE public.child1(
    id VARCHAR(255),
    version integer,

    PRIMARY KEY(id, version),
    FOREIGN KEY(id) REFERENCES public.parent(id)
);

CREATE TABLE public.child2(
    id SERIAL PRIMARY KEY,
    child1_id VARCHAR(255),
    child1_version INTEGER,

    FOREIGN KEY(child1_id, child1_version) REFERENCES public.child1(id, version)
);