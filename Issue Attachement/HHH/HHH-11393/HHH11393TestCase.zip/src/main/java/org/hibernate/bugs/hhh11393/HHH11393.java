package org.hibernate.bugs.hhh11393;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * Entity implementation class for Entity: HHH11393
 */
@Entity
@SuppressWarnings("javadoc")
public class HHH11393 implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;
  private String code;
  private String description;

  public HHH11393() {
    super();
  }

  public HHH11393(final String code, final String description) {
    setCode(code);
    setDescription(description);
  }

  public Long getId() {

    return id;
  }

  public void setId(final Long id) {

    this.id = id;
  }

  public String getCode() {

    return code;
  }

  public void setCode(final String code) {

    this.code = code;
  }

  public String getDescription() {

    return description;
  }

  public void setDescription(final String description) {

    this.description = description;
  }

}
