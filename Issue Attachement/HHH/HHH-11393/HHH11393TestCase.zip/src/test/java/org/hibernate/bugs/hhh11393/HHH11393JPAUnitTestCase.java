package org.hibernate.bugs.hhh11393;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.Trimspec;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.bugs.HHH1234_;
import org.hibernate.bugs.hhh11393.HHH11393;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
@SuppressWarnings("javadoc")
public class HHH11393JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

  @Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh11393Test() throws Exception {
		final EntityManager entityManager = entityManagerFactory.createEntityManager();
    final EntityTransaction transaction = entityManager.getTransaction();

    // insert record with leading 0's
    transaction.begin();
    final HHH11393 insertTwo = new HHH11393("001001", "Description 1001");
    entityManager.persist(insertTwo);
    transaction.commit();

    transaction.begin();
    final HHH11393 two = findByCode(entityManager, "1001");
    assertThat(two, is(notNullValue()));
    assertThat(two.getDescription(), is("Description 1001"));
    transaction.commit();

    entityManager.close();
  }

  private HHH11393 findByCode(final EntityManager entityManager, final String code) {

    final CriteriaBuilder builder = entityManager.getCriteriaBuilder();
    final CriteriaQuery<HHH11393> query = builder.createQuery(HHH11393.class);

    // Tables (from, join)
    final Root<HHH11393> hhh1234 = query.from(HHH11393.class);

    // Conditions
    final Path<String> _code = hhh1234.get(HHH1234_.code);
    final Predicate predicate = builder.or(
        builder.equal(_code, code),
        builder.equal(builder.trim(Trimspec.LEADING, Character.valueOf('0'), _code), code));
    query.where(predicate);

    final TypedQuery<HHH11393> run = entityManager.createQuery(query);
    return run.getSingleResult();
  }
}
