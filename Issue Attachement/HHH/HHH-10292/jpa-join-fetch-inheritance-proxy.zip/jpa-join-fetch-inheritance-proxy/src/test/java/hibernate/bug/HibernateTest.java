package hibernate.bug;

import hibernate.bug.model.MyEntity;
import hibernate.bug.model.PolymorphicIdRelation;
import hibernate.bug.model.PolymorphicIdRelationId;
import hibernate.bug.model.PolymorphicStart;
import hibernate.bug.model.PolymorphicSub1;
import hibernate.bug.model.PolymorphicSub2;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HibernateTest {
    
    private EntityManagerFactory emf;
    
    @Before
    public void init() throws Exception {
        emf = Persistence.createEntityManagerFactory("Test");
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        
        MyEntity iie1 = new MyEntity("a");
        PolymorphicSub1 ps1 = new PolymorphicSub1(iie1);
        PolymorphicIdRelation pir1 = new PolymorphicIdRelation(new PolymorphicIdRelationId("a", ps1));
        PolymorphicStart pps1 = new PolymorphicStart(pir1);
        
        MyEntity iie2 = new MyEntity("b");
        PolymorphicSub2 ps2 = new PolymorphicSub2(iie2);
        PolymorphicIdRelation pir2 = new PolymorphicIdRelation(new PolymorphicIdRelationId("b", ps2));
        PolymorphicStart pps2 = new PolymorphicStart(pir2);
        
        em.persist(iie1);
        em.persist(ps1);
        em.persist(pir1);
        em.persist(pps1);
        
        em.persist(iie2);
        em.persist(ps2);
        em.persist(pir2);
        em.persist(pps2);
        
        em.flush();
        tx.commit();
        em.close();
    }
    
    @Test
    public void testCase() {
        EntityManager em = emf.createEntityManager();
        
        List<PolymorphicStart> l = em.createQuery(
                "SELECT start "
                + "FROM PolymorphicStart start "
                + "LEFT JOIN FETCH start.idRelation r "
                + "LEFT JOIN FETCH r.id.base b "
                + "ORDER BY r.id.name ASC")
                .getResultList();
        
        Assert.assertEquals(2, l.size());
        Assert.assertEquals(PolymorphicSub1.class, l.get(0).getIdRelation().getId().getBase().getClass());
        Assert.assertEquals(PolymorphicSub2.class, l.get(1).getIdRelation().getId().getBase().getClass());
        
        em.close();
    }
}
