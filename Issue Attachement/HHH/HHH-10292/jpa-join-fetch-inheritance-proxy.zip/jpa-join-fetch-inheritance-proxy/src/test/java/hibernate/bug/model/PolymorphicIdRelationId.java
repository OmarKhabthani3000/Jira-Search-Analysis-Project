package hibernate.bug.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

@Embeddable
public class PolymorphicIdRelationId implements Serializable {
    private static final long serialVersionUID = 1L;

    private String name;
    private PolymorphicBase base;

    public PolymorphicIdRelationId() {
    }

    public PolymorphicIdRelationId(String name, PolymorphicBase base) {
        this.name = name;
        this.base = base;
    }

    @Basic(optional = false)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    public PolymorphicBase getBase() {
        return base;
    }

    public void setBase(PolymorphicBase base) {
        this.base = base;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + (this.name != null ? this.name.hashCode() : 0);
        hash = 29 * hash + (this.base != null ? this.base.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PolymorphicIdRelationId other = (PolymorphicIdRelationId) obj;
        if ((this.name == null) ? (other.name != null) : !this.name.equals(other.name)) {
            return false;
        }
        if (this.base != other.base && (this.base == null || !this.base.equals(other.base))) {
            return false;
        }
        return true;
    }
}
