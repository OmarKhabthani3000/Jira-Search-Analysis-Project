package hibernate.bug.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

@Entity
public class PolymorphicSub2 extends PolymorphicBase {
    private static final long serialVersionUID = 1L;

    private MyEntity relation2;

    public PolymorphicSub2() {
    }

    public PolymorphicSub2(MyEntity relation2) {
        this.relation2 = relation2;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    public MyEntity getRelation2() {
        return relation2;
    }

    public void setRelation2(MyEntity relation2) {
        this.relation2 = relation2;
    }
}
