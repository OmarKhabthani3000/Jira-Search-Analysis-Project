package tester;

import java.sql.Date;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HQLTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		HQLTest t = new HQLTest();
		t.run();
	}

	private void run() {
		test1();
		test2();
	}
	
	void test1() {
		SessionFactory fact = getSessionFactory();
		Session sess = fact.getCurrentSession();
		sess.beginTransaction();

		try {
			String hql =
				"select (p.endDate - p.startDate) as period, p\n" +
				"from Project as p\n" +
				"order by period";
			System.out.println(hql);
			
			Query q = sess.createQuery(hql);
			q.list(); // ERROR
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		sess.getTransaction().commit();
	}
	
	void test2() {
		SessionFactory fact = getSessionFactory();
		Session sess = fact.getCurrentSession();
		sess.beginTransaction();

		try {
			String hql =
				"select (p.endDate - p.startDate) as period, p\n" +
				"from Project as p\n" +
				"where period > :period_length";
			System.out.println(hql);
			
			Query q = sess.createQuery(hql);
			q.setDate("period_length", Date.valueOf("0000-00-01"));
			q.list(); // ERROR
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		sess.getTransaction().commit();
	}

	SessionFactory getSessionFactory() {
		SessionFactory fact = new Configuration().configure().buildSessionFactory();
		return fact;
	}
	
}
