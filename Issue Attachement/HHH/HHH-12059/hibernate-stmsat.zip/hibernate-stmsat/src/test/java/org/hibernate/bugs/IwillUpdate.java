
package org.hibernate.bugs;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author matteo.steccolini
 */
@Entity
public class IwillUpdate {
	@Id
	public Integer FIELD1;
}
