package org.hibernate.test.onetoone.merge;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.test.TestCase;

public class OneToOneTest extends TestCase {

	public OneToOneTest(String str) {
		super(str);
	}
	public void testOne() throws Exception {

		Session s;
		Transaction t;
		Person person;
		Address address;

		s = openSession();
		t = s.beginTransaction();
		
		person = new Person();
		
		address = new Address();
		address.setPerson(person);
		
		person.setAddress(address);
		
		s.save(person);
		s.save(address);
		
		t.commit();
		s.close();
		
		s = openSession();
		t = s.beginTransaction();
		
		person = (Person)s.get(Person.class, person.getPersonId());
		
		t.commit();
		s.close();
		
		s = openSession();
		t = s.beginTransaction();
		
		try {
			s.merge(person);
		} catch (Exception e) {
			throw e;
		}
		
		t.commit();
		s.close();
	}

	protected String[] getMappings() {
		return new String[] { "onetoone/merge/Person.hbm.xml" };
	}

	protected void configure(Configuration cfg) {
		cfg.setProperty(Environment.USE_SECOND_LEVEL_CACHE, "false");
		cfg.setProperty(Environment.GENERATE_STATISTICS, "true");

	
//		cfg.setProperty(Environment.URL, "jdbc:postgresql://localhost:5432/hibtest");
//		cfg.setProperty(Environment.DIALECT, "org.hibernate.dialect.PostgreSQLDialect");
//		cfg.setProperty(Environment.DRIVER, "org.postgresql.Driver");
//		cfg.setProperty(Environment.USER, "********");
//		cfg.setProperty(Environment.PASS, "********");
		
	}
	
	public static Test suite() {
		return new TestSuite(OneToOneTest.class);
	}
}
