package bug.test;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Transient;

@Entity
public class Foo {

	private static final long serialVersionUID = 8486988381949739779L;

	private String description;

	private Map<String, Bar> bars;

	protected String id = java.util.UUID.randomUUID().toString();

	private int version;

	@Id
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
//
//	@Version
//	public int getVersion() {
//		return version;
//	}
//
//	public void setVersion(int version) {
//		this.version = version;
//	}

	@Transient
	public Foo getItem() {
		return this;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@ManyToMany
	public Map<String, Bar> getBars() {
		return new HashMap<String, Bar>(bars);
	}

	public void setBars(Map<String, Bar> bars) {
		this.bars = bars;
	}
}
