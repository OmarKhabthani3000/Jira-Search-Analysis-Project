package bug.test;


import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Bar {
    
	protected String id = java.util.UUID.randomUUID().toString();

	@Id 
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
