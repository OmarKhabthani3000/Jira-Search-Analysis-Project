package bug.test;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;

import org.hibernate.Session;

public class Test {

	public static void main(String[] args) throws IOException, SQLException {
		Session session = HibernateUtil.getSession();
		session.beginTransaction();

		Bar bar = new Bar();
		session.save(bar);

		Foo foo = new Foo();
		HashMap<String, Bar> bars = new HashMap<String, Bar>();
		bars.put(bar.getId(), bar);
		foo.setBars(bars);
		foo.setDescription("blah");
		session.save(foo);

		foo = new Foo();
		bars = new HashMap<String, Bar>();
		bars.put(bar.getId(), bar);
		foo.setBars(bars);
		foo.setDescription("blahblah");
		session.save(foo);

		foo = new Foo();
		bars = new HashMap<String, Bar>();
		bars.put(bar.getId(), bar);
		foo.setBars(bars);
		foo.setDescription("blahblahblah");
		session.save(foo);
		session.getTransaction().commit();
		HibernateUtil.getSession().beginTransaction();

		// note here all our former changes are saved and committed, however
		// when we commit this final save EVERY foo_bar relationship will be
		// deleted and resaved
		System.out.println("Final Save");
		foo.setDescription("blahblahblahblah");
		session.update(foo);
		session.getTransaction().commit();
		HibernateUtil.getSession().beginTransaction();
	}
}
