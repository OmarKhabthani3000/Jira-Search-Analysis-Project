Before running a test create user test/test on MySQL running at localhost:3036.
Create test database and grant "test" user all privileges to "test" database.

Execute hhh3096.RunMeTest with JUnit runner. The second test fails. 
