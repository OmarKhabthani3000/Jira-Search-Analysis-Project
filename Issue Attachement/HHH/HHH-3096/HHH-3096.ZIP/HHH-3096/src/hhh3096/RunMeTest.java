package hhh3096;

import static org.junit.Assert.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.Test;

/**
 * Tests http://opensource.atlassian.com/projects/hibernate/browse/HHH-3096
 * 
 * @author karol.bienkowski@syncron.com on 19 Aug 2008
 */
public class RunMeTest {

	/**
	 * This test is successful. It generates
	 * 
	 * <pre>
	 * select count((entitywith0_.a, entitywith0_.b)) as col_0_0_ from EntityWithCompositeKey entitywith0_
	 * </pre>
	 * 
	 * which works on H2 database.
	 */
	@Test
	public void testCountCompositeKeyH2() {
		doTest("testH2");
	}

	/**
	 * Prerequisite: Create user test/test and database test on MySQL at
	 * localhost:3036, grant user "test" all permissions to "test" DB.
	 * 
	 * This test fails. Generated SQL fails on MySQL:
	 * 
	 * <pre>
	 * Hibernate: select count((entitywith0_.a, entitywith0_.b)) as col_0_0_ from EntityWithCompositeKey entitywith0_
	 * 3616 [Main Thread] WARN org.hibernate.util.JDBCExceptionReporter - SQL Error: 1241, SQLState: 21000
	 * 3616 [Main Thread] ERROR org.hibernate.util.JDBCExceptionReporter - Operand should contain 1 column(s)
	 * </pre>
	 * 
	 * Tested on 5.0.24-community-nt.
	 */
	@Test
	public void testCountCompositeKeyMySQL() {
		doTest("testMySQL");
	}

	private void doTest(String unitName) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(unitName);
		EntityManager em = emf.createEntityManager();
		Query query = em.createNamedQuery(EntityWithCompositeKey.COUNT);
		assertEquals(0, query.getSingleResult());
	}

}
