package hhh3096;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CompositeKey implements Serializable {

	private static final long serialVersionUID = -731167551740383718L;

	public int a;

	public int b;

}
