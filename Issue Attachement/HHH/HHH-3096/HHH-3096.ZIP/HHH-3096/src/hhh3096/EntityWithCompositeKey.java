package hhh3096;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name = EntityWithCompositeKey.COUNT, query = "SELECT count(e) FROM EntityWithCompositeKey e")
public class EntityWithCompositeKey {

	public static final String COUNT = "count";

	@EmbeddedId
	public CompositeKey pk;

}
