package com.walshk.model;

import org.hibernate.envers.Audited;

import javax.persistence.*;
import java.util.Set;

@Entity
@Audited
public class OneToManyParent {

    private Long id;
    private Set<OneToManyChild> children;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @OneToMany(cascade = CascadeType.ALL)
    public Set<OneToManyChild> getChildren() {
        return children;
    }

    public void setChildren(Set<OneToManyChild> children) {
        this.children = children;
    }
}
