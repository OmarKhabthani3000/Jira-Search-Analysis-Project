package com.walshk.model;

import org.hibernate.envers.Audited;

import javax.persistence.*;
import java.util.Set;

@Entity
@Audited
public class ManyToManyParent {

    private Long id;
    private Set<ManyToManyChild> children;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @ManyToMany(cascade = CascadeType.ALL)
    public Set<ManyToManyChild> getChildren() {
        return children;
    }

    public void setChildren(Set<ManyToManyChild> children) {
        this.children = children;
    }
}
