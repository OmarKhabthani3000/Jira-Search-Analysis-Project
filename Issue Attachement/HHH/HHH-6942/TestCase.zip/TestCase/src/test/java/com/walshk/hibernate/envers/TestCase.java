package com.walshk.hibernate.envers;

import com.walshk.model.ManyToManyChild;
import com.walshk.model.ManyToManyParent;
import com.walshk.model.OneToManyChild;
import com.walshk.model.OneToManyParent;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import java.sql.SQLException;
import java.util.*;

import static java.util.Arrays.asList;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

@ContextConfiguration("classpath*:test-context.xml")
public class TestCase extends AbstractJUnit4SpringContextTests {

    @Autowired
    private HibernateTemplate hibernateTemplate;

    @Autowired
    private TransactionTemplate transactionTemplate;

    @Test
    public void manyToManyRevision_shouldNotContainRemovedChildren_afterChildCollectionReplace_andSaveOrUpdate() {
        //Given two children
        ManyToManyChild childA = new ManyToManyChild();
        ManyToManyChild childB = new ManyToManyChild();

        //That belong to a parent
        ManyToManyParent parent = new ManyToManyParent();
        parent.setChildren(setOf(childA, childB));

        saveOrUpdate(childA);
        saveOrUpdate(childB);
        saveOrUpdate(parent);

        //When the parent is updated to have one less child and a saveOrUpdate is issued
        parent.setChildren(setOf(childA));
        saveOrUpdate(parent);

        //Then the latest revision should only contain one child
        Set<ManyToManyChild> revisionChildren = childrenOfLatestRevision(parent);
        assertThat(revisionChildren.size(), is(1));
    }

    @Test
    public void manyToManyRevision_shouldNotContainRemovedChildren_afterExplicitChildRemoval_andSaveOrUpdate() {
        //Given two children
        ManyToManyChild childA = new ManyToManyChild();
        ManyToManyChild childB = new ManyToManyChild();

        //That belong to a parent
        ManyToManyParent parent = new ManyToManyParent();
        parent.setChildren(setOf(childA, childB));

        saveOrUpdate(childA);
        saveOrUpdate(childB);
        saveOrUpdate(parent);

        //When a child is removed explicitly and a saveOrUpdate is issued
        parent.getChildren().remove(childB);
        saveOrUpdate(parent);

        //Then the latest revision should only contain one child
        Set<ManyToManyChild> revisionChildren = childrenOfLatestRevision(parent);
        assertThat(revisionChildren.size(), is(1));
    }

    @Test
    public void manyToManyRevision_shouldNotContainRemovedChildren_afterChildCollectionReplace_andMerge() {
        //Given two children
        ManyToManyChild childA = new ManyToManyChild();
        ManyToManyChild childB = new ManyToManyChild();

        //That belong to a parent
        ManyToManyParent parent = new ManyToManyParent();
        parent.setChildren(setOf(childA, childB));

        saveOrUpdate(childA);
        saveOrUpdate(childB);
        saveOrUpdate(parent);

        //When the parent is updated to have one less child and a merge is issued
        parent.setChildren(setOf(childA));
        merge(parent);

        //Then the latest revision should only contain one child
        Set<ManyToManyChild> revisionChildren = childrenOfLatestRevision(parent);
        assertThat(revisionChildren.size(), is(1));
    }
    
    @Test
    public void oneToManyRevision_shouldNotContainRemovedChildren_afterChildCollectionReplace_andSaveOrUpdate() {
        //Given two children
        OneToManyChild childA = new OneToManyChild();
        OneToManyChild childB = new OneToManyChild();

        //That belong to a parent
        OneToManyParent parent = new OneToManyParent();
        parent.setChildren(setOf(childA, childB));

        saveOrUpdate(childA);
        saveOrUpdate(childB);
        saveOrUpdate(parent);

        //When the parent is updated to have one less child and a saveOrUpdate is issued
        parent.setChildren(setOf(childA));
        saveOrUpdate(parent);

        //Then the latest revision should only contain one child
        Set<OneToManyChild> revisionChildren = childrenOfLatestRevision(parent);
        assertThat(revisionChildren.size(), is(1));
    }

    @Test
    public void oneToManyRevision_shouldNotContainRemovedChildren_afterExplicitChildRemoval_andSaveOrUpdate() {
        //Given two children
        OneToManyChild childA = new OneToManyChild();
        OneToManyChild childB = new OneToManyChild();

        //That belong to a parent
        OneToManyParent parent = new OneToManyParent();
        parent.setChildren(setOf(childA, childB));

        saveOrUpdate(childA);
        saveOrUpdate(childB);
        saveOrUpdate(parent);

        //When a child is removed explicitly and a saveOrUpdate is issued
        parent.getChildren().remove(childB);
        saveOrUpdate(parent);

        //Then the latest revision should only contain one child
        Set<OneToManyChild> revisionChildren = childrenOfLatestRevision(parent);
        assertThat(revisionChildren.size(), is(1));
    }

    @Test
    public void oneToManyRevision_shouldNotContainRemovedChildren_afterChildCollectionReplace_andMerge() {
        //Given two children
        OneToManyChild childA = new OneToManyChild();
        OneToManyChild childB = new OneToManyChild();

        //That belong to a parent
        OneToManyParent parent = new OneToManyParent();
        parent.setChildren(setOf(childA, childB));

        saveOrUpdate(childA);
        saveOrUpdate(childB);
        saveOrUpdate(parent);

        //When the parent is updated to have one less child and a merge is issued
        parent.setChildren(setOf(childA));
        merge(parent);

        //Then the latest revision should only contain one child
        Set<OneToManyChild> revisionChildren = childrenOfLatestRevision(parent);
        assertThat(revisionChildren.size(), is(1));
    }
    
    private Set<ManyToManyChild> childrenOfLatestRevision(final ManyToManyParent parent) {
        return hibernateTemplate.execute(new HibernateCallback<Set<ManyToManyChild>>() {
            @Override
            public Set<ManyToManyChild> doInHibernate(Session session) throws HibernateException, SQLException {
                AuditReader reader = AuditReaderFactory.get(session);

                Number latestRevision = latestFrom(reader.getRevisions(ManyToManyParent.class, parent.getId()));

                Set<ManyToManyChild> children = reader.find(ManyToManyParent.class, parent.getId(), latestRevision).getChildren();

                //Fetch all children
                for (ManyToManyChild child : children) {}

                return children;
            }
        });
    }

    private Set<OneToManyChild> childrenOfLatestRevision(final OneToManyParent parent) {
        return hibernateTemplate.execute(new HibernateCallback<Set<OneToManyChild>>() {
            @Override
            public Set<OneToManyChild> doInHibernate(Session session) throws HibernateException, SQLException {
                AuditReader reader = AuditReaderFactory.get(session);

                Number latestRevision = latestFrom(reader.getRevisions(OneToManyParent.class, parent.getId()));

                Set<OneToManyChild> children = reader.find(OneToManyParent.class, parent.getId(), latestRevision).getChildren();

                //Fetch all children
                for (OneToManyChild child : children) {}

                return children;
            }
        });
    }

    private Number latestFrom(List<Number> revisions) {
        return revisions.get(revisions.size() - 1);
    }

    private void saveOrUpdate(final Object object) {
        transactionTemplate.execute(new TransactionCallback<Object>() {
            @Override
            public Object doInTransaction(TransactionStatus transactionStatus) {
                hibernateTemplate.saveOrUpdate(object);
                return object;
            }
        });
    }

    private void merge(final Object object) {
        transactionTemplate.execute(new TransactionCallback<Object>() {
            @Override
            public Object doInTransaction(TransactionStatus transactionStatus) {
                hibernateTemplate.merge(object);
                return object;
            }
        });
    }

    private <T> Set<T> setOf(T... tees) {
        return new HashSet<T>(asList(tees));
    }
}
