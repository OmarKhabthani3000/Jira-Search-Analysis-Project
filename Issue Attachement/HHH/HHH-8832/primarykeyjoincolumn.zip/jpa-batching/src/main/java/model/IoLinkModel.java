/*******************************************************************************
 * Copyright: DOCUFY GmbH (c) 2013
 * Company: DOCUFY GmbH,
 *          Kapuzinerstraße 32,
 *          96047 Bamberg
 *          http://www.docufy.de
 * $LastChangedBy: philipp $
 * $LastChangedDate: 2013-12-16 20:50:48 +0100 (Mo, 16 Dez 2013) $
 * $HeadURL: svn://192.168.11.107/supplemental/philipp/cosima-api/trunk/persistence/persistence-jpa/src/main/java/de/docufy/cms/persistence/model/io/IoLinkModel.java $
 * $LastChangedRevision: 1454 $
 *******************************************************************************/
package model;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.PrimaryKeyJoinColumns;
import javax.persistence.Table;

/**
 * @author Philipp
 *
 */
@Entity
@Table(name="io_link")
@Cacheable(false)
public class IoLinkModel {

	@EmbeddedId
	private IoLinkPk pk;

	@ManyToOne(optional=false)
	@PrimaryKeyJoinColumns({
		@PrimaryKeyJoinColumn(name="from_io_id", referencedColumnName="io_id"),
		@PrimaryKeyJoinColumn(name="from_iov_number", referencedColumnName="iov_number"),
		@PrimaryKeyJoinColumn(name="from_ln_code", referencedColumnName="ln_code"),
		@PrimaryKeyJoinColumn(name="from_vr_code", referencedColumnName="vr_code")
	})
	private IoLanguageVariantModel source;

	@ManyToOne(optional=false)
	@PrimaryKeyJoinColumns({
		@PrimaryKeyJoinColumn(name="to_io_id", referencedColumnName="io_id"),
		@PrimaryKeyJoinColumn(name="to_iov_number", referencedColumnName="iov_number"),
		@PrimaryKeyJoinColumn(name="to_ln_code", referencedColumnName="ln_code"),
		@PrimaryKeyJoinColumn(name="to_vr_code", referencedColumnName="vr_code")
	})
	private IoLanguageVariantModel target;

	@Column(name="iol_automatic")
	private boolean automatic;

	@Column(name="iol_translate")
	private boolean translate;

	@Column(name="iol_order")
	private double order;

	/**
	 * @return the pk
	 */
	public IoLinkPk getPk() {
		return pk;
	}

	/**
	 * @param pk the pk to set
	 */
	public void setPk(IoLinkPk pk) {
		this.pk = pk;
	}

	/**
	 * @return the source
	 */
	public IoLanguageVariantModel getSource() {
		return source;
	}

	/**
	 * @param source the source to set
	 */
	public void setSource(IoLanguageVariantModel source) {
		this.source = source;
	}

	/**
	 * @return the target
	 */
	public IoLanguageVariantModel getTarget() {
		return target;
	}

	/**
	 * @param target the target to set
	 */
	public void setTarget(IoLanguageVariantModel target) {
		this.target = target;
	}

	/**
	 * @return the automatic
	 */
	public boolean isAutomatic() {
		return automatic;
	}

	/**
	 * @param automatic the automatic to set
	 */
	public void setAutomatic(boolean automatic) {
		this.automatic = automatic;
	}

	/**
	 * @return the translate
	 */
	public boolean isTranslate() {
		return translate;
	}

	/**
	 * @param translate the translate to set
	 */
	public void setTranslate(boolean translate) {
		this.translate = translate;
	}

	/**
	 * @return the order
	 */
	public double getOrder() {
		return order;
	}

	/**
	 * @param order the order to set
	 */
	public void setOrder(double order) {
		this.order = order;
	}
}
