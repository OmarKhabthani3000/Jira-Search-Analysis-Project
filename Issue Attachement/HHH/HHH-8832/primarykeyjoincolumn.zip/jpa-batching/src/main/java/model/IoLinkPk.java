/*******************************************************************************
 * Copyright: DOCUFY GmbH (c) 2013
 * Company: DOCUFY GmbH,
 *          Kapuzinerstraße 32,
 *          96047 Bamberg
 *          http://www.docufy.de
 * $LastChangedBy: philipp $
 * $LastChangedDate: 2013-11-16 17:41:07 +0100 (Sa, 16 Nov 2013) $
 * $HeadURL: svn://192.168.11.107/supplemental/philipp/cosima-api/trunk/persistence/persistence-jpa/src/main/java/de/docufy/cms/persistence/model/io/IoLinkPk.java $
 * $LastChangedRevision: 1345 $
 *******************************************************************************/
package model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * @author Philipp
 *
 */
@Embeddable
public class IoLinkPk implements Serializable {

	private static final long serialVersionUID = 2332845608862349232L;

	@Column(name="from_io_id", length=32)
	private String fromIo;

	@Column(name="from_iov_number")
	private int fromVersion;

	@Column(name="from_ln_code", length=2)
	private String fromLanguage;

	@Column(name="from_vr_code", length=2)
	private String fromVariant;

	@Column(name="from_yid", length=35)
	private String fromYid;

	@Column(name="to_io_id", length=32)
	private String toIo;

	@Column(name="to_iov_number")
	private int toVersion;

	@Column(name="to_ln_code", length=2)
	private String toLanguage;

	@Column(name="to_vr_code", length=2)
	private String toVariant;

	@Column(name="to_yid", length=35)
	private String toYid;

	@Column(name="lt_id", length=32)
	private String type;

	/**
	 * 
	 */
	protected IoLinkPk() {
		// Needed for JPA
	}

	/**
	 * @param fromIo
	 * @param fromVersion
	 * @param fromLanguage
	 * @param fromVariant
	 * @param fromYid
	 * @param toIo
	 * @param toVersion
	 * @param toLanguage
	 * @param toVariant
	 * @param toYid
	 * @param type
	 */
	public IoLinkPk(String fromIo, int fromVersion, String fromLanguage,
			String fromVariant, String fromYid, String toIo, int toVersion,
			String toLanguage, String toVariant, String toYid, String type) {
		this.fromIo = fromIo;
		this.fromVersion = fromVersion;
		this.fromLanguage = fromLanguage;
		this.fromVariant = fromVariant;
		this.fromYid = fromYid;
		this.toIo = toIo;
		this.toVersion = toVersion;
		this.toLanguage = toLanguage;
		this.toVariant = toVariant;
		this.toYid = toYid;
		this.type = type;
	}

	/**
	 * @return the fromIo
	 */
	public String getFromIo() {
		return fromIo;
	}

	/**
	 * @param fromIo the fromIo to set
	 */
	public void setFromIo(String fromIo) {
		this.fromIo = fromIo;
	}

	/**
	 * @return the fromVersion
	 */
	public int getFromVersion() {
		return fromVersion;
	}

	/**
	 * @param fromVersion the fromVersion to set
	 */
	public void setFromVersion(int fromVersion) {
		this.fromVersion = fromVersion;
	}

	/**
	 * @return the fromLanguage
	 */
	public String getFromLanguage() {
		return fromLanguage;
	}

	/**
	 * @param fromLanguage the fromLanguage to set
	 */
	public void setFromLanguage(String fromLanguage) {
		this.fromLanguage = fromLanguage;
	}

	/**
	 * @return the fromVariant
	 */
	public String getFromVariant() {
		return fromVariant;
	}

	/**
	 * @param fromVariant the fromVariant to set
	 */
	public void setFromVariant(String fromVariant) {
		this.fromVariant = fromVariant;
	}

	/**
	 * @return the fromYid
	 */
	public String getFromYid() {
		return fromYid;
	}

	/**
	 * @param fromYid the fromYid to set
	 */
	public void setFromYid(String fromYid) {
		this.fromYid = fromYid;
	}

	/**
	 * @return the toIo
	 */
	public String getToIo() {
		return toIo;
	}

	/**
	 * @param toIo the toIo to set
	 */
	public void setToIo(String toIo) {
		this.toIo = toIo;
	}

	/**
	 * @return the toVersion
	 */
	public int getToVersion() {
		return toVersion;
	}

	/**
	 * @param toVersion the toVersion to set
	 */
	public void setToVersion(int toVersion) {
		this.toVersion = toVersion;
	}

	/**
	 * @return the toLanguage
	 */
	public String getToLanguage() {
		return toLanguage;
	}

	/**
	 * @param toLanguage the toLanguage to set
	 */
	public void setToLanguage(String toLanguage) {
		this.toLanguage = toLanguage;
	}

	/**
	 * @return the toVariant
	 */
	public String getToVariant() {
		return toVariant;
	}

	/**
	 * @param toVariant the toVariant to set
	 */
	public void setToVariant(String toVariant) {
		this.toVariant = toVariant;
	}

	/**
	 * @return the toYid
	 */
	public String getToYid() {
		return toYid;
	}

	/**
	 * @param toYid the toYid to set
	 */
	public void setToYid(String toYid) {
		this.toYid = toYid;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fromIo == null) ? 0 : fromIo.hashCode());
		result = prime * result
				+ ((fromLanguage == null) ? 0 : fromLanguage.hashCode());
		result = prime * result
				+ ((fromVariant == null) ? 0 : fromVariant.hashCode());
		result = prime * result + fromVersion;
		result = prime * result + ((fromYid == null) ? 0 : fromYid.hashCode());
		result = prime * result + ((toIo == null) ? 0 : toIo.hashCode());
		result = prime * result
				+ ((toLanguage == null) ? 0 : toLanguage.hashCode());
		result = prime * result
				+ ((toVariant == null) ? 0 : toVariant.hashCode());
		result = prime * result + toVersion;
		result = prime * result + ((toYid == null) ? 0 : toYid.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		IoLinkPk other = (IoLinkPk) obj;
		if (fromIo == null) {
			if (other.fromIo != null)
				return false;
		} else if (!fromIo.equals(other.fromIo))
			return false;
		if (fromLanguage == null) {
			if (other.fromLanguage != null)
				return false;
		} else if (!fromLanguage.equals(other.fromLanguage))
			return false;
		if (fromVariant == null) {
			if (other.fromVariant != null)
				return false;
		} else if (!fromVariant.equals(other.fromVariant))
			return false;
		if (fromVersion != other.fromVersion)
			return false;
		if (fromYid == null) {
			if (other.fromYid != null)
				return false;
		} else if (!fromYid.equals(other.fromYid))
			return false;
		if (toIo == null) {
			if (other.toIo != null)
				return false;
		} else if (!toIo.equals(other.toIo))
			return false;
		if (toLanguage == null) {
			if (other.toLanguage != null)
				return false;
		} else if (!toLanguage.equals(other.toLanguage))
			return false;
		if (toVariant == null) {
			if (other.toVariant != null)
				return false;
		} else if (!toVariant.equals(other.toVariant))
			return false;
		if (toVersion != other.toVersion)
			return false;
		if (toYid == null) {
			if (other.toYid != null)
				return false;
		} else if (!toYid.equals(other.toYid))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}
}
