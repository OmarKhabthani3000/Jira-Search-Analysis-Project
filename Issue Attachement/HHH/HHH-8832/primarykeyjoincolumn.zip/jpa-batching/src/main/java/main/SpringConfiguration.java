/*******************************************************************************
 * Copyright: DOCUFY GmbH (c) 2013
 * Company: DOCUFY GmbH,
 *          Kapuzinerstraße 32,
 *          96047 Bamberg
 *          http://www.docufy.de
 * $LastChangedBy: frank $
 * $LastChangedDate: 2013-02-25 17:47:28 +0100 (Mo, 25 Feb 2013) $
 * $HeadURL: svn://192.168.11.107/projects/viessmann/trunk/server/kernelplugin/src/main/java/de/docufy/viessmann/service/resolver/handler/ViessmannAttributeExtender.java $
 * $LastChangedRevision: 67530 $
 *******************************************************************************/
package main;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


/**
 * @author Philipp
 *
 */
@Configuration
@ImportResource("classpath:spring/persistence-context.xml")
@EnableJpaRepositories("repository")
public class SpringConfiguration {

}
