/*******************************************************************************
 * Copyright: DOCUFY GmbH (c) 2013
 * Company: DOCUFY GmbH,
 *          Kapuzinerstraße 32,
 *          96047 Bamberg
 *          http://www.docufy.de
 * $LastChangedBy: philipp $
 * $LastChangedDate: 2014-01-02 19:31:49 +0100 (Do, 02 Jan 2014) $
 * $HeadURL: svn://192.168.11.107/supplemental/philipp/cosima-api/trunk/persistence/persistence-jpa/src/main/java/de/docufy/cms/persistence/model/io/IoLanguageVariantModel.java $
 * $LastChangedRevision: 1465 $
 *******************************************************************************/
package model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author Philipp
 *
 */
@Entity
@Table(name="io_language_variant")
public class IoLanguageVariantModel {

	@EmbeddedId
	private IoLanguageVariantPk pk;

	@Column(name="lgv_title")
	private String title;

	@Column(name="lgv_source_language")
	private boolean sourceLanguage;

	@OneToMany(mappedBy="source")
	private List<IoLinkModel> linksFrom;

	@OneToMany(mappedBy="target")
	private List<IoLinkModel> linksTo;

	/**
	 * @return the pk
	 */
	public IoLanguageVariantPk getPk() {
		return pk;
	}

	/**
	 * @param pk the pk to set
	 */
	public void setPk(IoLanguageVariantPk pk) {
		this.pk = pk;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the sourceLanguage
	 */
	public boolean isSourceLanguage() {
		return sourceLanguage;
	}

	/**
	 * @param sourceLanguage the sourceLanguage to set
	 */
	public void setSourceLanguage(boolean sourceLanguage) {
		this.sourceLanguage = sourceLanguage;
	}

	/**
	 * @return the linksFrom
	 */
	public List<IoLinkModel> getLinksFrom() {
		return linksFrom;
	}

	/**
	 * @param linksFrom the linksFrom to set
	 */
	public void setLinksFrom(List<IoLinkModel> linksFrom) {
		this.linksFrom = linksFrom;
	}

	/**
	 * @return the linksTo
	 */
	public List<IoLinkModel> getLinksTo() {
		return linksTo;
	}

	/**
	 * @param linksTo the linksTo to set
	 */
	public void setLinksTo(List<IoLinkModel> linksTo) {
		this.linksTo = linksTo;
	}
}
