/*******************************************************************************
 * Copyright: DOCUFY GmbH (c) 2013
 * Company: DOCUFY GmbH,
 *          Kapuzinerstraße 32,
 *          96047 Bamberg
 *          http://www.docufy.de
 * $LastChangedBy: philipp $
 * $LastChangedDate: 2013-11-16 17:41:07 +0100 (Sa, 16 Nov 2013) $
 * $HeadURL: svn://192.168.11.107/supplemental/philipp/cosima-api/trunk/persistence/persistence-jpa/src/main/java/de/docufy/cms/persistence/repository/io/IoLinkRepository.java $
 * $LastChangedRevision: 1345 $
 *******************************************************************************/
package repository;

import model.IoLinkModel;
import model.IoLinkPk;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Philipp
 *
 */
public interface IoLinkRepository extends JpaRepository<IoLinkModel, IoLinkPk> {

}
