/*******************************************************************************
 * Copyright: DOCUFY GmbH (c) 2013
 * Company: DOCUFY GmbH,
 *          Kapuzinerstraße 32,
 *          96047 Bamberg
 *          http://www.docufy.de
 * $LastChangedBy: frank $
 * $LastChangedDate: 2013-02-25 17:47:28 +0100 (Mo, 25 Feb 2013) $
 * $HeadURL: svn://192.168.11.107/projects/viessmann/trunk/server/kernelplugin/src/main/java/de/docufy/viessmann/service/resolver/handler/ViessmannAttributeExtender.java $
 * $LastChangedRevision: 67530 $
 *******************************************************************************/
package service;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import model.IoLinkModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import repository.IoLanguageVariantRepository;
import repository.IoLinkRepository;

/**
 * @author Philipp
 *
 */
@Component
public class BatchProcessor {

	@Autowired
	private IoLanguageVariantRepository iolvRepo;
	@Autowired
	private IoLinkRepository linkRepo;
	
	@PersistenceContext
	private EntityManager entityManager;

	@PostConstruct
	public void doWork() {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<IoLinkModel> cq = cb.createQuery(IoLinkModel.class);
		Root<IoLinkModel> e = cq.from(IoLinkModel.class);
		Predicate p1 = cb.equal(e.get("pk").get("fromIo"), "123456");
		Predicate p2 = cb.equal(e.get("pk").get("fromVersion"), 1);
		Predicate p3 = cb.equal(e.get("pk").get("fromLanguage"), "de");
		Predicate p4 = cb.equal(e.get("pk").get("fromVariant"), "DE");
		
		cq.where(p1, p2, p3, p4);
		
		for (IoLinkModel model : entityManager.createQuery(cq).getResultList()) {
			
		}
	}

}
