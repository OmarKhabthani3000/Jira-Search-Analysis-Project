package test;

import java.util.List;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Expression;


public class Test extends TestCase {
	Configuration configuration;
	SessionFactory sessionFactory;
	
	public void setUp() throws Exception {
		configuration = new Configuration();
		configuration.configure();
		sessionFactory = configuration.buildSessionFactory();
	}

	
	public void testIt() throws Exception {
		Session session = sessionFactory.openSession();
		String uniq = "uniq" + System.currentTimeMillis();

		// insert object
		try {
			Transaction tx = session.beginTransaction();

			
			TestObject obj = new TestObject();
			obj.setText("XyZ " + uniq + " blablabla");
			
			session.saveOrUpdate(obj);
			session.flush();
			tx.commit();
		} finally {
			session.close();

		}
		
		String pattern = "XyZ " + uniq + "%";

		// retrieve object - case sensitive - works ok
		session = sessionFactory.openSession();
		try {
			List objects = session.createCriteria(TestObject.class)
						   .add(Expression.like("text", pattern))
						   .list();
			
			assertEquals(1, objects.size());
		} finally {
			session.close();
		}

		// retrieve object - case insensitive - works ok
		session = sessionFactory.openSession();
		try {
			List objects = session.createCriteria(TestObject.class)
						   .add(Expression.like("text", pattern).ignoreCase())
						   .list();
			
			assertEquals(1, objects.size());
		} finally {
			session.close();
		}

		
		// retrieve object - case insensitive via custom expression - works ok
		session = sessionFactory.openSession();
		try {
			List objects = session.createCriteria(TestObject.class)
						   .add(StringExpression.stringExpression("text", pattern, true))
						   .list();
			
			assertEquals(1, objects.size());
		} finally {
			session.close();
		}

		
		// retrieve object - case sensitive via custom expression - not working
		session = sessionFactory.openSession();
		try {
			List objects = session.createCriteria(TestObject.class)
						   .add(StringExpression.stringExpression("text", pattern, false))
						   .list();
			
			assertEquals(1, objects.size());
		} finally {
			session.close();
		}
		
		
	}	
}
