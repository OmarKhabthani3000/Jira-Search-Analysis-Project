package org.hibernate.model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "base_object")
public class BaseObject implements Serializable {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    @Column(name = "name", nullable = false, unique = true)
    private String name;
    @ManyToMany
    @JoinTable(
            name = "related_objects",
            joinColumns = @JoinColumn(name = "base_name", referencedColumnName = "name"),
            inverseJoinColumns = @JoinColumn(name = "related_name", referencedColumnName = "name")
    )
    private Set<RelatedObject> related = new HashSet<>();

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<RelatedObject> getRelated() {
        return related;
    }

    public void setRelated(Set<RelatedObject> related) {
        this.related = related;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 79 * hash + Objects.hashCode(getId());
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof BaseObject)) {
            return false;
        }
        final BaseObject other = (BaseObject) obj;
        if (!Objects.equals(this.getId(), other.getId())) {
            return false;
        }
        return true;
    }
}
