package com.lmig.hibernate;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.mapping.Property;
import org.hibernate.mapping.RootClass;
import org.hibernate.type.BlobType;
import org.hibernate.type.ClobType;
import org.hibernate.type.Type;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.util.TablesNamesFinder;

public class Helper {
	private static final Logger logger = LoggerFactory.getLogger(Helper.class);
	
	// could read the view definitions at runtime and extract this...
	private static final Map<String, String[]> extraDependencies = new HashMap<String, String[]>();
			
			/*Collections.unmodifiableMap(
		    new HashMap<String, String[]>() {{
		        put("BOB_HIERARCHY", new String[] {"THIRDPARTY", "THIRDPARTYRELATIONSHIP"});
		        put("CLAIMSACVIEW", new String[] {"CLAIMSACCESSCONTROLENTRY", "USERRELATIONSHIP", "S_PRINCIPAL", "S_PERMISSIONS","S_AUTHORITY","S_ROLE_PRIVILEGES"});
		        put("DOCV_LABEL", new String[] {"DOC_LABEL", "DOC_TYPE_LABEL" });
		        put("DOCV_NODE", new String[] {"DOC_NODE", "DOC_NODE_EVENT", "DOC_EVENT", "DOC_DOCUMENT_EVENT","DOC_DOCUMENT_TYPE"});
		        put("DOCV_NODE_PATH", new String[] {"DOCV_NODE"}); // reference above
		        put("DOCV_NODE_PRIVILEGES", new String[] {"DOC_NODE_PRIVILEGE_EVENT", "DOC_NODE_EVENT"});
		        put("DOCV_TYPE_MAP", new String[] {"DOC_TYPE_MAP_EVENT", "DOC_DOCUMENT_TYPE"});
		        put("VIEW_CAMPAIGN_TARGET", new String[] {"CAMPAIGN", "FIELDCRITERIA" ,"FIELDCRITERIA","STRINGFIELDCRITERIA_VALUE","LOOKUPLIST","LOOKUPVALUE"});
		    }});*/
	
	static public Collection<String> getTables(String queryString) {
		if (queryString == null || queryString.trim().isEmpty()) {
			return Collections.EMPTY_SET;
		}
		Collection<String> tablesFromQuery = extractTableFromQuery(queryString);
		// need to supplement with extra dependencies like when from DB view(s)
		HashSet<String> processed = new HashSet<String>();
		HashSet<String> extraTables = new HashSet<String>();
		
		// Pass 1
		for (String table :tablesFromQuery) {
			String upperCaseTable = table.toUpperCase();
			processed.add(upperCaseTable);
			String[] tmpExtraTables = extraDependencies.get(upperCaseTable);
			if (tmpExtraTables!=null) {
				List<String> toAdd = Arrays.asList(tmpExtraTables);
				toAdd.removeAll(processed);
				extraTables.addAll(toAdd);
			}
		}
		
		// Pass 2+
		while(!extraTables.isEmpty()) {
			String table = extraTables.iterator().next();
			processed.add(table);
			String[] tmpExtraTables = extraDependencies.get(table);
			if (tmpExtraTables!=null) {
				List<String> toAdd = Arrays.asList(tmpExtraTables);
				toAdd.removeAll(processed);
				extraTables.addAll(toAdd);
			}
			extraTables.remove(table);
		}
		
		return processed;
	}

	private static Collection<String> extractTableFromQuery(String queryString) {
		queryString = queryString.replace(':', ' ');
		Statement statement;
		try {
			statement = CCJSqlParserUtil.parse(queryString);
			TablesNamesFinder tablesNamesFinder = new TablesNamesFinder();
			List<String> tableList = tablesNamesFinder.getTableList(statement);
			return tableList;
		} catch (JSQLParserException e) {
			logger.warn("Not able to figure out the table(s) referenced by this query: "+ queryString, e);
			
			return Collections.EMPTY_SET;
		}
	}
	
	public static boolean isEntityCacheable(Object persistentClass) {
		if (persistentClass instanceof RootClass) {
			org.hibernate.mapping.RootClass rootPersistentClass= (RootClass)persistentClass;
			Iterator propertyIterator = rootPersistentClass.getPropertyIterator();
			for (Iterator ite=propertyIterator;ite.hasNext();) {
				Object propertyObj = ite.next();
				if (propertyObj instanceof Property) {
					Property property = (Property)propertyObj;
					Type type = property.getType();
					if (type instanceof BlobType || type instanceof ClobType) {
						logger.info("Persistent class: {}, will not be entity cached because its property: {}, is a {}.",rootPersistentClass.getEntityName(),property.getName(),type.getName());
						return false;
					}
				}	
			}
		}
		return true;
	}

	public static void processViewDependencies(Collection<Object[]> listOfViewDefinitions) {
		for (Object[] viewNameAndViewDefinition : listOfViewDefinitions) {
			String viewName = viewNameAndViewDefinition[0].toString().toUpperCase();
			String viewDefinition = viewNameAndViewDefinition[1].toString().toUpperCase();
			Collection<String> dependentTables = extractTableFromQuery(viewDefinition);
			extraDependencies.put(viewName,getInArrayAllUpperCase(dependentTables));
		}
	}

	private static String[] getInArrayAllUpperCase(Collection<String> dependentTables) {
		String[] tables = (String[]) dependentTables.toArray(new String[0]);
		for (int i=0;i<tables.length;i++) {
			tables[i] = tables[i].toUpperCase();
		}
		return tables;
	}

}
