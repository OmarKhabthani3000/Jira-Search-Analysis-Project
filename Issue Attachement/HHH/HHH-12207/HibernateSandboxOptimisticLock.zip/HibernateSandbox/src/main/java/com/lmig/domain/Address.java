package com.lmig.domain;

import java.sql.Blob;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Version;
import org.hibernate.cache.*;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class Address {

	//@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	private int id;
	private String street;
	
	@Version
	@Column(name = "version")
	private int version;
	
	//@Lob
	//private Blob receivedXml;

	public Address() {
	}
	
	public Address(int id, String street) {
		this.id = id;
		this.street = street;
	}

	public Address(String street) {
		this.street = street;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public void setVersion(int version) {
		this.version = version;
		
	}

}
