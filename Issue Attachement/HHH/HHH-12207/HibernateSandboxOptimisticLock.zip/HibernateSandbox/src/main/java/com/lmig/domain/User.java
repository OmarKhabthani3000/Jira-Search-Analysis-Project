package com.lmig.domain;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Version;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.FetchProfile;

@FetchProfile(name = "user-all-eager", fetchOverrides = {
		@FetchProfile.FetchOverride(entity = User.class, association = "addresses", mode = org.hibernate.annotations.FetchMode.JOIN)
		})
@NamedQuery
(name="User.findAll", query="SELECT u FROM User u") 
@Entity
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class User {

	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Id
	private int id;
	private String name;
	private String surname;
	
	@Version
	@Column(name = "version")
	private int version;

	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY)
    @JoinColumn(name="USER_ID")
	private Collection<Address> addresses = new ArrayList();
	public User() {
		
	}
	public User(int id, String name, String surname) {
		this.id = id;
		this.name = name;
		this.surname = surname;
	}
    public Collection<Address> getAddresses() {
        return addresses;
    }
	 
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getSurname() {
		return surname;
	}
	
	public void setSurname(String surname) {
		this.surname = surname;
	}	
	
	@Override
	public String toString() {
		StringBuffer strBuff = new StringBuffer();
		strBuff.append("id : ").append(id);
		strBuff.append(", name : ").append(name);
		strBuff.append(", surname : ").append(surname);
		return strBuff.toString();
	}
	

}
