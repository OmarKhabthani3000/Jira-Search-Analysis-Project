package com.lmig.monitoring;

import java.io.IOException;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.view.facelets.ResourceResolver;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.newrelic.api.agent.NewRelic;

//import com.exigen.ipb.jsf.utils.BeanLookupUtil;

public class NewRelicBrowserInstrumentationInjector extends ResourceResolver {
	private static final Logger logger = LoggerFactory.getLogger(NewRelicBrowserInstrumentationInjector.class);

	private ResourceResolver parent;

	private Map<String, URL> processedTemplates = new ConcurrentHashMap<String, URL>();
	
	private String browserTimingHeader;
	private String browserTimingFooter;

	public NewRelicBrowserInstrumentationInjector(ResourceResolver parent) {
		this.parent = parent;
		logger.debug(
				"NewRelicBrowserInstrumentationInjector constructor called with parent: {}, but will delegate to BeanLookupUtil.getResourceResolver().",
				parent);
	}

	@Override
	public URL resolveUrl(String path) {
		logger.debug("NewRelicBrowserInstrumentationInjector resolveUrl called with path: {}.", path);

		URL urlToReturn = processedTemplates.get(path);

		if (urlToReturn != null) {
			return urlToReturn;
		}

		if (isTemplate(path)) {
			URL urlToRemeber = originalResolve(path);
			String originalString = getOriginalString(urlToRemeber);
			if (originalString == null) {
				return null;
			}
			String modifiedString = injectAsNeeded(path,originalString);
			if (modifiedString != originalString) {
				urlToRemeber = InMemoryURLFactory.getInstance().build(path, modifiedString.getBytes());
				logger.debug("NewRelicBrowserInstrumentationInjector caching template of path: {} with url: {}.", path,
						urlToRemeber);	
			} 
			
			processedTemplates.put(path, urlToRemeber);

			return urlToRemeber;
						
			
		}

		return originalResolve(path);
	}
	
	String injectAsNeeded(String originalString) {
		return injectAsNeeded("unknown",originalString);
	}

	String injectAsNeeded(String path,String originalString) {
		
		if (originalString == null ) {
			return "";
		}
		
		StringBuilder workedString = new StringBuilder(originalString);
		if (injectHead(workedString) && injectBody(workedString)) {
			
			logger.info("NewRelic Browser Instrumentation Added to path: {}.",path);
			logger.debug("Full output for path: {} is [{}].",path,workedString);
			return workedString.toString();
			
		}
		
		logger.debug("NewRelicBrowserInstrumentationInjector didn't find a head and/or body for: {template}.", originalString);
		
		return originalString;
		
	}

	private boolean injectHead(StringBuilder workedString) {

		// find <h:head> or <head>
		int indexAfterHead = getIndexAfter(0, workedString, "<h:head>", "<head>");

		if (indexAfterHead == -1) {
			// no head, cannot process
			return false;
		}

		int indexLocationToInject = getIndexAfterLastRegex(indexAfterHead, workedString, "<meta\\s.*?/>");
		if (indexLocationToInject == -1) {
			indexLocationToInject = indexAfterHead;
		}

		workedString.insert(indexLocationToInject, getBrowserTimingHeader());
		return true;
	}

	synchronized String getBrowserTimingHeader() {
		if (browserTimingHeader==null) {
			browserTimingHeader = wrap(unwrap(NewRelic.getBrowserTimingHeader()));
		}
		return browserTimingHeader;
	}
	
	synchronized String getBrowserTimingFooter() {
		if (browserTimingFooter == null) {
			browserTimingFooter = wrap(unwrap(NewRelic.getBrowserTimingFooter()));
		}
		return browserTimingFooter;
	}
	
	String unwrap(String newRelicScript) {
		// Create a Pattern object
        Pattern r = Pattern.compile("<script type=\"text/javascript\">(.*)</script>");

        // Now create matcher object.
        Matcher m = r.matcher(newRelicScript);

        if (m.find()) {
           return m.group(1);
        }
        
        return newRelicScript;
	}

	private String wrap(String newRelicScript) {
		return 	"\n"+
				"<script type=\"text/javascript\">" + "\n"+
				"//<![CDATA["+ "\n" +
				newRelicScript + "\n" +
				"//]]>" + "\n" +
				"</script>" + "\n";
	}

	private boolean injectBody(StringBuilder workedString) {

		// find before </h:body> or </body>
		int indexBeforeEndBody = getIndexBefore(workedString, "</h:body>", "</body>");
		if (indexBeforeEndBody == -1) {
			// no body...
			return false;
		}
		
		workedString.insert(indexBeforeEndBody, getBrowserTimingFooter());
		return true;
	}

	private int getIndexBefore(StringBuilder stringToSearchOn, String... toMatchOr) {
		int indexFound;
		for (String toMatch: toMatchOr) {
			indexFound = stringToSearchOn.indexOf(toMatch);
			if (indexFound != -1) {
				return indexFound;
			}
		}
		
		return -1;
	}

	private int getIndexAfterLastRegex(int indexAfterHead, StringBuilder stringToSearchOn, String regex) {
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(stringToSearchOn);
		int indexFound = -1;
		while (m.find()) {
			indexFound = m.end();
		}
		
		if (indexAfterHead>indexFound) {
			return -1;
		}
		return indexFound;
	}

	private int getIndexAfter(int i, StringBuilder stringToSearchOn, String... toMatchOr) {
		int indexFound;
		for (String toMatch: toMatchOr) {
			indexFound = stringToSearchOn.indexOf(toMatch);
			if (indexFound != -1) {
				return indexFound+toMatch.length();
			}
		}
		
		return -1;
	}

	private String getOriginalString(URL originalURL) {
		
		if (originalURL==null) {
			return null;
		}
		try {
			return IOUtils.toString( originalURL, "UTF-8" );
		} catch (IOException e) {
			throw new RuntimeException(e); //NOSONAR
		}
	}
	
	private URL originalResolve(String path) {
		return parent.resolveUrl(path);
		// return BeanLookupUtil.getResourceResolver().resolveUrl(path);
	}

	private boolean isTemplate(String path) {
		return (!StringUtils.isEmpty(path)) && path.endsWith(".xhtml");
	}

}