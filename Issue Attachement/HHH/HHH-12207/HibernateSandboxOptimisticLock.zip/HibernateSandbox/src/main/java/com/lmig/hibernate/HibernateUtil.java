package com.lmig.hibernate;

import java.lang.management.ManagementFactory;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Cache;
import org.hibernate.SessionFactory;
import org.hibernate.ejb.EntityManagerFactoryImpl;
import org.hibernate.impl.SessionFactoryImpl;
import org.hibernate.jmx.StatisticsService;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.management.ManagementService;

public class HibernateUtil {

	private static EntityManagerFactoryImpl emf = null;

	public static EntityManagerFactoryImpl getEntityManagerFactory() {
		if (emf == null) {
			System.setProperty("tc.active", "true");
			emf = (EntityManagerFactoryImpl)Persistence.createEntityManagerFactory("persistenceUnit");

			MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();
			StatisticsService statsMBean = new StatisticsService();
			
			SessionFactory sessionFactory = getSessionFactory();
			statsMBean.setSessionFactory(sessionFactory);
			statsMBean.setStatisticsEnabled(true);
			
			//Cache cache = sessionFactory.getCache();
		//	ManagementService.registerMBeans(CacheManager.getCacheManager("HibernateEHCache"), mBeanServer, true, true, true, true);
			try {
				mBeanServer.registerMBean(statsMBean, new ObjectName("Hibernate:application=Statistics"));
		
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return emf;
	}

	public static SessionFactoryImpl getSessionFactory() {
		EntityManagerFactoryImpl entityManagerFactoryImpl = getEntityManagerFactory();
		SessionFactory sessionFactory = entityManagerFactoryImpl.getSessionFactory();
		return (SessionFactoryImpl)sessionFactory;
	}
	
}
