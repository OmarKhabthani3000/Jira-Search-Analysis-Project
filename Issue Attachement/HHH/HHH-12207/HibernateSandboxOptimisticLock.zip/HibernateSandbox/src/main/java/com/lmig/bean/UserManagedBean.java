package com.lmig.bean;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.type.StandardBasicTypes;

import com.lmig.domain.Address;
import com.lmig.domain.User;
import com.lmig.hibernate.HibernateUtil;

public class UserManagedBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(UserManagedBean.class);
	private static final String SUCCESS = "success";
	private static final String ERROR = "error";
	private String name;
	private String surname;
	private String message;
	private static User lastSavedUser;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getMessage() {
		StringBuffer strBuff = new StringBuffer();
		strBuff.append("Name : ").append(this.getName());
		strBuff.append(", Surname : ").append(this.getSurname());
		this.setMessage(strBuff.toString());
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getSave() {
		return "my get Save";
	}
	
	public String loadAllManyTimes() {
		for (int i =0;i<3;i++) {
			getUsers();
		}
		return SUCCESS;
	}


	public String modifyLastSaved() {
		if (lastSavedUser == null) {
			return ERROR;
		} else {
			getUsers();
			EntityManager entityManager = HibernateUtil.getEntityManagerFactory().createEntityManager();
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			lastSavedUser.setName(lastSavedUser.getName() + "+");
			entityManager.unwrap(Session.class).update(lastSavedUser);
		
			Query query = entityManager.createNativeQuery("update UseR set name ='asdf' where id = 233232");
			
		
			// should trigger no flush
			try {
				entityManager.find(User.class, 1);
				query.executeUpdate();
			}
			catch(Exception ex) {
				// don't care
			}
		
			tx.commit();
			entityManager.close();
			return SUCCESS;
		}

	}

	public String save() {
		String result = null;
		EntityManager entityManager = HibernateUtil.getEntityManagerFactory().createEntityManager();

		User user = new User();
		user.setName(this.getName());
		user.setSurname(this.getSurname());
		user.getAddresses().add(new Address("TheStreet"));
		EntityTransaction tx = null;

		try {
			tx = entityManager.getTransaction();
			tx.begin();
			entityManager.persist(user);
			lastSavedUser = user;
			tx.commit();
			log.debug("New Record : " + user + ", isActive : " + tx.isActive());
			result = SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			if (tx.isActive()) {
				tx.rollback();
				result = ERROR;
				e.printStackTrace();
			}
		} finally {
			entityManager.close();
		}
		return result;
	}

	public static class NameSurname {
		String name;
		String surname;
	}
	public Collection<User> getUsers() {
		EntityManager entityManager = HibernateUtil.getEntityManagerFactory().createEntityManager();
		// not working but should
		// entityManager.unwrap(Session.class).enableFetchProfile("user-all-eager"); 

		EntityTransaction tx = entityManager.getTransaction();
		tx.begin();
		// query.executeUpdate();
		// query.getResultList();
		Query query = entityManager.createQuery("SELECT u FROM User u");
		try {
			List<User> listUsers = query.getResultList();
			for (User user:listUsers) {
				user.getAddresses().size(); // force lazy load
			}
			
			SQLQuery sqlquery = entityManager.unwrap(Session.class).createSQLQuery("select name as name ,surname as surname from user");
			List<Object[]> list = sqlquery.list();
			if (!list.isEmpty()) {
				Object[] nameSurname = list.get(0);
				String name= (String)nameSurname[0];
				String surname= (String)nameSurname[1];
			}
			
			return listUsers;
		} finally {
			tx.commit();
			entityManager.close();
		}
	}

	public void reset() {
		this.setName("");
		this.setSurname("");
	}
}