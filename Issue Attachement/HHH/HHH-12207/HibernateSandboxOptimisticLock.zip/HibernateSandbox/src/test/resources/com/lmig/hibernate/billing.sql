select distinct accounting3_.id as id108_, accounting3_.billingEvent_id as billing20_108_, accounting3_.transactionDate as transact3_108_, accounting3_.transactionEffectiveDate as transact4_108_, accounting3_.account_id as account21_108_, accounting3_.period_id as period22_108_, accounting3_.dueDate as dueDate108_, accounting3_.invoiceAdditionalStatus as invoiceA6_108_, accounting3_.invoiceNumber as invoiceN7_108_, accounting3_.invoiceStatus as invoiceS8_108_, accounting3_.snapshot_id as snapshot23_108_, accounting3_.additionalInfo as addition9_108_, accounting3_.amount as amount108_, accounting3_.currency as currency108_, accounting3_.originalPayment_id as origina24_108_, accounting3_.paymentDetails_id as payment25_108_, accounting3_.paymentNumber as payment12_108_, accounting3_.invoice_id as invoice26_108_, accounting3_.additionalDiscardReason as additio13_108_, accounting3_.discardReason as discard14_108_, accounting3_.customerNumber as custome15_108_, accounting3_.originalAmount as origina16_108_, accounting3_.receivedFrom as receive17_108_, accounting3_.referenceNumber as referen18_108_, accounting3_.suspenseStatus as suspens19_108_, accounting3_.accountingDocument_id as account27_108_, accounting3_.DTYPE as DTYPE108_ 
from TransactionAssociation transactio0_, TransactionAssociation suspenseas1_ 
inner join TransactionAssociation suspenseit2_ on suspenseas1_.suspenseItem_id=suspenseit2_.id 
inner join AccountingTransaction accounting3_ on suspenseit2_.originalTransaction_id=accounting3_.id 
where suspenseas1_.DTYPE='SuspenseAssociationItem' and transactio0_.transaction_id=:1  
and (suspenseas1_.id in (select suspenseas5_.id 
from TransactionAssociation suspenseal4_ 
inner join TransactionAssociation suspenseas5_ on suspenseal4_.associationItem_id=suspenseas5_.id 
where suspenseal4_.DTYPE='SuspenseAllocationItem' and suspenseal4_.id=transactio0_.id) or suspenseas1_.id in 
(select suspenseas7_.id 
from TransactionAssociation unallocate6_ 
inner join TransactionAssociation suspenseas7_ on unallocate6_.associationItem_id=suspenseas7_.id 
where unallocate6_.DTYPE='UnallocatedPaymentItem' and unallocate6_.id=transactio0_.id) or suspenseas1_.id in 
(select suspenseas8_.id from TransactionAssociation suspenseas8_ where suspenseas8_.DTYPE='SuspenseAssociationItem' and suspenseas8_.id=transactio0_.id))