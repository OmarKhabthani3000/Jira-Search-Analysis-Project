WITH PATH ( L, NODE_ID, NAME, PARENT_ID ) AS
						  (select   
						    1 AS L,
						    NODE_ID,
						    NAME,
						    PARENT_ID  
						  FROM DOCV_NODE
						  WHERE NODE_ID = ? AND REPOSITORY_ID = ?
						  UNION ALL
						  SELECT   
						    B.L + 1 AS L,
						    A.NODE_ID,
						    A.NAME,
						    A.PARENT_ID  
						  FROM DOCV_NODE A
						  INNER JOIN PATH B
						  ON A.NODE_ID = B.PARENT_ID AND A.REPOSITORY_ID = ?
						)  
						SELECT 
						  NAME
						FROM PATH ORDER BY L DESC