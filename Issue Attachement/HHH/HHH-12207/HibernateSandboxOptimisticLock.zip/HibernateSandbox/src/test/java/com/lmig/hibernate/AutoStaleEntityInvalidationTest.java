package com.lmig.hibernate;

import static org.junit.Assert.fail;
import org.hibernate.cache.CacheKey;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.transaction.NotSupportedException;
import javax.transaction.SystemException;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.StaleObjectStateException;
import org.hibernate.Transaction;
import org.hibernate.cache.access.EntityRegionAccessStrategy;
import org.hibernate.cache.entry.CacheEntry;
import org.hibernate.connection.ConnectionProvider;
import org.hibernate.impl.SessionFactoryImpl;
import org.hibernate.impl.SessionImpl;
import org.hibernate.persister.entity.EntityPersister;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.lmig.domain.Address;
import com.lmig.domain.User;

import junit.framework.Assert;
import net.sf.ehcache.hibernate.regions.EhcacheEntityRegion;

public class AutoStaleEntityInvalidationTest {
	final static Logger logger = Logger.getLogger(AutoStaleEntityInvalidationTest.class);
	private SessionFactoryImpl sessionFactory;
	Session session1;
	Session session2;

	@Before
	public void initConnection() throws NotSupportedException, SystemException {
		System.setProperty("net.sf.ehcache.skipUpdateCheck", "true");
		sessionFactory = HibernateUtil.getSessionFactory();
		executeSQLBypassingHibernate("SET DATABASE EVENT LOG SQL LEVEL 3");
		session1 = sessionFactory.openSession();

	}

	@After
	public void close() {
		executeSQLBypassingHibernate("TRUNCATE SCHEMA PUBLIC RESTART IDENTITY AND COMMIT NO CHECK");
	}

	@Test
	public void testOptimisticLockException_Flush_LocalV0_CacheV0_DBV1() {
		try {
			Transaction tx1 = session1.beginTransaction();
			User emp1 = new User(5, "tom", "Dearman");
			Address address = new Address(5, "tom");
			session1.save(emp1);
			session1.save(address);
			tx1.commit();
			session1.close();

			executeSQLBypassingHibernate("update Address set version = version + 1");
			session2 = sessionFactory.openSession();
			Transaction tx2 = session2.beginTransaction();
			User emp2 = (User) session2.get(User.class, 5);
			Address mana2 = (Address) session2.get(Address.class, 5);

			emp2.setName("tom6@gmail.com");
			mana2.setStreet("tom6@gmail.com");
			try {
				session2.flush();
				tx2.commit();
			} finally {
				session2.close();
			}
			fail("Expected StaleObjectStateException");
		} catch (StaleObjectStateException e) {
			Session session3 = sessionFactory.openSession();
			Transaction tx3 = session3.beginTransaction();
			executeSQLBypassingHibernate("update User set name = 'NewFirstName'");
			// should have cache hit, but will not
			User emp3 = (User) session3.get(User.class, 5);
			if (emp3.getName().equals("NewFirstName")) {
				logger.info(
						"Employee didn't get a cache hit because got invalidated as a side effect of manager having a version mismatch. Not optimal behavior.");
			} else {
				logger.info("Employee got a cache hit");
			}
			Address mana3 = (Address) session3.get(Address.class, 5);
			mana3.setStreet("me6@gmail.com");
			session3.save(emp3);
			tx3.commit(); // not throwing exception here means than manager got an update from DB
			session3.close();
		}
	}

	@Test
	public void testOptimisticLockException_Merge_LocalV1_CacheV0_DBV1() {
		try {
			Transaction tx1 = session1.beginTransaction();
			Address mana1 = (Address) new Address(1, "tom");
			session1.save(mana1);
			tx1.commit();
			session1.close();

			// outside our control the db has changed
			int outsideVersion = 666;
			executeSQLBypassingHibernate("update Address set version = " + outsideVersion);
			session2 = sessionFactory.openSession();
			Transaction tx2 = session2.beginTransaction();
			Address mana2 = (Address) session2.get(Address.class, 1);
			CacheEntry mana2_2ndLevelCache = getDirectlyFrom2ndLevelCache(session2,Address.class, 1);
			mana1.setVersion(outsideVersion);
			try {
				tx2.rollback();
			session2.merge(mana1);
			}
			finally {
				session2.close();
			}
			fail("Should have throw an StaleObjectStateException");
		} catch (StaleObjectStateException e) {
			
			Session session3 = sessionFactory.openSession();
			Transaction tx3 = session3.beginTransaction();
			// should NOT have a cache hit to be able to get version 666
			CacheEntry mana2_2ndLevelCache = getDirectlyFrom2ndLevelCache(session2,Address.class, 1);
			Address mana3 = (Address) session3.get(Address.class, 1);
			
			mana3.setStreet("me6@gmail.com");
			try {
			session3.save(mana3);
			tx3.commit();}
			finally {
				session3.close();
			}
		}
	}
	
	@Test
	public void testDefaultFlushEntityEventListener_getDatabaseSnapshot() {
		// not sure how to test
	}
	
	@Test
	public void testLoader_checkVersion() {
		// not sure how to test
	}
	
	@Test
	public void testAbstractEntityPersister_forceVersionIncrement() throws IllegalAccessException {
		// tried but I don't know how to test this
	}
	
	@Test
	public void testLock() {
		Transaction tx1 = session1.beginTransaction();
		User emp1 = new User(15, "tom", "Dearman");
		Address address = new Address(15, "tom");
		session1.save(emp1);
		session1.save(address);
		tx1.commit();
		session1.close();

		executeSQLBypassingHibernate("update Address set version = version + 1");
		session2 = sessionFactory.openSession();
		Transaction tx2 = session2.beginTransaction();
		Address emp2 = (Address) session2.get(Address.class, 15);
		try {
			session2.lock(emp2, LockMode.PESSIMISTIC_WRITE);
			fail("Expected StaleObjectStateException");
		}
		catch(StaleObjectStateException sose) {
			Session session3 = sessionFactory.openSession();
			Transaction tx3 = session3.beginTransaction();
			emp2 = (Address) session3.get(Address.class, 15);

			session3.lock(emp2, LockMode.PESSIMISTIC_WRITE);
			tx3.rollback();
			session3.close();
		}
		finally {
			
			session2.close();
		}
	}
	
	@Test
	public void testDelete() {
		Transaction tx1 = session1.beginTransaction();
		User emp1 = new User(20, "tom", "Dearman");
		Address address = new Address(20, "tom");
		session1.save(emp1);
		session1.save(address);
		tx1.commit();
		session1.close();

		executeSQLBypassingHibernate("update Address set version = version + 1");
		session2 = sessionFactory.openSession();
		Transaction tx2 = session2.beginTransaction();
		Address emp2 = (Address) session2.get(Address.class, 20);
		try {
			session2.delete(emp2);
			session2.flush();
			fail("Expected StaleObjectStateException");
		}
		catch(StaleObjectStateException sose) {
			session2.close();
			Session session3 = sessionFactory.openSession();
			CacheEntry cacheEntry = getDirectlyFrom2ndLevelCache(session3,Address.class, 20);
			Assert.assertNull(cacheEntry);

			Address emp3 = (Address) session3.get(Address.class, 20);
			Assert.assertNotNull(emp3);
			session3.close();
		}
	}

	/*
	 * Other constructs available to write tests Object key =
	 * generateCacheKey(Manager.class, 1);
	 * 
	 * EhcacheEntityRegion entityRegion = getRegion(Manager.class); Object obj =
	 * entityRegion.get(key); entityRegion.remove(key);
	 */
	
	private <T> CacheEntry getDirectlyFrom2ndLevelCache(Session session, Class<T> clazz, Serializable identifier) {
		SessionImpl sessionImpl = (SessionImpl)session;
		SessionFactoryImpl sessionFactoryImpl = (SessionFactoryImpl)session.getSessionFactory();
		EntityPersister entityPersister = sessionFactoryImpl.getEntityPersister(clazz.getName());
	
		EntityRegionAccessStrategy entityRegionAccessStrategy = entityPersister.getCacheAccessStrategy();
		
		CacheKey ck = new CacheKey(
				identifier,
				entityPersister.getIdentifierType(),
				entityPersister.getRootEntityName(),
				session.getEntityMode(),
				sessionFactoryImpl);
		
		CacheEntry cacheEntry = (CacheEntry)entityPersister.getCacheAccessStrategy().get( ck, sessionImpl.getTimestamp() );
		
		return cacheEntry;
	}

	
	private EhcacheEntityRegion getRegion(Class clazz) {
		EntityRegionAccessStrategy cache2 = getCacheAccessStrategy(clazz);
		return (EhcacheEntityRegion) cache2.getRegion();
	}

	private Object generateCacheKey(Class clazz, Serializable id) {
		EntityPersister p = getEntityPersister(clazz);
		EntityRegionAccessStrategy cache2 = getCacheAccessStrategy(clazz);
		return null;// cache2.generateCacheKey(id, p, sf, null);
	}

	private EntityRegionAccessStrategy getCacheAccessStrategy(Class clazz) {
		EntityPersister p = getEntityPersister(clazz);
		return p.getCacheAccessStrategy();
	}

	private EntityPersister getEntityPersister(Class clazz) {
		return null;// sf.getMetamodel().entityPersister(clazz.getName());
	}

	private void executeSQLBypassingHibernate(String sql) {
		try {
			ConnectionProvider connectionProvider = sessionFactory.getConnectionProvider();
			Connection connection = connectionProvider.getConnection();
			connection.setAutoCommit(true);
			Statement stmt = connection.createStatement();
			stmt.execute(sql);
			stmt.close();
			connection.commit();
			connection.close();
	
			// Assert.assertEquals(1, stmt.getUpdateCount());
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
