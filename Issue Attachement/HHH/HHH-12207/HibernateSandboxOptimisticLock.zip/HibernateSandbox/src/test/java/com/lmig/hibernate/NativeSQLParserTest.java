package com.lmig.hibernate;
import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Test;

class NativeSQLParserTest {

	@Test
	void test() throws IOException {

		assertThat(Helper.getTables("")).containsExactlyInAnyOrder();
		assertThat(Helper.getTables("select id from ClaimsICDCode where ICDCode=:ICDCodeselect")).containsExactlyInAnyOrder("CLAIMSICDCODE");
		assertThat(Helper.getTables(" select id from ClaimsICDCode where ICDCode=:ICDCodeselect")).containsExactlyInAnyOrder("CLAIMSICDCODE");
		assertThat(Helper.getTables("select id i from ClaimsICDCode where ICDCode=:ICDCodeselect")).containsExactlyInAnyOrder("CLAIMSICDCODE");
		assertThat(Helper.getTables("select id from ClaimsICDCode as c where ICDCode=:ICDCodeselect")).containsExactlyInAnyOrder("CLAIMSICDCODE");
		
		Collection<String> result = Helper.getTables(
				"select Coverage.id from Coverage where Coverage.RiskItem_ID in "+
		"(select RiskItem.id from RiskItem where RiskItem.POLICYDETAIL_ID in (select PolicySummary.policyDetail_id from PolicySummary where PolicySummary.id in (:policyIds) ))");
		assertThat(result).containsExactlyInAnyOrder("POLICYSUMMARY", "COVERAGE", "RISKITEM");
		
		assertThat(Helper.getTables("update BillingAccount set disabledConstraints=:disabledConstraints where accountnumber=:accountNumber")).containsExactlyInAnyOrder("BILLINGACCOUNT");
		
		assertThat(Helper.getTables("update user set name ='asdf' where id = 233232")).containsExactlyInAnyOrder("USER");
		assertThat(Helper.getTables(" update user set name ='asdf' where id = 233232")).containsExactlyInAnyOrder("USER");
		assertThat(Helper.getTables(" update user u set name ='asdf' where id = 233232")).containsExactlyInAnyOrder("USER");
		assertThat(Helper.getTables("update user as u set name ='asdf' where id = 233232")).containsExactlyInAnyOrder("USER");
		
		assertThat(Helper.getTables("UPDATE COMMISSIONTRANSACTION SET CREATIONDATE = :date WHERE COMMISSIONABLEPRODUCT_ID IN (SELECT ID from COMMISSIONABLEPRODUCT WHERE PRODUCTNUMBER = :policyNumber)")).containsExactlyInAnyOrder("COMMISSIONTRANSACTION","COMMISSIONABLEPRODUCT");
		assertThat(Helper.getTables("select ICDCode,CodeDescription from ClaimsICDCode where LOWER(CodeDescription) like LOWER(:searchText) ESCAPE '\\\\' or LOWER(ICDCode) like LOWER(:searchText) ESCAPE '\\\\' order by ICDCode")).containsExactlyInAnyOrder("CLAIMSICDCODE");
		
		String sql = IOUtils.toString( this.getClass().getResourceAsStream("billing.sql"));
		assertThat(Helper.getTables(sql)).containsExactlyInAnyOrder("TRANSACTIONASSOCIATION","ACCOUNTINGTRANSACTION");
		
		sql = IOUtils.toString( this.getClass().getResourceAsStream("chartOfAccount.sql"));
		assertThat(Helper.getTables(sql)).containsExactlyInAnyOrder("TRANSACTIONASSOCIATION","TRANSACTIONASSOCIATIONENTRY", "CHARTOFACCOUNTS");
		
		sql = IOUtils.toString( this.getClass().getResourceAsStream("security.sql"));
		assertThat(Helper.getTables(sql)).containsExactlyInAnyOrder("S_PRINCIPAL","S_AUTHORITY", "S_ROLE_PRIVILEGES","S_USER_GROUP","S_PERMISSIONS");
		
		Collection<Object[]> viewNameAndDefinition = new ArrayList<Object[]>();
		
		viewNameAndDefinition.add(new Object[]{"DOCV_NODE", "SELECT\n" + 
				"				B.NODE_TYPE,\n" + 
				"				B.EVENT_ID AS LAST_EVENT_ID,\n" + 
				"				B.NODE_ID,\n" + 
				"				B.PARENT_ID,\n" + 
				"				B.NAME,\n" + 
				"				C.CHANGE_TIME,\n" + 
				"				C.PERFORMER,\n" + 
				"				C.EVENT_TYPE,\n" + 
				"				C.REPOSITORY_ID,\n" + 
				"				D.DOCUMENT_TYPE_ID,\n" + 
				"				D.OWNER,\n" + 
				"				D.CONTENT_LENGHT,\n" + 
				"				D.CONTENT_TYPE,\n" + 
				"				D.DOC_COMMENT,\n" + 
				"				E.CODE AS DOC_TYPE_CODE,\n" + 
				"				E.NAME AS DOC_TYPE_NAME,\n" + 
				"				B.SOURCE_URL,\n" + 
				"				F.CHANGE_TIME AS CREATE_TIME,\n" + 
				"				F.PERFORMER AS CREATE_PERFORMER\n" + 
				"			FROM\n" + 
				"			DOC_NODE A\n" + 
				"			INNER JOIN   DOC_NODE_EVENT B ON A.LAST_EVENT_ID = LAST_EVENT_ID AND A.NODE_ID=B.NODE_ID\n" + 
				"			INNER JOIN   DOC_EVENT C ON A.LAST_EVENT_ID = C.EVENT_ID\n" + 
				"			INNER JOIN   DOC_NODE_EVENT G ON G.NODE_ID = A.NODE_ID\n" + 
				"			INNER JOIN   DOC_EVENT F ON G.EVENT_ID = F.EVENT_ID\n" + 
				"			LEFT  JOIN   DOC_DOCUMENT_EVENT D ON  A.LAST_EVENT_ID = D.EVENT_ID  AND A.NODE_ID = D.NODE_ID\n" + 
				"			LEFT  JOIN   DOC_DOCUMENT_TYPE E ON D.DOCUMENT_TYPE_ID = E.DOCUMENT_TYPE_ID\n" + 
				"			WHERE B.DELETE_EVENT_ID IS NULL   AND\n" + 
				"				(F.EVENT_TYPE  = 'CREATE_DOCUMENT'  OR F.EVENT_TYPE = 'CREATE_FOLDER' OR  F.EVENT_TYPE = 'DEPLOY')"});
		
		viewNameAndDefinition.add(new Object[]{"DOCV_NODE_PATH", "WITH PATH ( PATH_LEVEL, FULL_PATH, NODE_ID, NAME, PARENT_ID, CHANGE_TIME, PERFORMER, REPOSITORY_ID, NODE_TYPE, OWNER, DOCUMENT_TYPE_ID, CONTENT_LENGHT, CONTENT_TYPE, DOC_COMMENT, DOC_TYPE_CODE, DOC_TYPE_NAME, SOURCE_URL ) AS ( SELECT 0 AS PATH_LEVEL, '/' || NAME AS FULL_PATH, NODE_ID, NAME, PARENT_ID, CHANGE_TIME, PERFORMER, REPOSITORY_ID, NODE_TYPE, OWNER, DOCUMENT_TYPE_ID, CONTENT_LENGHT, CONTENT_TYPE, DOC_COMMENT, DOC_TYPE_CODE, DOC_TYPE_NAME, SOURCE_URL FROM DOCV_NODE WHERE PARENT_ID IS NULL UNION ALL SELECT B.PATH_LEVEL + 1 AS PATH_LEVEL, ( B.FULL_PATH || '/' || A.NAME ) AS FULL_PATH, A.NODE_ID, A.NAME, A.PARENT_ID, A.CHANGE_TIME, A.PERFORMER, A.REPOSITORY_ID, A.NODE_TYPE, A.OWNER, A.DOCUMENT_TYPE_ID, A.CONTENT_LENGHT, A.CONTENT_TYPE, A.DOC_COMMENT, A.DOC_TYPE_CODE, A.DOC_TYPE_NAME, A.SOURCE_URL FROM DOCV_NODE A INNER JOIN PATH B ON B.NODE_ID = A.PARENT_ID ) SELECT PATH_LEVEL, FULL_PATH, NODE_ID, NAME, PARENT_ID, CHANGE_TIME, PERFORMER, REPOSITORY_ID, NODE_TYPE, OWNER, DOCUMENT_TYPE_ID, CONTENT_LENGHT, CONTENT_TYPE, DOC_COMMENT, DOC_TYPE_CODE, DOC_TYPE_NAME, SOURCE_URL FROM PATH"});
		
		Helper.processViewDependencies(viewNameAndDefinition);
		
		// This test extra dependencies of view calling another view
		sql = IOUtils.toString( this.getClass().getResourceAsStream("path.sql"));
		assertThat(Helper.getTables(sql)).containsExactlyInAnyOrder("DOCV_NODE","DOC_DOCUMENT_EVENT",
			    "DOC_NODE_EVENT",
			    "DOC_DOCUMENT_TYPE",
			    "DOC_NODE",
			    "DOC_EVENT");
		
		assertThat(Helper.getTables("select * from dOCV_NODE_PATH")).containsExactlyInAnyOrder("DOCV_NODE","DOC_DOCUMENT_EVENT",
			    "DOC_NODE_EVENT",
			    "DOC_DOCUMENT_TYPE",
			    "DOC_NODE",
			    "DOC_EVENT","DOCV_NODE_PATH");
	}
}
