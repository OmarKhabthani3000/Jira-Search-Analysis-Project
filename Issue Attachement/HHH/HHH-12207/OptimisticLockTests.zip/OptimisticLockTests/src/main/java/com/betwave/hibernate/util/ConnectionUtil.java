package com.betwave.hibernate.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionUtil
{
    private static SessionFactory sessionFactory = buildSessionFactory();

    private static Connection connection = createConnection();

    private static final String userName = "sa";
    private static final String password = "";
    //private static final String url = "jdbc:postgresql://localhost:5432/tom";
    private static final String url = "jdbc:hsqldb:mem:tom";

    private static Connection createConnection() {
        Properties props = new Properties();
        props.setProperty("user",userName);
        props.setProperty("password",password);
        try {
            return DriverManager.getConnection(url, props);
        } catch (SQLException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    private static SessionFactory buildSessionFactory()
    {
        try
        {
            if (sessionFactory == null)
            {
                Configuration configuration = new Configuration().configure();
                Properties properties = new Properties();

                properties.put("hibernate.connection.username", userName);
                properties.put("hibernate.connection.password", password);
                properties.put("hibernate.connection.url",url);
                configuration.addProperties(properties);

                sessionFactory = configuration.buildSessionFactory();
            }
            return sessionFactory;
        } catch (Throwable ex)
        {
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory()
    {
        return sessionFactory;
    }

    public static Connection getConnection()
    {
        return connection;
    }

    public static void shutdown()
    {
        if (sessionFactory != null)
        {
            sessionFactory.close();
        }

        try {
            if (connection != null)
            {
                connection.close();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
