package com.betwave.hibernate;

import static org.junit.Assert.fail;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.persistence.OptimisticLockException;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cache.ehcache.internal.regions.EhcacheEntityRegion;
import org.hibernate.cache.spi.access.EntityRegionAccessStrategy;
import org.hibernate.internal.SessionFactoryImpl;
import org.hibernate.persister.entity.EntityPersister;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.betwave.hibernate.util.ConnectionUtil;

public class EmployeeTest {
	final static Logger logger = Logger.getLogger(EmployeeTest.class);
	private SessionFactoryImpl sf;
	private Connection connection;
	Session session1;
	Session session2;

	@Before 
	public void initConnection() {
		System.setProperty("net.sf.ehcache.skipUpdateCheck", "true");
		sf = (SessionFactoryImpl) ConnectionUtil.getSessionFactory();
		connection = ConnectionUtil.getConnection();
		try {
			connection.setAutoCommit(true);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		
		session1 = sf.openSession();
		session2 = sf.openSession();
	}

	@After
	public void close() {
		executeSQLBypassingHibernate("TRUNCATE SCHEMA PUBLIC RESTART IDENTITY AND COMMIT NO CHECK");
	}

	@Test
	public void testOptimisticLockException_Flush_LocalV0_CacheV0_DBV1() {
		try {
			Transaction tx1 = session1.beginTransaction();
			Employee emp1 = new Employee(1, "tom", "Dearman", "td@gmail.com");
			Manager mana1 = new Manager(1, "tom", "Dearman", "td@gmail.com");
			session1.save(emp1);
			session1.save(mana1);
			tx1.commit();
			session1.close();

			executeSQLBypassingHibernate("update Manager set version = version + 1 where MANAGER_ID = 1");

			Transaction tx2 = session2.beginTransaction();
			Employee emp2 = session2.get(Employee.class, 1);
			Manager mana2 = session2.get(Manager.class, 1);

			emp2.setEmail("tom6@gmail.com");
			mana2.setEmail("tom6@gmail.com");

			tx2.commit();
			fail("Expected OptimisticLockException");
		} catch (OptimisticLockException e) {
			Session session3 = sf.openSession();
			Transaction tx3 = session3.beginTransaction();
			executeSQLBypassingHibernate("update Employee set FIRST_NAME = 'NewFirstName'");
			// should have cache hit, but will not
			Employee emp3 = session3.get(Employee.class, 1);
			if (emp3.getFirstName().equals("NewFirstName")){
				logger.info("Employee didn't get a cache hit because got invalidated as a side effect of manager having a version mismatch. Not optimal behavior.");
			} else {
				logger.info("Employee got a cache hit");
			}
			Manager mana3 = session3.get(Manager.class, 1);
			mana3.setEmail("me6@gmail.com");
			session3.save(emp3);
			tx3.commit(); // not throwing exception here means than manager got an update from DB
		}
	}

	@Test
	public void testOptimisticLockException_Merge_LocalV1_CacheV0_DBV1() {
		try {
			Transaction tx1 = session1.beginTransaction();
			Manager mana1 = new Manager(1, "tom", "Dearman", "td@gmail.com");
			session1.save(mana1);
			tx1.commit();
			session1.close();

			// outside our control the db has changed
			int outsideVersion = 666;
			executeSQLBypassingHibernate("update Manager set version = "+outsideVersion);
			Transaction tx2 = session2.beginTransaction();
			Manager mana2 = session2.get(Manager.class, 1);
			mana1.setVersion(666);
			session2.merge(mana1);
			fail("Should have throw an optimistic lock exception");
		} catch (OptimisticLockException e) {
			Session session3 = sf.openSession();
			Transaction tx3 = session3.beginTransaction();
			// should NOT have a cache hit to be able to get version 666
			Manager mana3 = session3.get(Manager.class, 1);
			mana3.setEmail("me6@gmail.com");
			session3.save(mana3);
			tx3.commit();
		}
	}

	/*
	 * Other constructs available to write tests
  			Object key = generateCacheKey(Manager.class, 1);

			EhcacheEntityRegion entityRegion = getRegion(Manager.class);
			Object obj = entityRegion.get(key);
			entityRegion.remove(key);
	 */
	private EhcacheEntityRegion getRegion(Class clazz) {
		EntityRegionAccessStrategy cache2 = getCacheAccessStrategy(clazz);
		return (EhcacheEntityRegion) cache2.getRegion();
	}

	private Object generateCacheKey(Class clazz, Serializable id) {
		EntityPersister p = getEntityPersister(clazz);
		EntityRegionAccessStrategy cache2 = getCacheAccessStrategy(clazz);
		return cache2.generateCacheKey(id, p, sf, null);
	}

	private EntityRegionAccessStrategy getCacheAccessStrategy(Class clazz) {
		EntityPersister p = getEntityPersister(clazz);
		return p.getCacheAccessStrategy();
	}

	private EntityPersister getEntityPersister(Class clazz) {
		return sf.getMetamodel().entityPersister(clazz.getName());
	}
	
	private void executeSQLBypassingHibernate(String sql) {
		try {
			connection.setAutoCommit(true);
			Statement stmt = connection.createStatement();
			stmt.execute(sql);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
