package org.hibernate.bugs;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import jakarta.persistence.criteria.Root;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This template demonstrates how to develop a test case for Hibernate ORM, using the Java Persistence API.
 */
public class JPAUnitTestCase {

	private EntityManagerFactory entityManagerFactory;

	@Before
	public void init() {
		entityManagerFactory = Persistence.createEntityManagerFactory( "templatePU" );
	}

	@After
	public void destroy() {
		entityManagerFactory.close();
	}

	// Entities are auto-discovered, so just add them anywhere on class-path
	// Add your tests, using standard JUnit.
	@Test
	public void hhh17085Test() throws Exception {
		try(EntityManager entityManager = entityManagerFactory.createEntityManager()) {
			entityManager.getTransaction().begin();
			persistData(entityManager);
			var cb = entityManager.getCriteriaBuilder();
			var query = cb.createTupleQuery();
			Root<Primary> root = query.from(Primary.class);
			var secondaryJoin = root.join("secondary");
			//when
			query.multiselect(
					secondaryJoin.get("entityName").alias("secondary"),
					cb.sum(root.get("amount")).alias("sum")
			).groupBy(
					secondaryJoin
			).orderBy(
					cb.desc(secondaryJoin.get("entityName"))
			);
			var list = entityManager.createQuery(query).getResultList();
			//then
			assertThat(list).hasSize(3);
			var tupleIt = list.iterator();
			var tuple = tupleIt.next();
			assertThat(tuple.get("secondary", String.class)).isEqualTo("c");
			assertThat(tuple.get("sum", BigDecimal.class)).isEqualByComparingTo(new BigDecimal("6000"));
			tuple = tupleIt.next();
			assertThat(tuple.get("secondary", String.class)).isEqualTo("b");
			assertThat(tuple.get("sum", BigDecimal.class)).isEqualByComparingTo(new BigDecimal("600"));
			tuple = tupleIt.next();
			assertThat(tuple.get("secondary", String.class)).isEqualTo("a");
			assertThat(tuple.get("sum", BigDecimal.class)).isEqualByComparingTo(new BigDecimal("60"));
		}
	}

	private void persistData(EntityManager em) {
		var secondaryA = createSecondary(1, "a");
		var secondaryB = createSecondary(2, "b");
		var secondaryC = createSecondary(3, "c");

		var entities = new ArrayList<Object>(List.of(
				createPrimary(1, new BigDecimal("10"), secondaryA),
				createPrimary(2, new BigDecimal("20"), secondaryA),
				createPrimary(3, new BigDecimal("30"), secondaryA),
				createPrimary(4, new BigDecimal("100"), secondaryB),
				createPrimary(5, new BigDecimal("200"), secondaryB),
				createPrimary(6, new BigDecimal("300"), secondaryB),
				createPrimary(7, new BigDecimal("1000"), secondaryC),
				createPrimary(8, new BigDecimal("2000"), secondaryC),
				createPrimary(9, new BigDecimal("3000"), secondaryC)
		));
		entities.addAll(List.of(
				secondaryA, secondaryB, secondaryC
		));
		entities.forEach(em::persist);
		em.flush();
		em.clear();
	}

	private Primary createPrimary(int id, BigDecimal amount, Secondary secondary) {
		var entity = new Primary();
		entity.setId(id);
		entity.setAmount(amount);
		entity.setSecondary(secondary);
		return entity;
	}

	private Secondary createSecondary(int id, String entityName) {
		var entity = new Secondary();
		entity.setId(id);
		entity.setEntityName(entityName);
		return entity;
	}
}
