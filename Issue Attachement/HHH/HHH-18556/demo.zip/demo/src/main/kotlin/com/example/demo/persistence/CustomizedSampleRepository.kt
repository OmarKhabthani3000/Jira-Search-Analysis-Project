package com.example.demo.persistence

import com.example.demo.vo.SampleVO

interface CustomizedSampleRepository {
    fun testQueryDslNPE(): SampleVO?
}