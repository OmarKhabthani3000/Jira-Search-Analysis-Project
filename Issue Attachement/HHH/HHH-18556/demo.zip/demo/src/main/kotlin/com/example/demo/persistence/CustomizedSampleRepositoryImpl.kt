package com.example.demo.persistence

import com.example.demo.vo.SampleVO
import com.querydsl.core.types.Projections
import com.querydsl.core.types.dsl.Expressions
import org.springframework.data.jpa.repository.support.QuerydslRepositorySupport

class CustomizedSampleRepositoryImpl : QuerydslRepositorySupport(SampleEntity::class.java), CustomizedSampleRepository {
    override fun testQueryDslNPE(): SampleVO? {
        val sample = QSampleEntity.sampleEntity
        val case = sample.name.`when`("param1").then(1)
            .otherwise(Expressions.nullExpression(Int::class.javaObjectType))

        return from(sample)
            .select(Projections.constructor(
                SampleVO::class.java,
                case.count()
            )).fetchOne()
    }
}