package com.example.demo.persistence

import org.springframework.data.jpa.repository.JpaRepository

interface SampleRepository : JpaRepository<SampleEntity, Long>, CustomizedSampleRepository {
}