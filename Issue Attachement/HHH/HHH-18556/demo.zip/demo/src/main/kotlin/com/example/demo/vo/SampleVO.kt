package com.example.demo.vo

data class SampleVO(
    val count: Long
)