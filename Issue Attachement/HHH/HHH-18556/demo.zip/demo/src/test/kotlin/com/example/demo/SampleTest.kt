package com.example.demo

import com.example.demo.persistence.SampleRepository
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class SampleTest(
    @Autowired val sampleRepository: SampleRepository
) {

    @Test
    fun test() {
        val vo = sampleRepository.testQueryDslNPE()
    }
}